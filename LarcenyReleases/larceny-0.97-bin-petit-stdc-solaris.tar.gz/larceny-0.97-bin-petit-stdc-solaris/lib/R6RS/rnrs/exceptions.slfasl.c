/* Generated from /proj/will/pnkfelix/larcenytest/larceny-petit-Nightly-2009-08-19/larceny_src/lib/R6RS/rnrs/exceptions.slfasl */
#include "petit-instr.h"

static RTYPE compiled_block_1_1271( CONT_PARAMS );
static RTYPE compiled_block_1_1270( CONT_PARAMS );
static RTYPE compiled_start_1_0( CONT_PARAMS );
static RTYPE compiled_start_1_3( CONT_PARAMS );
static RTYPE compiled_block_1_1267( CONT_PARAMS );
static RTYPE compiled_block_1_1050( CONT_PARAMS );
static RTYPE compiled_start_1_2( CONT_PARAMS );
static RTYPE compiled_block_1_1231( CONT_PARAMS );
static RTYPE compiled_block_1_1233( CONT_PARAMS );
static RTYPE compiled_block_1_1235( CONT_PARAMS );
static RTYPE compiled_block_1_1237( CONT_PARAMS );
static RTYPE compiled_block_1_1239( CONT_PARAMS );
static RTYPE compiled_block_1_1246( CONT_PARAMS );
static RTYPE compiled_block_1_1248( CONT_PARAMS );
static RTYPE compiled_block_1_1250( CONT_PARAMS );
static RTYPE compiled_block_1_1252( CONT_PARAMS );
static RTYPE compiled_block_1_1257( CONT_PARAMS );
static RTYPE compiled_block_1_1256( CONT_PARAMS );
static RTYPE compiled_block_1_1255( CONT_PARAMS );
static RTYPE compiled_block_1_1254( CONT_PARAMS );
static RTYPE compiled_block_1_1253( CONT_PARAMS );
static RTYPE compiled_block_1_1241( CONT_PARAMS );
static RTYPE compiled_block_1_1242( CONT_PARAMS );
static RTYPE compiled_block_1_1244( CONT_PARAMS );
static RTYPE compiled_block_1_1243( CONT_PARAMS );
static RTYPE compiled_block_1_1240( CONT_PARAMS );
static RTYPE compiled_block_1_1056( CONT_PARAMS );
static RTYPE compiled_block_1_1189( CONT_PARAMS );
static RTYPE compiled_block_1_1191( CONT_PARAMS );
static RTYPE compiled_block_1_1193( CONT_PARAMS );
static RTYPE compiled_block_1_1195( CONT_PARAMS );
static RTYPE compiled_block_1_1197( CONT_PARAMS );
static RTYPE compiled_block_1_1204( CONT_PARAMS );
static RTYPE compiled_block_1_1206( CONT_PARAMS );
static RTYPE compiled_block_1_1208( CONT_PARAMS );
static RTYPE compiled_block_1_1210( CONT_PARAMS );
static RTYPE compiled_block_1_1213( CONT_PARAMS );
static RTYPE compiled_block_1_1219( CONT_PARAMS );
static RTYPE compiled_block_1_1218( CONT_PARAMS );
static RTYPE compiled_block_1_1217( CONT_PARAMS );
static RTYPE compiled_block_1_1216( CONT_PARAMS );
static RTYPE compiled_block_1_1215( CONT_PARAMS );
static RTYPE compiled_block_1_1214( CONT_PARAMS );
static RTYPE compiled_block_1_1211( CONT_PARAMS );
static RTYPE compiled_block_1_1199( CONT_PARAMS );
static RTYPE compiled_block_1_1200( CONT_PARAMS );
static RTYPE compiled_block_1_1202( CONT_PARAMS );
static RTYPE compiled_block_1_1201( CONT_PARAMS );
static RTYPE compiled_block_1_1198( CONT_PARAMS );
static RTYPE compiled_block_1_1055( CONT_PARAMS );
static RTYPE compiled_block_1_1171( CONT_PARAMS );
static RTYPE compiled_block_1_1173( CONT_PARAMS );
static RTYPE compiled_block_1_1175( CONT_PARAMS );
static RTYPE compiled_block_1_1177( CONT_PARAMS );
static RTYPE compiled_block_1_1179( CONT_PARAMS );
static RTYPE compiled_block_1_1181( CONT_PARAMS );
static RTYPE compiled_block_1_1054( CONT_PARAMS );
static RTYPE compiled_block_1_1143( CONT_PARAMS );
static RTYPE compiled_block_1_1145( CONT_PARAMS );
static RTYPE compiled_block_1_1147( CONT_PARAMS );
static RTYPE compiled_block_1_1149( CONT_PARAMS );
static RTYPE compiled_block_1_1151( CONT_PARAMS );
static RTYPE compiled_block_1_1153( CONT_PARAMS );
static RTYPE compiled_block_1_1156( CONT_PARAMS );
static RTYPE compiled_block_1_1162( CONT_PARAMS );
static RTYPE compiled_block_1_1161( CONT_PARAMS );
static RTYPE compiled_block_1_1160( CONT_PARAMS );
static RTYPE compiled_block_1_1159( CONT_PARAMS );
static RTYPE compiled_block_1_1158( CONT_PARAMS );
static RTYPE compiled_block_1_1157( CONT_PARAMS );
static RTYPE compiled_block_1_1154( CONT_PARAMS );
static RTYPE compiled_block_1_1053( CONT_PARAMS );
static RTYPE compiled_block_1_1119( CONT_PARAMS );
static RTYPE compiled_block_1_1121( CONT_PARAMS );
static RTYPE compiled_block_1_1123( CONT_PARAMS );
static RTYPE compiled_block_1_1125( CONT_PARAMS );
static RTYPE compiled_block_1_1127( CONT_PARAMS );
static RTYPE compiled_block_1_1130( CONT_PARAMS );
static RTYPE compiled_block_1_1132( CONT_PARAMS );
static RTYPE compiled_block_1_1134( CONT_PARAMS );
static RTYPE compiled_block_1_1133( CONT_PARAMS );
static RTYPE compiled_block_1_1128( CONT_PARAMS );
static RTYPE compiled_block_1_1052( CONT_PARAMS );
static RTYPE compiled_block_1_1090( CONT_PARAMS );
static RTYPE compiled_block_1_1092( CONT_PARAMS );
static RTYPE compiled_block_1_1094( CONT_PARAMS );
static RTYPE compiled_block_1_1096( CONT_PARAMS );
static RTYPE compiled_block_1_1098( CONT_PARAMS );
static RTYPE compiled_block_1_1101( CONT_PARAMS );
static RTYPE compiled_block_1_1103( CONT_PARAMS );
static RTYPE compiled_block_1_1106( CONT_PARAMS );
static RTYPE compiled_block_1_1109( CONT_PARAMS );
static RTYPE compiled_block_1_1108( CONT_PARAMS );
static RTYPE compiled_block_1_1107( CONT_PARAMS );
static RTYPE compiled_block_1_1104( CONT_PARAMS );
static RTYPE compiled_block_1_1099( CONT_PARAMS );
static RTYPE compiled_block_1_1051( CONT_PARAMS );
static RTYPE compiled_block_1_1059( CONT_PARAMS );
static RTYPE compiled_block_1_1061( CONT_PARAMS );
static RTYPE compiled_block_1_1063( CONT_PARAMS );
static RTYPE compiled_block_1_1065( CONT_PARAMS );
static RTYPE compiled_block_1_1072( CONT_PARAMS );
static RTYPE compiled_block_1_1074( CONT_PARAMS );
static RTYPE compiled_block_1_1077( CONT_PARAMS );
static RTYPE compiled_block_1_1079( CONT_PARAMS );
static RTYPE compiled_block_1_1080( CONT_PARAMS );
static RTYPE compiled_block_1_1075( CONT_PARAMS );
static RTYPE compiled_block_1_1067( CONT_PARAMS );
static RTYPE compiled_block_1_1068( CONT_PARAMS );
static RTYPE compiled_block_1_1070( CONT_PARAMS );
static RTYPE compiled_block_1_1069( CONT_PARAMS );
static RTYPE compiled_block_1_1066( CONT_PARAMS );
static RTYPE compiled_start_1_5( CONT_PARAMS );
static RTYPE compiled_block_1_1003( CONT_PARAMS );
static RTYPE compiled_block_1_1005( CONT_PARAMS );
static RTYPE compiled_block_1_1007( CONT_PARAMS );
static RTYPE compiled_block_1_1010( CONT_PARAMS );
static RTYPE compiled_block_1_1012( CONT_PARAMS );
static RTYPE compiled_block_1_1015( CONT_PARAMS );
static RTYPE compiled_block_1_1043( CONT_PARAMS );
static RTYPE compiled_block_1_1042( CONT_PARAMS );
static RTYPE compiled_block_1_1041( CONT_PARAMS );
static RTYPE compiled_block_1_1040( CONT_PARAMS );
static RTYPE compiled_block_1_1039( CONT_PARAMS );
static RTYPE compiled_block_1_1038( CONT_PARAMS );
static RTYPE compiled_block_1_1037( CONT_PARAMS );
static RTYPE compiled_block_1_1036( CONT_PARAMS );
static RTYPE compiled_block_1_1035( CONT_PARAMS );
static RTYPE compiled_block_1_1034( CONT_PARAMS );
static RTYPE compiled_block_1_1033( CONT_PARAMS );
static RTYPE compiled_block_1_1032( CONT_PARAMS );
static RTYPE compiled_block_1_1031( CONT_PARAMS );
static RTYPE compiled_block_1_1030( CONT_PARAMS );
static RTYPE compiled_block_1_1029( CONT_PARAMS );
static RTYPE compiled_block_1_1028( CONT_PARAMS );
static RTYPE compiled_block_1_1027( CONT_PARAMS );
static RTYPE compiled_block_1_1026( CONT_PARAMS );
static RTYPE compiled_block_1_1025( CONT_PARAMS );
static RTYPE compiled_block_1_1024( CONT_PARAMS );
static RTYPE compiled_block_1_1023( CONT_PARAMS );
static RTYPE compiled_block_1_1022( CONT_PARAMS );
static RTYPE compiled_block_1_1021( CONT_PARAMS );
static RTYPE compiled_block_1_1020( CONT_PARAMS );
static RTYPE compiled_block_1_1019( CONT_PARAMS );
static RTYPE compiled_block_1_1018( CONT_PARAMS );
static RTYPE compiled_block_1_1017( CONT_PARAMS );
static RTYPE compiled_block_1_1016( CONT_PARAMS );
static RTYPE compiled_block_1_1013( CONT_PARAMS );
static RTYPE compiled_block_1_1008( CONT_PARAMS );
static RTYPE compiled_start_1_4( CONT_PARAMS );
static RTYPE compiled_start_1_1( CONT_PARAMS );

static RTYPE compiled_start_1_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1270, compiled_block_1_1270 );
  twobit_invoke( 8 );
  twobit_label( 1270, compiled_block_1_1270 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1271, compiled_block_1_1271 );
  twobit_invoke( 1 );
  twobit_label( 1271, compiled_block_1_1271 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* ex:uncompress */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_4, 2, 0 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1050, compiled_block_1_1050 );
  twobit_invoke( 2 );
  twobit_label( 1050, compiled_block_1_1050 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_5, 6, 0 );
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1267, compiled_block_1_1267 );
  twobit_invoke( 2 );
  twobit_label( 1267, compiled_block_1_1267 );
  twobit_load( 0, 0 );
  twobit_global( 8 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1003, compiled_block_1_1003 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1005, compiled_block_1_1005 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1007, compiled_block_1_1007 ); /* internal:branchf-pair? */
  twobit_save( 21 );
  twobit_store( 0, 0 );
  twobit_store( 1, 21 );
  twobit_store( 4, 1 );
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1008, compiled_block_1_1008 );
  twobit_invoke( 1 );
  twobit_label( 1008, compiled_block_1_1008 );
  twobit_load( 0, 0 );
  twobit_branchf( 1010, compiled_block_1_1010 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1012, compiled_block_1_1012 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 16 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 15 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1013, compiled_block_1_1013 );
  twobit_invoke( 1 );
  twobit_label( 1013, compiled_block_1_1013 );
  twobit_load( 0, 0 );
  twobit_branchf( 1015, compiled_block_1_1015 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1016, compiled_block_1_1016 );
  twobit_invoke( 5 );
  twobit_label( 1016, compiled_block_1_1016 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 20 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1017, compiled_block_1_1017 );
  twobit_invoke( 5 );
  twobit_label( 1017, compiled_block_1_1017 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 19 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1018, compiled_block_1_1018 );
  twobit_invoke( 5 );
  twobit_label( 1018, compiled_block_1_1018 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 18 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1019, compiled_block_1_1019 );
  twobit_invoke( 5 );
  twobit_label( 1019, compiled_block_1_1019 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 17 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1020, compiled_block_1_1020 );
  twobit_invoke( 5 );
  twobit_label( 1020, compiled_block_1_1020 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 14 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1021, compiled_block_1_1021 );
  twobit_invoke( 5 );
  twobit_label( 1021, compiled_block_1_1021 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 13 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1022, compiled_block_1_1022 );
  twobit_invoke( 5 );
  twobit_label( 1022, compiled_block_1_1022 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1023, compiled_block_1_1023 );
  twobit_invoke( 5 );
  twobit_label( 1023, compiled_block_1_1023 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1024, compiled_block_1_1024 );
  twobit_invoke( 5 );
  twobit_label( 1024, compiled_block_1_1024 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1025, compiled_block_1_1025 );
  twobit_invoke( 5 );
  twobit_label( 1025, compiled_block_1_1025 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1026, compiled_block_1_1026 );
  twobit_invoke( 5 );
  twobit_label( 1026, compiled_block_1_1026 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1027, compiled_block_1_1027 );
  twobit_invoke( 5 );
  twobit_label( 1027, compiled_block_1_1027 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1028, compiled_block_1_1028 );
  twobit_invoke( 5 );
  twobit_label( 1028, compiled_block_1_1028 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1029, compiled_block_1_1029 );
  twobit_invoke( 5 );
  twobit_label( 1029, compiled_block_1_1029 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1030, compiled_block_1_1030 );
  twobit_invoke( 5 );
  twobit_label( 1030, compiled_block_1_1030 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1031, compiled_block_1_1031 );
  twobit_invoke( 5 );
  twobit_label( 1031, compiled_block_1_1031 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1032, compiled_block_1_1032 );
  twobit_invoke( 5 );
  twobit_label( 1032, compiled_block_1_1032 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1033, compiled_block_1_1033 );
  twobit_invoke( 5 );
  twobit_label( 1033, compiled_block_1_1033 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 13 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 14 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1034, compiled_block_1_1034 );
  twobit_invoke( 5 );
  twobit_label( 1034, compiled_block_1_1034 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1035, compiled_block_1_1035 );
  twobit_invoke( 5 );
  twobit_label( 1035, compiled_block_1_1035 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_load( 3, 15 );
  twobit_stack( 16 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 15 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1036, compiled_block_1_1036 );
  twobit_invoke( 5 );
  twobit_label( 1036, compiled_block_1_1036 );
  twobit_load( 0, 0 );
  twobit_load( 3, 15 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1037, compiled_block_1_1037 );
  twobit_invoke( 5 );
  twobit_label( 1037, compiled_block_1_1037 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1038, compiled_block_1_1038 );
  twobit_invoke( 5 );
  twobit_label( 1038, compiled_block_1_1038 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1039, compiled_block_1_1039 );
  twobit_invoke( 5 );
  twobit_label( 1039, compiled_block_1_1039 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 13 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1040, compiled_block_1_1040 );
  twobit_invoke( 5 );
  twobit_label( 1040, compiled_block_1_1040 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 14 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1041, compiled_block_1_1041 );
  twobit_invoke( 5 );
  twobit_label( 1041, compiled_block_1_1041 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 16 );
  twobit_const( 17 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1042, compiled_block_1_1042 );
  twobit_invoke( 5 );
  twobit_label( 1042, compiled_block_1_1042 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 15 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1043, compiled_block_1_1043 );
  twobit_invoke( 5 );
  twobit_label( 1043, compiled_block_1_1043 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 15 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 16 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 14 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 13 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 17 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 18 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 19 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 20 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 21 );
  twobit_return();
  twobit_label( 1015, compiled_block_1_1015 );
  twobit_load( 1, 21 );
  twobit_global( 18 ); /* ex:invalid-form */
  twobit_pop( 21 );
  twobit_invoke( 1 );
  twobit_label( 1012, compiled_block_1_1012 );
  twobit_load( 1, 21 );
  twobit_global( 18 ); /* ex:invalid-form */
  twobit_pop( 21 );
  twobit_invoke( 1 );
  twobit_label( 1010, compiled_block_1_1010 );
  twobit_load( 1, 21 );
  twobit_global( 18 ); /* ex:invalid-form */
  twobit_pop( 21 );
  twobit_invoke( 1 );
  twobit_label( 1007, compiled_block_1_1007 );
  twobit_global( 18 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1005, compiled_block_1_1005 );
  twobit_global( 18 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1003, compiled_block_1_1003 );
  twobit_global( 18 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1059, compiled_block_1_1059 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1061, compiled_block_1_1061 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1063, compiled_block_1_1063 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1065, compiled_block_1_1065 ); /* internal:branchf-pair? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 3, 2 );
  twobit_store( 4, 3 );
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /* ex:identifier? */
  twobit_setrtn( 1066, compiled_block_1_1066 );
  twobit_invoke( 1 );
  twobit_label( 1066, compiled_block_1_1066 );
  twobit_load( 0, 0 );
  twobit_branchf( 1068, compiled_block_1_1068 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1069, compiled_block_1_1069 );
  twobit_invoke( 5 );
  twobit_label( 1069, compiled_block_1_1069 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* ex:free-identifier=? */
  twobit_setrtn( 1070, compiled_block_1_1070 );
  twobit_invoke( 2 );
  twobit_label( 1070, compiled_block_1_1070 );
  twobit_load( 0, 0 );
  twobit_skip( 1067, compiled_block_1_1067 );
  twobit_label( 1068, compiled_block_1_1068 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1067, compiled_block_1_1067 );
  twobit_branchf( 1072, compiled_block_1_1072 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1074, compiled_block_1_1074 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 7 ); /* list? */
  twobit_setrtn( 1075, compiled_block_1_1075 );
  twobit_invoke( 1 );
  twobit_label( 1075, compiled_block_1_1075 );
  twobit_load( 0, 0 );
  twobit_branchf( 1077, compiled_block_1_1077 );
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1079, compiled_block_1_1079 ); /* internal:branchf-null? */
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1080, compiled_block_1_1080 );
  twobit_invoke( 5 );
  twobit_label( 1080, compiled_block_1_1080 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1079, compiled_block_1_1079 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1056, compiled_block_1_1056 );
  twobit_label( 1077, compiled_block_1_1077 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1056, compiled_block_1_1056 );
  twobit_label( 1074, compiled_block_1_1074 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1056, compiled_block_1_1056 );
  twobit_label( 1072, compiled_block_1_1072 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1056, compiled_block_1_1056 );
  twobit_label( 1065, compiled_block_1_1065 );
  twobit_branch( 1056, compiled_block_1_1056 );
  twobit_label( 1063, compiled_block_1_1063 );
  twobit_branch( 1056, compiled_block_1_1056 );
  twobit_label( 1061, compiled_block_1_1061 );
  twobit_branch( 1056, compiled_block_1_1056 );
  twobit_label( 1059, compiled_block_1_1059 );
  twobit_branch( 1056, compiled_block_1_1056 );
  twobit_label( 1051, compiled_block_1_1051 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1090, compiled_block_1_1090 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1092, compiled_block_1_1092 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1094, compiled_block_1_1094 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1096, compiled_block_1_1096 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1098, compiled_block_1_1098 ); /* internal:branchf-pair? */
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 8 );
  twobit_store( 3, 5 );
  twobit_store( 4, 1 );
  twobit_store( 31, 6 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_store( 30, 3 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 7 ); /* list? */
  twobit_setrtn( 1099, compiled_block_1_1099 );
  twobit_invoke( 1 );
  twobit_label( 1099, compiled_block_1_1099 );
  twobit_load( 0, 0 );
  twobit_branchf( 1101, compiled_block_1_1101 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1103, compiled_block_1_1103 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 7 ); /* list? */
  twobit_setrtn( 1104, compiled_block_1_1104 );
  twobit_invoke( 1 );
  twobit_label( 1104, compiled_block_1_1104 );
  twobit_load( 0, 0 );
  twobit_branchf( 1106, compiled_block_1_1106 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1107, compiled_block_1_1107 );
  twobit_invoke( 5 );
  twobit_label( 1107, compiled_block_1_1107 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 3, 2 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1108, compiled_block_1_1108 );
  twobit_invoke( 5 );
  twobit_label( 1108, compiled_block_1_1108 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 3, 1 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1109, compiled_block_1_1109 );
  twobit_invoke( 5 );
  twobit_label( 1109, compiled_block_1_1109 );
  twobit_load( 0, 0 );
  twobit_load( 3, 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 1106, compiled_block_1_1106 );
  twobit_load( 1, 8 );
  twobit_global( 12 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 1103, compiled_block_1_1103 );
  twobit_load( 1, 8 );
  twobit_global( 12 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 1101, compiled_block_1_1101 );
  twobit_load( 1, 8 );
  twobit_global( 12 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 1098, compiled_block_1_1098 );
  twobit_global( 12 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1096, compiled_block_1_1096 );
  twobit_global( 12 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1094, compiled_block_1_1094 );
  twobit_global( 12 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1092, compiled_block_1_1092 );
  twobit_global( 12 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1090, compiled_block_1_1090 );
  twobit_global( 12 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1052, compiled_block_1_1052 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1119, compiled_block_1_1119 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1121, compiled_block_1_1121 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1123, compiled_block_1_1123 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1125, compiled_block_1_1125 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1127, compiled_block_1_1127 ); /* internal:branchf-pair? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 3, 2 );
  twobit_store( 4, 1 );
  twobit_store( 31, 5 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_store( 30, 4 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_movereg( 2, 1 );
  twobit_global( 7 ); /* list? */
  twobit_setrtn( 1128, compiled_block_1_1128 );
  twobit_invoke( 1 );
  twobit_label( 1128, compiled_block_1_1128 );
  twobit_load( 0, 0 );
  twobit_branchf( 1130, compiled_block_1_1130 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1132, compiled_block_1_1132 ); /* internal:branchf-null? */
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 13 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1133, compiled_block_1_1133 );
  twobit_invoke( 5 );
  twobit_label( 1133, compiled_block_1_1133 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_load( 2, 3 );
  twobit_stack( 4 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 13 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1134, compiled_block_1_1134 );
  twobit_invoke( 5 );
  twobit_label( 1134, compiled_block_1_1134 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1132, compiled_block_1_1132 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1051, compiled_block_1_1051 );
  twobit_label( 1130, compiled_block_1_1130 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1051, compiled_block_1_1051 );
  twobit_label( 1127, compiled_block_1_1127 );
  twobit_branch( 1051, compiled_block_1_1051 );
  twobit_label( 1125, compiled_block_1_1125 );
  twobit_branch( 1051, compiled_block_1_1051 );
  twobit_label( 1123, compiled_block_1_1123 );
  twobit_branch( 1051, compiled_block_1_1051 );
  twobit_label( 1121, compiled_block_1_1121 );
  twobit_branch( 1051, compiled_block_1_1051 );
  twobit_label( 1119, compiled_block_1_1119 );
  twobit_branch( 1051, compiled_block_1_1051 );
  twobit_label( 1053, compiled_block_1_1053 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1143, compiled_block_1_1143 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1145, compiled_block_1_1145 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1147, compiled_block_1_1147 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1149, compiled_block_1_1149 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1151, compiled_block_1_1151 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1153, compiled_block_1_1153 ); /* internal:branchf-pair? */
  twobit_save( 9 );
  twobit_store( 0, 0 );
  twobit_store( 1, 9 );
  twobit_store( 3, 4 );
  twobit_store( 31, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 7 ); /* list? */
  twobit_setrtn( 1154, compiled_block_1_1154 );
  twobit_invoke( 1 );
  twobit_label( 1154, compiled_block_1_1154 );
  twobit_load( 0, 0 );
  twobit_branchf( 1156, compiled_block_1_1156 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1157, compiled_block_1_1157 );
  twobit_invoke( 5 );
  twobit_label( 1157, compiled_block_1_1157 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1158, compiled_block_1_1158 );
  twobit_invoke( 5 );
  twobit_label( 1158, compiled_block_1_1158 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1159, compiled_block_1_1159 );
  twobit_invoke( 5 );
  twobit_label( 1159, compiled_block_1_1159 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1160, compiled_block_1_1160 );
  twobit_invoke( 5 );
  twobit_label( 1160, compiled_block_1_1160 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1161, compiled_block_1_1161 );
  twobit_invoke( 5 );
  twobit_label( 1161, compiled_block_1_1161 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 3, 2 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1162, compiled_block_1_1162 );
  twobit_invoke( 5 );
  twobit_label( 1162, compiled_block_1_1162 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 9 );
  twobit_return();
  twobit_label( 1156, compiled_block_1_1156 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1052, compiled_block_1_1052 );
  twobit_label( 1153, compiled_block_1_1153 );
  twobit_branch( 1052, compiled_block_1_1052 );
  twobit_label( 1151, compiled_block_1_1151 );
  twobit_branch( 1052, compiled_block_1_1052 );
  twobit_label( 1149, compiled_block_1_1149 );
  twobit_branch( 1052, compiled_block_1_1052 );
  twobit_label( 1147, compiled_block_1_1147 );
  twobit_branch( 1052, compiled_block_1_1052 );
  twobit_label( 1145, compiled_block_1_1145 );
  twobit_branch( 1052, compiled_block_1_1052 );
  twobit_label( 1143, compiled_block_1_1143 );
  twobit_branch( 1052, compiled_block_1_1052 );
  twobit_label( 1054, compiled_block_1_1054 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1171, compiled_block_1_1171 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1173, compiled_block_1_1173 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1175, compiled_block_1_1175 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1177, compiled_block_1_1177 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1179, compiled_block_1_1179 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1181, compiled_block_1_1181 ); /* internal:branchf-null? */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1181, compiled_block_1_1181 );
  twobit_branch( 1053, compiled_block_1_1053 );
  twobit_label( 1179, compiled_block_1_1179 );
  twobit_branch( 1053, compiled_block_1_1053 );
  twobit_label( 1177, compiled_block_1_1177 );
  twobit_branch( 1053, compiled_block_1_1053 );
  twobit_label( 1175, compiled_block_1_1175 );
  twobit_branch( 1053, compiled_block_1_1053 );
  twobit_label( 1173, compiled_block_1_1173 );
  twobit_branch( 1053, compiled_block_1_1053 );
  twobit_label( 1171, compiled_block_1_1171 );
  twobit_branch( 1053, compiled_block_1_1053 );
  twobit_label( 1055, compiled_block_1_1055 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1189, compiled_block_1_1189 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1191, compiled_block_1_1191 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1193, compiled_block_1_1193 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1195, compiled_block_1_1195 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1197, compiled_block_1_1197 ); /* internal:branchf-pair? */
  twobit_save( 9 );
  twobit_store( 0, 0 );
  twobit_store( 1, 9 );
  twobit_store( 2, 2 );
  twobit_store( 3, 5 );
  twobit_store( 4, 3 );
  twobit_store( 31, 4 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_store( 30, 1 );
  twobit_movereg( 30, 1 );
  twobit_global( 1 ); /* ex:identifier? */
  twobit_setrtn( 1198, compiled_block_1_1198 );
  twobit_invoke( 1 );
  twobit_label( 1198, compiled_block_1_1198 );
  twobit_load( 0, 0 );
  twobit_branchf( 1200, compiled_block_1_1200 );
  twobit_const( 17 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 18 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1201, compiled_block_1_1201 );
  twobit_invoke( 5 );
  twobit_label( 1201, compiled_block_1_1201 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* ex:free-identifier=? */
  twobit_setrtn( 1202, compiled_block_1_1202 );
  twobit_invoke( 2 );
  twobit_label( 1202, compiled_block_1_1202 );
  twobit_load( 0, 0 );
  twobit_skip( 1199, compiled_block_1_1199 );
  twobit_label( 1200, compiled_block_1_1200 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1199, compiled_block_1_1199 );
  twobit_branchf( 1204, compiled_block_1_1204 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1206, compiled_block_1_1206 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1208, compiled_block_1_1208 ); /* internal:branchf-null? */
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1210, compiled_block_1_1210 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_movereg( 4, 1 );
  twobit_global( 7 ); /* list? */
  twobit_setrtn( 1211, compiled_block_1_1211 );
  twobit_invoke( 1 );
  twobit_label( 1211, compiled_block_1_1211 );
  twobit_load( 0, 0 );
  twobit_branchf( 1213, compiled_block_1_1213 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 18 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1214, compiled_block_1_1214 );
  twobit_invoke( 5 );
  twobit_label( 1214, compiled_block_1_1214 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 18 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1215, compiled_block_1_1215 );
  twobit_invoke( 5 );
  twobit_label( 1215, compiled_block_1_1215 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 18 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1216, compiled_block_1_1216 );
  twobit_invoke( 5 );
  twobit_label( 1216, compiled_block_1_1216 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 18 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1217, compiled_block_1_1217 );
  twobit_invoke( 5 );
  twobit_label( 1217, compiled_block_1_1217 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 18 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1218, compiled_block_1_1218 );
  twobit_invoke( 5 );
  twobit_label( 1218, compiled_block_1_1218 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 3, 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 18 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1219, compiled_block_1_1219 );
  twobit_invoke( 5 );
  twobit_label( 1219, compiled_block_1_1219 );
  twobit_load( 0, 0 );
  twobit_load( 3, 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 9 );
  twobit_return();
  twobit_label( 1213, compiled_block_1_1213 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1054, compiled_block_1_1054 );
  twobit_label( 1210, compiled_block_1_1210 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1054, compiled_block_1_1054 );
  twobit_label( 1208, compiled_block_1_1208 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1054, compiled_block_1_1054 );
  twobit_label( 1206, compiled_block_1_1206 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1054, compiled_block_1_1054 );
  twobit_label( 1204, compiled_block_1_1204 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1054, compiled_block_1_1054 );
  twobit_label( 1197, compiled_block_1_1197 );
  twobit_branch( 1054, compiled_block_1_1054 );
  twobit_label( 1195, compiled_block_1_1195 );
  twobit_branch( 1054, compiled_block_1_1054 );
  twobit_label( 1193, compiled_block_1_1193 );
  twobit_branch( 1054, compiled_block_1_1054 );
  twobit_label( 1191, compiled_block_1_1191 );
  twobit_branch( 1054, compiled_block_1_1054 );
  twobit_label( 1189, compiled_block_1_1189 );
  twobit_branch( 1054, compiled_block_1_1054 );
  twobit_label( 1056, compiled_block_1_1056 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1231, compiled_block_1_1231 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1233, compiled_block_1_1233 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1235, compiled_block_1_1235 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1237, compiled_block_1_1237 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1239, compiled_block_1_1239 ); /* internal:branchf-pair? */
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 7 );
  twobit_store( 2, 2 );
  twobit_store( 3, 5 );
  twobit_store( 4, 3 );
  twobit_store( 31, 4 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_store( 30, 1 );
  twobit_movereg( 30, 1 );
  twobit_global( 1 ); /* ex:identifier? */
  twobit_setrtn( 1240, compiled_block_1_1240 );
  twobit_invoke( 1 );
  twobit_label( 1240, compiled_block_1_1240 );
  twobit_load( 0, 0 );
  twobit_branchf( 1242, compiled_block_1_1242 );
  twobit_const( 17 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 19 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1243, compiled_block_1_1243 );
  twobit_invoke( 5 );
  twobit_label( 1243, compiled_block_1_1243 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* ex:free-identifier=? */
  twobit_setrtn( 1244, compiled_block_1_1244 );
  twobit_invoke( 2 );
  twobit_label( 1244, compiled_block_1_1244 );
  twobit_load( 0, 0 );
  twobit_skip( 1241, compiled_block_1_1241 );
  twobit_label( 1242, compiled_block_1_1242 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1241, compiled_block_1_1241 );
  twobit_branchf( 1246, compiled_block_1_1246 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1248, compiled_block_1_1248 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1250, compiled_block_1_1250 ); /* internal:branchf-null? */
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1252, compiled_block_1_1252 ); /* internal:branchf-null? */
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 19 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1253, compiled_block_1_1253 );
  twobit_invoke( 5 );
  twobit_label( 1253, compiled_block_1_1253 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 19 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1254, compiled_block_1_1254 );
  twobit_invoke( 5 );
  twobit_label( 1254, compiled_block_1_1254 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 19 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1255, compiled_block_1_1255 );
  twobit_invoke( 5 );
  twobit_label( 1255, compiled_block_1_1255 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 19 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1256, compiled_block_1_1256 );
  twobit_invoke( 5 );
  twobit_label( 1256, compiled_block_1_1256 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 19 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1257, compiled_block_1_1257 );
  twobit_invoke( 5 );
  twobit_label( 1257, compiled_block_1_1257 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1252, compiled_block_1_1252 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1055, compiled_block_1_1055 );
  twobit_label( 1250, compiled_block_1_1250 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1055, compiled_block_1_1055 );
  twobit_label( 1248, compiled_block_1_1248 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1055, compiled_block_1_1055 );
  twobit_label( 1246, compiled_block_1_1246 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1055, compiled_block_1_1055 );
  twobit_label( 1239, compiled_block_1_1239 );
  twobit_branch( 1055, compiled_block_1_1055 );
  twobit_label( 1237, compiled_block_1_1237 );
  twobit_branch( 1055, compiled_block_1_1055 );
  twobit_label( 1235, compiled_block_1_1235 );
  twobit_branch( 1055, compiled_block_1_1055 );
  twobit_label( 1233, compiled_block_1_1233 );
  twobit_branch( 1055, compiled_block_1_1055 );
  twobit_label( 1231, compiled_block_1_1231 );
  twobit_branch( 1055, compiled_block_1_1055 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_354e7514d4b8af2ecd750e46c40dadd0_0(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_1_0(CONT_ACTUALS));
}
codeptr_t CDECL twobit_load_table[] = { 
  twobit_thunk_354e7514d4b8af2ecd750e46c40dadd0_0,
  0  /* The table may be empty; some compilers complain */
};

/* Generated from /proj/will/pnkfelix/larcenytest/larceny-petit-Nightly-2009-08-19/larceny_src/lib/R6RS/rnrs/lists.slfasl */
#include "petit-instr.h"

static RTYPE compiled_block_1_1004( CONT_PARAMS );
static RTYPE compiled_block_1_1003( CONT_PARAMS );
static RTYPE compiled_start_1_0( CONT_PARAMS );
static RTYPE compiled_start_1_3( CONT_PARAMS );
static RTYPE compiled_start_1_2( CONT_PARAMS );
static RTYPE compiled_start_1_1( CONT_PARAMS );

static RTYPE compiled_start_1_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 2 ); /*  assoc~1ayXVW~1405 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 3 ); /*  member~1ayXVW~1404 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 4 ); /*  remove~1ayXVW~1403 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 5 ); /*  fold-right~1ayXVW~1402 */
  twobit_lambda( compiled_start_1_1, 7, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_2, 9, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_3, 11, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_const( 13 );
  twobit_setreg( 3 );
  twobit_const( 14 );
  twobit_setreg( 4 );
  twobit_const( 15 );
  twobit_setreg( 5 );
  twobit_const( 16 );
  twobit_setreg( 8 );
  twobit_global( 17 ); /* ex:make-library */
  twobit_setrtn( 1003, compiled_block_1_1003 );
  twobit_invoke( 8 );
  twobit_label( 1003, compiled_block_1_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 18 ); /* ex:register-library! */
  twobit_setrtn( 1004, compiled_block_1_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_1_1004 );
  twobit_load( 0, 0 );
  twobit_global( 19 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 2 ); /*  assoc~1ayXVW~1405 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 3 ); /*  member~1ayXVW~1404 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 4 ); /*  remove~1ayXVW~1403 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 5 ); /*  fold-right~1ayXVW~1402 */
  twobit_global( 6 ); /* larceny:fold-right */
  twobit_setglbl( 5 ); /*  fold-right~1ayXVW~1402 */
  twobit_global( 7 ); /* larceny:remove */
  twobit_setglbl( 4 ); /*  remove~1ayXVW~1403 */
  twobit_global( 8 ); /* larceny:member */
  twobit_setglbl( 3 ); /*  member~1ayXVW~1404 */
  twobit_global( 9 ); /* larceny:assoc */
  twobit_setglbl( 2 ); /*  assoc~1ayXVW~1405 */
  twobit_global( 10 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_0aa688bc38e0d50f7f92d98051606007_0(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_1_0(CONT_ACTUALS));
}
codeptr_t CDECL twobit_load_table[] = { 
  twobit_thunk_0aa688bc38e0d50f7f92d98051606007_0,
  0  /* The table may be empty; some compilers complain */
};

/* Generated from /proj/will/pnkfelix/larcenytest/larceny-petit-Nightly-2009-08-19/larceny_src/lib/R6RS/rnrs/r5rs.slfasl */
#include "petit-instr.h"

static RTYPE compiled_block_1_1031( CONT_PARAMS );
static RTYPE compiled_block_1_1030( CONT_PARAMS );
static RTYPE compiled_start_1_0( CONT_PARAMS );
static RTYPE compiled_block_1_1019( CONT_PARAMS );
static RTYPE compiled_start_1_3( CONT_PARAMS );
static RTYPE compiled_start_1_7( CONT_PARAMS );
static RTYPE compiled_block_1_1028( CONT_PARAMS );
static RTYPE compiled_block_1_1026( CONT_PARAMS );
static RTYPE compiled_block_1_1025( CONT_PARAMS );
static RTYPE compiled_start_1_8( CONT_PARAMS );
static RTYPE compiled_start_1_6( CONT_PARAMS );
static RTYPE compiled_block_1_1020( CONT_PARAMS );
static RTYPE compiled_block_1_1022( CONT_PARAMS );
static RTYPE compiled_block_1_1021( CONT_PARAMS );
static RTYPE compiled_temp_1_9( CONT_PARAMS );
static RTYPE compiled_start_1_5( CONT_PARAMS );
static RTYPE compiled_block_1_1015( CONT_PARAMS );
static RTYPE compiled_block_1_1017( CONT_PARAMS );
static RTYPE compiled_block_1_1016( CONT_PARAMS );
static RTYPE compiled_temp_1_10( CONT_PARAMS );
static RTYPE compiled_start_1_4( CONT_PARAMS );
static RTYPE compiled_block_1_1013( CONT_PARAMS );
static RTYPE compiled_start_1_2( CONT_PARAMS );
static RTYPE compiled_block_1_1003( CONT_PARAMS );
static RTYPE compiled_block_1_1005( CONT_PARAMS );
static RTYPE compiled_block_1_1007( CONT_PARAMS );
static RTYPE compiled_block_1_1009( CONT_PARAMS );
static RTYPE compiled_block_1_1008( CONT_PARAMS );
static RTYPE compiled_start_1_11( CONT_PARAMS );
static RTYPE compiled_start_1_1( CONT_PARAMS );

static RTYPE compiled_start_1_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 2 ); /*  make-promise~1ayXVW~3719 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 3 ); /*  force~1ayXVW~3703 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 4 ); /*  null-environment~1ayXVW~3702 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 5 ); /*  scheme-report-environment~1ayXVW~3701 */
  twobit_lambda( compiled_start_1_1, 7, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_2, 9, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_3, 11, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_const( 13 );
  twobit_setreg( 3 );
  twobit_const( 14 );
  twobit_setreg( 4 );
  twobit_const( 15 );
  twobit_setreg( 5 );
  twobit_const( 16 );
  twobit_setreg( 8 );
  twobit_global( 17 ); /* ex:make-library */
  twobit_setrtn( 1030, compiled_block_1_1030 );
  twobit_invoke( 8 );
  twobit_label( 1030, compiled_block_1_1030 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 18 ); /* ex:register-library! */
  twobit_setrtn( 1031, compiled_block_1_1031 );
  twobit_invoke( 1 );
  twobit_label( 1031, compiled_block_1_1031 );
  twobit_load( 0, 0 );
  twobit_global( 19 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* ex:uncompress */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_11, 2, 0 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1013, compiled_block_1_1013 );
  twobit_invoke( 2 );
  twobit_label( 1013, compiled_block_1_1013 );
  twobit_load( 0, 0 );
  twobit_global( 5 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_11( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1003, compiled_block_1_1003 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1005, compiled_block_1_1005 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1007, compiled_block_1_1007 ); /* internal:branchf-null? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1008, compiled_block_1_1008 );
  twobit_invoke( 5 );
  twobit_label( 1008, compiled_block_1_1008 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1009, compiled_block_1_1009 );
  twobit_invoke( 5 );
  twobit_label( 1009, compiled_block_1_1009 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1007, compiled_block_1_1007 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1005, compiled_block_1_1005 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1003, compiled_block_1_1003 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 2 ); /*  make-promise~1ayXVW~3719 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 3 ); /*  force~1ayXVW~3703 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 4 ); /*  null-environment~1ayXVW~3702 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 5 ); /*  scheme-report-environment~1ayXVW~3701 */
  twobit_lambda( compiled_start_1_4, 7, 0 );
  twobit_setglbl( 5 ); /*  scheme-report-environment~1ayXVW~3701 */
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_const( 9 );
  twobit_setreg( 2 );
  twobit_global( 10 ); /* ex:environment */
  twobit_setrtn( 1019, compiled_block_1_1019 );
  twobit_invoke( 2 );
  twobit_label( 1019, compiled_block_1_1019 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_5, 12, 1 );
  twobit_setglbl( 4 ); /*  null-environment~1ayXVW~3702 */
  twobit_lambda( compiled_start_1_6, 14, 0 );
  twobit_setglbl( 3 ); /*  force~1ayXVW~3703 */
  twobit_lambda( compiled_start_1_7, 16, 0 );
  twobit_setglbl( 2 ); /*  make-promise~1ayXVW~3719 */
  twobit_global( 17 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_639( fixnum(5), 10, compiled_temp_1_10, 1016, compiled_block_1_1016 ); /* internal:branchf-=/imm */
  twobit_op1_3(); /* unspecified */
  twobit_skip( 1015, compiled_block_1_1015 );
  twobit_label( 1016, compiled_block_1_1016 );
  twobit_movereg( 1, 3 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* assertion-violation */
  twobit_setrtn( 1017, compiled_block_1_1017 );
  twobit_invoke( 3 );
  twobit_label( 1017, compiled_block_1_1017 );
  twobit_load( 0, 0 );
  twobit_label( 1015, compiled_block_1_1015 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /* ex:environment */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_639( fixnum(5), 9, compiled_temp_1_9, 1021, compiled_block_1_1021 ); /* internal:branchf-=/imm */
  twobit_op1_3(); /* unspecified */
  twobit_skip( 1020, compiled_block_1_1020 );
  twobit_label( 1021, compiled_block_1_1021 );
  twobit_movereg( 1, 3 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* assertion-violation */
  twobit_setrtn( 1022, compiled_block_1_1022 );
  twobit_invoke( 3 );
  twobit_label( 1022, compiled_block_1_1022 );
  twobit_load( 0, 0 );
  twobit_label( 1020, compiled_block_1_1020 );
  twobit_lexical( 0, 1 );
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_6( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_movereg( 1, 4 );
  twobit_reg( 4 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_7( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_8, 2, 3 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_8( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_branchf( 1025, compiled_block_1_1025 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_return();
  twobit_label( 1025, compiled_block_1_1025 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1026, compiled_block_1_1026 );
  twobit_invoke( 0 );
  twobit_label( 1026, compiled_block_1_1026 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_branchf( 1028, compiled_block_1_1028 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1028, compiled_block_1_1028 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_lexical( 0, 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


RTYPE twobit_thunk_6a10b592eb2fdbb9a2be8b52be5b925d_0(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_1_0(CONT_ACTUALS));
}
codeptr_t CDECL twobit_load_table[] = { 
  twobit_thunk_6a10b592eb2fdbb9a2be8b52be5b925d_0,
  0  /* The table may be empty; some compilers complain */
};

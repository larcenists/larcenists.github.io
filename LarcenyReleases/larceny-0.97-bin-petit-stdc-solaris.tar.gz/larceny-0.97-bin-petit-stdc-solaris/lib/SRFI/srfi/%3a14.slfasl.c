/* Generated from /proj/will/pnkfelix/larcenytest/larceny-petit-Nightly-2009-08-19/larceny_src/lib/SRFI/srfi/%3a14.slfasl */
#include "petit-instr.h"

static RTYPE compiled_block_1_1465( CONT_PARAMS );
static RTYPE compiled_block_1_1464( CONT_PARAMS );
static RTYPE compiled_start_1_0( CONT_PARAMS );
static RTYPE compiled_block_1_1462( CONT_PARAMS );
static RTYPE compiled_block_1_1461( CONT_PARAMS );
static RTYPE compiled_block_1_1460( CONT_PARAMS );
static RTYPE compiled_block_1_1459( CONT_PARAMS );
static RTYPE compiled_block_1_1458( CONT_PARAMS );
static RTYPE compiled_block_1_1457( CONT_PARAMS );
static RTYPE compiled_block_1_1456( CONT_PARAMS );
static RTYPE compiled_block_1_1455( CONT_PARAMS );
static RTYPE compiled_block_1_1454( CONT_PARAMS );
static RTYPE compiled_block_1_1453( CONT_PARAMS );
static RTYPE compiled_block_1_1452( CONT_PARAMS );
static RTYPE compiled_block_1_1451( CONT_PARAMS );
static RTYPE compiled_block_1_1450( CONT_PARAMS );
static RTYPE compiled_block_1_1449( CONT_PARAMS );
static RTYPE compiled_block_1_1448( CONT_PARAMS );
static RTYPE compiled_block_1_1447( CONT_PARAMS );
static RTYPE compiled_block_1_1446( CONT_PARAMS );
static RTYPE compiled_block_1_1445( CONT_PARAMS );
static RTYPE compiled_block_1_1444( CONT_PARAMS );
static RTYPE compiled_block_1_1443( CONT_PARAMS );
static RTYPE compiled_block_1_1442( CONT_PARAMS );
static RTYPE compiled_block_1_1441( CONT_PARAMS );
static RTYPE compiled_block_1_1440( CONT_PARAMS );
static RTYPE compiled_block_1_1439( CONT_PARAMS );
static RTYPE compiled_block_1_1438( CONT_PARAMS );
static RTYPE compiled_block_1_1437( CONT_PARAMS );
static RTYPE compiled_block_1_1436( CONT_PARAMS );
static RTYPE compiled_block_1_1435( CONT_PARAMS );
static RTYPE compiled_block_1_1434( CONT_PARAMS );
static RTYPE compiled_block_1_1433( CONT_PARAMS );
static RTYPE compiled_block_1_1432( CONT_PARAMS );
static RTYPE compiled_block_1_1431( CONT_PARAMS );
static RTYPE compiled_block_1_1048( CONT_PARAMS );
static RTYPE compiled_block_1_1047( CONT_PARAMS );
static RTYPE compiled_block_1_1022( CONT_PARAMS );
static RTYPE compiled_block_1_1021( CONT_PARAMS );
static RTYPE compiled_block_1_1020( CONT_PARAMS );
static RTYPE compiled_block_1_1019( CONT_PARAMS );
static RTYPE compiled_start_1_3( CONT_PARAMS );
static RTYPE compiled_block_1_1429( CONT_PARAMS );
static RTYPE compiled_block_1_1428( CONT_PARAMS );
static RTYPE compiled_block_1_1427( CONT_PARAMS );
static RTYPE compiled_block_1_1426( CONT_PARAMS );
static RTYPE compiled_block_1_1425( CONT_PARAMS );
static RTYPE compiled_start_1_75( CONT_PARAMS );
static RTYPE compiled_block_1_1423( CONT_PARAMS );
static RTYPE compiled_block_1_1422( CONT_PARAMS );
static RTYPE compiled_block_1_1414( CONT_PARAMS );
static RTYPE compiled_block_1_1413( CONT_PARAMS );
static RTYPE compiled_start_1_74( CONT_PARAMS );
static RTYPE compiled_block_1_1420( CONT_PARAMS );
static RTYPE compiled_block_1_1418( CONT_PARAMS );
static RTYPE compiled_block_1_1416( CONT_PARAMS );
static RTYPE compiled_temp_1_77( CONT_PARAMS );
static RTYPE compiled_start_1_76( CONT_PARAMS );
static RTYPE compiled_start_1_73( CONT_PARAMS );
static RTYPE compiled_block_1_1410( CONT_PARAMS );
static RTYPE compiled_start_1_78( CONT_PARAMS );
static RTYPE compiled_block_1_1407( CONT_PARAMS );
static RTYPE compiled_block_1_1408( CONT_PARAMS );
static RTYPE compiled_block_1_1405( CONT_PARAMS );
static RTYPE compiled_block_1_1404( CONT_PARAMS );
static RTYPE compiled_temp_1_80( CONT_PARAMS );
static RTYPE compiled_start_1_79( CONT_PARAMS );
static RTYPE compiled_block_1_1397( CONT_PARAMS );
static RTYPE compiled_block_1_1400( CONT_PARAMS );
static RTYPE compiled_block_1_1399( CONT_PARAMS );
static RTYPE compiled_block_1_1398( CONT_PARAMS );
static RTYPE compiled_start_1_72( CONT_PARAMS );
static RTYPE compiled_block_1_1395( CONT_PARAMS );
static RTYPE compiled_block_1_1394( CONT_PARAMS );
static RTYPE compiled_start_1_71( CONT_PARAMS );
static RTYPE compiled_block_1_1388( CONT_PARAMS );
static RTYPE compiled_block_1_1391( CONT_PARAMS );
static RTYPE compiled_block_1_1390( CONT_PARAMS );
static RTYPE compiled_block_1_1389( CONT_PARAMS );
static RTYPE compiled_start_1_70( CONT_PARAMS );
static RTYPE compiled_block_1_1386( CONT_PARAMS );
static RTYPE compiled_block_1_1385( CONT_PARAMS );
static RTYPE compiled_start_1_69( CONT_PARAMS );
static RTYPE compiled_block_1_1379( CONT_PARAMS );
static RTYPE compiled_block_1_1382( CONT_PARAMS );
static RTYPE compiled_block_1_1381( CONT_PARAMS );
static RTYPE compiled_block_1_1380( CONT_PARAMS );
static RTYPE compiled_start_1_68( CONT_PARAMS );
static RTYPE compiled_block_1_1377( CONT_PARAMS );
static RTYPE compiled_block_1_1376( CONT_PARAMS );
static RTYPE compiled_start_1_67( CONT_PARAMS );
static RTYPE compiled_block_1_1370( CONT_PARAMS );
static RTYPE compiled_block_1_1373( CONT_PARAMS );
static RTYPE compiled_block_1_1372( CONT_PARAMS );
static RTYPE compiled_block_1_1371( CONT_PARAMS );
static RTYPE compiled_start_1_66( CONT_PARAMS );
static RTYPE compiled_block_1_1368( CONT_PARAMS );
static RTYPE compiled_block_1_1367( CONT_PARAMS );
static RTYPE compiled_start_1_65( CONT_PARAMS );
static RTYPE compiled_block_1_1366( CONT_PARAMS );
static RTYPE compiled_block_1_1364( CONT_PARAMS );
static RTYPE compiled_start_1_64( CONT_PARAMS );
static RTYPE compiled_start_1_81( CONT_PARAMS );
static RTYPE compiled_block_1_1362( CONT_PARAMS );
static RTYPE compiled_block_1_1360( CONT_PARAMS );
static RTYPE compiled_start_1_63( CONT_PARAMS );
static RTYPE compiled_start_1_82( CONT_PARAMS );
static RTYPE compiled_start_1_62( CONT_PARAMS );
static RTYPE compiled_block_1_1352( CONT_PARAMS );
static RTYPE compiled_start_1_83( CONT_PARAMS );
static RTYPE compiled_block_1_1354( CONT_PARAMS );
static RTYPE compiled_temp_1_86( CONT_PARAMS );
static RTYPE compiled_block_1_1356( CONT_PARAMS );
static RTYPE compiled_block_1_1355( CONT_PARAMS );
static RTYPE compiled_temp_1_85( CONT_PARAMS );
static RTYPE compiled_start_1_84( CONT_PARAMS );
static RTYPE compiled_block_1_1344( CONT_PARAMS );
static RTYPE compiled_start_1_61( CONT_PARAMS );
static RTYPE compiled_block_1_1347( CONT_PARAMS );
static RTYPE compiled_block_1_1346( CONT_PARAMS );
static RTYPE compiled_block_1_1349( CONT_PARAMS );
static RTYPE compiled_block_1_1348( CONT_PARAMS );
static RTYPE compiled_temp_1_88( CONT_PARAMS );
static RTYPE compiled_start_1_87( CONT_PARAMS );
static RTYPE compiled_block_1_1341( CONT_PARAMS );
static RTYPE compiled_block_1_1338( CONT_PARAMS );
static RTYPE compiled_block_1_1336( CONT_PARAMS );
static RTYPE compiled_block_1_1334( CONT_PARAMS );
static RTYPE compiled_start_1_60( CONT_PARAMS );
static RTYPE compiled_block_1_1333( CONT_PARAMS );
static RTYPE compiled_block_1_1332( CONT_PARAMS );
static RTYPE compiled_block_1_1331( CONT_PARAMS );
static RTYPE compiled_start_1_59( CONT_PARAMS );
static RTYPE compiled_block_1_1329( CONT_PARAMS );
static RTYPE compiled_block_1_1328( CONT_PARAMS );
static RTYPE compiled_block_1_1327( CONT_PARAMS );
static RTYPE compiled_start_1_58( CONT_PARAMS );
static RTYPE compiled_start_1_57( CONT_PARAMS );
static RTYPE compiled_block_1_1316( CONT_PARAMS );
static RTYPE compiled_temp_1_91( CONT_PARAMS );
static RTYPE compiled_block_1_1322( CONT_PARAMS );
static RTYPE compiled_block_1_1323( CONT_PARAMS );
static RTYPE compiled_block_1_1324( CONT_PARAMS );
static RTYPE compiled_block_1_1318( CONT_PARAMS );
static RTYPE compiled_block_1_1319( CONT_PARAMS );
static RTYPE compiled_block_1_1321( CONT_PARAMS );
static RTYPE compiled_block_1_1320( CONT_PARAMS );
static RTYPE compiled_block_1_1317( CONT_PARAMS );
static RTYPE compiled_temp_1_90( CONT_PARAMS );
static RTYPE compiled_start_1_89( CONT_PARAMS );
static RTYPE compiled_block_1_1314( CONT_PARAMS );
static RTYPE compiled_block_1_1313( CONT_PARAMS );
static RTYPE compiled_start_1_56( CONT_PARAMS );
static RTYPE compiled_block_1_1310( CONT_PARAMS );
static RTYPE compiled_block_1_1311( CONT_PARAMS );
static RTYPE compiled_block_1_1308( CONT_PARAMS );
static RTYPE compiled_block_1_1309( CONT_PARAMS );
static RTYPE compiled_block_1_1307( CONT_PARAMS );
static RTYPE compiled_block_1_1305( CONT_PARAMS );
static RTYPE compiled_block_1_1306( CONT_PARAMS );
static RTYPE compiled_start_1_55( CONT_PARAMS );
static RTYPE compiled_temp_1_96( CONT_PARAMS );
static RTYPE compiled_block_1_1298( CONT_PARAMS );
static RTYPE compiled_block_1_1299( CONT_PARAMS );
static RTYPE compiled_temp_1_95( CONT_PARAMS );
static RTYPE compiled_block_1_1296( CONT_PARAMS );
static RTYPE compiled_block_1_1297( CONT_PARAMS );
static RTYPE compiled_block_1_1294( CONT_PARAMS );
static RTYPE compiled_block_1_1295( CONT_PARAMS );
static RTYPE compiled_temp_1_94( CONT_PARAMS );
static RTYPE compiled_block_1_1291( CONT_PARAMS );
static RTYPE compiled_block_1_1292( CONT_PARAMS );
static RTYPE compiled_block_1_1293( CONT_PARAMS );
static RTYPE compiled_block_1_1287( CONT_PARAMS );
static RTYPE compiled_block_1_1288( CONT_PARAMS );
static RTYPE compiled_block_1_1290( CONT_PARAMS );
static RTYPE compiled_temp_1_93( CONT_PARAMS );
static RTYPE compiled_temp_1_92( CONT_PARAMS );
static RTYPE compiled_start_1_54( CONT_PARAMS );
static RTYPE compiled_block_1_1301( CONT_PARAMS );
static RTYPE compiled_temp_1_99( CONT_PARAMS );
static RTYPE compiled_block_1_1302( CONT_PARAMS );
static RTYPE compiled_temp_1_98( CONT_PARAMS );
static RTYPE compiled_start_1_97( CONT_PARAMS );
static RTYPE compiled_block_1_1277( CONT_PARAMS );
static RTYPE compiled_block_1_1276( CONT_PARAMS );
static RTYPE compiled_start_1_53( CONT_PARAMS );
static RTYPE compiled_block_1_1284( CONT_PARAMS );
static RTYPE compiled_temp_1_102( CONT_PARAMS );
static RTYPE compiled_block_1_1281( CONT_PARAMS );
static RTYPE compiled_block_1_1283( CONT_PARAMS );
static RTYPE compiled_block_1_1282( CONT_PARAMS );
static RTYPE compiled_block_1_1280( CONT_PARAMS );
static RTYPE compiled_block_1_1279( CONT_PARAMS );
static RTYPE compiled_temp_1_101( CONT_PARAMS );
static RTYPE compiled_start_1_100( CONT_PARAMS );
static RTYPE compiled_block_1_1275( CONT_PARAMS );
static RTYPE compiled_block_1_1274( CONT_PARAMS );
static RTYPE compiled_start_1_52( CONT_PARAMS );
static RTYPE compiled_block_1_1272( CONT_PARAMS );
static RTYPE compiled_block_1_1271( CONT_PARAMS );
static RTYPE compiled_start_1_51( CONT_PARAMS );
static RTYPE compiled_block_1_1263( CONT_PARAMS );
static RTYPE compiled_start_1_50( CONT_PARAMS );
static RTYPE compiled_block_1_1266( CONT_PARAMS );
static RTYPE compiled_block_1_1268( CONT_PARAMS );
static RTYPE compiled_block_1_1267( CONT_PARAMS );
static RTYPE compiled_block_1_1265( CONT_PARAMS );
static RTYPE compiled_temp_1_104( CONT_PARAMS );
static RTYPE compiled_start_1_103( CONT_PARAMS );
static RTYPE compiled_block_1_1254( CONT_PARAMS );
static RTYPE compiled_start_1_49( CONT_PARAMS );
static RTYPE compiled_block_1_1258( CONT_PARAMS );
static RTYPE compiled_block_1_1260( CONT_PARAMS );
static RTYPE compiled_block_1_1259( CONT_PARAMS );
static RTYPE compiled_block_1_1257( CONT_PARAMS );
static RTYPE compiled_temp_1_107( CONT_PARAMS );
static RTYPE compiled_block_1_1256( CONT_PARAMS );
static RTYPE compiled_temp_1_106( CONT_PARAMS );
static RTYPE compiled_start_1_105( CONT_PARAMS );
static RTYPE compiled_block_1_1253( CONT_PARAMS );
static RTYPE compiled_block_1_1252( CONT_PARAMS );
static RTYPE compiled_start_1_48( CONT_PARAMS );
static RTYPE compiled_block_1_1250( CONT_PARAMS );
static RTYPE compiled_block_1_1249( CONT_PARAMS );
static RTYPE compiled_start_1_47( CONT_PARAMS );
static RTYPE compiled_block_1_1247( CONT_PARAMS );
static RTYPE compiled_start_1_46( CONT_PARAMS );
static RTYPE compiled_start_1_45( CONT_PARAMS );
static RTYPE compiled_block_1_1244( CONT_PARAMS );
static RTYPE compiled_start_1_108( CONT_PARAMS );
static RTYPE compiled_block_1_1243( CONT_PARAMS );
static RTYPE compiled_block_1_1242( CONT_PARAMS );
static RTYPE compiled_start_1_44( CONT_PARAMS );
static RTYPE compiled_block_1_1240( CONT_PARAMS );
static RTYPE compiled_block_1_1239( CONT_PARAMS );
static RTYPE compiled_start_1_43( CONT_PARAMS );
static RTYPE compiled_start_1_42( CONT_PARAMS );
static RTYPE compiled_block_1_1236( CONT_PARAMS );
static RTYPE compiled_block_1_1235( CONT_PARAMS );
static RTYPE compiled_block_1_1234( CONT_PARAMS );
static RTYPE compiled_block_1_1233( CONT_PARAMS );
static RTYPE compiled_block_1_1232( CONT_PARAMS );
static RTYPE compiled_block_1_1230( CONT_PARAMS );
static RTYPE compiled_start_1_109( CONT_PARAMS );
static RTYPE compiled_block_1_1218( CONT_PARAMS );
static RTYPE compiled_start_1_41( CONT_PARAMS );
static RTYPE compiled_block_1_1220( CONT_PARAMS );
static RTYPE compiled_temp_1_112( CONT_PARAMS );
static RTYPE compiled_block_1_1227( CONT_PARAMS );
static RTYPE compiled_block_1_1222( CONT_PARAMS );
static RTYPE compiled_block_1_1223( CONT_PARAMS );
static RTYPE compiled_block_1_1225( CONT_PARAMS );
static RTYPE compiled_block_1_1224( CONT_PARAMS );
static RTYPE compiled_block_1_1221( CONT_PARAMS );
static RTYPE compiled_temp_1_111( CONT_PARAMS );
static RTYPE compiled_start_1_110( CONT_PARAMS );
static RTYPE compiled_block_1_1206( CONT_PARAMS );
static RTYPE compiled_start_1_40( CONT_PARAMS );
static RTYPE compiled_block_1_1215( CONT_PARAMS );
static RTYPE compiled_temp_1_115( CONT_PARAMS );
static RTYPE compiled_block_1_1210( CONT_PARAMS );
static RTYPE compiled_block_1_1213( CONT_PARAMS );
static RTYPE compiled_block_1_1212( CONT_PARAMS );
static RTYPE compiled_block_1_1211( CONT_PARAMS );
static RTYPE compiled_block_1_1209( CONT_PARAMS );
static RTYPE compiled_block_1_1208( CONT_PARAMS );
static RTYPE compiled_temp_1_114( CONT_PARAMS );
static RTYPE compiled_start_1_113( CONT_PARAMS );
static RTYPE compiled_block_1_1196( CONT_PARAMS );
static RTYPE compiled_start_1_39( CONT_PARAMS );
static RTYPE compiled_block_1_1200( CONT_PARAMS );
static RTYPE compiled_block_1_1203( CONT_PARAMS );
static RTYPE compiled_block_1_1202( CONT_PARAMS );
static RTYPE compiled_block_1_1201( CONT_PARAMS );
static RTYPE compiled_block_1_1199( CONT_PARAMS );
static RTYPE compiled_temp_1_118( CONT_PARAMS );
static RTYPE compiled_block_1_1198( CONT_PARAMS );
static RTYPE compiled_temp_1_117( CONT_PARAMS );
static RTYPE compiled_start_1_116( CONT_PARAMS );
static RTYPE compiled_block_1_1194( CONT_PARAMS );
static RTYPE compiled_block_1_1183( CONT_PARAMS );
static RTYPE compiled_start_1_38( CONT_PARAMS );
static RTYPE compiled_block_1_1185( CONT_PARAMS );
static RTYPE compiled_temp_1_121( CONT_PARAMS );
static RTYPE compiled_block_1_1187( CONT_PARAMS );
static RTYPE compiled_block_1_1188( CONT_PARAMS );
static RTYPE compiled_block_1_1192( CONT_PARAMS );
static RTYPE compiled_block_1_1191( CONT_PARAMS );
static RTYPE compiled_block_1_1190( CONT_PARAMS );
static RTYPE compiled_block_1_1189( CONT_PARAMS );
static RTYPE compiled_block_1_1186( CONT_PARAMS );
static RTYPE compiled_temp_1_120( CONT_PARAMS );
static RTYPE compiled_start_1_119( CONT_PARAMS );
static RTYPE compiled_block_1_1173( CONT_PARAMS );
static RTYPE compiled_start_1_37( CONT_PARAMS );
static RTYPE compiled_block_1_1175( CONT_PARAMS );
static RTYPE compiled_temp_1_124( CONT_PARAMS );
static RTYPE compiled_block_1_1177( CONT_PARAMS );
static RTYPE compiled_block_1_1178( CONT_PARAMS );
static RTYPE compiled_block_1_1180( CONT_PARAMS );
static RTYPE compiled_block_1_1179( CONT_PARAMS );
static RTYPE compiled_block_1_1176( CONT_PARAMS );
static RTYPE compiled_temp_1_123( CONT_PARAMS );
static RTYPE compiled_start_1_122( CONT_PARAMS );
static RTYPE compiled_block_1_1165( CONT_PARAMS );
static RTYPE compiled_start_1_36( CONT_PARAMS );
static RTYPE compiled_block_1_1170( CONT_PARAMS );
static RTYPE compiled_block_1_1166( CONT_PARAMS );
static RTYPE compiled_block_1_1168( CONT_PARAMS );
static RTYPE compiled_block_1_1167( CONT_PARAMS );
static RTYPE compiled_temp_1_127( CONT_PARAMS );
static RTYPE compiled_temp_1_126( CONT_PARAMS );
static RTYPE compiled_start_1_125( CONT_PARAMS );
static RTYPE compiled_start_1_35( CONT_PARAMS );
static RTYPE compiled_start_1_34( CONT_PARAMS );
static RTYPE compiled_temp_1_128( CONT_PARAMS );
static RTYPE compiled_start_1_33( CONT_PARAMS );
static RTYPE compiled_start_1_32( CONT_PARAMS );
static RTYPE compiled_start_1_31( CONT_PARAMS );
static RTYPE compiled_start_1_30( CONT_PARAMS );
static RTYPE compiled_start_1_29( CONT_PARAMS );
static RTYPE compiled_start_1_28( CONT_PARAMS );
static RTYPE compiled_block_1_1157( CONT_PARAMS );
static RTYPE compiled_block_1_1154( CONT_PARAMS );
static RTYPE compiled_start_1_27( CONT_PARAMS );
static RTYPE compiled_block_1_1155( CONT_PARAMS );
static RTYPE compiled_start_1_129( CONT_PARAMS );
static RTYPE compiled_block_1_1152( CONT_PARAMS );
static RTYPE compiled_block_1_1149( CONT_PARAMS );
static RTYPE compiled_block_1_1148( CONT_PARAMS );
static RTYPE compiled_start_1_26( CONT_PARAMS );
static RTYPE compiled_block_1_1150( CONT_PARAMS );
static RTYPE compiled_start_1_130( CONT_PARAMS );
static RTYPE compiled_block_1_1136( CONT_PARAMS );
static RTYPE compiled_start_1_25( CONT_PARAMS );
static RTYPE compiled_block_1_1144( CONT_PARAMS );
static RTYPE compiled_block_1_1145( CONT_PARAMS );
static RTYPE compiled_temp_1_134( CONT_PARAMS );
static RTYPE compiled_block_1_1140( CONT_PARAMS );
static RTYPE compiled_block_1_1141( CONT_PARAMS );
static RTYPE compiled_block_1_1143( CONT_PARAMS );
static RTYPE compiled_block_1_1142( CONT_PARAMS );
static RTYPE compiled_block_1_1139( CONT_PARAMS );
static RTYPE compiled_temp_1_133( CONT_PARAMS );
static RTYPE compiled_block_1_1138( CONT_PARAMS );
static RTYPE compiled_temp_1_132( CONT_PARAMS );
static RTYPE compiled_start_1_131( CONT_PARAMS );
static RTYPE compiled_block_1_1130( CONT_PARAMS );
static RTYPE compiled_start_1_24( CONT_PARAMS );
static RTYPE compiled_temp_1_138( CONT_PARAMS );
static RTYPE compiled_block_1_1133( CONT_PARAMS );
static RTYPE compiled_temp_1_137( CONT_PARAMS );
static RTYPE compiled_block_1_1132( CONT_PARAMS );
static RTYPE compiled_temp_1_136( CONT_PARAMS );
static RTYPE compiled_start_1_135( CONT_PARAMS );
static RTYPE compiled_block_1_1128( CONT_PARAMS );
static RTYPE compiled_block_1_1127( CONT_PARAMS );
static RTYPE compiled_start_1_23( CONT_PARAMS );
static RTYPE compiled_block_1_1110( CONT_PARAMS );
static RTYPE compiled_block_1_1117( CONT_PARAMS );
static RTYPE compiled_block_1_1113( CONT_PARAMS );
static RTYPE compiled_block_1_1111( CONT_PARAMS );
static RTYPE compiled_block_1_1112( CONT_PARAMS );
static RTYPE compiled_temp_1_140( CONT_PARAMS );
static RTYPE compiled_block_1_1108( CONT_PARAMS );
static RTYPE compiled_block_1_1109( CONT_PARAMS );
static RTYPE compiled_block_1_1106( CONT_PARAMS );
static RTYPE compiled_block_1_1107( CONT_PARAMS );
static RTYPE compiled_temp_1_139( CONT_PARAMS );
static RTYPE compiled_start_1_22( CONT_PARAMS );
static RTYPE compiled_block_1_1122( CONT_PARAMS );
static RTYPE compiled_block_1_1124( CONT_PARAMS );
static RTYPE compiled_temp_1_146( CONT_PARAMS );
static RTYPE compiled_temp_1_145( CONT_PARAMS );
static RTYPE compiled_block_1_1123( CONT_PARAMS );
static RTYPE compiled_block_1_1121( CONT_PARAMS );
static RTYPE compiled_temp_1_144( CONT_PARAMS );
static RTYPE compiled_block_1_1119( CONT_PARAMS );
static RTYPE compiled_temp_1_143( CONT_PARAMS );
static RTYPE compiled_start_1_142( CONT_PARAMS );
static RTYPE compiled_temp_1_149( CONT_PARAMS );
static RTYPE compiled_block_1_1115( CONT_PARAMS );
static RTYPE compiled_temp_1_148( CONT_PARAMS );
static RTYPE compiled_temp_1_147( CONT_PARAMS );
static RTYPE compiled_start_1_141( CONT_PARAMS );
static RTYPE compiled_block_1_1087( CONT_PARAMS );
static RTYPE compiled_block_1_1088( CONT_PARAMS );
static RTYPE compiled_block_1_1086( CONT_PARAMS );
static RTYPE compiled_start_1_21( CONT_PARAMS );
static RTYPE compiled_block_1_1091( CONT_PARAMS );
static RTYPE compiled_block_1_1094( CONT_PARAMS );
static RTYPE compiled_block_1_1092( CONT_PARAMS );
static RTYPE compiled_block_1_1090( CONT_PARAMS );
static RTYPE compiled_start_1_150( CONT_PARAMS );
static RTYPE compiled_block_1_1102( CONT_PARAMS );
static RTYPE compiled_temp_1_154( CONT_PARAMS );
static RTYPE compiled_temp_1_153( CONT_PARAMS );
static RTYPE compiled_block_1_1100( CONT_PARAMS );
static RTYPE compiled_block_1_1099( CONT_PARAMS );
static RTYPE compiled_block_1_1097( CONT_PARAMS );
static RTYPE compiled_temp_1_152( CONT_PARAMS );
static RTYPE compiled_start_1_151( CONT_PARAMS );
static RTYPE compiled_block_1_1074( CONT_PARAMS );
static RTYPE compiled_block_1_1075( CONT_PARAMS );
static RTYPE compiled_block_1_1073( CONT_PARAMS );
static RTYPE compiled_start_1_20( CONT_PARAMS );
static RTYPE compiled_block_1_1078( CONT_PARAMS );
static RTYPE compiled_block_1_1082( CONT_PARAMS );
static RTYPE compiled_block_1_1080( CONT_PARAMS );
static RTYPE compiled_block_1_1079( CONT_PARAMS );
static RTYPE compiled_block_1_1077( CONT_PARAMS );
static RTYPE compiled_start_1_155( CONT_PARAMS );
static RTYPE compiled_block_1_1070( CONT_PARAMS );
static RTYPE compiled_block_1_1069( CONT_PARAMS );
static RTYPE compiled_start_1_19( CONT_PARAMS );
static RTYPE compiled_temp_1_157( CONT_PARAMS );
static RTYPE compiled_block_1_1067( CONT_PARAMS );
static RTYPE compiled_block_1_1066( CONT_PARAMS );
static RTYPE compiled_temp_1_156( CONT_PARAMS );
static RTYPE compiled_start_1_18( CONT_PARAMS );
static RTYPE compiled_block_1_1063( CONT_PARAMS );
static RTYPE compiled_temp_1_158( CONT_PARAMS );
static RTYPE compiled_start_1_17( CONT_PARAMS );
static RTYPE compiled_block_1_1060( CONT_PARAMS );
static RTYPE compiled_temp_1_159( CONT_PARAMS );
static RTYPE compiled_start_1_16( CONT_PARAMS );
static RTYPE compiled_block_1_1057( CONT_PARAMS );
static RTYPE compiled_temp_1_160( CONT_PARAMS );
static RTYPE compiled_start_1_15( CONT_PARAMS );
static RTYPE compiled_temp_1_161( CONT_PARAMS );
static RTYPE compiled_start_1_14( CONT_PARAMS );
static RTYPE compiled_block_1_1054( CONT_PARAMS );
static RTYPE compiled_block_1_1053( CONT_PARAMS );
static RTYPE compiled_start_1_13( CONT_PARAMS );
static RTYPE compiled_block_1_1052( CONT_PARAMS );
static RTYPE compiled_start_1_12( CONT_PARAMS );
static RTYPE compiled_block_1_1051( CONT_PARAMS );
static RTYPE compiled_start_1_11( CONT_PARAMS );
static RTYPE compiled_block_1_1049( CONT_PARAMS );
static RTYPE compiled_start_1_10( CONT_PARAMS );
static RTYPE compiled_block_1_1046( CONT_PARAMS );
static RTYPE compiled_start_1_9( CONT_PARAMS );
static RTYPE compiled_block_1_1044( CONT_PARAMS );
static RTYPE compiled_temp_1_162( CONT_PARAMS );
static RTYPE compiled_block_1_1045( CONT_PARAMS );
static RTYPE compiled_start_1_8( CONT_PARAMS );
static RTYPE compiled_start_1_7( CONT_PARAMS );
static RTYPE compiled_block_1_1041( CONT_PARAMS );
static RTYPE compiled_block_1_1039( CONT_PARAMS );
static RTYPE compiled_block_1_1037( CONT_PARAMS );
static RTYPE compiled_start_1_163( CONT_PARAMS );
static RTYPE compiled_block_1_1036( CONT_PARAMS );
static RTYPE compiled_block_1_1026( CONT_PARAMS );
static RTYPE compiled_block_1_1028( CONT_PARAMS );
static RTYPE compiled_block_1_1031( CONT_PARAMS );
static RTYPE compiled_block_1_1032( CONT_PARAMS );
static RTYPE compiled_block_1_1029( CONT_PARAMS );
static RTYPE compiled_start_1_6( CONT_PARAMS );
static RTYPE compiled_block_1_1023( CONT_PARAMS );
static RTYPE compiled_start_1_5( CONT_PARAMS );
static RTYPE compiled_start_1_4( CONT_PARAMS );
static RTYPE compiled_block_1_1016( CONT_PARAMS );
static RTYPE compiled_start_1_2( CONT_PARAMS );
static RTYPE compiled_block_1_1002( CONT_PARAMS );
static RTYPE compiled_block_1_1004( CONT_PARAMS );
static RTYPE compiled_block_1_1006( CONT_PARAMS );
static RTYPE compiled_block_1_1008( CONT_PARAMS );
static RTYPE compiled_block_1_1010( CONT_PARAMS );
static RTYPE compiled_start_1_164( CONT_PARAMS );
static RTYPE compiled_start_1_1( CONT_PARAMS );

static RTYPE compiled_start_1_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 2 ); /*  char-set:ascii~1ayXVW~6604 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 3 ); /*  char-set:iso-control~1ayXVW~6603 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 4 ); /*  char-set:blank~1ayXVW~6602 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 5 ); /*  char-set:printing~1ayXVW~6601 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 6 ); /*  char-set:whitespace~1ayXVW~6600 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 7 ); /*  char-set:graphic~1ayXVW~6599 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 8 ); /*  char-set:symbol~1ayXVW~6598 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 9 ); /*  char-set:punctuation~1ayXVW~6597 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 10 ); /*  char-set:letter+digit~1ayXVW~6596 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 11 ); /*  char-set:hex-digit~1ayXVW~6595 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 12 ); /*  char-set:digit~1ayXVW~6594 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 13 ); /*  char-set:letter~1ayXVW~6593 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 14 ); /*  char-set:title-case~1ayXVW~6592 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 15 ); /*  char-set:upper-case~1ayXVW~6591 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 16 ); /*  char-set:lower-case~1ayXVW~6590 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 17 ); /*  char-set:full~1ayXVW~6589 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 18 ); /*  char-set:empty~1ayXVW~6588 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 19 ); /*  char-set-diff+intersection~1ayXVW~6587 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 20 ); /*  char-set-diff+intersection!~1ayXVW~6586 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 21 ); /*  %char-set-diff+intersection!~1ayXVW~6585 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 22 ); /*  char-set-xor~1ayXVW~6584 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 23 ); /*  char-set-xor!~1ayXVW~6583 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 24 ); /*  char-set-difference~1ayXVW~6582 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 25 ); /*  char-set-difference!~1ayXVW~6581 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 26 ); /*  char-set-intersection~1ayXVW~6580 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 27 ); /*  char-set-intersection!~1ayXVW~6579 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 28 ); /*  char-set-union~1ayXVW~6578 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 29 ); /*  char-set-union!~1ayXVW~6577 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 30 ); /*  char-set-complement!~1ayXVW~6576 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 31 ); /*  char-set-complement~1ayXVW~6575 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 32 ); /*  %char-set-algebra~1ayXVW~6574 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 33 ); /*  %string-iter~1ayXVW~6573 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 34 ); /*  ->char-set~1ayXVW~6572 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 35 ); /*  char-set-filter!~1ayXVW~6571 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 36 ); /*  char-set-filter~1ayXVW~6570 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 37 ); /*  %char-set-filter!~1ayXVW~6569 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 38 ); /*  ucs-range->char-set!~1ayXVW~6568 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 39 ); /*  ucs-range->char-set~1ayXVW~6567 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 40 ); /*  %ucs-range->char-set!~1ayXVW~6566 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 41 ); /*  char-set->string~1ayXVW~6565 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 42 ); /*  string->char-set!~1ayXVW~6564 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 43 ); /*  string->char-set~1ayXVW~6563 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 44 ); /*  %string->char-set!~1ayXVW~6562 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 45 ); /*  char-set->list~1ayXVW~6561 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 46 ); /*  list->char-set!~1ayXVW~6560 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 47 ); /*  list->char-set~1ayXVW~6559 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 48 ); /*  char-set~1ayXVW~6558 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 49 ); /*  %list->char-set!~1ayXVW~6557 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 50 ); /*  char-set-unfold!~1ayXVW~6556 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 51 ); /*  char-set-unfold~1ayXVW~6555 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 52 ); /*  %char-set-unfold!~1ayXVW~6554 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 53 ); /*  char-set-any~1ayXVW~6553 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 54 ); /*  char-set-every~1ayXVW~6552 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 55 ); /*  char-set-fold~1ayXVW~6551 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 56 ); /*  char-set-map~1ayXVW~6550 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 57 ); /*  char-set-for-each~1ayXVW~6549 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 58 ); /*  %char-set-cursor-next~1ayXVW~6548 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 59 ); /*  char-set-cursor-next~1ayXVW~6547 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 60 ); /*  char-set-ref~1ayXVW~6546 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 61 ); /*  end-of-char-set?~1ayXVW~6545 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 62 ); /*  char-set-cursor~1ayXVW~6544 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 63 ); /*  char-set-delete!~1ayXVW~6543 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 64 ); /*  char-set-delete~1ayXVW~6542 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 65 ); /*  char-set-adjoin!~1ayXVW~6541 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 66 ); /*  char-set-adjoin~1ayXVW~6540 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 67 ); /*  %set-char-set!~1ayXVW~6539 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 68 ); /*  %set-char-set~1ayXVW~6538 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 69 ); /*  char-set-count~1ayXVW~6537 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 70 ); /*  char-set-size~1ayXVW~6536 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 71 ); /*  char-set-contains?~1ayXVW~6535 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 72 ); /*  char-set-hash~1ayXVW~6534 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 73 ); /*  char-set<=~1ayXVW~6533 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 74 ); /*  char-set=~1ayXVW~6532 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 75 ); /*  char-set-copy~1ayXVW~6531 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 76 ); /*  %xor!~1ayXVW~6530 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 77 ); /*  %minus!~1ayXVW~6529 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 78 ); /*  %or!~1ayXVW~6528 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 79 ); /*  %and!~1ayXVW~6527 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 80 ); /*  %not!~1ayXVW~6526 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 81 ); /*  setv!~1ayXVW~6525 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 82 ); /*  %set1!~1ayXVW~6524 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 83 ); /*  %set0!~1ayXVW~6523 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 84 ); /*  si~1ayXVW~6522 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 85 ); /*  c1~1ayXVW~6521 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 86 ); /*  c0~1ayXVW~6520 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 87 ); /*  si=1?~1ayXVW~6519 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 88 ); /*  si=0?~1ayXVW~6518 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 89 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 90 ); /*  %default-base~1ayXVW~6516 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 91 ); /*  %string-copy~1ayXVW~6515 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 92 ); /*  %char->latin1~1ayXVW~6514 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 93 ); /*  %latin1->char~1ayXVW~6513 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 94 ); /*  char-set:s~1ayXVW~6492 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 95 ); /*  char-set?~1ayXVW~6491 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 96 ); /*  make-char-set~1ayXVW~6490 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 97 ); /*  :char-set~1ayXVW~6489 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 98 ); /*  error~1ayXVW~6485 */
  twobit_lambda( compiled_start_1_1, 100, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_2, 102, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_3, 104, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 105 );
  twobit_setreg( 1 );
  twobit_const( 106 );
  twobit_setreg( 3 );
  twobit_const( 107 );
  twobit_setreg( 4 );
  twobit_const( 108 );
  twobit_setreg( 5 );
  twobit_const( 109 );
  twobit_setreg( 8 );
  twobit_global( 110 ); /* ex:make-library */
  twobit_setrtn( 1464, compiled_block_1_1464 );
  twobit_invoke( 8 );
  twobit_label( 1464, compiled_block_1_1464 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 111 ); /* ex:register-library! */
  twobit_setrtn( 1465, compiled_block_1_1465 );
  twobit_invoke( 1 );
  twobit_label( 1465, compiled_block_1_1465 );
  twobit_load( 0, 0 );
  twobit_global( 112 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_164, 2, 0 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1016, compiled_block_1_1016 );
  twobit_invoke( 2 );
  twobit_label( 1016, compiled_block_1_1016 );
  twobit_load( 0, 0 );
  twobit_global( 5 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_164( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1002, compiled_block_1_1002 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1004, compiled_block_1_1004 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1006, compiled_block_1_1006 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1008, compiled_block_1_1008 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1010, compiled_block_1_1010 ); /* internal:branchf-null? */
  twobit_reg( 3 );
  twobit_return();
  twobit_label( 1010, compiled_block_1_1010 );
  twobit_global( 1 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1008, compiled_block_1_1008 );
  twobit_global( 1 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1006, compiled_block_1_1006 );
  twobit_global( 1 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_1_1004 );
  twobit_global( 1 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1002, compiled_block_1_1002 );
  twobit_global( 1 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 2 ); /*  char-set:ascii~1ayXVW~6604 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 3 ); /*  char-set:iso-control~1ayXVW~6603 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 4 ); /*  char-set:blank~1ayXVW~6602 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 5 ); /*  char-set:printing~1ayXVW~6601 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 6 ); /*  char-set:whitespace~1ayXVW~6600 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 7 ); /*  char-set:graphic~1ayXVW~6599 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 8 ); /*  char-set:symbol~1ayXVW~6598 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 9 ); /*  char-set:punctuation~1ayXVW~6597 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 10 ); /*  char-set:letter+digit~1ayXVW~6596 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 11 ); /*  char-set:hex-digit~1ayXVW~6595 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 12 ); /*  char-set:digit~1ayXVW~6594 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 13 ); /*  char-set:letter~1ayXVW~6593 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 14 ); /*  char-set:title-case~1ayXVW~6592 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 15 ); /*  char-set:upper-case~1ayXVW~6591 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 16 ); /*  char-set:lower-case~1ayXVW~6590 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 17 ); /*  char-set:full~1ayXVW~6589 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 18 ); /*  char-set:empty~1ayXVW~6588 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 19 ); /*  char-set-diff+intersection~1ayXVW~6587 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 20 ); /*  char-set-diff+intersection!~1ayXVW~6586 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 21 ); /*  %char-set-diff+intersection!~1ayXVW~6585 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 22 ); /*  char-set-xor~1ayXVW~6584 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 23 ); /*  char-set-xor!~1ayXVW~6583 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 24 ); /*  char-set-difference~1ayXVW~6582 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 25 ); /*  char-set-difference!~1ayXVW~6581 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 26 ); /*  char-set-intersection~1ayXVW~6580 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 27 ); /*  char-set-intersection!~1ayXVW~6579 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 28 ); /*  char-set-union~1ayXVW~6578 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 29 ); /*  char-set-union!~1ayXVW~6577 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 30 ); /*  char-set-complement!~1ayXVW~6576 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 31 ); /*  char-set-complement~1ayXVW~6575 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 32 ); /*  %char-set-algebra~1ayXVW~6574 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 33 ); /*  %string-iter~1ayXVW~6573 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 34 ); /*  ->char-set~1ayXVW~6572 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 35 ); /*  char-set-filter!~1ayXVW~6571 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 36 ); /*  char-set-filter~1ayXVW~6570 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 37 ); /*  %char-set-filter!~1ayXVW~6569 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 38 ); /*  ucs-range->char-set!~1ayXVW~6568 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 39 ); /*  ucs-range->char-set~1ayXVW~6567 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 40 ); /*  %ucs-range->char-set!~1ayXVW~6566 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 41 ); /*  char-set->string~1ayXVW~6565 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 42 ); /*  string->char-set!~1ayXVW~6564 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 43 ); /*  string->char-set~1ayXVW~6563 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 44 ); /*  %string->char-set!~1ayXVW~6562 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 45 ); /*  char-set->list~1ayXVW~6561 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 46 ); /*  list->char-set!~1ayXVW~6560 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 47 ); /*  list->char-set~1ayXVW~6559 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 48 ); /*  char-set~1ayXVW~6558 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 49 ); /*  %list->char-set!~1ayXVW~6557 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 50 ); /*  char-set-unfold!~1ayXVW~6556 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 51 ); /*  char-set-unfold~1ayXVW~6555 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 52 ); /*  %char-set-unfold!~1ayXVW~6554 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 53 ); /*  char-set-any~1ayXVW~6553 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 54 ); /*  char-set-every~1ayXVW~6552 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 55 ); /*  char-set-fold~1ayXVW~6551 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 56 ); /*  char-set-map~1ayXVW~6550 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 57 ); /*  char-set-for-each~1ayXVW~6549 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 58 ); /*  %char-set-cursor-next~1ayXVW~6548 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 59 ); /*  char-set-cursor-next~1ayXVW~6547 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 60 ); /*  char-set-ref~1ayXVW~6546 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 61 ); /*  end-of-char-set?~1ayXVW~6545 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 62 ); /*  char-set-cursor~1ayXVW~6544 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 63 ); /*  char-set-delete!~1ayXVW~6543 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 64 ); /*  char-set-delete~1ayXVW~6542 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 65 ); /*  char-set-adjoin!~1ayXVW~6541 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 66 ); /*  char-set-adjoin~1ayXVW~6540 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 67 ); /*  %set-char-set!~1ayXVW~6539 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 68 ); /*  %set-char-set~1ayXVW~6538 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 69 ); /*  char-set-count~1ayXVW~6537 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 70 ); /*  char-set-size~1ayXVW~6536 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 71 ); /*  char-set-contains?~1ayXVW~6535 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 72 ); /*  char-set-hash~1ayXVW~6534 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 73 ); /*  char-set<=~1ayXVW~6533 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 74 ); /*  char-set=~1ayXVW~6532 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 75 ); /*  char-set-copy~1ayXVW~6531 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 76 ); /*  %xor!~1ayXVW~6530 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 77 ); /*  %minus!~1ayXVW~6529 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 78 ); /*  %or!~1ayXVW~6528 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 79 ); /*  %and!~1ayXVW~6527 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 80 ); /*  %not!~1ayXVW~6526 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 81 ); /*  setv!~1ayXVW~6525 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 82 ); /*  %set1!~1ayXVW~6524 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 83 ); /*  %set0!~1ayXVW~6523 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 84 ); /*  si~1ayXVW~6522 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 85 ); /*  c1~1ayXVW~6521 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 86 ); /*  c0~1ayXVW~6520 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 87 ); /*  si=1?~1ayXVW~6519 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 88 ); /*  si=0?~1ayXVW~6518 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 89 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 90 ); /*  %default-base~1ayXVW~6516 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 91 ); /*  %string-copy~1ayXVW~6515 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 92 ); /*  %char->latin1~1ayXVW~6514 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 93 ); /*  %latin1->char~1ayXVW~6513 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 94 ); /*  char-set:s~1ayXVW~6492 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 95 ); /*  char-set?~1ayXVW~6491 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 96 ); /*  make-char-set~1ayXVW~6490 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 97 ); /*  :char-set~1ayXVW~6489 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 98 ); /*  error~1ayXVW~6485 */
  twobit_lambda( compiled_start_1_4, 100, 0 );
  twobit_setglbl( 101 ); /*  error~1ayXVW~6485 */
  twobit_const( 102 );
  twobit_setreg( 1 );
  twobit_const( 103 );
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_global( 104 ); /* make-rtd */
  twobit_setrtn( 1019, compiled_block_1_1019 );
  twobit_invoke( 3 );
  twobit_label( 1019, compiled_block_1_1019 );
  twobit_load( 0, 0 );
  twobit_setglbl( 105 ); /*  :char-set~1ayXVW~6489 */
  twobit_global( 106 ); /*  :char-set~1ayXVW~6489 */
  twobit_setreg( 1 );
  twobit_const( 107 );
  twobit_setreg( 2 );
  twobit_global( 108 ); /* rtd-constructor */
  twobit_setrtn( 1020, compiled_block_1_1020 );
  twobit_invoke( 2 );
  twobit_label( 1020, compiled_block_1_1020 );
  twobit_load( 0, 0 );
  twobit_setglbl( 109 ); /*  make-char-set~1ayXVW~6490 */
  twobit_global( 110 ); /*  :char-set~1ayXVW~6489 */
  twobit_setreg( 1 );
  twobit_global( 111 ); /* rtd-predicate */
  twobit_setrtn( 1021, compiled_block_1_1021 );
  twobit_invoke( 1 );
  twobit_label( 1021, compiled_block_1_1021 );
  twobit_load( 0, 0 );
  twobit_setglbl( 112 ); /*  char-set?~1ayXVW~6491 */
  twobit_global( 113 ); /*  :char-set~1ayXVW~6489 */
  twobit_setreg( 1 );
  twobit_const( 114 );
  twobit_setreg( 2 );
  twobit_global( 115 ); /* rtd-accessor */
  twobit_setrtn( 1022, compiled_block_1_1022 );
  twobit_invoke( 2 );
  twobit_label( 1022, compiled_block_1_1022 );
  twobit_load( 0, 0 );
  twobit_setglbl( 116 ); /*  char-set:s~1ayXVW~6492 */
  twobit_global( 117 ); /* integer->char */
  twobit_setglbl( 118 ); /*  %latin1->char~1ayXVW~6513 */
  twobit_global( 119 ); /* char->integer */
  twobit_setglbl( 120 ); /*  %char->latin1~1ayXVW~6514 */
  twobit_lambda( compiled_start_1_5, 122, 0 );
  twobit_setglbl( 123 ); /*  %string-copy~1ayXVW~6515 */
  twobit_lambda( compiled_start_1_6, 125, 0 );
  twobit_setglbl( 126 ); /*  %default-base~1ayXVW~6516 */
  twobit_lambda( compiled_start_1_7, 128, 0 );
  twobit_setglbl( 129 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_lambda( compiled_start_1_8, 131, 0 );
  twobit_setglbl( 132 ); /*  si=0?~1ayXVW~6518 */
  twobit_lambda( compiled_start_1_9, 134, 0 );
  twobit_setglbl( 135 ); /*  si=1?~1ayXVW~6519 */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_global( 136 ); /*  %latin1->char~1ayXVW~6513 */
  twobit_setrtn( 1047, compiled_block_1_1047 );
  twobit_invoke( 1 );
  twobit_label( 1047, compiled_block_1_1047 );
  twobit_load( 0, 0 );
  twobit_setglbl( 137 ); /*  c0~1ayXVW~6520 */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_global( 138 ); /*  %latin1->char~1ayXVW~6513 */
  twobit_setrtn( 1048, compiled_block_1_1048 );
  twobit_invoke( 1 );
  twobit_label( 1048, compiled_block_1_1048 );
  twobit_load( 0, 0 );
  twobit_setglbl( 139 ); /*  c1~1ayXVW~6521 */
  twobit_lambda( compiled_start_1_10, 141, 0 );
  twobit_setglbl( 142 ); /*  si~1ayXVW~6522 */
  twobit_lambda( compiled_start_1_11, 144, 0 );
  twobit_setglbl( 145 ); /*  %set0!~1ayXVW~6523 */
  twobit_lambda( compiled_start_1_12, 147, 0 );
  twobit_setglbl( 148 ); /*  %set1!~1ayXVW~6524 */
  twobit_lambda( compiled_start_1_13, 150, 0 );
  twobit_setglbl( 151 ); /*  setv!~1ayXVW~6525 */
  twobit_lambda( compiled_start_1_14, 153, 0 );
  twobit_setglbl( 154 ); /*  %not!~1ayXVW~6526 */
  twobit_lambda( compiled_start_1_15, 156, 0 );
  twobit_setglbl( 157 ); /*  %and!~1ayXVW~6527 */
  twobit_lambda( compiled_start_1_16, 159, 0 );
  twobit_setglbl( 160 ); /*  %or!~1ayXVW~6528 */
  twobit_lambda( compiled_start_1_17, 162, 0 );
  twobit_setglbl( 163 ); /*  %minus!~1ayXVW~6529 */
  twobit_lambda( compiled_start_1_18, 165, 0 );
  twobit_setglbl( 166 ); /*  %xor!~1ayXVW~6530 */
  twobit_lambda( compiled_start_1_19, 168, 0 );
  twobit_setglbl( 169 ); /*  char-set-copy~1ayXVW~6531 */
  twobit_lambda( compiled_start_1_20, 171, 0 );
  twobit_setglbl( 172 ); /*  char-set=~1ayXVW~6532 */
  twobit_lambda( compiled_start_1_21, 174, 0 );
  twobit_setglbl( 175 ); /*  char-set<=~1ayXVW~6533 */
  twobit_lambda( compiled_start_1_22, 177, 0 );
  twobit_setglbl( 178 ); /*  char-set-hash~1ayXVW~6534 */
  twobit_lambda( compiled_start_1_23, 180, 0 );
  twobit_setglbl( 181 ); /*  char-set-contains?~1ayXVW~6535 */
  twobit_lambda( compiled_start_1_24, 183, 0 );
  twobit_setglbl( 184 ); /*  char-set-size~1ayXVW~6536 */
  twobit_lambda( compiled_start_1_25, 186, 0 );
  twobit_setglbl( 187 ); /*  char-set-count~1ayXVW~6537 */
  twobit_lambda( compiled_start_1_26, 189, 0 );
  twobit_setglbl( 190 ); /*  %set-char-set~1ayXVW~6538 */
  twobit_lambda( compiled_start_1_27, 192, 0 );
  twobit_setglbl( 193 ); /*  %set-char-set!~1ayXVW~6539 */
  twobit_lambda( compiled_start_1_28, 195, 0 );
  twobit_setglbl( 196 ); /*  char-set-adjoin~1ayXVW~6540 */
  twobit_lambda( compiled_start_1_29, 198, 0 );
  twobit_setglbl( 199 ); /*  char-set-adjoin!~1ayXVW~6541 */
  twobit_lambda( compiled_start_1_30, 201, 0 );
  twobit_setglbl( 202 ); /*  char-set-delete~1ayXVW~6542 */
  twobit_lambda( compiled_start_1_31, 204, 0 );
  twobit_setglbl( 205 ); /*  char-set-delete!~1ayXVW~6543 */
  twobit_lambda( compiled_start_1_32, 207, 0 );
  twobit_setglbl( 208 ); /*  char-set-cursor~1ayXVW~6544 */
  twobit_lambda( compiled_start_1_33, 210, 0 );
  twobit_setglbl( 211 ); /*  end-of-char-set?~1ayXVW~6545 */
  twobit_lambda( compiled_start_1_34, 213, 0 );
  twobit_setglbl( 214 ); /*  char-set-ref~1ayXVW~6546 */
  twobit_lambda( compiled_start_1_35, 216, 0 );
  twobit_setglbl( 217 ); /*  char-set-cursor-next~1ayXVW~6547 */
  twobit_lambda( compiled_start_1_36, 219, 0 );
  twobit_setglbl( 220 ); /*  %char-set-cursor-next~1ayXVW~6548 */
  twobit_lambda( compiled_start_1_37, 222, 0 );
  twobit_setglbl( 223 ); /*  char-set-for-each~1ayXVW~6549 */
  twobit_lambda( compiled_start_1_38, 225, 0 );
  twobit_setglbl( 226 ); /*  char-set-map~1ayXVW~6550 */
  twobit_lambda( compiled_start_1_39, 228, 0 );
  twobit_setglbl( 229 ); /*  char-set-fold~1ayXVW~6551 */
  twobit_lambda( compiled_start_1_40, 231, 0 );
  twobit_setglbl( 232 ); /*  char-set-every~1ayXVW~6552 */
  twobit_lambda( compiled_start_1_41, 234, 0 );
  twobit_setglbl( 235 ); /*  char-set-any~1ayXVW~6553 */
  twobit_lambda( compiled_start_1_42, 237, 0 );
  twobit_setglbl( 238 ); /*  %char-set-unfold!~1ayXVW~6554 */
  twobit_lambda( compiled_start_1_43, 240, 0 );
  twobit_setglbl( 241 ); /*  char-set-unfold~1ayXVW~6555 */
  twobit_lambda( compiled_start_1_44, 243, 0 );
  twobit_setglbl( 244 ); /*  char-set-unfold!~1ayXVW~6556 */
  twobit_lambda( compiled_start_1_45, 246, 0 );
  twobit_setglbl( 49 ); /*  %list->char-set!~1ayXVW~6557 */
  twobit_lambda( compiled_start_1_46, 248, 0 );
  twobit_setglbl( 48 ); /*  char-set~1ayXVW~6558 */
  twobit_lambda( compiled_start_1_47, 250, 0 );
  twobit_setglbl( 47 ); /*  list->char-set~1ayXVW~6559 */
  twobit_lambda( compiled_start_1_48, 252, 0 );
  twobit_setglbl( 46 ); /*  list->char-set!~1ayXVW~6560 */
  twobit_lambda( compiled_start_1_49, 254, 0 );
  twobit_setglbl( 45 ); /*  char-set->list~1ayXVW~6561 */
  twobit_lambda( compiled_start_1_50, 256, 0 );
  twobit_setglbl( 44 ); /*  %string->char-set!~1ayXVW~6562 */
  twobit_lambda( compiled_start_1_51, 258, 0 );
  twobit_setglbl( 43 ); /*  string->char-set~1ayXVW~6563 */
  twobit_lambda( compiled_start_1_52, 260, 0 );
  twobit_setglbl( 42 ); /*  string->char-set!~1ayXVW~6564 */
  twobit_lambda( compiled_start_1_53, 262, 0 );
  twobit_setglbl( 41 ); /*  char-set->string~1ayXVW~6565 */
  twobit_lambda( compiled_start_1_54, 264, 0 );
  twobit_setglbl( 40 ); /*  %ucs-range->char-set!~1ayXVW~6566 */
  twobit_lambda( compiled_start_1_55, 266, 0 );
  twobit_setglbl( 39 ); /*  ucs-range->char-set~1ayXVW~6567 */
  twobit_lambda( compiled_start_1_56, 268, 0 );
  twobit_setglbl( 38 ); /*  ucs-range->char-set!~1ayXVW~6568 */
  twobit_lambda( compiled_start_1_57, 270, 0 );
  twobit_setglbl( 37 ); /*  %char-set-filter!~1ayXVW~6569 */
  twobit_lambda( compiled_start_1_58, 272, 0 );
  twobit_setglbl( 36 ); /*  char-set-filter~1ayXVW~6570 */
  twobit_lambda( compiled_start_1_59, 274, 0 );
  twobit_setglbl( 35 ); /*  char-set-filter!~1ayXVW~6571 */
  twobit_lambda( compiled_start_1_60, 276, 0 );
  twobit_setglbl( 34 ); /*  ->char-set~1ayXVW~6572 */
  twobit_lambda( compiled_start_1_61, 278, 0 );
  twobit_setglbl( 33 ); /*  %string-iter~1ayXVW~6573 */
  twobit_lambda( compiled_start_1_62, 280, 0 );
  twobit_setglbl( 32 ); /*  %char-set-algebra~1ayXVW~6574 */
  twobit_lambda( compiled_start_1_63, 282, 0 );
  twobit_setglbl( 31 ); /*  char-set-complement~1ayXVW~6575 */
  twobit_lambda( compiled_start_1_64, 284, 0 );
  twobit_setglbl( 30 ); /*  char-set-complement!~1ayXVW~6576 */
  twobit_lambda( compiled_start_1_65, 286, 0 );
  twobit_setglbl( 29 ); /*  char-set-union!~1ayXVW~6577 */
  twobit_lambda( compiled_start_1_66, 288, 0 );
  twobit_setglbl( 28 ); /*  char-set-union~1ayXVW~6578 */
  twobit_lambda( compiled_start_1_67, 290, 0 );
  twobit_setglbl( 27 ); /*  char-set-intersection!~1ayXVW~6579 */
  twobit_lambda( compiled_start_1_68, 292, 0 );
  twobit_setglbl( 26 ); /*  char-set-intersection~1ayXVW~6580 */
  twobit_lambda( compiled_start_1_69, 294, 0 );
  twobit_setglbl( 25 ); /*  char-set-difference!~1ayXVW~6581 */
  twobit_lambda( compiled_start_1_70, 296, 0 );
  twobit_setglbl( 24 ); /*  char-set-difference~1ayXVW~6582 */
  twobit_lambda( compiled_start_1_71, 298, 0 );
  twobit_setglbl( 23 ); /*  char-set-xor!~1ayXVW~6583 */
  twobit_lambda( compiled_start_1_72, 300, 0 );
  twobit_setglbl( 22 ); /*  char-set-xor~1ayXVW~6584 */
  twobit_lambda( compiled_start_1_73, 302, 0 );
  twobit_setglbl( 21 ); /*  %char-set-diff+intersection!~1ayXVW~6585 */
  twobit_lambda( compiled_start_1_74, 304, 0 );
  twobit_setglbl( 20 ); /*  char-set-diff+intersection!~1ayXVW~6586 */
  twobit_lambda( compiled_start_1_75, 306, 0 );
  twobit_setglbl( 19 ); /*  char-set-diff+intersection~1ayXVW~6587 */
  twobit_global( 48 ); /*  char-set~1ayXVW~6558 */
  twobit_setrtn( 1431, compiled_block_1_1431 );
  twobit_invoke( 0 );
  twobit_label( 1431, compiled_block_1_1431 );
  twobit_load( 0, 0 );
  twobit_setglbl( 18 ); /*  char-set:empty~1ayXVW~6588 */
  twobit_global( 18 ); /*  char-set:empty~1ayXVW~6588 */
  twobit_setreg( 1 );
  twobit_global( 31 ); /*  char-set-complement~1ayXVW~6575 */
  twobit_setrtn( 1432, compiled_block_1_1432 );
  twobit_invoke( 1 );
  twobit_label( 1432, compiled_block_1_1432 );
  twobit_load( 0, 0 );
  twobit_setglbl( 17 ); /*  char-set:full~1ayXVW~6589 */
  twobit_imm_const( fixnum(97) ); /* 97 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(123) ); /* 123 */
  twobit_setreg( 2 );
  twobit_global( 39 ); /*  ucs-range->char-set~1ayXVW~6567 */
  twobit_setrtn( 1433, compiled_block_1_1433 );
  twobit_invoke( 2 );
  twobit_label( 1433, compiled_block_1_1433 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(223) ); /* 223 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(247) ); /* 247 */
  twobit_setreg( 2 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 3 );
  twobit_global( 38 ); /*  ucs-range->char-set!~1ayXVW~6568 */
  twobit_setrtn( 1434, compiled_block_1_1434 );
  twobit_invoke( 4 );
  twobit_label( 1434, compiled_block_1_1434 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(248) ); /* 248 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(256) ); /* 256 */
  twobit_setreg( 2 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 3 );
  twobit_global( 38 ); /*  ucs-range->char-set!~1ayXVW~6568 */
  twobit_setrtn( 1435, compiled_block_1_1435 );
  twobit_invoke( 4 );
  twobit_label( 1435, compiled_block_1_1435 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( fixnum(181) ); /* 181 */
  twobit_setreg( 1 );
  twobit_global( 307 ); /*  %latin1->char~1ayXVW~6513 */
  twobit_setrtn( 1436, compiled_block_1_1436 );
  twobit_invoke( 1 );
  twobit_label( 1436, compiled_block_1_1436 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 308 ); /*  char-set-adjoin!~1ayXVW~6541 */
  twobit_setrtn( 1437, compiled_block_1_1437 );
  twobit_invoke( 2 );
  twobit_label( 1437, compiled_block_1_1437 );
  twobit_load( 0, 0 );
  twobit_setglbl( 16 ); /*  char-set:lower-case~1ayXVW~6590 */
  twobit_imm_const( fixnum(65) ); /* 65 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(91) ); /* 91 */
  twobit_setreg( 2 );
  twobit_global( 39 ); /*  ucs-range->char-set~1ayXVW~6567 */
  twobit_setrtn( 1438, compiled_block_1_1438 );
  twobit_invoke( 2 );
  twobit_label( 1438, compiled_block_1_1438 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(192) ); /* 192 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(215) ); /* 215 */
  twobit_setreg( 2 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 3 );
  twobit_global( 38 ); /*  ucs-range->char-set!~1ayXVW~6568 */
  twobit_setrtn( 1439, compiled_block_1_1439 );
  twobit_invoke( 4 );
  twobit_label( 1439, compiled_block_1_1439 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(216) ); /* 216 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(223) ); /* 223 */
  twobit_setreg( 2 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 3 );
  twobit_global( 38 ); /*  ucs-range->char-set!~1ayXVW~6568 */
  twobit_setrtn( 1440, compiled_block_1_1440 );
  twobit_invoke( 4 );
  twobit_label( 1440, compiled_block_1_1440 );
  twobit_load( 0, 0 );
  twobit_setglbl( 15 ); /*  char-set:upper-case~1ayXVW~6591 */
  twobit_global( 18 ); /*  char-set:empty~1ayXVW~6588 */
  twobit_setglbl( 14 ); /*  char-set:title-case~1ayXVW~6592 */
  twobit_global( 15 ); /*  char-set:upper-case~1ayXVW~6591 */
  twobit_setreg( 1 );
  twobit_global( 16 ); /*  char-set:lower-case~1ayXVW~6590 */
  twobit_setreg( 2 );
  twobit_global( 28 ); /*  char-set-union~1ayXVW~6578 */
  twobit_setrtn( 1441, compiled_block_1_1441 );
  twobit_invoke( 2 );
  twobit_label( 1441, compiled_block_1_1441 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( fixnum(170) ); /* 170 */
  twobit_setreg( 1 );
  twobit_global( 309 ); /*  %latin1->char~1ayXVW~6513 */
  twobit_setrtn( 1442, compiled_block_1_1442 );
  twobit_invoke( 1 );
  twobit_label( 1442, compiled_block_1_1442 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( fixnum(186) ); /* 186 */
  twobit_setreg( 1 );
  twobit_global( 310 ); /*  %latin1->char~1ayXVW~6513 */
  twobit_setrtn( 1443, compiled_block_1_1443 );
  twobit_invoke( 1 );
  twobit_label( 1443, compiled_block_1_1443 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_load( 1, 2 );
  twobit_global( 311 ); /*  char-set-adjoin!~1ayXVW~6541 */
  twobit_setrtn( 1444, compiled_block_1_1444 );
  twobit_invoke( 3 );
  twobit_label( 1444, compiled_block_1_1444 );
  twobit_load( 0, 0 );
  twobit_setglbl( 13 ); /*  char-set:letter~1ayXVW~6593 */
  twobit_const( 312 );
  twobit_setreg( 1 );
  twobit_global( 43 ); /*  string->char-set~1ayXVW~6563 */
  twobit_setrtn( 1445, compiled_block_1_1445 );
  twobit_invoke( 1 );
  twobit_label( 1445, compiled_block_1_1445 );
  twobit_load( 0, 0 );
  twobit_setglbl( 12 ); /*  char-set:digit~1ayXVW~6594 */
  twobit_const( 313 );
  twobit_setreg( 1 );
  twobit_global( 43 ); /*  string->char-set~1ayXVW~6563 */
  twobit_setrtn( 1446, compiled_block_1_1446 );
  twobit_invoke( 1 );
  twobit_label( 1446, compiled_block_1_1446 );
  twobit_load( 0, 0 );
  twobit_setglbl( 11 ); /*  char-set:hex-digit~1ayXVW~6595 */
  twobit_global( 13 ); /*  char-set:letter~1ayXVW~6593 */
  twobit_setreg( 1 );
  twobit_global( 12 ); /*  char-set:digit~1ayXVW~6594 */
  twobit_setreg( 2 );
  twobit_global( 28 ); /*  char-set-union~1ayXVW~6578 */
  twobit_setrtn( 1447, compiled_block_1_1447 );
  twobit_invoke( 2 );
  twobit_label( 1447, compiled_block_1_1447 );
  twobit_load( 0, 0 );
  twobit_setglbl( 10 ); /*  char-set:letter+digit~1ayXVW~6596 */
  twobit_global( 314 ); /*  %latin1->char~1ayXVW~6513 */
  twobit_setreg( 1 );
  twobit_const( 315 );
  twobit_setreg( 2 );
  twobit_global( 316 ); /*  map~1ayXVW~1381 */
  twobit_setrtn( 1448, compiled_block_1_1448 );
  twobit_invoke( 2 );
  twobit_label( 1448, compiled_block_1_1448 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 317 );
  twobit_setreg( 1 );
  twobit_global( 43 ); /*  string->char-set~1ayXVW~6563 */
  twobit_setrtn( 1449, compiled_block_1_1449 );
  twobit_invoke( 1 );
  twobit_label( 1449, compiled_block_1_1449 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 46 ); /*  list->char-set!~1ayXVW~6560 */
  twobit_setrtn( 1450, compiled_block_1_1450 );
  twobit_invoke( 2 );
  twobit_label( 1450, compiled_block_1_1450 );
  twobit_load( 0, 0 );
  twobit_setglbl( 9 ); /*  char-set:punctuation~1ayXVW~6597 */
  twobit_global( 318 ); /*  %latin1->char~1ayXVW~6513 */
  twobit_setreg( 1 );
  twobit_const( 319 );
  twobit_setreg( 2 );
  twobit_global( 320 ); /*  map~1ayXVW~1381 */
  twobit_setrtn( 1451, compiled_block_1_1451 );
  twobit_invoke( 2 );
  twobit_label( 1451, compiled_block_1_1451 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 321 );
  twobit_setreg( 1 );
  twobit_global( 43 ); /*  string->char-set~1ayXVW~6563 */
  twobit_setrtn( 1452, compiled_block_1_1452 );
  twobit_invoke( 1 );
  twobit_label( 1452, compiled_block_1_1452 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 46 ); /*  list->char-set!~1ayXVW~6560 */
  twobit_setrtn( 1453, compiled_block_1_1453 );
  twobit_invoke( 2 );
  twobit_label( 1453, compiled_block_1_1453 );
  twobit_load( 0, 0 );
  twobit_setglbl( 8 ); /*  char-set:symbol~1ayXVW~6598 */
  twobit_global( 10 ); /*  char-set:letter+digit~1ayXVW~6596 */
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  char-set:punctuation~1ayXVW~6597 */
  twobit_setreg( 2 );
  twobit_global( 8 ); /*  char-set:symbol~1ayXVW~6598 */
  twobit_setreg( 3 );
  twobit_global( 28 ); /*  char-set-union~1ayXVW~6578 */
  twobit_setrtn( 1454, compiled_block_1_1454 );
  twobit_invoke( 3 );
  twobit_label( 1454, compiled_block_1_1454 );
  twobit_load( 0, 0 );
  twobit_setglbl( 7 ); /*  char-set:graphic~1ayXVW~6599 */
  twobit_global( 322 ); /*  %latin1->char~1ayXVW~6513 */
  twobit_setreg( 1 );
  twobit_const( 323 );
  twobit_setreg( 2 );
  twobit_global( 324 ); /*  map~1ayXVW~1381 */
  twobit_setrtn( 1455, compiled_block_1_1455 );
  twobit_invoke( 2 );
  twobit_label( 1455, compiled_block_1_1455 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 47 ); /*  list->char-set~1ayXVW~6559 */
  twobit_setrtn( 1456, compiled_block_1_1456 );
  twobit_invoke( 1 );
  twobit_label( 1456, compiled_block_1_1456 );
  twobit_load( 0, 0 );
  twobit_setglbl( 6 ); /*  char-set:whitespace~1ayXVW~6600 */
  twobit_global( 6 ); /*  char-set:whitespace~1ayXVW~6600 */
  twobit_setreg( 1 );
  twobit_global( 7 ); /*  char-set:graphic~1ayXVW~6599 */
  twobit_setreg( 2 );
  twobit_global( 28 ); /*  char-set-union~1ayXVW~6578 */
  twobit_setrtn( 1457, compiled_block_1_1457 );
  twobit_invoke( 2 );
  twobit_label( 1457, compiled_block_1_1457 );
  twobit_load( 0, 0 );
  twobit_setglbl( 5 ); /*  char-set:printing~1ayXVW~6601 */
  twobit_global( 325 ); /*  %latin1->char~1ayXVW~6513 */
  twobit_setreg( 1 );
  twobit_const( 326 );
  twobit_setreg( 2 );
  twobit_global( 327 ); /*  map~1ayXVW~1381 */
  twobit_setrtn( 1458, compiled_block_1_1458 );
  twobit_invoke( 2 );
  twobit_label( 1458, compiled_block_1_1458 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 47 ); /*  list->char-set~1ayXVW~6559 */
  twobit_setrtn( 1459, compiled_block_1_1459 );
  twobit_invoke( 1 );
  twobit_label( 1459, compiled_block_1_1459 );
  twobit_load( 0, 0 );
  twobit_setglbl( 4 ); /*  char-set:blank~1ayXVW~6602 */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(32) ); /* 32 */
  twobit_setreg( 2 );
  twobit_global( 39 ); /*  ucs-range->char-set~1ayXVW~6567 */
  twobit_setrtn( 1460, compiled_block_1_1460 );
  twobit_invoke( 2 );
  twobit_label( 1460, compiled_block_1_1460 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(127) ); /* 127 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(160) ); /* 160 */
  twobit_setreg( 2 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 3 );
  twobit_global( 38 ); /*  ucs-range->char-set!~1ayXVW~6568 */
  twobit_setrtn( 1461, compiled_block_1_1461 );
  twobit_invoke( 4 );
  twobit_label( 1461, compiled_block_1_1461 );
  twobit_load( 0, 0 );
  twobit_setglbl( 3 ); /*  char-set:iso-control~1ayXVW~6603 */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(128) ); /* 128 */
  twobit_setreg( 2 );
  twobit_global( 39 ); /*  ucs-range->char-set~1ayXVW~6567 */
  twobit_setrtn( 1462, compiled_block_1_1462 );
  twobit_invoke( 2 );
  twobit_label( 1462, compiled_block_1_1462 );
  twobit_load( 0, 0 );
  twobit_setglbl( 2 ); /*  char-set:ascii~1ayXVW~6604 */
  twobit_global( 328 ); /* values */
  twobit_pop( 2 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_movereg( 2, 4 );
  twobit_movereg( 1, 3 );
  twobit_global( 1 ); /* assertion-violation */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* apply */
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 1, 0, 0, 1023, compiled_block_1_1023 );
  twobit_reg( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* substring */
  twobit_invoke( 3 );
  twobit_label( 1023, compiled_block_1_1023 );
  twobit_trap( 1, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_6( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1026, compiled_block_1_1026 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1028, compiled_block_1_1028 ); /* internal:branchf-null? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /*  char-set?~1ayXVW~6491 */
  twobit_setrtn( 1029, compiled_block_1_1029 );
  twobit_invoke( 1 );
  twobit_label( 1029, compiled_block_1_1029 );
  twobit_load( 0, 0 );
  twobit_branchf( 1031, compiled_block_1_1031 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  char-set:s~1ayXVW~6492 */
  twobit_setrtn( 1032, compiled_block_1_1032 );
  twobit_invoke( 1 );
  twobit_label( 1032, compiled_block_1_1032 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  %string-copy~1ayXVW~6515 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1031, compiled_block_1_1031 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_load( 3, 1 );
  twobit_global( 5 ); /*  error~1ayXVW~6485 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1028, compiled_block_1_1028 );
  twobit_movereg( 1, 3 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  error~1ayXVW~6485 */
  twobit_invoke( 3 );
  twobit_label( 1026, compiled_block_1_1026 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_global( 7 ); /*  %latin1->char~1ayXVW~6513 */
  twobit_setrtn( 1036, compiled_block_1_1036 );
  twobit_invoke( 1 );
  twobit_label( 1036, compiled_block_1_1036 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(256) ); /* 256 */
  twobit_op2_799( 4 ); /* make-ustring */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_7( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_163, 3, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_163( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  char-set?~1ayXVW~6491 */
  twobit_setrtn( 1037, compiled_block_1_1037 );
  twobit_invoke( 1 );
  twobit_label( 1037, compiled_block_1_1037 );
  twobit_load( 0, 0 );
  twobit_branchf( 1039, compiled_block_1_1039 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  char-set:s~1ayXVW~6492 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1039, compiled_block_1_1039 );
  twobit_load( 2, 1 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /*  error~1ayXVW~6485 */
  twobit_setrtn( 1041, compiled_block_1_1041 );
  twobit_invoke( 3 );
  twobit_label( 1041, compiled_block_1_1041 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_8( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_reg_op1_check_651(reg(2),1044,compiled_block_1_1044); /* internal:check-fixnum? with (2 1 0) */
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 2, 1, 0, 1044, compiled_block_1_1044 );
  twobit_reg( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg_op2_check_661(reg(2),reg(4),1044,compiled_block_1_1044); /* internal:check-range with (2 1 0) */
  twobit_reg( 1 );
  twobit_op2_802( 2 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %char->latin1~1ayXVW~6514 */
  twobit_setrtn( 1045, compiled_block_1_1045 );
  twobit_invoke( 1 );
  twobit_label( 1045, compiled_block_1_1045 );
  twobit_load( 0, 0 );
  twobit_op1_31( 162, compiled_temp_1_162 ); /* zero? */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1044, compiled_block_1_1044 );
  twobit_trap( 1, 2, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_9( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  si=0?~1ayXVW~6518 */
  twobit_setrtn( 1046, compiled_block_1_1046 );
  twobit_invoke( 2 );
  twobit_label( 1046, compiled_block_1_1046 );
  twobit_load( 0, 0 );
  twobit_op1_9(); /* not */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_10( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op1_check_651(reg(2),1049,compiled_block_1_1049); /* internal:check-fixnum? with (2 1 0) */
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 2, 1, 0, 1049, compiled_block_1_1049 );
  twobit_reg( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg_op2_check_661(reg(2),reg(4),1049,compiled_block_1_1049); /* internal:check-range with (2 1 0) */
  twobit_reg( 1 );
  twobit_op2_802( 2 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %char->latin1~1ayXVW~6514 */
  twobit_invoke( 1 );
  twobit_label( 1049, compiled_block_1_1049 );
  twobit_trap( 1, 2, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_11( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_global( 1 ); /*  c0~1ayXVW~6520 */
  twobit_setreg( 4 );
  twobit_reg_op1_check_651(reg(2),1051,compiled_block_1_1051); /* internal:check-fixnum? with (4 2 1) */
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 4, 2, 1, 1051, compiled_block_1_1051 );
  twobit_reg( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_reg_op2_check_661(reg(2),reg(3),1051,compiled_block_1_1051); /* internal:check-range with (4 2 1) */
  twobit_reg( 4 );
  twobit_op1_36(); /* char? */
  twobit_check( 4, 2, 1, 1051, compiled_block_1_1051 );
  twobit_reg( 1 );
  twobit_op3_803( 2, 4 ); /* ustring-set!:trusted */
  twobit_return();
  twobit_label( 1051, compiled_block_1_1051 );
  twobit_trap( 1, 2, 4, 61 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_12( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_global( 1 ); /*  c1~1ayXVW~6521 */
  twobit_setreg( 4 );
  twobit_reg_op1_check_651(reg(2),1052,compiled_block_1_1052); /* internal:check-fixnum? with (4 2 1) */
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 4, 2, 1, 1052, compiled_block_1_1052 );
  twobit_reg( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_reg_op2_check_661(reg(2),reg(3),1052,compiled_block_1_1052); /* internal:check-range with (4 2 1) */
  twobit_reg( 4 );
  twobit_op1_36(); /* char? */
  twobit_check( 4, 2, 1, 1052, compiled_block_1_1052 );
  twobit_reg( 1 );
  twobit_op3_803( 2, 4 ); /* ustring-set!:trusted */
  twobit_return();
  twobit_label( 1052, compiled_block_1_1052 );
  twobit_trap( 1, 2, 4, 61 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_13( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /*  %latin1->char~1ayXVW~6513 */
  twobit_setrtn( 1053, compiled_block_1_1053 );
  twobit_invoke( 1 );
  twobit_label( 1053, compiled_block_1_1053 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_load( 2, 1 );
  twobit_check( 4, 2, 3, 1054, compiled_block_1_1054 );
  twobit_stack( 2 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 4, 2, 3, 1054, compiled_block_1_1054 );
  twobit_stack( 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 2 );
  twobit_check( 4, 2, 3, 1054, compiled_block_1_1054 );
  twobit_stack( 1 );
  twobit_reg_op2imm_check_660(RESULT,fixnum(0),1054,compiled_block_1_1054); /* internal:check->=:fix:fix/imm with (4 2 3) */
  twobit_reg( 4 );
  twobit_op1_36(); /* char? */
  twobit_check( 4, 2, 3, 1054, compiled_block_1_1054 );
  twobit_load( 3, 1 );
  twobit_stack( 2 );
  twobit_op3_803( 3, 4 ); /* ustring-set!:trusted */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1054, compiled_block_1_1054 );
  twobit_trap( 3, 2, 4, 61 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_14( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_62( 3, 161, compiled_temp_1_161 ); /* - */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  setv!~1ayXVW~6525 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_15( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_612( 160, compiled_temp_1_160, 1057, compiled_block_1_1057 ); /* internal:branchf-zero? */
  twobit_global( 1 ); /*  %set0!~1ayXVW~6523 */
  twobit_invoke( 2 );
  twobit_label( 1057, compiled_block_1_1057 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_16( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_612( 159, compiled_temp_1_159, 1060, compiled_block_1_1060 ); /* internal:branchf-zero? */
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1060, compiled_block_1_1060 );
  twobit_global( 1 ); /*  %set1!~1ayXVW~6524 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_17( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_612( 158, compiled_temp_1_158, 1063, compiled_block_1_1063 ); /* internal:branchf-zero? */
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1063, compiled_block_1_1063 );
  twobit_global( 1 ); /*  %set0!~1ayXVW~6523 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_18( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_612( 156, compiled_temp_1_156, 1066, compiled_block_1_1066 ); /* internal:branchf-zero? */
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1066, compiled_block_1_1066 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_global( 1 ); /*  si~1ayXVW~6522 */
  twobit_setrtn( 1067, compiled_block_1_1067 );
  twobit_invoke( 2 );
  twobit_label( 1067, compiled_block_1_1067 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_62( 4, 157, compiled_temp_1_157 ); /* - */
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 2 ); /*  setv!~1ayXVW~6525 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_19( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  char-set-copy~1ayXVW~6531 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1069, compiled_block_1_1069 );
  twobit_invoke( 2 );
  twobit_label( 1069, compiled_block_1_1069 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  %string-copy~1ayXVW~6515 */
  twobit_setrtn( 1070, compiled_block_1_1070 );
  twobit_invoke( 1 );
  twobit_label( 1070, compiled_block_1_1070 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  make-char-set~1ayXVW~6490 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_20( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_reg( 1 );
  twobit_op1_10(); /* null? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1073, compiled_block_1_1073 );
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1073, compiled_block_1_1073 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_reg_op1_check_652(reg(1),1074,compiled_block_1_1074); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /*  char-set=~1ayXVW~6532 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1075, compiled_block_1_1075 );
  twobit_invoke( 2 );
  twobit_label( 1075, compiled_block_1_1075 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_store( 1, 2 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_155, 5, 2 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1074, compiled_block_1_1074 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_155( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_9(); /* not */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_branchf( 1077, compiled_block_1_1077 );
  twobit_reg( 3 );
  twobit_return();
  twobit_label( 1077, compiled_block_1_1077 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 4 );
  twobit_check( 1, 0, 0, 1078, compiled_block_1_1078 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  char-set=~1ayXVW~6532 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1079, compiled_block_1_1079 );
  twobit_invoke( 2 );
  twobit_label( 1079, compiled_block_1_1079 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* string=? */
  twobit_setrtn( 1080, compiled_block_1_1080 );
  twobit_invoke( 2 );
  twobit_label( 1080, compiled_block_1_1080 );
  twobit_load( 0, 0 );
  twobit_branchf( 1082, compiled_block_1_1082 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1082, compiled_block_1_1082 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1078, compiled_block_1_1078 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_21( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_reg( 1 );
  twobit_op1_10(); /* null? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1086, compiled_block_1_1086 );
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1086, compiled_block_1_1086 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_reg_op1_check_652(reg(1),1087,compiled_block_1_1087); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /*  char-set<=~1ayXVW~6533 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1088, compiled_block_1_1088 );
  twobit_invoke( 2 );
  twobit_label( 1088, compiled_block_1_1088 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_load( 2, 1 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_150, 5, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1087, compiled_block_1_1087 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_150( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_9(); /* not */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_branchf( 1090, compiled_block_1_1090 );
  twobit_reg( 3 );
  twobit_return();
  twobit_label( 1090, compiled_block_1_1090 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_reg( 4 );
  twobit_check( 2, 0, 0, 1091, compiled_block_1_1091 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  char-set<=~1ayXVW~6533 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1092, compiled_block_1_1092 );
  twobit_invoke( 2 );
  twobit_label( 1092, compiled_block_1_1092 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_branchf_624( 4, 1094, compiled_block_1_1094 ); /* internal:branchf-eq? */
  twobit_movereg( 3, 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_movereg( 4, 1 );
  twobit_reg( 3 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1094, compiled_block_1_1094 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_151, 5, 4 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(255) ); /* 255 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1091, compiled_block_1_1091 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_151( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(0), 152, compiled_temp_1_152, 1097, compiled_block_1_1097 ); /* internal:branchf-</imm */
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 1097, compiled_block_1_1097 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  si~1ayXVW~6522 */
  twobit_setrtn( 1099, compiled_block_1_1099 );
  twobit_invoke( 2 );
  twobit_label( 1099, compiled_block_1_1099 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  si~1ayXVW~6522 */
  twobit_setrtn( 1100, compiled_block_1_1100 );
  twobit_invoke( 2 );
  twobit_label( 1100, compiled_block_1_1100 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_branchf_622( 4, 153, compiled_temp_1_153, 1102, compiled_block_1_1102 ); /* internal:branchf-<= */
  twobit_stack( 1 );
  twobit_op2imm_131( fixnum(1), 154, compiled_temp_1_154 ); /* - */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1102, compiled_block_1_1102 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_22( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_reg( 2 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1107, compiled_block_1_1107 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_67( 3, 139, compiled_temp_1_139 ); /* <= */
  twobit_skip( 1106, compiled_block_1_1106 );
  twobit_label( 1107, compiled_block_1_1107 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1106, compiled_block_1_1106 );
  twobit_branchf( 1109, compiled_block_1_1109 );
  twobit_reg( 4 );
  twobit_check( 2, 0, 0, 1110, compiled_block_1_1110 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 1108, compiled_block_1_1108 );
  twobit_label( 1109, compiled_block_1_1109 );
  twobit_imm_const( fixnum(4194304) ); /* 4194304 */
  twobit_label( 1108, compiled_block_1_1108 );
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_612( 140, compiled_temp_1_140, 1112, compiled_block_1_1112 ); /* internal:branchf-zero? */
  twobit_imm_const( fixnum(4194304) ); /* 4194304 */
  twobit_skip( 1111, compiled_block_1_1111 );
  twobit_label( 1112, compiled_block_1_1112 );
  twobit_reg( 3 );
  twobit_label( 1111, compiled_block_1_1111 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_global( 1 ); /*  char-set-hash~1ayXVW~6534 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1113, compiled_block_1_1113 );
  twobit_invoke( 2 );
  twobit_label( 1113, compiled_block_1_1113 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_141, 5, 2 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(65536) ); /* 65536 */
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_setrtn( 1117, compiled_block_1_1117 );
  twobit_invoke( 1 );
  twobit_label( 1117, compiled_block_1_1117 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_142, 7, 4 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(255) ); /* 255 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1110, compiled_block_1_1110 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_141( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_621( 4, 147, compiled_temp_1_147, 1115, compiled_block_1_1115 ); /* internal:branchf->= */
  twobit_reg( 1 );
  twobit_op2imm_131( fixnum(1), 148, compiled_temp_1_148 ); /* - */
  twobit_return();
  twobit_label( 1115, compiled_block_1_1115 );
  twobit_reg( 1 );
  twobit_op2_61( 1, 149, compiled_temp_1_149 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_142( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(0), 143, compiled_temp_1_143, 1119, compiled_block_1_1119 ); /* internal:branchf-</imm */
  twobit_movereg( 2, 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /* modulo */
  twobit_invoke( 2 );
  twobit_label( 1119, compiled_block_1_1119 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_reg( 1 );
  twobit_op2imm_131( fixnum(1), 144, compiled_temp_1_144 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  si=0?~1ayXVW~6518 */
  twobit_setrtn( 1121, compiled_block_1_1121 );
  twobit_invoke( 2 );
  twobit_label( 1121, compiled_block_1_1121 );
  twobit_load( 0, 0 );
  twobit_branchf( 1123, compiled_block_1_1123 );
  twobit_stack( 1 );
  twobit_skip( 1122, compiled_block_1_1122 );
  twobit_label( 1123, compiled_block_1_1123 );
  twobit_load( 4, 1 );
  twobit_imm_const( fixnum(37) ); /* 37 */
  twobit_op2_63( 4, 145, compiled_temp_1_145 ); /* * */
  twobit_load( 2, 2 );
  twobit_op2_61( 2, 146, compiled_temp_1_146 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* bitwise-and */
  twobit_setrtn( 1124, compiled_block_1_1124 );
  twobit_invoke( 2 );
  twobit_label( 1124, compiled_block_1_1124 );
  twobit_load( 0, 0 );
  twobit_label( 1122, compiled_block_1_1122 );
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_23( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  char-set-contains?~1ayXVW~6535 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1127, compiled_block_1_1127 );
  twobit_invoke( 2 );
  twobit_label( 1127, compiled_block_1_1127 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  %char->latin1~1ayXVW~6514 */
  twobit_setrtn( 1128, compiled_block_1_1128 );
  twobit_invoke( 1 );
  twobit_label( 1128, compiled_block_1_1128 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 4 ); /*  si=1?~1ayXVW~6519 */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_24( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  char-set-size~1ayXVW~6536 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1130, compiled_block_1_1130 );
  twobit_invoke( 2 );
  twobit_label( 1130, compiled_block_1_1130 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_135, 5, 2 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(255) ); /* 255 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 0 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_135( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(0), 136, compiled_temp_1_136, 1132, compiled_block_1_1132 ); /* internal:branchf-</imm */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1132, compiled_block_1_1132 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_movereg( 1, 2 );
  twobit_reg( 1 );
  twobit_op2imm_131( fixnum(1), 137, compiled_temp_1_137 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  si~1ayXVW~6522 */
  twobit_setrtn( 1133, compiled_block_1_1133 );
  twobit_invoke( 2 );
  twobit_label( 1133, compiled_block_1_1133 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_stack( 2 );
  twobit_op2_61( 4, 138, compiled_temp_1_138 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_25( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  char-set-count~1ayXVW~6537 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1136, compiled_block_1_1136 );
  twobit_invoke( 2 );
  twobit_label( 1136, compiled_block_1_1136 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_131, 5, 3 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(255) ); /* 255 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_131( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(0), 132, compiled_temp_1_132, 1138, compiled_block_1_1138 ); /* internal:branchf-</imm */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1138, compiled_block_1_1138 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 1, 2 );
  twobit_reg( 1 );
  twobit_op2imm_131( fixnum(1), 133, compiled_temp_1_133 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  si=1?~1ayXVW~6519 */
  twobit_setrtn( 1139, compiled_block_1_1139 );
  twobit_invoke( 2 );
  twobit_label( 1139, compiled_block_1_1139 );
  twobit_load( 0, 0 );
  twobit_branchf( 1141, compiled_block_1_1141 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  %latin1->char~1ayXVW~6513 */
  twobit_setrtn( 1142, compiled_block_1_1142 );
  twobit_invoke( 1 );
  twobit_label( 1142, compiled_block_1_1142 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1143, compiled_block_1_1143 );
  twobit_invoke( 1 );
  twobit_label( 1143, compiled_block_1_1143 );
  twobit_load( 0, 0 );
  twobit_skip( 1140, compiled_block_1_1140 );
  twobit_label( 1141, compiled_block_1_1141 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1140, compiled_block_1_1140 );
  twobit_branchf( 1145, compiled_block_1_1145 );
  twobit_stack( 2 );
  twobit_op2imm_130( fixnum(1), 134, compiled_temp_1_134 ); /* + */
  twobit_skip( 1144, compiled_block_1_1144 );
  twobit_label( 1145, compiled_block_1_1145 );
  twobit_stack( 2 );
  twobit_label( 1144, compiled_block_1_1144 );
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_26( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 4, 1 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1148, compiled_block_1_1148 );
  twobit_invoke( 2 );
  twobit_label( 1148, compiled_block_1_1148 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  %string-copy~1ayXVW~6515 */
  twobit_setrtn( 1149, compiled_block_1_1149 );
  twobit_invoke( 1 );
  twobit_label( 1149, compiled_block_1_1149 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 2, 1 );
  twobit_store( 2, 3 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_130, 4, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_global( 5 ); /*  for-each~1ayXVW~1382 */
  twobit_setrtn( 1152, compiled_block_1_1152 );
  twobit_invoke( 2 );
  twobit_label( 1152, compiled_block_1_1152 );
  twobit_load( 0, 0 );
  twobit_load( 1, 4 );
  twobit_global( 6 ); /*  make-char-set~1ayXVW~6490 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_130( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  %char->latin1~1ayXVW~6514 */
  twobit_setrtn( 1150, compiled_block_1_1150 );
  twobit_invoke( 1 );
  twobit_label( 1150, compiled_block_1_1150 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_pop( 0 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_27( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 3, 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1154, compiled_block_1_1154 );
  twobit_invoke( 2 );
  twobit_label( 1154, compiled_block_1_1154 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_store( 2, 3 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_129, 3, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_global( 4 ); /*  for-each~1ayXVW~1382 */
  twobit_setrtn( 1157, compiled_block_1_1157 );
  twobit_invoke( 2 );
  twobit_label( 1157, compiled_block_1_1157 );
  twobit_load( 0, 0 );
  twobit_stack( 4 );
  twobit_pop( 4 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_129( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  %char->latin1~1ayXVW~6514 */
  twobit_setrtn( 1155, compiled_block_1_1155 );
  twobit_invoke( 1 );
  twobit_label( 1155, compiled_block_1_1155 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_pop( 0 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_28( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_movereg( 1, 3 );
  twobit_movereg( 2, 4 );
  twobit_global( 1 ); /*  %set1!~1ayXVW~6524 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  char-set-adjoin~1ayXVW~6540 */
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  %set-char-set~1ayXVW~6538 */
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_29( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_movereg( 1, 3 );
  twobit_movereg( 2, 4 );
  twobit_global( 1 ); /*  %set1!~1ayXVW~6524 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  char-set-adjoin!~1ayXVW~6541 */
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  %set-char-set!~1ayXVW~6539 */
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_30( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_movereg( 1, 3 );
  twobit_movereg( 2, 4 );
  twobit_global( 1 ); /*  %set0!~1ayXVW~6523 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  char-set-delete~1ayXVW~6542 */
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  %set-char-set~1ayXVW~6538 */
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_31( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_movereg( 1, 3 );
  twobit_movereg( 2, 4 );
  twobit_global( 1 ); /*  %set0!~1ayXVW~6523 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  char-set-delete!~1ayXVW~6543 */
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  %set-char-set!~1ayXVW~6539 */
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_32( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_global( 1 ); /*  char-set-cursor~1ayXVW~6544 */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(256) ); /* 256 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set-cursor-next~1ayXVW~6548 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_33( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_132( fixnum(0), 128, compiled_temp_1_128 ); /* < */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_34( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  %latin1->char~1ayXVW~6513 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_35( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_global( 1 ); /*  char-set-cursor-next~1ayXVW~6547 */
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  %char-set-cursor-next~1ayXVW~6548 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_36( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_global( 1 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1165, compiled_block_1_1165 );
  twobit_invoke( 2 );
  twobit_label( 1165, compiled_block_1_1165 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_store( 1, 2 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_125, 4, 2 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_125( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op2imm_131( fixnum(1), 126, compiled_temp_1_126 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_635( fixnum(0), 127, compiled_temp_1_127, 1167, compiled_block_1_1167 ); /* internal:branchf-</imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1166, compiled_block_1_1166 );
  twobit_label( 1167, compiled_block_1_1167 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 1 ); /*  si=1?~1ayXVW~6519 */
  twobit_setrtn( 1168, compiled_block_1_1168 );
  twobit_invoke( 2 );
  twobit_label( 1168, compiled_block_1_1168 );
  twobit_load( 0, 0 );
  twobit_label( 1166, compiled_block_1_1166 );
  twobit_branchf( 1170, compiled_block_1_1170 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1170, compiled_block_1_1170 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_37( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  char-set-for-each~1ayXVW~6549 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1173, compiled_block_1_1173 );
  twobit_invoke( 2 );
  twobit_label( 1173, compiled_block_1_1173 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_122, 5, 3 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(255) ); /* 255 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_122( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_637( fixnum(0), 123, compiled_temp_1_123, 1175, compiled_block_1_1175 ); /* internal:branchf->=/imm */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  si=1?~1ayXVW~6519 */
  twobit_setrtn( 1176, compiled_block_1_1176 );
  twobit_invoke( 2 );
  twobit_label( 1176, compiled_block_1_1176 );
  twobit_load( 0, 0 );
  twobit_branchf( 1178, compiled_block_1_1178 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  %latin1->char~1ayXVW~6513 */
  twobit_setrtn( 1179, compiled_block_1_1179 );
  twobit_invoke( 1 );
  twobit_label( 1179, compiled_block_1_1179 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1180, compiled_block_1_1180 );
  twobit_invoke( 1 );
  twobit_label( 1180, compiled_block_1_1180 );
  twobit_load( 0, 0 );
  twobit_skip( 1177, compiled_block_1_1177 );
  twobit_label( 1178, compiled_block_1_1178 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 1177, compiled_block_1_1177 );
  twobit_stack( 1 );
  twobit_op2imm_131( fixnum(1), 124, compiled_temp_1_124 ); /* - */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1175, compiled_block_1_1175 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_38( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  char-set-map~1ayXVW~6550 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1183, compiled_block_1_1183 );
  twobit_invoke( 2 );
  twobit_label( 1183, compiled_block_1_1183 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_global( 3 ); /*  c0~1ayXVW~6520 */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(256) ); /* 256 */
  twobit_op2_799( 3 ); /* make-ustring */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_global( 4 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_119, 6, 4 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(255) ); /* 255 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1194, compiled_block_1_1194 );
  twobit_invoke( 1 );
  twobit_label( 1194, compiled_block_1_1194 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_global( 7 ); /*  make-char-set~1ayXVW~6490 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_119( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_637( fixnum(0), 120, compiled_temp_1_120, 1185, compiled_block_1_1185 ); /* internal:branchf->=/imm */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  si=1?~1ayXVW~6519 */
  twobit_setrtn( 1186, compiled_block_1_1186 );
  twobit_invoke( 2 );
  twobit_label( 1186, compiled_block_1_1186 );
  twobit_load( 0, 0 );
  twobit_branchf( 1188, compiled_block_1_1188 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  %latin1->char~1ayXVW~6513 */
  twobit_setrtn( 1189, compiled_block_1_1189 );
  twobit_invoke( 1 );
  twobit_label( 1189, compiled_block_1_1189 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1190, compiled_block_1_1190 );
  twobit_invoke( 1 );
  twobit_label( 1190, compiled_block_1_1190 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  %char->latin1~1ayXVW~6514 */
  twobit_setrtn( 1191, compiled_block_1_1191 );
  twobit_invoke( 1 );
  twobit_label( 1191, compiled_block_1_1191 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  %set1!~1ayXVW~6524 */
  twobit_setrtn( 1192, compiled_block_1_1192 );
  twobit_invoke( 2 );
  twobit_label( 1192, compiled_block_1_1192 );
  twobit_load( 0, 0 );
  twobit_skip( 1187, compiled_block_1_1187 );
  twobit_label( 1188, compiled_block_1_1188 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 1187, compiled_block_1_1187 );
  twobit_stack( 1 );
  twobit_op2imm_131( fixnum(1), 121, compiled_temp_1_121 ); /* - */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1185, compiled_block_1_1185 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_39( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /*  char-set-fold~1ayXVW~6551 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1196, compiled_block_1_1196 );
  twobit_invoke( 2 );
  twobit_label( 1196, compiled_block_1_1196 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_116, 5, 3 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(255) ); /* 255 */
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_116( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(0), 117, compiled_temp_1_117, 1198, compiled_block_1_1198 ); /* internal:branchf-</imm */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1198, compiled_block_1_1198 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_reg( 1 );
  twobit_op2imm_131( fixnum(1), 118, compiled_temp_1_118 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  si=0?~1ayXVW~6518 */
  twobit_setrtn( 1199, compiled_block_1_1199 );
  twobit_invoke( 2 );
  twobit_label( 1199, compiled_block_1_1199 );
  twobit_load( 0, 0 );
  twobit_branchf( 1201, compiled_block_1_1201 );
  twobit_stack( 1 );
  twobit_skip( 1200, compiled_block_1_1200 );
  twobit_label( 1201, compiled_block_1_1201 );
  twobit_load( 1, 2 );
  twobit_global( 2 ); /*  %latin1->char~1ayXVW~6513 */
  twobit_setrtn( 1202, compiled_block_1_1202 );
  twobit_invoke( 1 );
  twobit_label( 1202, compiled_block_1_1202 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1203, compiled_block_1_1203 );
  twobit_invoke( 2 );
  twobit_label( 1203, compiled_block_1_1203 );
  twobit_load( 0, 0 );
  twobit_label( 1200, compiled_block_1_1200 );
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_40( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  char-set-every~1ayXVW~6552 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1206, compiled_block_1_1206 );
  twobit_invoke( 2 );
  twobit_label( 1206, compiled_block_1_1206 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_113, 5, 3 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(255) ); /* 255 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_113( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_132( fixnum(0), 114, compiled_temp_1_114 ); /* < */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1208, compiled_block_1_1208 );
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1208, compiled_block_1_1208 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  si=0?~1ayXVW~6518 */
  twobit_setrtn( 1209, compiled_block_1_1209 );
  twobit_invoke( 2 );
  twobit_label( 1209, compiled_block_1_1209 );
  twobit_load( 0, 0 );
  twobit_branchf( 1211, compiled_block_1_1211 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1210, compiled_block_1_1210 );
  twobit_label( 1211, compiled_block_1_1211 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  %latin1->char~1ayXVW~6513 */
  twobit_setrtn( 1212, compiled_block_1_1212 );
  twobit_invoke( 1 );
  twobit_label( 1212, compiled_block_1_1212 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1213, compiled_block_1_1213 );
  twobit_invoke( 1 );
  twobit_label( 1213, compiled_block_1_1213 );
  twobit_load( 0, 0 );
  twobit_label( 1210, compiled_block_1_1210 );
  twobit_branchf( 1215, compiled_block_1_1215 );
  twobit_stack( 1 );
  twobit_op2imm_131( fixnum(1), 115, compiled_temp_1_115 ); /* - */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1215, compiled_block_1_1215 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_41( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  char-set-any~1ayXVW~6553 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1218, compiled_block_1_1218 );
  twobit_invoke( 2 );
  twobit_label( 1218, compiled_block_1_1218 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_110, 5, 3 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(255) ); /* 255 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_110( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_637( fixnum(0), 111, compiled_temp_1_111, 1220, compiled_block_1_1220 ); /* internal:branchf->=/imm */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  si=1?~1ayXVW~6519 */
  twobit_setrtn( 1221, compiled_block_1_1221 );
  twobit_invoke( 2 );
  twobit_label( 1221, compiled_block_1_1221 );
  twobit_load( 0, 0 );
  twobit_branchf( 1223, compiled_block_1_1223 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  %latin1->char~1ayXVW~6513 */
  twobit_setrtn( 1224, compiled_block_1_1224 );
  twobit_invoke( 1 );
  twobit_label( 1224, compiled_block_1_1224 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1225, compiled_block_1_1225 );
  twobit_invoke( 1 );
  twobit_label( 1225, compiled_block_1_1225 );
  twobit_load( 0, 0 );
  twobit_skip( 1222, compiled_block_1_1222 );
  twobit_label( 1223, compiled_block_1_1223 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1222, compiled_block_1_1222 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1227, compiled_block_1_1227 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1227, compiled_block_1_1227 );
  twobit_stack( 1 );
  twobit_op2imm_131( fixnum(1), 112, compiled_temp_1_112 ); /* - */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1220, compiled_block_1_1220 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_42( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 6 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_movereg( 6, 1 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 31 );
  twobit_movereg( 31, 1 );
  twobit_lambda( compiled_start_1_109, 3, 5 );
  twobit_setreg( 4 );
  twobit_reg( 31 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 31 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_109( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1230, compiled_block_1_1230 );
  twobit_invoke( 1 );
  twobit_label( 1230, compiled_block_1_1230 );
  twobit_load( 0, 0 );
  twobit_branchf( 1232, compiled_block_1_1232 );
  twobit_op1_3(); /* unspecified */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1232, compiled_block_1_1232 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 3 );
  twobit_setrtn( 1233, compiled_block_1_1233 );
  twobit_invoke( 1 );
  twobit_label( 1233, compiled_block_1_1233 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %char->latin1~1ayXVW~6514 */
  twobit_setrtn( 1234, compiled_block_1_1234 );
  twobit_invoke( 1 );
  twobit_label( 1234, compiled_block_1_1234 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  %set1!~1ayXVW~6524 */
  twobit_setrtn( 1235, compiled_block_1_1235 );
  twobit_invoke( 2 );
  twobit_label( 1235, compiled_block_1_1235 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 4 );
  twobit_setrtn( 1236, compiled_block_1_1236 );
  twobit_invoke( 1 );
  twobit_label( 1236, compiled_block_1_1236 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_43( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 4 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_store( 4, 4 );
  twobit_movereg( 5, 1 );
  twobit_global( 1 ); /*  char-set-unfold~1ayXVW~6555 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %default-base~1ayXVW~6516 */
  twobit_setrtn( 1239, compiled_block_1_1239 );
  twobit_invoke( 2 );
  twobit_label( 1239, compiled_block_1_1239 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 2, 1 );
  twobit_load( 3, 2 );
  twobit_load( 4, 3 );
  twobit_store( 4, 2 );
  twobit_stack( 4 );
  twobit_setreg( 1 );
  twobit_store( 1, 4 );
  twobit_stack( 5 );
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  char-set-unfold~1ayXVW~6555 */
  twobit_setreg( 1 );
  twobit_movereg( 4, 5 );
  twobit_load( 4, 2 );
  twobit_load( 6, 4 );
  twobit_global( 3 ); /*  %char-set-unfold!~1ayXVW~6554 */
  twobit_setrtn( 1240, compiled_block_1_1240 );
  twobit_invoke( 6 );
  twobit_label( 1240, compiled_block_1_1240 );
  twobit_load( 0, 0 );
  twobit_load( 1, 5 );
  twobit_global( 4 ); /*  make-char-set~1ayXVW~6490 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_44( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_store( 4, 4 );
  twobit_store( 5, 6 );
  twobit_movereg( 5, 1 );
  twobit_global( 1 ); /*  char-set-unfold!~1ayXVW~6556 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1242, compiled_block_1_1242 );
  twobit_invoke( 2 );
  twobit_label( 1242, compiled_block_1_1242 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 2, 1 );
  twobit_load( 3, 2 );
  twobit_load( 4, 3 );
  twobit_stack( 4 );
  twobit_setreg( 1 );
  twobit_store( 1, 4 );
  twobit_global( 1 ); /*  char-set-unfold!~1ayXVW~6556 */
  twobit_setreg( 1 );
  twobit_load( 5, 5 );
  twobit_load( 6, 4 );
  twobit_global( 3 ); /*  %char-set-unfold!~1ayXVW~6554 */
  twobit_setrtn( 1243, compiled_block_1_1243 );
  twobit_invoke( 6 );
  twobit_label( 1243, compiled_block_1_1243 );
  twobit_load( 0, 0 );
  twobit_stack( 6 );
  twobit_pop( 6 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_45( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_108, 2, 1 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 3 ); /*  for-each~1ayXVW~1382 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_108( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  %char->latin1~1ayXVW~6514 */
  twobit_setrtn( 1244, compiled_block_1_1244 );
  twobit_invoke( 1 );
  twobit_label( 1244, compiled_block_1_1244 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  %set1!~1ayXVW~6524 */
  twobit_pop( 0 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_46( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  c0~1ayXVW~6520 */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(256) ); /* 256 */
  twobit_op2_799( 4 ); /* make-ustring */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 2 ); /*  %list->char-set!~1ayXVW~6557 */
  twobit_setrtn( 1247, compiled_block_1_1247 );
  twobit_invoke( 2 );
  twobit_label( 1247, compiled_block_1_1247 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  make-char-set~1ayXVW~6490 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_47( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  list->char-set~1ayXVW~6559 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %default-base~1ayXVW~6516 */
  twobit_setrtn( 1249, compiled_block_1_1249 );
  twobit_invoke( 2 );
  twobit_label( 1249, compiled_block_1_1249 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  %list->char-set!~1ayXVW~6557 */
  twobit_setrtn( 1250, compiled_block_1_1250 );
  twobit_invoke( 2 );
  twobit_label( 1250, compiled_block_1_1250 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_global( 4 ); /*  make-char-set~1ayXVW~6490 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_48( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  list->char-set!~1ayXVW~6560 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1252, compiled_block_1_1252 );
  twobit_invoke( 2 );
  twobit_label( 1252, compiled_block_1_1252 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  %list->char-set!~1ayXVW~6557 */
  twobit_setrtn( 1253, compiled_block_1_1253 );
  twobit_invoke( 2 );
  twobit_label( 1253, compiled_block_1_1253 );
  twobit_load( 0, 0 );
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_49( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  char-set->list~1ayXVW~6561 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1254, compiled_block_1_1254 );
  twobit_invoke( 2 );
  twobit_label( 1254, compiled_block_1_1254 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_105, 5, 2 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(255) ); /* 255 */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 0 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_105( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(0), 106, compiled_temp_1_106, 1256, compiled_block_1_1256 ); /* internal:branchf-</imm */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1256, compiled_block_1_1256 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_reg( 1 );
  twobit_op2imm_131( fixnum(1), 107, compiled_temp_1_107 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  si=0?~1ayXVW~6518 */
  twobit_setrtn( 1257, compiled_block_1_1257 );
  twobit_invoke( 2 );
  twobit_label( 1257, compiled_block_1_1257 );
  twobit_load( 0, 0 );
  twobit_branchf( 1259, compiled_block_1_1259 );
  twobit_stack( 1 );
  twobit_skip( 1258, compiled_block_1_1258 );
  twobit_label( 1259, compiled_block_1_1259 );
  twobit_load( 1, 2 );
  twobit_global( 2 ); /*  %latin1->char~1ayXVW~6513 */
  twobit_setrtn( 1260, compiled_block_1_1260 );
  twobit_invoke( 1 );
  twobit_label( 1260, compiled_block_1_1260 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_label( 1258, compiled_block_1_1258 );
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_50( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 1, 0, 0, 1263, compiled_block_1_1263 );
  twobit_reg( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 31 );
  twobit_movereg( 31, 3 );
  twobit_lambda( compiled_start_1_103, 3, 4 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 31 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1263, compiled_block_1_1263 );
  twobit_trap( 1, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_103( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(0), 104, compiled_temp_1_104, 1265, compiled_block_1_1265 ); /* internal:branchf-</imm */
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1265, compiled_block_1_1265 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1266, compiled_block_1_1266 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1266, compiled_block_1_1266 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1266, compiled_block_1_1266 );
  twobit_lexical( 0, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %char->latin1~1ayXVW~6514 */
  twobit_setrtn( 1267, compiled_block_1_1267 );
  twobit_invoke( 1 );
  twobit_label( 1267, compiled_block_1_1267 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  %set1!~1ayXVW~6524 */
  twobit_setrtn( 1268, compiled_block_1_1268 );
  twobit_invoke( 2 );
  twobit_label( 1268, compiled_block_1_1268 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1266, compiled_block_1_1266 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_51( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  string->char-set~1ayXVW~6563 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %default-base~1ayXVW~6516 */
  twobit_setrtn( 1271, compiled_block_1_1271 );
  twobit_invoke( 2 );
  twobit_label( 1271, compiled_block_1_1271 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 2 );
  twobit_global( 1 ); /*  string->char-set~1ayXVW~6563 */
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  %string->char-set!~1ayXVW~6562 */
  twobit_setrtn( 1272, compiled_block_1_1272 );
  twobit_invoke( 3 );
  twobit_label( 1272, compiled_block_1_1272 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_global( 4 ); /*  make-char-set~1ayXVW~6490 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_52( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  string->char-set!~1ayXVW~6564 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1274, compiled_block_1_1274 );
  twobit_invoke( 2 );
  twobit_label( 1274, compiled_block_1_1274 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  string->char-set!~1ayXVW~6564 */
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  %string->char-set!~1ayXVW~6562 */
  twobit_setrtn( 1275, compiled_block_1_1275 );
  twobit_invoke( 3 );
  twobit_label( 1275, compiled_block_1_1275 );
  twobit_load( 0, 0 );
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_53( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  char-set->string~1ayXVW~6565 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1276, compiled_block_1_1276 );
  twobit_invoke( 2 );
  twobit_label( 1276, compiled_block_1_1276 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  char-set-size~1ayXVW~6536 */
  twobit_setrtn( 1277, compiled_block_1_1277 );
  twobit_invoke( 1 );
  twobit_label( 1277, compiled_block_1_1277 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( int_to_char(32), 3 ); /*   */
  twobit_op2_799( 3 ); /* make-ustring */
  twobit_setreg( 4 );
  twobit_global( 4 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_100, 6, 3 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(255) ); /* 255 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_100( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(0), 101, compiled_temp_1_101, 1279, compiled_block_1_1279 ); /* internal:branchf-</imm */
  twobit_lexical( 0, 1 );
  twobit_return();
  twobit_label( 1279, compiled_block_1_1279 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  si=0?~1ayXVW~6518 */
  twobit_setrtn( 1280, compiled_block_1_1280 );
  twobit_invoke( 2 );
  twobit_label( 1280, compiled_block_1_1280 );
  twobit_load( 0, 0 );
  twobit_branchf( 1282, compiled_block_1_1282 );
  twobit_stack( 1 );
  twobit_skip( 1281, compiled_block_1_1281 );
  twobit_label( 1282, compiled_block_1_1282 );
  twobit_load( 1, 2 );
  twobit_global( 2 ); /*  %latin1->char~1ayXVW~6513 */
  twobit_setrtn( 1283, compiled_block_1_1283 );
  twobit_invoke( 1 );
  twobit_label( 1283, compiled_block_1_1283 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 2, 1284, compiled_block_1_1284 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 2, 1284, compiled_block_1_1284 );
  twobit_stack( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 2, 1284, compiled_block_1_1284 );
  twobit_reg( 4 );
  twobit_op1_36(); /* char? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 2, 1284, compiled_block_1_1284 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 1 );
  twobit_op3_803( 3, 4 ); /* ustring-set!:trusted */
  twobit_reg( 3 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_label( 1281, compiled_block_1_1281 );
  twobit_setreg( 2 );
  twobit_stack( 2 );
  twobit_op2imm_131( fixnum(1), 102, compiled_temp_1_102 ); /* - */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1284, compiled_block_1_1284 );
  twobit_trap( 2, 1, 4, 61 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_54( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_store( 4, 3 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 2, 92, compiled_temp_1_92, 1288, compiled_block_1_1288 ); /* internal:branchf-< */
  twobit_imm_const( fixnum(256) ); /* 256 */
  twobit_op2_branchf_619( 2, 93, compiled_temp_1_93, 1290, compiled_block_1_1290 ); /* internal:branchf-< */
  twobit_reg( 3 );
  twobit_skip( 1287, compiled_block_1_1287 );
  twobit_label( 1290, compiled_block_1_1290 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1287, compiled_block_1_1287 );
  twobit_label( 1288, compiled_block_1_1288 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1287, compiled_block_1_1287 );
  twobit_branchf( 1292, compiled_block_1_1292 );
  twobit_movereg( 5, 2 );
  twobit_movereg( 1, 3 );
  twobit_load( 4, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~6485 */
  twobit_setrtn( 1293, compiled_block_1_1293 );
  twobit_invoke( 4 );
  twobit_label( 1293, compiled_block_1_1293 );
  twobit_load( 0, 0 );
  twobit_skip( 1291, compiled_block_1_1291 );
  twobit_label( 1292, compiled_block_1_1292 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 1291, compiled_block_1_1291 );
  twobit_stack( 1 );
  twobit_op2imm_branchf_638( fixnum(256), 94, compiled_temp_1_94, 1295, compiled_block_1_1295 ); /* internal:branchf-<=/imm */
  twobit_stack( 1 );
  twobit_skip( 1294, compiled_block_1_1294 );
  twobit_label( 1295, compiled_block_1_1295 );
  twobit_imm_const( fixnum(256) ); /* 256 */
  twobit_label( 1294, compiled_block_1_1294 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_26(); /* inexact? */
  twobit_branchf( 1297, compiled_block_1_1297 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1296, compiled_block_1_1296 );
  twobit_label( 1297, compiled_block_1_1297 );
  twobit_imm_const( fixnum(256) ); /* 256 */
  twobit_op1_26(); /* inexact? */
  twobit_label( 1296, compiled_block_1_1296 );
  twobit_branchf( 1299, compiled_block_1_1299 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_61( 3, 95, compiled_temp_1_95 ); /* + */
  twobit_skip( 1298, compiled_block_1_1298 );
  twobit_label( 1299, compiled_block_1_1299 );
  twobit_reg( 4 );
  twobit_label( 1298, compiled_block_1_1298 );
  twobit_op2imm_131( fixnum(1), 96, compiled_temp_1_96 ); /* - */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_global( 4 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_97, 6, 3 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_97( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 3 );
  twobit_op2_branchf_622( 1, 98, compiled_temp_1_98, 1301, compiled_block_1_1301 ); /* internal:branchf-<= */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %set1!~1ayXVW~6524 */
  twobit_setrtn( 1302, compiled_block_1_1302 );
  twobit_invoke( 2 );
  twobit_label( 1302, compiled_block_1_1302 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op2imm_131( fixnum(1), 99, compiled_temp_1_99 ); /* - */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1301, compiled_block_1_1301 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_55( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 4 );
  twobit_store( 3, 1 );
  twobit_reg( 3 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_branchf( 1306, compiled_block_1_1306 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_skip( 1305, compiled_block_1_1305 );
  twobit_label( 1306, compiled_block_1_1306 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_label( 1305, compiled_block_1_1305 );
  twobit_global( 1 ); /*  ucs-range->char-set~1ayXVW~6567 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %default-base~1ayXVW~6516 */
  twobit_setrtn( 1307, compiled_block_1_1307 );
  twobit_invoke( 2 );
  twobit_label( 1307, compiled_block_1_1307 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_stack( 1 );
  twobit_op1_branchf_610( 1309, compiled_block_1_1309 ); /* internal:branchf-null? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1308, compiled_block_1_1308 );
  twobit_label( 1309, compiled_block_1_1309 );
  twobit_stack( 2 );
  twobit_load( 2, 1 );
  twobit_check( 2, 0, 0, 1310, compiled_block_1_1310 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_label( 1308, compiled_block_1_1308 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  ucs-range->char-set~1ayXVW~6567 */
  twobit_setreg( 2 );
  twobit_movereg( 2, 5 );
  twobit_load( 1, 3 );
  twobit_load( 2, 4 );
  twobit_global( 3 ); /*  %ucs-range->char-set!~1ayXVW~6566 */
  twobit_setrtn( 1311, compiled_block_1_1311 );
  twobit_invoke( 5 );
  twobit_label( 1311, compiled_block_1_1311 );
  twobit_load( 0, 0 );
  twobit_load( 1, 5 );
  twobit_global( 4 ); /*  make-char-set~1ayXVW~6490 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 1310, compiled_block_1_1310 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_56( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_store( 4, 4 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /*  ucs-range->char-set!~1ayXVW~6568 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1313, compiled_block_1_1313 );
  twobit_invoke( 2 );
  twobit_label( 1313, compiled_block_1_1313 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_global( 3 ); /*  ucs-range->char-set~1ayXVW~6567 */
  twobit_setreg( 3 );
  twobit_movereg( 3, 5 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_load( 3, 3 );
  twobit_global( 4 ); /*  %ucs-range->char-set!~1ayXVW~6566 */
  twobit_setrtn( 1314, compiled_block_1_1314 );
  twobit_invoke( 5 );
  twobit_label( 1314, compiled_block_1_1314 );
  twobit_load( 0, 0 );
  twobit_stack( 4 );
  twobit_pop( 4 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_57( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_89, 3, 4 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(255) ); /* 255 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_89( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_637( fixnum(0), 90, compiled_temp_1_90, 1316, compiled_block_1_1316 ); /* internal:branchf->=/imm */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  si=1?~1ayXVW~6519 */
  twobit_setrtn( 1317, compiled_block_1_1317 );
  twobit_invoke( 2 );
  twobit_label( 1317, compiled_block_1_1317 );
  twobit_load( 0, 0 );
  twobit_branchf( 1319, compiled_block_1_1319 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  %latin1->char~1ayXVW~6513 */
  twobit_setrtn( 1320, compiled_block_1_1320 );
  twobit_invoke( 1 );
  twobit_label( 1320, compiled_block_1_1320 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1321, compiled_block_1_1321 );
  twobit_invoke( 1 );
  twobit_label( 1321, compiled_block_1_1321 );
  twobit_load( 0, 0 );
  twobit_skip( 1318, compiled_block_1_1318 );
  twobit_label( 1319, compiled_block_1_1319 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1318, compiled_block_1_1318 );
  twobit_branchf( 1323, compiled_block_1_1323 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  %set1!~1ayXVW~6524 */
  twobit_setrtn( 1324, compiled_block_1_1324 );
  twobit_invoke( 2 );
  twobit_label( 1324, compiled_block_1_1324 );
  twobit_load( 0, 0 );
  twobit_skip( 1322, compiled_block_1_1322 );
  twobit_label( 1323, compiled_block_1_1323 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 1322, compiled_block_1_1322 );
  twobit_stack( 1 );
  twobit_op2imm_131( fixnum(1), 91, compiled_temp_1_91 ); /* - */
  twobit_setreg( 1 );
  twobit_lexical( 0, 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1316, compiled_block_1_1316 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_58( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /*  char-set-filter~1ayXVW~6570 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %default-base~1ayXVW~6516 */
  twobit_setrtn( 1327, compiled_block_1_1327 );
  twobit_invoke( 2 );
  twobit_label( 1327, compiled_block_1_1327 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  char-set-filter!~1ayXVW~6571 */
  twobit_setreg( 2 );
  twobit_global( 4 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1328, compiled_block_1_1328 );
  twobit_invoke( 2 );
  twobit_label( 1328, compiled_block_1_1328 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 3, 2 );
  twobit_global( 1 ); /*  char-set-filter~1ayXVW~6570 */
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_global( 5 ); /*  %char-set-filter!~1ayXVW~6569 */
  twobit_setrtn( 1329, compiled_block_1_1329 );
  twobit_invoke( 4 );
  twobit_label( 1329, compiled_block_1_1329 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /*  make-char-set~1ayXVW~6490 */
  twobit_pop( 3 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_59( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  char-set-filter!~1ayXVW~6571 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1331, compiled_block_1_1331 );
  twobit_invoke( 2 );
  twobit_label( 1331, compiled_block_1_1331 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 1 ); /*  char-set-filter!~1ayXVW~6571 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1332, compiled_block_1_1332 );
  twobit_invoke( 2 );
  twobit_label( 1332, compiled_block_1_1332 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_global( 1 ); /*  char-set-filter!~1ayXVW~6571 */
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_global( 3 ); /*  %char-set-filter!~1ayXVW~6569 */
  twobit_setrtn( 1333, compiled_block_1_1333 );
  twobit_invoke( 4 );
  twobit_label( 1333, compiled_block_1_1333 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_pop( 3 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_60( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  char-set?~1ayXVW~6491 */
  twobit_setrtn( 1334, compiled_block_1_1334 );
  twobit_invoke( 1 );
  twobit_label( 1334, compiled_block_1_1334 );
  twobit_load( 0, 0 );
  twobit_branchf( 1336, compiled_block_1_1336 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1336, compiled_block_1_1336 );
  twobit_stack( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 1338, compiled_block_1_1338 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  string->char-set~1ayXVW~6563 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1338, compiled_block_1_1338 );
  twobit_stack( 1 );
  twobit_op1_branchf_615( 1341, compiled_block_1_1341 ); /* internal:branchf-char? */
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  char-set~1ayXVW~6558 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1341, compiled_block_1_1341 );
  twobit_load( 2, 1 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  error~1ayXVW~6485 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_61( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 2 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 2, 0, 0, 1344, compiled_block_1_1344 );
  twobit_reg( 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 31 );
  twobit_movereg( 31, 3 );
  twobit_lambda( compiled_start_1_87, 3, 4 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 31 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1344, compiled_block_1_1344 );
  twobit_trap( 2, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_87( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_637( fixnum(0), 88, compiled_temp_1_88, 1346, compiled_block_1_1346 ); /* internal:branchf->=/imm */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1347, compiled_block_1_1347 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1347, compiled_block_1_1347 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1347, compiled_block_1_1347 );
  twobit_lexical( 0, 2 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %char->latin1~1ayXVW~6514 */
  twobit_setrtn( 1348, compiled_block_1_1348 );
  twobit_invoke( 1 );
  twobit_label( 1348, compiled_block_1_1348 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1349, compiled_block_1_1349 );
  twobit_invoke( 2 );
  twobit_label( 1349, compiled_block_1_1349 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1346, compiled_block_1_1346 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1347, compiled_block_1_1347 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_62( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_83, 2, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 3 ); /*  for-each~1ayXVW~1382 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_83( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1352, compiled_block_1_1352 );
  twobit_invoke( 2 );
  twobit_label( 1352, compiled_block_1_1352 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_84, 4, 2 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(255) ); /* 255 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_84( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_637( fixnum(0), 85, compiled_temp_1_85, 1354, compiled_block_1_1354 ); /* internal:branchf->=/imm */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  si~1ayXVW~6522 */
  twobit_setrtn( 1355, compiled_block_1_1355 );
  twobit_invoke( 2 );
  twobit_label( 1355, compiled_block_1_1355 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 3 );
  twobit_setrtn( 1356, compiled_block_1_1356 );
  twobit_invoke( 3 );
  twobit_label( 1356, compiled_block_1_1356 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op2imm_131( fixnum(1), 86, compiled_temp_1_86 ); /* - */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1354, compiled_block_1_1354 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_63( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  char-set-complement~1ayXVW~6575 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1360, compiled_block_1_1360 );
  twobit_invoke( 2 );
  twobit_label( 1360, compiled_block_1_1360 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_imm_const( int_to_char(32) ); /* #\space */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(256) ); /* 256 */
  twobit_op2_799( 4 ); /* make-ustring */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_82, 4, 1 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  %string-iter~1ayXVW~6573 */
  twobit_setrtn( 1362, compiled_block_1_1362 );
  twobit_invoke( 2 );
  twobit_label( 1362, compiled_block_1_1362 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /*  make-char-set~1ayXVW~6490 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_82( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %not!~1ayXVW~6526 */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_64( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  char-set-complement!~1ayXVW~6576 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1364, compiled_block_1_1364 );
  twobit_invoke( 2 );
  twobit_label( 1364, compiled_block_1_1364 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_81, 4, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 5 ); /*  %string-iter~1ayXVW~6573 */
  twobit_setrtn( 1366, compiled_block_1_1366 );
  twobit_invoke( 2 );
  twobit_label( 1366, compiled_block_1_1366 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_81( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %not!~1ayXVW~6526 */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_65( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  char-set-union!~1ayXVW~6577 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1367, compiled_block_1_1367 );
  twobit_invoke( 2 );
  twobit_label( 1367, compiled_block_1_1367 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  %or!~1ayXVW~6528 */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  char-set-union!~1ayXVW~6577 */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /*  %char-set-algebra~1ayXVW~6574 */
  twobit_setrtn( 1368, compiled_block_1_1368 );
  twobit_invoke( 4 );
  twobit_label( 1368, compiled_block_1_1368 );
  twobit_load( 0, 0 );
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_66( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1370, compiled_block_1_1370 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  char-set-union~1ayXVW~6578 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1371, compiled_block_1_1371 );
  twobit_invoke( 2 );
  twobit_label( 1371, compiled_block_1_1371 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  %string-copy~1ayXVW~6515 */
  twobit_setrtn( 1372, compiled_block_1_1372 );
  twobit_invoke( 1 );
  twobit_label( 1372, compiled_block_1_1372 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 4 ); /*  %or!~1ayXVW~6528 */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  char-set-union~1ayXVW~6578 */
  twobit_setreg( 4 );
  twobit_global( 5 ); /*  %char-set-algebra~1ayXVW~6574 */
  twobit_setrtn( 1373, compiled_block_1_1373 );
  twobit_invoke( 4 );
  twobit_label( 1373, compiled_block_1_1373 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /*  make-char-set~1ayXVW~6490 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1370, compiled_block_1_1370 );
  twobit_global( 7 ); /*  char-set:empty~1ayXVW~6588 */
  twobit_setreg( 1 );
  twobit_global( 8 ); /*  char-set-copy~1ayXVW~6531 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_67( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  char-set-intersection!~1ayXVW~6579 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1376, compiled_block_1_1376 );
  twobit_invoke( 2 );
  twobit_label( 1376, compiled_block_1_1376 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  %and!~1ayXVW~6527 */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  char-set-intersection!~1ayXVW~6579 */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /*  %char-set-algebra~1ayXVW~6574 */
  twobit_setrtn( 1377, compiled_block_1_1377 );
  twobit_invoke( 4 );
  twobit_label( 1377, compiled_block_1_1377 );
  twobit_load( 0, 0 );
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_68( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1379, compiled_block_1_1379 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  char-set-intersection~1ayXVW~6580 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1380, compiled_block_1_1380 );
  twobit_invoke( 2 );
  twobit_label( 1380, compiled_block_1_1380 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  %string-copy~1ayXVW~6515 */
  twobit_setrtn( 1381, compiled_block_1_1381 );
  twobit_invoke( 1 );
  twobit_label( 1381, compiled_block_1_1381 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 4 ); /*  %and!~1ayXVW~6527 */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  char-set-intersection~1ayXVW~6580 */
  twobit_setreg( 4 );
  twobit_global( 5 ); /*  %char-set-algebra~1ayXVW~6574 */
  twobit_setrtn( 1382, compiled_block_1_1382 );
  twobit_invoke( 4 );
  twobit_label( 1382, compiled_block_1_1382 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /*  make-char-set~1ayXVW~6490 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1379, compiled_block_1_1379 );
  twobit_global( 7 ); /*  char-set:full~1ayXVW~6589 */
  twobit_setreg( 1 );
  twobit_global( 8 ); /*  char-set-copy~1ayXVW~6531 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_69( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  char-set-difference!~1ayXVW~6581 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1385, compiled_block_1_1385 );
  twobit_invoke( 2 );
  twobit_label( 1385, compiled_block_1_1385 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  %minus!~1ayXVW~6529 */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  char-set-difference!~1ayXVW~6581 */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /*  %char-set-algebra~1ayXVW~6574 */
  twobit_setrtn( 1386, compiled_block_1_1386 );
  twobit_invoke( 4 );
  twobit_label( 1386, compiled_block_1_1386 );
  twobit_load( 0, 0 );
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_70( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1388, compiled_block_1_1388 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  char-set-difference~1ayXVW~6582 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1389, compiled_block_1_1389 );
  twobit_invoke( 2 );
  twobit_label( 1389, compiled_block_1_1389 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  %string-copy~1ayXVW~6515 */
  twobit_setrtn( 1390, compiled_block_1_1390 );
  twobit_invoke( 1 );
  twobit_label( 1390, compiled_block_1_1390 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 4 ); /*  %minus!~1ayXVW~6529 */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  char-set-difference~1ayXVW~6582 */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /*  %char-set-algebra~1ayXVW~6574 */
  twobit_setrtn( 1391, compiled_block_1_1391 );
  twobit_invoke( 4 );
  twobit_label( 1391, compiled_block_1_1391 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /*  make-char-set~1ayXVW~6490 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1388, compiled_block_1_1388 );
  twobit_global( 7 ); /*  char-set-copy~1ayXVW~6531 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_71( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  char-set-xor!~1ayXVW~6583 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1394, compiled_block_1_1394 );
  twobit_invoke( 2 );
  twobit_label( 1394, compiled_block_1_1394 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  %xor!~1ayXVW~6530 */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  char-set-xor!~1ayXVW~6583 */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /*  %char-set-algebra~1ayXVW~6574 */
  twobit_setrtn( 1395, compiled_block_1_1395 );
  twobit_invoke( 4 );
  twobit_label( 1395, compiled_block_1_1395 );
  twobit_load( 0, 0 );
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_72( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1397, compiled_block_1_1397 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  char-set-xor~1ayXVW~6584 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1398, compiled_block_1_1398 );
  twobit_invoke( 2 );
  twobit_label( 1398, compiled_block_1_1398 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  %string-copy~1ayXVW~6515 */
  twobit_setrtn( 1399, compiled_block_1_1399 );
  twobit_invoke( 1 );
  twobit_label( 1399, compiled_block_1_1399 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 4 ); /*  %xor!~1ayXVW~6530 */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  char-set-xor~1ayXVW~6584 */
  twobit_setreg( 4 );
  twobit_global( 5 ); /*  %char-set-algebra~1ayXVW~6574 */
  twobit_setrtn( 1400, compiled_block_1_1400 );
  twobit_invoke( 4 );
  twobit_label( 1400, compiled_block_1_1400 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /*  make-char-set~1ayXVW~6490 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1397, compiled_block_1_1397 );
  twobit_global( 7 ); /*  char-set:empty~1ayXVW~6588 */
  twobit_setreg( 1 );
  twobit_global( 8 ); /*  char-set-copy~1ayXVW~6531 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_73( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_78, 2, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 3 ); /*  for-each~1ayXVW~1382 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_78( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_79, 2, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1410, compiled_block_1_1410 );
  twobit_invoke( 2 );
  twobit_label( 1410, compiled_block_1_1410 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 4 ); /*  %string-iter~1ayXVW~6573 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_79( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_612( 80, compiled_temp_1_80, 1404, compiled_block_1_1404 ); /* internal:branchf-zero? */
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1404, compiled_block_1_1404 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  si=1?~1ayXVW~6519 */
  twobit_setrtn( 1405, compiled_block_1_1405 );
  twobit_invoke( 2 );
  twobit_label( 1405, compiled_block_1_1405 );
  twobit_load( 0, 0 );
  twobit_branchf( 1407, compiled_block_1_1407 );
  twobit_load( 2, 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  %set0!~1ayXVW~6523 */
  twobit_setrtn( 1408, compiled_block_1_1408 );
  twobit_invoke( 2 );
  twobit_label( 1408, compiled_block_1_1408 );
  twobit_load( 0, 0 );
  twobit_load( 2, 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  %set1!~1ayXVW~6524 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1407, compiled_block_1_1407 );
  twobit_op1_3(); /* unspecified */
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_74( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 5 );
  twobit_store( 3, 4 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  char-set-diff+intersection!~1ayXVW~6586 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1413, compiled_block_1_1413 );
  twobit_invoke( 2 );
  twobit_label( 1413, compiled_block_1_1413 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_global( 1 ); /*  char-set-diff+intersection!~1ayXVW~6586 */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1414, compiled_block_1_1414 );
  twobit_invoke( 2 );
  twobit_label( 1414, compiled_block_1_1414 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 2, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_76, 4, 2 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 5 ); /*  %string-iter~1ayXVW~6573 */
  twobit_setrtn( 1422, compiled_block_1_1422 );
  twobit_invoke( 2 );
  twobit_label( 1422, compiled_block_1_1422 );
  twobit_load( 0, 0 );
  twobit_global( 1 ); /*  char-set-diff+intersection!~1ayXVW~6586 */
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_load( 2, 2 );
  twobit_load( 3, 4 );
  twobit_global( 6 ); /*  %char-set-diff+intersection!~1ayXVW~6585 */
  twobit_setrtn( 1423, compiled_block_1_1423 );
  twobit_invoke( 4 );
  twobit_label( 1423, compiled_block_1_1423 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_load( 2, 5 );
  twobit_global( 7 ); /* values */
  twobit_pop( 5 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_76( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_612( 77, compiled_temp_1_77, 1416, compiled_block_1_1416 ); /* internal:branchf-zero? */
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %set0!~1ayXVW~6523 */
  twobit_invoke( 2 );
  twobit_label( 1416, compiled_block_1_1416 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  si=1?~1ayXVW~6519 */
  twobit_setrtn( 1418, compiled_block_1_1418 );
  twobit_invoke( 2 );
  twobit_label( 1418, compiled_block_1_1418 );
  twobit_load( 0, 0 );
  twobit_branchf( 1420, compiled_block_1_1420 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %set0!~1ayXVW~6523 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1420, compiled_block_1_1420 );
  twobit_op1_3(); /* unspecified */
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_75( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  char-set-diff+intersection~1ayXVW~6587 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %char-set:s/check~1ayXVW~6517 */
  twobit_setrtn( 1425, compiled_block_1_1425 );
  twobit_invoke( 2 );
  twobit_label( 1425, compiled_block_1_1425 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* string-copy */
  twobit_setrtn( 1426, compiled_block_1_1426 );
  twobit_invoke( 1 );
  twobit_label( 1426, compiled_block_1_1426 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 4 ); /*  c0~1ayXVW~6520 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(256) ); /* 256 */
  twobit_op2_799( 2 ); /* make-ustring */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  char-set-diff+intersection~1ayXVW~6587 */
  twobit_setreg( 4 );
  twobit_global( 5 ); /*  %char-set-diff+intersection!~1ayXVW~6585 */
  twobit_setrtn( 1427, compiled_block_1_1427 );
  twobit_invoke( 4 );
  twobit_label( 1427, compiled_block_1_1427 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /*  make-char-set~1ayXVW~6490 */
  twobit_setrtn( 1428, compiled_block_1_1428 );
  twobit_invoke( 1 );
  twobit_label( 1428, compiled_block_1_1428 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /*  make-char-set~1ayXVW~6490 */
  twobit_setrtn( 1429, compiled_block_1_1429 );
  twobit_invoke( 1 );
  twobit_label( 1429, compiled_block_1_1429 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 7 ); /* values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


RTYPE twobit_thunk_0df72f5ef084dd02323b48f6e1971198_0(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_1_0(CONT_ACTUALS));
}
static RTYPE compiled_block_2_1004( CONT_PARAMS );
static RTYPE compiled_block_2_1003( CONT_PARAMS );
static RTYPE compiled_start_2_0( CONT_PARAMS );
static RTYPE compiled_start_2_3( CONT_PARAMS );
static RTYPE compiled_start_2_2( CONT_PARAMS );
static RTYPE compiled_start_2_1( CONT_PARAMS );

static RTYPE compiled_start_2_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_2_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_2_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1003, compiled_block_2_1003 );
  twobit_invoke( 8 );
  twobit_label( 1003, compiled_block_2_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1004, compiled_block_2_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_2_1004 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_0df72f5ef084dd02323b48f6e1971198_1(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_2_0(CONT_ACTUALS));
}
codeptr_t CDECL twobit_load_table[] = { 
  twobit_thunk_0df72f5ef084dd02323b48f6e1971198_0,
  twobit_thunk_0df72f5ef084dd02323b48f6e1971198_1,
  0  /* The table may be empty; some compilers complain */
};

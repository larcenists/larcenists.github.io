/* Generated from /proj/will/pnkfelix/larcenytest/larceny-petit-Nightly-2009-08-19/larceny_src/lib/SRFI/srfi/%3a13.slfasl */
#include "petit-instr.h"

static RTYPE compiled_block_1_2546( CONT_PARAMS );
static RTYPE compiled_block_1_2545( CONT_PARAMS );
static RTYPE compiled_start_1_0( CONT_PARAMS );
static RTYPE compiled_start_1_3( CONT_PARAMS );
static RTYPE compiled_start_1_109( CONT_PARAMS );
static RTYPE compiled_block_1_2538( CONT_PARAMS );
static RTYPE compiled_block_1_2540( CONT_PARAMS );
static RTYPE compiled_block_1_2536( CONT_PARAMS );
static RTYPE compiled_start_1_111( CONT_PARAMS );
static RTYPE compiled_start_1_110( CONT_PARAMS );
static RTYPE compiled_block_1_2504( CONT_PARAMS );
static RTYPE compiled_block_1_2507( CONT_PARAMS );
static RTYPE compiled_block_1_2524( CONT_PARAMS );
static RTYPE compiled_block_1_2526( CONT_PARAMS );
static RTYPE compiled_block_1_2509( CONT_PARAMS );
static RTYPE compiled_block_1_2512( CONT_PARAMS );
static RTYPE compiled_block_1_2521( CONT_PARAMS );
static RTYPE compiled_block_1_2519( CONT_PARAMS );
static RTYPE compiled_block_1_2520( CONT_PARAMS );
static RTYPE compiled_block_1_2516( CONT_PARAMS );
static RTYPE compiled_block_1_2517( CONT_PARAMS );
static RTYPE compiled_block_1_2513( CONT_PARAMS );
static RTYPE compiled_block_1_2514( CONT_PARAMS );
static RTYPE compiled_block_1_2510( CONT_PARAMS );
static RTYPE compiled_block_1_2511( CONT_PARAMS );
static RTYPE compiled_start_1_113( CONT_PARAMS );
static RTYPE compiled_block_1_2531( CONT_PARAMS );
static RTYPE compiled_block_1_2532( CONT_PARAMS );
static RTYPE compiled_start_1_114( CONT_PARAMS );
static RTYPE compiled_block_1_2502( CONT_PARAMS );
static RTYPE compiled_block_1_2500( CONT_PARAMS );
static RTYPE compiled_start_1_112( CONT_PARAMS );
static RTYPE compiled_temp_1_121( CONT_PARAMS );
static RTYPE compiled_temp_1_120( CONT_PARAMS );
static RTYPE compiled_temp_1_119( CONT_PARAMS );
static RTYPE compiled_temp_1_118( CONT_PARAMS );
static RTYPE compiled_block_1_2492( CONT_PARAMS );
static RTYPE compiled_temp_1_117( CONT_PARAMS );
static RTYPE compiled_temp_1_116( CONT_PARAMS );
static RTYPE compiled_block_1_2491( CONT_PARAMS );
static RTYPE compiled_temp_1_115( CONT_PARAMS );
static RTYPE compiled_start_1_108( CONT_PARAMS );
static RTYPE compiled_temp_1_128( CONT_PARAMS );
static RTYPE compiled_temp_1_127( CONT_PARAMS );
static RTYPE compiled_block_1_2496( CONT_PARAMS );
static RTYPE compiled_block_1_2494( CONT_PARAMS );
static RTYPE compiled_temp_1_126( CONT_PARAMS );
static RTYPE compiled_temp_1_125( CONT_PARAMS );
static RTYPE compiled_temp_1_124( CONT_PARAMS );
static RTYPE compiled_temp_1_123( CONT_PARAMS );
static RTYPE compiled_start_1_122( CONT_PARAMS );
static RTYPE compiled_start_1_107( CONT_PARAMS );
static RTYPE compiled_block_1_2488( CONT_PARAMS );
static RTYPE compiled_temp_1_133( CONT_PARAMS );
static RTYPE compiled_block_1_2482( CONT_PARAMS );
static RTYPE compiled_start_1_130( CONT_PARAMS );
static RTYPE compiled_block_1_2485( CONT_PARAMS );
static RTYPE compiled_start_1_132( CONT_PARAMS );
static RTYPE compiled_block_1_2483( CONT_PARAMS );
static RTYPE compiled_start_1_131( CONT_PARAMS );
static RTYPE compiled_block_1_2471( CONT_PARAMS );
static RTYPE compiled_block_1_2476( CONT_PARAMS );
static RTYPE compiled_temp_1_144( CONT_PARAMS );
static RTYPE compiled_block_1_2478( CONT_PARAMS );
static RTYPE compiled_temp_1_143( CONT_PARAMS );
static RTYPE compiled_block_1_2477( CONT_PARAMS );
static RTYPE compiled_temp_1_142( CONT_PARAMS );
static RTYPE compiled_block_1_2474( CONT_PARAMS );
static RTYPE compiled_temp_1_141( CONT_PARAMS );
static RTYPE compiled_block_1_2473( CONT_PARAMS );
static RTYPE compiled_temp_1_140( CONT_PARAMS );
static RTYPE compiled_block_1_2470( CONT_PARAMS );
static RTYPE compiled_temp_1_139( CONT_PARAMS );
static RTYPE compiled_block_1_2467( CONT_PARAMS );
static RTYPE compiled_temp_1_138( CONT_PARAMS );
static RTYPE compiled_block_1_2465( CONT_PARAMS );
static RTYPE compiled_temp_1_137( CONT_PARAMS );
static RTYPE compiled_block_1_2463( CONT_PARAMS );
static RTYPE compiled_temp_1_136( CONT_PARAMS );
static RTYPE compiled_temp_1_135( CONT_PARAMS );
static RTYPE compiled_temp_1_134( CONT_PARAMS );
static RTYPE compiled_start_1_129( CONT_PARAMS );
static RTYPE compiled_start_1_106( CONT_PARAMS );
static RTYPE compiled_block_1_2453( CONT_PARAMS );
static RTYPE compiled_block_1_2461( CONT_PARAMS );
static RTYPE compiled_block_1_2457( CONT_PARAMS );
static RTYPE compiled_temp_1_156( CONT_PARAMS );
static RTYPE compiled_block_1_2459( CONT_PARAMS );
static RTYPE compiled_temp_1_155( CONT_PARAMS );
static RTYPE compiled_block_1_2458( CONT_PARAMS );
static RTYPE compiled_temp_1_154( CONT_PARAMS );
static RTYPE compiled_block_1_2455( CONT_PARAMS );
static RTYPE compiled_temp_1_153( CONT_PARAMS );
static RTYPE compiled_block_1_2454( CONT_PARAMS );
static RTYPE compiled_temp_1_152( CONT_PARAMS );
static RTYPE compiled_block_1_2452( CONT_PARAMS );
static RTYPE compiled_temp_1_151( CONT_PARAMS );
static RTYPE compiled_block_1_2449( CONT_PARAMS );
static RTYPE compiled_temp_1_150( CONT_PARAMS );
static RTYPE compiled_block_1_2447( CONT_PARAMS );
static RTYPE compiled_temp_1_149( CONT_PARAMS );
static RTYPE compiled_temp_1_148( CONT_PARAMS );
static RTYPE compiled_temp_1_147( CONT_PARAMS );
static RTYPE compiled_start_1_146( CONT_PARAMS );
static RTYPE compiled_block_1_2444( CONT_PARAMS );
static RTYPE compiled_temp_1_159( CONT_PARAMS );
static RTYPE compiled_block_1_2438( CONT_PARAMS );
static RTYPE compiled_start_1_145( CONT_PARAMS );
static RTYPE compiled_block_1_2441( CONT_PARAMS );
static RTYPE compiled_start_1_158( CONT_PARAMS );
static RTYPE compiled_block_1_2439( CONT_PARAMS );
static RTYPE compiled_start_1_157( CONT_PARAMS );
static RTYPE compiled_start_1_105( CONT_PARAMS );
static RTYPE compiled_block_1_2430( CONT_PARAMS );
static RTYPE compiled_block_1_2433( CONT_PARAMS );
static RTYPE compiled_block_1_2431( CONT_PARAMS );
static RTYPE compiled_block_1_2428( CONT_PARAMS );
static RTYPE compiled_start_1_161( CONT_PARAMS );
static RTYPE compiled_start_1_160( CONT_PARAMS );
static RTYPE compiled_start_1_163( CONT_PARAMS );
static RTYPE compiled_start_1_162( CONT_PARAMS );
static RTYPE compiled_block_1_2417( CONT_PARAMS );
static RTYPE compiled_block_1_2423( CONT_PARAMS );
static RTYPE compiled_block_1_2420( CONT_PARAMS );
static RTYPE compiled_block_1_2421( CONT_PARAMS );
static RTYPE compiled_temp_1_167( CONT_PARAMS );
static RTYPE compiled_block_1_2418( CONT_PARAMS );
static RTYPE compiled_temp_1_166( CONT_PARAMS );
static RTYPE compiled_block_1_2413( CONT_PARAMS );
static RTYPE compiled_block_1_2414( CONT_PARAMS );
static RTYPE compiled_block_1_2415( CONT_PARAMS );
static RTYPE compiled_temp_1_165( CONT_PARAMS );
static RTYPE compiled_start_1_164( CONT_PARAMS );
static RTYPE compiled_block_1_2406( CONT_PARAMS );
static RTYPE compiled_start_1_104( CONT_PARAMS );
static RTYPE compiled_block_1_2408( CONT_PARAMS );
static RTYPE compiled_block_1_2411( CONT_PARAMS );
static RTYPE compiled_temp_1_174( CONT_PARAMS );
static RTYPE compiled_block_1_2410( CONT_PARAMS );
static RTYPE compiled_block_1_2409( CONT_PARAMS );
static RTYPE compiled_temp_1_173( CONT_PARAMS );
static RTYPE compiled_temp_1_172( CONT_PARAMS );
static RTYPE compiled_temp_1_171( CONT_PARAMS );
static RTYPE compiled_temp_1_170( CONT_PARAMS );
static RTYPE compiled_start_1_169( CONT_PARAMS );
static RTYPE compiled_start_1_168( CONT_PARAMS );
static RTYPE compiled_block_1_2405( CONT_PARAMS );
static RTYPE compiled_block_1_2399( CONT_PARAMS );
static RTYPE compiled_temp_1_175( CONT_PARAMS );
static RTYPE compiled_start_1_103( CONT_PARAMS );
static RTYPE compiled_block_1_2402( CONT_PARAMS );
static RTYPE compiled_block_1_2401( CONT_PARAMS );
static RTYPE compiled_block_1_2403( CONT_PARAMS );
static RTYPE compiled_temp_1_177( CONT_PARAMS );
static RTYPE compiled_start_1_176( CONT_PARAMS );
static RTYPE compiled_start_1_102( CONT_PARAMS );
static RTYPE compiled_block_1_2393( CONT_PARAMS );
static RTYPE compiled_block_1_2395( CONT_PARAMS );
static RTYPE compiled_block_1_2391( CONT_PARAMS );
static RTYPE compiled_start_1_179( CONT_PARAMS );
static RTYPE compiled_start_1_178( CONT_PARAMS );
static RTYPE compiled_block_1_2369( CONT_PARAMS );
static RTYPE compiled_start_1_181( CONT_PARAMS );
static RTYPE compiled_block_1_2372( CONT_PARAMS );
static RTYPE compiled_block_1_2383( CONT_PARAMS );
static RTYPE compiled_block_1_2385( CONT_PARAMS );
static RTYPE compiled_block_1_2381( CONT_PARAMS );
static RTYPE compiled_block_1_2382( CONT_PARAMS );
static RTYPE compiled_temp_1_187( CONT_PARAMS );
static RTYPE compiled_temp_1_186( CONT_PARAMS );
static RTYPE compiled_block_1_2379( CONT_PARAMS );
static RTYPE compiled_temp_1_185( CONT_PARAMS );
static RTYPE compiled_block_1_2371( CONT_PARAMS );
static RTYPE compiled_block_1_2375( CONT_PARAMS );
static RTYPE compiled_block_1_2376( CONT_PARAMS );
static RTYPE compiled_block_1_2373( CONT_PARAMS );
static RTYPE compiled_temp_1_184( CONT_PARAMS );
static RTYPE compiled_block_1_2374( CONT_PARAMS );
static RTYPE compiled_temp_1_183( CONT_PARAMS );
static RTYPE compiled_start_1_182( CONT_PARAMS );
static RTYPE compiled_block_1_2354( CONT_PARAMS );
static RTYPE compiled_block_1_2361( CONT_PARAMS );
static RTYPE compiled_block_1_2356( CONT_PARAMS );
static RTYPE compiled_block_1_2365( CONT_PARAMS );
static RTYPE compiled_block_1_2357( CONT_PARAMS );
static RTYPE compiled_block_1_2358( CONT_PARAMS );
static RTYPE compiled_block_1_2360( CONT_PARAMS );
static RTYPE compiled_block_1_2363( CONT_PARAMS );
static RTYPE compiled_temp_1_189( CONT_PARAMS );
static RTYPE compiled_temp_1_188( CONT_PARAMS );
static RTYPE compiled_block_1_2353( CONT_PARAMS );
static RTYPE compiled_start_1_180( CONT_PARAMS );
static RTYPE compiled_start_1_101( CONT_PARAMS );
static RTYPE compiled_block_1_2346( CONT_PARAMS );
static RTYPE compiled_block_1_2348( CONT_PARAMS );
static RTYPE compiled_block_1_2344( CONT_PARAMS );
static RTYPE compiled_start_1_191( CONT_PARAMS );
static RTYPE compiled_start_1_190( CONT_PARAMS );
static RTYPE compiled_block_1_2334( CONT_PARAMS );
static RTYPE compiled_block_1_2339( CONT_PARAMS );
static RTYPE compiled_start_1_193( CONT_PARAMS );
static RTYPE compiled_block_1_2337( CONT_PARAMS );
static RTYPE compiled_block_1_2336( CONT_PARAMS );
static RTYPE compiled_temp_1_195( CONT_PARAMS );
static RTYPE compiled_start_1_194( CONT_PARAMS );
static RTYPE compiled_block_1_2319( CONT_PARAMS );
static RTYPE compiled_block_1_2326( CONT_PARAMS );
static RTYPE compiled_block_1_2321( CONT_PARAMS );
static RTYPE compiled_block_1_2330( CONT_PARAMS );
static RTYPE compiled_block_1_2322( CONT_PARAMS );
static RTYPE compiled_block_1_2323( CONT_PARAMS );
static RTYPE compiled_block_1_2325( CONT_PARAMS );
static RTYPE compiled_block_1_2328( CONT_PARAMS );
static RTYPE compiled_temp_1_197( CONT_PARAMS );
static RTYPE compiled_temp_1_196( CONT_PARAMS );
static RTYPE compiled_block_1_2318( CONT_PARAMS );
static RTYPE compiled_start_1_192( CONT_PARAMS );
static RTYPE compiled_block_1_2316( CONT_PARAMS );
static RTYPE compiled_block_1_2310( CONT_PARAMS );
static RTYPE compiled_start_1_100( CONT_PARAMS );
static RTYPE compiled_block_1_2313( CONT_PARAMS );
static RTYPE compiled_block_1_2312( CONT_PARAMS );
static RTYPE compiled_temp_1_200( CONT_PARAMS );
static RTYPE compiled_block_1_2314( CONT_PARAMS );
static RTYPE compiled_start_1_199( CONT_PARAMS );
static RTYPE compiled_block_1_2308( CONT_PARAMS );
static RTYPE compiled_block_1_2307( CONT_PARAMS );
static RTYPE compiled_temp_1_201( CONT_PARAMS );
static RTYPE compiled_start_1_198( CONT_PARAMS );
static RTYPE compiled_start_1_99( CONT_PARAMS );
static RTYPE compiled_block_1_2287( CONT_PARAMS );
static RTYPE compiled_block_1_2296( CONT_PARAMS );
static RTYPE compiled_block_1_2304( CONT_PARAMS );
static RTYPE compiled_block_1_2298( CONT_PARAMS );
static RTYPE compiled_temp_1_206( CONT_PARAMS );
static RTYPE compiled_block_1_2295( CONT_PARAMS );
static RTYPE compiled_temp_1_205( CONT_PARAMS );
static RTYPE compiled_block_1_2286( CONT_PARAMS );
static RTYPE compiled_temp_1_204( CONT_PARAMS );
static RTYPE compiled_block_1_2291( CONT_PARAMS );
static RTYPE compiled_block_1_2292( CONT_PARAMS );
static RTYPE compiled_block_1_2289( CONT_PARAMS );
static RTYPE compiled_temp_1_203( CONT_PARAMS );
static RTYPE compiled_start_1_202( CONT_PARAMS );
static RTYPE compiled_block_1_2301( CONT_PARAMS );
static RTYPE compiled_block_1_2300( CONT_PARAMS );
static RTYPE compiled_temp_1_208( CONT_PARAMS );
static RTYPE compiled_block_1_2302( CONT_PARAMS );
static RTYPE compiled_start_1_207( CONT_PARAMS );
static RTYPE compiled_start_1_98( CONT_PARAMS );
static RTYPE compiled_start_1_97( CONT_PARAMS );
static RTYPE compiled_temp_1_211( CONT_PARAMS );
static RTYPE compiled_start_1_210( CONT_PARAMS );
static RTYPE compiled_block_1_2280( CONT_PARAMS );
static RTYPE compiled_block_1_2279( CONT_PARAMS );
static RTYPE compiled_temp_1_213( CONT_PARAMS );
static RTYPE compiled_start_1_212( CONT_PARAMS );
static RTYPE compiled_start_1_209( CONT_PARAMS );
static RTYPE compiled_block_1_2276( CONT_PARAMS );
static RTYPE compiled_temp_1_214( CONT_PARAMS );
static RTYPE compiled_block_1_2271( CONT_PARAMS );
static RTYPE compiled_start_1_96( CONT_PARAMS );
static RTYPE compiled_block_1_2274( CONT_PARAMS );
static RTYPE compiled_block_1_2273( CONT_PARAMS );
static RTYPE compiled_start_1_215( CONT_PARAMS );
static RTYPE compiled_start_1_95( CONT_PARAMS );
static RTYPE compiled_temp_1_218( CONT_PARAMS );
static RTYPE compiled_start_1_217( CONT_PARAMS );
static RTYPE compiled_block_1_2265( CONT_PARAMS );
static RTYPE compiled_block_1_2267( CONT_PARAMS );
static RTYPE compiled_block_1_2262( CONT_PARAMS );
static RTYPE compiled_block_1_2263( CONT_PARAMS );
static RTYPE compiled_block_1_2264( CONT_PARAMS );
static RTYPE compiled_block_1_2266( CONT_PARAMS );
static RTYPE compiled_block_1_2261( CONT_PARAMS );
static RTYPE compiled_temp_1_220( CONT_PARAMS );
static RTYPE compiled_start_1_219( CONT_PARAMS );
static RTYPE compiled_start_1_216( CONT_PARAMS );
static RTYPE compiled_start_1_94( CONT_PARAMS );
static RTYPE compiled_block_1_2257( CONT_PARAMS );
static RTYPE compiled_temp_1_224( CONT_PARAMS );
static RTYPE compiled_temp_1_223( CONT_PARAMS );
static RTYPE compiled_start_1_222( CONT_PARAMS );
static RTYPE compiled_block_1_2255( CONT_PARAMS );
static RTYPE compiled_block_1_2254( CONT_PARAMS );
static RTYPE compiled_block_1_2253( CONT_PARAMS );
static RTYPE compiled_temp_1_226( CONT_PARAMS );
static RTYPE compiled_start_1_225( CONT_PARAMS );
static RTYPE compiled_start_1_221( CONT_PARAMS );
static RTYPE compiled_block_1_2250( CONT_PARAMS );
static RTYPE compiled_temp_1_227( CONT_PARAMS );
static RTYPE compiled_start_1_93( CONT_PARAMS );
static RTYPE compiled_start_1_92( CONT_PARAMS );
static RTYPE compiled_block_1_2244( CONT_PARAMS );
static RTYPE compiled_block_1_2246( CONT_PARAMS );
static RTYPE compiled_block_1_2242( CONT_PARAMS );
static RTYPE compiled_start_1_229( CONT_PARAMS );
static RTYPE compiled_start_1_228( CONT_PARAMS );
static RTYPE compiled_start_1_231( CONT_PARAMS );
static RTYPE compiled_block_1_2221( CONT_PARAMS );
static RTYPE compiled_block_1_2220( CONT_PARAMS );
static RTYPE compiled_start_1_233( CONT_PARAMS );
static RTYPE compiled_block_1_2226( CONT_PARAMS );
static RTYPE compiled_block_1_2235( CONT_PARAMS );
static RTYPE compiled_block_1_2225( CONT_PARAMS );
static RTYPE compiled_temp_1_237( CONT_PARAMS );
static RTYPE compiled_block_1_2223( CONT_PARAMS );
static RTYPE compiled_temp_1_236( CONT_PARAMS );
static RTYPE compiled_temp_1_235( CONT_PARAMS );
static RTYPE compiled_start_1_234( CONT_PARAMS );
static RTYPE compiled_block_1_2231( CONT_PARAMS );
static RTYPE compiled_block_1_2227( CONT_PARAMS );
static RTYPE compiled_block_1_2233( CONT_PARAMS );
static RTYPE compiled_temp_1_241( CONT_PARAMS );
static RTYPE compiled_block_1_2230( CONT_PARAMS );
static RTYPE compiled_temp_1_240( CONT_PARAMS );
static RTYPE compiled_block_1_2228( CONT_PARAMS );
static RTYPE compiled_temp_1_239( CONT_PARAMS );
static RTYPE compiled_start_1_238( CONT_PARAMS );
static RTYPE compiled_start_1_232( CONT_PARAMS );
static RTYPE compiled_block_1_2209( CONT_PARAMS );
static RTYPE compiled_block_1_2215( CONT_PARAMS );
static RTYPE compiled_block_1_2210( CONT_PARAMS );
static RTYPE compiled_block_1_2211( CONT_PARAMS );
static RTYPE compiled_block_1_2213( CONT_PARAMS );
static RTYPE compiled_temp_1_242( CONT_PARAMS );
static RTYPE compiled_block_1_2207( CONT_PARAMS );
static RTYPE compiled_start_1_230( CONT_PARAMS );
static RTYPE compiled_start_1_91( CONT_PARAMS );
static RTYPE compiled_block_1_2201( CONT_PARAMS );
static RTYPE compiled_block_1_2197( CONT_PARAMS );
static RTYPE compiled_block_1_2203( CONT_PARAMS );
static RTYPE compiled_temp_1_246( CONT_PARAMS );
static RTYPE compiled_block_1_2200( CONT_PARAMS );
static RTYPE compiled_temp_1_245( CONT_PARAMS );
static RTYPE compiled_block_1_2198( CONT_PARAMS );
static RTYPE compiled_temp_1_244( CONT_PARAMS );
static RTYPE compiled_start_1_243( CONT_PARAMS );
static RTYPE compiled_start_1_90( CONT_PARAMS );
static RTYPE compiled_block_1_2191( CONT_PARAMS );
static RTYPE compiled_block_1_2193( CONT_PARAMS );
static RTYPE compiled_block_1_2189( CONT_PARAMS );
static RTYPE compiled_start_1_248( CONT_PARAMS );
static RTYPE compiled_start_1_247( CONT_PARAMS );
static RTYPE compiled_block_1_2164( CONT_PARAMS );
static RTYPE compiled_block_1_2165( CONT_PARAMS );
static RTYPE compiled_block_1_2161( CONT_PARAMS );
static RTYPE compiled_block_1_2162( CONT_PARAMS );
static RTYPE compiled_block_1_2163( CONT_PARAMS );
static RTYPE compiled_block_1_2185( CONT_PARAMS );
static RTYPE compiled_temp_1_253( CONT_PARAMS );
static RTYPE compiled_temp_1_252( CONT_PARAMS );
static RTYPE compiled_temp_1_251( CONT_PARAMS );
static RTYPE compiled_start_1_250( CONT_PARAMS );
static RTYPE compiled_block_1_2168( CONT_PARAMS );
static RTYPE compiled_block_1_2167( CONT_PARAMS );
static RTYPE compiled_temp_1_255( CONT_PARAMS );
static RTYPE compiled_start_1_254( CONT_PARAMS );
static RTYPE compiled_block_1_2180( CONT_PARAMS );
static RTYPE compiled_block_1_2182( CONT_PARAMS );
static RTYPE compiled_block_1_2174( CONT_PARAMS );
static RTYPE compiled_block_1_2176( CONT_PARAMS );
static RTYPE compiled_block_1_2179( CONT_PARAMS );
static RTYPE compiled_temp_1_263( CONT_PARAMS );
static RTYPE compiled_temp_1_262( CONT_PARAMS );
static RTYPE compiled_temp_1_261( CONT_PARAMS );
static RTYPE compiled_block_1_2177( CONT_PARAMS );
static RTYPE compiled_temp_1_260( CONT_PARAMS );
static RTYPE compiled_block_1_2170( CONT_PARAMS );
static RTYPE compiled_temp_1_259( CONT_PARAMS );
static RTYPE compiled_block_1_2172( CONT_PARAMS );
static RTYPE compiled_block_1_2173( CONT_PARAMS );
static RTYPE compiled_block_1_2171( CONT_PARAMS );
static RTYPE compiled_temp_1_258( CONT_PARAMS );
static RTYPE compiled_temp_1_257( CONT_PARAMS );
static RTYPE compiled_start_1_256( CONT_PARAMS );
static RTYPE compiled_start_1_249( CONT_PARAMS );
static RTYPE compiled_temp_1_265( CONT_PARAMS );
static RTYPE compiled_temp_1_264( CONT_PARAMS );
static RTYPE compiled_block_1_2142( CONT_PARAMS );
static RTYPE compiled_start_1_89( CONT_PARAMS );
static RTYPE compiled_block_1_2153( CONT_PARAMS );
static RTYPE compiled_block_1_2148( CONT_PARAMS );
static RTYPE compiled_block_1_2147( CONT_PARAMS );
static RTYPE compiled_block_1_2146( CONT_PARAMS );
static RTYPE compiled_temp_1_276( CONT_PARAMS );
static RTYPE compiled_block_1_2155( CONT_PARAMS );
static RTYPE compiled_temp_1_275( CONT_PARAMS );
static RTYPE compiled_temp_1_274( CONT_PARAMS );
static RTYPE compiled_block_1_2151( CONT_PARAMS );
static RTYPE compiled_temp_1_273( CONT_PARAMS );
static RTYPE compiled_temp_1_272( CONT_PARAMS );
static RTYPE compiled_temp_1_271( CONT_PARAMS );
static RTYPE compiled_block_1_2149( CONT_PARAMS );
static RTYPE compiled_temp_1_270( CONT_PARAMS );
static RTYPE compiled_temp_1_269( CONT_PARAMS );
static RTYPE compiled_block_1_2144( CONT_PARAMS );
static RTYPE compiled_temp_1_268( CONT_PARAMS );
static RTYPE compiled_temp_1_267( CONT_PARAMS );
static RTYPE compiled_start_1_266( CONT_PARAMS );
static RTYPE compiled_start_1_88( CONT_PARAMS );
static RTYPE compiled_start_1_278( CONT_PARAMS );
static RTYPE compiled_start_1_277( CONT_PARAMS );
static RTYPE compiled_temp_1_283( CONT_PARAMS );
static RTYPE compiled_temp_1_282( CONT_PARAMS );
static RTYPE compiled_temp_1_281( CONT_PARAMS );
static RTYPE compiled_start_1_280( CONT_PARAMS );
static RTYPE compiled_block_1_2133( CONT_PARAMS );
static RTYPE compiled_temp_1_287( CONT_PARAMS );
static RTYPE compiled_block_1_2136( CONT_PARAMS );
static RTYPE compiled_block_1_2134( CONT_PARAMS );
static RTYPE compiled_temp_1_286( CONT_PARAMS );
static RTYPE compiled_temp_1_285( CONT_PARAMS );
static RTYPE compiled_start_1_284( CONT_PARAMS );
static RTYPE compiled_start_1_279( CONT_PARAMS );
static RTYPE compiled_start_1_87( CONT_PARAMS );
static RTYPE compiled_start_1_289( CONT_PARAMS );
static RTYPE compiled_start_1_288( CONT_PARAMS );
static RTYPE compiled_temp_1_294( CONT_PARAMS );
static RTYPE compiled_temp_1_293( CONT_PARAMS );
static RTYPE compiled_temp_1_292( CONT_PARAMS );
static RTYPE compiled_start_1_291( CONT_PARAMS );
static RTYPE compiled_block_1_2122( CONT_PARAMS );
static RTYPE compiled_temp_1_298( CONT_PARAMS );
static RTYPE compiled_block_1_2125( CONT_PARAMS );
static RTYPE compiled_block_1_2123( CONT_PARAMS );
static RTYPE compiled_temp_1_297( CONT_PARAMS );
static RTYPE compiled_temp_1_296( CONT_PARAMS );
static RTYPE compiled_start_1_295( CONT_PARAMS );
static RTYPE compiled_start_1_290( CONT_PARAMS );
static RTYPE compiled_temp_1_304( CONT_PARAMS );
static RTYPE compiled_temp_1_303( CONT_PARAMS );
static RTYPE compiled_temp_1_302( CONT_PARAMS );
static RTYPE compiled_temp_1_301( CONT_PARAMS );
static RTYPE compiled_block_1_2107( CONT_PARAMS );
static RTYPE compiled_temp_1_299( CONT_PARAMS );
static RTYPE compiled_start_1_86( CONT_PARAMS );
static RTYPE compiled_block_1_2117( CONT_PARAMS );
static RTYPE compiled_block_1_2116( CONT_PARAMS );
static RTYPE compiled_block_1_2115( CONT_PARAMS );
static RTYPE compiled_temp_1_306( CONT_PARAMS );
static RTYPE compiled_start_1_305( CONT_PARAMS );
static RTYPE compiled_block_1_2111( CONT_PARAMS );
static RTYPE compiled_block_1_2110( CONT_PARAMS );
static RTYPE compiled_block_1_2109( CONT_PARAMS );
static RTYPE compiled_temp_1_307( CONT_PARAMS );
static RTYPE compiled_start_1_300( CONT_PARAMS );
static RTYPE compiled_start_1_85( CONT_PARAMS );
static RTYPE compiled_start_1_309( CONT_PARAMS );
static RTYPE compiled_block_1_2102( CONT_PARAMS );
static RTYPE compiled_temp_1_311( CONT_PARAMS );
static RTYPE compiled_temp_1_310( CONT_PARAMS );
static RTYPE compiled_start_1_308( CONT_PARAMS );
static RTYPE compiled_start_1_84( CONT_PARAMS );
static RTYPE compiled_start_1_313( CONT_PARAMS );
static RTYPE compiled_temp_1_314( CONT_PARAMS );
static RTYPE compiled_start_1_312( CONT_PARAMS );
static RTYPE compiled_block_1_2097( CONT_PARAMS );
static RTYPE compiled_block_1_2096( CONT_PARAMS );
static RTYPE compiled_temp_1_316( CONT_PARAMS );
static RTYPE compiled_start_1_315( CONT_PARAMS );
static RTYPE compiled_start_1_83( CONT_PARAMS );
static RTYPE compiled_start_1_318( CONT_PARAMS );
static RTYPE compiled_block_1_2083( CONT_PARAMS );
static RTYPE compiled_block_1_2073( CONT_PARAMS );
static RTYPE compiled_block_1_2071( CONT_PARAMS );
static RTYPE compiled_block_1_2063( CONT_PARAMS );
static RTYPE compiled_start_1_317( CONT_PARAMS );
static RTYPE compiled_block_1_2086( CONT_PARAMS );
static RTYPE compiled_block_1_2088( CONT_PARAMS );
static RTYPE compiled_block_1_2089( CONT_PARAMS );
static RTYPE compiled_temp_1_324( CONT_PARAMS );
static RTYPE compiled_block_1_2087( CONT_PARAMS );
static RTYPE compiled_temp_1_323( CONT_PARAMS );
static RTYPE compiled_block_1_2085( CONT_PARAMS );
static RTYPE compiled_temp_1_322( CONT_PARAMS );
static RTYPE compiled_start_1_321( CONT_PARAMS );
static RTYPE compiled_block_1_2076( CONT_PARAMS );
static RTYPE compiled_block_1_2078( CONT_PARAMS );
static RTYPE compiled_block_1_2079( CONT_PARAMS );
static RTYPE compiled_temp_1_327( CONT_PARAMS );
static RTYPE compiled_block_1_2077( CONT_PARAMS );
static RTYPE compiled_temp_1_326( CONT_PARAMS );
static RTYPE compiled_block_1_2075( CONT_PARAMS );
static RTYPE compiled_temp_1_325( CONT_PARAMS );
static RTYPE compiled_start_1_320( CONT_PARAMS );
static RTYPE compiled_block_1_2066( CONT_PARAMS );
static RTYPE compiled_block_1_2067( CONT_PARAMS );
static RTYPE compiled_block_1_2068( CONT_PARAMS );
static RTYPE compiled_temp_1_329( CONT_PARAMS );
static RTYPE compiled_block_1_2065( CONT_PARAMS );
static RTYPE compiled_temp_1_328( CONT_PARAMS );
static RTYPE compiled_start_1_319( CONT_PARAMS );
static RTYPE compiled_start_1_82( CONT_PARAMS );
static RTYPE compiled_start_1_331( CONT_PARAMS );
static RTYPE compiled_block_1_2050( CONT_PARAMS );
static RTYPE compiled_temp_1_336( CONT_PARAMS );
static RTYPE compiled_block_1_2040( CONT_PARAMS );
static RTYPE compiled_temp_1_334( CONT_PARAMS );
static RTYPE compiled_block_1_2038( CONT_PARAMS );
static RTYPE compiled_block_1_2030( CONT_PARAMS );
static RTYPE compiled_temp_1_332( CONT_PARAMS );
static RTYPE compiled_start_1_330( CONT_PARAMS );
static RTYPE compiled_block_1_2053( CONT_PARAMS );
static RTYPE compiled_block_1_2052( CONT_PARAMS );
static RTYPE compiled_block_1_2056( CONT_PARAMS );
static RTYPE compiled_block_1_2054( CONT_PARAMS );
static RTYPE compiled_temp_1_338( CONT_PARAMS );
static RTYPE compiled_start_1_337( CONT_PARAMS );
static RTYPE compiled_block_1_2043( CONT_PARAMS );
static RTYPE compiled_block_1_2042( CONT_PARAMS );
static RTYPE compiled_block_1_2046( CONT_PARAMS );
static RTYPE compiled_block_1_2044( CONT_PARAMS );
static RTYPE compiled_temp_1_339( CONT_PARAMS );
static RTYPE compiled_start_1_335( CONT_PARAMS );
static RTYPE compiled_block_1_2033( CONT_PARAMS );
static RTYPE compiled_block_1_2032( CONT_PARAMS );
static RTYPE compiled_block_1_2035( CONT_PARAMS );
static RTYPE compiled_temp_1_340( CONT_PARAMS );
static RTYPE compiled_start_1_333( CONT_PARAMS );
static RTYPE compiled_start_1_81( CONT_PARAMS );
static RTYPE compiled_start_1_342( CONT_PARAMS );
static RTYPE compiled_block_1_2017( CONT_PARAMS );
static RTYPE compiled_block_1_2007( CONT_PARAMS );
static RTYPE compiled_block_1_2005( CONT_PARAMS );
static RTYPE compiled_block_1_1997( CONT_PARAMS );
static RTYPE compiled_start_1_341( CONT_PARAMS );
static RTYPE compiled_block_1_2020( CONT_PARAMS );
static RTYPE compiled_block_1_2019( CONT_PARAMS );
static RTYPE compiled_block_1_2023( CONT_PARAMS );
static RTYPE compiled_block_1_2021( CONT_PARAMS );
static RTYPE compiled_temp_1_346( CONT_PARAMS );
static RTYPE compiled_start_1_345( CONT_PARAMS );
static RTYPE compiled_block_1_2010( CONT_PARAMS );
static RTYPE compiled_block_1_2009( CONT_PARAMS );
static RTYPE compiled_block_1_2013( CONT_PARAMS );
static RTYPE compiled_block_1_2011( CONT_PARAMS );
static RTYPE compiled_temp_1_347( CONT_PARAMS );
static RTYPE compiled_start_1_344( CONT_PARAMS );
static RTYPE compiled_block_1_2000( CONT_PARAMS );
static RTYPE compiled_block_1_1999( CONT_PARAMS );
static RTYPE compiled_block_1_2002( CONT_PARAMS );
static RTYPE compiled_temp_1_348( CONT_PARAMS );
static RTYPE compiled_start_1_343( CONT_PARAMS );
static RTYPE compiled_start_1_80( CONT_PARAMS );
static RTYPE compiled_start_1_350( CONT_PARAMS );
static RTYPE compiled_block_1_1984( CONT_PARAMS );
static RTYPE compiled_temp_1_355( CONT_PARAMS );
static RTYPE compiled_block_1_1974( CONT_PARAMS );
static RTYPE compiled_temp_1_353( CONT_PARAMS );
static RTYPE compiled_block_1_1972( CONT_PARAMS );
static RTYPE compiled_block_1_1964( CONT_PARAMS );
static RTYPE compiled_temp_1_351( CONT_PARAMS );
static RTYPE compiled_start_1_349( CONT_PARAMS );
static RTYPE compiled_block_1_1987( CONT_PARAMS );
static RTYPE compiled_block_1_1986( CONT_PARAMS );
static RTYPE compiled_block_1_1990( CONT_PARAMS );
static RTYPE compiled_block_1_1988( CONT_PARAMS );
static RTYPE compiled_temp_1_357( CONT_PARAMS );
static RTYPE compiled_start_1_356( CONT_PARAMS );
static RTYPE compiled_block_1_1977( CONT_PARAMS );
static RTYPE compiled_block_1_1976( CONT_PARAMS );
static RTYPE compiled_block_1_1980( CONT_PARAMS );
static RTYPE compiled_block_1_1978( CONT_PARAMS );
static RTYPE compiled_temp_1_358( CONT_PARAMS );
static RTYPE compiled_start_1_354( CONT_PARAMS );
static RTYPE compiled_block_1_1967( CONT_PARAMS );
static RTYPE compiled_block_1_1966( CONT_PARAMS );
static RTYPE compiled_block_1_1969( CONT_PARAMS );
static RTYPE compiled_temp_1_359( CONT_PARAMS );
static RTYPE compiled_start_1_352( CONT_PARAMS );
static RTYPE compiled_start_1_79( CONT_PARAMS );
static RTYPE compiled_start_1_361( CONT_PARAMS );
static RTYPE compiled_block_1_1951( CONT_PARAMS );
static RTYPE compiled_block_1_1941( CONT_PARAMS );
static RTYPE compiled_block_1_1939( CONT_PARAMS );
static RTYPE compiled_block_1_1931( CONT_PARAMS );
static RTYPE compiled_start_1_360( CONT_PARAMS );
static RTYPE compiled_block_1_1954( CONT_PARAMS );
static RTYPE compiled_block_1_1953( CONT_PARAMS );
static RTYPE compiled_block_1_1957( CONT_PARAMS );
static RTYPE compiled_block_1_1955( CONT_PARAMS );
static RTYPE compiled_temp_1_365( CONT_PARAMS );
static RTYPE compiled_start_1_364( CONT_PARAMS );
static RTYPE compiled_block_1_1944( CONT_PARAMS );
static RTYPE compiled_block_1_1943( CONT_PARAMS );
static RTYPE compiled_block_1_1947( CONT_PARAMS );
static RTYPE compiled_block_1_1945( CONT_PARAMS );
static RTYPE compiled_temp_1_366( CONT_PARAMS );
static RTYPE compiled_start_1_363( CONT_PARAMS );
static RTYPE compiled_block_1_1934( CONT_PARAMS );
static RTYPE compiled_block_1_1933( CONT_PARAMS );
static RTYPE compiled_block_1_1936( CONT_PARAMS );
static RTYPE compiled_temp_1_367( CONT_PARAMS );
static RTYPE compiled_start_1_362( CONT_PARAMS );
static RTYPE compiled_start_1_78( CONT_PARAMS );
static RTYPE compiled_start_1_369( CONT_PARAMS );
static RTYPE compiled_block_1_1927( CONT_PARAMS );
static RTYPE compiled_block_1_1922( CONT_PARAMS );
static RTYPE compiled_block_1_1913( CONT_PARAMS );
static RTYPE compiled_block_1_1918( CONT_PARAMS );
static RTYPE compiled_block_1_1916( CONT_PARAMS );
static RTYPE compiled_block_1_1917( CONT_PARAMS );
static RTYPE compiled_block_1_1914( CONT_PARAMS );
static RTYPE compiled_block_1_1912( CONT_PARAMS );
static RTYPE compiled_block_1_1903( CONT_PARAMS );
static RTYPE compiled_block_1_1910( CONT_PARAMS );
static RTYPE compiled_temp_1_372( CONT_PARAMS );
static RTYPE compiled_block_1_1908( CONT_PARAMS );
static RTYPE compiled_temp_1_370( CONT_PARAMS );
static RTYPE compiled_start_1_368( CONT_PARAMS );
static RTYPE compiled_block_1_1926( CONT_PARAMS );
static RTYPE compiled_block_1_1925( CONT_PARAMS );
static RTYPE compiled_block_1_1923( CONT_PARAMS );
static RTYPE compiled_start_1_374( CONT_PARAMS );
static RTYPE compiled_block_1_1921( CONT_PARAMS );
static RTYPE compiled_temp_1_375( CONT_PARAMS );
static RTYPE compiled_block_1_1919( CONT_PARAMS );
static RTYPE compiled_start_1_373( CONT_PARAMS );
static RTYPE compiled_block_1_1907( CONT_PARAMS );
static RTYPE compiled_block_1_1906( CONT_PARAMS );
static RTYPE compiled_block_1_1904( CONT_PARAMS );
static RTYPE compiled_start_1_371( CONT_PARAMS );
static RTYPE compiled_start_1_77( CONT_PARAMS );
static RTYPE compiled_start_1_377( CONT_PARAMS );
static RTYPE compiled_block_1_1899( CONT_PARAMS );
static RTYPE compiled_block_1_1894( CONT_PARAMS );
static RTYPE compiled_block_1_1885( CONT_PARAMS );
static RTYPE compiled_block_1_1890( CONT_PARAMS );
static RTYPE compiled_block_1_1888( CONT_PARAMS );
static RTYPE compiled_block_1_1889( CONT_PARAMS );
static RTYPE compiled_block_1_1886( CONT_PARAMS );
static RTYPE compiled_block_1_1884( CONT_PARAMS );
static RTYPE compiled_block_1_1875( CONT_PARAMS );
static RTYPE compiled_block_1_1882( CONT_PARAMS );
static RTYPE compiled_temp_1_380( CONT_PARAMS );
static RTYPE compiled_block_1_1880( CONT_PARAMS );
static RTYPE compiled_temp_1_378( CONT_PARAMS );
static RTYPE compiled_start_1_376( CONT_PARAMS );
static RTYPE compiled_block_1_1898( CONT_PARAMS );
static RTYPE compiled_block_1_1897( CONT_PARAMS );
static RTYPE compiled_block_1_1895( CONT_PARAMS );
static RTYPE compiled_start_1_382( CONT_PARAMS );
static RTYPE compiled_temp_1_383( CONT_PARAMS );
static RTYPE compiled_block_1_1893( CONT_PARAMS );
static RTYPE compiled_block_1_1891( CONT_PARAMS );
static RTYPE compiled_start_1_381( CONT_PARAMS );
static RTYPE compiled_block_1_1879( CONT_PARAMS );
static RTYPE compiled_block_1_1878( CONT_PARAMS );
static RTYPE compiled_block_1_1876( CONT_PARAMS );
static RTYPE compiled_start_1_379( CONT_PARAMS );
static RTYPE compiled_start_1_76( CONT_PARAMS );
static RTYPE compiled_block_1_1868( CONT_PARAMS );
static RTYPE compiled_block_1_1870( CONT_PARAMS );
static RTYPE compiled_block_1_1866( CONT_PARAMS );
static RTYPE compiled_start_1_385( CONT_PARAMS );
static RTYPE compiled_start_1_384( CONT_PARAMS );
static RTYPE compiled_start_1_387( CONT_PARAMS );
static RTYPE compiled_block_1_1862( CONT_PARAMS );
static RTYPE compiled_temp_1_391( CONT_PARAMS );
static RTYPE compiled_block_1_1860( CONT_PARAMS );
static RTYPE compiled_temp_1_390( CONT_PARAMS );
static RTYPE compiled_temp_1_389( CONT_PARAMS );
static RTYPE compiled_temp_1_388( CONT_PARAMS );
static RTYPE compiled_start_1_386( CONT_PARAMS );
static RTYPE compiled_start_1_75( CONT_PARAMS );
static RTYPE compiled_block_1_1853( CONT_PARAMS );
static RTYPE compiled_block_1_1855( CONT_PARAMS );
static RTYPE compiled_block_1_1851( CONT_PARAMS );
static RTYPE compiled_start_1_393( CONT_PARAMS );
static RTYPE compiled_start_1_392( CONT_PARAMS );
static RTYPE compiled_start_1_395( CONT_PARAMS );
static RTYPE compiled_block_1_1847( CONT_PARAMS );
static RTYPE compiled_block_1_1845( CONT_PARAMS );
static RTYPE compiled_temp_1_398( CONT_PARAMS );
static RTYPE compiled_temp_1_397( CONT_PARAMS );
static RTYPE compiled_temp_1_396( CONT_PARAMS );
static RTYPE compiled_start_1_394( CONT_PARAMS );
static RTYPE compiled_start_1_74( CONT_PARAMS );
static RTYPE compiled_block_1_1841( CONT_PARAMS );
static RTYPE compiled_block_1_1839( CONT_PARAMS );
static RTYPE compiled_start_1_400( CONT_PARAMS );
static RTYPE compiled_start_1_399( CONT_PARAMS );
static RTYPE compiled_start_1_402( CONT_PARAMS );
static RTYPE compiled_block_1_1833( CONT_PARAMS );
static RTYPE compiled_temp_1_403( CONT_PARAMS );
static RTYPE compiled_block_1_1834( CONT_PARAMS );
static RTYPE compiled_block_1_1831( CONT_PARAMS );
static RTYPE compiled_start_1_401( CONT_PARAMS );
static RTYPE compiled_start_1_73( CONT_PARAMS );
static RTYPE compiled_block_1_1828( CONT_PARAMS );
static RTYPE compiled_block_1_1826( CONT_PARAMS );
static RTYPE compiled_start_1_405( CONT_PARAMS );
static RTYPE compiled_start_1_404( CONT_PARAMS );
static RTYPE compiled_start_1_407( CONT_PARAMS );
static RTYPE compiled_block_1_1821( CONT_PARAMS );
static RTYPE compiled_temp_1_408( CONT_PARAMS );
static RTYPE compiled_block_1_1819( CONT_PARAMS );
static RTYPE compiled_start_1_406( CONT_PARAMS );
static RTYPE compiled_start_1_72( CONT_PARAMS );
static RTYPE compiled_block_1_1816( CONT_PARAMS );
static RTYPE compiled_block_1_1814( CONT_PARAMS );
static RTYPE compiled_start_1_410( CONT_PARAMS );
static RTYPE compiled_start_1_409( CONT_PARAMS );
static RTYPE compiled_start_1_412( CONT_PARAMS );
static RTYPE compiled_block_1_1809( CONT_PARAMS );
static RTYPE compiled_block_1_1807( CONT_PARAMS );
static RTYPE compiled_start_1_411( CONT_PARAMS );
static RTYPE compiled_block_1_1805( CONT_PARAMS );
static RTYPE compiled_temp_1_413( CONT_PARAMS );
static RTYPE compiled_start_1_71( CONT_PARAMS );
static RTYPE compiled_block_1_1803( CONT_PARAMS );
static RTYPE compiled_start_1_70( CONT_PARAMS );
static RTYPE compiled_block_1_1801( CONT_PARAMS );
static RTYPE compiled_temp_1_414( CONT_PARAMS );
static RTYPE compiled_start_1_69( CONT_PARAMS );
static RTYPE compiled_start_1_68( CONT_PARAMS );
static RTYPE compiled_start_1_67( CONT_PARAMS );
static RTYPE compiled_block_1_1798( CONT_PARAMS );
static RTYPE compiled_temp_1_417( CONT_PARAMS );
static RTYPE compiled_block_1_1797( CONT_PARAMS );
static RTYPE compiled_start_1_416( CONT_PARAMS );
static RTYPE compiled_start_1_415( CONT_PARAMS );
static RTYPE compiled_start_1_66( CONT_PARAMS );
static RTYPE compiled_start_1_419( CONT_PARAMS );
static RTYPE compiled_start_1_418( CONT_PARAMS );
static RTYPE compiled_start_1_65( CONT_PARAMS );
static RTYPE compiled_block_1_1785( CONT_PARAMS );
static RTYPE compiled_block_1_1783( CONT_PARAMS );
static RTYPE compiled_block_1_1782( CONT_PARAMS );
static RTYPE compiled_block_1_1788( CONT_PARAMS );
static RTYPE compiled_temp_1_421( CONT_PARAMS );
static RTYPE compiled_block_1_1789( CONT_PARAMS );
static RTYPE compiled_block_1_1786( CONT_PARAMS );
static RTYPE compiled_block_1_1784( CONT_PARAMS );
static RTYPE compiled_block_1_1780( CONT_PARAMS );
static RTYPE compiled_start_1_420( CONT_PARAMS );
static RTYPE compiled_start_1_64( CONT_PARAMS );
static RTYPE compiled_start_1_423( CONT_PARAMS );
static RTYPE compiled_start_1_422( CONT_PARAMS );
static RTYPE compiled_start_1_63( CONT_PARAMS );
static RTYPE compiled_start_1_425( CONT_PARAMS );
static RTYPE compiled_start_1_424( CONT_PARAMS );
static RTYPE compiled_start_1_62( CONT_PARAMS );
static RTYPE compiled_start_1_427( CONT_PARAMS );
static RTYPE compiled_start_1_426( CONT_PARAMS );
static RTYPE compiled_start_1_61( CONT_PARAMS );
static RTYPE compiled_start_1_429( CONT_PARAMS );
static RTYPE compiled_start_1_428( CONT_PARAMS );
static RTYPE compiled_start_1_60( CONT_PARAMS );
static RTYPE compiled_block_1_1758( CONT_PARAMS );
static RTYPE compiled_block_1_1764( CONT_PARAMS );
static RTYPE compiled_block_1_1759( CONT_PARAMS );
static RTYPE compiled_block_1_1760( CONT_PARAMS );
static RTYPE compiled_block_1_1762( CONT_PARAMS );
static RTYPE compiled_temp_1_432( CONT_PARAMS );
static RTYPE compiled_block_1_1756( CONT_PARAMS );
static RTYPE compiled_start_1_431( CONT_PARAMS );
static RTYPE compiled_block_1_1749( CONT_PARAMS );
static RTYPE compiled_block_1_1750( CONT_PARAMS );
static RTYPE compiled_temp_1_433( CONT_PARAMS );
static RTYPE compiled_start_1_430( CONT_PARAMS );
static RTYPE compiled_start_1_435( CONT_PARAMS );
static RTYPE compiled_block_1_1752( CONT_PARAMS );
static RTYPE compiled_start_1_436( CONT_PARAMS );
static RTYPE compiled_start_1_434( CONT_PARAMS );
static RTYPE compiled_start_1_59( CONT_PARAMS );
static RTYPE compiled_block_1_1739( CONT_PARAMS );
static RTYPE compiled_block_1_1745( CONT_PARAMS );
static RTYPE compiled_block_1_1740( CONT_PARAMS );
static RTYPE compiled_block_1_1741( CONT_PARAMS );
static RTYPE compiled_block_1_1743( CONT_PARAMS );
static RTYPE compiled_temp_1_439( CONT_PARAMS );
static RTYPE compiled_block_1_1737( CONT_PARAMS );
static RTYPE compiled_start_1_438( CONT_PARAMS );
static RTYPE compiled_block_1_1731( CONT_PARAMS );
static RTYPE compiled_block_1_1732( CONT_PARAMS );
static RTYPE compiled_temp_1_440( CONT_PARAMS );
static RTYPE compiled_start_1_437( CONT_PARAMS );
static RTYPE compiled_start_1_442( CONT_PARAMS );
static RTYPE compiled_start_1_441( CONT_PARAMS );
static RTYPE compiled_block_1_1729( CONT_PARAMS );
static RTYPE compiled_block_1_1716( CONT_PARAMS );
static RTYPE compiled_block_1_1721( CONT_PARAMS );
static RTYPE compiled_start_1_58( CONT_PARAMS );
static RTYPE compiled_block_1_1726( CONT_PARAMS );
static RTYPE compiled_temp_1_448( CONT_PARAMS );
static RTYPE compiled_block_1_1725( CONT_PARAMS );
static RTYPE compiled_temp_1_447( CONT_PARAMS );
static RTYPE compiled_temp_1_446( CONT_PARAMS );
static RTYPE compiled_block_1_1723( CONT_PARAMS );
static RTYPE compiled_temp_1_445( CONT_PARAMS );
static RTYPE compiled_start_1_444( CONT_PARAMS );
static RTYPE compiled_temp_1_451( CONT_PARAMS );
static RTYPE compiled_block_1_1719( CONT_PARAMS );
static RTYPE compiled_temp_1_450( CONT_PARAMS );
static RTYPE compiled_temp_1_449( CONT_PARAMS );
static RTYPE compiled_start_1_443( CONT_PARAMS );
static RTYPE compiled_start_1_57( CONT_PARAMS );
static RTYPE compiled_start_1_453( CONT_PARAMS );
static RTYPE compiled_start_1_452( CONT_PARAMS );
static RTYPE compiled_block_1_1711( CONT_PARAMS );
static RTYPE compiled_temp_1_457( CONT_PARAMS );
static RTYPE compiled_block_1_1708( CONT_PARAMS );
static RTYPE compiled_block_1_1709( CONT_PARAMS );
static RTYPE compiled_temp_1_456( CONT_PARAMS );
static RTYPE compiled_start_1_455( CONT_PARAMS );
static RTYPE compiled_start_1_458( CONT_PARAMS );
static RTYPE compiled_start_1_454( CONT_PARAMS );
static RTYPE compiled_start_1_56( CONT_PARAMS );
static RTYPE compiled_start_1_460( CONT_PARAMS );
static RTYPE compiled_start_1_459( CONT_PARAMS );
static RTYPE compiled_block_1_1702( CONT_PARAMS );
static RTYPE compiled_temp_1_464( CONT_PARAMS );
static RTYPE compiled_block_1_1699( CONT_PARAMS );
static RTYPE compiled_block_1_1700( CONT_PARAMS );
static RTYPE compiled_temp_1_463( CONT_PARAMS );
static RTYPE compiled_start_1_462( CONT_PARAMS );
static RTYPE compiled_start_1_465( CONT_PARAMS );
static RTYPE compiled_start_1_461( CONT_PARAMS );
static RTYPE compiled_start_1_55( CONT_PARAMS );
static RTYPE compiled_start_1_467( CONT_PARAMS );
static RTYPE compiled_start_1_466( CONT_PARAMS );
static RTYPE compiled_block_1_1693( CONT_PARAMS );
static RTYPE compiled_temp_1_471( CONT_PARAMS );
static RTYPE compiled_block_1_1690( CONT_PARAMS );
static RTYPE compiled_block_1_1691( CONT_PARAMS );
static RTYPE compiled_temp_1_470( CONT_PARAMS );
static RTYPE compiled_start_1_469( CONT_PARAMS );
static RTYPE compiled_start_1_473( CONT_PARAMS );
static RTYPE compiled_start_1_472( CONT_PARAMS );
static RTYPE compiled_start_1_468( CONT_PARAMS );
static RTYPE compiled_start_1_54( CONT_PARAMS );
static RTYPE compiled_start_1_475( CONT_PARAMS );
static RTYPE compiled_start_1_474( CONT_PARAMS );
static RTYPE compiled_block_1_1684( CONT_PARAMS );
static RTYPE compiled_temp_1_479( CONT_PARAMS );
static RTYPE compiled_block_1_1681( CONT_PARAMS );
static RTYPE compiled_block_1_1682( CONT_PARAMS );
static RTYPE compiled_temp_1_478( CONT_PARAMS );
static RTYPE compiled_start_1_477( CONT_PARAMS );
static RTYPE compiled_start_1_481( CONT_PARAMS );
static RTYPE compiled_start_1_480( CONT_PARAMS );
static RTYPE compiled_start_1_476( CONT_PARAMS );
static RTYPE compiled_start_1_53( CONT_PARAMS );
static RTYPE compiled_start_1_483( CONT_PARAMS );
static RTYPE compiled_start_1_482( CONT_PARAMS );
static RTYPE compiled_block_1_1675( CONT_PARAMS );
static RTYPE compiled_block_1_1672( CONT_PARAMS );
static RTYPE compiled_block_1_1673( CONT_PARAMS );
static RTYPE compiled_temp_1_489( CONT_PARAMS );
static RTYPE compiled_block_1_1671( CONT_PARAMS );
static RTYPE compiled_temp_1_488( CONT_PARAMS );
static RTYPE compiled_temp_1_487( CONT_PARAMS );
static RTYPE compiled_temp_1_486( CONT_PARAMS );
static RTYPE compiled_start_1_485( CONT_PARAMS );
static RTYPE compiled_start_1_490( CONT_PARAMS );
static RTYPE compiled_start_1_484( CONT_PARAMS );
static RTYPE compiled_start_1_52( CONT_PARAMS );
static RTYPE compiled_start_1_492( CONT_PARAMS );
static RTYPE compiled_start_1_491( CONT_PARAMS );
static RTYPE compiled_block_1_1660( CONT_PARAMS );
static RTYPE compiled_block_1_1664( CONT_PARAMS );
static RTYPE compiled_block_1_1661( CONT_PARAMS );
static RTYPE compiled_block_1_1662( CONT_PARAMS );
static RTYPE compiled_temp_1_498( CONT_PARAMS );
static RTYPE compiled_temp_1_497( CONT_PARAMS );
static RTYPE compiled_temp_1_496( CONT_PARAMS );
static RTYPE compiled_temp_1_495( CONT_PARAMS );
static RTYPE compiled_start_1_494( CONT_PARAMS );
static RTYPE compiled_start_1_500( CONT_PARAMS );
static RTYPE compiled_start_1_499( CONT_PARAMS );
static RTYPE compiled_start_1_493( CONT_PARAMS );
static RTYPE compiled_start_1_51( CONT_PARAMS );
static RTYPE compiled_start_1_502( CONT_PARAMS );
static RTYPE compiled_start_1_501( CONT_PARAMS );
static RTYPE compiled_block_1_1653( CONT_PARAMS );
static RTYPE compiled_temp_1_506( CONT_PARAMS );
static RTYPE compiled_block_1_1650( CONT_PARAMS );
static RTYPE compiled_block_1_1651( CONT_PARAMS );
static RTYPE compiled_temp_1_505( CONT_PARAMS );
static RTYPE compiled_start_1_504( CONT_PARAMS );
static RTYPE compiled_start_1_507( CONT_PARAMS );
static RTYPE compiled_start_1_503( CONT_PARAMS );
static RTYPE compiled_start_1_50( CONT_PARAMS );
static RTYPE compiled_start_1_509( CONT_PARAMS );
static RTYPE compiled_start_1_508( CONT_PARAMS );
static RTYPE compiled_block_1_1644( CONT_PARAMS );
static RTYPE compiled_temp_1_513( CONT_PARAMS );
static RTYPE compiled_block_1_1641( CONT_PARAMS );
static RTYPE compiled_block_1_1642( CONT_PARAMS );
static RTYPE compiled_temp_1_512( CONT_PARAMS );
static RTYPE compiled_start_1_511( CONT_PARAMS );
static RTYPE compiled_start_1_514( CONT_PARAMS );
static RTYPE compiled_start_1_510( CONT_PARAMS );
static RTYPE compiled_start_1_49( CONT_PARAMS );
static RTYPE compiled_start_1_516( CONT_PARAMS );
static RTYPE compiled_start_1_515( CONT_PARAMS );
static RTYPE compiled_block_1_1635( CONT_PARAMS );
static RTYPE compiled_temp_1_520( CONT_PARAMS );
static RTYPE compiled_block_1_1632( CONT_PARAMS );
static RTYPE compiled_block_1_1633( CONT_PARAMS );
static RTYPE compiled_temp_1_519( CONT_PARAMS );
static RTYPE compiled_start_1_518( CONT_PARAMS );
static RTYPE compiled_start_1_522( CONT_PARAMS );
static RTYPE compiled_start_1_521( CONT_PARAMS );
static RTYPE compiled_start_1_517( CONT_PARAMS );
static RTYPE compiled_start_1_48( CONT_PARAMS );
static RTYPE compiled_start_1_524( CONT_PARAMS );
static RTYPE compiled_start_1_523( CONT_PARAMS );
static RTYPE compiled_block_1_1626( CONT_PARAMS );
static RTYPE compiled_temp_1_528( CONT_PARAMS );
static RTYPE compiled_block_1_1623( CONT_PARAMS );
static RTYPE compiled_block_1_1624( CONT_PARAMS );
static RTYPE compiled_temp_1_527( CONT_PARAMS );
static RTYPE compiled_start_1_526( CONT_PARAMS );
static RTYPE compiled_start_1_530( CONT_PARAMS );
static RTYPE compiled_start_1_529( CONT_PARAMS );
static RTYPE compiled_start_1_525( CONT_PARAMS );
static RTYPE compiled_start_1_47( CONT_PARAMS );
static RTYPE compiled_start_1_532( CONT_PARAMS );
static RTYPE compiled_start_1_531( CONT_PARAMS );
static RTYPE compiled_block_1_1617( CONT_PARAMS );
static RTYPE compiled_block_1_1614( CONT_PARAMS );
static RTYPE compiled_block_1_1615( CONT_PARAMS );
static RTYPE compiled_temp_1_538( CONT_PARAMS );
static RTYPE compiled_block_1_1613( CONT_PARAMS );
static RTYPE compiled_temp_1_537( CONT_PARAMS );
static RTYPE compiled_temp_1_536( CONT_PARAMS );
static RTYPE compiled_temp_1_535( CONT_PARAMS );
static RTYPE compiled_start_1_534( CONT_PARAMS );
static RTYPE compiled_start_1_539( CONT_PARAMS );
static RTYPE compiled_start_1_533( CONT_PARAMS );
static RTYPE compiled_start_1_46( CONT_PARAMS );
static RTYPE compiled_start_1_541( CONT_PARAMS );
static RTYPE compiled_start_1_540( CONT_PARAMS );
static RTYPE compiled_block_1_1602( CONT_PARAMS );
static RTYPE compiled_block_1_1606( CONT_PARAMS );
static RTYPE compiled_block_1_1603( CONT_PARAMS );
static RTYPE compiled_block_1_1604( CONT_PARAMS );
static RTYPE compiled_temp_1_547( CONT_PARAMS );
static RTYPE compiled_temp_1_546( CONT_PARAMS );
static RTYPE compiled_temp_1_545( CONT_PARAMS );
static RTYPE compiled_temp_1_544( CONT_PARAMS );
static RTYPE compiled_start_1_543( CONT_PARAMS );
static RTYPE compiled_start_1_549( CONT_PARAMS );
static RTYPE compiled_start_1_548( CONT_PARAMS );
static RTYPE compiled_start_1_542( CONT_PARAMS );
static RTYPE compiled_start_1_45( CONT_PARAMS );
static RTYPE compiled_start_1_551( CONT_PARAMS );
static RTYPE compiled_start_1_550( CONT_PARAMS );
static RTYPE compiled_start_1_553( CONT_PARAMS );
static RTYPE compiled_start_1_552( CONT_PARAMS );
static RTYPE compiled_start_1_44( CONT_PARAMS );
static RTYPE compiled_start_1_555( CONT_PARAMS );
static RTYPE compiled_start_1_554( CONT_PARAMS );
static RTYPE compiled_start_1_557( CONT_PARAMS );
static RTYPE compiled_start_1_556( CONT_PARAMS );
static RTYPE compiled_block_1_1584( CONT_PARAMS );
static RTYPE compiled_block_1_1585( CONT_PARAMS );
static RTYPE compiled_block_1_1582( CONT_PARAMS );
static RTYPE compiled_block_1_1588( CONT_PARAMS );
static RTYPE compiled_block_1_1586( CONT_PARAMS );
static RTYPE compiled_temp_1_564( CONT_PARAMS );
static RTYPE compiled_block_1_1583( CONT_PARAMS );
static RTYPE compiled_temp_1_563( CONT_PARAMS );
static RTYPE compiled_temp_1_562( CONT_PARAMS );
static RTYPE compiled_block_1_1578( CONT_PARAMS );
static RTYPE compiled_block_1_1579( CONT_PARAMS );
static RTYPE compiled_block_1_1580( CONT_PARAMS );
static RTYPE compiled_temp_1_561( CONT_PARAMS );
static RTYPE compiled_temp_1_560( CONT_PARAMS );
static RTYPE compiled_block_1_1576( CONT_PARAMS );
static RTYPE compiled_temp_1_559( CONT_PARAMS );
static RTYPE compiled_temp_1_558( CONT_PARAMS );
static RTYPE compiled_start_1_43( CONT_PARAMS );
static RTYPE compiled_block_1_1572( CONT_PARAMS );
static RTYPE compiled_block_1_1571( CONT_PARAMS );
static RTYPE compiled_block_1_1569( CONT_PARAMS );
static RTYPE compiled_block_1_1574( CONT_PARAMS );
static RTYPE compiled_temp_1_572( CONT_PARAMS );
static RTYPE compiled_temp_1_571( CONT_PARAMS );
static RTYPE compiled_block_1_1570( CONT_PARAMS );
static RTYPE compiled_temp_1_570( CONT_PARAMS );
static RTYPE compiled_temp_1_569( CONT_PARAMS );
static RTYPE compiled_block_1_1565( CONT_PARAMS );
static RTYPE compiled_block_1_1566( CONT_PARAMS );
static RTYPE compiled_block_1_1567( CONT_PARAMS );
static RTYPE compiled_temp_1_568( CONT_PARAMS );
static RTYPE compiled_temp_1_567( CONT_PARAMS );
static RTYPE compiled_block_1_1563( CONT_PARAMS );
static RTYPE compiled_temp_1_566( CONT_PARAMS );
static RTYPE compiled_temp_1_565( CONT_PARAMS );
static RTYPE compiled_start_1_42( CONT_PARAMS );
static RTYPE compiled_block_1_1561( CONT_PARAMS );
static RTYPE compiled_temp_1_576( CONT_PARAMS );
static RTYPE compiled_block_1_1562( CONT_PARAMS );
static RTYPE compiled_temp_1_575( CONT_PARAMS );
static RTYPE compiled_temp_1_574( CONT_PARAMS );
static RTYPE compiled_temp_1_573( CONT_PARAMS );
static RTYPE compiled_start_1_41( CONT_PARAMS );
static RTYPE compiled_block_1_1558( CONT_PARAMS );
static RTYPE compiled_temp_1_580( CONT_PARAMS );
static RTYPE compiled_block_1_1559( CONT_PARAMS );
static RTYPE compiled_temp_1_579( CONT_PARAMS );
static RTYPE compiled_temp_1_578( CONT_PARAMS );
static RTYPE compiled_temp_1_577( CONT_PARAMS );
static RTYPE compiled_start_1_40( CONT_PARAMS );
static RTYPE compiled_block_1_1555( CONT_PARAMS );
static RTYPE compiled_temp_1_584( CONT_PARAMS );
static RTYPE compiled_block_1_1556( CONT_PARAMS );
static RTYPE compiled_temp_1_583( CONT_PARAMS );
static RTYPE compiled_temp_1_582( CONT_PARAMS );
static RTYPE compiled_temp_1_581( CONT_PARAMS );
static RTYPE compiled_start_1_39( CONT_PARAMS );
static RTYPE compiled_block_1_1552( CONT_PARAMS );
static RTYPE compiled_temp_1_588( CONT_PARAMS );
static RTYPE compiled_block_1_1553( CONT_PARAMS );
static RTYPE compiled_temp_1_587( CONT_PARAMS );
static RTYPE compiled_temp_1_586( CONT_PARAMS );
static RTYPE compiled_temp_1_585( CONT_PARAMS );
static RTYPE compiled_start_1_38( CONT_PARAMS );
static RTYPE compiled_start_1_37( CONT_PARAMS );
static RTYPE compiled_start_1_590( CONT_PARAMS );
static RTYPE compiled_start_1_589( CONT_PARAMS );
static RTYPE compiled_start_1_592( CONT_PARAMS );
static RTYPE compiled_start_1_591( CONT_PARAMS );
static RTYPE compiled_start_1_36( CONT_PARAMS );
static RTYPE compiled_start_1_594( CONT_PARAMS );
static RTYPE compiled_start_1_593( CONT_PARAMS );
static RTYPE compiled_start_1_596( CONT_PARAMS );
static RTYPE compiled_start_1_595( CONT_PARAMS );
static RTYPE compiled_start_1_35( CONT_PARAMS );
static RTYPE compiled_start_1_598( CONT_PARAMS );
static RTYPE compiled_start_1_597( CONT_PARAMS );
static RTYPE compiled_start_1_600( CONT_PARAMS );
static RTYPE compiled_start_1_599( CONT_PARAMS );
static RTYPE compiled_start_1_34( CONT_PARAMS );
static RTYPE compiled_start_1_602( CONT_PARAMS );
static RTYPE compiled_start_1_601( CONT_PARAMS );
static RTYPE compiled_start_1_604( CONT_PARAMS );
static RTYPE compiled_start_1_603( CONT_PARAMS );
static RTYPE compiled_start_1_33( CONT_PARAMS );
static RTYPE compiled_start_1_606( CONT_PARAMS );
static RTYPE compiled_start_1_605( CONT_PARAMS );
static RTYPE compiled_start_1_608( CONT_PARAMS );
static RTYPE compiled_start_1_607( CONT_PARAMS );
static RTYPE compiled_start_1_32( CONT_PARAMS );
static RTYPE compiled_start_1_610( CONT_PARAMS );
static RTYPE compiled_start_1_609( CONT_PARAMS );
static RTYPE compiled_start_1_612( CONT_PARAMS );
static RTYPE compiled_start_1_611( CONT_PARAMS );
static RTYPE compiled_start_1_31( CONT_PARAMS );
static RTYPE compiled_start_1_614( CONT_PARAMS );
static RTYPE compiled_start_1_613( CONT_PARAMS );
static RTYPE compiled_start_1_616( CONT_PARAMS );
static RTYPE compiled_start_1_615( CONT_PARAMS );
static RTYPE compiled_start_1_30( CONT_PARAMS );
static RTYPE compiled_start_1_618( CONT_PARAMS );
static RTYPE compiled_start_1_617( CONT_PARAMS );
static RTYPE compiled_start_1_620( CONT_PARAMS );
static RTYPE compiled_start_1_619( CONT_PARAMS );
static RTYPE compiled_temp_1_628( CONT_PARAMS );
static RTYPE compiled_temp_1_627( CONT_PARAMS );
static RTYPE compiled_block_1_1499( CONT_PARAMS );
static RTYPE compiled_block_1_1496( CONT_PARAMS );
static RTYPE compiled_block_1_1497( CONT_PARAMS );
static RTYPE compiled_temp_1_626( CONT_PARAMS );
static RTYPE compiled_temp_1_625( CONT_PARAMS );
static RTYPE compiled_block_1_1494( CONT_PARAMS );
static RTYPE compiled_block_1_1495( CONT_PARAMS );
static RTYPE compiled_temp_1_624( CONT_PARAMS );
static RTYPE compiled_block_1_1492( CONT_PARAMS );
static RTYPE compiled_block_1_1493( CONT_PARAMS );
static RTYPE compiled_block_1_1490( CONT_PARAMS );
static RTYPE compiled_block_1_1491( CONT_PARAMS );
static RTYPE compiled_temp_1_623( CONT_PARAMS );
static RTYPE compiled_temp_1_622( CONT_PARAMS );
static RTYPE compiled_temp_1_621( CONT_PARAMS );
static RTYPE compiled_start_1_29( CONT_PARAMS );
static RTYPE compiled_block_1_1503( CONT_PARAMS );
static RTYPE compiled_block_1_1502( CONT_PARAMS );
static RTYPE compiled_temp_1_634( CONT_PARAMS );
static RTYPE compiled_temp_1_633( CONT_PARAMS );
static RTYPE compiled_block_1_1508( CONT_PARAMS );
static RTYPE compiled_temp_1_632( CONT_PARAMS );
static RTYPE compiled_temp_1_631( CONT_PARAMS );
static RTYPE compiled_block_1_1500( CONT_PARAMS );
static RTYPE compiled_block_1_1506( CONT_PARAMS );
static RTYPE compiled_block_1_1504( CONT_PARAMS );
static RTYPE compiled_block_1_1501( CONT_PARAMS );
static RTYPE compiled_temp_1_630( CONT_PARAMS );
static RTYPE compiled_start_1_629( CONT_PARAMS );
static RTYPE compiled_block_1_1478( CONT_PARAMS );
static RTYPE compiled_block_1_1475( CONT_PARAMS );
static RTYPE compiled_block_1_1476( CONT_PARAMS );
static RTYPE compiled_temp_1_640( CONT_PARAMS );
static RTYPE compiled_temp_1_639( CONT_PARAMS );
static RTYPE compiled_block_1_1473( CONT_PARAMS );
static RTYPE compiled_block_1_1474( CONT_PARAMS );
static RTYPE compiled_temp_1_638( CONT_PARAMS );
static RTYPE compiled_block_1_1471( CONT_PARAMS );
static RTYPE compiled_block_1_1472( CONT_PARAMS );
static RTYPE compiled_block_1_1469( CONT_PARAMS );
static RTYPE compiled_block_1_1470( CONT_PARAMS );
static RTYPE compiled_temp_1_637( CONT_PARAMS );
static RTYPE compiled_temp_1_636( CONT_PARAMS );
static RTYPE compiled_temp_1_635( CONT_PARAMS );
static RTYPE compiled_start_1_28( CONT_PARAMS );
static RTYPE compiled_block_1_1482( CONT_PARAMS );
static RTYPE compiled_block_1_1481( CONT_PARAMS );
static RTYPE compiled_temp_1_645( CONT_PARAMS );
static RTYPE compiled_temp_1_644( CONT_PARAMS );
static RTYPE compiled_block_1_1487( CONT_PARAMS );
static RTYPE compiled_temp_1_643( CONT_PARAMS );
static RTYPE compiled_block_1_1479( CONT_PARAMS );
static RTYPE compiled_block_1_1485( CONT_PARAMS );
static RTYPE compiled_block_1_1483( CONT_PARAMS );
static RTYPE compiled_block_1_1480( CONT_PARAMS );
static RTYPE compiled_temp_1_642( CONT_PARAMS );
static RTYPE compiled_start_1_641( CONT_PARAMS );
static RTYPE compiled_temp_1_653( CONT_PARAMS );
static RTYPE compiled_temp_1_652( CONT_PARAMS );
static RTYPE compiled_block_1_1458( CONT_PARAMS );
static RTYPE compiled_block_1_1455( CONT_PARAMS );
static RTYPE compiled_block_1_1456( CONT_PARAMS );
static RTYPE compiled_temp_1_651( CONT_PARAMS );
static RTYPE compiled_temp_1_650( CONT_PARAMS );
static RTYPE compiled_block_1_1453( CONT_PARAMS );
static RTYPE compiled_block_1_1454( CONT_PARAMS );
static RTYPE compiled_temp_1_649( CONT_PARAMS );
static RTYPE compiled_block_1_1451( CONT_PARAMS );
static RTYPE compiled_block_1_1452( CONT_PARAMS );
static RTYPE compiled_block_1_1449( CONT_PARAMS );
static RTYPE compiled_block_1_1450( CONT_PARAMS );
static RTYPE compiled_temp_1_648( CONT_PARAMS );
static RTYPE compiled_temp_1_647( CONT_PARAMS );
static RTYPE compiled_temp_1_646( CONT_PARAMS );
static RTYPE compiled_start_1_27( CONT_PARAMS );
static RTYPE compiled_block_1_1461( CONT_PARAMS );
static RTYPE compiled_block_1_1462( CONT_PARAMS );
static RTYPE compiled_temp_1_659( CONT_PARAMS );
static RTYPE compiled_temp_1_658( CONT_PARAMS );
static RTYPE compiled_block_1_1466( CONT_PARAMS );
static RTYPE compiled_temp_1_657( CONT_PARAMS );
static RTYPE compiled_temp_1_656( CONT_PARAMS );
static RTYPE compiled_block_1_1459( CONT_PARAMS );
static RTYPE compiled_block_1_1464( CONT_PARAMS );
static RTYPE compiled_block_1_1460( CONT_PARAMS );
static RTYPE compiled_temp_1_655( CONT_PARAMS );
static RTYPE compiled_start_1_654( CONT_PARAMS );
static RTYPE compiled_block_1_1438( CONT_PARAMS );
static RTYPE compiled_block_1_1435( CONT_PARAMS );
static RTYPE compiled_block_1_1436( CONT_PARAMS );
static RTYPE compiled_temp_1_665( CONT_PARAMS );
static RTYPE compiled_temp_1_664( CONT_PARAMS );
static RTYPE compiled_block_1_1433( CONT_PARAMS );
static RTYPE compiled_block_1_1434( CONT_PARAMS );
static RTYPE compiled_temp_1_663( CONT_PARAMS );
static RTYPE compiled_block_1_1431( CONT_PARAMS );
static RTYPE compiled_block_1_1432( CONT_PARAMS );
static RTYPE compiled_block_1_1429( CONT_PARAMS );
static RTYPE compiled_block_1_1430( CONT_PARAMS );
static RTYPE compiled_temp_1_662( CONT_PARAMS );
static RTYPE compiled_temp_1_661( CONT_PARAMS );
static RTYPE compiled_temp_1_660( CONT_PARAMS );
static RTYPE compiled_start_1_26( CONT_PARAMS );
static RTYPE compiled_block_1_1441( CONT_PARAMS );
static RTYPE compiled_block_1_1442( CONT_PARAMS );
static RTYPE compiled_temp_1_670( CONT_PARAMS );
static RTYPE compiled_temp_1_669( CONT_PARAMS );
static RTYPE compiled_block_1_1446( CONT_PARAMS );
static RTYPE compiled_temp_1_668( CONT_PARAMS );
static RTYPE compiled_block_1_1439( CONT_PARAMS );
static RTYPE compiled_block_1_1444( CONT_PARAMS );
static RTYPE compiled_block_1_1440( CONT_PARAMS );
static RTYPE compiled_temp_1_667( CONT_PARAMS );
static RTYPE compiled_start_1_666( CONT_PARAMS );
static RTYPE compiled_block_1_1428( CONT_PARAMS );
static RTYPE compiled_temp_1_671( CONT_PARAMS );
static RTYPE compiled_start_1_25( CONT_PARAMS );
static RTYPE compiled_block_1_1426( CONT_PARAMS );
static RTYPE compiled_block_1_1425( CONT_PARAMS );
static RTYPE compiled_block_1_1424( CONT_PARAMS );
static RTYPE compiled_temp_1_673( CONT_PARAMS );
static RTYPE compiled_start_1_672( CONT_PARAMS );
static RTYPE compiled_start_1_24( CONT_PARAMS );
static RTYPE compiled_block_1_1409( CONT_PARAMS );
static RTYPE compiled_block_1_1411( CONT_PARAMS );
static RTYPE compiled_temp_1_678( CONT_PARAMS );
static RTYPE compiled_block_1_1399( CONT_PARAMS );
static RTYPE compiled_block_1_1397( CONT_PARAMS );
static RTYPE compiled_block_1_1389( CONT_PARAMS );
static RTYPE compiled_start_1_675( CONT_PARAMS );
static RTYPE compiled_block_1_1412( CONT_PARAMS );
static RTYPE compiled_block_1_1418( CONT_PARAMS );
static RTYPE compiled_block_1_1416( CONT_PARAMS );
static RTYPE compiled_block_1_1414( CONT_PARAMS );
static RTYPE compiled_temp_1_680( CONT_PARAMS );
static RTYPE compiled_start_1_679( CONT_PARAMS );
static RTYPE compiled_block_1_1402( CONT_PARAMS );
static RTYPE compiled_block_1_1401( CONT_PARAMS );
static RTYPE compiled_block_1_1405( CONT_PARAMS );
static RTYPE compiled_block_1_1403( CONT_PARAMS );
static RTYPE compiled_temp_1_681( CONT_PARAMS );
static RTYPE compiled_start_1_677( CONT_PARAMS );
static RTYPE compiled_block_1_1392( CONT_PARAMS );
static RTYPE compiled_block_1_1391( CONT_PARAMS );
static RTYPE compiled_block_1_1394( CONT_PARAMS );
static RTYPE compiled_temp_1_682( CONT_PARAMS );
static RTYPE compiled_start_1_676( CONT_PARAMS );
static RTYPE compiled_start_1_674( CONT_PARAMS );
static RTYPE compiled_start_1_23( CONT_PARAMS );
static RTYPE compiled_block_1_1373( CONT_PARAMS );
static RTYPE compiled_block_1_1375( CONT_PARAMS );
static RTYPE compiled_temp_1_687( CONT_PARAMS );
static RTYPE compiled_block_1_1363( CONT_PARAMS );
static RTYPE compiled_block_1_1361( CONT_PARAMS );
static RTYPE compiled_block_1_1353( CONT_PARAMS );
static RTYPE compiled_start_1_684( CONT_PARAMS );
static RTYPE compiled_block_1_1376( CONT_PARAMS );
static RTYPE compiled_block_1_1382( CONT_PARAMS );
static RTYPE compiled_block_1_1380( CONT_PARAMS );
static RTYPE compiled_block_1_1378( CONT_PARAMS );
static RTYPE compiled_temp_1_689( CONT_PARAMS );
static RTYPE compiled_start_1_688( CONT_PARAMS );
static RTYPE compiled_block_1_1366( CONT_PARAMS );
static RTYPE compiled_block_1_1369( CONT_PARAMS );
static RTYPE compiled_block_1_1367( CONT_PARAMS );
static RTYPE compiled_block_1_1365( CONT_PARAMS );
static RTYPE compiled_temp_1_690( CONT_PARAMS );
static RTYPE compiled_start_1_686( CONT_PARAMS );
static RTYPE compiled_block_1_1356( CONT_PARAMS );
static RTYPE compiled_block_1_1358( CONT_PARAMS );
static RTYPE compiled_block_1_1355( CONT_PARAMS );
static RTYPE compiled_temp_1_691( CONT_PARAMS );
static RTYPE compiled_start_1_685( CONT_PARAMS );
static RTYPE compiled_start_1_683( CONT_PARAMS );
static RTYPE compiled_start_1_22( CONT_PARAMS );
static RTYPE compiled_start_1_693( CONT_PARAMS );
static RTYPE compiled_block_1_1346( CONT_PARAMS );
static RTYPE compiled_temp_1_696( CONT_PARAMS );
static RTYPE compiled_block_1_1347( CONT_PARAMS );
static RTYPE compiled_temp_1_695( CONT_PARAMS );
static RTYPE compiled_start_1_694( CONT_PARAMS );
static RTYPE compiled_start_1_692( CONT_PARAMS );
static RTYPE compiled_start_1_21( CONT_PARAMS );
static RTYPE compiled_start_1_698( CONT_PARAMS );
static RTYPE compiled_block_1_1339( CONT_PARAMS );
static RTYPE compiled_block_1_1338( CONT_PARAMS );
static RTYPE compiled_block_1_1340( CONT_PARAMS );
static RTYPE compiled_temp_1_700( CONT_PARAMS );
static RTYPE compiled_start_1_699( CONT_PARAMS );
static RTYPE compiled_start_1_697( CONT_PARAMS );
static RTYPE compiled_start_1_20( CONT_PARAMS );
static RTYPE compiled_block_1_1330( CONT_PARAMS );
static RTYPE compiled_block_1_1332( CONT_PARAMS );
static RTYPE compiled_block_1_1328( CONT_PARAMS );
static RTYPE compiled_start_1_702( CONT_PARAMS );
static RTYPE compiled_start_1_701( CONT_PARAMS );
static RTYPE compiled_block_1_1293( CONT_PARAMS );
static RTYPE compiled_start_1_704( CONT_PARAMS );
static RTYPE compiled_start_1_705( CONT_PARAMS );
static RTYPE compiled_block_1_1298( CONT_PARAMS );
static RTYPE compiled_block_1_1313( CONT_PARAMS );
static RTYPE compiled_block_1_1321( CONT_PARAMS );
static RTYPE compiled_block_1_1315( CONT_PARAMS );
static RTYPE compiled_block_1_1299( CONT_PARAMS );
static RTYPE compiled_block_1_1314( CONT_PARAMS );
static RTYPE compiled_temp_1_719( CONT_PARAMS );
static RTYPE compiled_temp_1_718( CONT_PARAMS );
static RTYPE compiled_block_1_1319( CONT_PARAMS );
static RTYPE compiled_block_1_1320( CONT_PARAMS );
static RTYPE compiled_temp_1_717( CONT_PARAMS );
static RTYPE compiled_block_1_1317( CONT_PARAMS );
static RTYPE compiled_block_1_1318( CONT_PARAMS );
static RTYPE compiled_temp_1_716( CONT_PARAMS );
static RTYPE compiled_temp_1_715( CONT_PARAMS );
static RTYPE compiled_block_1_1312( CONT_PARAMS );
static RTYPE compiled_temp_1_714( CONT_PARAMS );
static RTYPE compiled_temp_1_713( CONT_PARAMS );
static RTYPE compiled_block_1_1310( CONT_PARAMS );
static RTYPE compiled_block_1_1309( CONT_PARAMS );
static RTYPE compiled_block_1_1296( CONT_PARAMS );
static RTYPE compiled_block_1_1308( CONT_PARAMS );
static RTYPE compiled_temp_1_711( CONT_PARAMS );
static RTYPE compiled_block_1_1301( CONT_PARAMS );
static RTYPE compiled_block_1_1300( CONT_PARAMS );
static RTYPE compiled_temp_1_710( CONT_PARAMS );
static RTYPE compiled_temp_1_709( CONT_PARAMS );
static RTYPE compiled_temp_1_708( CONT_PARAMS );
static RTYPE compiled_temp_1_707( CONT_PARAMS );
static RTYPE compiled_block_1_1297( CONT_PARAMS );
static RTYPE compiled_block_1_1294( CONT_PARAMS );
static RTYPE compiled_start_1_706( CONT_PARAMS );
static RTYPE compiled_block_1_1304( CONT_PARAMS );
static RTYPE compiled_block_1_1303( CONT_PARAMS );
static RTYPE compiled_temp_1_720( CONT_PARAMS );
static RTYPE compiled_block_1_1305( CONT_PARAMS );
static RTYPE compiled_start_1_712( CONT_PARAMS );
static RTYPE compiled_block_1_1287( CONT_PARAMS );
static RTYPE compiled_block_1_1289( CONT_PARAMS );
static RTYPE compiled_block_1_1285( CONT_PARAMS );
static RTYPE compiled_start_1_703( CONT_PARAMS );
static RTYPE compiled_start_1_721( CONT_PARAMS );
static RTYPE compiled_start_1_19( CONT_PARAMS );
static RTYPE compiled_block_1_1278( CONT_PARAMS );
static RTYPE compiled_block_1_1280( CONT_PARAMS );
static RTYPE compiled_block_1_1276( CONT_PARAMS );
static RTYPE compiled_start_1_723( CONT_PARAMS );
static RTYPE compiled_start_1_722( CONT_PARAMS );
static RTYPE compiled_block_1_1242( CONT_PARAMS );
static RTYPE compiled_start_1_725( CONT_PARAMS );
static RTYPE compiled_start_1_726( CONT_PARAMS );
static RTYPE compiled_block_1_1247( CONT_PARAMS );
static RTYPE compiled_block_1_1269( CONT_PARAMS );
static RTYPE compiled_block_1_1262( CONT_PARAMS );
static RTYPE compiled_block_1_1263( CONT_PARAMS );
static RTYPE compiled_block_1_1248( CONT_PARAMS );
static RTYPE compiled_temp_1_737( CONT_PARAMS );
static RTYPE compiled_block_1_1267( CONT_PARAMS );
static RTYPE compiled_block_1_1268( CONT_PARAMS );
static RTYPE compiled_temp_1_736( CONT_PARAMS );
static RTYPE compiled_block_1_1265( CONT_PARAMS );
static RTYPE compiled_block_1_1266( CONT_PARAMS );
static RTYPE compiled_temp_1_735( CONT_PARAMS );
static RTYPE compiled_temp_1_734( CONT_PARAMS );
static RTYPE compiled_block_1_1261( CONT_PARAMS );
static RTYPE compiled_temp_1_733( CONT_PARAMS );
static RTYPE compiled_block_1_1259( CONT_PARAMS );
static RTYPE compiled_block_1_1258( CONT_PARAMS );
static RTYPE compiled_block_1_1245( CONT_PARAMS );
static RTYPE compiled_block_1_1257( CONT_PARAMS );
static RTYPE compiled_block_1_1256( CONT_PARAMS );
static RTYPE compiled_block_1_1250( CONT_PARAMS );
static RTYPE compiled_temp_1_731( CONT_PARAMS );
static RTYPE compiled_block_1_1249( CONT_PARAMS );
static RTYPE compiled_temp_1_730( CONT_PARAMS );
static RTYPE compiled_temp_1_729( CONT_PARAMS );
static RTYPE compiled_temp_1_728( CONT_PARAMS );
static RTYPE compiled_block_1_1246( CONT_PARAMS );
static RTYPE compiled_block_1_1243( CONT_PARAMS );
static RTYPE compiled_start_1_727( CONT_PARAMS );
static RTYPE compiled_block_1_1253( CONT_PARAMS );
static RTYPE compiled_block_1_1252( CONT_PARAMS );
static RTYPE compiled_block_1_1254( CONT_PARAMS );
static RTYPE compiled_temp_1_738( CONT_PARAMS );
static RTYPE compiled_start_1_732( CONT_PARAMS );
static RTYPE compiled_block_1_1236( CONT_PARAMS );
static RTYPE compiled_block_1_1238( CONT_PARAMS );
static RTYPE compiled_block_1_1234( CONT_PARAMS );
static RTYPE compiled_start_1_724( CONT_PARAMS );
static RTYPE compiled_start_1_739( CONT_PARAMS );
static RTYPE compiled_start_1_18( CONT_PARAMS );
static RTYPE compiled_start_1_741( CONT_PARAMS );
static RTYPE compiled_temp_1_742( CONT_PARAMS );
static RTYPE compiled_start_1_740( CONT_PARAMS );
static RTYPE compiled_block_1_1227( CONT_PARAMS );
static RTYPE compiled_block_1_1226( CONT_PARAMS );
static RTYPE compiled_block_1_1228( CONT_PARAMS );
static RTYPE compiled_temp_1_745( CONT_PARAMS );
static RTYPE compiled_temp_1_744( CONT_PARAMS );
static RTYPE compiled_start_1_743( CONT_PARAMS );
static RTYPE compiled_start_1_17( CONT_PARAMS );
static RTYPE compiled_start_1_747( CONT_PARAMS );
static RTYPE compiled_start_1_746( CONT_PARAMS );
static RTYPE compiled_block_1_1219( CONT_PARAMS );
static RTYPE compiled_block_1_1218( CONT_PARAMS );
static RTYPE compiled_block_1_1220( CONT_PARAMS );
static RTYPE compiled_temp_1_750( CONT_PARAMS );
static RTYPE compiled_temp_1_749( CONT_PARAMS );
static RTYPE compiled_start_1_748( CONT_PARAMS );
static RTYPE compiled_temp_1_751( CONT_PARAMS );
static RTYPE compiled_start_1_16( CONT_PARAMS );
static RTYPE compiled_block_1_1212( CONT_PARAMS );
static RTYPE compiled_block_1_1214( CONT_PARAMS );
static RTYPE compiled_block_1_1213( CONT_PARAMS );
static RTYPE compiled_block_1_1211( CONT_PARAMS );
static RTYPE compiled_temp_1_753( CONT_PARAMS );
static RTYPE compiled_start_1_752( CONT_PARAMS );
static RTYPE compiled_start_1_15( CONT_PARAMS );
static RTYPE compiled_start_1_755( CONT_PARAMS );
static RTYPE compiled_start_1_754( CONT_PARAMS );
static RTYPE compiled_block_1_1206( CONT_PARAMS );
static RTYPE compiled_temp_1_758( CONT_PARAMS );
static RTYPE compiled_temp_1_757( CONT_PARAMS );
static RTYPE compiled_temp_1_756( CONT_PARAMS );
static RTYPE compiled_start_1_14( CONT_PARAMS );
static RTYPE compiled_block_1_1202( CONT_PARAMS );
static RTYPE compiled_block_1_1204( CONT_PARAMS );
static RTYPE compiled_block_1_1203( CONT_PARAMS );
static RTYPE compiled_block_1_1201( CONT_PARAMS );
static RTYPE compiled_temp_1_760( CONT_PARAMS );
static RTYPE compiled_start_1_759( CONT_PARAMS );
static RTYPE compiled_start_1_13( CONT_PARAMS );
static RTYPE compiled_start_1_762( CONT_PARAMS );
static RTYPE compiled_start_1_761( CONT_PARAMS );
static RTYPE compiled_start_1_12( CONT_PARAMS );
static RTYPE compiled_start_1_764( CONT_PARAMS );
static RTYPE compiled_start_1_763( CONT_PARAMS );
static RTYPE compiled_block_1_1190( CONT_PARAMS );
static RTYPE compiled_block_1_1192( CONT_PARAMS );
static RTYPE compiled_block_1_1188( CONT_PARAMS );
static RTYPE compiled_block_1_1189( CONT_PARAMS );
static RTYPE compiled_temp_1_766( CONT_PARAMS );
static RTYPE compiled_temp_1_765( CONT_PARAMS );
static RTYPE compiled_start_1_11( CONT_PARAMS );
static RTYPE compiled_block_1_1172( CONT_PARAMS );
static RTYPE compiled_block_1_1173( CONT_PARAMS );
static RTYPE compiled_block_1_1174( CONT_PARAMS );
static RTYPE compiled_block_1_1186( CONT_PARAMS );
static RTYPE compiled_block_1_1176( CONT_PARAMS );
static RTYPE compiled_block_1_1185( CONT_PARAMS );
static RTYPE compiled_block_1_1184( CONT_PARAMS );
static RTYPE compiled_block_1_1177( CONT_PARAMS );
static RTYPE compiled_block_1_1178( CONT_PARAMS );
static RTYPE compiled_block_1_1180( CONT_PARAMS );
static RTYPE compiled_block_1_1182( CONT_PARAMS );
static RTYPE compiled_temp_1_768( CONT_PARAMS );
static RTYPE compiled_temp_1_767( CONT_PARAMS );
static RTYPE compiled_start_1_10( CONT_PARAMS );
static RTYPE compiled_block_1_1170( CONT_PARAMS );
static RTYPE compiled_block_1_1168( CONT_PARAMS );
static RTYPE compiled_start_1_9( CONT_PARAMS );
static RTYPE compiled_block_1_1155( CONT_PARAMS );
static RTYPE compiled_block_1_1157( CONT_PARAMS );
static RTYPE compiled_block_1_1159( CONT_PARAMS );
static RTYPE compiled_block_1_1161( CONT_PARAMS );
static RTYPE compiled_block_1_1163( CONT_PARAMS );
static RTYPE compiled_block_1_1165( CONT_PARAMS );
static RTYPE compiled_block_1_1167( CONT_PARAMS );
static RTYPE compiled_temp_1_771( CONT_PARAMS );
static RTYPE compiled_temp_1_770( CONT_PARAMS );
static RTYPE compiled_temp_1_769( CONT_PARAMS );
static RTYPE compiled_start_1_8( CONT_PARAMS );
static RTYPE compiled_start_1_7( CONT_PARAMS );
static RTYPE compiled_block_1_1150( CONT_PARAMS );
static RTYPE compiled_start_1_773( CONT_PARAMS );
static RTYPE compiled_start_1_772( CONT_PARAMS );
static RTYPE compiled_block_1_1121( CONT_PARAMS );
static RTYPE compiled_block_1_1123( CONT_PARAMS );
static RTYPE compiled_block_1_1129( CONT_PARAMS );
static RTYPE compiled_block_1_1124( CONT_PARAMS );
static RTYPE compiled_block_1_1125( CONT_PARAMS );
static RTYPE compiled_block_1_1127( CONT_PARAMS );
static RTYPE compiled_temp_1_774( CONT_PARAMS );
static RTYPE compiled_block_1_1118( CONT_PARAMS );
static RTYPE compiled_block_1_1120( CONT_PARAMS );
static RTYPE compiled_block_1_1119( CONT_PARAMS );
static RTYPE compiled_start_1_6( CONT_PARAMS );
static RTYPE compiled_block_1_1142( CONT_PARAMS );
static RTYPE compiled_temp_1_777( CONT_PARAMS );
static RTYPE compiled_start_1_776( CONT_PARAMS );
static RTYPE compiled_block_1_1131( CONT_PARAMS );
static RTYPE compiled_block_1_1137( CONT_PARAMS );
static RTYPE compiled_block_1_1132( CONT_PARAMS );
static RTYPE compiled_block_1_1133( CONT_PARAMS );
static RTYPE compiled_block_1_1135( CONT_PARAMS );
static RTYPE compiled_temp_1_778( CONT_PARAMS );
static RTYPE compiled_start_1_775( CONT_PARAMS );
static RTYPE compiled_block_1_1117( CONT_PARAMS );
static RTYPE compiled_block_1_1116( CONT_PARAMS );
static RTYPE compiled_start_1_5( CONT_PARAMS );
static RTYPE compiled_start_1_4( CONT_PARAMS );
static RTYPE compiled_block_1_1113( CONT_PARAMS );
static RTYPE compiled_block_1_1067( CONT_PARAMS );
static RTYPE compiled_start_1_2( CONT_PARAMS );
static RTYPE compiled_block_1_1069( CONT_PARAMS );
static RTYPE compiled_block_1_1071( CONT_PARAMS );
static RTYPE compiled_block_1_1073( CONT_PARAMS );
static RTYPE compiled_block_1_1075( CONT_PARAMS );
static RTYPE compiled_block_1_1077( CONT_PARAMS );
static RTYPE compiled_block_1_1079( CONT_PARAMS );
static RTYPE compiled_block_1_1081( CONT_PARAMS );
static RTYPE compiled_block_1_1083( CONT_PARAMS );
static RTYPE compiled_block_1_1085( CONT_PARAMS );
static RTYPE compiled_block_1_1087( CONT_PARAMS );
static RTYPE compiled_block_1_1089( CONT_PARAMS );
static RTYPE compiled_block_1_1092( CONT_PARAMS );
static RTYPE compiled_block_1_1100( CONT_PARAMS );
static RTYPE compiled_block_1_1099( CONT_PARAMS );
static RTYPE compiled_block_1_1098( CONT_PARAMS );
static RTYPE compiled_block_1_1097( CONT_PARAMS );
static RTYPE compiled_block_1_1096( CONT_PARAMS );
static RTYPE compiled_block_1_1095( CONT_PARAMS );
static RTYPE compiled_block_1_1094( CONT_PARAMS );
static RTYPE compiled_block_1_1093( CONT_PARAMS );
static RTYPE compiled_block_1_1090( CONT_PARAMS );
static RTYPE compiled_start_1_780( CONT_PARAMS );
static RTYPE compiled_block_1_1035( CONT_PARAMS );
static RTYPE compiled_block_1_1037( CONT_PARAMS );
static RTYPE compiled_block_1_1039( CONT_PARAMS );
static RTYPE compiled_block_1_1041( CONT_PARAMS );
static RTYPE compiled_block_1_1043( CONT_PARAMS );
static RTYPE compiled_block_1_1045( CONT_PARAMS );
static RTYPE compiled_block_1_1047( CONT_PARAMS );
static RTYPE compiled_block_1_1049( CONT_PARAMS );
static RTYPE compiled_block_1_1051( CONT_PARAMS );
static RTYPE compiled_block_1_1054( CONT_PARAMS );
static RTYPE compiled_block_1_1056( CONT_PARAMS );
static RTYPE compiled_block_1_1055( CONT_PARAMS );
static RTYPE compiled_block_1_1052( CONT_PARAMS );
static RTYPE compiled_block_1_1002( CONT_PARAMS );
static RTYPE compiled_block_1_1005( CONT_PARAMS );
static RTYPE compiled_block_1_1007( CONT_PARAMS );
static RTYPE compiled_block_1_1009( CONT_PARAMS );
static RTYPE compiled_block_1_1011( CONT_PARAMS );
static RTYPE compiled_block_1_1013( CONT_PARAMS );
static RTYPE compiled_block_1_1015( CONT_PARAMS );
static RTYPE compiled_block_1_1017( CONT_PARAMS );
static RTYPE compiled_block_1_1019( CONT_PARAMS );
static RTYPE compiled_block_1_1022( CONT_PARAMS );
static RTYPE compiled_block_1_1024( CONT_PARAMS );
static RTYPE compiled_block_1_1023( CONT_PARAMS );
static RTYPE compiled_block_1_1020( CONT_PARAMS );
static RTYPE compiled_start_1_779( CONT_PARAMS );
static RTYPE compiled_start_1_1( CONT_PARAMS );

static RTYPE compiled_start_1_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 2 ); /*  string-join~1ayXVW~7680 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 3 ); /*  %multispan-repcopy!~1ayXVW~7679 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 4 ); /*  string-xcopy!~1ayXVW~7678 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 5 ); /*  xsubstring~1ayXVW~7677 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 6 ); /*  string-tokenize~1ayXVW~7676 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 7 ); /*  string-replace~1ayXVW~7675 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 8 ); /*  %finish-string-concatenate-reverse~1ayXVW~7674 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 9 ); /*  string-concatenate-reverse/shared~1ayXVW~7673 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 10 ); /*  string-concatenate-reverse~1ayXVW~7672 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 11 ); /*  string-concatenate~1ayXVW~7671 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 12 ); /*  string-concatenate/shared~1ayXVW~7670 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 13 ); /*  string-append/shared~1ayXVW~7669 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 14 ); /*  string->list~1ayXVW~7668 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 15 ); /*  reverse-list->string~1ayXVW~7667 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 16 ); /*  string-reverse!~1ayXVW~7666 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 17 ); /*  string-reverse~1ayXVW~7665 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 18 ); /*  string-null?~1ayXVW~7664 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 19 ); /*  string-kmp-partial-search~1ayXVW~7663 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 20 ); /*  kmp-step~1ayXVW~7662 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 21 ); /*  make-kmp-restart-vector~1ayXVW~7661 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 22 ); /*  %kmp-search~1ayXVW~7660 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 23 ); /*  string-contains-ci~1ayXVW~7659 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 24 ); /*  string-contains~1ayXVW~7658 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 25 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 26 ); /*  string-copy!~1ayXVW~7656 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 27 ); /*  string-fill!~1ayXVW~7655 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 28 ); /*  string-count~1ayXVW~7654 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 29 ); /*  string-skip-right~1ayXVW~7653 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 30 ); /*  string-skip~1ayXVW~7652 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 31 ); /*  string-index-right~1ayXVW~7651 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 32 ); /*  string-index~1ayXVW~7650 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 33 ); /*  string-filter~1ayXVW~7649 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 34 ); /*  string-delete~1ayXVW~7648 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 35 ); /*  string-pad~1ayXVW~7647 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 36 ); /*  string-pad-right~1ayXVW~7646 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 37 ); /*  string-trim-both~1ayXVW~7645 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 38 ); /*  string-trim-right~1ayXVW~7644 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 39 ); /*  string-trim~1ayXVW~7643 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 40 ); /*  string-drop-right~1ayXVW~7642 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 41 ); /*  string-drop~1ayXVW~7641 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 42 ); /*  string-take-right~1ayXVW~7640 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 43 ); /*  string-take~1ayXVW~7639 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 44 ); /*  string-titlecase~1ayXVW~7638 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 45 ); /*  string-titlecase!~1ayXVW~7637 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 46 ); /*  %string-titlecase!~1ayXVW~7636 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 47 ); /*  string-downcase!~1ayXVW~7635 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 48 ); /*  string-downcase~1ayXVW~7634 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 49 ); /*  string-upcase!~1ayXVW~7633 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 50 ); /*  string-upcase~1ayXVW~7632 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 51 ); /*  string-hash-ci~1ayXVW~7631 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 52 ); /*  string-hash~1ayXVW~7630 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 53 ); /*  %string-hash~1ayXVW~7629 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 54 ); /*  string-ci>=~1ayXVW~7628 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 55 ); /*  string-ci<=~1ayXVW~7627 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 56 ); /*  string-ci>~1ayXVW~7626 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 57 ); /*  string-ci<~1ayXVW~7625 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 58 ); /*  string-ci<>~1ayXVW~7624 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 59 ); /*  string-ci=~1ayXVW~7623 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 60 ); /*  string>=~1ayXVW~7622 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 61 ); /*  string<=~1ayXVW~7621 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 62 ); /*  string>~1ayXVW~7620 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 63 ); /*  string<~1ayXVW~7619 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 64 ); /*  string<>~1ayXVW~7618 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 65 ); /*  string=~1ayXVW~7617 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 66 ); /*  string-compare-ci~1ayXVW~7616 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 67 ); /*  string-compare~1ayXVW~7615 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 68 ); /*  %string-compare-ci~1ayXVW~7614 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 69 ); /*  %string-compare~1ayXVW~7613 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 70 ); /*  %string-suffix-ci?~1ayXVW~7612 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 71 ); /*  %string-prefix-ci?~1ayXVW~7611 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 72 ); /*  %string-suffix?~1ayXVW~7610 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 73 ); /*  %string-prefix?~1ayXVW~7609 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 74 ); /*  string-suffix-ci?~1ayXVW~7608 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 75 ); /*  string-prefix-ci?~1ayXVW~7607 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 76 ); /*  string-suffix?~1ayXVW~7606 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 77 ); /*  string-prefix?~1ayXVW~7605 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 78 ); /*  string-suffix-length-ci~1ayXVW~7604 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 79 ); /*  string-prefix-length-ci~1ayXVW~7603 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 80 ); /*  string-suffix-length~1ayXVW~7602 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 81 ); /*  string-prefix-length~1ayXVW~7601 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 82 ); /*  %string-suffix-length-ci~1ayXVW~7600 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 83 ); /*  %string-prefix-length-ci~1ayXVW~7599 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 84 ); /*  %string-suffix-length~1ayXVW~7598 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 85 ); /*  %string-prefix-length~1ayXVW~7597 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 86 ); /*  string-tabulate~1ayXVW~7596 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 87 ); /*  string-any~1ayXVW~7595 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 88 ); /*  string-every~1ayXVW~7594 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 89 ); /*  string-for-each-index~1ayXVW~7593 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 90 ); /*  string-for-each~1ayXVW~7592 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 91 ); /*  string-unfold-right~1ayXVW~7591 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 92 ); /*  string-unfold~1ayXVW~7590 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 93 ); /*  string-fold-right~1ayXVW~7589 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 94 ); /*  string-fold~1ayXVW~7588 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 95 ); /*  %string-map!~1ayXVW~7587 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 96 ); /*  string-map!~1ayXVW~7586 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 97 ); /*  %string-map~1ayXVW~7585 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 98 ); /*  string-map~1ayXVW~7584 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 99 ); /*  string-copy~1ayXVW~7583 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 100 ); /*  %substring/shared~1ayXVW~7582 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 101 ); /*  substring/shared~1ayXVW~7581 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 102 ); /*  check-substring-spec~1ayXVW~7580 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 103 ); /*  substring-spec-ok?~1ayXVW~7579 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 104 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 105 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 106 ); /*  char-cased?~1ayXVW~7480 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 107 ); /*  error~1ayXVW~7479 */
  twobit_lambda( compiled_start_1_1, 109, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_2, 111, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_3, 113, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 114 );
  twobit_setreg( 1 );
  twobit_const( 115 );
  twobit_setreg( 3 );
  twobit_const( 116 );
  twobit_setreg( 4 );
  twobit_const( 117 );
  twobit_setreg( 5 );
  twobit_const( 118 );
  twobit_setreg( 8 );
  twobit_global( 119 ); /* ex:make-library */
  twobit_setrtn( 2545, compiled_block_1_2545 );
  twobit_invoke( 8 );
  twobit_label( 2545, compiled_block_1_2545 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 120 ); /* ex:register-library! */
  twobit_setrtn( 2546, compiled_block_1_2546 );
  twobit_invoke( 1 );
  twobit_label( 2546, compiled_block_1_2546 );
  twobit_load( 0, 0 );
  twobit_global( 121 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* ex:uncompress */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_779, 2, 0 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1067, compiled_block_1_1067 );
  twobit_invoke( 2 );
  twobit_label( 1067, compiled_block_1_1067 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_780, 6, 0 );
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1113, compiled_block_1_1113 );
  twobit_invoke( 2 );
  twobit_label( 1113, compiled_block_1_1113 );
  twobit_load( 0, 0 );
  twobit_global( 8 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_779( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1005, compiled_block_1_1005 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1007, compiled_block_1_1007 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1009, compiled_block_1_1009 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1011, compiled_block_1_1011 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1013, compiled_block_1_1013 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1015, compiled_block_1_1015 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1017, compiled_block_1_1017 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1019, compiled_block_1_1019 ); /* internal:branchf-pair? */
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 8 );
  twobit_store( 2, 2 );
  twobit_store( 3, 5 );
  twobit_store( 30, 4 );
  twobit_store( 31, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 29 );
  twobit_store( 29, 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1020, compiled_block_1_1020 );
  twobit_invoke( 1 );
  twobit_label( 1020, compiled_block_1_1020 );
  twobit_load( 0, 0 );
  twobit_branchf( 1022, compiled_block_1_1022 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1023, compiled_block_1_1023 );
  twobit_invoke( 5 );
  twobit_label( 1023, compiled_block_1_1023 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 3 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_stack( 4 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_stack( 5 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 5 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1024, compiled_block_1_1024 );
  twobit_invoke( 5 );
  twobit_label( 1024, compiled_block_1_1024 );
  twobit_load( 0, 0 );
  twobit_load( 3, 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 1022, compiled_block_1_1022 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1019, compiled_block_1_1019 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1017, compiled_block_1_1017 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1015, compiled_block_1_1015 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1013, compiled_block_1_1013 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1011, compiled_block_1_1011 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1009, compiled_block_1_1009 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1007, compiled_block_1_1007 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1005, compiled_block_1_1005 );
  twobit_label( 1002, compiled_block_1_1002 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1035, compiled_block_1_1035 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1037, compiled_block_1_1037 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1039, compiled_block_1_1039 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1041, compiled_block_1_1041 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1043, compiled_block_1_1043 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1045, compiled_block_1_1045 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1047, compiled_block_1_1047 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1049, compiled_block_1_1049 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 29 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1051, compiled_block_1_1051 ); /* internal:branchf-pair? */
  twobit_save( 9 );
  twobit_store( 0, 0 );
  twobit_store( 1, 9 );
  twobit_store( 2, 2 );
  twobit_store( 3, 6 );
  twobit_store( 29, 5 );
  twobit_store( 30, 3 );
  twobit_store( 31, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 28 );
  twobit_store( 28, 4 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1052, compiled_block_1_1052 );
  twobit_invoke( 1 );
  twobit_label( 1052, compiled_block_1_1052 );
  twobit_load( 0, 0 );
  twobit_branchf( 1054, compiled_block_1_1054 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1055, compiled_block_1_1055 );
  twobit_invoke( 5 );
  twobit_label( 1055, compiled_block_1_1055 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 4 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_stack( 5 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_stack( 6 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 6 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1056, compiled_block_1_1056 );
  twobit_invoke( 5 );
  twobit_label( 1056, compiled_block_1_1056 );
  twobit_load( 0, 0 );
  twobit_load( 3, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 7 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 9 );
  twobit_return();
  twobit_label( 1054, compiled_block_1_1054 );
  twobit_load( 1, 9 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_pop( 9 );
  twobit_invoke( 1 );
  twobit_label( 1051, compiled_block_1_1051 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1049, compiled_block_1_1049 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1047, compiled_block_1_1047 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1045, compiled_block_1_1045 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1043, compiled_block_1_1043 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1041, compiled_block_1_1041 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1039, compiled_block_1_1039 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1037, compiled_block_1_1037 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1035, compiled_block_1_1035 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_780( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1069, compiled_block_1_1069 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1071, compiled_block_1_1071 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1073, compiled_block_1_1073 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1075, compiled_block_1_1075 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1077, compiled_block_1_1077 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1079, compiled_block_1_1079 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 29 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1081, compiled_block_1_1081 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1083, compiled_block_1_1083 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1085, compiled_block_1_1085 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 28 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1087, compiled_block_1_1087 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 27 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1089, compiled_block_1_1089 ); /* internal:branchf-pair? */
  twobit_save( 13 );
  twobit_store( 0, 0 );
  twobit_store( 1, 13 );
  twobit_store( 2, 3 );
  twobit_store( 3, 1 );
  twobit_store( 27, 7 );
  twobit_store( 28, 9 );
  twobit_store( 29, 4 );
  twobit_store( 30, 5 );
  twobit_store( 31, 2 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 26 );
  twobit_store( 26, 8 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1090, compiled_block_1_1090 );
  twobit_invoke( 1 );
  twobit_label( 1090, compiled_block_1_1090 );
  twobit_load( 0, 0 );
  twobit_branchf( 1092, compiled_block_1_1092 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1093, compiled_block_1_1093 );
  twobit_invoke( 5 );
  twobit_label( 1093, compiled_block_1_1093 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1094, compiled_block_1_1094 );
  twobit_invoke( 5 );
  twobit_label( 1094, compiled_block_1_1094 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1095, compiled_block_1_1095 );
  twobit_invoke( 5 );
  twobit_label( 1095, compiled_block_1_1095 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1096, compiled_block_1_1096 );
  twobit_invoke( 5 );
  twobit_label( 1096, compiled_block_1_1096 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1097, compiled_block_1_1097 );
  twobit_invoke( 5 );
  twobit_label( 1097, compiled_block_1_1097 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1098, compiled_block_1_1098 );
  twobit_invoke( 5 );
  twobit_label( 1098, compiled_block_1_1098 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1099, compiled_block_1_1099 );
  twobit_invoke( 5 );
  twobit_label( 1099, compiled_block_1_1099 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1100, compiled_block_1_1100 );
  twobit_invoke( 5 );
  twobit_label( 1100, compiled_block_1_1100 );
  twobit_load( 0, 0 );
  twobit_load( 3, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 13 );
  twobit_return();
  twobit_label( 1092, compiled_block_1_1092 );
  twobit_load( 1, 13 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_pop( 13 );
  twobit_invoke( 1 );
  twobit_label( 1089, compiled_block_1_1089 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1087, compiled_block_1_1087 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1085, compiled_block_1_1085 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1083, compiled_block_1_1083 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1081, compiled_block_1_1081 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1079, compiled_block_1_1079 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1077, compiled_block_1_1077 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1075, compiled_block_1_1075 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1073, compiled_block_1_1073 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1071, compiled_block_1_1071 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1069, compiled_block_1_1069 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 2 ); /*  string-join~1ayXVW~7680 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 3 ); /*  %multispan-repcopy!~1ayXVW~7679 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 4 ); /*  string-xcopy!~1ayXVW~7678 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 5 ); /*  xsubstring~1ayXVW~7677 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 6 ); /*  string-tokenize~1ayXVW~7676 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 7 ); /*  string-replace~1ayXVW~7675 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 8 ); /*  %finish-string-concatenate-reverse~1ayXVW~7674 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 9 ); /*  string-concatenate-reverse/shared~1ayXVW~7673 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 10 ); /*  string-concatenate-reverse~1ayXVW~7672 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 11 ); /*  string-concatenate~1ayXVW~7671 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 12 ); /*  string-concatenate/shared~1ayXVW~7670 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 13 ); /*  string-append/shared~1ayXVW~7669 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 14 ); /*  string->list~1ayXVW~7668 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 15 ); /*  reverse-list->string~1ayXVW~7667 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 16 ); /*  string-reverse!~1ayXVW~7666 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 17 ); /*  string-reverse~1ayXVW~7665 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 18 ); /*  string-null?~1ayXVW~7664 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 19 ); /*  string-kmp-partial-search~1ayXVW~7663 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 20 ); /*  kmp-step~1ayXVW~7662 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 21 ); /*  make-kmp-restart-vector~1ayXVW~7661 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 22 ); /*  %kmp-search~1ayXVW~7660 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 23 ); /*  string-contains-ci~1ayXVW~7659 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 24 ); /*  string-contains~1ayXVW~7658 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 25 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 26 ); /*  string-copy!~1ayXVW~7656 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 27 ); /*  string-fill!~1ayXVW~7655 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 28 ); /*  string-count~1ayXVW~7654 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 29 ); /*  string-skip-right~1ayXVW~7653 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 30 ); /*  string-skip~1ayXVW~7652 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 31 ); /*  string-index-right~1ayXVW~7651 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 32 ); /*  string-index~1ayXVW~7650 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 33 ); /*  string-filter~1ayXVW~7649 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 34 ); /*  string-delete~1ayXVW~7648 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 35 ); /*  string-pad~1ayXVW~7647 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 36 ); /*  string-pad-right~1ayXVW~7646 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 37 ); /*  string-trim-both~1ayXVW~7645 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 38 ); /*  string-trim-right~1ayXVW~7644 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 39 ); /*  string-trim~1ayXVW~7643 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 40 ); /*  string-drop-right~1ayXVW~7642 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 41 ); /*  string-drop~1ayXVW~7641 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 42 ); /*  string-take-right~1ayXVW~7640 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 43 ); /*  string-take~1ayXVW~7639 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 44 ); /*  string-titlecase~1ayXVW~7638 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 45 ); /*  string-titlecase!~1ayXVW~7637 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 46 ); /*  %string-titlecase!~1ayXVW~7636 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 47 ); /*  string-downcase!~1ayXVW~7635 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 48 ); /*  string-downcase~1ayXVW~7634 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 49 ); /*  string-upcase!~1ayXVW~7633 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 50 ); /*  string-upcase~1ayXVW~7632 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 51 ); /*  string-hash-ci~1ayXVW~7631 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 52 ); /*  string-hash~1ayXVW~7630 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 53 ); /*  %string-hash~1ayXVW~7629 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 54 ); /*  string-ci>=~1ayXVW~7628 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 55 ); /*  string-ci<=~1ayXVW~7627 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 56 ); /*  string-ci>~1ayXVW~7626 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 57 ); /*  string-ci<~1ayXVW~7625 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 58 ); /*  string-ci<>~1ayXVW~7624 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 59 ); /*  string-ci=~1ayXVW~7623 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 60 ); /*  string>=~1ayXVW~7622 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 61 ); /*  string<=~1ayXVW~7621 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 62 ); /*  string>~1ayXVW~7620 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 63 ); /*  string<~1ayXVW~7619 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 64 ); /*  string<>~1ayXVW~7618 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 65 ); /*  string=~1ayXVW~7617 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 66 ); /*  string-compare-ci~1ayXVW~7616 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 67 ); /*  string-compare~1ayXVW~7615 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 68 ); /*  %string-compare-ci~1ayXVW~7614 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 69 ); /*  %string-compare~1ayXVW~7613 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 70 ); /*  %string-suffix-ci?~1ayXVW~7612 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 71 ); /*  %string-prefix-ci?~1ayXVW~7611 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 72 ); /*  %string-suffix?~1ayXVW~7610 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 73 ); /*  %string-prefix?~1ayXVW~7609 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 74 ); /*  string-suffix-ci?~1ayXVW~7608 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 75 ); /*  string-prefix-ci?~1ayXVW~7607 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 76 ); /*  string-suffix?~1ayXVW~7606 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 77 ); /*  string-prefix?~1ayXVW~7605 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 78 ); /*  string-suffix-length-ci~1ayXVW~7604 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 79 ); /*  string-prefix-length-ci~1ayXVW~7603 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 80 ); /*  string-suffix-length~1ayXVW~7602 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 81 ); /*  string-prefix-length~1ayXVW~7601 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 82 ); /*  %string-suffix-length-ci~1ayXVW~7600 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 83 ); /*  %string-prefix-length-ci~1ayXVW~7599 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 84 ); /*  %string-suffix-length~1ayXVW~7598 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 85 ); /*  %string-prefix-length~1ayXVW~7597 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 86 ); /*  string-tabulate~1ayXVW~7596 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 87 ); /*  string-any~1ayXVW~7595 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 88 ); /*  string-every~1ayXVW~7594 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 89 ); /*  string-for-each-index~1ayXVW~7593 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 90 ); /*  string-for-each~1ayXVW~7592 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 91 ); /*  string-unfold-right~1ayXVW~7591 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 92 ); /*  string-unfold~1ayXVW~7590 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 93 ); /*  string-fold-right~1ayXVW~7589 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 94 ); /*  string-fold~1ayXVW~7588 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 95 ); /*  %string-map!~1ayXVW~7587 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 96 ); /*  string-map!~1ayXVW~7586 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 97 ); /*  %string-map~1ayXVW~7585 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 98 ); /*  string-map~1ayXVW~7584 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 99 ); /*  string-copy~1ayXVW~7583 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 100 ); /*  %substring/shared~1ayXVW~7582 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 101 ); /*  substring/shared~1ayXVW~7581 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 102 ); /*  check-substring-spec~1ayXVW~7580 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 103 ); /*  substring-spec-ok?~1ayXVW~7579 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 104 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 105 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 106 ); /*  char-cased?~1ayXVW~7480 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 107 ); /*  error~1ayXVW~7479 */
  twobit_lambda( compiled_start_1_4, 109, 0 );
  twobit_setglbl( 110 ); /*  error~1ayXVW~7479 */
  twobit_lambda( compiled_start_1_5, 112, 0 );
  twobit_setglbl( 113 ); /*  char-cased?~1ayXVW~7480 */
  twobit_lambda( compiled_start_1_6, 115, 0 );
  twobit_setglbl( 116 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_lambda( compiled_start_1_7, 118, 0 );
  twobit_setglbl( 119 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_lambda( compiled_start_1_8, 121, 0 );
  twobit_setglbl( 122 ); /*  substring-spec-ok?~1ayXVW~7579 */
  twobit_lambda( compiled_start_1_9, 124, 0 );
  twobit_setglbl( 125 ); /*  check-substring-spec~1ayXVW~7580 */
  twobit_lambda( compiled_start_1_10, 127, 0 );
  twobit_setglbl( 128 ); /*  substring/shared~1ayXVW~7581 */
  twobit_lambda( compiled_start_1_11, 130, 0 );
  twobit_setglbl( 131 ); /*  %substring/shared~1ayXVW~7582 */
  twobit_lambda( compiled_start_1_12, 133, 0 );
  twobit_setglbl( 134 ); /*  string-copy~1ayXVW~7583 */
  twobit_lambda( compiled_start_1_13, 136, 0 );
  twobit_setglbl( 137 ); /*  string-map~1ayXVW~7584 */
  twobit_lambda( compiled_start_1_14, 139, 0 );
  twobit_setglbl( 140 ); /*  %string-map~1ayXVW~7585 */
  twobit_lambda( compiled_start_1_15, 142, 0 );
  twobit_setglbl( 143 ); /*  string-map!~1ayXVW~7586 */
  twobit_lambda( compiled_start_1_16, 145, 0 );
  twobit_setglbl( 146 ); /*  %string-map!~1ayXVW~7587 */
  twobit_lambda( compiled_start_1_17, 148, 0 );
  twobit_setglbl( 149 ); /*  string-fold~1ayXVW~7588 */
  twobit_lambda( compiled_start_1_18, 151, 0 );
  twobit_setglbl( 152 ); /*  string-fold-right~1ayXVW~7589 */
  twobit_lambda( compiled_start_1_19, 154, 0 );
  twobit_setglbl( 155 ); /*  string-unfold~1ayXVW~7590 */
  twobit_lambda( compiled_start_1_20, 157, 0 );
  twobit_setglbl( 158 ); /*  string-unfold-right~1ayXVW~7591 */
  twobit_lambda( compiled_start_1_21, 160, 0 );
  twobit_setglbl( 161 ); /*  string-for-each~1ayXVW~7592 */
  twobit_lambda( compiled_start_1_22, 163, 0 );
  twobit_setglbl( 164 ); /*  string-for-each-index~1ayXVW~7593 */
  twobit_lambda( compiled_start_1_23, 166, 0 );
  twobit_setglbl( 167 ); /*  string-every~1ayXVW~7594 */
  twobit_lambda( compiled_start_1_24, 169, 0 );
  twobit_setglbl( 170 ); /*  string-any~1ayXVW~7595 */
  twobit_lambda( compiled_start_1_25, 172, 0 );
  twobit_setglbl( 173 ); /*  string-tabulate~1ayXVW~7596 */
  twobit_lambda( compiled_start_1_26, 175, 0 );
  twobit_setglbl( 176 ); /*  %string-prefix-length~1ayXVW~7597 */
  twobit_lambda( compiled_start_1_27, 178, 0 );
  twobit_setglbl( 179 ); /*  %string-suffix-length~1ayXVW~7598 */
  twobit_lambda( compiled_start_1_28, 181, 0 );
  twobit_setglbl( 182 ); /*  %string-prefix-length-ci~1ayXVW~7599 */
  twobit_lambda( compiled_start_1_29, 184, 0 );
  twobit_setglbl( 185 ); /*  %string-suffix-length-ci~1ayXVW~7600 */
  twobit_lambda( compiled_start_1_30, 187, 0 );
  twobit_setglbl( 188 ); /*  string-prefix-length~1ayXVW~7601 */
  twobit_lambda( compiled_start_1_31, 190, 0 );
  twobit_setglbl( 191 ); /*  string-suffix-length~1ayXVW~7602 */
  twobit_lambda( compiled_start_1_32, 193, 0 );
  twobit_setglbl( 194 ); /*  string-prefix-length-ci~1ayXVW~7603 */
  twobit_lambda( compiled_start_1_33, 196, 0 );
  twobit_setglbl( 197 ); /*  string-suffix-length-ci~1ayXVW~7604 */
  twobit_lambda( compiled_start_1_34, 199, 0 );
  twobit_setglbl( 200 ); /*  string-prefix?~1ayXVW~7605 */
  twobit_lambda( compiled_start_1_35, 202, 0 );
  twobit_setglbl( 203 ); /*  string-suffix?~1ayXVW~7606 */
  twobit_lambda( compiled_start_1_36, 205, 0 );
  twobit_setglbl( 206 ); /*  string-prefix-ci?~1ayXVW~7607 */
  twobit_lambda( compiled_start_1_37, 208, 0 );
  twobit_setglbl( 209 ); /*  string-suffix-ci?~1ayXVW~7608 */
  twobit_lambda( compiled_start_1_38, 211, 0 );
  twobit_setglbl( 212 ); /*  %string-prefix?~1ayXVW~7609 */
  twobit_lambda( compiled_start_1_39, 214, 0 );
  twobit_setglbl( 215 ); /*  %string-suffix?~1ayXVW~7610 */
  twobit_lambda( compiled_start_1_40, 217, 0 );
  twobit_setglbl( 218 ); /*  %string-prefix-ci?~1ayXVW~7611 */
  twobit_lambda( compiled_start_1_41, 220, 0 );
  twobit_setglbl( 221 ); /*  %string-suffix-ci?~1ayXVW~7612 */
  twobit_lambda( compiled_start_1_42, 223, 0 );
  twobit_setglbl( 224 ); /*  %string-compare~1ayXVW~7613 */
  twobit_lambda( compiled_start_1_43, 226, 0 );
  twobit_setglbl( 227 ); /*  %string-compare-ci~1ayXVW~7614 */
  twobit_lambda( compiled_start_1_44, 229, 0 );
  twobit_setglbl( 230 ); /*  string-compare~1ayXVW~7615 */
  twobit_lambda( compiled_start_1_45, 232, 0 );
  twobit_setglbl( 233 ); /*  string-compare-ci~1ayXVW~7616 */
  twobit_lambda( compiled_start_1_46, 235, 0 );
  twobit_setglbl( 236 ); /*  string=~1ayXVW~7617 */
  twobit_lambda( compiled_start_1_47, 238, 0 );
  twobit_setglbl( 239 ); /*  string<>~1ayXVW~7618 */
  twobit_lambda( compiled_start_1_48, 241, 0 );
  twobit_setglbl( 242 ); /*  string<~1ayXVW~7619 */
  twobit_lambda( compiled_start_1_49, 244, 0 );
  twobit_setglbl( 245 ); /*  string>~1ayXVW~7620 */
  twobit_lambda( compiled_start_1_50, 247, 0 );
  twobit_setglbl( 248 ); /*  string<=~1ayXVW~7621 */
  twobit_lambda( compiled_start_1_51, 250, 0 );
  twobit_setglbl( 251 ); /*  string>=~1ayXVW~7622 */
  twobit_lambda( compiled_start_1_52, 253, 0 );
  twobit_setglbl( 254 ); /*  string-ci=~1ayXVW~7623 */
  twobit_lambda( compiled_start_1_53, 256, 0 );
  twobit_setglbl( 257 ); /*  string-ci<>~1ayXVW~7624 */
  twobit_lambda( compiled_start_1_54, 259, 0 );
  twobit_setglbl( 260 ); /*  string-ci<~1ayXVW~7625 */
  twobit_lambda( compiled_start_1_55, 262, 0 );
  twobit_setglbl( 263 ); /*  string-ci>~1ayXVW~7626 */
  twobit_lambda( compiled_start_1_56, 265, 0 );
  twobit_setglbl( 266 ); /*  string-ci<=~1ayXVW~7627 */
  twobit_lambda( compiled_start_1_57, 268, 0 );
  twobit_setglbl( 269 ); /*  string-ci>=~1ayXVW~7628 */
  twobit_lambda( compiled_start_1_58, 271, 0 );
  twobit_setglbl( 272 ); /*  %string-hash~1ayXVW~7629 */
  twobit_lambda( compiled_start_1_59, 274, 0 );
  twobit_setglbl( 275 ); /*  string-hash~1ayXVW~7630 */
  twobit_lambda( compiled_start_1_60, 277, 0 );
  twobit_setglbl( 278 ); /*  string-hash-ci~1ayXVW~7631 */
  twobit_lambda( compiled_start_1_61, 280, 0 );
  twobit_setglbl( 281 ); /*  string-upcase~1ayXVW~7632 */
  twobit_lambda( compiled_start_1_62, 283, 0 );
  twobit_setglbl( 49 ); /*  string-upcase!~1ayXVW~7633 */
  twobit_lambda( compiled_start_1_63, 285, 0 );
  twobit_setglbl( 48 ); /*  string-downcase~1ayXVW~7634 */
  twobit_lambda( compiled_start_1_64, 287, 0 );
  twobit_setglbl( 47 ); /*  string-downcase!~1ayXVW~7635 */
  twobit_lambda( compiled_start_1_65, 289, 0 );
  twobit_setglbl( 46 ); /*  %string-titlecase!~1ayXVW~7636 */
  twobit_lambda( compiled_start_1_66, 291, 0 );
  twobit_setglbl( 45 ); /*  string-titlecase!~1ayXVW~7637 */
  twobit_lambda( compiled_start_1_67, 293, 0 );
  twobit_setglbl( 44 ); /*  string-titlecase~1ayXVW~7638 */
  twobit_lambda( compiled_start_1_68, 295, 0 );
  twobit_setglbl( 43 ); /*  string-take~1ayXVW~7639 */
  twobit_lambda( compiled_start_1_69, 297, 0 );
  twobit_setglbl( 42 ); /*  string-take-right~1ayXVW~7640 */
  twobit_lambda( compiled_start_1_70, 299, 0 );
  twobit_setglbl( 41 ); /*  string-drop~1ayXVW~7641 */
  twobit_lambda( compiled_start_1_71, 301, 0 );
  twobit_setglbl( 40 ); /*  string-drop-right~1ayXVW~7642 */
  twobit_lambda( compiled_start_1_72, 303, 0 );
  twobit_setglbl( 39 ); /*  string-trim~1ayXVW~7643 */
  twobit_lambda( compiled_start_1_73, 305, 0 );
  twobit_setglbl( 38 ); /*  string-trim-right~1ayXVW~7644 */
  twobit_lambda( compiled_start_1_74, 307, 0 );
  twobit_setglbl( 37 ); /*  string-trim-both~1ayXVW~7645 */
  twobit_lambda( compiled_start_1_75, 309, 0 );
  twobit_setglbl( 36 ); /*  string-pad-right~1ayXVW~7646 */
  twobit_lambda( compiled_start_1_76, 311, 0 );
  twobit_setglbl( 35 ); /*  string-pad~1ayXVW~7647 */
  twobit_lambda( compiled_start_1_77, 313, 0 );
  twobit_setglbl( 34 ); /*  string-delete~1ayXVW~7648 */
  twobit_lambda( compiled_start_1_78, 315, 0 );
  twobit_setglbl( 33 ); /*  string-filter~1ayXVW~7649 */
  twobit_lambda( compiled_start_1_79, 317, 0 );
  twobit_setglbl( 32 ); /*  string-index~1ayXVW~7650 */
  twobit_lambda( compiled_start_1_80, 319, 0 );
  twobit_setglbl( 31 ); /*  string-index-right~1ayXVW~7651 */
  twobit_lambda( compiled_start_1_81, 321, 0 );
  twobit_setglbl( 30 ); /*  string-skip~1ayXVW~7652 */
  twobit_lambda( compiled_start_1_82, 323, 0 );
  twobit_setglbl( 29 ); /*  string-skip-right~1ayXVW~7653 */
  twobit_lambda( compiled_start_1_83, 325, 0 );
  twobit_setglbl( 28 ); /*  string-count~1ayXVW~7654 */
  twobit_lambda( compiled_start_1_84, 327, 0 );
  twobit_setglbl( 27 ); /*  string-fill!~1ayXVW~7655 */
  twobit_lambda( compiled_start_1_85, 329, 0 );
  twobit_setglbl( 26 ); /*  string-copy!~1ayXVW~7656 */
  twobit_lambda( compiled_start_1_86, 331, 0 );
  twobit_setglbl( 25 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_lambda( compiled_start_1_87, 333, 0 );
  twobit_setglbl( 24 ); /*  string-contains~1ayXVW~7658 */
  twobit_lambda( compiled_start_1_88, 335, 0 );
  twobit_setglbl( 23 ); /*  string-contains-ci~1ayXVW~7659 */
  twobit_lambda( compiled_start_1_89, 337, 0 );
  twobit_setglbl( 22 ); /*  %kmp-search~1ayXVW~7660 */
  twobit_lambda( compiled_start_1_90, 339, 0 );
  twobit_setglbl( 21 ); /*  make-kmp-restart-vector~1ayXVW~7661 */
  twobit_lambda( compiled_start_1_91, 341, 0 );
  twobit_setglbl( 20 ); /*  kmp-step~1ayXVW~7662 */
  twobit_lambda( compiled_start_1_92, 343, 0 );
  twobit_setglbl( 19 ); /*  string-kmp-partial-search~1ayXVW~7663 */
  twobit_lambda( compiled_start_1_93, 345, 0 );
  twobit_setglbl( 18 ); /*  string-null?~1ayXVW~7664 */
  twobit_lambda( compiled_start_1_94, 347, 0 );
  twobit_setglbl( 17 ); /*  string-reverse~1ayXVW~7665 */
  twobit_lambda( compiled_start_1_95, 349, 0 );
  twobit_setglbl( 16 ); /*  string-reverse!~1ayXVW~7666 */
  twobit_lambda( compiled_start_1_96, 351, 0 );
  twobit_setglbl( 15 ); /*  reverse-list->string~1ayXVW~7667 */
  twobit_lambda( compiled_start_1_97, 353, 0 );
  twobit_setglbl( 14 ); /*  string->list~1ayXVW~7668 */
  twobit_lambda( compiled_start_1_98, 355, 0 );
  twobit_setglbl( 13 ); /*  string-append/shared~1ayXVW~7669 */
  twobit_lambda( compiled_start_1_99, 357, 0 );
  twobit_setglbl( 12 ); /*  string-concatenate/shared~1ayXVW~7670 */
  twobit_lambda( compiled_start_1_100, 359, 0 );
  twobit_setglbl( 11 ); /*  string-concatenate~1ayXVW~7671 */
  twobit_lambda( compiled_start_1_101, 361, 0 );
  twobit_setglbl( 10 ); /*  string-concatenate-reverse~1ayXVW~7672 */
  twobit_lambda( compiled_start_1_102, 363, 0 );
  twobit_setglbl( 9 ); /*  string-concatenate-reverse/shared~1ayXVW~7673 */
  twobit_lambda( compiled_start_1_103, 365, 0 );
  twobit_setglbl( 8 ); /*  %finish-string-concatenate-reverse~1ayXVW~7674 */
  twobit_lambda( compiled_start_1_104, 367, 0 );
  twobit_setglbl( 7 ); /*  string-replace~1ayXVW~7675 */
  twobit_lambda( compiled_start_1_105, 369, 0 );
  twobit_setglbl( 6 ); /*  string-tokenize~1ayXVW~7676 */
  twobit_lambda( compiled_start_1_106, 371, 0 );
  twobit_setglbl( 5 ); /*  xsubstring~1ayXVW~7677 */
  twobit_lambda( compiled_start_1_107, 373, 0 );
  twobit_setglbl( 4 ); /*  string-xcopy!~1ayXVW~7678 */
  twobit_lambda( compiled_start_1_108, 375, 0 );
  twobit_setglbl( 3 ); /*  %multispan-repcopy!~1ayXVW~7679 */
  twobit_lambda( compiled_start_1_109, 377, 0 );
  twobit_setglbl( 2 ); /*  string-join~1ayXVW~7680 */
  twobit_global( 378 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_movereg( 2, 4 );
  twobit_movereg( 1, 3 );
  twobit_global( 1 ); /* assertion-violation */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* apply */
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* char-upcase */
  twobit_setrtn( 1116, compiled_block_1_1116 );
  twobit_invoke( 1 );
  twobit_label( 1116, compiled_block_1_1116 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* char-downcase */
  twobit_setrtn( 1117, compiled_block_1_1117 );
  twobit_invoke( 1 );
  twobit_label( 1117, compiled_block_1_1117 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_87( 4 ); /* char=? */
  twobit_op1_9(); /* not */
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_6( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 1 );
  twobit_store( 3, 3 );
  twobit_reg( 2 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_branchf( 1119, compiled_block_1_1119 );
  twobit_op1_3(); /* unspecified */
  twobit_skip( 1118, compiled_block_1_1118 );
  twobit_label( 1119, compiled_block_1_1119 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~7479 */
  twobit_setrtn( 1120, compiled_block_1_1120 );
  twobit_invoke( 3 );
  twobit_label( 1120, compiled_block_1_1120 );
  twobit_load( 0, 0 );
  twobit_label( 1118, compiled_block_1_1118 );
  twobit_stack( 2 );
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1121, compiled_block_1_1121 );
  twobit_stack( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op1_branchf_611( 1123, compiled_block_1_1123 ); /* internal:branchf-pair? */
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_reg( 2 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1125, compiled_block_1_1125 );
  twobit_reg( 2 );
  twobit_op1_25(); /* exact? */
  twobit_branchf( 1127, compiled_block_1_1127 );
  twobit_reg( 2 );
  twobit_op2imm_136( fixnum(0), 774, compiled_temp_1_774 ); /* >= */
  twobit_skip( 1124, compiled_block_1_1124 );
  twobit_label( 1127, compiled_block_1_1127 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1124, compiled_block_1_1124 );
  twobit_label( 1125, compiled_block_1_1125 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1124, compiled_block_1_1124 );
  twobit_branchf( 1129, compiled_block_1_1129 );
  twobit_load( 2, 4 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_775, 4, 4 );
  twobit_setreg( 4 );
  twobit_load( 3, 3 );
  twobit_lambda( compiled_start_1_776, 6, 3 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 7 ); /* call-with-values */
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 1129, compiled_block_1_1129 );
  twobit_load( 2, 4 );
  twobit_load( 4, 1 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_load( 3, 3 );
  twobit_global( 2 ); /*  error~1ayXVW~7479 */
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 1123, compiled_block_1_1123 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_movereg( 4, 3 );
  twobit_global( 9 ); /* values */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 1121, compiled_block_1_1121 );
  twobit_trap( 3, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_775( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 3 );
  twobit_op1_branchf_611( 1131, compiled_block_1_1131 ); /* internal:branchf-pair? */
  twobit_lexical( 0, 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1133, compiled_block_1_1133 );
  twobit_reg( 3 );
  twobit_op1_25(); /* exact? */
  twobit_branchf( 1135, compiled_block_1_1135 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2_67( 2, 778, compiled_temp_1_778 ); /* <= */
  twobit_skip( 1132, compiled_block_1_1132 );
  twobit_label( 1135, compiled_block_1_1135 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1132, compiled_block_1_1132 );
  twobit_label( 1133, compiled_block_1_1133 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1132, compiled_block_1_1132 );
  twobit_branchf( 1137, compiled_block_1_1137 );
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1137, compiled_block_1_1137 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_global( 3 ); /*  error~1ayXVW~7479 */
  twobit_invoke( 4 );
  twobit_label( 1131, compiled_block_1_1131 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_776( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 3 );
  twobit_op2_branchf_622( 1, 777, compiled_temp_1_777, 1142, compiled_block_1_1142 ); /* internal:branchf-<= */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /* values */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_label( 1142, compiled_block_1_1142 );
  twobit_movereg( 1, 4 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 5 );
  twobit_global( 3 ); /*  error~1ayXVW~7479 */
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_7( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_lambda( compiled_start_1_772, 2, 3 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_773, 4, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_772( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_773( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1150, compiled_block_1_1150 ); /* internal:branchf-pair? */
  twobit_movereg( 1, 3 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  error~1ayXVW~7479 */
  twobit_invoke( 3 );
  twobit_label( 1150, compiled_block_1_1150 );
  twobit_movereg( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_global( 3 ); /* values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_8( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 1155, compiled_block_1_1155 );
  twobit_reg( 2 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1157, compiled_block_1_1157 );
  twobit_reg( 2 );
  twobit_op1_25(); /* exact? */
  twobit_branchf( 1159, compiled_block_1_1159 );
  twobit_reg( 3 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1161, compiled_block_1_1161 );
  twobit_reg( 3 );
  twobit_op1_25(); /* exact? */
  twobit_branchf( 1163, compiled_block_1_1163 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_branchf_622( 2, 769, compiled_temp_1_769, 1165, compiled_block_1_1165 ); /* internal:branchf-<= */
  twobit_reg( 2 );
  twobit_op2_branchf_622( 3, 770, compiled_temp_1_770, 1167, compiled_block_1_1167 ); /* internal:branchf-<= */
  twobit_reg( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_67( 4, 771, compiled_temp_1_771 ); /* <= */
  twobit_return();
  twobit_label( 1167, compiled_block_1_1167 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1165, compiled_block_1_1165 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1163, compiled_block_1_1163 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1161, compiled_block_1_1161 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1159, compiled_block_1_1159 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1157, compiled_block_1_1157 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1155, compiled_block_1_1155 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_9( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_store( 4, 4 );
  twobit_movereg( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 4, 3 );
  twobit_global( 1 ); /*  substring-spec-ok?~1ayXVW~7579 */
  twobit_setrtn( 1168, compiled_block_1_1168 );
  twobit_invoke( 3 );
  twobit_label( 1168, compiled_block_1_1168 );
  twobit_load( 0, 0 );
  twobit_branchf( 1170, compiled_block_1_1170 );
  twobit_op1_3(); /* unspecified */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1170, compiled_block_1_1170 );
  twobit_load( 2, 1 );
  twobit_load( 3, 2 );
  twobit_load( 4, 3 );
  twobit_stack( 4 );
  twobit_setreg( 1 );
  twobit_movereg( 1, 5 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~7479 */
  twobit_pop( 4 );
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_10( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 1, 0, 0, 1172, compiled_block_1_1172 );
  twobit_reg( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1174, compiled_block_1_1174 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1176, compiled_block_1_1176 ); /* internal:branchf-null? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1178, compiled_block_1_1178 );
  twobit_reg( 31 );
  twobit_op1_25(); /* exact? */
  twobit_branchf( 1180, compiled_block_1_1180 );
  twobit_reg( 2 );
  twobit_op2_branchf_622( 31, 767, compiled_temp_1_767, 1182, compiled_block_1_1182 ); /* internal:branchf-<= */
  twobit_reg( 31 );
  twobit_op2_67( 4, 768, compiled_temp_1_768 ); /* <= */
  twobit_skip( 1177, compiled_block_1_1177 );
  twobit_label( 1182, compiled_block_1_1182 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1177, compiled_block_1_1177 );
  twobit_label( 1180, compiled_block_1_1180 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1177, compiled_block_1_1177 );
  twobit_label( 1178, compiled_block_1_1178 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1177, compiled_block_1_1177 );
  twobit_branchf( 1184, compiled_block_1_1184 );
  twobit_reg( 31 );
  twobit_skip( 1173, compiled_block_1_1173 );
  twobit_label( 1184, compiled_block_1_1184 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_movereg( 31, 2 );
  twobit_global( 2 ); /* error */
  twobit_setrtn( 1185, compiled_block_1_1185 );
  twobit_invoke( 2 );
  twobit_label( 1185, compiled_block_1_1185 );
  twobit_load( 0, 0 );
  twobit_skip( 1173, compiled_block_1_1173 );
  twobit_label( 1176, compiled_block_1_1176 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* error */
  twobit_setrtn( 1186, compiled_block_1_1186 );
  twobit_invoke( 1 );
  twobit_label( 1186, compiled_block_1_1186 );
  twobit_load( 0, 0 );
  twobit_skip( 1173, compiled_block_1_1173 );
  twobit_label( 1174, compiled_block_1_1174 );
  twobit_reg( 4 );
  twobit_label( 1173, compiled_block_1_1173 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 4 ); /*  %substring/shared~1ayXVW~7582 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1172, compiled_block_1_1172 );
  twobit_trap( 1, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_11( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 2 );
  twobit_op1_branchf_612( 765, compiled_temp_1_765, 1189, compiled_block_1_1189 ); /* internal:branchf-zero? */
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 1, 0, 0, 1190, compiled_block_1_1190 );
  twobit_reg( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_68( 4, 766, compiled_temp_1_766 ); /* = */
  twobit_skip( 1188, compiled_block_1_1188 );
  twobit_label( 1189, compiled_block_1_1189 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1188, compiled_block_1_1188 );
  twobit_branchf( 1192, compiled_block_1_1192 );
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1192, compiled_block_1_1192 );
  twobit_global( 1 ); /* substring */
  twobit_invoke( 3 );
  twobit_label( 1190, compiled_block_1_1190 );
  twobit_trap( 1, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_12( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_lambda( compiled_start_1_763, 2, 2 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_764, 4, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_763( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-copy~1ayXVW~7583 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_764( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* substring */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_13( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_761, 2, 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_762, 4, 2 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_761( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-map~1ayXVW~7584 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_762( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 1, 3 );
  twobit_movereg( 2, 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  %string-map~1ayXVW~7585 */
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_14( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_reg( 4 );
  twobit_op2_62( 3, 756, compiled_temp_1_756 ); /* - */
  twobit_setreg( 3 );
  twobit_imm_const( int_to_char(32) ); /* #\space */
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op2_799( 31 ); /* make-ustring */
  twobit_setreg( 31 );
  twobit_store( 31, 4 );
  twobit_reg( 4 );
  twobit_op2imm_131( fixnum(1), 757, compiled_temp_1_757 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 3 );
  twobit_op2imm_131( fixnum(1), 758, compiled_temp_1_758 ); /* - */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 30 );
  twobit_movereg( 31, 4 );
  twobit_movereg( 30, 3 );
  twobit_lambda( compiled_start_1_759, 3, 4 );
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_load( 2, 1 );
  twobit_load( 1, 2 );
  twobit_load( 4, 3 );
  twobit_reg( 30 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 30 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1206, compiled_block_1_1206 );
  twobit_invoke( 2 );
  twobit_label( 1206, compiled_block_1_1206 );
  twobit_load( 0, 0 );
  twobit_stack( 4 );
  twobit_pop( 4 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_759( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op2imm_branchf_635( fixnum(0), 760, compiled_temp_1_760, 1201, compiled_block_1_1201 ); /* internal:branchf-</imm */
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1201, compiled_block_1_1201 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1202, compiled_block_1_1202 );
  twobit_lexical( 0, 2 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1202, compiled_block_1_1202 );
  twobit_lexical( 0, 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1202, compiled_block_1_1202 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1202, compiled_block_1_1202 );
  twobit_lexical( 0, 2 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1203, compiled_block_1_1203 );
  twobit_invoke( 1 );
  twobit_label( 1203, compiled_block_1_1203 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 2, 1204, compiled_block_1_1204 );
  twobit_lexical( 0, 4 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 2, 1204, compiled_block_1_1204 );
  twobit_stack( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 2, 1204, compiled_block_1_1204 );
  twobit_reg( 4 );
  twobit_op1_36(); /* char? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 2, 1204, compiled_block_1_1204 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 4 );
  twobit_op3_803( 3, 4 ); /* ustring-set!:trusted */
  twobit_stack( 2 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1204, compiled_block_1_1204 );
  twobit_trap( 2, 1, 4, 61 );
  twobit_label( 1202, compiled_block_1_1202 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_15( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_754, 2, 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_755, 4, 2 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_754( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-map!~1ayXVW~7586 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_755( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 1, 3 );
  twobit_movereg( 2, 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  %string-map!~1ayXVW~7587 */
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_16( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 4 );
  twobit_op2imm_131( fixnum(1), 751, compiled_temp_1_751 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 31 );
  twobit_movereg( 31, 4 );
  twobit_lambda( compiled_start_1_752, 3, 4 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 31 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_752( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 753, compiled_temp_1_753, 1211, compiled_block_1_1211 ); /* internal:branchf-< */
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1211, compiled_block_1_1211 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1212, compiled_block_1_1212 );
  twobit_lexical( 0, 2 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1212, compiled_block_1_1212 );
  twobit_lexical( 0, 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1212, compiled_block_1_1212 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1212, compiled_block_1_1212 );
  twobit_lexical( 0, 2 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1213, compiled_block_1_1213 );
  twobit_invoke( 1 );
  twobit_label( 1213, compiled_block_1_1213 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_36(); /* char? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 2, 1214, compiled_block_1_1214 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 2 );
  twobit_op3_803( 3, 4 ); /* ustring-set!:trusted */
  twobit_reg( 3 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1214, compiled_block_1_1214 );
  twobit_trap( 2, 1, 4, 61 );
  twobit_label( 1212, compiled_block_1_1212 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_17( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_746, 2, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_747, 4, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_746( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_748, 3, 2 );
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_748( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_branchf_619( 4, 749, compiled_temp_1_749, 1218, compiled_block_1_1218 ); /* internal:branchf-< */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 2 );
  twobit_op2imm_130( fixnum(1), 750, compiled_temp_1_750 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 2 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 2, 31, 0, 1219, compiled_block_1_1219 );
  twobit_lexical( 1, 3 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 3 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 2, 31, 0, 1219, compiled_block_1_1219 );
  twobit_lexical( 1, 3 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 2, 31, 0, 1219, compiled_block_1_1219 );
  twobit_reg( 2 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 2, 31, 0, 1219, compiled_block_1_1219 );
  twobit_lexical( 1, 3 );
  twobit_op2_802( 2 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_lexical( 1, 1 );
  twobit_setrtn( 1220, compiled_block_1_1220 );
  twobit_invoke( 2 );
  twobit_label( 1220, compiled_block_1_1220 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1218, compiled_block_1_1218 );
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1219, compiled_block_1_1219 );
  twobit_trap( 31, 2, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_747( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-fold~1ayXVW~7588 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_18( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_740, 2, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_741, 4, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_740( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 2 );
  twobit_op2imm_131( fixnum(1), 742, compiled_temp_1_742 ); /* - */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_743, 3, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_743( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_branchf_621( 4, 744, compiled_temp_1_744, 1226, compiled_block_1_1226 ); /* internal:branchf->= */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 2 );
  twobit_op2imm_131( fixnum(1), 745, compiled_temp_1_745 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 2 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 2, 31, 0, 1227, compiled_block_1_1227 );
  twobit_lexical( 1, 3 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 3 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 2, 31, 0, 1227, compiled_block_1_1227 );
  twobit_lexical( 1, 3 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 2, 31, 0, 1227, compiled_block_1_1227 );
  twobit_reg( 2 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 2, 31, 0, 1227, compiled_block_1_1227 );
  twobit_lexical( 1, 3 );
  twobit_op2_802( 2 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_lexical( 1, 1 );
  twobit_setrtn( 1228, compiled_block_1_1228 );
  twobit_invoke( 2 );
  twobit_label( 1228, compiled_block_1_1228 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1226, compiled_block_1_1226 );
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1227, compiled_block_1_1227 );
  twobit_trap( 31, 2, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_741( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-fold-right~1ayXVW~7589 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_19( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 4 );
  twobit_lambda( compiled_start_1_722, 2, 4 );
  twobit_setreg( 2 );
  twobit_movereg( 5, 1 );
  twobit_lambda( compiled_start_1_723, 4, 1 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_722( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_724, 2, 1 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_725, 4, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_724( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_610( 1234, compiled_block_1_1234 ); /* internal:branchf-null? */
  twobit_lambda( compiled_start_1_739, 2, 0 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 3 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1234, compiled_block_1_1234 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 1236, compiled_block_1_1236 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1238, compiled_block_1_1238 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 3 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1238, compiled_block_1_1238 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 5 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1236, compiled_block_1_1236 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_739( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_const( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_725( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1242, compiled_block_1_1242 ); /* internal:branchf-null? */
  twobit_imm_const( int_to_char(32) ); /* #\space */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(40) ); /* 40 */
  twobit_op2_799( 4 ); /* make-ustring */
  twobit_setreg( 3 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_726, 3, 2 );
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_op2_84( 1 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 7 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(40) ); /* 40 */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 5 );
  twobit_lexical( 1, 4 );
  twobit_setreg( 6 );
  twobit_reg( 7 );
  twobit_invoke( 6 );
  twobit_label( 1242, compiled_block_1_1242 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /* error */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_726( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 6 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 5, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 31 );
  twobit_movereg( 31, 5 );
  twobit_lambda( compiled_start_1_727, 3, 5 );
  twobit_setreg( 4 );
  twobit_movereg( 6, 2 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 31 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_727( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_lexical( 3, 1 );
  twobit_setrtn( 1243, compiled_block_1_1243 );
  twobit_invoke( 1 );
  twobit_label( 1243, compiled_block_1_1243 );
  twobit_load( 0, 0 );
  twobit_branchf( 1245, compiled_block_1_1245 );
  twobit_load( 1, 1 );
  twobit_lexical( 1, 1 );
  twobit_setrtn( 1246, compiled_block_1_1246 );
  twobit_invoke( 1 );
  twobit_label( 1246, compiled_block_1_1246 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 4, 0, 0, 1247, compiled_block_1_1247 );
  twobit_reg( 4 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_lexical( 2, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 1 );
  twobit_lexical( 2, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 2, 0, 0, 1248, compiled_block_1_1248 );
  twobit_lexical( 2, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 2 );
  twobit_store( 2, 5 );
  twobit_load( 1, 2 );
  twobit_lexical( 0, 2 );
  twobit_op2_61( 1, 728, compiled_temp_1_728 ); /* + */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op2_61( 1, 729, compiled_temp_1_729 ); /* + */
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op2_61( 3, 730, compiled_temp_1_730 ); /* + */
  twobit_imm_const_setreg( int_to_char(32), 4 ); /*   */
  twobit_op2_799( 4 ); /* make-ustring */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_movereg( 4, 1 );
  twobit_movereg( 3, 5 );
  twobit_load( 2, 1 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_setrtn( 1249, compiled_block_1_1249 );
  twobit_invoke( 5 );
  twobit_label( 1249, compiled_block_1_1249 );
  twobit_load( 0, 0 );
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_stack( 1 );
  twobit_op2_62( 3, 731, compiled_temp_1_731 ); /* - */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 4, 5 );
  twobit_load( 1, 4 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_setrtn( 1250, compiled_block_1_1250 );
  twobit_invoke( 5 );
  twobit_label( 1250, compiled_block_1_1250 );
  twobit_load( 0, 0 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 4 );
  twobit_lambda( compiled_start_1_732, 4, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_setrtn( 1256, compiled_block_1_1256 );
  twobit_invoke( 2 );
  twobit_label( 1256, compiled_block_1_1256 );
  twobit_load( 0, 0 );
  twobit_load( 1, 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_lexical( 2, 1 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_load( 5, 5 );
  twobit_global( 1 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_setrtn( 1257, compiled_block_1_1257 );
  twobit_invoke( 5 );
  twobit_label( 1257, compiled_block_1_1257 );
  twobit_load( 0, 0 );
  twobit_stack( 4 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1245, compiled_block_1_1245 );
  twobit_load( 1, 1 );
  twobit_lexical( 3, 3 );
  twobit_setrtn( 1258, compiled_block_1_1258 );
  twobit_invoke( 1 );
  twobit_label( 1258, compiled_block_1_1258 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_lexical( 3, 2 );
  twobit_setrtn( 1259, compiled_block_1_1259 );
  twobit_invoke( 1 );
  twobit_label( 1259, compiled_block_1_1259 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_branchf_619( 3, 733, compiled_temp_1_733, 1261, compiled_block_1_1261 ); /* internal:branchf-< */
  twobit_load( 2, 3 );
  twobit_store( 2, 4 );
  twobit_stack( 2 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 1 );
  twobit_load( 4, 2 );
  twobit_load( 2, 1 );
  twobit_reg( 3 );
  twobit_check( 2, 4, 1, 1262, compiled_block_1_1262 );
  twobit_lexical( 0, 3 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_load( 3, 2 );
  twobit_load( 4, 1 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 2, 1263, compiled_block_1_1263 );
  twobit_lexical( 0, 3 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_load( 4, 1 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 2, 1263, compiled_block_1_1263 );
  twobit_stack( 2 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 2, 1263, compiled_block_1_1263 );
  twobit_stack( 1 );
  twobit_op1_36(); /* char? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 2, 1263, compiled_block_1_1263 );
  twobit_load( 4, 2 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 3 );
  twobit_op3_803( 4, 3 ); /* ustring-set!:trusted */
  twobit_reg( 4 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 5 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 4 );
  twobit_reg( 4 );
  twobit_pop( 5 );
  twobit_invoke( 2 );
  twobit_label( 1261, compiled_block_1_1261 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 4 );
  twobit_op2_61( 3, 734, compiled_temp_1_734 ); /* + */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(4096) ); /* 4096 */
  twobit_op2_branchf_622( 3, 735, compiled_temp_1_735, 1266, compiled_block_1_1266 ); /* internal:branchf-<= */
  twobit_imm_const( fixnum(4096) ); /* 4096 */
  twobit_skip( 1265, compiled_block_1_1265 );
  twobit_label( 1266, compiled_block_1_1266 );
  twobit_reg( 3 );
  twobit_label( 1265, compiled_block_1_1265 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_26(); /* inexact? */
  twobit_branchf( 1268, compiled_block_1_1268 );
  twobit_const( 5 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_61( 3, 736, compiled_temp_1_736 ); /* + */
  twobit_skip( 1267, compiled_block_1_1267 );
  twobit_label( 1268, compiled_block_1_1268 );
  twobit_reg( 2 );
  twobit_label( 1267, compiled_block_1_1267 );
  twobit_setreg( 3 );
  twobit_imm_const( int_to_char(32) ); /* #\space */
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_op2_799( 1 ); /* make-ustring */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_reg( 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(1),1269,compiled_block_1_1269); /* internal:check-<:fix:fix with (4 0 2) */
  twobit_reg( 4 );
  twobit_op1_36(); /* char? */
  twobit_check( 4, 0, 2, 1269, compiled_block_1_1269 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op3_803( 1, 4 ); /* ustring-set!:trusted */
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_61( 4, 737, compiled_temp_1_737 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 7 );
  twobit_movereg( 3, 4 );
  twobit_load( 3, 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 5 );
  twobit_load( 6, 3 );
  twobit_reg( 7 );
  twobit_pop( 5 );
  twobit_invoke( 6 );
  twobit_label( 1248, compiled_block_1_1248 );
  twobit_trap( 2, 0, 0, 62 );
  twobit_label( 1263, compiled_block_1_1263 );
  twobit_trap( 2, 3, 4, 61 );
  twobit_label( 1262, compiled_block_1_1262 );
  twobit_trap( 1, 4, 2, 61 );
  twobit_label( 1269, compiled_block_1_1269 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 4, 61 );
  twobit_label( 1247, compiled_block_1_1247 );
  twobit_trap( 4, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_732( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1252, compiled_block_1_1252 ); /* internal:branchf-pair? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 4, 0, 0, 1253, compiled_block_1_1253 );
  twobit_reg( 4 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_reg( 1 );
  twobit_op2_62( 2, 738, compiled_temp_1_738 ); /* - */
  twobit_setreg( 1 );
  twobit_store( 1, 3 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_load( 5, 1 );
  twobit_global( 1 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_setrtn( 1254, compiled_block_1_1254 );
  twobit_invoke( 5 );
  twobit_label( 1254, compiled_block_1_1254 );
  twobit_load( 0, 0 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1252, compiled_block_1_1252 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1253, compiled_block_1_1253 );
  twobit_trap( 4, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_723( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_610( 1276, compiled_block_1_1276 ); /* internal:branchf-null? */
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1276, compiled_block_1_1276 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 1278, compiled_block_1_1278 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 1280, compiled_block_1_1280 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 2 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1280, compiled_block_1_1280 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 4 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1278, compiled_block_1_1278 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_20( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 4 );
  twobit_lambda( compiled_start_1_701, 2, 4 );
  twobit_setreg( 2 );
  twobit_movereg( 5, 1 );
  twobit_lambda( compiled_start_1_702, 4, 1 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_701( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_703, 2, 1 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_704, 4, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_703( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_610( 1285, compiled_block_1_1285 ); /* internal:branchf-null? */
  twobit_lambda( compiled_start_1_721, 2, 0 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 3 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1285, compiled_block_1_1285 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 1287, compiled_block_1_1287 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1289, compiled_block_1_1289 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 3 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1289, compiled_block_1_1289 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 5 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1287, compiled_block_1_1287 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_721( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_const( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_704( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1293, compiled_block_1_1293 ); /* internal:branchf-null? */
  twobit_imm_const( int_to_char(32) ); /* #\space */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(40) ); /* 40 */
  twobit_op2_799( 4 ); /* make-ustring */
  twobit_setreg( 3 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_705, 3, 2 );
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_op2_84( 1 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 7 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(40) ); /* 40 */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(40) ); /* 40 */
  twobit_setreg( 5 );
  twobit_lexical( 1, 4 );
  twobit_setreg( 6 );
  twobit_reg( 7 );
  twobit_invoke( 6 );
  twobit_label( 1293, compiled_block_1_1293 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /* error */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_705( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 6 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 5, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 31 );
  twobit_movereg( 31, 5 );
  twobit_lambda( compiled_start_1_706, 3, 5 );
  twobit_setreg( 4 );
  twobit_movereg( 6, 2 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 31 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_706( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_lexical( 3, 1 );
  twobit_setrtn( 1294, compiled_block_1_1294 );
  twobit_invoke( 1 );
  twobit_label( 1294, compiled_block_1_1294 );
  twobit_load( 0, 0 );
  twobit_branchf( 1296, compiled_block_1_1296 );
  twobit_load( 1, 1 );
  twobit_lexical( 1, 1 );
  twobit_setrtn( 1297, compiled_block_1_1297 );
  twobit_invoke( 1 );
  twobit_label( 1297, compiled_block_1_1297 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 4, 0, 0, 1298, compiled_block_1_1298 );
  twobit_reg( 4 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_lexical( 2, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 1 );
  twobit_lexical( 2, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 2, 0, 0, 1299, compiled_block_1_1299 );
  twobit_lexical( 2, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 2 );
  twobit_store( 2, 6 );
  twobit_load( 1, 2 );
  twobit_lexical( 0, 4 );
  twobit_op2_62( 1, 707, compiled_temp_1_707 ); /* - */
  twobit_setreg( 1 );
  twobit_store( 1, 5 );
  twobit_lexical( 0, 2 );
  twobit_op2_61( 1, 708, compiled_temp_1_708 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_61( 4, 709, compiled_temp_1_709 ); /* + */
  twobit_op2_61( 3, 710, compiled_temp_1_710 ); /* + */
  twobit_imm_const_setreg( int_to_char(32), 4 ); /*   */
  twobit_op2_799( 4 ); /* make-ustring */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_movereg( 4, 1 );
  twobit_movereg( 3, 5 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_load( 3, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_setrtn( 1300, compiled_block_1_1300 );
  twobit_invoke( 5 );
  twobit_label( 1300, compiled_block_1_1300 );
  twobit_load( 0, 0 );
  twobit_load( 4, 2 );
  twobit_load( 1, 3 );
  twobit_load( 2, 4 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 5 );
  twobit_global( 1 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_setrtn( 1301, compiled_block_1_1301 );
  twobit_invoke( 5 );
  twobit_label( 1301, compiled_block_1_1301 );
  twobit_load( 0, 0 );
  twobit_load( 4, 5 );
  twobit_stack( 4 );
  twobit_op2_61( 4, 711, compiled_temp_1_711 ); /* + */
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_load( 2, 6 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_712, 4, 3 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_setrtn( 1308, compiled_block_1_1308 );
  twobit_invoke( 2 );
  twobit_label( 1308, compiled_block_1_1308 );
  twobit_load( 0, 0 );
  twobit_stack( 3 );
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1296, compiled_block_1_1296 );
  twobit_load( 1, 1 );
  twobit_lexical( 3, 3 );
  twobit_setrtn( 1309, compiled_block_1_1309 );
  twobit_invoke( 1 );
  twobit_label( 1309, compiled_block_1_1309 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_lexical( 3, 2 );
  twobit_setrtn( 1310, compiled_block_1_1310 );
  twobit_invoke( 1 );
  twobit_label( 1310, compiled_block_1_1310 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_stack( 2 );
  twobit_op2imm_branchf_636( fixnum(0), 713, compiled_temp_1_713, 1312, compiled_block_1_1312 ); /* internal:branchf->/imm */
  twobit_load( 2, 3 );
  twobit_store( 2, 4 );
  twobit_stack( 2 );
  twobit_op2imm_131( fixnum(1), 714, compiled_temp_1_714 ); /* - */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 3 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_reg( 1 );
  twobit_check( 3, 3, 4, 1313, compiled_block_1_1313 );
  twobit_lexical( 0, 3 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_load( 1, 2 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_check( 2, 1, 3, 1314, compiled_block_1_1314 );
  twobit_lexical( 0, 3 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_load( 3, 2 );
  twobit_load( 4, 1 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 2, 1315, compiled_block_1_1315 );
  twobit_stack( 2 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 2, 1315, compiled_block_1_1315 );
  twobit_stack( 1 );
  twobit_op1_36(); /* char? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 2, 1315, compiled_block_1_1315 );
  twobit_load( 4, 2 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 3 );
  twobit_op3_803( 4, 3 ); /* ustring-set!:trusted */
  twobit_lexical( 0, 5 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_movereg( 4, 1 );
  twobit_load( 2, 4 );
  twobit_reg( 3 );
  twobit_pop( 6 );
  twobit_invoke( 2 );
  twobit_label( 1312, compiled_block_1_1312 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 4 );
  twobit_op2_61( 3, 715, compiled_temp_1_715 ); /* + */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(4096) ); /* 4096 */
  twobit_op2_branchf_622( 3, 716, compiled_temp_1_716, 1318, compiled_block_1_1318 ); /* internal:branchf-<= */
  twobit_imm_const( fixnum(4096) ); /* 4096 */
  twobit_skip( 1317, compiled_block_1_1317 );
  twobit_label( 1318, compiled_block_1_1318 );
  twobit_reg( 3 );
  twobit_label( 1317, compiled_block_1_1317 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_26(); /* inexact? */
  twobit_branchf( 1320, compiled_block_1_1320 );
  twobit_const( 5 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_61( 3, 717, compiled_temp_1_717 ); /* + */
  twobit_skip( 1319, compiled_block_1_1319 );
  twobit_label( 1320, compiled_block_1_1320 );
  twobit_reg( 2 );
  twobit_label( 1319, compiled_block_1_1319 );
  twobit_setreg( 3 );
  twobit_imm_const( int_to_char(32) ); /* #\space */
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_op2_799( 1 ); /* make-ustring */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_reg( 3 );
  twobit_op2imm_131( fixnum(1), 718, compiled_temp_1_718 ); /* - */
  twobit_setreg( 1 );
  twobit_store( 1, 4 );
  twobit_reg_op1_check_651(reg(1),1321,compiled_block_1_1321); /* internal:check-fixnum? with (4 1 2) */
  twobit_reg( 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_load( 4, 1 );
  twobit_check( 4, 1, 2, 1321, compiled_block_1_1321 );
  twobit_reg_op2imm_check_660(reg(1),fixnum(0),1321,compiled_block_1_1321); /* internal:check->=:fix:fix/imm with (4 1 2) */
  twobit_stack( 1 );
  twobit_op1_36(); /* char? */
  twobit_check( 4, 1, 2, 1321, compiled_block_1_1321 );
  twobit_reg( 2 );
  twobit_op3_803( 1, 4 ); /* ustring-set!:trusted */
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_61( 4, 719, compiled_temp_1_719 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 7 );
  twobit_movereg( 3, 4 );
  twobit_load( 3, 2 );
  twobit_load( 5, 4 );
  twobit_load( 6, 3 );
  twobit_reg( 7 );
  twobit_pop( 6 );
  twobit_invoke( 6 );
  twobit_label( 1314, compiled_block_1_1314 );
  twobit_trap( 3, 1, 2, 61 );
  twobit_label( 1299, compiled_block_1_1299 );
  twobit_trap( 2, 0, 0, 62 );
  twobit_label( 1315, compiled_block_1_1315 );
  twobit_trap( 2, 3, 4, 61 );
  twobit_label( 1321, compiled_block_1_1321 );
  twobit_trap( 2, 1, 4, 61 );
  twobit_label( 1313, compiled_block_1_1313 );
  twobit_trap( 4, 3, 3, 61 );
  twobit_label( 1298, compiled_block_1_1298 );
  twobit_trap( 4, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_712( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1303, compiled_block_1_1303 ); /* internal:branchf-pair? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 1, 2 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 4, 0, 0, 1304, compiled_block_1_1304 );
  twobit_reg( 4 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 31 );
  twobit_store( 31, 2 );
  twobit_movereg( 31, 30 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_movereg( 30, 5 );
  twobit_global( 1 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_setrtn( 1305, compiled_block_1_1305 );
  twobit_invoke( 5 );
  twobit_label( 1305, compiled_block_1_1305 );
  twobit_load( 0, 0 );
  twobit_load( 2, 1 );
  twobit_load( 4, 2 );
  twobit_stack( 3 );
  twobit_op2_61( 4, 720, compiled_temp_1_720 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1303, compiled_block_1_1303 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 3, 1 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 5 );
  twobit_global( 1 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_invoke( 5 );
  twobit_label( 1304, compiled_block_1_1304 );
  twobit_trap( 4, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_702( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_610( 1328, compiled_block_1_1328 ); /* internal:branchf-null? */
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1328, compiled_block_1_1328 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 1330, compiled_block_1_1330 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 1332, compiled_block_1_1332 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 2 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1332, compiled_block_1_1332 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 4 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1330, compiled_block_1_1330 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_21( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_697, 2, 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_698, 4, 2 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_697( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-for-each~1ayXVW~7592 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_698( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_699, 3, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_699( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 700, compiled_temp_1_700, 1338, compiled_block_1_1338 ); /* internal:branchf-< */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1339, compiled_block_1_1339 );
  twobit_lexical( 1, 2 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1339, compiled_block_1_1339 );
  twobit_lexical( 1, 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1339, compiled_block_1_1339 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1339, compiled_block_1_1339 );
  twobit_lexical( 1, 2 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setrtn( 1340, compiled_block_1_1340 );
  twobit_invoke( 1 );
  twobit_label( 1340, compiled_block_1_1340 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1338, compiled_block_1_1338 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1339, compiled_block_1_1339 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_22( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_692, 2, 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_693, 4, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_692( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-for-each-index~1ayXVW~7593 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_693( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_694, 3, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_694( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 695, compiled_temp_1_695, 1346, compiled_block_1_1346 ); /* internal:branchf-< */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_lexical( 1, 1 );
  twobit_setrtn( 1347, compiled_block_1_1347 );
  twobit_invoke( 1 );
  twobit_label( 1347, compiled_block_1_1347 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 696, compiled_temp_1_696 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1346, compiled_block_1_1346 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_23( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_683, 2, 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_684, 4, 2 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_683( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-every~1ayXVW~7594 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_684( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_615( 1353, compiled_block_1_1353 ); /* internal:branchf-char? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_685, 3, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1353, compiled_block_1_1353 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  char-set?~1ayXVW~6491 */
  twobit_setrtn( 1361, compiled_block_1_1361 );
  twobit_invoke( 1 );
  twobit_label( 1361, compiled_block_1_1361 );
  twobit_load( 0, 0 );
  twobit_branchf( 1363, compiled_block_1_1363 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_686, 6, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1363, compiled_block_1_1363 );
  twobit_lexical( 0, 1 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1373, compiled_block_1_1373 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_op2_68( 4, 687, compiled_temp_1_687 ); /* = */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_branchf( 1375, compiled_block_1_1375 );
  twobit_reg( 3 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1375, compiled_block_1_1375 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_688, 8, 2 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1373, compiled_block_1_1373 );
  twobit_global( 9 ); /*  string-every~1ayXVW~7594 */
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 11 ); /*  error~1ayXVW~7479 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_685( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_70( 4, 691, compiled_temp_1_691 ); /* >= */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1355, compiled_block_1_1355 );
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1355, compiled_block_1_1355 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1356, compiled_block_1_1356 );
  twobit_lexical( 1, 2 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1356, compiled_block_1_1356 );
  twobit_lexical( 1, 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1356, compiled_block_1_1356 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1356, compiled_block_1_1356 );
  twobit_lexical( 1, 2 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_op2_branchf_625( 4, 1358, compiled_block_1_1358 ); /* internal:branchf-char=? */
  twobit_reg( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 1358, compiled_block_1_1358 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1356, compiled_block_1_1356 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_686( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_70( 4, 690, compiled_temp_1_690 ); /* >= */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1365, compiled_block_1_1365 );
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1365, compiled_block_1_1365 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1366, compiled_block_1_1366 );
  twobit_lexical( 1, 2 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1366, compiled_block_1_1366 );
  twobit_lexical( 1, 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1366, compiled_block_1_1366 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1366, compiled_block_1_1366 );
  twobit_lexical( 1, 2 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  char-set-contains?~1ayXVW~6535 */
  twobit_setrtn( 1367, compiled_block_1_1367 );
  twobit_invoke( 2 );
  twobit_label( 1367, compiled_block_1_1367 );
  twobit_load( 0, 0 );
  twobit_branchf( 1369, compiled_block_1_1369 );
  twobit_stack( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1369, compiled_block_1_1369 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1366, compiled_block_1_1366 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_688( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1376, compiled_block_1_1376 );
  twobit_lexical( 1, 2 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1376, compiled_block_1_1376 );
  twobit_lexical( 1, 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1376, compiled_block_1_1376 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1376, compiled_block_1_1376 );
  twobit_lexical( 1, 2 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2_branchf_623( 2, 689, compiled_temp_1_689, 1378, compiled_block_1_1378 ); /* internal:branchf-= */
  twobit_movereg( 4, 1 );
  twobit_lexical( 1, 1 );
  twobit_invoke( 1 );
  twobit_label( 1378, compiled_block_1_1378 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_movereg( 4, 1 );
  twobit_lexical( 1, 1 );
  twobit_setrtn( 1380, compiled_block_1_1380 );
  twobit_invoke( 1 );
  twobit_label( 1380, compiled_block_1_1380 );
  twobit_load( 0, 0 );
  twobit_branchf( 1382, compiled_block_1_1382 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1382, compiled_block_1_1382 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1376, compiled_block_1_1376 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_24( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_674, 2, 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_675, 4, 2 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_674( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-any~1ayXVW~7595 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_675( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_615( 1389, compiled_block_1_1389 ); /* internal:branchf-char? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_676, 3, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1389, compiled_block_1_1389 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  char-set?~1ayXVW~6491 */
  twobit_setrtn( 1397, compiled_block_1_1397 );
  twobit_invoke( 1 );
  twobit_label( 1397, compiled_block_1_1397 );
  twobit_load( 0, 0 );
  twobit_branchf( 1399, compiled_block_1_1399 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_677, 6, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1399, compiled_block_1_1399 );
  twobit_lexical( 0, 1 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1409, compiled_block_1_1409 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_op2_branchf_619( 4, 678, compiled_temp_1_678, 1411, compiled_block_1_1411 ); /* internal:branchf-< */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_679, 8, 2 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1411, compiled_block_1_1411 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1409, compiled_block_1_1409 );
  twobit_global( 9 ); /*  string-any~1ayXVW~7595 */
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 11 ); /*  error~1ayXVW~7479 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_676( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 682, compiled_temp_1_682, 1391, compiled_block_1_1391 ); /* internal:branchf-< */
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1392, compiled_block_1_1392 );
  twobit_lexical( 1, 2 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1392, compiled_block_1_1392 );
  twobit_lexical( 1, 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1392, compiled_block_1_1392 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1392, compiled_block_1_1392 );
  twobit_lexical( 1, 2 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_op2_87( 4 ); /* char=? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1394, compiled_block_1_1394 );
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1394, compiled_block_1_1394 );
  twobit_reg( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 1391, compiled_block_1_1391 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1392, compiled_block_1_1392 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_677( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 681, compiled_temp_1_681, 1401, compiled_block_1_1401 ); /* internal:branchf-< */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1402, compiled_block_1_1402 );
  twobit_lexical( 1, 2 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1402, compiled_block_1_1402 );
  twobit_lexical( 1, 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1402, compiled_block_1_1402 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1402, compiled_block_1_1402 );
  twobit_lexical( 1, 2 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  char-set-contains?~1ayXVW~6535 */
  twobit_setrtn( 1403, compiled_block_1_1403 );
  twobit_invoke( 2 );
  twobit_label( 1403, compiled_block_1_1403 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1405, compiled_block_1_1405 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1405, compiled_block_1_1405 );
  twobit_stack( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1401, compiled_block_1_1401 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1402, compiled_block_1_1402 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_679( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1412, compiled_block_1_1412 );
  twobit_lexical( 1, 2 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1412, compiled_block_1_1412 );
  twobit_lexical( 1, 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1412, compiled_block_1_1412 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1412, compiled_block_1_1412 );
  twobit_lexical( 1, 2 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2_branchf_623( 2, 680, compiled_temp_1_680, 1414, compiled_block_1_1414 ); /* internal:branchf-= */
  twobit_movereg( 4, 1 );
  twobit_lexical( 1, 1 );
  twobit_invoke( 1 );
  twobit_label( 1414, compiled_block_1_1414 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_movereg( 4, 1 );
  twobit_lexical( 1, 1 );
  twobit_setrtn( 1416, compiled_block_1_1416 );
  twobit_invoke( 1 );
  twobit_label( 1416, compiled_block_1_1416 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1418, compiled_block_1_1418 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1418, compiled_block_1_1418 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1412, compiled_block_1_1412 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_25( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_imm_const( int_to_char(32) ); /* #\space */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_799( 4 ); /* make-ustring */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 2 );
  twobit_op2imm_131( fixnum(1), 671, compiled_temp_1_671 ); /* - */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 2 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_672, 3, 3 );
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_load( 1, 1 );
  twobit_load( 4, 2 );
  twobit_reg( 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1428, compiled_block_1_1428 );
  twobit_invoke( 1 );
  twobit_label( 1428, compiled_block_1_1428 );
  twobit_load( 0, 0 );
  twobit_stack( 3 );
  twobit_pop( 3 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_672( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(0), 673, compiled_temp_1_673, 1424, compiled_block_1_1424 ); /* internal:branchf-</imm */
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1424, compiled_block_1_1424 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1425, compiled_block_1_1425 );
  twobit_invoke( 1 );
  twobit_label( 1425, compiled_block_1_1425 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 2, 1426, compiled_block_1_1426 );
  twobit_lexical( 0, 3 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 2, 1426, compiled_block_1_1426 );
  twobit_stack( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 2, 1426, compiled_block_1_1426 );
  twobit_reg( 4 );
  twobit_op1_36(); /* char? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 2, 1426, compiled_block_1_1426 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 3 );
  twobit_op3_803( 3, 4 ); /* ustring-set!:trusted */
  twobit_reg( 3 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1426, compiled_block_1_1426 );
  twobit_trap( 2, 1, 4, 61 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_26( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 6 );
  twobit_reg( 6 );
  twobit_op2_62( 5, 660, compiled_temp_1_660 ); /* - */
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op2_62( 2, 661, compiled_temp_1_661 ); /* - */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op2_branchf_622( 31, 662, compiled_temp_1_662, 1430, compiled_block_1_1430 ); /* internal:branchf-<= */
  twobit_reg( 3 );
  twobit_skip( 1429, compiled_block_1_1429 );
  twobit_label( 1430, compiled_block_1_1430 );
  twobit_reg( 31 );
  twobit_label( 1429, compiled_block_1_1429 );
  twobit_setreg( 30 );
  twobit_reg( 3 );
  twobit_op1_26(); /* inexact? */
  twobit_branchf( 1432, compiled_block_1_1432 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1431, compiled_block_1_1431 );
  twobit_label( 1432, compiled_block_1_1432 );
  twobit_reg( 31 );
  twobit_op1_26(); /* inexact? */
  twobit_label( 1431, compiled_block_1_1431 );
  twobit_branchf( 1434, compiled_block_1_1434 );
  twobit_const( 1 );
  twobit_setreg( 3 );
  twobit_reg( 30 );
  twobit_op2_61( 3, 663, compiled_temp_1_663 ); /* + */
  twobit_skip( 1433, compiled_block_1_1433 );
  twobit_label( 1434, compiled_block_1_1434 );
  twobit_reg( 30 );
  twobit_label( 1433, compiled_block_1_1433 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_61( 3, 664, compiled_temp_1_664 ); /* + */
  twobit_setreg( 31 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 4, 1436, compiled_block_1_1436 ); /* internal:branchf-eq? */
  twobit_reg( 2 );
  twobit_op2_68( 5, 665, compiled_temp_1_665 ); /* = */
  twobit_skip( 1435, compiled_block_1_1435 );
  twobit_label( 1436, compiled_block_1_1436 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1435, compiled_block_1_1435 );
  twobit_branchf( 1438, compiled_block_1_1438 );
  twobit_reg( 3 );
  twobit_return();
  twobit_label( 1438, compiled_block_1_1438 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 5, 1 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 31, 5 );
  twobit_lambda( compiled_start_1_666, 4, 5 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_load( 1, 2 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_666( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_621( 4, 667, compiled_temp_1_667, 1440, compiled_block_1_1440 ); /* internal:branchf->= */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1439, compiled_block_1_1439 );
  twobit_label( 1440, compiled_block_1_1440 );
  twobit_reg( 2 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 2, 3, 0, 1441, compiled_block_1_1441 );
  twobit_lexical( 0, 4 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 2, 3, 0, 1441, compiled_block_1_1441 );
  twobit_lexical( 0, 4 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 2, 3, 0, 1441, compiled_block_1_1441 );
  twobit_reg( 2 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 2, 3, 0, 1441, compiled_block_1_1441 );
  twobit_lexical( 0, 4 );
  twobit_op2_802( 2 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 0, 1442, compiled_block_1_1442 );
  twobit_lexical( 0, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 0, 1442, compiled_block_1_1442 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 0, 1442, compiled_block_1_1442 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 0, 1442, compiled_block_1_1442 );
  twobit_lexical( 0, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_op2_branchf_625( 4, 1444, compiled_block_1_1444 ); /* internal:branchf-char=? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1439, compiled_block_1_1439 );
  twobit_label( 1444, compiled_block_1_1444 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_label( 1439, compiled_block_1_1439 );
  twobit_branchf( 1446, compiled_block_1_1446 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_62( 4, 668, compiled_temp_1_668 ); /* - */
  twobit_return();
  twobit_label( 1446, compiled_block_1_1446 );
  twobit_reg( 1 );
  twobit_op2imm_130( fixnum(1), 669, compiled_temp_1_669 ); /* + */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op2imm_130( fixnum(1), 670, compiled_temp_1_670 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 1442, compiled_block_1_1442 );
  twobit_trap( 31, 1, 0, 60 );
  twobit_label( 1441, compiled_block_1_1441 );
  twobit_trap( 3, 2, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_27( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 6 );
  twobit_reg( 6 );
  twobit_op2_62( 5, 646, compiled_temp_1_646 ); /* - */
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op2_62( 2, 647, compiled_temp_1_647 ); /* - */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op2_branchf_622( 31, 648, compiled_temp_1_648, 1450, compiled_block_1_1450 ); /* internal:branchf-<= */
  twobit_reg( 2 );
  twobit_skip( 1449, compiled_block_1_1449 );
  twobit_label( 1450, compiled_block_1_1450 );
  twobit_reg( 31 );
  twobit_label( 1449, compiled_block_1_1449 );
  twobit_setreg( 30 );
  twobit_reg( 2 );
  twobit_op1_26(); /* inexact? */
  twobit_branchf( 1452, compiled_block_1_1452 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1451, compiled_block_1_1451 );
  twobit_label( 1452, compiled_block_1_1452 );
  twobit_reg( 31 );
  twobit_op1_26(); /* inexact? */
  twobit_label( 1451, compiled_block_1_1451 );
  twobit_branchf( 1454, compiled_block_1_1454 );
  twobit_const( 1 );
  twobit_setreg( 2 );
  twobit_reg( 30 );
  twobit_op2_61( 2, 649, compiled_temp_1_649 ); /* + */
  twobit_skip( 1453, compiled_block_1_1453 );
  twobit_label( 1454, compiled_block_1_1454 );
  twobit_reg( 30 );
  twobit_label( 1453, compiled_block_1_1453 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2_62( 2, 650, compiled_temp_1_650 ); /* - */
  twobit_setreg( 31 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 4, 1456, compiled_block_1_1456 ); /* internal:branchf-eq? */
  twobit_reg( 3 );
  twobit_op2_68( 6, 651, compiled_temp_1_651 ); /* = */
  twobit_skip( 1455, compiled_block_1_1455 );
  twobit_label( 1456, compiled_block_1_1456 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1455, compiled_block_1_1455 );
  twobit_branchf( 1458, compiled_block_1_1458 );
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1458, compiled_block_1_1458 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_reg( 3 );
  twobit_op2imm_131( fixnum(1), 652, compiled_temp_1_652 ); /* - */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_reg( 6 );
  twobit_op2imm_131( fixnum(1), 653, compiled_temp_1_653 ); /* - */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 30 );
  twobit_movereg( 31, 5 );
  twobit_movereg( 30, 2 );
  twobit_lambda( compiled_start_1_654, 4, 5 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 30 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 30 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_654( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 655, compiled_temp_1_655, 1460, compiled_block_1_1460 ); /* internal:branchf-< */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1459, compiled_block_1_1459 );
  twobit_label( 1460, compiled_block_1_1460 );
  twobit_reg( 2 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 2, 3, 0, 1461, compiled_block_1_1461 );
  twobit_lexical( 0, 4 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 2, 3, 0, 1461, compiled_block_1_1461 );
  twobit_lexical( 0, 4 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 2, 3, 0, 1461, compiled_block_1_1461 );
  twobit_reg( 2 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 2, 3, 0, 1461, compiled_block_1_1461 );
  twobit_lexical( 0, 4 );
  twobit_op2_802( 2 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 0, 1462, compiled_block_1_1462 );
  twobit_lexical( 0, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 0, 1462, compiled_block_1_1462 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 0, 1462, compiled_block_1_1462 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 0, 1462, compiled_block_1_1462 );
  twobit_lexical( 0, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_op2_branchf_625( 4, 1464, compiled_block_1_1464 ); /* internal:branchf-char=? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1459, compiled_block_1_1459 );
  twobit_label( 1464, compiled_block_1_1464 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_label( 1459, compiled_block_1_1459 );
  twobit_branchf( 1466, compiled_block_1_1466 );
  twobit_lexical( 0, 3 );
  twobit_op2_62( 1, 656, compiled_temp_1_656 ); /* - */
  twobit_op2imm_131( fixnum(1), 657, compiled_temp_1_657 ); /* - */
  twobit_return();
  twobit_label( 1466, compiled_block_1_1466 );
  twobit_reg( 1 );
  twobit_op2imm_131( fixnum(1), 658, compiled_temp_1_658 ); /* - */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op2imm_131( fixnum(1), 659, compiled_temp_1_659 ); /* - */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 1462, compiled_block_1_1462 );
  twobit_trap( 31, 1, 0, 60 );
  twobit_label( 1461, compiled_block_1_1461 );
  twobit_trap( 3, 2, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_28( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 6 );
  twobit_reg( 6 );
  twobit_op2_62( 5, 635, compiled_temp_1_635 ); /* - */
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op2_62( 2, 636, compiled_temp_1_636 ); /* - */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op2_branchf_622( 31, 637, compiled_temp_1_637, 1470, compiled_block_1_1470 ); /* internal:branchf-<= */
  twobit_reg( 3 );
  twobit_skip( 1469, compiled_block_1_1469 );
  twobit_label( 1470, compiled_block_1_1470 );
  twobit_reg( 31 );
  twobit_label( 1469, compiled_block_1_1469 );
  twobit_setreg( 30 );
  twobit_reg( 3 );
  twobit_op1_26(); /* inexact? */
  twobit_branchf( 1472, compiled_block_1_1472 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1471, compiled_block_1_1471 );
  twobit_label( 1472, compiled_block_1_1472 );
  twobit_reg( 31 );
  twobit_op1_26(); /* inexact? */
  twobit_label( 1471, compiled_block_1_1471 );
  twobit_branchf( 1474, compiled_block_1_1474 );
  twobit_const( 1 );
  twobit_setreg( 3 );
  twobit_reg( 30 );
  twobit_op2_61( 3, 638, compiled_temp_1_638 ); /* + */
  twobit_skip( 1473, compiled_block_1_1473 );
  twobit_label( 1474, compiled_block_1_1474 );
  twobit_reg( 30 );
  twobit_label( 1473, compiled_block_1_1473 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_61( 3, 639, compiled_temp_1_639 ); /* + */
  twobit_setreg( 31 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 4, 1476, compiled_block_1_1476 ); /* internal:branchf-eq? */
  twobit_reg( 2 );
  twobit_op2_68( 5, 640, compiled_temp_1_640 ); /* = */
  twobit_skip( 1475, compiled_block_1_1475 );
  twobit_label( 1476, compiled_block_1_1476 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1475, compiled_block_1_1475 );
  twobit_branchf( 1478, compiled_block_1_1478 );
  twobit_reg( 3 );
  twobit_return();
  twobit_label( 1478, compiled_block_1_1478 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 5, 1 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 31, 5 );
  twobit_lambda( compiled_start_1_641, 4, 5 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_load( 1, 2 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_641( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_621( 4, 642, compiled_temp_1_642, 1480, compiled_block_1_1480 ); /* internal:branchf->= */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1479, compiled_block_1_1479 );
  twobit_label( 1480, compiled_block_1_1480 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1481, compiled_block_1_1481 );
  twobit_lexical( 0, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1481, compiled_block_1_1481 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1481, compiled_block_1_1481 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1481, compiled_block_1_1481 );
  twobit_lexical( 0, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 2, 3, 0, 1482, compiled_block_1_1482 );
  twobit_lexical( 0, 4 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 2, 3, 0, 1482, compiled_block_1_1482 );
  twobit_lexical( 0, 4 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 2, 3, 0, 1482, compiled_block_1_1482 );
  twobit_reg( 2 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 2, 3, 0, 1482, compiled_block_1_1482 );
  twobit_lexical( 0, 4 );
  twobit_op2_802( 2 ); /* ustring-ref:trusted */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* char-ci=? */
  twobit_setrtn( 1483, compiled_block_1_1483 );
  twobit_invoke( 2 );
  twobit_label( 1483, compiled_block_1_1483 );
  twobit_load( 0, 0 );
  twobit_branchf( 1485, compiled_block_1_1485 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1479, compiled_block_1_1479 );
  twobit_label( 1485, compiled_block_1_1485 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_label( 1479, compiled_block_1_1479 );
  twobit_branchf( 1487, compiled_block_1_1487 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_62( 4, 643, compiled_temp_1_643 ); /* - */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1487, compiled_block_1_1487 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 644, compiled_temp_1_644 ); /* + */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op2imm_130( fixnum(1), 645, compiled_temp_1_645 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1481, compiled_block_1_1481 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_label( 1482, compiled_block_1_1482 );
  twobit_trap( 3, 2, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_29( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 6 );
  twobit_reg( 6 );
  twobit_op2_62( 5, 621, compiled_temp_1_621 ); /* - */
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op2_62( 2, 622, compiled_temp_1_622 ); /* - */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op2_branchf_622( 31, 623, compiled_temp_1_623, 1491, compiled_block_1_1491 ); /* internal:branchf-<= */
  twobit_reg( 2 );
  twobit_skip( 1490, compiled_block_1_1490 );
  twobit_label( 1491, compiled_block_1_1491 );
  twobit_reg( 31 );
  twobit_label( 1490, compiled_block_1_1490 );
  twobit_setreg( 30 );
  twobit_reg( 2 );
  twobit_op1_26(); /* inexact? */
  twobit_branchf( 1493, compiled_block_1_1493 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1492, compiled_block_1_1492 );
  twobit_label( 1493, compiled_block_1_1493 );
  twobit_reg( 31 );
  twobit_op1_26(); /* inexact? */
  twobit_label( 1492, compiled_block_1_1492 );
  twobit_branchf( 1495, compiled_block_1_1495 );
  twobit_const( 1 );
  twobit_setreg( 2 );
  twobit_reg( 30 );
  twobit_op2_61( 2, 624, compiled_temp_1_624 ); /* + */
  twobit_skip( 1494, compiled_block_1_1494 );
  twobit_label( 1495, compiled_block_1_1495 );
  twobit_reg( 30 );
  twobit_label( 1494, compiled_block_1_1494 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2_62( 2, 625, compiled_temp_1_625 ); /* - */
  twobit_setreg( 31 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 4, 1497, compiled_block_1_1497 ); /* internal:branchf-eq? */
  twobit_reg( 3 );
  twobit_op2_68( 6, 626, compiled_temp_1_626 ); /* = */
  twobit_skip( 1496, compiled_block_1_1496 );
  twobit_label( 1497, compiled_block_1_1497 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1496, compiled_block_1_1496 );
  twobit_branchf( 1499, compiled_block_1_1499 );
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1499, compiled_block_1_1499 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_reg( 3 );
  twobit_op2imm_131( fixnum(1), 627, compiled_temp_1_627 ); /* - */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_reg( 6 );
  twobit_op2imm_131( fixnum(1), 628, compiled_temp_1_628 ); /* - */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 30 );
  twobit_movereg( 31, 5 );
  twobit_movereg( 30, 2 );
  twobit_lambda( compiled_start_1_629, 4, 5 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 30 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 30 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_629( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 630, compiled_temp_1_630, 1501, compiled_block_1_1501 ); /* internal:branchf-< */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1500, compiled_block_1_1500 );
  twobit_label( 1501, compiled_block_1_1501 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1502, compiled_block_1_1502 );
  twobit_lexical( 0, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1502, compiled_block_1_1502 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1502, compiled_block_1_1502 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1502, compiled_block_1_1502 );
  twobit_lexical( 0, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 2, 3, 0, 1503, compiled_block_1_1503 );
  twobit_lexical( 0, 4 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 2, 3, 0, 1503, compiled_block_1_1503 );
  twobit_lexical( 0, 4 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 2, 3, 0, 1503, compiled_block_1_1503 );
  twobit_reg( 2 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 2, 3, 0, 1503, compiled_block_1_1503 );
  twobit_lexical( 0, 4 );
  twobit_op2_802( 2 ); /* ustring-ref:trusted */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* char-ci=? */
  twobit_setrtn( 1504, compiled_block_1_1504 );
  twobit_invoke( 2 );
  twobit_label( 1504, compiled_block_1_1504 );
  twobit_load( 0, 0 );
  twobit_branchf( 1506, compiled_block_1_1506 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1500, compiled_block_1_1500 );
  twobit_label( 1506, compiled_block_1_1506 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_label( 1500, compiled_block_1_1500 );
  twobit_branchf( 1508, compiled_block_1_1508 );
  twobit_load( 4, 1 );
  twobit_lexical( 0, 3 );
  twobit_op2_62( 4, 631, compiled_temp_1_631 ); /* - */
  twobit_op2imm_131( fixnum(1), 632, compiled_temp_1_632 ); /* - */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1508, compiled_block_1_1508 );
  twobit_stack( 1 );
  twobit_op2imm_131( fixnum(1), 633, compiled_temp_1_633 ); /* - */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op2imm_131( fixnum(1), 634, compiled_temp_1_634 ); /* - */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1502, compiled_block_1_1502 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_label( 1503, compiled_block_1_1503 );
  twobit_trap( 3, 2, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_30( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  string-prefix-length~1ayXVW~7601 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_617, 3, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_618, 5, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_617( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_619, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_620, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_619( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_620( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 1, 4 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 3, 6 );
  twobit_movereg( 4, 5 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  %string-prefix-length~1ayXVW~7597 */
  twobit_invoke( 6 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_618( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_31( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  string-suffix-length~1ayXVW~7602 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_613, 3, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_614, 5, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_613( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_615, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_616, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_615( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_616( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 1, 4 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 3, 6 );
  twobit_movereg( 4, 5 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  %string-suffix-length~1ayXVW~7598 */
  twobit_invoke( 6 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_614( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_32( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  string-prefix-length-ci~1ayXVW~7603 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_609, 3, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_610, 5, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_609( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_611, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_612, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_611( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_612( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 1, 4 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 3, 6 );
  twobit_movereg( 4, 5 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  %string-prefix-length-ci~1ayXVW~7599 */
  twobit_invoke( 6 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_610( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_33( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  string-suffix-length-ci~1ayXVW~7604 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_605, 3, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_606, 5, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_605( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_607, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_608, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_607( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_608( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 1, 4 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 3, 6 );
  twobit_movereg( 4, 5 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  %string-suffix-length-ci~1ayXVW~7600 */
  twobit_invoke( 6 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_606( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_34( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  string-prefix?~1ayXVW~7605 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_601, 3, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_602, 5, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_601( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_603, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_604, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_603( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_604( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 1, 4 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 3, 6 );
  twobit_movereg( 4, 5 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  %string-prefix?~1ayXVW~7609 */
  twobit_invoke( 6 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_602( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_35( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  string-suffix?~1ayXVW~7606 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_597, 3, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_598, 5, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_597( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_599, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_600, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_599( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_600( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 1, 4 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 3, 6 );
  twobit_movereg( 4, 5 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  %string-suffix?~1ayXVW~7610 */
  twobit_invoke( 6 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_598( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_36( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  string-prefix-ci?~1ayXVW~7607 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_593, 3, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_594, 5, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_593( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_595, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_596, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_595( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_596( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 1, 4 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 3, 6 );
  twobit_movereg( 4, 5 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  %string-prefix-ci?~1ayXVW~7611 */
  twobit_invoke( 6 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_594( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_37( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  string-suffix-ci?~1ayXVW~7608 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_589, 3, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_590, 5, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_589( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_591, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_592, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_591( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_592( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 1, 4 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 3, 6 );
  twobit_movereg( 4, 5 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  %string-suffix-ci?~1ayXVW~7612 */
  twobit_invoke( 6 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_590( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_38( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 6 );
  twobit_reg( 3 );
  twobit_op2_62( 2, 585, compiled_temp_1_585 ); /* - */
  twobit_setreg( 31 );
  twobit_reg( 6 );
  twobit_op2_62( 5, 586, compiled_temp_1_586 ); /* - */
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_op2_branchf_622( 30, 587, compiled_temp_1_587, 1552, compiled_block_1_1552 ); /* internal:branchf-<= */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 31, 1 );
  twobit_global( 1 ); /*  %string-prefix-length~1ayXVW~7597 */
  twobit_setrtn( 1553, compiled_block_1_1553 );
  twobit_invoke( 6 );
  twobit_label( 1553, compiled_block_1_1553 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_68( 3, 588, compiled_temp_1_588 ); /* = */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1552, compiled_block_1_1552 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_39( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 6 );
  twobit_reg( 3 );
  twobit_op2_62( 2, 581, compiled_temp_1_581 ); /* - */
  twobit_setreg( 31 );
  twobit_reg( 6 );
  twobit_op2_62( 5, 582, compiled_temp_1_582 ); /* - */
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_op2_branchf_622( 30, 583, compiled_temp_1_583, 1555, compiled_block_1_1555 ); /* internal:branchf-<= */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 31, 1 );
  twobit_global( 1 ); /*  %string-suffix-length~1ayXVW~7598 */
  twobit_setrtn( 1556, compiled_block_1_1556 );
  twobit_invoke( 6 );
  twobit_label( 1556, compiled_block_1_1556 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_68( 4, 584, compiled_temp_1_584 ); /* = */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1555, compiled_block_1_1555 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_40( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 6 );
  twobit_reg( 3 );
  twobit_op2_62( 2, 577, compiled_temp_1_577 ); /* - */
  twobit_setreg( 31 );
  twobit_reg( 6 );
  twobit_op2_62( 5, 578, compiled_temp_1_578 ); /* - */
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_op2_branchf_622( 30, 579, compiled_temp_1_579, 1558, compiled_block_1_1558 ); /* internal:branchf-<= */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 31, 1 );
  twobit_global( 1 ); /*  %string-prefix-length-ci~1ayXVW~7599 */
  twobit_setrtn( 1559, compiled_block_1_1559 );
  twobit_invoke( 6 );
  twobit_label( 1559, compiled_block_1_1559 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_68( 4, 580, compiled_temp_1_580 ); /* = */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1558, compiled_block_1_1558 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_41( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 6 );
  twobit_reg( 3 );
  twobit_op2_62( 2, 573, compiled_temp_1_573 ); /* - */
  twobit_setreg( 31 );
  twobit_reg( 6 );
  twobit_op2_62( 5, 574, compiled_temp_1_574 ); /* - */
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_op2_branchf_622( 30, 575, compiled_temp_1_575, 1561, compiled_block_1_1561 ); /* internal:branchf-<= */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 31, 1 );
  twobit_global( 1 ); /*  %string-suffix-length-ci~1ayXVW~7600 */
  twobit_setrtn( 1562, compiled_block_1_1562 );
  twobit_invoke( 6 );
  twobit_label( 1562, compiled_block_1_1562 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_68( 4, 576, compiled_temp_1_576 ); /* = */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1561, compiled_block_1_1561 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_42( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 9 );
  twobit_save( 10 );
  twobit_store( 0, 0 );
  twobit_store( 1, 10 );
  twobit_store( 2, 6 );
  twobit_store( 3, 5 );
  twobit_store( 4, 9 );
  twobit_store( 5, 8 );
  twobit_store( 7, 4 );
  twobit_store( 8, 3 );
  twobit_store( 9, 7 );
  twobit_reg( 6 );
  twobit_op2_62( 5, 565, compiled_temp_1_565 ); /* - */
  twobit_setreg( 31 );
  twobit_store( 31, 2 );
  twobit_reg( 3 );
  twobit_op2_62( 2, 566, compiled_temp_1_566 ); /* - */
  twobit_setreg( 30 );
  twobit_store( 30, 1 );
  twobit_global( 1 ); /*  %string-prefix-length~1ayXVW~7597 */
  twobit_setrtn( 1563, compiled_block_1_1563 );
  twobit_invoke( 6 );
  twobit_label( 1563, compiled_block_1_1563 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_reg( 4 );
  twobit_op2_branchf_623( 3, 567, compiled_temp_1_567, 1565, compiled_block_1_1565 ); /* internal:branchf-= */
  twobit_load( 3, 2 );
  twobit_reg( 4 );
  twobit_op2_branchf_623( 3, 568, compiled_temp_1_568, 1567, compiled_block_1_1567 ); /* internal:branchf-= */
  twobit_stack( 3 );
  twobit_skip( 1566, compiled_block_1_1566 );
  twobit_label( 1567, compiled_block_1_1567 );
  twobit_stack( 4 );
  twobit_label( 1566, compiled_block_1_1566 );
  twobit_setreg( 4 );
  twobit_load( 1, 5 );
  twobit_reg( 4 );
  twobit_pop( 10 );
  twobit_invoke( 1 );
  twobit_label( 1565, compiled_block_1_1565 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_61( 3, 569, compiled_temp_1_569 ); /* + */
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_op2_branchf_623( 1, 570, compiled_temp_1_570, 1570, compiled_block_1_1570 ); /* internal:branchf-= */
  twobit_stack( 7 );
  twobit_skip( 1569, compiled_block_1_1569 );
  twobit_label( 1570, compiled_block_1_1570 );
  twobit_stack( 8 );
  twobit_op2_61( 4, 571, compiled_temp_1_571 ); /* + */
  twobit_setreg( 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 9 );
  twobit_check( 1, 3, 0, 1571, compiled_block_1_1571 );
  twobit_stack( 9 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 1, 3, 0, 1571, compiled_block_1_1571 );
  twobit_stack( 9 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 9 );
  twobit_check( 1, 3, 0, 1571, compiled_block_1_1571 );
  twobit_reg_op2imm_check_660(reg(1),fixnum(0),1571,compiled_block_1_1571); /* internal:check->=:fix:fix/imm with (1 3 0) */
  twobit_stack( 9 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 3 );
  twobit_stack( 6 );
  twobit_op2_61( 4, 572, compiled_temp_1_572 ); /* + */
  twobit_setreg( 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 4, 10 );
  twobit_check( 1, 4, 0, 1572, compiled_block_1_1572 );
  twobit_stack( 10 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 1, 4, 0, 1572, compiled_block_1_1572 );
  twobit_stack( 10 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_load( 4, 10 );
  twobit_check( 1, 4, 0, 1572, compiled_block_1_1572 );
  twobit_reg_op2imm_check_660(reg(1),fixnum(0),1572,compiled_block_1_1572); /* internal:check->=:fix:fix/imm with (1 4 0) */
  twobit_stack( 10 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_op2_branchf_629( 3, 1574, compiled_block_1_1574 ); /* internal:branchf-char<? */
  twobit_stack( 4 );
  twobit_skip( 1569, compiled_block_1_1569 );
  twobit_label( 1574, compiled_block_1_1574 );
  twobit_stack( 7 );
  twobit_label( 1569, compiled_block_1_1569 );
  twobit_setreg( 4 );
  twobit_movereg( 2, 1 );
  twobit_reg( 4 );
  twobit_pop( 10 );
  twobit_invoke( 1 );
  twobit_label( 1571, compiled_block_1_1571 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_label( 1572, compiled_block_1_1572 );
  twobit_trap( 4, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_43( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 9 );
  twobit_save( 10 );
  twobit_store( 0, 0 );
  twobit_store( 1, 8 );
  twobit_store( 2, 6 );
  twobit_store( 3, 5 );
  twobit_store( 4, 10 );
  twobit_store( 5, 9 );
  twobit_store( 7, 4 );
  twobit_store( 8, 3 );
  twobit_store( 9, 7 );
  twobit_reg( 6 );
  twobit_op2_62( 5, 558, compiled_temp_1_558 ); /* - */
  twobit_setreg( 31 );
  twobit_store( 31, 2 );
  twobit_reg( 3 );
  twobit_op2_62( 2, 559, compiled_temp_1_559 ); /* - */
  twobit_setreg( 30 );
  twobit_store( 30, 1 );
  twobit_global( 1 ); /*  %string-prefix-length-ci~1ayXVW~7599 */
  twobit_setrtn( 1576, compiled_block_1_1576 );
  twobit_invoke( 6 );
  twobit_label( 1576, compiled_block_1_1576 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_reg( 4 );
  twobit_op2_branchf_623( 3, 560, compiled_temp_1_560, 1578, compiled_block_1_1578 ); /* internal:branchf-= */
  twobit_load( 3, 2 );
  twobit_reg( 4 );
  twobit_op2_branchf_623( 3, 561, compiled_temp_1_561, 1580, compiled_block_1_1580 ); /* internal:branchf-= */
  twobit_stack( 3 );
  twobit_skip( 1579, compiled_block_1_1579 );
  twobit_label( 1580, compiled_block_1_1580 );
  twobit_stack( 4 );
  twobit_label( 1579, compiled_block_1_1579 );
  twobit_setreg( 4 );
  twobit_load( 1, 5 );
  twobit_reg( 4 );
  twobit_pop( 10 );
  twobit_invoke( 1 );
  twobit_label( 1578, compiled_block_1_1578 );
  twobit_stack( 6 );
  twobit_op2_61( 4, 562, compiled_temp_1_562 ); /* + */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_op2_branchf_623( 2, 563, compiled_temp_1_563, 1583, compiled_block_1_1583 ); /* internal:branchf-= */
  twobit_stack( 7 );
  twobit_skip( 1582, compiled_block_1_1582 );
  twobit_label( 1583, compiled_block_1_1583 );
  twobit_reg( 3 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 2, 8 );
  twobit_check( 3, 2, 0, 1584, compiled_block_1_1584 );
  twobit_stack( 8 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 3, 2, 0, 1584, compiled_block_1_1584 );
  twobit_stack( 8 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2_407( 2 ); /* <:fix:fix */
  twobit_load( 2, 8 );
  twobit_check( 3, 2, 0, 1584, compiled_block_1_1584 );
  twobit_reg_op2imm_check_660(reg(3),fixnum(0),1584,compiled_block_1_1584); /* internal:check->=:fix:fix/imm with (3 2 0) */
  twobit_stack( 8 );
  twobit_op2_802( 3 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_stack( 9 );
  twobit_op2_61( 4, 564, compiled_temp_1_564 ); /* + */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 4, 10 );
  twobit_check( 2, 4, 0, 1585, compiled_block_1_1585 );
  twobit_stack( 10 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 2, 4, 0, 1585, compiled_block_1_1585 );
  twobit_stack( 10 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_load( 4, 10 );
  twobit_check( 2, 4, 0, 1585, compiled_block_1_1585 );
  twobit_reg_op2imm_check_660(reg(2),fixnum(0),1585,compiled_block_1_1585); /* internal:check->=:fix:fix/imm with (2 4 0) */
  twobit_stack( 10 );
  twobit_op2_802( 2 ); /* ustring-ref:trusted */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* char-ci<? */
  twobit_setrtn( 1586, compiled_block_1_1586 );
  twobit_invoke( 2 );
  twobit_label( 1586, compiled_block_1_1586 );
  twobit_load( 0, 0 );
  twobit_branchf( 1588, compiled_block_1_1588 );
  twobit_stack( 4 );
  twobit_skip( 1582, compiled_block_1_1582 );
  twobit_label( 1588, compiled_block_1_1588 );
  twobit_stack( 7 );
  twobit_label( 1582, compiled_block_1_1582 );
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_pop( 10 );
  twobit_invoke( 1 );
  twobit_label( 1585, compiled_block_1_1585 );
  twobit_trap( 4, 2, 0, 60 );
  twobit_label( 1584, compiled_block_1_1584 );
  twobit_trap( 2, 3, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_44( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 5 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 6, 1 );
  twobit_global( 1 ); /*  string-compare~1ayXVW~7615 */
  twobit_setreg( 31 );
  twobit_movereg( 31, 6 );
  twobit_lambda( compiled_start_1_554, 3, 6 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 31, 2 );
  twobit_lambda( compiled_start_1_555, 5, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_554( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_556, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_557, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_556( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 6 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_557( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 1, 4 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 3, 6 );
  twobit_movereg( 4, 5 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 7 );
  twobit_lexical( 1, 4 );
  twobit_setreg( 8 );
  twobit_lexical( 1, 5 );
  twobit_setreg( 9 );
  twobit_global( 1 ); /*  %string-compare~1ayXVW~7613 */
  twobit_invoke( 9 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_555( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_45( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 5 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 6, 1 );
  twobit_global( 1 ); /*  string-compare-ci~1ayXVW~7616 */
  twobit_setreg( 31 );
  twobit_movereg( 31, 6 );
  twobit_lambda( compiled_start_1_550, 3, 6 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 31, 2 );
  twobit_lambda( compiled_start_1_551, 5, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_550( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_552, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_553, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_552( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 6 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_553( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 1, 4 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 3, 6 );
  twobit_movereg( 4, 5 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 7 );
  twobit_lexical( 1, 4 );
  twobit_setreg( 8 );
  twobit_lexical( 1, 5 );
  twobit_setreg( 9 );
  twobit_global( 1 ); /*  %string-compare-ci~1ayXVW~7614 */
  twobit_invoke( 9 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_551( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_46( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  string=~1ayXVW~7617 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_540, 3, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_541, 5, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_540( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_542, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_543, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_542( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_543( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op2_62( 1, 544, compiled_temp_1_544 ); /* - */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op2_62( 3, 545, compiled_temp_1_545 ); /* - */
  twobit_op2_branchf_623( 4, 546, compiled_temp_1_546, 1602, compiled_block_1_1602 ); /* internal:branchf-= */
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_op2_branchf_624( 3, 1604, compiled_block_1_1604 ); /* internal:branchf-eq? */
  twobit_lexical( 0, 2 );
  twobit_op2_68( 1, 547, compiled_temp_1_547 ); /* = */
  twobit_skip( 1603, compiled_block_1_1603 );
  twobit_label( 1604, compiled_block_1_1604 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1603, compiled_block_1_1603 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1606, compiled_block_1_1606 );
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1606, compiled_block_1_1606 );
  twobit_movereg( 2, 4 );
  twobit_movereg( 1, 3 );
  twobit_lambda( compiled_start_1_548, 2, 0 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* values */
  twobit_setreg( 1 );
  twobit_lambda( compiled_start_1_549, 5, 0 );
  twobit_setreg( 31 );
  twobit_movereg( 1, 8 );
  twobit_movereg( 2, 7 );
  twobit_movereg( 4, 6 );
  twobit_movereg( 3, 5 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_movereg( 31, 9 );
  twobit_global( 6 ); /*  %string-compare~1ayXVW~7613 */
  twobit_invoke( 9 );
  twobit_label( 1602, compiled_block_1_1602 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_548( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_549( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_541( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_47( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  string<>~1ayXVW~7618 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_531, 3, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_532, 5, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_531( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_533, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_534, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_533( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_534( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op2_62( 1, 535, compiled_temp_1_535 ); /* - */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op2_62( 3, 536, compiled_temp_1_536 ); /* - */
  twobit_op2_68( 4, 537, compiled_temp_1_537 ); /* = */
  twobit_op1_9(); /* not */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_branchf( 1613, compiled_block_1_1613 );
  twobit_reg( 3 );
  twobit_return();
  twobit_label( 1613, compiled_block_1_1613 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 31 );
  twobit_lexical( 1, 1 );
  twobit_op2_branchf_624( 31, 1615, compiled_block_1_1615 ); /* internal:branchf-eq? */
  twobit_lexical( 0, 2 );
  twobit_op2_68( 1, 538, compiled_temp_1_538 ); /* = */
  twobit_skip( 1614, compiled_block_1_1614 );
  twobit_label( 1615, compiled_block_1_1615 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1614, compiled_block_1_1614 );
  twobit_branchf( 1617, compiled_block_1_1617 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1617, compiled_block_1_1617 );
  twobit_movereg( 1, 4 );
  twobit_movereg( 2, 3 );
  twobit_global( 1 ); /* values */
  twobit_setreg( 2 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_539, 3, 0 );
  twobit_setreg( 31 );
  twobit_movereg( 1, 7 );
  twobit_movereg( 3, 6 );
  twobit_movereg( 4, 5 );
  twobit_movereg( 2, 9 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_movereg( 31, 8 );
  twobit_global( 4 ); /*  %string-compare~1ayXVW~7613 */
  twobit_invoke( 9 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_539( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_532( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_48( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  string<~1ayXVW~7619 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_523, 3, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_524, 5, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_523( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_525, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_526, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_525( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_526( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_op2_branchf_624( 4, 1624, compiled_block_1_1624 ); /* internal:branchf-eq? */
  twobit_lexical( 0, 2 );
  twobit_op2_68( 1, 527, compiled_temp_1_527 ); /* = */
  twobit_skip( 1623, compiled_block_1_1623 );
  twobit_label( 1624, compiled_block_1_1624 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1623, compiled_block_1_1623 );
  twobit_branchf( 1626, compiled_block_1_1626 );
  twobit_lexical( 0, 1 );
  twobit_op2_66( 2, 528, compiled_temp_1_528 ); /* < */
  twobit_return();
  twobit_label( 1626, compiled_block_1_1626 );
  twobit_movereg( 2, 4 );
  twobit_movereg( 1, 3 );
  twobit_global( 1 ); /* values */
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_529, 3, 0 );
  twobit_setreg( 1 );
  twobit_lambda( compiled_start_1_530, 5, 0 );
  twobit_setreg( 31 );
  twobit_movereg( 1, 8 );
  twobit_movereg( 2, 7 );
  twobit_movereg( 4, 6 );
  twobit_movereg( 3, 5 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_movereg( 31, 9 );
  twobit_global( 6 ); /*  %string-compare~1ayXVW~7613 */
  twobit_invoke( 9 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_529( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_530( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_524( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_49( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  string>~1ayXVW~7620 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_515, 3, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_516, 5, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_515( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_517, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_518, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_517( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_518( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_op2_branchf_624( 4, 1633, compiled_block_1_1633 ); /* internal:branchf-eq? */
  twobit_lexical( 0, 2 );
  twobit_op2_68( 1, 519, compiled_temp_1_519 ); /* = */
  twobit_skip( 1632, compiled_block_1_1632 );
  twobit_label( 1633, compiled_block_1_1633 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1632, compiled_block_1_1632 );
  twobit_branchf( 1635, compiled_block_1_1635 );
  twobit_lexical( 0, 1 );
  twobit_op2_69( 2, 520, compiled_temp_1_520 ); /* > */
  twobit_return();
  twobit_label( 1635, compiled_block_1_1635 );
  twobit_movereg( 2, 4 );
  twobit_movereg( 1, 3 );
  twobit_lambda( compiled_start_1_521, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_522, 4, 0 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /* values */
  twobit_setreg( 31 );
  twobit_movereg( 1, 8 );
  twobit_movereg( 2, 7 );
  twobit_movereg( 4, 6 );
  twobit_movereg( 3, 5 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_movereg( 31, 9 );
  twobit_global( 6 ); /*  %string-compare~1ayXVW~7613 */
  twobit_invoke( 9 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_521( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_522( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_516( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_50( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  string<=~1ayXVW~7621 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_508, 3, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_509, 5, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_508( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_510, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_511, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_510( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_511( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_op2_branchf_624( 4, 1642, compiled_block_1_1642 ); /* internal:branchf-eq? */
  twobit_lexical( 0, 2 );
  twobit_op2_68( 1, 512, compiled_temp_1_512 ); /* = */
  twobit_skip( 1641, compiled_block_1_1641 );
  twobit_label( 1642, compiled_block_1_1642 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1641, compiled_block_1_1641 );
  twobit_branchf( 1644, compiled_block_1_1644 );
  twobit_lexical( 0, 1 );
  twobit_op2_67( 2, 513, compiled_temp_1_513 ); /* <= */
  twobit_return();
  twobit_label( 1644, compiled_block_1_1644 );
  twobit_movereg( 1, 4 );
  twobit_movereg( 2, 3 );
  twobit_global( 1 ); /* values */
  twobit_setreg( 2 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_514, 3, 0 );
  twobit_setreg( 31 );
  twobit_movereg( 2, 8 );
  twobit_movereg( 1, 7 );
  twobit_movereg( 3, 6 );
  twobit_movereg( 4, 5 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_movereg( 31, 9 );
  twobit_global( 4 ); /*  %string-compare~1ayXVW~7613 */
  twobit_invoke( 9 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_514( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_509( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_51( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  string>=~1ayXVW~7622 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_501, 3, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_502, 5, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_501( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_503, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_504, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_503( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_504( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_op2_branchf_624( 4, 1651, compiled_block_1_1651 ); /* internal:branchf-eq? */
  twobit_lexical( 0, 2 );
  twobit_op2_68( 1, 505, compiled_temp_1_505 ); /* = */
  twobit_skip( 1650, compiled_block_1_1650 );
  twobit_label( 1651, compiled_block_1_1651 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1650, compiled_block_1_1650 );
  twobit_branchf( 1653, compiled_block_1_1653 );
  twobit_lexical( 0, 1 );
  twobit_op2_70( 2, 506, compiled_temp_1_506 ); /* >= */
  twobit_return();
  twobit_label( 1653, compiled_block_1_1653 );
  twobit_movereg( 1, 4 );
  twobit_movereg( 2, 3 );
  twobit_lambda( compiled_start_1_507, 2, 0 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* values */
  twobit_setreg( 1 );
  twobit_movereg( 1, 31 );
  twobit_movereg( 2, 7 );
  twobit_movereg( 3, 6 );
  twobit_movereg( 4, 5 );
  twobit_movereg( 1, 9 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_movereg( 31, 8 );
  twobit_global( 4 ); /*  %string-compare~1ayXVW~7613 */
  twobit_invoke( 9 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_507( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_502( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_52( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  string-ci=~1ayXVW~7623 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_491, 3, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_492, 5, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_491( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_493, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_494, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_493( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_494( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op2_62( 1, 495, compiled_temp_1_495 ); /* - */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op2_62( 3, 496, compiled_temp_1_496 ); /* - */
  twobit_op2_branchf_623( 4, 497, compiled_temp_1_497, 1660, compiled_block_1_1660 ); /* internal:branchf-= */
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_op2_branchf_624( 3, 1662, compiled_block_1_1662 ); /* internal:branchf-eq? */
  twobit_lexical( 0, 2 );
  twobit_op2_68( 1, 498, compiled_temp_1_498 ); /* = */
  twobit_skip( 1661, compiled_block_1_1661 );
  twobit_label( 1662, compiled_block_1_1662 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1661, compiled_block_1_1661 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1664, compiled_block_1_1664 );
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1664, compiled_block_1_1664 );
  twobit_movereg( 2, 4 );
  twobit_movereg( 1, 3 );
  twobit_lambda( compiled_start_1_499, 2, 0 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* values */
  twobit_setreg( 1 );
  twobit_lambda( compiled_start_1_500, 5, 0 );
  twobit_setreg( 31 );
  twobit_movereg( 1, 8 );
  twobit_movereg( 2, 7 );
  twobit_movereg( 4, 6 );
  twobit_movereg( 3, 5 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_movereg( 31, 9 );
  twobit_global( 6 ); /*  %string-compare-ci~1ayXVW~7614 */
  twobit_invoke( 9 );
  twobit_label( 1660, compiled_block_1_1660 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_499( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_500( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_492( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_53( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  string-ci<>~1ayXVW~7624 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_482, 3, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_483, 5, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_482( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_484, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_485, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_484( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_485( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op2_62( 1, 486, compiled_temp_1_486 ); /* - */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op2_62( 3, 487, compiled_temp_1_487 ); /* - */
  twobit_op2_68( 4, 488, compiled_temp_1_488 ); /* = */
  twobit_op1_9(); /* not */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_branchf( 1671, compiled_block_1_1671 );
  twobit_reg( 3 );
  twobit_return();
  twobit_label( 1671, compiled_block_1_1671 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 31 );
  twobit_lexical( 1, 1 );
  twobit_op2_branchf_624( 31, 1673, compiled_block_1_1673 ); /* internal:branchf-eq? */
  twobit_lexical( 0, 2 );
  twobit_op2_68( 1, 489, compiled_temp_1_489 ); /* = */
  twobit_skip( 1672, compiled_block_1_1672 );
  twobit_label( 1673, compiled_block_1_1673 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1672, compiled_block_1_1672 );
  twobit_branchf( 1675, compiled_block_1_1675 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1675, compiled_block_1_1675 );
  twobit_movereg( 1, 4 );
  twobit_movereg( 2, 3 );
  twobit_global( 1 ); /* values */
  twobit_setreg( 2 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_490, 3, 0 );
  twobit_setreg( 31 );
  twobit_movereg( 1, 7 );
  twobit_movereg( 3, 6 );
  twobit_movereg( 4, 5 );
  twobit_movereg( 2, 9 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_movereg( 31, 8 );
  twobit_global( 4 ); /*  %string-compare-ci~1ayXVW~7614 */
  twobit_invoke( 9 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_490( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_483( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_54( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  string-ci<~1ayXVW~7625 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_474, 3, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_475, 5, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_474( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_476, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_477, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_476( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_477( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_op2_branchf_624( 4, 1682, compiled_block_1_1682 ); /* internal:branchf-eq? */
  twobit_lexical( 0, 2 );
  twobit_op2_68( 1, 478, compiled_temp_1_478 ); /* = */
  twobit_skip( 1681, compiled_block_1_1681 );
  twobit_label( 1682, compiled_block_1_1682 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1681, compiled_block_1_1681 );
  twobit_branchf( 1684, compiled_block_1_1684 );
  twobit_lexical( 0, 1 );
  twobit_op2_66( 2, 479, compiled_temp_1_479 ); /* < */
  twobit_return();
  twobit_label( 1684, compiled_block_1_1684 );
  twobit_movereg( 2, 4 );
  twobit_movereg( 1, 3 );
  twobit_global( 1 ); /* values */
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_480, 3, 0 );
  twobit_setreg( 1 );
  twobit_lambda( compiled_start_1_481, 5, 0 );
  twobit_setreg( 31 );
  twobit_movereg( 1, 8 );
  twobit_movereg( 2, 7 );
  twobit_movereg( 4, 6 );
  twobit_movereg( 3, 5 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_movereg( 31, 9 );
  twobit_global( 6 ); /*  %string-compare-ci~1ayXVW~7614 */
  twobit_invoke( 9 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_480( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_481( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_475( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_55( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  string-ci>~1ayXVW~7626 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_466, 3, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_467, 5, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_466( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_468, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_469, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_468( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_469( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_op2_branchf_624( 4, 1691, compiled_block_1_1691 ); /* internal:branchf-eq? */
  twobit_lexical( 0, 2 );
  twobit_op2_68( 1, 470, compiled_temp_1_470 ); /* = */
  twobit_skip( 1690, compiled_block_1_1690 );
  twobit_label( 1691, compiled_block_1_1691 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1690, compiled_block_1_1690 );
  twobit_branchf( 1693, compiled_block_1_1693 );
  twobit_lexical( 0, 1 );
  twobit_op2_69( 2, 471, compiled_temp_1_471 ); /* > */
  twobit_return();
  twobit_label( 1693, compiled_block_1_1693 );
  twobit_movereg( 2, 4 );
  twobit_movereg( 1, 3 );
  twobit_lambda( compiled_start_1_472, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_473, 4, 0 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /* values */
  twobit_setreg( 31 );
  twobit_movereg( 1, 8 );
  twobit_movereg( 2, 7 );
  twobit_movereg( 4, 6 );
  twobit_movereg( 3, 5 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_movereg( 31, 9 );
  twobit_global( 6 ); /*  %string-compare-ci~1ayXVW~7614 */
  twobit_invoke( 9 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_472( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_473( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_467( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_56( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  string-ci<=~1ayXVW~7627 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_459, 3, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_460, 5, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_459( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_461, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_462, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_461( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_462( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_op2_branchf_624( 4, 1700, compiled_block_1_1700 ); /* internal:branchf-eq? */
  twobit_lexical( 0, 2 );
  twobit_op2_68( 1, 463, compiled_temp_1_463 ); /* = */
  twobit_skip( 1699, compiled_block_1_1699 );
  twobit_label( 1700, compiled_block_1_1700 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1699, compiled_block_1_1699 );
  twobit_branchf( 1702, compiled_block_1_1702 );
  twobit_lexical( 0, 1 );
  twobit_op2_67( 2, 464, compiled_temp_1_464 ); /* <= */
  twobit_return();
  twobit_label( 1702, compiled_block_1_1702 );
  twobit_movereg( 1, 4 );
  twobit_movereg( 2, 3 );
  twobit_global( 1 ); /* values */
  twobit_setreg( 2 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_465, 3, 0 );
  twobit_setreg( 31 );
  twobit_movereg( 2, 8 );
  twobit_movereg( 1, 7 );
  twobit_movereg( 3, 6 );
  twobit_movereg( 4, 5 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_movereg( 31, 9 );
  twobit_global( 4 ); /*  %string-compare-ci~1ayXVW~7614 */
  twobit_invoke( 9 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_465( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_460( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_57( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  string-ci>=~1ayXVW~7628 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_452, 3, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_453, 5, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_452( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_454, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_455, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_454( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_455( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_op2_branchf_624( 4, 1709, compiled_block_1_1709 ); /* internal:branchf-eq? */
  twobit_lexical( 0, 2 );
  twobit_op2_68( 1, 456, compiled_temp_1_456 ); /* = */
  twobit_skip( 1708, compiled_block_1_1708 );
  twobit_label( 1709, compiled_block_1_1709 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1708, compiled_block_1_1708 );
  twobit_branchf( 1711, compiled_block_1_1711 );
  twobit_lexical( 0, 1 );
  twobit_op2_70( 2, 457, compiled_temp_1_457 ); /* >= */
  twobit_return();
  twobit_label( 1711, compiled_block_1_1711 );
  twobit_movereg( 1, 4 );
  twobit_movereg( 2, 3 );
  twobit_lambda( compiled_start_1_458, 2, 0 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* values */
  twobit_setreg( 1 );
  twobit_movereg( 1, 31 );
  twobit_movereg( 2, 7 );
  twobit_movereg( 3, 6 );
  twobit_movereg( 4, 5 );
  twobit_movereg( 1, 9 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_movereg( 31, 8 );
  twobit_global( 4 ); /*  %string-compare-ci~1ayXVW~7614 */
  twobit_invoke( 9 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_458( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_453( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_58( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 3 );
  twobit_store( 3, 2 );
  twobit_store( 4, 5 );
  twobit_store( 5, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 31 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 31, 1 );
  twobit_lambda( compiled_start_1_443, 3, 2 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_op2_84( 30 ); /* cell-set! */
  twobit_reg( 31 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_movereg( 1, 2 );
  twobit_imm_const( fixnum(65536) ); /* 65536 */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_setrtn( 1721, compiled_block_1_1721 );
  twobit_invoke( 1 );
  twobit_label( 1721, compiled_block_1_1721 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 6, 1 );
  twobit_load( 5, 2 );
  twobit_load( 2, 3 );
  twobit_load( 1, 4 );
  twobit_lambda( compiled_start_1_444, 5, 6 );
  twobit_setreg( 4 );
  twobit_load( 1, 5 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 5 );
  twobit_invoke( 2 );
  twobit_label( 1716, compiled_block_1_1716 );
  twobit_movereg( 1, 4 );
  twobit_reg_op1_check_651(reg(3),1729,compiled_block_1_1729); /* internal:check-fixnum? with (3 2 0) */
  twobit_reg( 2 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 3, 2, 0, 1729, compiled_block_1_1729 );
  twobit_reg( 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 1 );
  twobit_reg_op2_check_661(reg(3),reg(1),1729,compiled_block_1_1729); /* internal:check-range with (3 2 0) */
  twobit_reg( 2 );
  twobit_op2_802( 3 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 1729, compiled_block_1_1729 );
  twobit_trap( 2, 3, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_443( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_621( 4, 449, compiled_temp_1_449, 1719, compiled_block_1_1719 ); /* internal:branchf->= */
  twobit_reg( 1 );
  twobit_op2imm_131( fixnum(1), 450, compiled_temp_1_450 ); /* - */
  twobit_return();
  twobit_label( 1719, compiled_block_1_1719 );
  twobit_reg( 1 );
  twobit_op2_61( 1, 451, compiled_temp_1_451 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_444( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 6 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_621( 4, 445, compiled_temp_1_445, 1723, compiled_block_1_1723 ); /* internal:branchf->= */
  twobit_movereg( 2, 1 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /* modulo */
  twobit_invoke( 2 );
  twobit_label( 1723, compiled_block_1_1723 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 3 );
  twobit_reg( 1 );
  twobit_op2imm_130( fixnum(1), 446, compiled_temp_1_446 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( fixnum(37) ); /* 37 */
  twobit_op2_63( 2, 447, compiled_temp_1_447 ); /* * */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_setrtn( 1725, compiled_block_1_1725 );
  twobit_jump( 1, 1716, compiled_block_1_1716 );
  twobit_label( 1725, compiled_block_1_1725 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_61( 4, 448, compiled_temp_1_448 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* bitwise-and */
  twobit_setrtn( 1726, compiled_block_1_1726 );
  twobit_invoke( 2 );
  twobit_label( 1726, compiled_block_1_1726 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_59( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_lambda( compiled_start_1_437, 2, 1 );
  twobit_setreg( 4 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_438, 4, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_437( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op1_branchf_612( 440, compiled_temp_1_440, 1732, compiled_block_1_1732 ); /* internal:branchf-zero? */
  twobit_imm_const( fixnum(4194304) ); /* 4194304 */
  twobit_skip( 1731, compiled_block_1_1731 );
  twobit_label( 1732, compiled_block_1_1732 );
  twobit_reg( 1 );
  twobit_label( 1731, compiled_block_1_1731 );
  twobit_setreg( 4 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_441, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_442, 4, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_441( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-hash~1ayXVW~7630 */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_442( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_movereg( 2, 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 1, 4 );
  twobit_global( 1 ); /* char->integer */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_load( 5, 1 );
  twobit_global( 2 ); /*  %string-hash~1ayXVW~7629 */
  twobit_pop( 1 );
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_438( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_610( 1737, compiled_block_1_1737 ); /* internal:branchf-null? */
  twobit_imm_const( fixnum(4194304) ); /* 4194304 */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1737, compiled_block_1_1737 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 1739, compiled_block_1_1739 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1741, compiled_block_1_1741 );
  twobit_reg( 4 );
  twobit_op1_25(); /* exact? */
  twobit_branchf( 1743, compiled_block_1_1743 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_67( 4, 439, compiled_temp_1_439 ); /* <= */
  twobit_skip( 1740, compiled_block_1_1740 );
  twobit_label( 1743, compiled_block_1_1743 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1740, compiled_block_1_1740 );
  twobit_label( 1741, compiled_block_1_1741 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1740, compiled_block_1_1740 );
  twobit_branchf( 1745, compiled_block_1_1745 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1745, compiled_block_1_1745 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 3 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1739, compiled_block_1_1739 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_60( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_lambda( compiled_start_1_430, 2, 1 );
  twobit_setreg( 4 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_431, 4, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_430( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op1_branchf_612( 433, compiled_temp_1_433, 1750, compiled_block_1_1750 ); /* internal:branchf-zero? */
  twobit_imm_const( fixnum(4194304) ); /* 4194304 */
  twobit_skip( 1749, compiled_block_1_1749 );
  twobit_label( 1750, compiled_block_1_1750 );
  twobit_reg( 1 );
  twobit_label( 1749, compiled_block_1_1749 );
  twobit_setreg( 4 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_434, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_435, 4, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_434( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-hash-ci~1ayXVW~7631 */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_435( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_movereg( 2, 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 1, 4 );
  twobit_lambda( compiled_start_1_436, 2, 0 );
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_load( 5, 1 );
  twobit_global( 3 ); /*  %string-hash~1ayXVW~7629 */
  twobit_pop( 1 );
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_436( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* char-downcase */
  twobit_setrtn( 1752, compiled_block_1_1752 );
  twobit_invoke( 1 );
  twobit_label( 1752, compiled_block_1_1752 );
  twobit_load( 0, 0 );
  twobit_op1_37(); /* char->integer */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_431( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_610( 1756, compiled_block_1_1756 ); /* internal:branchf-null? */
  twobit_imm_const( fixnum(4194304) ); /* 4194304 */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1756, compiled_block_1_1756 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 1758, compiled_block_1_1758 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1760, compiled_block_1_1760 );
  twobit_reg( 4 );
  twobit_op1_25(); /* exact? */
  twobit_branchf( 1762, compiled_block_1_1762 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_67( 4, 432, compiled_temp_1_432 ); /* <= */
  twobit_skip( 1759, compiled_block_1_1759 );
  twobit_label( 1762, compiled_block_1_1762 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1759, compiled_block_1_1759 );
  twobit_label( 1760, compiled_block_1_1760 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1759, compiled_block_1_1759 );
  twobit_branchf( 1764, compiled_block_1_1764 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1764, compiled_block_1_1764 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 3 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1758, compiled_block_1_1758 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_61( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_lambda( compiled_start_1_428, 2, 2 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_429, 4, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_428( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-upcase~1ayXVW~7632 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_429( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 2, 4 );
  twobit_movereg( 1, 3 );
  twobit_global( 1 ); /* char-upcase */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %string-map~1ayXVW~7585 */
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_62( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_lambda( compiled_start_1_426, 2, 2 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_427, 4, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_426( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-upcase!~1ayXVW~7633 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_427( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 2, 4 );
  twobit_movereg( 1, 3 );
  twobit_global( 1 ); /* char-upcase */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %string-map!~1ayXVW~7587 */
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_63( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_lambda( compiled_start_1_424, 2, 2 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_425, 4, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_424( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-downcase~1ayXVW~7634 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_425( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 2, 4 );
  twobit_movereg( 1, 3 );
  twobit_global( 1 ); /* char-downcase */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %string-map~1ayXVW~7585 */
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_64( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_lambda( compiled_start_1_422, 2, 2 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_423, 4, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_422( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-downcase!~1ayXVW~7635 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_423( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 2, 4 );
  twobit_movereg( 1, 3 );
  twobit_global( 1 ); /* char-downcase */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %string-map!~1ayXVW~7587 */
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_65( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_420, 3, 3 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_420( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 3 );
  twobit_global( 1 ); /*  char-cased?~1ayXVW~7480 */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 4 );
  twobit_global( 2 ); /*  string-index~1ayXVW~7650 */
  twobit_setrtn( 1780, compiled_block_1_1780 );
  twobit_invoke( 4 );
  twobit_label( 1780, compiled_block_1_1780 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_branchf( 1782, compiled_block_1_1782 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 2, 0, 1783, compiled_block_1_1783 );
  twobit_lexical( 0, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 2, 0, 1783, compiled_block_1_1783 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 2, 0, 1783, compiled_block_1_1783 );
  twobit_reg( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 2, 0, 1783, compiled_block_1_1783 );
  twobit_lexical( 0, 1 );
  twobit_op2_802( 4 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_global( 3 ); /* char-titlecase */
  twobit_setrtn( 1784, compiled_block_1_1784 );
  twobit_invoke( 1 );
  twobit_label( 1784, compiled_block_1_1784 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_36(); /* char? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 2, 1785, compiled_block_1_1785 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 1 );
  twobit_op3_803( 3, 4 ); /* ustring-set!:trusted */
  twobit_reg( 3 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 3 );
  twobit_global( 1 ); /*  char-cased?~1ayXVW~7480 */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 4 );
  twobit_global( 4 ); /*  string-skip~1ayXVW~7652 */
  twobit_setrtn( 1786, compiled_block_1_1786 );
  twobit_invoke( 4 );
  twobit_label( 1786, compiled_block_1_1786 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_branchf( 1788, compiled_block_1_1788 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 3 );
  twobit_global( 5 ); /*  string-downcase!~1ayXVW~7635 */
  twobit_setrtn( 1789, compiled_block_1_1789 );
  twobit_invoke( 3 );
  twobit_label( 1789, compiled_block_1_1789 );
  twobit_load( 0, 0 );
  twobit_stack( 2 );
  twobit_op2imm_130( fixnum(1), 421, compiled_temp_1_421 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1788, compiled_block_1_1788 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 5 ); /*  string-downcase!~1ayXVW~7635 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1782, compiled_block_1_1782 );
  twobit_op1_3(); /* unspecified */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1783, compiled_block_1_1783 );
  twobit_trap( 2, 4, 0, 60 );
  twobit_label( 1785, compiled_block_1_1785 );
  twobit_trap( 2, 1, 4, 61 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_66( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_lambda( compiled_start_1_418, 2, 2 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_419, 4, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_418( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-titlecase!~1ayXVW~7637 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_419( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %string-titlecase!~1ayXVW~7636 */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_67( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_lambda( compiled_start_1_415, 2, 2 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_416, 4, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_415( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-titlecase!~1ayXVW~7637 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_416( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* substring */
  twobit_setrtn( 1797, compiled_block_1_1797 );
  twobit_invoke( 3 );
  twobit_label( 1797, compiled_block_1_1797 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 3, 2 );
  twobit_stack( 1 );
  twobit_op2_62( 3, 417, compiled_temp_1_417 ); /* - */
  twobit_setreg( 3 );
  twobit_movereg( 4, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %string-titlecase!~1ayXVW~7636 */
  twobit_setrtn( 1798, compiled_block_1_1798 );
  twobit_invoke( 3 );
  twobit_label( 1798, compiled_block_1_1798 );
  twobit_load( 0, 0 );
  twobit_stack( 3 );
  twobit_pop( 3 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_68( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 2, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  %substring/shared~1ayXVW~7582 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_69( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 1, 0, 0, 1801, compiled_block_1_1801 );
  twobit_reg( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2_62( 2, 414, compiled_temp_1_414 ); /* - */
  twobit_setreg( 2 );
  twobit_movereg( 4, 3 );
  twobit_global( 1 ); /*  %substring/shared~1ayXVW~7582 */
  twobit_invoke( 3 );
  twobit_label( 1801, compiled_block_1_1801 );
  twobit_trap( 1, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_70( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 1, 0, 0, 1803, compiled_block_1_1803 );
  twobit_reg( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  %substring/shared~1ayXVW~7582 */
  twobit_invoke( 3 );
  twobit_label( 1803, compiled_block_1_1803 );
  twobit_trap( 1, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_71( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 1, 0, 0, 1805, compiled_block_1_1805 );
  twobit_reg( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_op2_62( 2, 413, compiled_temp_1_413 ); /* - */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  %substring/shared~1ayXVW~7582 */
  twobit_invoke( 3 );
  twobit_label( 1805, compiled_block_1_1805 );
  twobit_trap( 1, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_72( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_lambda( compiled_start_1_409, 2, 1 );
  twobit_setreg( 4 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_410, 4, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_409( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lambda( compiled_start_1_411, 2, 1 );
  twobit_setreg( 4 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_412, 4, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_411( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 3 );
  twobit_movereg( 2, 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  string-skip~1ayXVW~7652 */
  twobit_setrtn( 1807, compiled_block_1_1807 );
  twobit_invoke( 4 );
  twobit_label( 1807, compiled_block_1_1807 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1809, compiled_block_1_1809 );
  twobit_load( 3, 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 2 ); /*  %substring/shared~1ayXVW~7582 */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_label( 1809, compiled_block_1_1809 );
  twobit_const( 3 );
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_412( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-trim~1ayXVW~7643 */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_410( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_610( 1814, compiled_block_1_1814 ); /* internal:branchf-null? */
  twobit_global( 1 ); /*  char-set:whitespace~1ayXVW~6600 */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1814, compiled_block_1_1814 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 1816, compiled_block_1_1816 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1816, compiled_block_1_1816 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_73( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_lambda( compiled_start_1_404, 2, 1 );
  twobit_setreg( 4 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_405, 4, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_404( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lambda( compiled_start_1_406, 2, 1 );
  twobit_setreg( 4 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_407, 4, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_406( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 3 );
  twobit_movereg( 2, 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  string-skip-right~1ayXVW~7653 */
  twobit_setrtn( 1819, compiled_block_1_1819 );
  twobit_invoke( 4 );
  twobit_label( 1819, compiled_block_1_1819 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1821, compiled_block_1_1821 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 4, 408, compiled_temp_1_408 ); /* + */
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %substring/shared~1ayXVW~7582 */
  twobit_pop( 0 );
  twobit_invoke( 3 );
  twobit_label( 1821, compiled_block_1_1821 );
  twobit_const( 3 );
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_407( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-trim-right~1ayXVW~7644 */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_405( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_610( 1826, compiled_block_1_1826 ); /* internal:branchf-null? */
  twobit_global( 1 ); /*  char-set:whitespace~1ayXVW~6600 */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1826, compiled_block_1_1826 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 1828, compiled_block_1_1828 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1828, compiled_block_1_1828 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_74( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_lambda( compiled_start_1_399, 2, 1 );
  twobit_setreg( 4 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_400, 4, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_399( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lambda( compiled_start_1_401, 2, 1 );
  twobit_setreg( 4 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_402, 4, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_401( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 3 );
  twobit_movereg( 2, 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  string-skip~1ayXVW~7652 */
  twobit_setrtn( 1831, compiled_block_1_1831 );
  twobit_invoke( 4 );
  twobit_label( 1831, compiled_block_1_1831 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_branchf( 1833, compiled_block_1_1833 );
  twobit_load( 4, 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_load( 3, 2 );
  twobit_global( 2 ); /*  string-skip-right~1ayXVW~7653 */
  twobit_setrtn( 1834, compiled_block_1_1834 );
  twobit_invoke( 4 );
  twobit_label( 1834, compiled_block_1_1834 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 4, 403, compiled_temp_1_403 ); /* + */
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 3 ); /*  %substring/shared~1ayXVW~7582 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1833, compiled_block_1_1833 );
  twobit_const( 4 );
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_402( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-trim-both~1ayXVW~7645 */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_400( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_610( 1839, compiled_block_1_1839 ); /* internal:branchf-null? */
  twobit_global( 1 ); /*  char-set:whitespace~1ayXVW~6600 */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1839, compiled_block_1_1839 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 1841, compiled_block_1_1841 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1841, compiled_block_1_1841 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_75( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_lambda( compiled_start_1_392, 2, 2 );
  twobit_setreg( 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_393, 4, 1 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_392( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lambda( compiled_start_1_394, 2, 1 );
  twobit_setreg( 4 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_395, 4, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_394( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op2_62( 1, 396, compiled_temp_1_396 ); /* - */
  twobit_setreg( 4 );
  twobit_lexical( 1, 2 );
  twobit_op2_branchf_622( 4, 397, compiled_temp_1_397, 1845, compiled_block_1_1845 ); /* internal:branchf-<= */
  twobit_movereg( 1, 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_61( 4, 398, compiled_temp_1_398 ); /* + */
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %substring/shared~1ayXVW~7582 */
  twobit_invoke( 3 );
  twobit_label( 1845, compiled_block_1_1845 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_movereg( 2, 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 1, 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_op2_799( 3 ); /* make-ustring */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_movereg( 3, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_load( 5, 1 );
  twobit_global( 2 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_setrtn( 1847, compiled_block_1_1847 );
  twobit_invoke( 5 );
  twobit_label( 1847, compiled_block_1_1847 );
  twobit_load( 0, 0 );
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_395( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-pad-right~1ayXVW~7646 */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_393( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_610( 1851, compiled_block_1_1851 ); /* internal:branchf-null? */
  twobit_imm_const( int_to_char(32) ); /* #\space */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1851, compiled_block_1_1851 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 1853, compiled_block_1_1853 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_615( 1855, compiled_block_1_1855 ); /* internal:branchf-char? */
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1855, compiled_block_1_1855 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 3 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1853, compiled_block_1_1853 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_76( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_lambda( compiled_start_1_384, 2, 2 );
  twobit_setreg( 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_385, 4, 1 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_384( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lambda( compiled_start_1_386, 2, 1 );
  twobit_setreg( 4 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_387, 4, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_386( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op2_62( 1, 388, compiled_temp_1_388 ); /* - */
  twobit_setreg( 4 );
  twobit_lexical( 1, 2 );
  twobit_op2_branchf_622( 4, 389, compiled_temp_1_389, 1860, compiled_block_1_1860 ); /* internal:branchf-<= */
  twobit_movereg( 2, 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_62( 4, 390, compiled_temp_1_390 ); /* - */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %substring/shared~1ayXVW~7582 */
  twobit_invoke( 3 );
  twobit_label( 1860, compiled_block_1_1860 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 4, 1 );
  twobit_movereg( 1, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 2, 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_op2_799( 2 ); /* make-ustring */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_movereg( 2, 1 );
  twobit_load( 4, 1 );
  twobit_lexical( 1, 2 );
  twobit_op2_62( 4, 391, compiled_temp_1_391 ); /* - */
  twobit_setreg( 2 );
  twobit_movereg( 3, 5 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_load( 4, 2 );
  twobit_global( 2 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_setrtn( 1862, compiled_block_1_1862 );
  twobit_invoke( 5 );
  twobit_label( 1862, compiled_block_1_1862 );
  twobit_load( 0, 0 );
  twobit_stack( 3 );
  twobit_pop( 3 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_387( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-pad~1ayXVW~7647 */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_385( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_610( 1866, compiled_block_1_1866 ); /* internal:branchf-null? */
  twobit_imm_const( int_to_char(32) ); /* #\space */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1866, compiled_block_1_1866 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 1868, compiled_block_1_1868 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_615( 1870, compiled_block_1_1870 ); /* internal:branchf-char? */
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1870, compiled_block_1_1870 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 3 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1868, compiled_block_1_1868 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_77( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_376, 2, 2 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_1_377, 4, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_376( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1875, compiled_block_1_1875 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_movereg( 2, 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 1, 4 );
  twobit_reg( 2 );
  twobit_op2_62( 1, 378, compiled_temp_1_378 ); /* - */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_imm_const( int_to_char(32) ); /* #\space */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2_799( 2 ); /* make-ustring */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_379, 2, 1 );
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_load( 5, 1 );
  twobit_global( 3 ); /*  string-fold~1ayXVW~7588 */
  twobit_setrtn( 1880, compiled_block_1_1880 );
  twobit_invoke( 5 );
  twobit_label( 1880, compiled_block_1_1880 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_reg( 4 );
  twobit_op2_branchf_623( 3, 380, compiled_temp_1_380, 1882, compiled_block_1_1882 ); /* internal:branchf-= */
  twobit_stack( 3 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1882, compiled_block_1_1882 );
  twobit_load( 1, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_movereg( 4, 3 );
  twobit_global( 4 ); /* substring */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1875, compiled_block_1_1875 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  char-set?~1ayXVW~6491 */
  twobit_setrtn( 1884, compiled_block_1_1884 );
  twobit_invoke( 1 );
  twobit_label( 1884, compiled_block_1_1884 );
  twobit_load( 0, 0 );
  twobit_branchf( 1886, compiled_block_1_1886 );
  twobit_lexical( 0, 2 );
  twobit_skip( 1885, compiled_block_1_1885 );
  twobit_label( 1886, compiled_block_1_1886 );
  twobit_lexical( 0, 2 );
  twobit_op1_branchf_615( 1888, compiled_block_1_1888 ); /* internal:branchf-char? */
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  char-set~1ayXVW~6558 */
  twobit_setrtn( 1889, compiled_block_1_1889 );
  twobit_invoke( 1 );
  twobit_label( 1889, compiled_block_1_1889 );
  twobit_load( 0, 0 );
  twobit_skip( 1885, compiled_block_1_1885 );
  twobit_label( 1888, compiled_block_1_1888 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_global( 8 ); /*  error~1ayXVW~7479 */
  twobit_setrtn( 1890, compiled_block_1_1890 );
  twobit_invoke( 2 );
  twobit_label( 1890, compiled_block_1_1890 );
  twobit_load( 0, 0 );
  twobit_label( 1885, compiled_block_1_1885 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_381, 10, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 3, 5 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  string-fold~1ayXVW~7588 */
  twobit_setrtn( 1894, compiled_block_1_1894 );
  twobit_invoke( 5 );
  twobit_label( 1894, compiled_block_1_1894 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_stack( 2 );
  twobit_setreg( 3 );
  twobit_load( 4, 1 );
  twobit_imm_const( int_to_char(32) ); /* #\space */
  twobit_setreg( 2 );
  twobit_stack( 4 );
  twobit_op2_799( 2 ); /* make-ustring */
  twobit_setreg( 2 );
  twobit_store( 2, 4 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_382, 12, 2 );
  twobit_setreg( 1 );
  twobit_movereg( 3, 5 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  string-fold~1ayXVW~7588 */
  twobit_setrtn( 1899, compiled_block_1_1899 );
  twobit_invoke( 5 );
  twobit_label( 1899, compiled_block_1_1899 );
  twobit_load( 0, 0 );
  twobit_stack( 4 );
  twobit_pop( 4 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_379( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_lexical( 1, 2 );
  twobit_setrtn( 1876, compiled_block_1_1876 );
  twobit_invoke( 1 );
  twobit_label( 1876, compiled_block_1_1876 );
  twobit_load( 0, 0 );
  twobit_branchf( 1878, compiled_block_1_1878 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1878, compiled_block_1_1878 );
  twobit_stack( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_load( 3, 1 );
  twobit_load( 4, 2 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 2, 1879, compiled_block_1_1879 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_load( 4, 2 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 2, 1879, compiled_block_1_1879 );
  twobit_stack( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 2, 1879, compiled_block_1_1879 );
  twobit_stack( 2 );
  twobit_op1_36(); /* char? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 2, 1879, compiled_block_1_1879 );
  twobit_load( 4, 1 );
  twobit_load( 3, 2 );
  twobit_lexical( 0, 1 );
  twobit_op3_803( 4, 3 ); /* ustring-set!:trusted */
  twobit_reg( 4 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1879, compiled_block_1_1879 );
  twobit_trap( 2, 3, 4, 61 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_381( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  char-set-contains?~1ayXVW~6535 */
  twobit_setrtn( 1891, compiled_block_1_1891 );
  twobit_invoke( 2 );
  twobit_label( 1891, compiled_block_1_1891 );
  twobit_load( 0, 0 );
  twobit_branchf( 1893, compiled_block_1_1893 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1893, compiled_block_1_1893 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 383, compiled_temp_1_383 ); /* + */
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_382( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  char-set-contains?~1ayXVW~6535 */
  twobit_setrtn( 1895, compiled_block_1_1895 );
  twobit_invoke( 2 );
  twobit_label( 1895, compiled_block_1_1895 );
  twobit_load( 0, 0 );
  twobit_branchf( 1897, compiled_block_1_1897 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1897, compiled_block_1_1897 );
  twobit_stack( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_load( 3, 1 );
  twobit_load( 4, 2 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 2, 1898, compiled_block_1_1898 );
  twobit_lexical( 0, 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_load( 4, 2 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 2, 1898, compiled_block_1_1898 );
  twobit_stack( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 2, 1898, compiled_block_1_1898 );
  twobit_stack( 2 );
  twobit_op1_36(); /* char? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 2, 1898, compiled_block_1_1898 );
  twobit_load( 4, 1 );
  twobit_load( 3, 2 );
  twobit_lexical( 0, 2 );
  twobit_op3_803( 4, 3 ); /* ustring-set!:trusted */
  twobit_reg( 4 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1898, compiled_block_1_1898 );
  twobit_trap( 2, 3, 4, 61 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_377( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-delete~1ayXVW~7648 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_78( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_368, 2, 2 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_1_369, 4, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_368( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1903, compiled_block_1_1903 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_movereg( 2, 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 1, 4 );
  twobit_reg( 2 );
  twobit_op2_62( 1, 370, compiled_temp_1_370 ); /* - */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_imm_const( int_to_char(32) ); /* #\space */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2_799( 2 ); /* make-ustring */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_371, 2, 1 );
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_load( 5, 1 );
  twobit_global( 3 ); /*  string-fold~1ayXVW~7588 */
  twobit_setrtn( 1908, compiled_block_1_1908 );
  twobit_invoke( 5 );
  twobit_label( 1908, compiled_block_1_1908 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_reg( 4 );
  twobit_op2_branchf_623( 3, 372, compiled_temp_1_372, 1910, compiled_block_1_1910 ); /* internal:branchf-= */
  twobit_stack( 3 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1910, compiled_block_1_1910 );
  twobit_load( 1, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_movereg( 4, 3 );
  twobit_global( 4 ); /* substring */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1903, compiled_block_1_1903 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  char-set?~1ayXVW~6491 */
  twobit_setrtn( 1912, compiled_block_1_1912 );
  twobit_invoke( 1 );
  twobit_label( 1912, compiled_block_1_1912 );
  twobit_load( 0, 0 );
  twobit_branchf( 1914, compiled_block_1_1914 );
  twobit_lexical( 0, 2 );
  twobit_skip( 1913, compiled_block_1_1913 );
  twobit_label( 1914, compiled_block_1_1914 );
  twobit_lexical( 0, 2 );
  twobit_op1_branchf_615( 1916, compiled_block_1_1916 ); /* internal:branchf-char? */
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  char-set~1ayXVW~6558 */
  twobit_setrtn( 1917, compiled_block_1_1917 );
  twobit_invoke( 1 );
  twobit_label( 1917, compiled_block_1_1917 );
  twobit_load( 0, 0 );
  twobit_skip( 1913, compiled_block_1_1913 );
  twobit_label( 1916, compiled_block_1_1916 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_global( 8 ); /*  error~1ayXVW~7479 */
  twobit_setrtn( 1918, compiled_block_1_1918 );
  twobit_invoke( 2 );
  twobit_label( 1918, compiled_block_1_1918 );
  twobit_load( 0, 0 );
  twobit_label( 1913, compiled_block_1_1913 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_373, 10, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 3, 5 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  string-fold~1ayXVW~7588 */
  twobit_setrtn( 1922, compiled_block_1_1922 );
  twobit_invoke( 5 );
  twobit_label( 1922, compiled_block_1_1922 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_stack( 2 );
  twobit_setreg( 3 );
  twobit_load( 4, 1 );
  twobit_imm_const( int_to_char(32) ); /* #\space */
  twobit_setreg( 2 );
  twobit_stack( 4 );
  twobit_op2_799( 2 ); /* make-ustring */
  twobit_setreg( 2 );
  twobit_store( 2, 4 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_374, 12, 2 );
  twobit_setreg( 1 );
  twobit_movereg( 3, 5 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  string-fold~1ayXVW~7588 */
  twobit_setrtn( 1927, compiled_block_1_1927 );
  twobit_invoke( 5 );
  twobit_label( 1927, compiled_block_1_1927 );
  twobit_load( 0, 0 );
  twobit_stack( 4 );
  twobit_pop( 4 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_371( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_lexical( 1, 2 );
  twobit_setrtn( 1904, compiled_block_1_1904 );
  twobit_invoke( 1 );
  twobit_label( 1904, compiled_block_1_1904 );
  twobit_load( 0, 0 );
  twobit_branchf( 1906, compiled_block_1_1906 );
  twobit_stack( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_load( 3, 1 );
  twobit_load( 4, 2 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 2, 1907, compiled_block_1_1907 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_load( 4, 2 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 2, 1907, compiled_block_1_1907 );
  twobit_stack( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 2, 1907, compiled_block_1_1907 );
  twobit_stack( 2 );
  twobit_op1_36(); /* char? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 2, 1907, compiled_block_1_1907 );
  twobit_load( 4, 1 );
  twobit_load( 3, 2 );
  twobit_lexical( 0, 1 );
  twobit_op3_803( 4, 3 ); /* ustring-set!:trusted */
  twobit_reg( 4 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1906, compiled_block_1_1906 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1907, compiled_block_1_1907 );
  twobit_trap( 2, 3, 4, 61 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_373( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  char-set-contains?~1ayXVW~6535 */
  twobit_setrtn( 1919, compiled_block_1_1919 );
  twobit_invoke( 2 );
  twobit_label( 1919, compiled_block_1_1919 );
  twobit_load( 0, 0 );
  twobit_branchf( 1921, compiled_block_1_1921 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 375, compiled_temp_1_375 ); /* + */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1921, compiled_block_1_1921 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_374( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  char-set-contains?~1ayXVW~6535 */
  twobit_setrtn( 1923, compiled_block_1_1923 );
  twobit_invoke( 2 );
  twobit_label( 1923, compiled_block_1_1923 );
  twobit_load( 0, 0 );
  twobit_branchf( 1925, compiled_block_1_1925 );
  twobit_stack( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_load( 3, 1 );
  twobit_load( 4, 2 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 2, 1926, compiled_block_1_1926 );
  twobit_lexical( 0, 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_load( 4, 2 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 2, 1926, compiled_block_1_1926 );
  twobit_stack( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 2, 1926, compiled_block_1_1926 );
  twobit_stack( 2 );
  twobit_op1_36(); /* char? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 2, 1926, compiled_block_1_1926 );
  twobit_load( 4, 1 );
  twobit_load( 3, 2 );
  twobit_lexical( 0, 2 );
  twobit_op3_803( 4, 3 ); /* ustring-set!:trusted */
  twobit_reg( 4 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1925, compiled_block_1_1925 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1926, compiled_block_1_1926 );
  twobit_trap( 2, 3, 4, 61 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_369( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-filter~1ayXVW~7649 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_79( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_360, 2, 2 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_1_361, 4, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_360( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_branchf_615( 1931, compiled_block_1_1931 ); /* internal:branchf-char? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_362, 3, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1931, compiled_block_1_1931 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  char-set?~1ayXVW~6491 */
  twobit_setrtn( 1939, compiled_block_1_1939 );
  twobit_invoke( 1 );
  twobit_label( 1939, compiled_block_1_1939 );
  twobit_load( 0, 0 );
  twobit_branchf( 1941, compiled_block_1_1941 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_363, 6, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1941, compiled_block_1_1941 );
  twobit_lexical( 0, 2 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1951, compiled_block_1_1951 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_364, 8, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1951, compiled_block_1_1951 );
  twobit_global( 9 ); /*  string-index~1ayXVW~7650 */
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 11 ); /*  error~1ayXVW~7479 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_362( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 367, compiled_temp_1_367, 1933, compiled_block_1_1933 ); /* internal:branchf-< */
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1934, compiled_block_1_1934 );
  twobit_lexical( 1, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1934, compiled_block_1_1934 );
  twobit_lexical( 1, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1934, compiled_block_1_1934 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1934, compiled_block_1_1934 );
  twobit_lexical( 1, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_lexical( 1, 2 );
  twobit_op2_branchf_625( 4, 1936, compiled_block_1_1936 ); /* internal:branchf-char=? */
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1936, compiled_block_1_1936 );
  twobit_reg( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 1933, compiled_block_1_1933 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1934, compiled_block_1_1934 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_363( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 366, compiled_temp_1_366, 1943, compiled_block_1_1943 ); /* internal:branchf-< */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1944, compiled_block_1_1944 );
  twobit_lexical( 1, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1944, compiled_block_1_1944 );
  twobit_lexical( 1, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1944, compiled_block_1_1944 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1944, compiled_block_1_1944 );
  twobit_lexical( 1, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  char-set-contains?~1ayXVW~6535 */
  twobit_setrtn( 1945, compiled_block_1_1945 );
  twobit_invoke( 2 );
  twobit_label( 1945, compiled_block_1_1945 );
  twobit_load( 0, 0 );
  twobit_branchf( 1947, compiled_block_1_1947 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1947, compiled_block_1_1947 );
  twobit_stack( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1943, compiled_block_1_1943 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1944, compiled_block_1_1944 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_364( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 365, compiled_temp_1_365, 1953, compiled_block_1_1953 ); /* internal:branchf-< */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1954, compiled_block_1_1954 );
  twobit_lexical( 1, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1954, compiled_block_1_1954 );
  twobit_lexical( 1, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1954, compiled_block_1_1954 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1954, compiled_block_1_1954 );
  twobit_lexical( 1, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setrtn( 1955, compiled_block_1_1955 );
  twobit_invoke( 1 );
  twobit_label( 1955, compiled_block_1_1955 );
  twobit_load( 0, 0 );
  twobit_branchf( 1957, compiled_block_1_1957 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1957, compiled_block_1_1957 );
  twobit_stack( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1953, compiled_block_1_1953 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1954, compiled_block_1_1954 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_361( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-index~1ayXVW~7650 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_80( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_349, 2, 2 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_1_350, 4, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_349( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_branchf_615( 1964, compiled_block_1_1964 ); /* internal:branchf-char? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 2 );
  twobit_op2imm_131( fixnum(1), 351, compiled_temp_1_351 ); /* - */
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_352, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1964, compiled_block_1_1964 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  char-set?~1ayXVW~6491 */
  twobit_setrtn( 1972, compiled_block_1_1972 );
  twobit_invoke( 1 );
  twobit_label( 1972, compiled_block_1_1972 );
  twobit_load( 0, 0 );
  twobit_branchf( 1974, compiled_block_1_1974 );
  twobit_stack( 1 );
  twobit_op2imm_131( fixnum(1), 353, compiled_temp_1_353 ); /* - */
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_354, 6, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1974, compiled_block_1_1974 );
  twobit_lexical( 0, 2 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1984, compiled_block_1_1984 );
  twobit_stack( 1 );
  twobit_op2imm_131( fixnum(1), 355, compiled_temp_1_355 ); /* - */
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_356, 8, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1984, compiled_block_1_1984 );
  twobit_global( 9 ); /*  string-index-right~1ayXVW~7651 */
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 11 ); /*  error~1ayXVW~7479 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_352( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_637( fixnum(0), 359, compiled_temp_1_359, 1966, compiled_block_1_1966 ); /* internal:branchf->=/imm */
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1967, compiled_block_1_1967 );
  twobit_lexical( 1, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1967, compiled_block_1_1967 );
  twobit_lexical( 1, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1967, compiled_block_1_1967 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1967, compiled_block_1_1967 );
  twobit_lexical( 1, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_lexical( 1, 2 );
  twobit_op2_branchf_625( 4, 1969, compiled_block_1_1969 ); /* internal:branchf-char=? */
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1969, compiled_block_1_1969 );
  twobit_reg( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 1966, compiled_block_1_1966 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1967, compiled_block_1_1967 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_354( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_637( fixnum(0), 358, compiled_temp_1_358, 1976, compiled_block_1_1976 ); /* internal:branchf->=/imm */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1977, compiled_block_1_1977 );
  twobit_lexical( 1, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1977, compiled_block_1_1977 );
  twobit_lexical( 1, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1977, compiled_block_1_1977 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1977, compiled_block_1_1977 );
  twobit_lexical( 1, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  char-set-contains?~1ayXVW~6535 */
  twobit_setrtn( 1978, compiled_block_1_1978 );
  twobit_invoke( 2 );
  twobit_label( 1978, compiled_block_1_1978 );
  twobit_load( 0, 0 );
  twobit_branchf( 1980, compiled_block_1_1980 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1980, compiled_block_1_1980 );
  twobit_stack( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1976, compiled_block_1_1976 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1977, compiled_block_1_1977 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_356( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_637( fixnum(0), 357, compiled_temp_1_357, 1986, compiled_block_1_1986 ); /* internal:branchf->=/imm */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1987, compiled_block_1_1987 );
  twobit_lexical( 1, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1987, compiled_block_1_1987 );
  twobit_lexical( 1, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1987, compiled_block_1_1987 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1987, compiled_block_1_1987 );
  twobit_lexical( 1, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setrtn( 1988, compiled_block_1_1988 );
  twobit_invoke( 1 );
  twobit_label( 1988, compiled_block_1_1988 );
  twobit_load( 0, 0 );
  twobit_branchf( 1990, compiled_block_1_1990 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1990, compiled_block_1_1990 );
  twobit_stack( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1986, compiled_block_1_1986 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1987, compiled_block_1_1987 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_350( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-index-right~1ayXVW~7651 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_81( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_341, 2, 2 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_1_342, 4, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_341( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_branchf_615( 1997, compiled_block_1_1997 ); /* internal:branchf-char? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_343, 3, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1997, compiled_block_1_1997 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  char-set?~1ayXVW~6491 */
  twobit_setrtn( 2005, compiled_block_1_2005 );
  twobit_invoke( 1 );
  twobit_label( 2005, compiled_block_1_2005 );
  twobit_load( 0, 0 );
  twobit_branchf( 2007, compiled_block_1_2007 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_344, 6, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2007, compiled_block_1_2007 );
  twobit_lexical( 0, 2 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 2017, compiled_block_1_2017 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_345, 8, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2017, compiled_block_1_2017 );
  twobit_global( 9 ); /*  string-skip~1ayXVW~7652 */
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 11 ); /*  error~1ayXVW~7479 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_343( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 348, compiled_temp_1_348, 1999, compiled_block_1_1999 ); /* internal:branchf-< */
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 2000, compiled_block_1_2000 );
  twobit_lexical( 1, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 2000, compiled_block_1_2000 );
  twobit_lexical( 1, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 2000, compiled_block_1_2000 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 2000, compiled_block_1_2000 );
  twobit_lexical( 1, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_lexical( 1, 2 );
  twobit_op2_branchf_625( 4, 2002, compiled_block_1_2002 ); /* internal:branchf-char=? */
  twobit_reg( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 2002, compiled_block_1_2002 );
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1999, compiled_block_1_1999 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 2000, compiled_block_1_2000 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_344( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 347, compiled_temp_1_347, 2009, compiled_block_1_2009 ); /* internal:branchf-< */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 2010, compiled_block_1_2010 );
  twobit_lexical( 1, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 2010, compiled_block_1_2010 );
  twobit_lexical( 1, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 2010, compiled_block_1_2010 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 2010, compiled_block_1_2010 );
  twobit_lexical( 1, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  char-set-contains?~1ayXVW~6535 */
  twobit_setrtn( 2011, compiled_block_1_2011 );
  twobit_invoke( 2 );
  twobit_label( 2011, compiled_block_1_2011 );
  twobit_load( 0, 0 );
  twobit_branchf( 2013, compiled_block_1_2013 );
  twobit_stack( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 2013, compiled_block_1_2013 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2009, compiled_block_1_2009 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 2010, compiled_block_1_2010 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_345( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 346, compiled_temp_1_346, 2019, compiled_block_1_2019 ); /* internal:branchf-< */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 2020, compiled_block_1_2020 );
  twobit_lexical( 1, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 2020, compiled_block_1_2020 );
  twobit_lexical( 1, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 2020, compiled_block_1_2020 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 2020, compiled_block_1_2020 );
  twobit_lexical( 1, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setrtn( 2021, compiled_block_1_2021 );
  twobit_invoke( 1 );
  twobit_label( 2021, compiled_block_1_2021 );
  twobit_load( 0, 0 );
  twobit_branchf( 2023, compiled_block_1_2023 );
  twobit_stack( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 2023, compiled_block_1_2023 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2019, compiled_block_1_2019 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 2020, compiled_block_1_2020 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_342( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-skip~1ayXVW~7652 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_82( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_330, 2, 2 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_1_331, 4, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_330( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_branchf_615( 2030, compiled_block_1_2030 ); /* internal:branchf-char? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 2 );
  twobit_op2imm_131( fixnum(1), 332, compiled_temp_1_332 ); /* - */
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_333, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 2030, compiled_block_1_2030 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  char-set?~1ayXVW~6491 */
  twobit_setrtn( 2038, compiled_block_1_2038 );
  twobit_invoke( 1 );
  twobit_label( 2038, compiled_block_1_2038 );
  twobit_load( 0, 0 );
  twobit_branchf( 2040, compiled_block_1_2040 );
  twobit_stack( 1 );
  twobit_op2imm_131( fixnum(1), 334, compiled_temp_1_334 ); /* - */
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_335, 6, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2040, compiled_block_1_2040 );
  twobit_lexical( 0, 2 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 2050, compiled_block_1_2050 );
  twobit_stack( 1 );
  twobit_op2imm_131( fixnum(1), 336, compiled_temp_1_336 ); /* - */
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_337, 8, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2050, compiled_block_1_2050 );
  twobit_global( 9 ); /*  string-skip-right~1ayXVW~7653 */
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 11 ); /*  error~1ayXVW~7479 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_333( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_637( fixnum(0), 340, compiled_temp_1_340, 2032, compiled_block_1_2032 ); /* internal:branchf->=/imm */
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 2033, compiled_block_1_2033 );
  twobit_lexical( 1, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 2033, compiled_block_1_2033 );
  twobit_lexical( 1, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 2033, compiled_block_1_2033 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 2033, compiled_block_1_2033 );
  twobit_lexical( 1, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_lexical( 1, 2 );
  twobit_op2_branchf_625( 4, 2035, compiled_block_1_2035 ); /* internal:branchf-char=? */
  twobit_reg( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 2035, compiled_block_1_2035 );
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 2032, compiled_block_1_2032 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 2033, compiled_block_1_2033 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_335( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_637( fixnum(0), 339, compiled_temp_1_339, 2042, compiled_block_1_2042 ); /* internal:branchf->=/imm */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 2043, compiled_block_1_2043 );
  twobit_lexical( 1, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 2043, compiled_block_1_2043 );
  twobit_lexical( 1, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 2043, compiled_block_1_2043 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 2043, compiled_block_1_2043 );
  twobit_lexical( 1, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  char-set-contains?~1ayXVW~6535 */
  twobit_setrtn( 2044, compiled_block_1_2044 );
  twobit_invoke( 2 );
  twobit_label( 2044, compiled_block_1_2044 );
  twobit_load( 0, 0 );
  twobit_branchf( 2046, compiled_block_1_2046 );
  twobit_stack( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 2046, compiled_block_1_2046 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2042, compiled_block_1_2042 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 2043, compiled_block_1_2043 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_337( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_637( fixnum(0), 338, compiled_temp_1_338, 2052, compiled_block_1_2052 ); /* internal:branchf->=/imm */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 2053, compiled_block_1_2053 );
  twobit_lexical( 1, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 2053, compiled_block_1_2053 );
  twobit_lexical( 1, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 2053, compiled_block_1_2053 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 2053, compiled_block_1_2053 );
  twobit_lexical( 1, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setrtn( 2054, compiled_block_1_2054 );
  twobit_invoke( 1 );
  twobit_label( 2054, compiled_block_1_2054 );
  twobit_load( 0, 0 );
  twobit_branchf( 2056, compiled_block_1_2056 );
  twobit_stack( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 2056, compiled_block_1_2056 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2052, compiled_block_1_2052 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 2053, compiled_block_1_2053 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_331( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-skip-right~1ayXVW~7653 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_83( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_317, 2, 2 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_1_318, 4, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_317( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_branchf_615( 2063, compiled_block_1_2063 ); /* internal:branchf-char? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_319, 3, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2063, compiled_block_1_2063 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  char-set?~1ayXVW~6491 */
  twobit_setrtn( 2071, compiled_block_1_2071 );
  twobit_invoke( 1 );
  twobit_label( 2071, compiled_block_1_2071 );
  twobit_load( 0, 0 );
  twobit_branchf( 2073, compiled_block_1_2073 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_320, 6, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 2073, compiled_block_1_2073 );
  twobit_lexical( 0, 2 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 2083, compiled_block_1_2083 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_321, 8, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 2083, compiled_block_1_2083 );
  twobit_global( 9 ); /*  string-count~1ayXVW~7654 */
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 11 ); /*  error~1ayXVW~7479 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_319( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_621( 4, 328, compiled_temp_1_328, 2065, compiled_block_1_2065 ); /* internal:branchf->= */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 2065, compiled_block_1_2065 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2066, compiled_block_1_2066 );
  twobit_lexical( 1, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2066, compiled_block_1_2066 );
  twobit_lexical( 1, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2066, compiled_block_1_2066 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2066, compiled_block_1_2066 );
  twobit_lexical( 1, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_lexical( 1, 2 );
  twobit_op2_branchf_625( 4, 2068, compiled_block_1_2068 ); /* internal:branchf-char=? */
  twobit_reg( 2 );
  twobit_op2imm_130( fixnum(1), 329, compiled_temp_1_329 ); /* + */
  twobit_skip( 2067, compiled_block_1_2067 );
  twobit_label( 2068, compiled_block_1_2068 );
  twobit_reg( 2 );
  twobit_label( 2067, compiled_block_1_2067 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 2066, compiled_block_1_2066 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_320( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_621( 4, 325, compiled_temp_1_325, 2075, compiled_block_1_2075 ); /* internal:branchf->= */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 2075, compiled_block_1_2075 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_reg( 1 );
  twobit_op2imm_130( fixnum(1), 326, compiled_temp_1_326 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 0, 2076, compiled_block_1_2076 );
  twobit_lexical( 1, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 0, 2076, compiled_block_1_2076 );
  twobit_lexical( 1, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 0, 2076, compiled_block_1_2076 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 0, 2076, compiled_block_1_2076 );
  twobit_lexical( 1, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  char-set-contains?~1ayXVW~6535 */
  twobit_setrtn( 2077, compiled_block_1_2077 );
  twobit_invoke( 2 );
  twobit_label( 2077, compiled_block_1_2077 );
  twobit_load( 0, 0 );
  twobit_branchf( 2079, compiled_block_1_2079 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 327, compiled_temp_1_327 ); /* + */
  twobit_skip( 2078, compiled_block_1_2078 );
  twobit_label( 2079, compiled_block_1_2079 );
  twobit_stack( 1 );
  twobit_label( 2078, compiled_block_1_2078 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 2076, compiled_block_1_2076 );
  twobit_trap( 31, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_321( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_621( 4, 322, compiled_temp_1_322, 2085, compiled_block_1_2085 ); /* internal:branchf->= */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 2085, compiled_block_1_2085 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_reg( 1 );
  twobit_op2imm_130( fixnum(1), 323, compiled_temp_1_323 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 0, 2086, compiled_block_1_2086 );
  twobit_lexical( 1, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 0, 2086, compiled_block_1_2086 );
  twobit_lexical( 1, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 0, 2086, compiled_block_1_2086 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 0, 2086, compiled_block_1_2086 );
  twobit_lexical( 1, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setrtn( 2087, compiled_block_1_2087 );
  twobit_invoke( 1 );
  twobit_label( 2087, compiled_block_1_2087 );
  twobit_load( 0, 0 );
  twobit_branchf( 2089, compiled_block_1_2089 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 324, compiled_temp_1_324 ); /* + */
  twobit_skip( 2088, compiled_block_1_2088 );
  twobit_label( 2089, compiled_block_1_2089 );
  twobit_stack( 1 );
  twobit_label( 2088, compiled_block_1_2088 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 2086, compiled_block_1_2086 );
  twobit_trap( 31, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_318( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-count~1ayXVW~7654 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_84( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_312, 2, 2 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_1_313, 4, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_312( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 2 );
  twobit_op2imm_131( fixnum(1), 314, compiled_temp_1_314 ); /* - */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_1_315, 3, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 4, 1 );
  twobit_load( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_315( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 316, compiled_temp_1_316, 2096, compiled_block_1_2096 ); /* internal:branchf-< */
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 2096, compiled_block_1_2096 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_check( 2, 1, 3, 2097, compiled_block_1_2097 );
  twobit_lexical( 1, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_check( 2, 1, 3, 2097, compiled_block_1_2097 );
  twobit_lexical( 1, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_check( 2, 1, 3, 2097, compiled_block_1_2097 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_check( 2, 1, 3, 2097, compiled_block_1_2097 );
  twobit_lexical( 1, 2 );
  twobit_op1_36(); /* char? */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_check( 2, 1, 3, 2097, compiled_block_1_2097 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_op3_803( 1, 3 ); /* ustring-set!:trusted */
  twobit_reg( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 2097, compiled_block_1_2097 );
  twobit_trap( 3, 1, 2, 61 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_313( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-fill!~1ayXVW~7655 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_85( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_308, 2, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_309, 4, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_308( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_reg( 2 );
  twobit_op2_62( 1, 310, compiled_temp_1_310 ); /* - */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_61( 4, 311, compiled_temp_1_311 ); /* + */
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  string-copy!~1ayXVW~7656 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  check-substring-spec~1ayXVW~7580 */
  twobit_setrtn( 2102, compiled_block_1_2102 );
  twobit_invoke( 4 );
  twobit_label( 2102, compiled_block_1_2102 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 4, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_load( 5, 1 );
  twobit_global( 3 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_pop( 2 );
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_309( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-copy!~1ayXVW~7656 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_86( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_reg( 4 );
  twobit_op2_branchf_620( 2, 299, compiled_temp_1_299, 2107, compiled_block_1_2107 ); /* internal:branchf-> */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 4, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 31 );
  twobit_movereg( 5, 4 );
  twobit_movereg( 31, 2 );
  twobit_lambda( compiled_start_1_300, 3, 4 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 31 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 2107, compiled_block_1_2107 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 5 );
  twobit_op2imm_131( fixnum(1), 301, compiled_temp_1_301 ); /* - */
  twobit_setreg( 31 );
  twobit_reg( 5 );
  twobit_op2_62( 4, 302, compiled_temp_1_302 ); /* - */
  twobit_setreg( 30 );
  twobit_reg( 2 );
  twobit_op2_61( 30, 303, compiled_temp_1_303 ); /* + */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 2, 304, compiled_temp_1_304 ); /* + */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 30 );
  twobit_movereg( 30, 2 );
  twobit_lambda( compiled_start_1_305, 5, 4 );
  twobit_setreg( 4 );
  twobit_movereg( 31, 1 );
  twobit_reg( 30 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 30 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_300( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_621( 4, 307, compiled_temp_1_307, 2109, compiled_block_1_2109 ); /* internal:branchf->= */
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 2109, compiled_block_1_2109 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2110, compiled_block_1_2110 );
  twobit_lexical( 0, 3 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2110, compiled_block_1_2110 );
  twobit_lexical( 0, 3 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2110, compiled_block_1_2110 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2110, compiled_block_1_2110 );
  twobit_lexical( 0, 3 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 31, 2111, compiled_block_1_2111 );
  twobit_lexical( 0, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 31, 2111, compiled_block_1_2111 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 31, 2111, compiled_block_1_2111 );
  twobit_reg( 2 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 31, 2111, compiled_block_1_2111 );
  twobit_reg( 4 );
  twobit_op1_36(); /* char? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 31, 2111, compiled_block_1_2111 );
  twobit_lexical( 0, 1 );
  twobit_op3_803( 2, 4 ); /* ustring-set!:trusted */
  twobit_reg( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 2110, compiled_block_1_2110 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_label( 2111, compiled_block_1_2111 );
  twobit_trap( 31, 2, 4, 61 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_305( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 306, compiled_temp_1_306, 2115, compiled_block_1_2115 ); /* internal:branchf-< */
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 2115, compiled_block_1_2115 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2116, compiled_block_1_2116 );
  twobit_lexical( 0, 3 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2116, compiled_block_1_2116 );
  twobit_lexical( 0, 3 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2116, compiled_block_1_2116 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2116, compiled_block_1_2116 );
  twobit_lexical( 0, 3 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 31, 2117, compiled_block_1_2117 );
  twobit_lexical( 0, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 31, 2117, compiled_block_1_2117 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 31, 2117, compiled_block_1_2117 );
  twobit_reg( 2 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 31, 2117, compiled_block_1_2117 );
  twobit_reg( 4 );
  twobit_op1_36(); /* char? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 31, 2117, compiled_block_1_2117 );
  twobit_lexical( 0, 1 );
  twobit_op3_803( 2, 4 ); /* ustring-set!:trusted */
  twobit_reg( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 2116, compiled_block_1_2116 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_label( 2117, compiled_block_1_2117 );
  twobit_trap( 31, 2, 4, 61 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_87( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  string-contains~1ayXVW~7658 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_288, 3, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_289, 5, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_288( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_290, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_291, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_290( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_291( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op2_62( 1, 292, compiled_temp_1_292 ); /* - */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op2_62( 4, 293, compiled_temp_1_293 ); /* - */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 3, 294, compiled_temp_1_294 ); /* + */
  twobit_setreg( 3 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 31 );
  twobit_movereg( 31, 5 );
  twobit_lambda( compiled_start_1_295, 3, 5 );
  twobit_setreg( 4 );
  twobit_reg( 31 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 31 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_295( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 296, compiled_temp_1_296, 2122, compiled_block_1_2122 ); /* internal:branchf-< */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 3 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_61( 4, 297, compiled_temp_1_297 ); /* + */
  twobit_setreg( 4 );
  twobit_lexical( 2, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 2, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 5 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 6 );
  twobit_global( 1 ); /*  string=~1ayXVW~7617 */
  twobit_setrtn( 2123, compiled_block_1_2123 );
  twobit_invoke( 6 );
  twobit_label( 2123, compiled_block_1_2123 );
  twobit_load( 0, 0 );
  twobit_branchf( 2125, compiled_block_1_2125 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2125, compiled_block_1_2125 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 298, compiled_temp_1_298 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 0, 5 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 2122, compiled_block_1_2122 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_289( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_88( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  string-contains~1ayXVW~7658 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_277, 3, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_278, 5, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_277( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_279, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_280, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_279( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_280( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op2_62( 1, 281, compiled_temp_1_281 ); /* - */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op2_62( 4, 282, compiled_temp_1_282 ); /* - */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 3, 283, compiled_temp_1_283 ); /* + */
  twobit_setreg( 3 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 31 );
  twobit_movereg( 31, 5 );
  twobit_lambda( compiled_start_1_284, 3, 5 );
  twobit_setreg( 4 );
  twobit_reg( 31 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 31 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_284( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 285, compiled_temp_1_285, 2133, compiled_block_1_2133 ); /* internal:branchf-< */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 3 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_61( 4, 286, compiled_temp_1_286 ); /* + */
  twobit_setreg( 4 );
  twobit_lexical( 2, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 2, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 5 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 6 );
  twobit_global( 1 ); /*  string-ci=~1ayXVW~7623 */
  twobit_setrtn( 2134, compiled_block_1_2134 );
  twobit_invoke( 6 );
  twobit_label( 2134, compiled_block_1_2134 );
  twobit_load( 0, 0 );
  twobit_branchf( 2136, compiled_block_1_2136 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2136, compiled_block_1_2136 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 287, compiled_temp_1_287 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 0, 5 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 2133, compiled_block_1_2133 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_278( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_89( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 7 );
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 2, 7 );
  twobit_store( 3, 5 );
  twobit_store( 4, 1 );
  twobit_store( 5, 2 );
  twobit_store( 6, 3 );
  twobit_store( 7, 4 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 4, 3 );
  twobit_movereg( 5, 4 );
  twobit_global( 1 ); /*  make-kmp-restart-vector~1ayXVW~7661 */
  twobit_setrtn( 2142, compiled_block_1_2142 );
  twobit_invoke( 4 );
  twobit_label( 2142, compiled_block_1_2142 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_stack( 2 );
  twobit_op2_62( 3, 264, compiled_temp_1_264 ); /* - */
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_stack( 4 );
  twobit_op2_62( 1, 265, compiled_temp_1_265 ); /* - */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_load( 7, 5 );
  twobit_load( 6, 6 );
  twobit_load( 5, 1 );
  twobit_load( 3, 7 );
  twobit_lambda( compiled_start_1_266, 4, 7 );
  twobit_setreg( 4 );
  twobit_load( 3, 4 );
  twobit_load( 1, 3 );
  twobit_stack( 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_stack( 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 5 );
  twobit_movereg( 2, 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 5 );
  twobit_pop( 7 );
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_266( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 31 );
  twobit_reg( 2 );
  twobit_op2_branchf_623( 31, 267, compiled_temp_1_267, 2144, compiled_block_1_2144 ); /* internal:branchf-= */
  twobit_lexical( 0, 2 );
  twobit_setreg( 31 );
  twobit_reg( 1 );
  twobit_op2_62( 31, 268, compiled_temp_1_268 ); /* - */
  twobit_return();
  twobit_label( 2144, compiled_block_1_2144 );
  twobit_reg( 4 );
  twobit_op2_branchf_622( 3, 269, compiled_temp_1_269, 2146, compiled_block_1_2146 ); /* internal:branchf-<= */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_store( 4, 4 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 31 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 1, 30, 0, 2147, compiled_block_1_2147 );
  twobit_lexical( 0, 3 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 31 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 1, 30, 0, 2147, compiled_block_1_2147 );
  twobit_lexical( 0, 3 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 31 );
  twobit_reg( 1 );
  twobit_op2_407( 31 ); /* <:fix:fix */
  twobit_setreg( 31 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 1, 30, 0, 2147, compiled_block_1_2147 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 31 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 1, 30, 0, 2147, compiled_block_1_2147 );
  twobit_lexical( 0, 3 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_lexical( 0, 5 );
  twobit_op2_61( 2, 270, compiled_temp_1_270 ); /* + */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 30 );
  twobit_lexical( 0, 6 );
  twobit_setreg( 29 );
  twobit_reg( 30 );
  twobit_check( 31, 29, 0, 2148, compiled_block_1_2148 );
  twobit_lexical( 0, 6 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 30 );
  twobit_lexical( 0, 6 );
  twobit_setreg( 29 );
  twobit_reg( 30 );
  twobit_check( 31, 29, 0, 2148, compiled_block_1_2148 );
  twobit_lexical( 0, 6 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_op2_407( 30 ); /* <:fix:fix */
  twobit_setreg( 30 );
  twobit_lexical( 0, 6 );
  twobit_setreg( 29 );
  twobit_reg( 30 );
  twobit_check( 31, 29, 0, 2148, compiled_block_1_2148 );
  twobit_reg( 31 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 30 );
  twobit_lexical( 0, 6 );
  twobit_setreg( 29 );
  twobit_reg( 30 );
  twobit_check( 31, 29, 0, 2148, compiled_block_1_2148 );
  twobit_lexical( 0, 6 );
  twobit_op2_802( 31 ); /* ustring-ref:trusted */
  twobit_setreg( 2 );
  twobit_lexical( 0, 7 );
  twobit_setrtn( 2149, compiled_block_1_2149 );
  twobit_invoke( 2 );
  twobit_label( 2149, compiled_block_1_2149 );
  twobit_load( 0, 0 );
  twobit_branchf( 2151, compiled_block_1_2151 );
  twobit_load( 4, 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_500( 4 ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_load( 4, 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 4, 271, compiled_temp_1_271 ); /* + */
  twobit_setreg( 2 );
  twobit_stack( 3 );
  twobit_op2imm_131( fixnum(1), 272, compiled_temp_1_272 ); /* - */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2imm_131( fixnum(1), 273, compiled_temp_1_273 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 5 );
  twobit_load( 4, 3 );
  twobit_reg( 5 );
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 2151, compiled_block_1_2151 );
  twobit_stack( 2 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_load( 4, 2 );
  twobit_reg( 2 );
  twobit_check( 4, 3, 0, 2153, compiled_block_1_2153 );
  twobit_lexical( 0, 4 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 4, 3, 0, 2153, compiled_block_1_2153 );
  twobit_lexical( 0, 4 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_load( 4, 2 );
  twobit_reg( 2 );
  twobit_check( 4, 3, 0, 2153, compiled_block_1_2153 );
  twobit_stack( 2 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 4, 3, 0, 2153, compiled_block_1_2153 );
  twobit_lexical( 0, 4 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(-1), 274, compiled_temp_1_274, 2155, compiled_block_1_2155 ); /* internal:branchf-=/imm */
  twobit_stack( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_stack( 3 );
  twobit_op2imm_131( fixnum(1), 275, compiled_temp_1_275 ); /* - */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 5 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 5 );
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 2155, compiled_block_1_2155 );
  twobit_lexical( 0, 2 );
  twobit_op2_62( 4, 276, compiled_temp_1_276 ); /* - */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_movereg( 3, 5 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_load( 3, 3 );
  twobit_reg( 5 );
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 2146, compiled_block_1_2146 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 2147, compiled_block_1_2147 );
  twobit_trap( 30, 1, 0, 60 );
  twobit_label( 2148, compiled_block_1_2148 );
  twobit_trap( 29, 31, 0, 60 );
  twobit_label( 2153, compiled_block_1_2153 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_90( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_lambda( compiled_start_1_247, 2, 1 );
  twobit_setreg( 4 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_248, 4, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_247( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_249, 2, 1 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_250, 4, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_249( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  make-kmp-restart-vector~1ayXVW~7661 */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_250( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 2161, compiled_block_1_2161 ); /* internal:branchf-null? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_reg( 3 );
  twobit_op2_62( 2, 251, compiled_temp_1_251 ); /* - */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_80( 3 ); /* make-vector */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_636( fixnum(0), 252, compiled_temp_1_252, 2163, compiled_block_1_2163 ); /* internal:branchf->/imm */
  twobit_movereg( 2, 3 );
  twobit_store( 3, 2 );
  twobit_reg( 2 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 31 );
  twobit_reg( 1 );
  twobit_check( 2, 31, 0, 2164, compiled_block_1_2164 );
  twobit_lexical( 1, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 31 );
  twobit_reg( 1 );
  twobit_check( 2, 31, 0, 2164, compiled_block_1_2164 );
  twobit_lexical( 1, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op2_407( 1 ); /* <:fix:fix */
  twobit_setreg( 31 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 2, 30, 0, 2165, compiled_block_1_2165 );
  twobit_reg( 2 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 31 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 2, 30, 0, 2165, compiled_block_1_2165 );
  twobit_lexical( 1, 1 );
  twobit_op2_802( 2 ); /* ustring-ref:trusted */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op2imm_131( fixnum(1), 253, compiled_temp_1_253 ); /* - */
  twobit_setreg( 30 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 29 );
  twobit_movereg( 30, 6 );
  twobit_movereg( 31, 5 );
  twobit_movereg( 29, 4 );
  twobit_load( 3, 1 );
  twobit_lambda( compiled_start_1_254, 3, 6 );
  twobit_setreg( 1 );
  twobit_reg( 29 );
  twobit_op2_84( 1 ); /* cell-set! */
  twobit_reg( 29 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_setreg( 2 );
  twobit_load( 3, 2 );
  twobit_reg( 4 );
  twobit_setrtn( 2185, compiled_block_1_2185 );
  twobit_invoke( 3 );
  twobit_label( 2185, compiled_block_1_2185 );
  twobit_load( 0, 0 );
  twobit_skip( 2162, compiled_block_1_2162 );
  twobit_label( 2163, compiled_block_1_2163 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 2162, compiled_block_1_2162 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2161, compiled_block_1_2161 );
  twobit_movereg( 1, 2 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 2165, compiled_block_1_2165 );
  twobit_trap( 30, 2, 0, 60 );
  twobit_label( 2164, compiled_block_1_2164 );
  twobit_trap( 31, 2, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_254( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_lexical( 0, 6 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 255, compiled_temp_1_255, 2167, compiled_block_1_2167 ); /* internal:branchf-< */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_reg( 3 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 4 );
  twobit_lexical( 2, 1 );
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_check( 3, 31, 0, 2168, compiled_block_1_2168 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 2, 1 );
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_check( 3, 31, 0, 2168, compiled_block_1_2168 );
  twobit_reg( 3 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 2, 1 );
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_check( 3, 31, 0, 2168, compiled_block_1_2168 );
  twobit_lexical( 2, 1 );
  twobit_op2_802( 3 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 31 );
  twobit_movereg( 31, 2 );
  twobit_lambda( compiled_start_1_256, 3, 4 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 31 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 2167, compiled_block_1_2167 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 2168, compiled_block_1_2168 );
  twobit_trap( 31, 3, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_256( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_639( fixnum(-1), 257, compiled_temp_1_257, 2170, compiled_block_1_2170 ); /* internal:branchf-=/imm */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_op2imm_130( fixnum(1), 258, compiled_temp_1_258 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 5 );
  twobit_setreg( 2 );
  twobit_lexical( 2, 1 );
  twobit_setrtn( 2171, compiled_block_1_2171 );
  twobit_invoke( 2 );
  twobit_label( 2171, compiled_block_1_2171 );
  twobit_load( 0, 0 );
  twobit_branchf( 2173, compiled_block_1_2173 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_skip( 2172, compiled_block_1_2172 );
  twobit_label( 2173, compiled_block_1_2173 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_label( 2172, compiled_block_1_2172 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 2, 2174, compiled_block_1_2174 );
  twobit_lexical( 1, 3 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 2, 2174, compiled_block_1_2174 );
  twobit_stack( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 2, 2174, compiled_block_1_2174 );
  twobit_load( 3, 1 );
  twobit_lexical( 1, 3 );
  twobit_op3_403( 3, 4 ); /* vector-set!:trusted */
  twobit_lexical( 0, 3 );
  twobit_op2imm_130( fixnum(1), 259, compiled_temp_1_259 ); /* + */
  twobit_setreg( 3 );
  twobit_lexical( 1, 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_label( 2170, compiled_block_1_2170 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_61( 4, 260, compiled_temp_1_260 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 3, 1 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 0, 2176, compiled_block_1_2176 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 3, 1 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 0, 2176, compiled_block_1_2176 );
  twobit_reg( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 3, 1 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 0, 2176, compiled_block_1_2176 );
  twobit_lexical( 3, 1 );
  twobit_op2_802( 4 ); /* ustring-ref:trusted */
  twobit_setreg( 2 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 1 );
  twobit_lexical( 2, 1 );
  twobit_setrtn( 2177, compiled_block_1_2177 );
  twobit_invoke( 2 );
  twobit_label( 2177, compiled_block_1_2177 );
  twobit_load( 0, 0 );
  twobit_branchf( 2179, compiled_block_1_2179 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 4, 261, compiled_temp_1_261 ); /* + */
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 3, 262, compiled_temp_1_262 ); /* + */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_check( 3, 4, 1, 2180, compiled_block_1_2180 );
  twobit_lexical( 1, 3 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_407( 2 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_check( 3, 4, 1, 2180, compiled_block_1_2180 );
  twobit_reg( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_check( 3, 4, 1, 2180, compiled_block_1_2180 );
  twobit_lexical( 1, 3 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_lexical( 0, 3 );
  twobit_op2imm_130( fixnum(1), 263, compiled_temp_1_263 ); /* + */
  twobit_setreg( 3 );
  twobit_lexical( 1, 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_movereg( 2, 4 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_label( 2179, compiled_block_1_2179 );
  twobit_stack( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 3 );
  twobit_load( 4, 1 );
  twobit_reg( 2 );
  twobit_check( 4, 3, 0, 2182, compiled_block_1_2182 );
  twobit_lexical( 1, 3 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 3 );
  twobit_load( 4, 1 );
  twobit_reg( 2 );
  twobit_check( 4, 3, 0, 2182, compiled_block_1_2182 );
  twobit_stack( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 4, 3, 0, 2182, compiled_block_1_2182 );
  twobit_lexical( 1, 3 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 2176, compiled_block_1_2176 );
  twobit_trap( 2, 4, 0, 60 );
  twobit_label( 2174, compiled_block_1_2174 );
  twobit_trap( 2, 1, 4, 161 );
  twobit_label( 2182, compiled_block_1_2182 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_label( 2180, compiled_block_1_2180 );
  twobit_trap( 1, 4, 3, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_248( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_610( 2189, compiled_block_1_2189 ); /* internal:branchf-null? */
  twobit_global( 1 ); /* char=? */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 2189, compiled_block_1_2189 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 2191, compiled_block_1_2191 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 2193, compiled_block_1_2193 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 2 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 2193, compiled_block_1_2193 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 4 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 2191, compiled_block_1_2191 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_91( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 6 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 4, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 31 );
  twobit_movereg( 31, 4 );
  twobit_lambda( compiled_start_1_243, 3, 6 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 31 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_243( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_lexical( 0, 6 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_61( 4, 244, compiled_temp_1_244 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 0, 2197, compiled_block_1_2197 );
  twobit_lexical( 0, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 0, 2197, compiled_block_1_2197 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 0, 2197, compiled_block_1_2197 );
  twobit_reg( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 0, 2197, compiled_block_1_2197 );
  twobit_lexical( 0, 1 );
  twobit_op2_802( 4 ); /* ustring-ref:trusted */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 5 );
  twobit_setrtn( 2198, compiled_block_1_2198 );
  twobit_invoke( 2 );
  twobit_label( 2198, compiled_block_1_2198 );
  twobit_load( 0, 0 );
  twobit_branchf( 2200, compiled_block_1_2200 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 245, compiled_temp_1_245 ); /* + */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2200, compiled_block_1_2200 );
  twobit_stack( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_load( 4, 1 );
  twobit_reg( 2 );
  twobit_check( 4, 3, 0, 2201, compiled_block_1_2201 );
  twobit_lexical( 0, 2 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 4, 3, 0, 2201, compiled_block_1_2201 );
  twobit_lexical( 0, 2 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_load( 4, 1 );
  twobit_reg( 2 );
  twobit_check( 4, 3, 0, 2201, compiled_block_1_2201 );
  twobit_stack( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 4, 3, 0, 2201, compiled_block_1_2201 );
  twobit_lexical( 0, 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(-1), 246, compiled_temp_1_246, 2203, compiled_block_1_2203 ); /* internal:branchf-=/imm */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2203, compiled_block_1_2203 );
  twobit_lexical( 0, 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_movereg( 4, 1 );
  twobit_reg( 3 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 2197, compiled_block_1_2197 );
  twobit_trap( 2, 4, 0, 60 );
  twobit_label( 2201, compiled_block_1_2201 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_92( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 4 );
  twobit_lambda( compiled_start_1_228, 2, 4 );
  twobit_setreg( 2 );
  twobit_movereg( 5, 1 );
  twobit_lambda( compiled_start_1_229, 4, 1 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_228( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_230, 2, 1 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_231, 4, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_230( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_610( 2207, compiled_block_1_2207 ); /* internal:branchf-null? */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 2207, compiled_block_1_2207 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 2209, compiled_block_1_2209 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 2211, compiled_block_1_2211 );
  twobit_reg( 4 );
  twobit_op1_25(); /* exact? */
  twobit_branchf( 2213, compiled_block_1_2213 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_67( 4, 242, compiled_temp_1_242 ); /* <= */
  twobit_skip( 2210, compiled_block_1_2210 );
  twobit_label( 2213, compiled_block_1_2213 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 2210, compiled_block_1_2210 );
  twobit_label( 2211, compiled_block_1_2211 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2210, compiled_block_1_2210 );
  twobit_branchf( 2215, compiled_block_1_2215 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 2215, compiled_block_1_2215 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 3 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 2209, compiled_block_1_2209 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_231( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_232, 2, 1 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_233, 4, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_232( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-kmp-partial-search~1ayXVW~7663 */
  twobit_setreg( 1 );
  twobit_lexical( 2, 3 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-start+end~1ayXVW~7577 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_233( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 2220, compiled_block_1_2220 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_movereg( 2, 1 );
  twobit_store( 1, 1 );
  twobit_lexical( 2, 2 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 2 );
  twobit_lexical( 2, 2 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_check( 4, 0, 0, 2221, compiled_block_1_2221 );
  twobit_lexical( 2, 2 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_234, 3, 3 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_lexical( 2, 4 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2220, compiled_block_1_2220 );
  twobit_movereg( 1, 2 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 2221, compiled_block_1_2221 );
  twobit_trap( 4, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_234( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_branchf_623( 4, 235, compiled_temp_1_235, 2223, compiled_block_1_2223 ); /* internal:branchf-= */
  twobit_reg( 1 );
  twobit_op1_32( 236, compiled_temp_1_236 ); /* -- */
  twobit_return();
  twobit_label( 2223, compiled_block_1_2223 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_623( 4, 237, compiled_temp_1_237, 2225, compiled_block_1_2225 ); /* internal:branchf-= */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 2225, compiled_block_1_2225 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 4 );
  twobit_lexical( 3, 3 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2226, compiled_block_1_2226 );
  twobit_lexical( 3, 3 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 4 );
  twobit_lexical( 3, 3 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2226, compiled_block_1_2226 );
  twobit_lexical( 3, 3 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 3, 3 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2226, compiled_block_1_2226 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 3, 3 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2226, compiled_block_1_2226 );
  twobit_lexical( 3, 3 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_movereg( 2, 1 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_238, 3, 2 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 2235, compiled_block_1_2235 );
  twobit_invoke( 1 );
  twobit_label( 2235, compiled_block_1_2235 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 2226, compiled_block_1_2226 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_238( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_lexical( 2, 1 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_61( 4, 239, compiled_temp_1_239 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 4, 1 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 0, 2227, compiled_block_1_2227 );
  twobit_lexical( 4, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 3 );
  twobit_lexical( 4, 1 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 0, 2227, compiled_block_1_2227 );
  twobit_lexical( 4, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 4, 1 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 0, 2227, compiled_block_1_2227 );
  twobit_reg( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 4, 1 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 0, 2227, compiled_block_1_2227 );
  twobit_lexical( 4, 1 );
  twobit_op2_802( 4 ); /* ustring-ref:trusted */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 3, 1 );
  twobit_setrtn( 2228, compiled_block_1_2228 );
  twobit_invoke( 2 );
  twobit_label( 2228, compiled_block_1_2228 );
  twobit_load( 0, 0 );
  twobit_branchf( 2230, compiled_block_1_2230 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 240, compiled_temp_1_240 ); /* + */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2230, compiled_block_1_2230 );
  twobit_stack( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 4, 2 );
  twobit_setreg( 3 );
  twobit_load( 4, 1 );
  twobit_reg( 2 );
  twobit_check( 4, 3, 0, 2231, compiled_block_1_2231 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 4, 2 );
  twobit_setreg( 3 );
  twobit_load( 4, 1 );
  twobit_reg( 2 );
  twobit_check( 4, 3, 0, 2231, compiled_block_1_2231 );
  twobit_stack( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 4, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 4, 3, 0, 2231, compiled_block_1_2231 );
  twobit_lexical( 4, 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(-1), 241, compiled_temp_1_241, 2233, compiled_block_1_2233 ); /* internal:branchf-=/imm */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2233, compiled_block_1_2233 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_movereg( 4, 1 );
  twobit_reg( 3 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 2227, compiled_block_1_2227 );
  twobit_trap( 2, 4, 0, 60 );
  twobit_label( 2231, compiled_block_1_2231 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_229( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_610( 2242, compiled_block_1_2242 ); /* internal:branchf-null? */
  twobit_global( 1 ); /* char=? */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 2242, compiled_block_1_2242 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 2244, compiled_block_1_2244 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 2246, compiled_block_1_2246 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 2 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 2246, compiled_block_1_2246 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 4 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 2244, compiled_block_1_2244 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_93( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 1, 0, 0, 2250, compiled_block_1_2250 );
  twobit_reg( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_op1_31( 227, compiled_temp_1_227 ); /* zero? */
  twobit_return();
  twobit_label( 2250, compiled_block_1_2250 );
  twobit_trap( 1, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_94( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_lambda( compiled_start_1_221, 2, 2 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_222, 4, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_221( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-reverse~1ayXVW~7665 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_222( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 2 );
  twobit_op2_62( 1, 223, compiled_temp_1_223 ); /* - */
  twobit_setreg( 4 );
  twobit_imm_const( int_to_char(32) ); /* #\space */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_799( 3 ); /* make-ustring */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op2imm_131( fixnum(1), 224, compiled_temp_1_224 ); /* - */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_225, 3, 2 );
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op2_84( 31 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_setrtn( 2257, compiled_block_1_2257 );
  twobit_invoke( 2 );
  twobit_label( 2257, compiled_block_1_2257 );
  twobit_load( 0, 0 );
  twobit_stack( 3 );
  twobit_pop( 3 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_225( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op2imm_branchf_635( fixnum(0), 226, compiled_temp_1_226, 2253, compiled_block_1_2253 ); /* internal:branchf-</imm */
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 2253, compiled_block_1_2253 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2254, compiled_block_1_2254 );
  twobit_lexical( 1, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2254, compiled_block_1_2254 );
  twobit_lexical( 1, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2254, compiled_block_1_2254 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2254, compiled_block_1_2254 );
  twobit_lexical( 1, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 31, 2255, compiled_block_1_2255 );
  twobit_lexical( 0, 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 31, 2255, compiled_block_1_2255 );
  twobit_reg( 2 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 31, 2255, compiled_block_1_2255 );
  twobit_reg( 4 );
  twobit_op1_36(); /* char? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 31, 2255, compiled_block_1_2255 );
  twobit_lexical( 0, 2 );
  twobit_op3_803( 2, 4 ); /* ustring-set!:trusted */
  twobit_reg( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 2254, compiled_block_1_2254 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_label( 2255, compiled_block_1_2255 );
  twobit_trap( 31, 2, 4, 61 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_95( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_lambda( compiled_start_1_216, 2, 2 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_217, 4, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_216( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-reverse!~1ayXVW~7666 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_217( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 2 );
  twobit_op2imm_131( fixnum(1), 218, compiled_temp_1_218 ); /* - */
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_load( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_219, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_219( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op2_branchf_622( 2, 220, compiled_temp_1_220, 2261, compiled_block_1_2261 ); /* internal:branchf-<= */
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 2261, compiled_block_1_2261 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2262, compiled_block_1_2262 );
  twobit_lexical( 1, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2262, compiled_block_1_2262 );
  twobit_lexical( 1, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 0, 2263, compiled_block_1_2263 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 0, 2263, compiled_block_1_2263 );
  twobit_lexical( 1, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 31 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 2, 30, 0, 2264, compiled_block_1_2264 );
  twobit_reg( 2 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_check( 2, 31, 0, 2265, compiled_block_1_2265 );
  twobit_reg( 2 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_check( 2, 31, 0, 2265, compiled_block_1_2265 );
  twobit_lexical( 1, 1 );
  twobit_op2_802( 2 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_36(); /* char? */
  twobit_setreg( 31 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 4, 1, 30, 2266, compiled_block_1_2266 );
  twobit_lexical( 1, 1 );
  twobit_op3_803( 1, 4 ); /* ustring-set!:trusted */
  twobit_reg( 3 );
  twobit_op1_36(); /* char? */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_check( 3, 2, 31, 2267, compiled_block_1_2267 );
  twobit_lexical( 1, 1 );
  twobit_op3_803( 2, 3 ); /* ustring-set!:trusted */
  twobit_reg( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 2266, compiled_block_1_2266 );
  twobit_trap( 30, 1, 4, 61 );
  twobit_label( 2264, compiled_block_1_2264 );
  twobit_trap( 30, 2, 0, 60 );
  twobit_label( 2263, compiled_block_1_2263 );
  twobit_trap( 31, 1, 0, 60 );
  twobit_label( 2262, compiled_block_1_2262 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_label( 2267, compiled_block_1_2267 );
  twobit_trap( 31, 2, 3, 61 );
  twobit_label( 2265, compiled_block_1_2265 );
  twobit_trap( 31, 2, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_96( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 2271, compiled_block_1_2271 );
  twobit_invoke( 1 );
  twobit_label( 2271, compiled_block_1_2271 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_store( 2, 2 );
  twobit_imm_const( int_to_char(32) ); /* #\space */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_799( 3 ); /* make-ustring */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op2imm_131( fixnum(1), 214, compiled_temp_1_214 ); /* - */
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_215, 4, 2 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_setrtn( 2276, compiled_block_1_2276 );
  twobit_invoke( 2 );
  twobit_label( 2276, compiled_block_1_2276 );
  twobit_load( 0, 0 );
  twobit_stack( 3 );
  twobit_pop( 3 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_215( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 2273, compiled_block_1_2273 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 31, 2274, compiled_block_1_2274 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 31, 2274, compiled_block_1_2274 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 31, 2274, compiled_block_1_2274 );
  twobit_reg( 4 );
  twobit_op1_36(); /* char? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 31, 2274, compiled_block_1_2274 );
  twobit_lexical( 0, 1 );
  twobit_op3_803( 1, 4 ); /* ustring-set!:trusted */
  twobit_reg( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 2273, compiled_block_1_2273 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 2274, compiled_block_1_2274 );
  twobit_trap( 31, 1, 4, 61 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_97( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_lambda( compiled_start_1_209, 2, 2 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_210, 4, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_209( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string->list~1ayXVW~7668 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_210( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 2 );
  twobit_op2imm_131( fixnum(1), 211, compiled_temp_1_211 ); /* - */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_1_212, 3, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 4, 1 );
  twobit_load( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_212( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 213, compiled_temp_1_213, 2279, compiled_block_1_2279 ); /* internal:branchf-< */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 2279, compiled_block_1_2279 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2280, compiled_block_1_2280 );
  twobit_lexical( 1, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2280, compiled_block_1_2280 );
  twobit_lexical( 1, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2280, compiled_block_1_2280 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 2280, compiled_block_1_2280 );
  twobit_lexical( 1, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 2280, compiled_block_1_2280 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_98( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_global( 1 ); /*  string-concatenate/shared~1ayXVW~7670 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_99( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_202, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_202( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2286, compiled_block_1_2286 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 4, 0, 0, 2287, compiled_block_1_2287 );
  twobit_reg( 4 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_612( 203, compiled_temp_1_203, 2289, compiled_block_1_2289 ); /* internal:branchf-zero? */
  twobit_movereg( 31, 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 3 );
  twobit_label( 2289, compiled_block_1_2289 );
  twobit_reg( 3 );
  twobit_branchf( 2292, compiled_block_1_2292 );
  twobit_skip( 2291, compiled_block_1_2291 );
  twobit_label( 2292, compiled_block_1_2292 );
  twobit_movereg( 1, 3 );
  twobit_label( 2291, compiled_block_1_2291 );
  twobit_reg( 2 );
  twobit_op2_61( 4, 204, compiled_temp_1_204 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 31, 1 );
  twobit_reg( 4 );
  twobit_invoke( 3 );
  twobit_label( 2286, compiled_block_1_2286 );
  twobit_reg( 2 );
  twobit_op1_branchf_612( 205, compiled_temp_1_205, 2295, compiled_block_1_2295 ); /* internal:branchf-zero? */
  twobit_const( 1 );
  twobit_return();
  twobit_label( 2295, compiled_block_1_2295 );
  twobit_reg_op1_check_652(reg(3),2296,compiled_block_1_2296); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 4, 0, 0, 2287, compiled_block_1_2287 );
  twobit_reg( 4 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op2_branchf_623( 1, 206, compiled_temp_1_206, 2298, compiled_block_1_2298 ); /* internal:branchf-= */
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 2298, compiled_block_1_2298 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_movereg( 3, 1 );
  twobit_store( 1, 1 );
  twobit_imm_const( int_to_char(32) ); /* #\space */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_799( 4 ); /* make-ustring */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_207, 4, 2 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op2_84( 31 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_setrtn( 2304, compiled_block_1_2304 );
  twobit_invoke( 2 );
  twobit_label( 2304, compiled_block_1_2304 );
  twobit_load( 0, 0 );
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2296, compiled_block_1_2296 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_label( 2287, compiled_block_1_2287 );
  twobit_trap( 4, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_207( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2300, compiled_block_1_2300 ); /* internal:branchf-pair? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 3 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 4, 0, 0, 2301, compiled_block_1_2301 );
  twobit_reg( 4 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_movereg( 3, 31 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_movereg( 31, 5 );
  twobit_global( 1 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_setrtn( 2302, compiled_block_1_2302 );
  twobit_invoke( 5 );
  twobit_label( 2302, compiled_block_1_2302 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_load( 4, 2 );
  twobit_stack( 3 );
  twobit_op2_61( 4, 208, compiled_temp_1_208 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 2300, compiled_block_1_2300 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 2301, compiled_block_1_2301 );
  twobit_trap( 4, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_100( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_198, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_setrtn( 2310, compiled_block_1_2310 );
  twobit_invoke( 2 );
  twobit_label( 2310, compiled_block_1_2310 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_store( 2, 2 );
  twobit_imm_const( int_to_char(32) ); /* #\space */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_799( 3 ); /* make-ustring */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_199, 5, 2 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_setrtn( 2316, compiled_block_1_2316 );
  twobit_invoke( 2 );
  twobit_label( 2316, compiled_block_1_2316 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_198( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2307, compiled_block_1_2307 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 4, 0, 0, 2308, compiled_block_1_2308 );
  twobit_reg( 4 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_61( 4, 201, compiled_temp_1_201 ); /* + */
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 2307, compiled_block_1_2307 );
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 2308, compiled_block_1_2308 );
  twobit_trap( 4, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_199( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 2312, compiled_block_1_2312 ); /* internal:branchf-pair? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 3 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_movereg( 1, 2 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 4, 0, 0, 2313, compiled_block_1_2313 );
  twobit_reg( 4 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 3, 31 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_movereg( 31, 5 );
  twobit_global( 1 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_setrtn( 2314, compiled_block_1_2314 );
  twobit_invoke( 5 );
  twobit_label( 2314, compiled_block_1_2314 );
  twobit_load( 0, 0 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_op2_61( 4, 200, compiled_temp_1_200 ); /* + */
  twobit_setreg( 1 );
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 2312, compiled_block_1_2312 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 2313, compiled_block_1_2313 );
  twobit_trap( 4, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_101( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_lambda( compiled_start_1_190, 2, 1 );
  twobit_setreg( 4 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_191, 4, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_190( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lambda( compiled_start_1_192, 2, 2 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_193, 4, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_192( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_op1_branchf_610( 2318, compiled_block_1_2318 ); /* internal:branchf-null? */
  twobit_lexical( 0, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 2319, compiled_block_1_2319 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 2318, compiled_block_1_2318 );
  twobit_lexical( 0, 2 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 2321, compiled_block_1_2321 );
  twobit_lexical( 0, 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 2323, compiled_block_1_2323 );
  twobit_reg( 4 );
  twobit_op1_25(); /* exact? */
  twobit_branchf( 2325, compiled_block_1_2325 );
  twobit_lexical( 0, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 3, 0, 0, 2326, compiled_block_1_2326 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_67( 3, 196, compiled_temp_1_196 ); /* <= */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_branchf_622( 4, 197, compiled_temp_1_197, 2328, compiled_block_1_2328 ); /* internal:branchf-<= */
  twobit_reg( 3 );
  twobit_skip( 2322, compiled_block_1_2322 );
  twobit_label( 2328, compiled_block_1_2328 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 2322, compiled_block_1_2322 );
  twobit_label( 2325, compiled_block_1_2325 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 2322, compiled_block_1_2322 );
  twobit_label( 2323, compiled_block_1_2323 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2322, compiled_block_1_2322 );
  twobit_branchf( 2330, compiled_block_1_2330 );
  twobit_lexical( 0, 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 2330, compiled_block_1_2330 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 3 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 2321, compiled_block_1_2321 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 2326, compiled_block_1_2326 );
  twobit_trap( 3, 0, 0, 62 );
  twobit_label( 2319, compiled_block_1_2319 );
  twobit_trap( 4, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_193( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 2334, compiled_block_1_2334 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_194, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_setrtn( 2339, compiled_block_1_2339 );
  twobit_invoke( 2 );
  twobit_label( 2339, compiled_block_1_2339 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 4, 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /*  %finish-string-concatenate-reverse~1ayXVW~7674 */
  twobit_pop( 1 );
  twobit_invoke( 4 );
  twobit_label( 2334, compiled_block_1_2334 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /* error */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_194( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 2336, compiled_block_1_2336 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 4, 0, 0, 2337, compiled_block_1_2337 );
  twobit_reg( 4 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_61( 4, 195, compiled_temp_1_195 ); /* + */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 2336, compiled_block_1_2336 );
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 2337, compiled_block_1_2337 );
  twobit_trap( 4, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_191( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_610( 2344, compiled_block_1_2344 ); /* internal:branchf-null? */
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 2344, compiled_block_1_2344 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 2346, compiled_block_1_2346 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 2348, compiled_block_1_2348 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 2 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 2348, compiled_block_1_2348 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 4 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 2346, compiled_block_1_2346 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_102( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_lambda( compiled_start_1_178, 2, 1 );
  twobit_setreg( 4 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_179, 4, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_178( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lambda( compiled_start_1_180, 2, 2 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_181, 4, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_180( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_op1_branchf_610( 2353, compiled_block_1_2353 ); /* internal:branchf-null? */
  twobit_lexical( 0, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 2354, compiled_block_1_2354 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 2353, compiled_block_1_2353 );
  twobit_lexical( 0, 2 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 2356, compiled_block_1_2356 );
  twobit_lexical( 0, 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 2358, compiled_block_1_2358 );
  twobit_reg( 4 );
  twobit_op1_25(); /* exact? */
  twobit_branchf( 2360, compiled_block_1_2360 );
  twobit_lexical( 0, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 3, 0, 0, 2361, compiled_block_1_2361 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_67( 3, 188, compiled_temp_1_188 ); /* <= */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_branchf_622( 4, 189, compiled_temp_1_189, 2363, compiled_block_1_2363 ); /* internal:branchf-<= */
  twobit_reg( 3 );
  twobit_skip( 2357, compiled_block_1_2357 );
  twobit_label( 2363, compiled_block_1_2363 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 2357, compiled_block_1_2357 );
  twobit_label( 2360, compiled_block_1_2360 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 2357, compiled_block_1_2357 );
  twobit_label( 2358, compiled_block_1_2358 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2357, compiled_block_1_2357 );
  twobit_branchf( 2365, compiled_block_1_2365 );
  twobit_lexical( 0, 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 2365, compiled_block_1_2365 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 3 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 2356, compiled_block_1_2356 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 2361, compiled_block_1_2361 );
  twobit_trap( 3, 0, 0, 62 );
  twobit_label( 2354, compiled_block_1_2354 );
  twobit_trap( 4, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_181( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 2369, compiled_block_1_2369 ); /* internal:branchf-null? */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_182, 3, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_invoke( 3 );
  twobit_label( 2369, compiled_block_1_2369 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /* error */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_182( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 2371, compiled_block_1_2371 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 4, 0, 0, 2372, compiled_block_1_2372 );
  twobit_reg( 4 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_61( 4, 183, compiled_temp_1_183 ); /* + */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_branchf( 2374, compiled_block_1_2374 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2373, compiled_block_1_2373 );
  twobit_label( 2374, compiled_block_1_2374 );
  twobit_reg( 4 );
  twobit_op1_31( 184, compiled_temp_1_184 ); /* zero? */
  twobit_label( 2373, compiled_block_1_2373 );
  twobit_branchf( 2376, compiled_block_1_2376 );
  twobit_reg( 2 );
  twobit_skip( 2375, compiled_block_1_2375 );
  twobit_label( 2376, compiled_block_1_2376 );
  twobit_reg( 3 );
  twobit_label( 2375, compiled_block_1_2375 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 3 );
  twobit_label( 2371, compiled_block_1_2371 );
  twobit_reg( 1 );
  twobit_op1_branchf_612( 185, compiled_temp_1_185, 2379, compiled_block_1_2379 ); /* internal:branchf-zero? */
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  substring/shared~1ayXVW~7581 */
  twobit_invoke( 3 );
  twobit_label( 2379, compiled_block_1_2379 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_612( 186, compiled_temp_1_186, 2382, compiled_block_1_2382 ); /* internal:branchf-zero? */
  twobit_reg_op1_check_652(reg(2),2383,compiled_block_1_2383); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 4, 0, 0, 2372, compiled_block_1_2372 );
  twobit_reg( 4 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_68( 4, 187, compiled_temp_1_187 ); /* = */
  twobit_skip( 2381, compiled_block_1_2381 );
  twobit_label( 2382, compiled_block_1_2382 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2381, compiled_block_1_2381 );
  twobit_branchf( 2385, compiled_block_1_2385 );
  twobit_reg_op1_check_652(reg(2),2383,compiled_block_1_2383); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_return();
  twobit_label( 2385, compiled_block_1_2385 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_global( 2 ); /*  %finish-string-concatenate-reverse~1ayXVW~7674 */
  twobit_invoke( 4 );
  twobit_label( 2383, compiled_block_1_2383 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 2372, compiled_block_1_2372 );
  twobit_trap( 4, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_179( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_610( 2391, compiled_block_1_2391 ); /* internal:branchf-null? */
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 2391, compiled_block_1_2391 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 2393, compiled_block_1_2393 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 2395, compiled_block_1_2395 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 2 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 2395, compiled_block_1_2395 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 4 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 2393, compiled_block_1_2393 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_103( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 3 );
  twobit_movereg( 1, 2 );
  twobit_movereg( 4, 31 );
  twobit_reg( 4 );
  twobit_op2_61( 1, 175, compiled_temp_1_175 ); /* + */
  twobit_imm_const_setreg( int_to_char(32), 4 ); /*   */
  twobit_op2_799( 4 ); /* make-ustring */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_movereg( 31, 5 );
  twobit_global( 1 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_setrtn( 2399, compiled_block_1_2399 );
  twobit_invoke( 5 );
  twobit_label( 2399, compiled_block_1_2399 );
  twobit_load( 0, 0 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_176, 4, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_load( 2, 3 );
  twobit_reg( 4 );
  twobit_setrtn( 2405, compiled_block_1_2405 );
  twobit_invoke( 2 );
  twobit_label( 2405, compiled_block_1_2405 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_pop( 3 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_176( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 2401, compiled_block_1_2401 ); /* internal:branchf-pair? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 4, 0, 0, 2402, compiled_block_1_2402 );
  twobit_reg( 4 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_reg( 1 );
  twobit_op2_62( 2, 177, compiled_temp_1_177 ); /* - */
  twobit_setreg( 1 );
  twobit_store( 1, 3 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_load( 5, 1 );
  twobit_global( 1 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_setrtn( 2403, compiled_block_1_2403 );
  twobit_invoke( 5 );
  twobit_label( 2403, compiled_block_1_2403 );
  twobit_load( 0, 0 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 2401, compiled_block_1_2401 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 2402, compiled_block_1_2402 );
  twobit_trap( 4, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_104( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 4 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_store( 4, 5 );
  twobit_store( 5, 1 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /*  string-replace~1ayXVW~7675 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  check-substring-spec~1ayXVW~7580 */
  twobit_setrtn( 2406, compiled_block_1_2406 );
  twobit_invoke( 4 );
  twobit_label( 2406, compiled_block_1_2406 );
  twobit_load( 0, 0 );
  twobit_load( 2, 1 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_168, 4, 2 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 4, 3 );
  twobit_load( 3, 4 );
  twobit_load( 2, 5 );
  twobit_lambda( compiled_start_1_169, 6, 4 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 7 ); /* call-with-values */
  twobit_pop( 5 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_168( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-replace~1ayXVW~7675 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_169( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 2408, compiled_block_1_2408 );
  twobit_lexical( 0, 3 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_reg( 2 );
  twobit_op2_62( 1, 170, compiled_temp_1_170 ); /* - */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 31 );
  twobit_lexical( 0, 2 );
  twobit_op2_62( 31, 171, compiled_temp_1_171 ); /* - */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op2_62( 31, 172, compiled_temp_1_172 ); /* - */
  twobit_op2_61( 3, 173, compiled_temp_1_173 ); /* + */
  twobit_imm_const_setreg( int_to_char(32), 31 ); /*   */
  twobit_op2_799( 31 ); /* make-ustring */
  twobit_setreg( 31 );
  twobit_store( 31, 3 );
  twobit_movereg( 31, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 5 );
  twobit_global( 1 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_setrtn( 2409, compiled_block_1_2409 );
  twobit_invoke( 5 );
  twobit_label( 2409, compiled_block_1_2409 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 4, 2 );
  twobit_load( 1, 3 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_load( 5, 1 );
  twobit_global( 1 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_setrtn( 2410, compiled_block_1_2410 );
  twobit_invoke( 5 );
  twobit_label( 2410, compiled_block_1_2410 );
  twobit_load( 0, 0 );
  twobit_load( 4, 4 );
  twobit_lexical( 0, 4 );
  twobit_op2_61( 4, 174, compiled_temp_1_174 ); /* + */
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_load( 5, 5 );
  twobit_global( 1 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_setrtn( 2411, compiled_block_1_2411 );
  twobit_invoke( 5 );
  twobit_label( 2411, compiled_block_1_2411 );
  twobit_load( 0, 0 );
  twobit_stack( 3 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 2408, compiled_block_1_2408 );
  twobit_trap( 4, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_105( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_lambda( compiled_start_1_160, 2, 1 );
  twobit_setreg( 4 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_161, 4, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_160( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lambda( compiled_start_1_162, 2, 1 );
  twobit_setreg( 4 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_163, 4, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_162( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_164, 3, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_164( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 2, 3 );
  twobit_lexical( 0, 1 );
  twobit_op2_branchf_619( 1, 165, compiled_temp_1_165, 2414, compiled_block_1_2414 ); /* internal:branchf-< */
  twobit_movereg( 1, 4 );
  twobit_lexical( 2, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  string-index-right~1ayXVW~7651 */
  twobit_setrtn( 2415, compiled_block_1_2415 );
  twobit_invoke( 4 );
  twobit_label( 2415, compiled_block_1_2415 );
  twobit_load( 0, 0 );
  twobit_skip( 2413, compiled_block_1_2413 );
  twobit_label( 2414, compiled_block_1_2414 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2413, compiled_block_1_2413 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2417, compiled_block_1_2417 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 4, 166, compiled_temp_1_166 ); /* + */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_lexical( 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-skip-right~1ayXVW~7653 */
  twobit_setrtn( 2418, compiled_block_1_2418 );
  twobit_invoke( 4 );
  twobit_label( 2418, compiled_block_1_2418 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_reg( 4 );
  twobit_branchf( 2420, compiled_block_1_2420 );
  twobit_load( 3, 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 4, 167, compiled_temp_1_167 ); /* + */
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 2421, compiled_block_1_2421 );
  twobit_invoke( 3 );
  twobit_label( 2421, compiled_block_1_2421 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 2420, compiled_block_1_2420 );
  twobit_load( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_load( 3, 1 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 2423, compiled_block_1_2423 );
  twobit_invoke( 3 );
  twobit_label( 2423, compiled_block_1_2423 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2417, compiled_block_1_2417 );
  twobit_stack( 3 );
  twobit_pop( 4 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_163( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-tokenize~1ayXVW~7676 */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_161( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_610( 2428, compiled_block_1_2428 ); /* internal:branchf-null? */
  twobit_global( 1 ); /*  char-set:graphic~1ayXVW~6599 */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 2428, compiled_block_1_2428 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 2430, compiled_block_1_2430 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 3 ); /*  char-set?~1ayXVW~6491 */
  twobit_setrtn( 2431, compiled_block_1_2431 );
  twobit_invoke( 1 );
  twobit_label( 2431, compiled_block_1_2431 );
  twobit_load( 0, 0 );
  twobit_branchf( 2433, compiled_block_1_2433 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2433, compiled_block_1_2433 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* error */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2430, compiled_block_1_2430 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_106( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_lambda( compiled_start_1_145, 2, 3 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_146, 4, 2 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_145( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 3 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2438, compiled_block_1_2438 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_157, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_158, 4, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2438, compiled_block_1_2438 );
  twobit_lexical( 0, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 2444, compiled_block_1_2444 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_61( 4, 159, compiled_temp_1_159 ); /* + */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_movereg( 4, 3 );
  twobit_global( 6 ); /* values */
  twobit_invoke( 3 );
  twobit_label( 2444, compiled_block_1_2444 );
  twobit_trap( 4, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_157( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  xsubstring~1ayXVW~7677 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 2439, compiled_block_1_2439 );
  twobit_lexical( 1, 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_label( 2439, compiled_block_1_2439 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_158( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_check( 4, 0, 0, 2441, compiled_block_1_2441 );
  twobit_lexical( 1, 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* values */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_label( 2441, compiled_block_1_2441 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_146( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_62( 4, 147, compiled_temp_1_147 ); /* - */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_62( 2, 148, compiled_temp_1_148 ); /* - */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_branchf_612( 149, compiled_temp_1_149, 2447, compiled_block_1_2447 ); /* internal:branchf-zero? */
  twobit_const( 1 );
  twobit_return();
  twobit_label( 2447, compiled_block_1_2447 );
  twobit_reg( 31 );
  twobit_op1_branchf_612( 150, compiled_temp_1_150, 2449, compiled_block_1_2449 ); /* internal:branchf-zero? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_movereg( 3, 4 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 1, 2 );
  twobit_store( 2, 1 );
  twobit_global( 2 ); /*  xsubstring~1ayXVW~7677 */
  twobit_setreg( 2 );
  twobit_movereg( 4, 7 );
  twobit_movereg( 3, 6 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_load( 5, 1 );
  twobit_global( 4 ); /*  error~1ayXVW~7479 */
  twobit_pop( 1 );
  twobit_invoke( 7 );
  twobit_label( 2449, compiled_block_1_2449 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_branchf_623( 31, 151, compiled_temp_1_151, 2452, compiled_block_1_2452 ); /* internal:branchf-= */
  twobit_reg( 2 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_check( 2, 1, 0, 2453, compiled_block_1_2453 );
  twobit_lexical( 0, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_check( 2, 1, 0, 2453, compiled_block_1_2453 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_check( 2, 1, 0, 2453, compiled_block_1_2453 );
  twobit_reg( 2 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_check( 2, 1, 0, 2453, compiled_block_1_2453 );
  twobit_lexical( 0, 1 );
  twobit_op2_802( 2 ); /* ustring-ref:trusted */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_799( 3 ); /* make-ustring */
  twobit_return();
  twobit_label( 2452, compiled_block_1_2452 );
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 4 );
  twobit_store( 3, 5 );
  twobit_store( 4, 6 );
  twobit_store( 31, 1 );
  twobit_lexical( 0, 2 );
  twobit_op2_64( 31, 152, compiled_temp_1_152 ); /* / */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* floor */
  twobit_setrtn( 2454, compiled_block_1_2454 );
  twobit_invoke( 1 );
  twobit_label( 2454, compiled_block_1_2454 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 3, 1 );
  twobit_stack( 2 );
  twobit_op2_64( 3, 153, compiled_temp_1_153 ); /* / */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* floor */
  twobit_setrtn( 2455, compiled_block_1_2455 );
  twobit_invoke( 1 );
  twobit_label( 2455, compiled_block_1_2455 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_branchf_623( 4, 154, compiled_temp_1_154, 2457, compiled_block_1_2457 ); /* internal:branchf-= */
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 6 ); /* modulo */
  twobit_setrtn( 2458, compiled_block_1_2458 );
  twobit_invoke( 2 );
  twobit_label( 2458, compiled_block_1_2458 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_61( 4, 155, compiled_temp_1_155 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 2 );
  twobit_load( 2, 1 );
  twobit_global( 6 ); /* modulo */
  twobit_setrtn( 2459, compiled_block_1_2459 );
  twobit_invoke( 2 );
  twobit_label( 2459, compiled_block_1_2459 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_61( 4, 156, compiled_temp_1_156 ); /* + */
  twobit_setreg( 3 );
  twobit_load( 2, 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /* substring */
  twobit_pop( 6 );
  twobit_invoke( 3 );
  twobit_label( 2457, compiled_block_1_2457 );
  twobit_stack( 5 );
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_setreg( 2 );
  twobit_imm_const( int_to_char(32) ); /* #\space */
  twobit_setreg( 1 );
  twobit_stack( 6 );
  twobit_op2_799( 1 ); /* make-ustring */
  twobit_setreg( 1 );
  twobit_store( 1, 6 );
  twobit_movereg( 4, 7 );
  twobit_movereg( 3, 6 );
  twobit_movereg( 2, 5 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_global( 8 ); /*  %multispan-repcopy!~1ayXVW~7679 */
  twobit_setrtn( 2461, compiled_block_1_2461 );
  twobit_invoke( 7 );
  twobit_label( 2461, compiled_block_1_2461 );
  twobit_load( 0, 0 );
  twobit_stack( 6 );
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 2453, compiled_block_1_2453 );
  twobit_trap( 1, 2, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_107( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 4 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_129, 2, 4 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 5, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_130, 4, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_129( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 5 );
  twobit_store( 2, 4 );
  twobit_store( 3, 3 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_62( 4, 134, compiled_temp_1_134 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 2 );
  twobit_op2_61( 4, 135, compiled_temp_1_135 ); /* + */
  twobit_setreg( 31 );
  twobit_store( 31, 6 );
  twobit_movereg( 31, 4 );
  twobit_reg( 3 );
  twobit_op2_62( 2, 136, compiled_temp_1_136 ); /* - */
  twobit_setreg( 30 );
  twobit_store( 30, 2 );
  twobit_global( 1 ); /*  string-xcopy!~1ayXVW~7678 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  check-substring-spec~1ayXVW~7580 */
  twobit_setrtn( 2463, compiled_block_1_2463 );
  twobit_invoke( 4 );
  twobit_label( 2463, compiled_block_1_2463 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op1_31( 137, compiled_temp_1_137 ); /* zero? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2465, compiled_block_1_2465 );
  twobit_reg( 4 );
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 2465, compiled_block_1_2465 );
  twobit_stack( 2 );
  twobit_op1_branchf_612( 138, compiled_temp_1_138, 2467, compiled_block_1_2467 ); /* internal:branchf-zero? */
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_setreg( 3 );
  twobit_stack( 5 );
  twobit_setreg( 2 );
  twobit_store( 2, 5 );
  twobit_global( 1 ); /*  string-xcopy!~1ayXVW~7678 */
  twobit_setreg( 2 );
  twobit_movereg( 4, 9 );
  twobit_movereg( 3, 8 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 5 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 6 );
  twobit_load( 7, 5 );
  twobit_global( 4 ); /*  error~1ayXVW~7479 */
  twobit_pop( 6 );
  twobit_invoke( 9 );
  twobit_label( 2467, compiled_block_1_2467 );
  twobit_load( 4, 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_branchf_623( 4, 139, compiled_temp_1_139, 2470, compiled_block_1_2470 ); /* internal:branchf-= */
  twobit_stack( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_load( 4, 4 );
  twobit_reg( 2 );
  twobit_check( 4, 3, 0, 2471, compiled_block_1_2471 );
  twobit_lexical( 0, 3 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 4, 3, 0, 2471, compiled_block_1_2471 );
  twobit_lexical( 0, 3 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_load( 4, 4 );
  twobit_reg( 2 );
  twobit_check( 4, 3, 0, 2471, compiled_block_1_2471 );
  twobit_stack( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 4, 3, 0, 2471, compiled_block_1_2471 );
  twobit_lexical( 0, 3 );
  twobit_op2_802( 4 ); /* ustring-ref:trusted */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_load( 4, 6 );
  twobit_global( 5 ); /*  string-fill!~1ayXVW~7655 */
  twobit_pop( 6 );
  twobit_invoke( 4 );
  twobit_label( 2470, compiled_block_1_2470 );
  twobit_lexical( 0, 4 );
  twobit_op2_64( 4, 140, compiled_temp_1_140 ); /* / */
  twobit_setreg( 1 );
  twobit_global( 6 ); /* floor */
  twobit_setrtn( 2473, compiled_block_1_2473 );
  twobit_invoke( 1 );
  twobit_label( 2473, compiled_block_1_2473 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 3, 2 );
  twobit_stack( 5 );
  twobit_op2_64( 3, 141, compiled_temp_1_141 ); /* / */
  twobit_setreg( 1 );
  twobit_global( 6 ); /* floor */
  twobit_setrtn( 2474, compiled_block_1_2474 );
  twobit_invoke( 1 );
  twobit_label( 2474, compiled_block_1_2474 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_branchf_623( 4, 142, compiled_temp_1_142, 2476, compiled_block_1_2476 ); /* internal:branchf-= */
  twobit_lexical( 0, 4 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 7 ); /* modulo */
  twobit_setrtn( 2477, compiled_block_1_2477 );
  twobit_invoke( 2 );
  twobit_label( 2477, compiled_block_1_2477 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_61( 4, 143, compiled_temp_1_143 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 5 );
  twobit_load( 2, 2 );
  twobit_global( 7 ); /* modulo */
  twobit_setrtn( 2478, compiled_block_1_2478 );
  twobit_invoke( 2 );
  twobit_label( 2478, compiled_block_1_2478 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 4, 3 );
  twobit_load( 3, 2 );
  twobit_stack( 4 );
  twobit_op2_61( 3, 144, compiled_temp_1_144 ); /* + */
  twobit_setreg( 3 );
  twobit_movereg( 3, 5 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_global( 8 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_pop( 6 );
  twobit_invoke( 5 );
  twobit_label( 2476, compiled_block_1_2476 );
  twobit_stack( 5 );
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_setreg( 2 );
  twobit_movereg( 2, 7 );
  twobit_movereg( 3, 6 );
  twobit_movereg( 4, 5 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_global( 9 ); /*  %multispan-repcopy!~1ayXVW~7679 */
  twobit_pop( 6 );
  twobit_invoke( 7 );
  twobit_label( 2471, compiled_block_1_2471 );
  twobit_trap( 3, 4, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_130( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2482, compiled_block_1_2482 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_131, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_132, 4, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2482, compiled_block_1_2482 );
  twobit_lexical( 0, 3 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 2488, compiled_block_1_2488 );
  twobit_lexical( 0, 3 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op2_61( 4, 133, compiled_temp_1_133 ); /* + */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_movereg( 4, 3 );
  twobit_global( 6 ); /* values */
  twobit_invoke( 3 );
  twobit_label( 2488, compiled_block_1_2488 );
  twobit_trap( 4, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_131( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  string-xcopy!~1ayXVW~7678 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 2483, compiled_block_1_2483 );
  twobit_lexical( 1, 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  string-parse-final-start+end~1ayXVW~7578 */
  twobit_invoke( 3 );
  twobit_label( 2483, compiled_block_1_2483 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_132( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_check( 4, 0, 0, 2485, compiled_block_1_2485 );
  twobit_lexical( 1, 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* values */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_label( 2485, compiled_block_1_2485 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_108( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 7 );
  twobit_save( 10 );
  twobit_store( 0, 0 );
  twobit_store( 1, 5 );
  twobit_store( 2, 6 );
  twobit_store( 3, 7 );
  twobit_store( 4, 2 );
  twobit_store( 5, 3 );
  twobit_store( 6, 1 );
  twobit_store( 7, 4 );
  twobit_movereg( 4, 1 );
  twobit_reg( 7 );
  twobit_op2_62( 6, 115, compiled_temp_1_115 ); /* - */
  twobit_setreg( 31 );
  twobit_store( 31, 9 );
  twobit_movereg( 31, 2 );
  twobit_global( 1 ); /* modulo */
  twobit_setrtn( 2491, compiled_block_1_2491 );
  twobit_invoke( 2 );
  twobit_label( 2491, compiled_block_1_2491 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_61( 4, 116, compiled_temp_1_116 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_load( 3, 2 );
  twobit_stack( 3 );
  twobit_op2_62( 3, 117, compiled_temp_1_117 ); /* - */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_stack( 4 );
  twobit_setreg( 2 );
  twobit_movereg( 2, 5 );
  twobit_load( 1, 5 );
  twobit_load( 2, 6 );
  twobit_load( 3, 7 );
  twobit_global( 2 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_setrtn( 2492, compiled_block_1_2492 );
  twobit_invoke( 5 );
  twobit_label( 2492, compiled_block_1_2492 );
  twobit_load( 0, 0 );
  twobit_load( 4, 8 );
  twobit_stack( 4 );
  twobit_op2_62( 4, 118, compiled_temp_1_118 ); /* - */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_62( 4, 119, compiled_temp_1_119 ); /* - */
  twobit_load( 2, 9 );
  twobit_op2_65( 2, 120, compiled_temp_1_120 ); /* quotient */
  twobit_setreg( 3 );
  twobit_store( 3, 8 );
  twobit_stack( 6 );
  twobit_op2_61( 4, 121, compiled_temp_1_121 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 2 );
  twobit_store( 2, 10 );
  twobit_load( 8, 3 );
  twobit_load( 7, 6 );
  twobit_load( 6, 5 );
  twobit_load( 5, 7 );
  twobit_load( 4, 1 );
  twobit_load( 3, 4 );
  twobit_load( 1, 9 );
  twobit_lambda( compiled_start_1_122, 5, 8 );
  twobit_setreg( 4 );
  twobit_load( 2, 8 );
  twobit_load( 1, 2 );
  twobit_stack( 10 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_stack( 10 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 10 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_122( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_612( 123, compiled_temp_1_123, 2494, compiled_block_1_2494 ); /* internal:branchf-zero? */
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 7 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_62( 4, 124, compiled_temp_1_124 ); /* - */
  twobit_setreg( 4 );
  twobit_lexical( 0, 8 );
  twobit_op2_62( 4, 125, compiled_temp_1_125 ); /* - */
  twobit_setreg( 4 );
  twobit_lexical( 0, 4 );
  twobit_op2_61( 4, 126, compiled_temp_1_126 ); /* + */
  twobit_setreg( 4 );
  twobit_movereg( 4, 5 );
  twobit_lexical( 0, 6 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_invoke( 5 );
  twobit_label( 2494, compiled_block_1_2494 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 6 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 5 );
  twobit_global( 1 ); /*  %string-copy!~1ayXVW~7657 */
  twobit_setrtn( 2496, compiled_block_1_2496 );
  twobit_invoke( 5 );
  twobit_label( 2496, compiled_block_1_2496 );
  twobit_load( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_61( 4, 127, compiled_temp_1_127 ); /* + */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op2imm_131( fixnum(1), 128, compiled_temp_1_128 ); /* - */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_109( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_lambda( compiled_start_1_110, 2, 1 );
  twobit_setreg( 4 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_111, 4, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_110( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_112, 2, 1 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_113, 4, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_112( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_610( 2500, compiled_block_1_2500 ); /* internal:branchf-null? */
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 2500, compiled_block_1_2500 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 2502, compiled_block_1_2502 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 2502, compiled_block_1_2502 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_113( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 2507, compiled_block_1_2507 ); /* internal:branchf-null? */
  twobit_lexical( 1, 1 );
  twobit_op1_branchf_611( 2509, compiled_block_1_2509 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_const( 1 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 4, 2511, compiled_block_1_2511 ); /* internal:branchf-eq? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2510, compiled_block_1_2510 );
  twobit_label( 2511, compiled_block_1_2511 );
  twobit_const( 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_56( 4 ); /* eq? */
  twobit_label( 2510, compiled_block_1_2510 );
  twobit_branchf( 2513, compiled_block_1_2513 );
  twobit_lexical( 1, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 1, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_setrtn( 2514, compiled_block_1_2514 );
  twobit_branch( 2504, compiled_block_1_2504 );
  twobit_label( 2514, compiled_block_1_2514 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_skip( 2512, compiled_block_1_2512 );
  twobit_label( 2513, compiled_block_1_2513 );
  twobit_const( 3 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 4, 2516, compiled_block_1_2516 ); /* internal:branchf-eq? */
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_setrtn( 2517, compiled_block_1_2517 );
  twobit_branch( 2504, compiled_block_1_2504 );
  twobit_label( 2517, compiled_block_1_2517 );
  twobit_load( 0, 0 );
  twobit_skip( 2512, compiled_block_1_2512 );
  twobit_label( 2516, compiled_block_1_2516 );
  twobit_const( 4 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 4, 2519, compiled_block_1_2519 ); /* internal:branchf-eq? */
  twobit_lexical( 1, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 1, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_setrtn( 2520, compiled_block_1_2520 );
  twobit_branch( 2504, compiled_block_1_2504 );
  twobit_label( 2520, compiled_block_1_2520 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_skip( 2512, compiled_block_1_2512 );
  twobit_label( 2519, compiled_block_1_2519 );
  twobit_movereg( 1, 2 );
  twobit_global( 5 ); /*  string-join~1ayXVW~7680 */
  twobit_setreg( 3 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /*  error~1ayXVW~7479 */
  twobit_setrtn( 2521, compiled_block_1_2521 );
  twobit_invoke( 3 );
  twobit_label( 2521, compiled_block_1_2521 );
  twobit_load( 0, 0 );
  twobit_label( 2512, compiled_block_1_2512 );
  twobit_setreg( 1 );
  twobit_global( 8 ); /*  string-concatenate~1ayXVW~7671 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 2509, compiled_block_1_2509 );
  twobit_lexical( 1, 1 );
  twobit_op1_branchf_610( 2524, compiled_block_1_2524 ); /* internal:branchf-null? */
  twobit_const( 1 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 4, 2526, compiled_block_1_2526 ); /* internal:branchf-eq? */
  twobit_global( 5 ); /*  string-join~1ayXVW~7680 */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /*  error~1ayXVW~7479 */
  twobit_invoke( 2 );
  twobit_label( 2526, compiled_block_1_2526 );
  twobit_const( 10 );
  twobit_return();
  twobit_label( 2524, compiled_block_1_2524 );
  twobit_global( 5 ); /*  string-join~1ayXVW~7680 */
  twobit_setreg( 3 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 2 );
  twobit_global( 7 ); /*  error~1ayXVW~7479 */
  twobit_invoke( 3 );
  twobit_label( 2507, compiled_block_1_2507 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 2504, compiled_block_1_2504 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 14 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_114, 16, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_114( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2531, compiled_block_1_2531 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 2532, compiled_block_1_2532 );
  twobit_invoke( 1 );
  twobit_label( 2532, compiled_block_1_2532 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2531, compiled_block_1_2531 );
  twobit_lexical( 0, 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_111( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_610( 2536, compiled_block_1_2536 ); /* internal:branchf-null? */
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 2536, compiled_block_1_2536 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 2538, compiled_block_1_2538 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 2540, compiled_block_1_2540 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 2 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 2540, compiled_block_1_2540 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 4 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 2538, compiled_block_1_2538 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_ba5afdc1ba19a6fb678a73fc5a554b29_0(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_1_0(CONT_ACTUALS));
}
static RTYPE compiled_block_2_1004( CONT_PARAMS );
static RTYPE compiled_block_2_1003( CONT_PARAMS );
static RTYPE compiled_start_2_0( CONT_PARAMS );
static RTYPE compiled_start_2_3( CONT_PARAMS );
static RTYPE compiled_start_2_2( CONT_PARAMS );
static RTYPE compiled_start_2_1( CONT_PARAMS );

static RTYPE compiled_start_2_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_2_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_2_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1003, compiled_block_2_1003 );
  twobit_invoke( 8 );
  twobit_label( 1003, compiled_block_2_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1004, compiled_block_2_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_2_1004 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_ba5afdc1ba19a6fb678a73fc5a554b29_1(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_2_0(CONT_ACTUALS));
}
codeptr_t CDECL twobit_load_table[] = { 
  twobit_thunk_ba5afdc1ba19a6fb678a73fc5a554b29_0,
  twobit_thunk_ba5afdc1ba19a6fb678a73fc5a554b29_1,
  0  /* The table may be empty; some compilers complain */
};

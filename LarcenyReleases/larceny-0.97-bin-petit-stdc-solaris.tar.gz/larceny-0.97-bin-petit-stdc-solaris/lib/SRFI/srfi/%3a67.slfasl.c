/* Generated from /proj/will/pnkfelix/larcenytest/larceny-petit-Nightly-2009-08-19/larceny_src/lib/SRFI/srfi/%3a67.slfasl */
#include "petit-instr.h"

static RTYPE compiled_block_1_4079( CONT_PARAMS );
static RTYPE compiled_block_1_4078( CONT_PARAMS );
static RTYPE compiled_start_1_0( CONT_PARAMS );
static RTYPE compiled_start_1_3( CONT_PARAMS );
static RTYPE compiled_block_1_4075( CONT_PARAMS );
static RTYPE compiled_block_1_4070( CONT_PARAMS );
static RTYPE compiled_temp_1_56( CONT_PARAMS );
static RTYPE compiled_block_1_4073( CONT_PARAMS );
static RTYPE compiled_temp_1_55( CONT_PARAMS );
static RTYPE compiled_block_1_4071( CONT_PARAMS );
static RTYPE compiled_block_1_4069( CONT_PARAMS );
static RTYPE compiled_block_1_4027( CONT_PARAMS );
static RTYPE compiled_start_1_53( CONT_PARAMS );
static RTYPE compiled_block_1_4054( CONT_PARAMS );
static RTYPE compiled_block_1_4067( CONT_PARAMS );
static RTYPE compiled_block_1_4068( CONT_PARAMS );
static RTYPE compiled_temp_1_71( CONT_PARAMS );
static RTYPE compiled_block_1_4066( CONT_PARAMS );
static RTYPE compiled_block_1_4042( CONT_PARAMS );
static RTYPE compiled_block_1_4043( CONT_PARAMS );
static RTYPE compiled_block_1_4057( CONT_PARAMS );
static RTYPE compiled_block_1_4065( CONT_PARAMS );
static RTYPE compiled_block_1_4064( CONT_PARAMS );
static RTYPE compiled_block_1_4055( CONT_PARAMS );
static RTYPE compiled_temp_1_69( CONT_PARAMS );
static RTYPE compiled_temp_1_68( CONT_PARAMS );
static RTYPE compiled_temp_1_67( CONT_PARAMS );
static RTYPE compiled_temp_1_66( CONT_PARAMS );
static RTYPE compiled_temp_1_65( CONT_PARAMS );
static RTYPE compiled_block_1_4051( CONT_PARAMS );
static RTYPE compiled_block_1_4053( CONT_PARAMS );
static RTYPE compiled_block_1_4052( CONT_PARAMS );
static RTYPE compiled_temp_1_64( CONT_PARAMS );
static RTYPE compiled_temp_1_63( CONT_PARAMS );
static RTYPE compiled_block_1_4048( CONT_PARAMS );
static RTYPE compiled_block_1_4050( CONT_PARAMS );
static RTYPE compiled_block_1_4049( CONT_PARAMS );
static RTYPE compiled_temp_1_62( CONT_PARAMS );
static RTYPE compiled_temp_1_61( CONT_PARAMS );
static RTYPE compiled_block_1_4047( CONT_PARAMS );
static RTYPE compiled_block_1_4046( CONT_PARAMS );
static RTYPE compiled_block_1_4045( CONT_PARAMS );
static RTYPE compiled_block_1_4044( CONT_PARAMS );
static RTYPE compiled_block_1_4039( CONT_PARAMS );
static RTYPE compiled_block_1_4041( CONT_PARAMS );
static RTYPE compiled_block_1_4040( CONT_PARAMS );
static RTYPE compiled_temp_1_60( CONT_PARAMS );
static RTYPE compiled_temp_1_59( CONT_PARAMS );
static RTYPE compiled_block_1_4036( CONT_PARAMS );
static RTYPE compiled_block_1_4038( CONT_PARAMS );
static RTYPE compiled_block_1_4037( CONT_PARAMS );
static RTYPE compiled_temp_1_58( CONT_PARAMS );
static RTYPE compiled_block_1_4033( CONT_PARAMS );
static RTYPE compiled_block_1_4035( CONT_PARAMS );
static RTYPE compiled_block_1_4034( CONT_PARAMS );
static RTYPE compiled_temp_1_57( CONT_PARAMS );
static RTYPE compiled_block_1_4032( CONT_PARAMS );
static RTYPE compiled_block_1_4031( CONT_PARAMS );
static RTYPE compiled_block_1_4030( CONT_PARAMS );
static RTYPE compiled_block_1_4029( CONT_PARAMS );
static RTYPE compiled_start_1_54( CONT_PARAMS );
static RTYPE compiled_block_1_4063( CONT_PARAMS );
static RTYPE compiled_block_1_4061( CONT_PARAMS );
static RTYPE compiled_block_1_4059( CONT_PARAMS );
static RTYPE compiled_start_1_70( CONT_PARAMS );
static RTYPE compiled_block_1_3960( CONT_PARAMS );
static RTYPE compiled_block_1_4025( CONT_PARAMS );
static RTYPE compiled_block_1_4020( CONT_PARAMS );
static RTYPE compiled_block_1_4022( CONT_PARAMS );
static RTYPE compiled_block_1_4018( CONT_PARAMS );
static RTYPE compiled_block_1_4017( CONT_PARAMS );
static RTYPE compiled_block_1_4016( CONT_PARAMS );
static RTYPE compiled_block_1_4011( CONT_PARAMS );
static RTYPE compiled_block_1_4013( CONT_PARAMS );
static RTYPE compiled_block_1_4009( CONT_PARAMS );
static RTYPE compiled_block_1_4008( CONT_PARAMS );
static RTYPE compiled_block_1_4007( CONT_PARAMS );
static RTYPE compiled_block_1_4002( CONT_PARAMS );
static RTYPE compiled_block_1_4004( CONT_PARAMS );
static RTYPE compiled_block_1_4000( CONT_PARAMS );
static RTYPE compiled_block_1_3999( CONT_PARAMS );
static RTYPE compiled_block_1_3998( CONT_PARAMS );
static RTYPE compiled_block_1_3993( CONT_PARAMS );
static RTYPE compiled_block_1_3995( CONT_PARAMS );
static RTYPE compiled_block_1_3991( CONT_PARAMS );
static RTYPE compiled_block_1_3990( CONT_PARAMS );
static RTYPE compiled_block_1_3989( CONT_PARAMS );
static RTYPE compiled_block_1_3984( CONT_PARAMS );
static RTYPE compiled_block_1_3986( CONT_PARAMS );
static RTYPE compiled_block_1_3982( CONT_PARAMS );
static RTYPE compiled_block_1_3981( CONT_PARAMS );
static RTYPE compiled_block_1_3980( CONT_PARAMS );
static RTYPE compiled_block_1_3975( CONT_PARAMS );
static RTYPE compiled_block_1_3977( CONT_PARAMS );
static RTYPE compiled_block_1_3973( CONT_PARAMS );
static RTYPE compiled_block_1_3972( CONT_PARAMS );
static RTYPE compiled_block_1_3971( CONT_PARAMS );
static RTYPE compiled_block_1_3957( CONT_PARAMS );
static RTYPE compiled_block_1_3959( CONT_PARAMS );
static RTYPE compiled_block_1_3968( CONT_PARAMS );
static RTYPE compiled_block_1_3965( CONT_PARAMS );
static RTYPE compiled_block_1_3963( CONT_PARAMS );
static RTYPE compiled_block_1_3961( CONT_PARAMS );
static RTYPE compiled_block_1_3955( CONT_PARAMS );
static RTYPE compiled_block_1_3954( CONT_PARAMS );
static RTYPE compiled_block_1_3953( CONT_PARAMS );
static RTYPE compiled_block_1_3949( CONT_PARAMS );
static RTYPE compiled_block_1_3951( CONT_PARAMS );
static RTYPE compiled_block_1_3947( CONT_PARAMS );
static RTYPE compiled_block_1_3946( CONT_PARAMS );
static RTYPE compiled_start_1_52( CONT_PARAMS );
static RTYPE compiled_block_1_3942( CONT_PARAMS );
static RTYPE compiled_temp_1_78( CONT_PARAMS );
static RTYPE compiled_block_1_3938( CONT_PARAMS );
static RTYPE compiled_temp_1_76( CONT_PARAMS );
static RTYPE compiled_block_1_3934( CONT_PARAMS );
static RTYPE compiled_temp_1_74( CONT_PARAMS );
static RTYPE compiled_block_1_3907( CONT_PARAMS );
static RTYPE compiled_temp_1_72( CONT_PARAMS );
static RTYPE compiled_block_1_3905( CONT_PARAMS );
static RTYPE compiled_start_1_51( CONT_PARAMS );
static RTYPE compiled_start_1_79( CONT_PARAMS );
static RTYPE compiled_start_1_77( CONT_PARAMS );
static RTYPE compiled_start_1_75( CONT_PARAMS );
static RTYPE compiled_block_1_3914( CONT_PARAMS );
static RTYPE compiled_block_1_3915( CONT_PARAMS );
static RTYPE compiled_temp_1_81( CONT_PARAMS );
static RTYPE compiled_block_1_3912( CONT_PARAMS );
static RTYPE compiled_block_1_3913( CONT_PARAMS );
static RTYPE compiled_block_1_3910( CONT_PARAMS );
static RTYPE compiled_block_1_3911( CONT_PARAMS );
static RTYPE compiled_temp_1_80( CONT_PARAMS );
static RTYPE compiled_block_1_3909( CONT_PARAMS );
static RTYPE compiled_block_1_3908( CONT_PARAMS );
static RTYPE compiled_start_1_73( CONT_PARAMS );
static RTYPE compiled_block_1_3929( CONT_PARAMS );
static RTYPE compiled_block_1_3926( CONT_PARAMS );
static RTYPE compiled_temp_1_83( CONT_PARAMS );
static RTYPE compiled_block_1_3924( CONT_PARAMS );
static RTYPE compiled_block_1_3922( CONT_PARAMS );
static RTYPE compiled_block_1_3921( CONT_PARAMS );
static RTYPE compiled_block_1_3920( CONT_PARAMS );
static RTYPE compiled_block_1_3918( CONT_PARAMS );
static RTYPE compiled_block_1_3916( CONT_PARAMS );
static RTYPE compiled_start_1_82( CONT_PARAMS );
static RTYPE compiled_block_1_3901( CONT_PARAMS );
static RTYPE compiled_temp_1_90( CONT_PARAMS );
static RTYPE compiled_block_1_3897( CONT_PARAMS );
static RTYPE compiled_temp_1_88( CONT_PARAMS );
static RTYPE compiled_block_1_3893( CONT_PARAMS );
static RTYPE compiled_temp_1_86( CONT_PARAMS );
static RTYPE compiled_block_1_3865( CONT_PARAMS );
static RTYPE compiled_temp_1_84( CONT_PARAMS );
static RTYPE compiled_block_1_3863( CONT_PARAMS );
static RTYPE compiled_start_1_50( CONT_PARAMS );
static RTYPE compiled_start_1_91( CONT_PARAMS );
static RTYPE compiled_start_1_89( CONT_PARAMS );
static RTYPE compiled_start_1_87( CONT_PARAMS );
static RTYPE compiled_block_1_3889( CONT_PARAMS );
static RTYPE compiled_block_1_3872( CONT_PARAMS );
static RTYPE compiled_block_1_3870( CONT_PARAMS );
static RTYPE compiled_block_1_3868( CONT_PARAMS );
static RTYPE compiled_block_1_3867( CONT_PARAMS );
static RTYPE compiled_block_1_3866( CONT_PARAMS );
static RTYPE compiled_start_1_85( CONT_PARAMS );
static RTYPE compiled_block_1_3885( CONT_PARAMS );
static RTYPE compiled_block_1_3882( CONT_PARAMS );
static RTYPE compiled_temp_1_93( CONT_PARAMS );
static RTYPE compiled_block_1_3880( CONT_PARAMS );
static RTYPE compiled_block_1_3878( CONT_PARAMS );
static RTYPE compiled_block_1_3877( CONT_PARAMS );
static RTYPE compiled_block_1_3876( CONT_PARAMS );
static RTYPE compiled_block_1_3875( CONT_PARAMS );
static RTYPE compiled_block_1_3873( CONT_PARAMS );
static RTYPE compiled_start_1_92( CONT_PARAMS );
static RTYPE compiled_block_1_3859( CONT_PARAMS );
static RTYPE compiled_temp_1_100( CONT_PARAMS );
static RTYPE compiled_block_1_3855( CONT_PARAMS );
static RTYPE compiled_temp_1_98( CONT_PARAMS );
static RTYPE compiled_block_1_3851( CONT_PARAMS );
static RTYPE compiled_temp_1_96( CONT_PARAMS );
static RTYPE compiled_block_1_3828( CONT_PARAMS );
static RTYPE compiled_temp_1_94( CONT_PARAMS );
static RTYPE compiled_block_1_3826( CONT_PARAMS );
static RTYPE compiled_start_1_49( CONT_PARAMS );
static RTYPE compiled_start_1_101( CONT_PARAMS );
static RTYPE compiled_start_1_99( CONT_PARAMS );
static RTYPE compiled_start_1_97( CONT_PARAMS );
static RTYPE compiled_block_1_3847( CONT_PARAMS );
static RTYPE compiled_block_1_3844( CONT_PARAMS );
static RTYPE compiled_block_1_3842( CONT_PARAMS );
static RTYPE compiled_block_1_3840( CONT_PARAMS );
static RTYPE compiled_start_1_95( CONT_PARAMS );
static RTYPE compiled_block_1_3838( CONT_PARAMS );
static RTYPE compiled_block_1_3837( CONT_PARAMS );
static RTYPE compiled_block_1_3836( CONT_PARAMS );
static RTYPE compiled_block_1_3832( CONT_PARAMS );
static RTYPE compiled_block_1_3834( CONT_PARAMS );
static RTYPE compiled_block_1_3830( CONT_PARAMS );
static RTYPE compiled_block_1_3829( CONT_PARAMS );
static RTYPE compiled_start_1_102( CONT_PARAMS );
static RTYPE compiled_block_1_3822( CONT_PARAMS );
static RTYPE compiled_temp_1_109( CONT_PARAMS );
static RTYPE compiled_block_1_3818( CONT_PARAMS );
static RTYPE compiled_temp_1_107( CONT_PARAMS );
static RTYPE compiled_block_1_3814( CONT_PARAMS );
static RTYPE compiled_temp_1_105( CONT_PARAMS );
static RTYPE compiled_block_1_3790( CONT_PARAMS );
static RTYPE compiled_temp_1_103( CONT_PARAMS );
static RTYPE compiled_block_1_3788( CONT_PARAMS );
static RTYPE compiled_start_1_48( CONT_PARAMS );
static RTYPE compiled_start_1_110( CONT_PARAMS );
static RTYPE compiled_start_1_108( CONT_PARAMS );
static RTYPE compiled_start_1_106( CONT_PARAMS );
static RTYPE compiled_block_1_3810( CONT_PARAMS );
static RTYPE compiled_block_1_3805( CONT_PARAMS );
static RTYPE compiled_block_1_3807( CONT_PARAMS );
static RTYPE compiled_block_1_3806( CONT_PARAMS );
static RTYPE compiled_block_1_3803( CONT_PARAMS );
static RTYPE compiled_block_1_3801( CONT_PARAMS );
static RTYPE compiled_block_1_3800( CONT_PARAMS );
static RTYPE compiled_block_1_3799( CONT_PARAMS );
static RTYPE compiled_block_1_3798( CONT_PARAMS );
static RTYPE compiled_block_1_3794( CONT_PARAMS );
static RTYPE compiled_block_1_3796( CONT_PARAMS );
static RTYPE compiled_block_1_3792( CONT_PARAMS );
static RTYPE compiled_block_1_3791( CONT_PARAMS );
static RTYPE compiled_start_1_104( CONT_PARAMS );
static RTYPE compiled_block_1_3784( CONT_PARAMS );
static RTYPE compiled_temp_1_115( CONT_PARAMS );
static RTYPE compiled_block_1_3759( CONT_PARAMS );
static RTYPE compiled_temp_1_113( CONT_PARAMS );
static RTYPE compiled_block_1_3745( CONT_PARAMS );
static RTYPE compiled_temp_1_111( CONT_PARAMS );
static RTYPE compiled_block_1_3743( CONT_PARAMS );
static RTYPE compiled_start_1_47( CONT_PARAMS );
static RTYPE compiled_start_1_116( CONT_PARAMS );
static RTYPE compiled_block_1_3780( CONT_PARAMS );
static RTYPE compiled_block_1_3767( CONT_PARAMS );
static RTYPE compiled_block_1_3769( CONT_PARAMS );
static RTYPE compiled_block_1_3777( CONT_PARAMS );
static RTYPE compiled_block_1_3774( CONT_PARAMS );
static RTYPE compiled_block_1_3772( CONT_PARAMS );
static RTYPE compiled_block_1_3770( CONT_PARAMS );
static RTYPE compiled_block_1_3765( CONT_PARAMS );
static RTYPE compiled_block_1_3761( CONT_PARAMS );
static RTYPE compiled_block_1_3763( CONT_PARAMS );
static RTYPE compiled_start_1_114( CONT_PARAMS );
static RTYPE compiled_block_1_3746( CONT_PARAMS );
static RTYPE compiled_block_1_3747( CONT_PARAMS );
static RTYPE compiled_block_1_3755( CONT_PARAMS );
static RTYPE compiled_block_1_3752( CONT_PARAMS );
static RTYPE compiled_block_1_3750( CONT_PARAMS );
static RTYPE compiled_block_1_3748( CONT_PARAMS );
static RTYPE compiled_start_1_112( CONT_PARAMS );
static RTYPE compiled_start_1_46( CONT_PARAMS );
static RTYPE compiled_block_1_3741( CONT_PARAMS );
static RTYPE compiled_block_1_3740( CONT_PARAMS );
static RTYPE compiled_start_1_117( CONT_PARAMS );
static RTYPE compiled_start_1_45( CONT_PARAMS );
static RTYPE compiled_block_1_3737( CONT_PARAMS );
static RTYPE compiled_block_1_3738( CONT_PARAMS );
static RTYPE compiled_start_1_118( CONT_PARAMS );
static RTYPE compiled_block_1_3732( CONT_PARAMS );
static RTYPE compiled_block_1_3735( CONT_PARAMS );
static RTYPE compiled_block_1_3734( CONT_PARAMS );
static RTYPE compiled_block_1_3733( CONT_PARAMS );
static RTYPE compiled_block_1_3728( CONT_PARAMS );
static RTYPE compiled_block_1_3731( CONT_PARAMS );
static RTYPE compiled_block_1_3730( CONT_PARAMS );
static RTYPE compiled_block_1_3729( CONT_PARAMS );
static RTYPE compiled_start_1_44( CONT_PARAMS );
static RTYPE compiled_block_1_3726( CONT_PARAMS );
static RTYPE compiled_block_1_3723( CONT_PARAMS );
static RTYPE compiled_block_1_3721( CONT_PARAMS );
static RTYPE compiled_block_1_3719( CONT_PARAMS );
static RTYPE compiled_block_1_3717( CONT_PARAMS );
static RTYPE compiled_block_1_3714( CONT_PARAMS );
static RTYPE compiled_block_1_3715( CONT_PARAMS );
static RTYPE compiled_block_1_3710( CONT_PARAMS );
static RTYPE compiled_block_1_3713( CONT_PARAMS );
static RTYPE compiled_block_1_3712( CONT_PARAMS );
static RTYPE compiled_block_1_3711( CONT_PARAMS );
static RTYPE compiled_block_1_3706( CONT_PARAMS );
static RTYPE compiled_block_1_3709( CONT_PARAMS );
static RTYPE compiled_block_1_3708( CONT_PARAMS );
static RTYPE compiled_block_1_3707( CONT_PARAMS );
static RTYPE compiled_start_1_43( CONT_PARAMS );
static RTYPE compiled_block_1_3704( CONT_PARAMS );
static RTYPE compiled_block_1_3691( CONT_PARAMS );
static RTYPE compiled_block_1_3702( CONT_PARAMS );
static RTYPE compiled_block_1_3695( CONT_PARAMS );
static RTYPE compiled_block_1_3701( CONT_PARAMS );
static RTYPE compiled_block_1_3699( CONT_PARAMS );
static RTYPE compiled_block_1_3698( CONT_PARAMS );
static RTYPE compiled_block_1_3696( CONT_PARAMS );
static RTYPE compiled_block_1_3693( CONT_PARAMS );
static RTYPE compiled_start_1_42( CONT_PARAMS );
static RTYPE compiled_block_1_3688( CONT_PARAMS );
static RTYPE compiled_block_1_3674( CONT_PARAMS );
static RTYPE compiled_block_1_3686( CONT_PARAMS );
static RTYPE compiled_block_1_3679( CONT_PARAMS );
static RTYPE compiled_block_1_3685( CONT_PARAMS );
static RTYPE compiled_block_1_3683( CONT_PARAMS );
static RTYPE compiled_block_1_3682( CONT_PARAMS );
static RTYPE compiled_block_1_3680( CONT_PARAMS );
static RTYPE compiled_block_1_3677( CONT_PARAMS );
static RTYPE compiled_block_1_3676( CONT_PARAMS );
static RTYPE compiled_block_1_3672( CONT_PARAMS );
static RTYPE compiled_start_1_41( CONT_PARAMS );
static RTYPE compiled_block_1_3670( CONT_PARAMS );
static RTYPE compiled_block_1_3657( CONT_PARAMS );
static RTYPE compiled_block_1_3668( CONT_PARAMS );
static RTYPE compiled_block_1_3661( CONT_PARAMS );
static RTYPE compiled_block_1_3667( CONT_PARAMS );
static RTYPE compiled_block_1_3665( CONT_PARAMS );
static RTYPE compiled_block_1_3664( CONT_PARAMS );
static RTYPE compiled_block_1_3662( CONT_PARAMS );
static RTYPE compiled_block_1_3659( CONT_PARAMS );
static RTYPE compiled_start_1_40( CONT_PARAMS );
static RTYPE compiled_block_1_3654( CONT_PARAMS );
static RTYPE compiled_block_1_3653( CONT_PARAMS );
static RTYPE compiled_block_1_3649( CONT_PARAMS );
static RTYPE compiled_block_1_3652( CONT_PARAMS );
static RTYPE compiled_block_1_3651( CONT_PARAMS );
static RTYPE compiled_block_1_3650( CONT_PARAMS );
static RTYPE compiled_block_1_3645( CONT_PARAMS );
static RTYPE compiled_block_1_3648( CONT_PARAMS );
static RTYPE compiled_block_1_3647( CONT_PARAMS );
static RTYPE compiled_block_1_3646( CONT_PARAMS );
static RTYPE compiled_start_1_39( CONT_PARAMS );
static RTYPE compiled_block_1_3643( CONT_PARAMS );
static RTYPE compiled_block_1_3630( CONT_PARAMS );
static RTYPE compiled_block_1_3641( CONT_PARAMS );
static RTYPE compiled_block_1_3634( CONT_PARAMS );
static RTYPE compiled_block_1_3640( CONT_PARAMS );
static RTYPE compiled_block_1_3638( CONT_PARAMS );
static RTYPE compiled_block_1_3637( CONT_PARAMS );
static RTYPE compiled_block_1_3635( CONT_PARAMS );
static RTYPE compiled_block_1_3632( CONT_PARAMS );
static RTYPE compiled_start_1_38( CONT_PARAMS );
static RTYPE compiled_block_1_3627( CONT_PARAMS );
static RTYPE compiled_block_1_3614( CONT_PARAMS );
static RTYPE compiled_block_1_3625( CONT_PARAMS );
static RTYPE compiled_block_1_3618( CONT_PARAMS );
static RTYPE compiled_block_1_3624( CONT_PARAMS );
static RTYPE compiled_block_1_3622( CONT_PARAMS );
static RTYPE compiled_block_1_3621( CONT_PARAMS );
static RTYPE compiled_block_1_3619( CONT_PARAMS );
static RTYPE compiled_block_1_3616( CONT_PARAMS );
static RTYPE compiled_start_1_37( CONT_PARAMS );
static RTYPE compiled_block_1_3611( CONT_PARAMS );
static RTYPE compiled_block_1_3598( CONT_PARAMS );
static RTYPE compiled_block_1_3609( CONT_PARAMS );
static RTYPE compiled_block_1_3602( CONT_PARAMS );
static RTYPE compiled_block_1_3608( CONT_PARAMS );
static RTYPE compiled_block_1_3606( CONT_PARAMS );
static RTYPE compiled_block_1_3605( CONT_PARAMS );
static RTYPE compiled_block_1_3603( CONT_PARAMS );
static RTYPE compiled_block_1_3600( CONT_PARAMS );
static RTYPE compiled_start_1_36( CONT_PARAMS );
static RTYPE compiled_block_1_3595( CONT_PARAMS );
static RTYPE compiled_block_1_3582( CONT_PARAMS );
static RTYPE compiled_block_1_3593( CONT_PARAMS );
static RTYPE compiled_block_1_3586( CONT_PARAMS );
static RTYPE compiled_block_1_3592( CONT_PARAMS );
static RTYPE compiled_block_1_3590( CONT_PARAMS );
static RTYPE compiled_block_1_3589( CONT_PARAMS );
static RTYPE compiled_block_1_3587( CONT_PARAMS );
static RTYPE compiled_block_1_3584( CONT_PARAMS );
static RTYPE compiled_start_1_35( CONT_PARAMS );
static RTYPE compiled_block_1_3580( CONT_PARAMS );
static RTYPE compiled_block_1_3576( CONT_PARAMS );
static RTYPE compiled_block_1_3578( CONT_PARAMS );
static RTYPE compiled_block_1_3571( CONT_PARAMS );
static RTYPE compiled_block_1_3574( CONT_PARAMS );
static RTYPE compiled_block_1_3573( CONT_PARAMS );
static RTYPE compiled_block_1_3572( CONT_PARAMS );
static RTYPE compiled_block_1_3569( CONT_PARAMS );
static RTYPE compiled_block_1_3570( CONT_PARAMS );
static RTYPE compiled_block_1_3565( CONT_PARAMS );
static RTYPE compiled_block_1_3568( CONT_PARAMS );
static RTYPE compiled_block_1_3567( CONT_PARAMS );
static RTYPE compiled_block_1_3566( CONT_PARAMS );
static RTYPE compiled_block_1_3563( CONT_PARAMS );
static RTYPE compiled_block_1_3564( CONT_PARAMS );
static RTYPE compiled_start_1_34( CONT_PARAMS );
static RTYPE compiled_block_1_3554( CONT_PARAMS );
static RTYPE compiled_temp_1_121( CONT_PARAMS );
static RTYPE compiled_block_1_3545( CONT_PARAMS );
static RTYPE compiled_temp_1_119( CONT_PARAMS );
static RTYPE compiled_block_1_3543( CONT_PARAMS );
static RTYPE compiled_start_1_33( CONT_PARAMS );
static RTYPE compiled_block_1_3560( CONT_PARAMS );
static RTYPE compiled_block_1_3558( CONT_PARAMS );
static RTYPE compiled_block_1_3557( CONT_PARAMS );
static RTYPE compiled_block_1_3555( CONT_PARAMS );
static RTYPE compiled_start_1_122( CONT_PARAMS );
static RTYPE compiled_start_1_120( CONT_PARAMS );
static RTYPE compiled_block_1_3551( CONT_PARAMS );
static RTYPE compiled_block_1_3549( CONT_PARAMS );
static RTYPE compiled_block_1_3548( CONT_PARAMS );
static RTYPE compiled_block_1_3546( CONT_PARAMS );
static RTYPE compiled_start_1_123( CONT_PARAMS );
static RTYPE compiled_block_1_3534( CONT_PARAMS );
static RTYPE compiled_temp_1_126( CONT_PARAMS );
static RTYPE compiled_block_1_3525( CONT_PARAMS );
static RTYPE compiled_temp_1_124( CONT_PARAMS );
static RTYPE compiled_block_1_3523( CONT_PARAMS );
static RTYPE compiled_start_1_32( CONT_PARAMS );
static RTYPE compiled_block_1_3540( CONT_PARAMS );
static RTYPE compiled_block_1_3538( CONT_PARAMS );
static RTYPE compiled_block_1_3537( CONT_PARAMS );
static RTYPE compiled_block_1_3535( CONT_PARAMS );
static RTYPE compiled_start_1_127( CONT_PARAMS );
static RTYPE compiled_start_1_125( CONT_PARAMS );
static RTYPE compiled_block_1_3531( CONT_PARAMS );
static RTYPE compiled_block_1_3529( CONT_PARAMS );
static RTYPE compiled_block_1_3528( CONT_PARAMS );
static RTYPE compiled_block_1_3526( CONT_PARAMS );
static RTYPE compiled_start_1_128( CONT_PARAMS );
static RTYPE compiled_block_1_3514( CONT_PARAMS );
static RTYPE compiled_temp_1_131( CONT_PARAMS );
static RTYPE compiled_block_1_3505( CONT_PARAMS );
static RTYPE compiled_temp_1_129( CONT_PARAMS );
static RTYPE compiled_block_1_3503( CONT_PARAMS );
static RTYPE compiled_start_1_31( CONT_PARAMS );
static RTYPE compiled_block_1_3517( CONT_PARAMS );
static RTYPE compiled_block_1_3520( CONT_PARAMS );
static RTYPE compiled_block_1_3518( CONT_PARAMS );
static RTYPE compiled_block_1_3515( CONT_PARAMS );
static RTYPE compiled_start_1_132( CONT_PARAMS );
static RTYPE compiled_start_1_130( CONT_PARAMS );
static RTYPE compiled_block_1_3508( CONT_PARAMS );
static RTYPE compiled_block_1_3511( CONT_PARAMS );
static RTYPE compiled_block_1_3509( CONT_PARAMS );
static RTYPE compiled_block_1_3506( CONT_PARAMS );
static RTYPE compiled_start_1_133( CONT_PARAMS );
static RTYPE compiled_block_1_3494( CONT_PARAMS );
static RTYPE compiled_temp_1_136( CONT_PARAMS );
static RTYPE compiled_block_1_3485( CONT_PARAMS );
static RTYPE compiled_temp_1_134( CONT_PARAMS );
static RTYPE compiled_block_1_3483( CONT_PARAMS );
static RTYPE compiled_start_1_30( CONT_PARAMS );
static RTYPE compiled_block_1_3497( CONT_PARAMS );
static RTYPE compiled_block_1_3500( CONT_PARAMS );
static RTYPE compiled_block_1_3498( CONT_PARAMS );
static RTYPE compiled_block_1_3495( CONT_PARAMS );
static RTYPE compiled_start_1_137( CONT_PARAMS );
static RTYPE compiled_start_1_135( CONT_PARAMS );
static RTYPE compiled_block_1_3488( CONT_PARAMS );
static RTYPE compiled_block_1_3491( CONT_PARAMS );
static RTYPE compiled_block_1_3489( CONT_PARAMS );
static RTYPE compiled_block_1_3486( CONT_PARAMS );
static RTYPE compiled_start_1_138( CONT_PARAMS );
static RTYPE compiled_block_1_3474( CONT_PARAMS );
static RTYPE compiled_temp_1_141( CONT_PARAMS );
static RTYPE compiled_block_1_3465( CONT_PARAMS );
static RTYPE compiled_temp_1_139( CONT_PARAMS );
static RTYPE compiled_block_1_3463( CONT_PARAMS );
static RTYPE compiled_start_1_29( CONT_PARAMS );
static RTYPE compiled_block_1_3480( CONT_PARAMS );
static RTYPE compiled_block_1_3478( CONT_PARAMS );
static RTYPE compiled_block_1_3477( CONT_PARAMS );
static RTYPE compiled_block_1_3475( CONT_PARAMS );
static RTYPE compiled_start_1_142( CONT_PARAMS );
static RTYPE compiled_start_1_140( CONT_PARAMS );
static RTYPE compiled_block_1_3471( CONT_PARAMS );
static RTYPE compiled_block_1_3469( CONT_PARAMS );
static RTYPE compiled_block_1_3468( CONT_PARAMS );
static RTYPE compiled_block_1_3466( CONT_PARAMS );
static RTYPE compiled_start_1_143( CONT_PARAMS );
static RTYPE compiled_block_1_3454( CONT_PARAMS );
static RTYPE compiled_temp_1_146( CONT_PARAMS );
static RTYPE compiled_block_1_3445( CONT_PARAMS );
static RTYPE compiled_temp_1_144( CONT_PARAMS );
static RTYPE compiled_block_1_3443( CONT_PARAMS );
static RTYPE compiled_start_1_28( CONT_PARAMS );
static RTYPE compiled_block_1_3460( CONT_PARAMS );
static RTYPE compiled_block_1_3458( CONT_PARAMS );
static RTYPE compiled_block_1_3457( CONT_PARAMS );
static RTYPE compiled_block_1_3455( CONT_PARAMS );
static RTYPE compiled_start_1_147( CONT_PARAMS );
static RTYPE compiled_start_1_145( CONT_PARAMS );
static RTYPE compiled_block_1_3451( CONT_PARAMS );
static RTYPE compiled_block_1_3449( CONT_PARAMS );
static RTYPE compiled_block_1_3448( CONT_PARAMS );
static RTYPE compiled_block_1_3446( CONT_PARAMS );
static RTYPE compiled_start_1_148( CONT_PARAMS );
static RTYPE compiled_block_1_3403( CONT_PARAMS );
static RTYPE compiled_temp_1_155( CONT_PARAMS );
static RTYPE compiled_block_1_3296( CONT_PARAMS );
static RTYPE compiled_temp_1_153( CONT_PARAMS );
static RTYPE compiled_block_1_3271( CONT_PARAMS );
static RTYPE compiled_temp_1_151( CONT_PARAMS );
static RTYPE compiled_block_1_3263( CONT_PARAMS );
static RTYPE compiled_temp_1_149( CONT_PARAMS );
static RTYPE compiled_block_1_3261( CONT_PARAMS );
static RTYPE compiled_start_1_27( CONT_PARAMS );
static RTYPE compiled_block_1_3410( CONT_PARAMS );
static RTYPE compiled_temp_1_157( CONT_PARAMS );
static RTYPE compiled_block_1_3409( CONT_PARAMS );
static RTYPE compiled_block_1_3406( CONT_PARAMS );
static RTYPE compiled_block_1_3408( CONT_PARAMS );
static RTYPE compiled_block_1_3407( CONT_PARAMS );
static RTYPE compiled_block_1_3404( CONT_PARAMS );
static RTYPE compiled_block_1_3405( CONT_PARAMS );
static RTYPE compiled_start_1_156( CONT_PARAMS );
static RTYPE compiled_block_1_3412( CONT_PARAMS );
static RTYPE compiled_block_1_3411( CONT_PARAMS );
static RTYPE compiled_start_1_158( CONT_PARAMS );
static RTYPE compiled_block_1_3427( CONT_PARAMS );
static RTYPE compiled_block_1_3436( CONT_PARAMS );
static RTYPE compiled_temp_1_168( CONT_PARAMS );
static RTYPE compiled_block_1_3433( CONT_PARAMS );
static RTYPE compiled_temp_1_167( CONT_PARAMS );
static RTYPE compiled_block_1_3430( CONT_PARAMS );
static RTYPE compiled_temp_1_166( CONT_PARAMS );
static RTYPE compiled_block_1_3428( CONT_PARAMS );
static RTYPE compiled_block_1_3414( CONT_PARAMS );
static RTYPE compiled_temp_1_165( CONT_PARAMS );
static RTYPE compiled_block_1_3421( CONT_PARAMS );
static RTYPE compiled_temp_1_164( CONT_PARAMS );
static RTYPE compiled_block_1_3423( CONT_PARAMS );
static RTYPE compiled_temp_1_163( CONT_PARAMS );
static RTYPE compiled_temp_1_162( CONT_PARAMS );
static RTYPE compiled_temp_1_161( CONT_PARAMS );
static RTYPE compiled_block_1_3419( CONT_PARAMS );
static RTYPE compiled_temp_1_160( CONT_PARAMS );
static RTYPE compiled_block_1_3417( CONT_PARAMS );
static RTYPE compiled_block_1_3415( CONT_PARAMS );
static RTYPE compiled_start_1_159( CONT_PARAMS );
static RTYPE compiled_block_1_3375( CONT_PARAMS );
static RTYPE compiled_block_1_3390( CONT_PARAMS );
static RTYPE compiled_block_1_3397( CONT_PARAMS );
static RTYPE compiled_block_1_3395( CONT_PARAMS );
static RTYPE compiled_block_1_3392( CONT_PARAMS );
static RTYPE compiled_block_1_3393( CONT_PARAMS );
static RTYPE compiled_block_1_3391( CONT_PARAMS );
static RTYPE compiled_block_1_3380( CONT_PARAMS );
static RTYPE compiled_block_1_3387( CONT_PARAMS );
static RTYPE compiled_block_1_3385( CONT_PARAMS );
static RTYPE compiled_block_1_3382( CONT_PARAMS );
static RTYPE compiled_block_1_3383( CONT_PARAMS );
static RTYPE compiled_block_1_3381( CONT_PARAMS );
static RTYPE compiled_block_1_3377( CONT_PARAMS );
static RTYPE compiled_block_1_3378( CONT_PARAMS );
static RTYPE compiled_block_1_3376( CONT_PARAMS );
static RTYPE compiled_block_1_3325( CONT_PARAMS );
static RTYPE compiled_block_1_3356( CONT_PARAMS );
static RTYPE compiled_block_1_3363( CONT_PARAMS );
static RTYPE compiled_block_1_3370( CONT_PARAMS );
static RTYPE compiled_block_1_3368( CONT_PARAMS );
static RTYPE compiled_block_1_3365( CONT_PARAMS );
static RTYPE compiled_block_1_3366( CONT_PARAMS );
static RTYPE compiled_block_1_3364( CONT_PARAMS );
static RTYPE compiled_block_1_3361( CONT_PARAMS );
static RTYPE compiled_block_1_3358( CONT_PARAMS );
static RTYPE compiled_block_1_3359( CONT_PARAMS );
static RTYPE compiled_block_1_3357( CONT_PARAMS );
static RTYPE compiled_block_1_3346( CONT_PARAMS );
static RTYPE compiled_block_1_3353( CONT_PARAMS );
static RTYPE compiled_block_1_3351( CONT_PARAMS );
static RTYPE compiled_block_1_3348( CONT_PARAMS );
static RTYPE compiled_block_1_3349( CONT_PARAMS );
static RTYPE compiled_block_1_3347( CONT_PARAMS );
static RTYPE compiled_block_1_3328( CONT_PARAMS );
static RTYPE compiled_block_1_3335( CONT_PARAMS );
static RTYPE compiled_block_1_3342( CONT_PARAMS );
static RTYPE compiled_block_1_3340( CONT_PARAMS );
static RTYPE compiled_block_1_3337( CONT_PARAMS );
static RTYPE compiled_block_1_3338( CONT_PARAMS );
static RTYPE compiled_block_1_3336( CONT_PARAMS );
static RTYPE compiled_block_1_3333( CONT_PARAMS );
static RTYPE compiled_block_1_3330( CONT_PARAMS );
static RTYPE compiled_block_1_3331( CONT_PARAMS );
static RTYPE compiled_block_1_3329( CONT_PARAMS );
static RTYPE compiled_block_1_3326( CONT_PARAMS );
static RTYPE compiled_block_1_3299( CONT_PARAMS );
static RTYPE compiled_block_1_3314( CONT_PARAMS );
static RTYPE compiled_block_1_3321( CONT_PARAMS );
static RTYPE compiled_block_1_3319( CONT_PARAMS );
static RTYPE compiled_block_1_3316( CONT_PARAMS );
static RTYPE compiled_block_1_3317( CONT_PARAMS );
static RTYPE compiled_block_1_3315( CONT_PARAMS );
static RTYPE compiled_block_1_3304( CONT_PARAMS );
static RTYPE compiled_block_1_3311( CONT_PARAMS );
static RTYPE compiled_block_1_3309( CONT_PARAMS );
static RTYPE compiled_block_1_3306( CONT_PARAMS );
static RTYPE compiled_block_1_3307( CONT_PARAMS );
static RTYPE compiled_block_1_3305( CONT_PARAMS );
static RTYPE compiled_block_1_3301( CONT_PARAMS );
static RTYPE compiled_block_1_3302( CONT_PARAMS );
static RTYPE compiled_block_1_3300( CONT_PARAMS );
static RTYPE compiled_block_1_3297( CONT_PARAMS );
static RTYPE compiled_start_1_154( CONT_PARAMS );
static RTYPE compiled_block_1_3284( CONT_PARAMS );
static RTYPE compiled_block_1_3291( CONT_PARAMS );
static RTYPE compiled_block_1_3289( CONT_PARAMS );
static RTYPE compiled_block_1_3286( CONT_PARAMS );
static RTYPE compiled_block_1_3287( CONT_PARAMS );
static RTYPE compiled_block_1_3285( CONT_PARAMS );
static RTYPE compiled_block_1_3274( CONT_PARAMS );
static RTYPE compiled_block_1_3281( CONT_PARAMS );
static RTYPE compiled_block_1_3279( CONT_PARAMS );
static RTYPE compiled_block_1_3276( CONT_PARAMS );
static RTYPE compiled_block_1_3277( CONT_PARAMS );
static RTYPE compiled_block_1_3275( CONT_PARAMS );
static RTYPE compiled_block_1_3272( CONT_PARAMS );
static RTYPE compiled_start_1_152( CONT_PARAMS );
static RTYPE compiled_block_1_3266( CONT_PARAMS );
static RTYPE compiled_block_1_3264( CONT_PARAMS );
static RTYPE compiled_start_1_150( CONT_PARAMS );
static RTYPE compiled_block_1_3237( CONT_PARAMS );
static RTYPE compiled_temp_1_177( CONT_PARAMS );
static RTYPE compiled_block_1_3178( CONT_PARAMS );
static RTYPE compiled_temp_1_175( CONT_PARAMS );
static RTYPE compiled_block_1_3151( CONT_PARAMS );
static RTYPE compiled_temp_1_173( CONT_PARAMS );
static RTYPE compiled_block_1_3140( CONT_PARAMS );
static RTYPE compiled_temp_1_171( CONT_PARAMS );
static RTYPE compiled_block_1_3136( CONT_PARAMS );
static RTYPE compiled_temp_1_169( CONT_PARAMS );
static RTYPE compiled_block_1_3134( CONT_PARAMS );
static RTYPE compiled_start_1_26( CONT_PARAMS );
static RTYPE compiled_block_1_3241( CONT_PARAMS );
static RTYPE compiled_block_1_3245( CONT_PARAMS );
static RTYPE compiled_block_1_3244( CONT_PARAMS );
static RTYPE compiled_block_1_3242( CONT_PARAMS );
static RTYPE compiled_block_1_3239( CONT_PARAMS );
static RTYPE compiled_block_1_3240( CONT_PARAMS );
static RTYPE compiled_block_1_3238( CONT_PARAMS );
static RTYPE compiled_start_1_178( CONT_PARAMS );
static RTYPE compiled_block_1_3248( CONT_PARAMS );
static RTYPE compiled_block_1_3252( CONT_PARAMS );
static RTYPE compiled_block_1_3256( CONT_PARAMS );
static RTYPE compiled_block_1_3255( CONT_PARAMS );
static RTYPE compiled_block_1_3253( CONT_PARAMS );
static RTYPE compiled_block_1_3250( CONT_PARAMS );
static RTYPE compiled_block_1_3251( CONT_PARAMS );
static RTYPE compiled_block_1_3249( CONT_PARAMS );
static RTYPE compiled_block_1_3247( CONT_PARAMS );
static RTYPE compiled_start_1_179( CONT_PARAMS );
static RTYPE compiled_block_1_3209( CONT_PARAMS );
static RTYPE compiled_block_1_3224( CONT_PARAMS );
static RTYPE compiled_block_1_3231( CONT_PARAMS );
static RTYPE compiled_block_1_3229( CONT_PARAMS );
static RTYPE compiled_block_1_3226( CONT_PARAMS );
static RTYPE compiled_block_1_3227( CONT_PARAMS );
static RTYPE compiled_block_1_3225( CONT_PARAMS );
static RTYPE compiled_block_1_3214( CONT_PARAMS );
static RTYPE compiled_block_1_3221( CONT_PARAMS );
static RTYPE compiled_block_1_3219( CONT_PARAMS );
static RTYPE compiled_block_1_3216( CONT_PARAMS );
static RTYPE compiled_block_1_3217( CONT_PARAMS );
static RTYPE compiled_block_1_3215( CONT_PARAMS );
static RTYPE compiled_block_1_3211( CONT_PARAMS );
static RTYPE compiled_block_1_3212( CONT_PARAMS );
static RTYPE compiled_block_1_3210( CONT_PARAMS );
static RTYPE compiled_block_1_3183( CONT_PARAMS );
static RTYPE compiled_block_1_3198( CONT_PARAMS );
static RTYPE compiled_block_1_3205( CONT_PARAMS );
static RTYPE compiled_block_1_3203( CONT_PARAMS );
static RTYPE compiled_block_1_3200( CONT_PARAMS );
static RTYPE compiled_block_1_3201( CONT_PARAMS );
static RTYPE compiled_block_1_3199( CONT_PARAMS );
static RTYPE compiled_block_1_3188( CONT_PARAMS );
static RTYPE compiled_block_1_3195( CONT_PARAMS );
static RTYPE compiled_block_1_3193( CONT_PARAMS );
static RTYPE compiled_block_1_3190( CONT_PARAMS );
static RTYPE compiled_block_1_3191( CONT_PARAMS );
static RTYPE compiled_block_1_3189( CONT_PARAMS );
static RTYPE compiled_block_1_3185( CONT_PARAMS );
static RTYPE compiled_block_1_3186( CONT_PARAMS );
static RTYPE compiled_block_1_3184( CONT_PARAMS );
static RTYPE compiled_block_1_3180( CONT_PARAMS );
static RTYPE compiled_block_1_3181( CONT_PARAMS );
static RTYPE compiled_block_1_3179( CONT_PARAMS );
static RTYPE compiled_start_1_176( CONT_PARAMS );
static RTYPE compiled_block_1_3166( CONT_PARAMS );
static RTYPE compiled_block_1_3173( CONT_PARAMS );
static RTYPE compiled_block_1_3171( CONT_PARAMS );
static RTYPE compiled_block_1_3168( CONT_PARAMS );
static RTYPE compiled_block_1_3169( CONT_PARAMS );
static RTYPE compiled_block_1_3167( CONT_PARAMS );
static RTYPE compiled_block_1_3156( CONT_PARAMS );
static RTYPE compiled_block_1_3163( CONT_PARAMS );
static RTYPE compiled_block_1_3161( CONT_PARAMS );
static RTYPE compiled_block_1_3158( CONT_PARAMS );
static RTYPE compiled_block_1_3159( CONT_PARAMS );
static RTYPE compiled_block_1_3157( CONT_PARAMS );
static RTYPE compiled_block_1_3153( CONT_PARAMS );
static RTYPE compiled_block_1_3154( CONT_PARAMS );
static RTYPE compiled_block_1_3152( CONT_PARAMS );
static RTYPE compiled_start_1_174( CONT_PARAMS );
static RTYPE compiled_block_1_3147( CONT_PARAMS );
static RTYPE compiled_block_1_3145( CONT_PARAMS );
static RTYPE compiled_block_1_3142( CONT_PARAMS );
static RTYPE compiled_block_1_3143( CONT_PARAMS );
static RTYPE compiled_block_1_3141( CONT_PARAMS );
static RTYPE compiled_start_1_172( CONT_PARAMS );
static RTYPE compiled_start_1_170( CONT_PARAMS );
static RTYPE compiled_block_1_3110( CONT_PARAMS );
static RTYPE compiled_temp_1_188( CONT_PARAMS );
static RTYPE compiled_block_1_3051( CONT_PARAMS );
static RTYPE compiled_temp_1_186( CONT_PARAMS );
static RTYPE compiled_block_1_3024( CONT_PARAMS );
static RTYPE compiled_temp_1_184( CONT_PARAMS );
static RTYPE compiled_block_1_3013( CONT_PARAMS );
static RTYPE compiled_temp_1_182( CONT_PARAMS );
static RTYPE compiled_block_1_3009( CONT_PARAMS );
static RTYPE compiled_temp_1_180( CONT_PARAMS );
static RTYPE compiled_block_1_3007( CONT_PARAMS );
static RTYPE compiled_start_1_25( CONT_PARAMS );
static RTYPE compiled_block_1_3114( CONT_PARAMS );
static RTYPE compiled_block_1_3118( CONT_PARAMS );
static RTYPE compiled_block_1_3117( CONT_PARAMS );
static RTYPE compiled_block_1_3115( CONT_PARAMS );
static RTYPE compiled_block_1_3112( CONT_PARAMS );
static RTYPE compiled_block_1_3113( CONT_PARAMS );
static RTYPE compiled_block_1_3111( CONT_PARAMS );
static RTYPE compiled_start_1_189( CONT_PARAMS );
static RTYPE compiled_block_1_3121( CONT_PARAMS );
static RTYPE compiled_block_1_3125( CONT_PARAMS );
static RTYPE compiled_block_1_3129( CONT_PARAMS );
static RTYPE compiled_block_1_3128( CONT_PARAMS );
static RTYPE compiled_block_1_3126( CONT_PARAMS );
static RTYPE compiled_block_1_3123( CONT_PARAMS );
static RTYPE compiled_block_1_3124( CONT_PARAMS );
static RTYPE compiled_block_1_3122( CONT_PARAMS );
static RTYPE compiled_block_1_3120( CONT_PARAMS );
static RTYPE compiled_start_1_190( CONT_PARAMS );
static RTYPE compiled_block_1_3082( CONT_PARAMS );
static RTYPE compiled_block_1_3097( CONT_PARAMS );
static RTYPE compiled_block_1_3104( CONT_PARAMS );
static RTYPE compiled_block_1_3102( CONT_PARAMS );
static RTYPE compiled_block_1_3099( CONT_PARAMS );
static RTYPE compiled_block_1_3100( CONT_PARAMS );
static RTYPE compiled_block_1_3098( CONT_PARAMS );
static RTYPE compiled_block_1_3087( CONT_PARAMS );
static RTYPE compiled_block_1_3094( CONT_PARAMS );
static RTYPE compiled_block_1_3092( CONT_PARAMS );
static RTYPE compiled_block_1_3089( CONT_PARAMS );
static RTYPE compiled_block_1_3090( CONT_PARAMS );
static RTYPE compiled_block_1_3088( CONT_PARAMS );
static RTYPE compiled_block_1_3084( CONT_PARAMS );
static RTYPE compiled_block_1_3085( CONT_PARAMS );
static RTYPE compiled_block_1_3083( CONT_PARAMS );
static RTYPE compiled_block_1_3056( CONT_PARAMS );
static RTYPE compiled_block_1_3071( CONT_PARAMS );
static RTYPE compiled_block_1_3078( CONT_PARAMS );
static RTYPE compiled_block_1_3076( CONT_PARAMS );
static RTYPE compiled_block_1_3073( CONT_PARAMS );
static RTYPE compiled_block_1_3074( CONT_PARAMS );
static RTYPE compiled_block_1_3072( CONT_PARAMS );
static RTYPE compiled_block_1_3061( CONT_PARAMS );
static RTYPE compiled_block_1_3068( CONT_PARAMS );
static RTYPE compiled_block_1_3066( CONT_PARAMS );
static RTYPE compiled_block_1_3063( CONT_PARAMS );
static RTYPE compiled_block_1_3064( CONT_PARAMS );
static RTYPE compiled_block_1_3062( CONT_PARAMS );
static RTYPE compiled_block_1_3058( CONT_PARAMS );
static RTYPE compiled_block_1_3059( CONT_PARAMS );
static RTYPE compiled_block_1_3057( CONT_PARAMS );
static RTYPE compiled_block_1_3053( CONT_PARAMS );
static RTYPE compiled_block_1_3054( CONT_PARAMS );
static RTYPE compiled_block_1_3052( CONT_PARAMS );
static RTYPE compiled_start_1_187( CONT_PARAMS );
static RTYPE compiled_block_1_3039( CONT_PARAMS );
static RTYPE compiled_block_1_3046( CONT_PARAMS );
static RTYPE compiled_block_1_3044( CONT_PARAMS );
static RTYPE compiled_block_1_3041( CONT_PARAMS );
static RTYPE compiled_block_1_3042( CONT_PARAMS );
static RTYPE compiled_block_1_3040( CONT_PARAMS );
static RTYPE compiled_block_1_3029( CONT_PARAMS );
static RTYPE compiled_block_1_3036( CONT_PARAMS );
static RTYPE compiled_block_1_3034( CONT_PARAMS );
static RTYPE compiled_block_1_3031( CONT_PARAMS );
static RTYPE compiled_block_1_3032( CONT_PARAMS );
static RTYPE compiled_block_1_3030( CONT_PARAMS );
static RTYPE compiled_block_1_3026( CONT_PARAMS );
static RTYPE compiled_block_1_3027( CONT_PARAMS );
static RTYPE compiled_block_1_3025( CONT_PARAMS );
static RTYPE compiled_start_1_185( CONT_PARAMS );
static RTYPE compiled_block_1_3020( CONT_PARAMS );
static RTYPE compiled_block_1_3018( CONT_PARAMS );
static RTYPE compiled_block_1_3015( CONT_PARAMS );
static RTYPE compiled_block_1_3016( CONT_PARAMS );
static RTYPE compiled_block_1_3014( CONT_PARAMS );
static RTYPE compiled_start_1_183( CONT_PARAMS );
static RTYPE compiled_start_1_181( CONT_PARAMS );
static RTYPE compiled_block_1_2963( CONT_PARAMS );
static RTYPE compiled_temp_1_199( CONT_PARAMS );
static RTYPE compiled_block_1_2935( CONT_PARAMS );
static RTYPE compiled_temp_1_197( CONT_PARAMS );
static RTYPE compiled_block_1_2924( CONT_PARAMS );
static RTYPE compiled_temp_1_195( CONT_PARAMS );
static RTYPE compiled_block_1_2920( CONT_PARAMS );
static RTYPE compiled_temp_1_193( CONT_PARAMS );
static RTYPE compiled_block_1_2917( CONT_PARAMS );
static RTYPE compiled_temp_1_191( CONT_PARAMS );
static RTYPE compiled_block_1_2915( CONT_PARAMS );
static RTYPE compiled_start_1_24( CONT_PARAMS );
static RTYPE compiled_block_1_2964( CONT_PARAMS );
static RTYPE compiled_start_1_200( CONT_PARAMS );
static RTYPE compiled_block_1_2972( CONT_PARAMS );
static RTYPE compiled_block_1_2975( CONT_PARAMS );
static RTYPE compiled_block_1_2974( CONT_PARAMS );
static RTYPE compiled_block_1_2966( CONT_PARAMS );
static RTYPE compiled_block_1_2971( CONT_PARAMS );
static RTYPE compiled_block_1_2967( CONT_PARAMS );
static RTYPE compiled_block_1_2968( CONT_PARAMS );
static RTYPE compiled_block_1_2969( CONT_PARAMS );
static RTYPE compiled_temp_1_202( CONT_PARAMS );
static RTYPE compiled_start_1_201( CONT_PARAMS );
static RTYPE compiled_block_1_2989( CONT_PARAMS );
static RTYPE compiled_block_1_2987( CONT_PARAMS );
static RTYPE compiled_block_1_3000( CONT_PARAMS );
static RTYPE compiled_temp_1_206( CONT_PARAMS );
static RTYPE compiled_block_1_2995( CONT_PARAMS );
static RTYPE compiled_block_1_2997( CONT_PARAMS );
static RTYPE compiled_block_1_2992( CONT_PARAMS );
static RTYPE compiled_temp_1_205( CONT_PARAMS );
static RTYPE compiled_block_1_2990( CONT_PARAMS );
static RTYPE compiled_block_1_2986( CONT_PARAMS );
static RTYPE compiled_temp_1_204( CONT_PARAMS );
static RTYPE compiled_block_1_2984( CONT_PARAMS );
static RTYPE compiled_block_1_2977( CONT_PARAMS );
static RTYPE compiled_block_1_2981( CONT_PARAMS );
static RTYPE compiled_block_1_2982( CONT_PARAMS );
static RTYPE compiled_block_1_2979( CONT_PARAMS );
static RTYPE compiled_block_1_2978( CONT_PARAMS );
static RTYPE compiled_start_1_203( CONT_PARAMS );
static RTYPE compiled_block_1_2958( CONT_PARAMS );
static RTYPE compiled_block_1_2940( CONT_PARAMS );
static RTYPE compiled_block_1_2955( CONT_PARAMS );
static RTYPE compiled_block_1_2945( CONT_PARAMS );
static RTYPE compiled_block_1_2952( CONT_PARAMS );
static RTYPE compiled_block_1_2950( CONT_PARAMS );
static RTYPE compiled_block_1_2947( CONT_PARAMS );
static RTYPE compiled_block_1_2948( CONT_PARAMS );
static RTYPE compiled_block_1_2946( CONT_PARAMS );
static RTYPE compiled_block_1_2942( CONT_PARAMS );
static RTYPE compiled_block_1_2943( CONT_PARAMS );
static RTYPE compiled_block_1_2941( CONT_PARAMS );
static RTYPE compiled_block_1_2937( CONT_PARAMS );
static RTYPE compiled_block_1_2938( CONT_PARAMS );
static RTYPE compiled_block_1_2936( CONT_PARAMS );
static RTYPE compiled_start_1_198( CONT_PARAMS );
static RTYPE compiled_block_1_2931( CONT_PARAMS );
static RTYPE compiled_block_1_2929( CONT_PARAMS );
static RTYPE compiled_block_1_2926( CONT_PARAMS );
static RTYPE compiled_block_1_2927( CONT_PARAMS );
static RTYPE compiled_block_1_2925( CONT_PARAMS );
static RTYPE compiled_start_1_196( CONT_PARAMS );
static RTYPE compiled_start_1_194( CONT_PARAMS );
static RTYPE compiled_start_1_192( CONT_PARAMS );
static RTYPE compiled_block_1_2889( CONT_PARAMS );
static RTYPE compiled_temp_1_215( CONT_PARAMS );
static RTYPE compiled_block_1_2869( CONT_PARAMS );
static RTYPE compiled_temp_1_213( CONT_PARAMS );
static RTYPE compiled_block_1_2858( CONT_PARAMS );
static RTYPE compiled_temp_1_211( CONT_PARAMS );
static RTYPE compiled_block_1_2854( CONT_PARAMS );
static RTYPE compiled_temp_1_209( CONT_PARAMS );
static RTYPE compiled_block_1_2851( CONT_PARAMS );
static RTYPE compiled_temp_1_207( CONT_PARAMS );
static RTYPE compiled_block_1_2849( CONT_PARAMS );
static RTYPE compiled_start_1_23( CONT_PARAMS );
static RTYPE compiled_block_1_2910( CONT_PARAMS );
static RTYPE compiled_block_1_2894( CONT_PARAMS );
static RTYPE compiled_block_1_2891( CONT_PARAMS );
static RTYPE compiled_block_1_2892( CONT_PARAMS );
static RTYPE compiled_block_1_2890( CONT_PARAMS );
static RTYPE compiled_start_1_216( CONT_PARAMS );
static RTYPE compiled_block_1_2897( CONT_PARAMS );
static RTYPE compiled_block_1_2905( CONT_PARAMS );
static RTYPE compiled_block_1_2902( CONT_PARAMS );
static RTYPE compiled_block_1_2899( CONT_PARAMS );
static RTYPE compiled_block_1_2900( CONT_PARAMS );
static RTYPE compiled_block_1_2898( CONT_PARAMS );
static RTYPE compiled_block_1_2896( CONT_PARAMS );
static RTYPE compiled_start_1_217( CONT_PARAMS );
static RTYPE compiled_block_1_2884( CONT_PARAMS );
static RTYPE compiled_block_1_2874( CONT_PARAMS );
static RTYPE compiled_block_1_2881( CONT_PARAMS );
static RTYPE compiled_block_1_2879( CONT_PARAMS );
static RTYPE compiled_block_1_2876( CONT_PARAMS );
static RTYPE compiled_block_1_2877( CONT_PARAMS );
static RTYPE compiled_block_1_2875( CONT_PARAMS );
static RTYPE compiled_block_1_2871( CONT_PARAMS );
static RTYPE compiled_block_1_2872( CONT_PARAMS );
static RTYPE compiled_block_1_2870( CONT_PARAMS );
static RTYPE compiled_start_1_214( CONT_PARAMS );
static RTYPE compiled_block_1_2865( CONT_PARAMS );
static RTYPE compiled_block_1_2863( CONT_PARAMS );
static RTYPE compiled_block_1_2860( CONT_PARAMS );
static RTYPE compiled_block_1_2861( CONT_PARAMS );
static RTYPE compiled_block_1_2859( CONT_PARAMS );
static RTYPE compiled_start_1_212( CONT_PARAMS );
static RTYPE compiled_start_1_210( CONT_PARAMS );
static RTYPE compiled_start_1_208( CONT_PARAMS );
static RTYPE compiled_block_1_2823( CONT_PARAMS );
static RTYPE compiled_temp_1_226( CONT_PARAMS );
static RTYPE compiled_block_1_2803( CONT_PARAMS );
static RTYPE compiled_temp_1_224( CONT_PARAMS );
static RTYPE compiled_block_1_2792( CONT_PARAMS );
static RTYPE compiled_temp_1_222( CONT_PARAMS );
static RTYPE compiled_block_1_2788( CONT_PARAMS );
static RTYPE compiled_temp_1_220( CONT_PARAMS );
static RTYPE compiled_block_1_2785( CONT_PARAMS );
static RTYPE compiled_temp_1_218( CONT_PARAMS );
static RTYPE compiled_block_1_2783( CONT_PARAMS );
static RTYPE compiled_start_1_22( CONT_PARAMS );
static RTYPE compiled_block_1_2844( CONT_PARAMS );
static RTYPE compiled_block_1_2828( CONT_PARAMS );
static RTYPE compiled_block_1_2825( CONT_PARAMS );
static RTYPE compiled_block_1_2826( CONT_PARAMS );
static RTYPE compiled_block_1_2824( CONT_PARAMS );
static RTYPE compiled_start_1_227( CONT_PARAMS );
static RTYPE compiled_block_1_2831( CONT_PARAMS );
static RTYPE compiled_block_1_2839( CONT_PARAMS );
static RTYPE compiled_block_1_2836( CONT_PARAMS );
static RTYPE compiled_block_1_2833( CONT_PARAMS );
static RTYPE compiled_block_1_2834( CONT_PARAMS );
static RTYPE compiled_block_1_2832( CONT_PARAMS );
static RTYPE compiled_block_1_2830( CONT_PARAMS );
static RTYPE compiled_start_1_228( CONT_PARAMS );
static RTYPE compiled_block_1_2818( CONT_PARAMS );
static RTYPE compiled_block_1_2808( CONT_PARAMS );
static RTYPE compiled_block_1_2815( CONT_PARAMS );
static RTYPE compiled_block_1_2813( CONT_PARAMS );
static RTYPE compiled_block_1_2810( CONT_PARAMS );
static RTYPE compiled_block_1_2811( CONT_PARAMS );
static RTYPE compiled_block_1_2809( CONT_PARAMS );
static RTYPE compiled_block_1_2805( CONT_PARAMS );
static RTYPE compiled_block_1_2806( CONT_PARAMS );
static RTYPE compiled_block_1_2804( CONT_PARAMS );
static RTYPE compiled_start_1_225( CONT_PARAMS );
static RTYPE compiled_block_1_2799( CONT_PARAMS );
static RTYPE compiled_block_1_2797( CONT_PARAMS );
static RTYPE compiled_block_1_2794( CONT_PARAMS );
static RTYPE compiled_block_1_2795( CONT_PARAMS );
static RTYPE compiled_block_1_2793( CONT_PARAMS );
static RTYPE compiled_start_1_223( CONT_PARAMS );
static RTYPE compiled_start_1_221( CONT_PARAMS );
static RTYPE compiled_start_1_219( CONT_PARAMS );
static RTYPE compiled_block_1_2757( CONT_PARAMS );
static RTYPE compiled_temp_1_237( CONT_PARAMS );
static RTYPE compiled_block_1_2737( CONT_PARAMS );
static RTYPE compiled_temp_1_235( CONT_PARAMS );
static RTYPE compiled_block_1_2726( CONT_PARAMS );
static RTYPE compiled_temp_1_233( CONT_PARAMS );
static RTYPE compiled_block_1_2722( CONT_PARAMS );
static RTYPE compiled_temp_1_231( CONT_PARAMS );
static RTYPE compiled_block_1_2719( CONT_PARAMS );
static RTYPE compiled_temp_1_229( CONT_PARAMS );
static RTYPE compiled_block_1_2717( CONT_PARAMS );
static RTYPE compiled_start_1_21( CONT_PARAMS );
static RTYPE compiled_block_1_2778( CONT_PARAMS );
static RTYPE compiled_block_1_2775( CONT_PARAMS );
static RTYPE compiled_block_1_2776( CONT_PARAMS );
static RTYPE compiled_block_1_2760( CONT_PARAMS );
static RTYPE compiled_block_1_2758( CONT_PARAMS );
static RTYPE compiled_start_1_238( CONT_PARAMS );
static RTYPE compiled_block_1_2763( CONT_PARAMS );
static RTYPE compiled_block_1_2771( CONT_PARAMS );
static RTYPE compiled_block_1_2768( CONT_PARAMS );
static RTYPE compiled_block_1_2769( CONT_PARAMS );
static RTYPE compiled_block_1_2766( CONT_PARAMS );
static RTYPE compiled_block_1_2764( CONT_PARAMS );
static RTYPE compiled_block_1_2762( CONT_PARAMS );
static RTYPE compiled_start_1_239( CONT_PARAMS );
static RTYPE compiled_block_1_2752( CONT_PARAMS );
static RTYPE compiled_block_1_2749( CONT_PARAMS );
static RTYPE compiled_block_1_2750( CONT_PARAMS );
static RTYPE compiled_block_1_2740( CONT_PARAMS );
static RTYPE compiled_block_1_2747( CONT_PARAMS );
static RTYPE compiled_block_1_2744( CONT_PARAMS );
static RTYPE compiled_block_1_2745( CONT_PARAMS );
static RTYPE compiled_block_1_2743( CONT_PARAMS );
static RTYPE compiled_block_1_2741( CONT_PARAMS );
static RTYPE compiled_block_1_2738( CONT_PARAMS );
static RTYPE compiled_start_1_236( CONT_PARAMS );
static RTYPE compiled_block_1_2733( CONT_PARAMS );
static RTYPE compiled_block_1_2730( CONT_PARAMS );
static RTYPE compiled_block_1_2731( CONT_PARAMS );
static RTYPE compiled_block_1_2729( CONT_PARAMS );
static RTYPE compiled_block_1_2727( CONT_PARAMS );
static RTYPE compiled_start_1_234( CONT_PARAMS );
static RTYPE compiled_start_1_232( CONT_PARAMS );
static RTYPE compiled_start_1_230( CONT_PARAMS );
static RTYPE compiled_block_1_2691( CONT_PARAMS );
static RTYPE compiled_temp_1_248( CONT_PARAMS );
static RTYPE compiled_block_1_2671( CONT_PARAMS );
static RTYPE compiled_temp_1_246( CONT_PARAMS );
static RTYPE compiled_block_1_2660( CONT_PARAMS );
static RTYPE compiled_temp_1_244( CONT_PARAMS );
static RTYPE compiled_block_1_2656( CONT_PARAMS );
static RTYPE compiled_temp_1_242( CONT_PARAMS );
static RTYPE compiled_block_1_2653( CONT_PARAMS );
static RTYPE compiled_temp_1_240( CONT_PARAMS );
static RTYPE compiled_block_1_2651( CONT_PARAMS );
static RTYPE compiled_start_1_20( CONT_PARAMS );
static RTYPE compiled_block_1_2712( CONT_PARAMS );
static RTYPE compiled_block_1_2709( CONT_PARAMS );
static RTYPE compiled_block_1_2710( CONT_PARAMS );
static RTYPE compiled_block_1_2694( CONT_PARAMS );
static RTYPE compiled_block_1_2692( CONT_PARAMS );
static RTYPE compiled_start_1_249( CONT_PARAMS );
static RTYPE compiled_block_1_2697( CONT_PARAMS );
static RTYPE compiled_block_1_2705( CONT_PARAMS );
static RTYPE compiled_block_1_2702( CONT_PARAMS );
static RTYPE compiled_block_1_2703( CONT_PARAMS );
static RTYPE compiled_block_1_2700( CONT_PARAMS );
static RTYPE compiled_block_1_2698( CONT_PARAMS );
static RTYPE compiled_block_1_2696( CONT_PARAMS );
static RTYPE compiled_start_1_250( CONT_PARAMS );
static RTYPE compiled_block_1_2686( CONT_PARAMS );
static RTYPE compiled_block_1_2683( CONT_PARAMS );
static RTYPE compiled_block_1_2684( CONT_PARAMS );
static RTYPE compiled_block_1_2674( CONT_PARAMS );
static RTYPE compiled_block_1_2681( CONT_PARAMS );
static RTYPE compiled_block_1_2678( CONT_PARAMS );
static RTYPE compiled_block_1_2679( CONT_PARAMS );
static RTYPE compiled_block_1_2677( CONT_PARAMS );
static RTYPE compiled_block_1_2675( CONT_PARAMS );
static RTYPE compiled_block_1_2672( CONT_PARAMS );
static RTYPE compiled_start_1_247( CONT_PARAMS );
static RTYPE compiled_block_1_2667( CONT_PARAMS );
static RTYPE compiled_block_1_2664( CONT_PARAMS );
static RTYPE compiled_block_1_2665( CONT_PARAMS );
static RTYPE compiled_block_1_2663( CONT_PARAMS );
static RTYPE compiled_block_1_2661( CONT_PARAMS );
static RTYPE compiled_start_1_245( CONT_PARAMS );
static RTYPE compiled_start_1_243( CONT_PARAMS );
static RTYPE compiled_start_1_241( CONT_PARAMS );
static RTYPE compiled_block_1_2625( CONT_PARAMS );
static RTYPE compiled_temp_1_259( CONT_PARAMS );
static RTYPE compiled_block_1_2605( CONT_PARAMS );
static RTYPE compiled_temp_1_257( CONT_PARAMS );
static RTYPE compiled_block_1_2594( CONT_PARAMS );
static RTYPE compiled_temp_1_255( CONT_PARAMS );
static RTYPE compiled_block_1_2590( CONT_PARAMS );
static RTYPE compiled_temp_1_253( CONT_PARAMS );
static RTYPE compiled_block_1_2587( CONT_PARAMS );
static RTYPE compiled_temp_1_251( CONT_PARAMS );
static RTYPE compiled_block_1_2585( CONT_PARAMS );
static RTYPE compiled_start_1_19( CONT_PARAMS );
static RTYPE compiled_block_1_2646( CONT_PARAMS );
static RTYPE compiled_block_1_2643( CONT_PARAMS );
static RTYPE compiled_block_1_2644( CONT_PARAMS );
static RTYPE compiled_block_1_2628( CONT_PARAMS );
static RTYPE compiled_block_1_2626( CONT_PARAMS );
static RTYPE compiled_start_1_260( CONT_PARAMS );
static RTYPE compiled_block_1_2631( CONT_PARAMS );
static RTYPE compiled_block_1_2639( CONT_PARAMS );
static RTYPE compiled_block_1_2636( CONT_PARAMS );
static RTYPE compiled_block_1_2637( CONT_PARAMS );
static RTYPE compiled_block_1_2634( CONT_PARAMS );
static RTYPE compiled_block_1_2632( CONT_PARAMS );
static RTYPE compiled_block_1_2630( CONT_PARAMS );
static RTYPE compiled_start_1_261( CONT_PARAMS );
static RTYPE compiled_block_1_2620( CONT_PARAMS );
static RTYPE compiled_block_1_2617( CONT_PARAMS );
static RTYPE compiled_block_1_2618( CONT_PARAMS );
static RTYPE compiled_block_1_2608( CONT_PARAMS );
static RTYPE compiled_block_1_2615( CONT_PARAMS );
static RTYPE compiled_block_1_2612( CONT_PARAMS );
static RTYPE compiled_block_1_2613( CONT_PARAMS );
static RTYPE compiled_block_1_2611( CONT_PARAMS );
static RTYPE compiled_block_1_2609( CONT_PARAMS );
static RTYPE compiled_block_1_2606( CONT_PARAMS );
static RTYPE compiled_start_1_258( CONT_PARAMS );
static RTYPE compiled_block_1_2601( CONT_PARAMS );
static RTYPE compiled_block_1_2598( CONT_PARAMS );
static RTYPE compiled_block_1_2599( CONT_PARAMS );
static RTYPE compiled_block_1_2597( CONT_PARAMS );
static RTYPE compiled_block_1_2595( CONT_PARAMS );
static RTYPE compiled_start_1_256( CONT_PARAMS );
static RTYPE compiled_start_1_254( CONT_PARAMS );
static RTYPE compiled_start_1_252( CONT_PARAMS );
static RTYPE compiled_block_1_2565( CONT_PARAMS );
static RTYPE compiled_temp_1_268( CONT_PARAMS );
static RTYPE compiled_block_1_2545( CONT_PARAMS );
static RTYPE compiled_temp_1_266( CONT_PARAMS );
static RTYPE compiled_block_1_2525( CONT_PARAMS );
static RTYPE compiled_temp_1_264( CONT_PARAMS );
static RTYPE compiled_block_1_2505( CONT_PARAMS );
static RTYPE compiled_temp_1_262( CONT_PARAMS );
static RTYPE compiled_block_1_2503( CONT_PARAMS );
static RTYPE compiled_start_1_18( CONT_PARAMS );
static RTYPE compiled_block_1_2580( CONT_PARAMS );
static RTYPE compiled_block_1_2570( CONT_PARAMS );
static RTYPE compiled_block_1_2577( CONT_PARAMS );
static RTYPE compiled_block_1_2575( CONT_PARAMS );
static RTYPE compiled_block_1_2572( CONT_PARAMS );
static RTYPE compiled_block_1_2573( CONT_PARAMS );
static RTYPE compiled_block_1_2571( CONT_PARAMS );
static RTYPE compiled_block_1_2567( CONT_PARAMS );
static RTYPE compiled_block_1_2568( CONT_PARAMS );
static RTYPE compiled_block_1_2566( CONT_PARAMS );
static RTYPE compiled_start_1_269( CONT_PARAMS );
static RTYPE compiled_block_1_2560( CONT_PARAMS );
static RTYPE compiled_block_1_2550( CONT_PARAMS );
static RTYPE compiled_block_1_2557( CONT_PARAMS );
static RTYPE compiled_block_1_2555( CONT_PARAMS );
static RTYPE compiled_block_1_2552( CONT_PARAMS );
static RTYPE compiled_block_1_2553( CONT_PARAMS );
static RTYPE compiled_block_1_2551( CONT_PARAMS );
static RTYPE compiled_block_1_2547( CONT_PARAMS );
static RTYPE compiled_block_1_2548( CONT_PARAMS );
static RTYPE compiled_block_1_2546( CONT_PARAMS );
static RTYPE compiled_start_1_267( CONT_PARAMS );
static RTYPE compiled_start_1_265( CONT_PARAMS );
static RTYPE compiled_block_1_2540( CONT_PARAMS );
static RTYPE compiled_block_1_2530( CONT_PARAMS );
static RTYPE compiled_block_1_2537( CONT_PARAMS );
static RTYPE compiled_block_1_2535( CONT_PARAMS );
static RTYPE compiled_block_1_2532( CONT_PARAMS );
static RTYPE compiled_block_1_2533( CONT_PARAMS );
static RTYPE compiled_block_1_2531( CONT_PARAMS );
static RTYPE compiled_block_1_2527( CONT_PARAMS );
static RTYPE compiled_block_1_2528( CONT_PARAMS );
static RTYPE compiled_block_1_2526( CONT_PARAMS );
static RTYPE compiled_start_1_270( CONT_PARAMS );
static RTYPE compiled_start_1_263( CONT_PARAMS );
static RTYPE compiled_block_1_2520( CONT_PARAMS );
static RTYPE compiled_block_1_2510( CONT_PARAMS );
static RTYPE compiled_block_1_2517( CONT_PARAMS );
static RTYPE compiled_block_1_2515( CONT_PARAMS );
static RTYPE compiled_block_1_2512( CONT_PARAMS );
static RTYPE compiled_block_1_2513( CONT_PARAMS );
static RTYPE compiled_block_1_2511( CONT_PARAMS );
static RTYPE compiled_block_1_2507( CONT_PARAMS );
static RTYPE compiled_block_1_2508( CONT_PARAMS );
static RTYPE compiled_block_1_2506( CONT_PARAMS );
static RTYPE compiled_start_1_271( CONT_PARAMS );
static RTYPE compiled_block_1_2483( CONT_PARAMS );
static RTYPE compiled_temp_1_278( CONT_PARAMS );
static RTYPE compiled_block_1_2463( CONT_PARAMS );
static RTYPE compiled_temp_1_276( CONT_PARAMS );
static RTYPE compiled_block_1_2443( CONT_PARAMS );
static RTYPE compiled_temp_1_274( CONT_PARAMS );
static RTYPE compiled_block_1_2423( CONT_PARAMS );
static RTYPE compiled_temp_1_272( CONT_PARAMS );
static RTYPE compiled_block_1_2421( CONT_PARAMS );
static RTYPE compiled_start_1_17( CONT_PARAMS );
static RTYPE compiled_block_1_2498( CONT_PARAMS );
static RTYPE compiled_block_1_2488( CONT_PARAMS );
static RTYPE compiled_block_1_2495( CONT_PARAMS );
static RTYPE compiled_block_1_2492( CONT_PARAMS );
static RTYPE compiled_block_1_2493( CONT_PARAMS );
static RTYPE compiled_block_1_2491( CONT_PARAMS );
static RTYPE compiled_block_1_2489( CONT_PARAMS );
static RTYPE compiled_block_1_2485( CONT_PARAMS );
static RTYPE compiled_block_1_2486( CONT_PARAMS );
static RTYPE compiled_block_1_2484( CONT_PARAMS );
static RTYPE compiled_start_1_279( CONT_PARAMS );
static RTYPE compiled_block_1_2478( CONT_PARAMS );
static RTYPE compiled_block_1_2468( CONT_PARAMS );
static RTYPE compiled_block_1_2475( CONT_PARAMS );
static RTYPE compiled_block_1_2472( CONT_PARAMS );
static RTYPE compiled_block_1_2473( CONT_PARAMS );
static RTYPE compiled_block_1_2471( CONT_PARAMS );
static RTYPE compiled_block_1_2469( CONT_PARAMS );
static RTYPE compiled_block_1_2465( CONT_PARAMS );
static RTYPE compiled_block_1_2466( CONT_PARAMS );
static RTYPE compiled_block_1_2464( CONT_PARAMS );
static RTYPE compiled_start_1_277( CONT_PARAMS );
static RTYPE compiled_start_1_275( CONT_PARAMS );
static RTYPE compiled_block_1_2458( CONT_PARAMS );
static RTYPE compiled_block_1_2448( CONT_PARAMS );
static RTYPE compiled_block_1_2455( CONT_PARAMS );
static RTYPE compiled_block_1_2452( CONT_PARAMS );
static RTYPE compiled_block_1_2453( CONT_PARAMS );
static RTYPE compiled_block_1_2451( CONT_PARAMS );
static RTYPE compiled_block_1_2449( CONT_PARAMS );
static RTYPE compiled_block_1_2445( CONT_PARAMS );
static RTYPE compiled_block_1_2446( CONT_PARAMS );
static RTYPE compiled_block_1_2444( CONT_PARAMS );
static RTYPE compiled_start_1_280( CONT_PARAMS );
static RTYPE compiled_start_1_273( CONT_PARAMS );
static RTYPE compiled_block_1_2438( CONT_PARAMS );
static RTYPE compiled_block_1_2428( CONT_PARAMS );
static RTYPE compiled_block_1_2435( CONT_PARAMS );
static RTYPE compiled_block_1_2432( CONT_PARAMS );
static RTYPE compiled_block_1_2433( CONT_PARAMS );
static RTYPE compiled_block_1_2431( CONT_PARAMS );
static RTYPE compiled_block_1_2429( CONT_PARAMS );
static RTYPE compiled_block_1_2425( CONT_PARAMS );
static RTYPE compiled_block_1_2426( CONT_PARAMS );
static RTYPE compiled_block_1_2424( CONT_PARAMS );
static RTYPE compiled_start_1_281( CONT_PARAMS );
static RTYPE compiled_block_1_2401( CONT_PARAMS );
static RTYPE compiled_temp_1_288( CONT_PARAMS );
static RTYPE compiled_block_1_2381( CONT_PARAMS );
static RTYPE compiled_temp_1_286( CONT_PARAMS );
static RTYPE compiled_block_1_2361( CONT_PARAMS );
static RTYPE compiled_temp_1_284( CONT_PARAMS );
static RTYPE compiled_block_1_2341( CONT_PARAMS );
static RTYPE compiled_temp_1_282( CONT_PARAMS );
static RTYPE compiled_block_1_2339( CONT_PARAMS );
static RTYPE compiled_start_1_16( CONT_PARAMS );
static RTYPE compiled_block_1_2416( CONT_PARAMS );
static RTYPE compiled_block_1_2413( CONT_PARAMS );
static RTYPE compiled_block_1_2414( CONT_PARAMS );
static RTYPE compiled_block_1_2404( CONT_PARAMS );
static RTYPE compiled_block_1_2411( CONT_PARAMS );
static RTYPE compiled_block_1_2409( CONT_PARAMS );
static RTYPE compiled_block_1_2406( CONT_PARAMS );
static RTYPE compiled_block_1_2407( CONT_PARAMS );
static RTYPE compiled_block_1_2405( CONT_PARAMS );
static RTYPE compiled_block_1_2402( CONT_PARAMS );
static RTYPE compiled_start_1_289( CONT_PARAMS );
static RTYPE compiled_block_1_2396( CONT_PARAMS );
static RTYPE compiled_block_1_2393( CONT_PARAMS );
static RTYPE compiled_block_1_2394( CONT_PARAMS );
static RTYPE compiled_block_1_2384( CONT_PARAMS );
static RTYPE compiled_block_1_2391( CONT_PARAMS );
static RTYPE compiled_block_1_2389( CONT_PARAMS );
static RTYPE compiled_block_1_2386( CONT_PARAMS );
static RTYPE compiled_block_1_2387( CONT_PARAMS );
static RTYPE compiled_block_1_2385( CONT_PARAMS );
static RTYPE compiled_block_1_2382( CONT_PARAMS );
static RTYPE compiled_start_1_287( CONT_PARAMS );
static RTYPE compiled_start_1_285( CONT_PARAMS );
static RTYPE compiled_block_1_2376( CONT_PARAMS );
static RTYPE compiled_block_1_2373( CONT_PARAMS );
static RTYPE compiled_block_1_2374( CONT_PARAMS );
static RTYPE compiled_block_1_2364( CONT_PARAMS );
static RTYPE compiled_block_1_2371( CONT_PARAMS );
static RTYPE compiled_block_1_2369( CONT_PARAMS );
static RTYPE compiled_block_1_2366( CONT_PARAMS );
static RTYPE compiled_block_1_2367( CONT_PARAMS );
static RTYPE compiled_block_1_2365( CONT_PARAMS );
static RTYPE compiled_block_1_2362( CONT_PARAMS );
static RTYPE compiled_start_1_290( CONT_PARAMS );
static RTYPE compiled_start_1_283( CONT_PARAMS );
static RTYPE compiled_block_1_2356( CONT_PARAMS );
static RTYPE compiled_block_1_2353( CONT_PARAMS );
static RTYPE compiled_block_1_2354( CONT_PARAMS );
static RTYPE compiled_block_1_2344( CONT_PARAMS );
static RTYPE compiled_block_1_2351( CONT_PARAMS );
static RTYPE compiled_block_1_2349( CONT_PARAMS );
static RTYPE compiled_block_1_2346( CONT_PARAMS );
static RTYPE compiled_block_1_2347( CONT_PARAMS );
static RTYPE compiled_block_1_2345( CONT_PARAMS );
static RTYPE compiled_block_1_2342( CONT_PARAMS );
static RTYPE compiled_start_1_291( CONT_PARAMS );
static RTYPE compiled_block_1_2319( CONT_PARAMS );
static RTYPE compiled_temp_1_298( CONT_PARAMS );
static RTYPE compiled_block_1_2299( CONT_PARAMS );
static RTYPE compiled_temp_1_296( CONT_PARAMS );
static RTYPE compiled_block_1_2279( CONT_PARAMS );
static RTYPE compiled_temp_1_294( CONT_PARAMS );
static RTYPE compiled_block_1_2259( CONT_PARAMS );
static RTYPE compiled_temp_1_292( CONT_PARAMS );
static RTYPE compiled_block_1_2257( CONT_PARAMS );
static RTYPE compiled_start_1_15( CONT_PARAMS );
static RTYPE compiled_block_1_2334( CONT_PARAMS );
static RTYPE compiled_block_1_2331( CONT_PARAMS );
static RTYPE compiled_block_1_2332( CONT_PARAMS );
static RTYPE compiled_block_1_2322( CONT_PARAMS );
static RTYPE compiled_block_1_2329( CONT_PARAMS );
static RTYPE compiled_block_1_2326( CONT_PARAMS );
static RTYPE compiled_block_1_2327( CONT_PARAMS );
static RTYPE compiled_block_1_2325( CONT_PARAMS );
static RTYPE compiled_block_1_2323( CONT_PARAMS );
static RTYPE compiled_block_1_2320( CONT_PARAMS );
static RTYPE compiled_start_1_299( CONT_PARAMS );
static RTYPE compiled_block_1_2314( CONT_PARAMS );
static RTYPE compiled_block_1_2311( CONT_PARAMS );
static RTYPE compiled_block_1_2312( CONT_PARAMS );
static RTYPE compiled_block_1_2302( CONT_PARAMS );
static RTYPE compiled_block_1_2309( CONT_PARAMS );
static RTYPE compiled_block_1_2306( CONT_PARAMS );
static RTYPE compiled_block_1_2307( CONT_PARAMS );
static RTYPE compiled_block_1_2305( CONT_PARAMS );
static RTYPE compiled_block_1_2303( CONT_PARAMS );
static RTYPE compiled_block_1_2300( CONT_PARAMS );
static RTYPE compiled_start_1_297( CONT_PARAMS );
static RTYPE compiled_start_1_295( CONT_PARAMS );
static RTYPE compiled_block_1_2294( CONT_PARAMS );
static RTYPE compiled_block_1_2291( CONT_PARAMS );
static RTYPE compiled_block_1_2292( CONT_PARAMS );
static RTYPE compiled_block_1_2282( CONT_PARAMS );
static RTYPE compiled_block_1_2289( CONT_PARAMS );
static RTYPE compiled_block_1_2286( CONT_PARAMS );
static RTYPE compiled_block_1_2287( CONT_PARAMS );
static RTYPE compiled_block_1_2285( CONT_PARAMS );
static RTYPE compiled_block_1_2283( CONT_PARAMS );
static RTYPE compiled_block_1_2280( CONT_PARAMS );
static RTYPE compiled_start_1_300( CONT_PARAMS );
static RTYPE compiled_start_1_293( CONT_PARAMS );
static RTYPE compiled_block_1_2274( CONT_PARAMS );
static RTYPE compiled_block_1_2271( CONT_PARAMS );
static RTYPE compiled_block_1_2272( CONT_PARAMS );
static RTYPE compiled_block_1_2262( CONT_PARAMS );
static RTYPE compiled_block_1_2269( CONT_PARAMS );
static RTYPE compiled_block_1_2266( CONT_PARAMS );
static RTYPE compiled_block_1_2267( CONT_PARAMS );
static RTYPE compiled_block_1_2265( CONT_PARAMS );
static RTYPE compiled_block_1_2263( CONT_PARAMS );
static RTYPE compiled_block_1_2260( CONT_PARAMS );
static RTYPE compiled_start_1_301( CONT_PARAMS );
static RTYPE compiled_block_1_2237( CONT_PARAMS );
static RTYPE compiled_temp_1_308( CONT_PARAMS );
static RTYPE compiled_block_1_2217( CONT_PARAMS );
static RTYPE compiled_temp_1_306( CONT_PARAMS );
static RTYPE compiled_block_1_2197( CONT_PARAMS );
static RTYPE compiled_temp_1_304( CONT_PARAMS );
static RTYPE compiled_block_1_2177( CONT_PARAMS );
static RTYPE compiled_temp_1_302( CONT_PARAMS );
static RTYPE compiled_block_1_2175( CONT_PARAMS );
static RTYPE compiled_start_1_14( CONT_PARAMS );
static RTYPE compiled_block_1_2252( CONT_PARAMS );
static RTYPE compiled_block_1_2242( CONT_PARAMS );
static RTYPE compiled_block_1_2249( CONT_PARAMS );
static RTYPE compiled_block_1_2247( CONT_PARAMS );
static RTYPE compiled_block_1_2244( CONT_PARAMS );
static RTYPE compiled_block_1_2245( CONT_PARAMS );
static RTYPE compiled_block_1_2243( CONT_PARAMS );
static RTYPE compiled_block_1_2239( CONT_PARAMS );
static RTYPE compiled_block_1_2240( CONT_PARAMS );
static RTYPE compiled_block_1_2238( CONT_PARAMS );
static RTYPE compiled_start_1_309( CONT_PARAMS );
static RTYPE compiled_block_1_2232( CONT_PARAMS );
static RTYPE compiled_block_1_2222( CONT_PARAMS );
static RTYPE compiled_block_1_2229( CONT_PARAMS );
static RTYPE compiled_block_1_2227( CONT_PARAMS );
static RTYPE compiled_block_1_2224( CONT_PARAMS );
static RTYPE compiled_block_1_2225( CONT_PARAMS );
static RTYPE compiled_block_1_2223( CONT_PARAMS );
static RTYPE compiled_block_1_2219( CONT_PARAMS );
static RTYPE compiled_block_1_2220( CONT_PARAMS );
static RTYPE compiled_block_1_2218( CONT_PARAMS );
static RTYPE compiled_start_1_307( CONT_PARAMS );
static RTYPE compiled_start_1_305( CONT_PARAMS );
static RTYPE compiled_block_1_2212( CONT_PARAMS );
static RTYPE compiled_block_1_2202( CONT_PARAMS );
static RTYPE compiled_block_1_2209( CONT_PARAMS );
static RTYPE compiled_block_1_2207( CONT_PARAMS );
static RTYPE compiled_block_1_2204( CONT_PARAMS );
static RTYPE compiled_block_1_2205( CONT_PARAMS );
static RTYPE compiled_block_1_2203( CONT_PARAMS );
static RTYPE compiled_block_1_2199( CONT_PARAMS );
static RTYPE compiled_block_1_2200( CONT_PARAMS );
static RTYPE compiled_block_1_2198( CONT_PARAMS );
static RTYPE compiled_start_1_310( CONT_PARAMS );
static RTYPE compiled_start_1_303( CONT_PARAMS );
static RTYPE compiled_block_1_2192( CONT_PARAMS );
static RTYPE compiled_block_1_2182( CONT_PARAMS );
static RTYPE compiled_block_1_2189( CONT_PARAMS );
static RTYPE compiled_block_1_2187( CONT_PARAMS );
static RTYPE compiled_block_1_2184( CONT_PARAMS );
static RTYPE compiled_block_1_2185( CONT_PARAMS );
static RTYPE compiled_block_1_2183( CONT_PARAMS );
static RTYPE compiled_block_1_2179( CONT_PARAMS );
static RTYPE compiled_block_1_2180( CONT_PARAMS );
static RTYPE compiled_block_1_2178( CONT_PARAMS );
static RTYPE compiled_start_1_311( CONT_PARAMS );
static RTYPE compiled_block_1_2155( CONT_PARAMS );
static RTYPE compiled_temp_1_318( CONT_PARAMS );
static RTYPE compiled_block_1_2135( CONT_PARAMS );
static RTYPE compiled_temp_1_316( CONT_PARAMS );
static RTYPE compiled_block_1_2115( CONT_PARAMS );
static RTYPE compiled_temp_1_314( CONT_PARAMS );
static RTYPE compiled_block_1_2095( CONT_PARAMS );
static RTYPE compiled_temp_1_312( CONT_PARAMS );
static RTYPE compiled_block_1_2093( CONT_PARAMS );
static RTYPE compiled_start_1_13( CONT_PARAMS );
static RTYPE compiled_block_1_2170( CONT_PARAMS );
static RTYPE compiled_block_1_2160( CONT_PARAMS );
static RTYPE compiled_block_1_2167( CONT_PARAMS );
static RTYPE compiled_block_1_2164( CONT_PARAMS );
static RTYPE compiled_block_1_2165( CONT_PARAMS );
static RTYPE compiled_block_1_2163( CONT_PARAMS );
static RTYPE compiled_block_1_2161( CONT_PARAMS );
static RTYPE compiled_block_1_2157( CONT_PARAMS );
static RTYPE compiled_block_1_2158( CONT_PARAMS );
static RTYPE compiled_block_1_2156( CONT_PARAMS );
static RTYPE compiled_start_1_319( CONT_PARAMS );
static RTYPE compiled_block_1_2150( CONT_PARAMS );
static RTYPE compiled_block_1_2140( CONT_PARAMS );
static RTYPE compiled_block_1_2147( CONT_PARAMS );
static RTYPE compiled_block_1_2144( CONT_PARAMS );
static RTYPE compiled_block_1_2145( CONT_PARAMS );
static RTYPE compiled_block_1_2143( CONT_PARAMS );
static RTYPE compiled_block_1_2141( CONT_PARAMS );
static RTYPE compiled_block_1_2137( CONT_PARAMS );
static RTYPE compiled_block_1_2138( CONT_PARAMS );
static RTYPE compiled_block_1_2136( CONT_PARAMS );
static RTYPE compiled_start_1_317( CONT_PARAMS );
static RTYPE compiled_start_1_315( CONT_PARAMS );
static RTYPE compiled_block_1_2130( CONT_PARAMS );
static RTYPE compiled_block_1_2120( CONT_PARAMS );
static RTYPE compiled_block_1_2127( CONT_PARAMS );
static RTYPE compiled_block_1_2124( CONT_PARAMS );
static RTYPE compiled_block_1_2125( CONT_PARAMS );
static RTYPE compiled_block_1_2123( CONT_PARAMS );
static RTYPE compiled_block_1_2121( CONT_PARAMS );
static RTYPE compiled_block_1_2117( CONT_PARAMS );
static RTYPE compiled_block_1_2118( CONT_PARAMS );
static RTYPE compiled_block_1_2116( CONT_PARAMS );
static RTYPE compiled_start_1_320( CONT_PARAMS );
static RTYPE compiled_start_1_313( CONT_PARAMS );
static RTYPE compiled_block_1_2110( CONT_PARAMS );
static RTYPE compiled_block_1_2100( CONT_PARAMS );
static RTYPE compiled_block_1_2107( CONT_PARAMS );
static RTYPE compiled_block_1_2104( CONT_PARAMS );
static RTYPE compiled_block_1_2105( CONT_PARAMS );
static RTYPE compiled_block_1_2103( CONT_PARAMS );
static RTYPE compiled_block_1_2101( CONT_PARAMS );
static RTYPE compiled_block_1_2097( CONT_PARAMS );
static RTYPE compiled_block_1_2098( CONT_PARAMS );
static RTYPE compiled_block_1_2096( CONT_PARAMS );
static RTYPE compiled_start_1_321( CONT_PARAMS );
static RTYPE compiled_block_1_2073( CONT_PARAMS );
static RTYPE compiled_temp_1_328( CONT_PARAMS );
static RTYPE compiled_block_1_2053( CONT_PARAMS );
static RTYPE compiled_temp_1_326( CONT_PARAMS );
static RTYPE compiled_block_1_2033( CONT_PARAMS );
static RTYPE compiled_temp_1_324( CONT_PARAMS );
static RTYPE compiled_block_1_2013( CONT_PARAMS );
static RTYPE compiled_temp_1_322( CONT_PARAMS );
static RTYPE compiled_block_1_2011( CONT_PARAMS );
static RTYPE compiled_start_1_12( CONT_PARAMS );
static RTYPE compiled_block_1_2088( CONT_PARAMS );
static RTYPE compiled_block_1_2085( CONT_PARAMS );
static RTYPE compiled_block_1_2086( CONT_PARAMS );
static RTYPE compiled_block_1_2076( CONT_PARAMS );
static RTYPE compiled_block_1_2083( CONT_PARAMS );
static RTYPE compiled_block_1_2081( CONT_PARAMS );
static RTYPE compiled_block_1_2078( CONT_PARAMS );
static RTYPE compiled_block_1_2079( CONT_PARAMS );
static RTYPE compiled_block_1_2077( CONT_PARAMS );
static RTYPE compiled_block_1_2074( CONT_PARAMS );
static RTYPE compiled_start_1_329( CONT_PARAMS );
static RTYPE compiled_block_1_2068( CONT_PARAMS );
static RTYPE compiled_block_1_2065( CONT_PARAMS );
static RTYPE compiled_block_1_2066( CONT_PARAMS );
static RTYPE compiled_block_1_2056( CONT_PARAMS );
static RTYPE compiled_block_1_2063( CONT_PARAMS );
static RTYPE compiled_block_1_2061( CONT_PARAMS );
static RTYPE compiled_block_1_2058( CONT_PARAMS );
static RTYPE compiled_block_1_2059( CONT_PARAMS );
static RTYPE compiled_block_1_2057( CONT_PARAMS );
static RTYPE compiled_block_1_2054( CONT_PARAMS );
static RTYPE compiled_start_1_327( CONT_PARAMS );
static RTYPE compiled_start_1_325( CONT_PARAMS );
static RTYPE compiled_block_1_2048( CONT_PARAMS );
static RTYPE compiled_block_1_2045( CONT_PARAMS );
static RTYPE compiled_block_1_2046( CONT_PARAMS );
static RTYPE compiled_block_1_2036( CONT_PARAMS );
static RTYPE compiled_block_1_2043( CONT_PARAMS );
static RTYPE compiled_block_1_2041( CONT_PARAMS );
static RTYPE compiled_block_1_2038( CONT_PARAMS );
static RTYPE compiled_block_1_2039( CONT_PARAMS );
static RTYPE compiled_block_1_2037( CONT_PARAMS );
static RTYPE compiled_block_1_2034( CONT_PARAMS );
static RTYPE compiled_start_1_330( CONT_PARAMS );
static RTYPE compiled_start_1_323( CONT_PARAMS );
static RTYPE compiled_block_1_2028( CONT_PARAMS );
static RTYPE compiled_block_1_2025( CONT_PARAMS );
static RTYPE compiled_block_1_2026( CONT_PARAMS );
static RTYPE compiled_block_1_2016( CONT_PARAMS );
static RTYPE compiled_block_1_2023( CONT_PARAMS );
static RTYPE compiled_block_1_2021( CONT_PARAMS );
static RTYPE compiled_block_1_2018( CONT_PARAMS );
static RTYPE compiled_block_1_2019( CONT_PARAMS );
static RTYPE compiled_block_1_2017( CONT_PARAMS );
static RTYPE compiled_block_1_2014( CONT_PARAMS );
static RTYPE compiled_start_1_331( CONT_PARAMS );
static RTYPE compiled_block_1_1991( CONT_PARAMS );
static RTYPE compiled_temp_1_338( CONT_PARAMS );
static RTYPE compiled_block_1_1971( CONT_PARAMS );
static RTYPE compiled_temp_1_336( CONT_PARAMS );
static RTYPE compiled_block_1_1951( CONT_PARAMS );
static RTYPE compiled_temp_1_334( CONT_PARAMS );
static RTYPE compiled_block_1_1931( CONT_PARAMS );
static RTYPE compiled_temp_1_332( CONT_PARAMS );
static RTYPE compiled_block_1_1929( CONT_PARAMS );
static RTYPE compiled_start_1_11( CONT_PARAMS );
static RTYPE compiled_block_1_2006( CONT_PARAMS );
static RTYPE compiled_block_1_2003( CONT_PARAMS );
static RTYPE compiled_block_1_2004( CONT_PARAMS );
static RTYPE compiled_block_1_1994( CONT_PARAMS );
static RTYPE compiled_block_1_2001( CONT_PARAMS );
static RTYPE compiled_block_1_1998( CONT_PARAMS );
static RTYPE compiled_block_1_1999( CONT_PARAMS );
static RTYPE compiled_block_1_1997( CONT_PARAMS );
static RTYPE compiled_block_1_1995( CONT_PARAMS );
static RTYPE compiled_block_1_1992( CONT_PARAMS );
static RTYPE compiled_start_1_339( CONT_PARAMS );
static RTYPE compiled_block_1_1986( CONT_PARAMS );
static RTYPE compiled_block_1_1983( CONT_PARAMS );
static RTYPE compiled_block_1_1984( CONT_PARAMS );
static RTYPE compiled_block_1_1974( CONT_PARAMS );
static RTYPE compiled_block_1_1981( CONT_PARAMS );
static RTYPE compiled_block_1_1978( CONT_PARAMS );
static RTYPE compiled_block_1_1979( CONT_PARAMS );
static RTYPE compiled_block_1_1977( CONT_PARAMS );
static RTYPE compiled_block_1_1975( CONT_PARAMS );
static RTYPE compiled_block_1_1972( CONT_PARAMS );
static RTYPE compiled_start_1_337( CONT_PARAMS );
static RTYPE compiled_start_1_335( CONT_PARAMS );
static RTYPE compiled_block_1_1966( CONT_PARAMS );
static RTYPE compiled_block_1_1963( CONT_PARAMS );
static RTYPE compiled_block_1_1964( CONT_PARAMS );
static RTYPE compiled_block_1_1954( CONT_PARAMS );
static RTYPE compiled_block_1_1961( CONT_PARAMS );
static RTYPE compiled_block_1_1958( CONT_PARAMS );
static RTYPE compiled_block_1_1959( CONT_PARAMS );
static RTYPE compiled_block_1_1957( CONT_PARAMS );
static RTYPE compiled_block_1_1955( CONT_PARAMS );
static RTYPE compiled_block_1_1952( CONT_PARAMS );
static RTYPE compiled_start_1_340( CONT_PARAMS );
static RTYPE compiled_start_1_333( CONT_PARAMS );
static RTYPE compiled_block_1_1946( CONT_PARAMS );
static RTYPE compiled_block_1_1943( CONT_PARAMS );
static RTYPE compiled_block_1_1944( CONT_PARAMS );
static RTYPE compiled_block_1_1934( CONT_PARAMS );
static RTYPE compiled_block_1_1941( CONT_PARAMS );
static RTYPE compiled_block_1_1938( CONT_PARAMS );
static RTYPE compiled_block_1_1939( CONT_PARAMS );
static RTYPE compiled_block_1_1937( CONT_PARAMS );
static RTYPE compiled_block_1_1935( CONT_PARAMS );
static RTYPE compiled_block_1_1932( CONT_PARAMS );
static RTYPE compiled_start_1_341( CONT_PARAMS );
static RTYPE compiled_block_1_1915( CONT_PARAMS );
static RTYPE compiled_temp_1_348( CONT_PARAMS );
static RTYPE compiled_block_1_1904( CONT_PARAMS );
static RTYPE compiled_temp_1_346( CONT_PARAMS );
static RTYPE compiled_block_1_1893( CONT_PARAMS );
static RTYPE compiled_temp_1_344( CONT_PARAMS );
static RTYPE compiled_block_1_1882( CONT_PARAMS );
static RTYPE compiled_temp_1_342( CONT_PARAMS );
static RTYPE compiled_block_1_1880( CONT_PARAMS );
static RTYPE compiled_start_1_10( CONT_PARAMS );
static RTYPE compiled_block_1_1917( CONT_PARAMS );
static RTYPE compiled_block_1_1924( CONT_PARAMS );
static RTYPE compiled_block_1_1922( CONT_PARAMS );
static RTYPE compiled_block_1_1919( CONT_PARAMS );
static RTYPE compiled_block_1_1920( CONT_PARAMS );
static RTYPE compiled_block_1_1918( CONT_PARAMS );
static RTYPE compiled_start_1_349( CONT_PARAMS );
static RTYPE compiled_block_1_1911( CONT_PARAMS );
static RTYPE compiled_block_1_1909( CONT_PARAMS );
static RTYPE compiled_block_1_1906( CONT_PARAMS );
static RTYPE compiled_block_1_1907( CONT_PARAMS );
static RTYPE compiled_block_1_1905( CONT_PARAMS );
static RTYPE compiled_start_1_347( CONT_PARAMS );
static RTYPE compiled_start_1_345( CONT_PARAMS );
static RTYPE compiled_block_1_1900( CONT_PARAMS );
static RTYPE compiled_block_1_1898( CONT_PARAMS );
static RTYPE compiled_block_1_1895( CONT_PARAMS );
static RTYPE compiled_block_1_1896( CONT_PARAMS );
static RTYPE compiled_block_1_1894( CONT_PARAMS );
static RTYPE compiled_start_1_350( CONT_PARAMS );
static RTYPE compiled_start_1_343( CONT_PARAMS );
static RTYPE compiled_block_1_1889( CONT_PARAMS );
static RTYPE compiled_block_1_1887( CONT_PARAMS );
static RTYPE compiled_block_1_1884( CONT_PARAMS );
static RTYPE compiled_block_1_1885( CONT_PARAMS );
static RTYPE compiled_block_1_1883( CONT_PARAMS );
static RTYPE compiled_start_1_351( CONT_PARAMS );
static RTYPE compiled_block_1_1866( CONT_PARAMS );
static RTYPE compiled_temp_1_358( CONT_PARAMS );
static RTYPE compiled_block_1_1855( CONT_PARAMS );
static RTYPE compiled_temp_1_356( CONT_PARAMS );
static RTYPE compiled_block_1_1844( CONT_PARAMS );
static RTYPE compiled_temp_1_354( CONT_PARAMS );
static RTYPE compiled_block_1_1833( CONT_PARAMS );
static RTYPE compiled_temp_1_352( CONT_PARAMS );
static RTYPE compiled_block_1_1831( CONT_PARAMS );
static RTYPE compiled_start_1_9( CONT_PARAMS );
static RTYPE compiled_block_1_1868( CONT_PARAMS );
static RTYPE compiled_block_1_1875( CONT_PARAMS );
static RTYPE compiled_block_1_1873( CONT_PARAMS );
static RTYPE compiled_block_1_1870( CONT_PARAMS );
static RTYPE compiled_block_1_1871( CONT_PARAMS );
static RTYPE compiled_block_1_1869( CONT_PARAMS );
static RTYPE compiled_start_1_359( CONT_PARAMS );
static RTYPE compiled_block_1_1862( CONT_PARAMS );
static RTYPE compiled_block_1_1860( CONT_PARAMS );
static RTYPE compiled_block_1_1857( CONT_PARAMS );
static RTYPE compiled_block_1_1858( CONT_PARAMS );
static RTYPE compiled_block_1_1856( CONT_PARAMS );
static RTYPE compiled_start_1_357( CONT_PARAMS );
static RTYPE compiled_start_1_355( CONT_PARAMS );
static RTYPE compiled_block_1_1851( CONT_PARAMS );
static RTYPE compiled_block_1_1849( CONT_PARAMS );
static RTYPE compiled_block_1_1846( CONT_PARAMS );
static RTYPE compiled_block_1_1847( CONT_PARAMS );
static RTYPE compiled_block_1_1845( CONT_PARAMS );
static RTYPE compiled_start_1_360( CONT_PARAMS );
static RTYPE compiled_start_1_353( CONT_PARAMS );
static RTYPE compiled_block_1_1840( CONT_PARAMS );
static RTYPE compiled_block_1_1838( CONT_PARAMS );
static RTYPE compiled_block_1_1835( CONT_PARAMS );
static RTYPE compiled_block_1_1836( CONT_PARAMS );
static RTYPE compiled_block_1_1834( CONT_PARAMS );
static RTYPE compiled_start_1_361( CONT_PARAMS );
static RTYPE compiled_block_1_1817( CONT_PARAMS );
static RTYPE compiled_temp_1_368( CONT_PARAMS );
static RTYPE compiled_block_1_1806( CONT_PARAMS );
static RTYPE compiled_temp_1_366( CONT_PARAMS );
static RTYPE compiled_block_1_1795( CONT_PARAMS );
static RTYPE compiled_temp_1_364( CONT_PARAMS );
static RTYPE compiled_block_1_1784( CONT_PARAMS );
static RTYPE compiled_temp_1_362( CONT_PARAMS );
static RTYPE compiled_block_1_1782( CONT_PARAMS );
static RTYPE compiled_start_1_8( CONT_PARAMS );
static RTYPE compiled_block_1_1819( CONT_PARAMS );
static RTYPE compiled_block_1_1826( CONT_PARAMS );
static RTYPE compiled_block_1_1824( CONT_PARAMS );
static RTYPE compiled_block_1_1821( CONT_PARAMS );
static RTYPE compiled_block_1_1822( CONT_PARAMS );
static RTYPE compiled_block_1_1820( CONT_PARAMS );
static RTYPE compiled_start_1_369( CONT_PARAMS );
static RTYPE compiled_block_1_1813( CONT_PARAMS );
static RTYPE compiled_block_1_1811( CONT_PARAMS );
static RTYPE compiled_block_1_1808( CONT_PARAMS );
static RTYPE compiled_block_1_1809( CONT_PARAMS );
static RTYPE compiled_block_1_1807( CONT_PARAMS );
static RTYPE compiled_start_1_367( CONT_PARAMS );
static RTYPE compiled_start_1_365( CONT_PARAMS );
static RTYPE compiled_block_1_1802( CONT_PARAMS );
static RTYPE compiled_block_1_1800( CONT_PARAMS );
static RTYPE compiled_block_1_1797( CONT_PARAMS );
static RTYPE compiled_block_1_1798( CONT_PARAMS );
static RTYPE compiled_block_1_1796( CONT_PARAMS );
static RTYPE compiled_start_1_370( CONT_PARAMS );
static RTYPE compiled_start_1_363( CONT_PARAMS );
static RTYPE compiled_block_1_1791( CONT_PARAMS );
static RTYPE compiled_block_1_1789( CONT_PARAMS );
static RTYPE compiled_block_1_1786( CONT_PARAMS );
static RTYPE compiled_block_1_1787( CONT_PARAMS );
static RTYPE compiled_block_1_1785( CONT_PARAMS );
static RTYPE compiled_start_1_371( CONT_PARAMS );
static RTYPE compiled_block_1_1768( CONT_PARAMS );
static RTYPE compiled_temp_1_378( CONT_PARAMS );
static RTYPE compiled_block_1_1757( CONT_PARAMS );
static RTYPE compiled_temp_1_376( CONT_PARAMS );
static RTYPE compiled_block_1_1746( CONT_PARAMS );
static RTYPE compiled_temp_1_374( CONT_PARAMS );
static RTYPE compiled_block_1_1735( CONT_PARAMS );
static RTYPE compiled_temp_1_372( CONT_PARAMS );
static RTYPE compiled_block_1_1733( CONT_PARAMS );
static RTYPE compiled_start_1_7( CONT_PARAMS );
static RTYPE compiled_block_1_1770( CONT_PARAMS );
static RTYPE compiled_block_1_1777( CONT_PARAMS );
static RTYPE compiled_block_1_1774( CONT_PARAMS );
static RTYPE compiled_block_1_1775( CONT_PARAMS );
static RTYPE compiled_block_1_1773( CONT_PARAMS );
static RTYPE compiled_block_1_1771( CONT_PARAMS );
static RTYPE compiled_start_1_379( CONT_PARAMS );
static RTYPE compiled_block_1_1764( CONT_PARAMS );
static RTYPE compiled_block_1_1761( CONT_PARAMS );
static RTYPE compiled_block_1_1762( CONT_PARAMS );
static RTYPE compiled_block_1_1760( CONT_PARAMS );
static RTYPE compiled_block_1_1758( CONT_PARAMS );
static RTYPE compiled_start_1_377( CONT_PARAMS );
static RTYPE compiled_start_1_375( CONT_PARAMS );
static RTYPE compiled_block_1_1753( CONT_PARAMS );
static RTYPE compiled_block_1_1750( CONT_PARAMS );
static RTYPE compiled_block_1_1751( CONT_PARAMS );
static RTYPE compiled_block_1_1749( CONT_PARAMS );
static RTYPE compiled_block_1_1747( CONT_PARAMS );
static RTYPE compiled_start_1_380( CONT_PARAMS );
static RTYPE compiled_start_1_373( CONT_PARAMS );
static RTYPE compiled_block_1_1742( CONT_PARAMS );
static RTYPE compiled_block_1_1739( CONT_PARAMS );
static RTYPE compiled_block_1_1740( CONT_PARAMS );
static RTYPE compiled_block_1_1738( CONT_PARAMS );
static RTYPE compiled_block_1_1736( CONT_PARAMS );
static RTYPE compiled_start_1_381( CONT_PARAMS );
static RTYPE compiled_block_1_1719( CONT_PARAMS );
static RTYPE compiled_temp_1_388( CONT_PARAMS );
static RTYPE compiled_block_1_1708( CONT_PARAMS );
static RTYPE compiled_temp_1_386( CONT_PARAMS );
static RTYPE compiled_block_1_1697( CONT_PARAMS );
static RTYPE compiled_temp_1_384( CONT_PARAMS );
static RTYPE compiled_block_1_1686( CONT_PARAMS );
static RTYPE compiled_temp_1_382( CONT_PARAMS );
static RTYPE compiled_block_1_1684( CONT_PARAMS );
static RTYPE compiled_start_1_6( CONT_PARAMS );
static RTYPE compiled_block_1_1721( CONT_PARAMS );
static RTYPE compiled_block_1_1728( CONT_PARAMS );
static RTYPE compiled_block_1_1725( CONT_PARAMS );
static RTYPE compiled_block_1_1726( CONT_PARAMS );
static RTYPE compiled_block_1_1724( CONT_PARAMS );
static RTYPE compiled_block_1_1722( CONT_PARAMS );
static RTYPE compiled_start_1_389( CONT_PARAMS );
static RTYPE compiled_block_1_1715( CONT_PARAMS );
static RTYPE compiled_block_1_1712( CONT_PARAMS );
static RTYPE compiled_block_1_1713( CONT_PARAMS );
static RTYPE compiled_block_1_1711( CONT_PARAMS );
static RTYPE compiled_block_1_1709( CONT_PARAMS );
static RTYPE compiled_start_1_387( CONT_PARAMS );
static RTYPE compiled_start_1_385( CONT_PARAMS );
static RTYPE compiled_block_1_1704( CONT_PARAMS );
static RTYPE compiled_block_1_1701( CONT_PARAMS );
static RTYPE compiled_block_1_1702( CONT_PARAMS );
static RTYPE compiled_block_1_1700( CONT_PARAMS );
static RTYPE compiled_block_1_1698( CONT_PARAMS );
static RTYPE compiled_start_1_390( CONT_PARAMS );
static RTYPE compiled_start_1_383( CONT_PARAMS );
static RTYPE compiled_block_1_1693( CONT_PARAMS );
static RTYPE compiled_block_1_1690( CONT_PARAMS );
static RTYPE compiled_block_1_1691( CONT_PARAMS );
static RTYPE compiled_block_1_1689( CONT_PARAMS );
static RTYPE compiled_block_1_1687( CONT_PARAMS );
static RTYPE compiled_start_1_391( CONT_PARAMS );
static RTYPE compiled_block_1_1670( CONT_PARAMS );
static RTYPE compiled_temp_1_398( CONT_PARAMS );
static RTYPE compiled_block_1_1659( CONT_PARAMS );
static RTYPE compiled_temp_1_396( CONT_PARAMS );
static RTYPE compiled_block_1_1648( CONT_PARAMS );
static RTYPE compiled_temp_1_394( CONT_PARAMS );
static RTYPE compiled_block_1_1637( CONT_PARAMS );
static RTYPE compiled_temp_1_392( CONT_PARAMS );
static RTYPE compiled_block_1_1635( CONT_PARAMS );
static RTYPE compiled_start_1_5( CONT_PARAMS );
static RTYPE compiled_block_1_1672( CONT_PARAMS );
static RTYPE compiled_block_1_1679( CONT_PARAMS );
static RTYPE compiled_block_1_1676( CONT_PARAMS );
static RTYPE compiled_block_1_1677( CONT_PARAMS );
static RTYPE compiled_block_1_1675( CONT_PARAMS );
static RTYPE compiled_block_1_1673( CONT_PARAMS );
static RTYPE compiled_start_1_399( CONT_PARAMS );
static RTYPE compiled_block_1_1666( CONT_PARAMS );
static RTYPE compiled_block_1_1663( CONT_PARAMS );
static RTYPE compiled_block_1_1664( CONT_PARAMS );
static RTYPE compiled_block_1_1662( CONT_PARAMS );
static RTYPE compiled_block_1_1660( CONT_PARAMS );
static RTYPE compiled_start_1_397( CONT_PARAMS );
static RTYPE compiled_start_1_395( CONT_PARAMS );
static RTYPE compiled_block_1_1655( CONT_PARAMS );
static RTYPE compiled_block_1_1652( CONT_PARAMS );
static RTYPE compiled_block_1_1653( CONT_PARAMS );
static RTYPE compiled_block_1_1651( CONT_PARAMS );
static RTYPE compiled_block_1_1649( CONT_PARAMS );
static RTYPE compiled_start_1_400( CONT_PARAMS );
static RTYPE compiled_start_1_393( CONT_PARAMS );
static RTYPE compiled_block_1_1644( CONT_PARAMS );
static RTYPE compiled_block_1_1641( CONT_PARAMS );
static RTYPE compiled_block_1_1642( CONT_PARAMS );
static RTYPE compiled_block_1_1640( CONT_PARAMS );
static RTYPE compiled_block_1_1638( CONT_PARAMS );
static RTYPE compiled_start_1_401( CONT_PARAMS );
static RTYPE compiled_block_1_1634( CONT_PARAMS );
static RTYPE compiled_start_1_4( CONT_PARAMS );
static RTYPE compiled_start_1_402( CONT_PARAMS );
static RTYPE compiled_block_1_1631( CONT_PARAMS );
static RTYPE compiled_block_1_1584( CONT_PARAMS );
static RTYPE compiled_block_1_1541( CONT_PARAMS );
static RTYPE compiled_block_1_1469( CONT_PARAMS );
static RTYPE compiled_block_1_1346( CONT_PARAMS );
static RTYPE compiled_block_1_1312( CONT_PARAMS );
static RTYPE compiled_block_1_1238( CONT_PARAMS );
static RTYPE compiled_block_1_1168( CONT_PARAMS );
static RTYPE compiled_block_1_1124( CONT_PARAMS );
static RTYPE compiled_block_1_1115( CONT_PARAMS );
static RTYPE compiled_block_1_1106( CONT_PARAMS );
static RTYPE compiled_block_1_1097( CONT_PARAMS );
static RTYPE compiled_block_1_1088( CONT_PARAMS );
static RTYPE compiled_block_1_1079( CONT_PARAMS );
static RTYPE compiled_block_1_1070( CONT_PARAMS );
static RTYPE compiled_block_1_1023( CONT_PARAMS );
static RTYPE compiled_start_1_2( CONT_PARAMS );
static RTYPE compiled_block_1_1586( CONT_PARAMS );
static RTYPE compiled_block_1_1588( CONT_PARAMS );
static RTYPE compiled_block_1_1590( CONT_PARAMS );
static RTYPE compiled_block_1_1592( CONT_PARAMS );
static RTYPE compiled_block_1_1594( CONT_PARAMS );
static RTYPE compiled_block_1_1596( CONT_PARAMS );
static RTYPE compiled_block_1_1598( CONT_PARAMS );
static RTYPE compiled_block_1_1623( CONT_PARAMS );
static RTYPE compiled_block_1_1622( CONT_PARAMS );
static RTYPE compiled_block_1_1621( CONT_PARAMS );
static RTYPE compiled_block_1_1620( CONT_PARAMS );
static RTYPE compiled_block_1_1619( CONT_PARAMS );
static RTYPE compiled_block_1_1618( CONT_PARAMS );
static RTYPE compiled_block_1_1617( CONT_PARAMS );
static RTYPE compiled_block_1_1616( CONT_PARAMS );
static RTYPE compiled_block_1_1615( CONT_PARAMS );
static RTYPE compiled_block_1_1614( CONT_PARAMS );
static RTYPE compiled_block_1_1613( CONT_PARAMS );
static RTYPE compiled_block_1_1612( CONT_PARAMS );
static RTYPE compiled_block_1_1611( CONT_PARAMS );
static RTYPE compiled_block_1_1610( CONT_PARAMS );
static RTYPE compiled_block_1_1609( CONT_PARAMS );
static RTYPE compiled_block_1_1608( CONT_PARAMS );
static RTYPE compiled_block_1_1607( CONT_PARAMS );
static RTYPE compiled_block_1_1606( CONT_PARAMS );
static RTYPE compiled_block_1_1605( CONT_PARAMS );
static RTYPE compiled_block_1_1604( CONT_PARAMS );
static RTYPE compiled_block_1_1603( CONT_PARAMS );
static RTYPE compiled_block_1_1602( CONT_PARAMS );
static RTYPE compiled_block_1_1601( CONT_PARAMS );
static RTYPE compiled_block_1_1600( CONT_PARAMS );
static RTYPE compiled_block_1_1599( CONT_PARAMS );
static RTYPE compiled_start_1_418( CONT_PARAMS );
static RTYPE compiled_block_1_1564( CONT_PARAMS );
static RTYPE compiled_block_1_1566( CONT_PARAMS );
static RTYPE compiled_block_1_1568( CONT_PARAMS );
static RTYPE compiled_block_1_1570( CONT_PARAMS );
static RTYPE compiled_block_1_1572( CONT_PARAMS );
static RTYPE compiled_block_1_1574( CONT_PARAMS );
static RTYPE compiled_block_1_1577( CONT_PARAMS );
static RTYPE compiled_block_1_1576( CONT_PARAMS );
static RTYPE compiled_block_1_1575( CONT_PARAMS );
static RTYPE compiled_block_1_1542( CONT_PARAMS );
static RTYPE compiled_block_1_1545( CONT_PARAMS );
static RTYPE compiled_block_1_1547( CONT_PARAMS );
static RTYPE compiled_block_1_1549( CONT_PARAMS );
static RTYPE compiled_block_1_1551( CONT_PARAMS );
static RTYPE compiled_block_1_1553( CONT_PARAMS );
static RTYPE compiled_block_1_1557( CONT_PARAMS );
static RTYPE compiled_block_1_1556( CONT_PARAMS );
static RTYPE compiled_block_1_1555( CONT_PARAMS );
static RTYPE compiled_block_1_1554( CONT_PARAMS );
static RTYPE compiled_start_1_417( CONT_PARAMS );
static RTYPE compiled_block_1_1517( CONT_PARAMS );
static RTYPE compiled_block_1_1519( CONT_PARAMS );
static RTYPE compiled_block_1_1521( CONT_PARAMS );
static RTYPE compiled_block_1_1528( CONT_PARAMS );
static RTYPE compiled_block_1_1531( CONT_PARAMS );
static RTYPE compiled_block_1_1533( CONT_PARAMS );
static RTYPE compiled_block_1_1534( CONT_PARAMS );
static RTYPE compiled_block_1_1529( CONT_PARAMS );
static RTYPE compiled_block_1_1523( CONT_PARAMS );
static RTYPE compiled_block_1_1524( CONT_PARAMS );
static RTYPE compiled_block_1_1526( CONT_PARAMS );
static RTYPE compiled_block_1_1525( CONT_PARAMS );
static RTYPE compiled_block_1_1522( CONT_PARAMS );
static RTYPE compiled_block_1_1471( CONT_PARAMS );
static RTYPE compiled_block_1_1480( CONT_PARAMS );
static RTYPE compiled_block_1_1482( CONT_PARAMS );
static RTYPE compiled_block_1_1484( CONT_PARAMS );
static RTYPE compiled_block_1_1486( CONT_PARAMS );
static RTYPE compiled_block_1_1488( CONT_PARAMS );
static RTYPE compiled_block_1_1490( CONT_PARAMS );
static RTYPE compiled_block_1_1493( CONT_PARAMS );
static RTYPE compiled_block_1_1496( CONT_PARAMS );
static RTYPE compiled_block_1_1507( CONT_PARAMS );
static RTYPE compiled_block_1_1506( CONT_PARAMS );
static RTYPE compiled_block_1_1505( CONT_PARAMS );
static RTYPE compiled_block_1_1504( CONT_PARAMS );
static RTYPE compiled_block_1_1503( CONT_PARAMS );
static RTYPE compiled_block_1_1502( CONT_PARAMS );
static RTYPE compiled_block_1_1501( CONT_PARAMS );
static RTYPE compiled_block_1_1500( CONT_PARAMS );
static RTYPE compiled_block_1_1499( CONT_PARAMS );
static RTYPE compiled_block_1_1498( CONT_PARAMS );
static RTYPE compiled_block_1_1497( CONT_PARAMS );
static RTYPE compiled_block_1_1494( CONT_PARAMS );
static RTYPE compiled_block_1_1491( CONT_PARAMS );
static RTYPE compiled_block_1_1470( CONT_PARAMS );
static RTYPE compiled_block_1_1474( CONT_PARAMS );
static RTYPE compiled_block_1_1476( CONT_PARAMS );
static RTYPE compiled_start_1_416( CONT_PARAMS );
static RTYPE compiled_block_1_1452( CONT_PARAMS );
static RTYPE compiled_block_1_1454( CONT_PARAMS );
static RTYPE compiled_block_1_1456( CONT_PARAMS );
static RTYPE compiled_block_1_1458( CONT_PARAMS );
static RTYPE compiled_block_1_1460( CONT_PARAMS );
static RTYPE compiled_block_1_1462( CONT_PARAMS );
static RTYPE compiled_block_1_1349( CONT_PARAMS );
static RTYPE compiled_block_1_1415( CONT_PARAMS );
static RTYPE compiled_block_1_1417( CONT_PARAMS );
static RTYPE compiled_block_1_1419( CONT_PARAMS );
static RTYPE compiled_block_1_1421( CONT_PARAMS );
static RTYPE compiled_block_1_1423( CONT_PARAMS );
static RTYPE compiled_block_1_1425( CONT_PARAMS );
static RTYPE compiled_block_1_1432( CONT_PARAMS );
static RTYPE compiled_block_1_1435( CONT_PARAMS );
static RTYPE compiled_block_1_1437( CONT_PARAMS );
static RTYPE compiled_block_1_1439( CONT_PARAMS );
static RTYPE compiled_block_1_1440( CONT_PARAMS );
static RTYPE compiled_block_1_1433( CONT_PARAMS );
static RTYPE compiled_block_1_1427( CONT_PARAMS );
static RTYPE compiled_block_1_1428( CONT_PARAMS );
static RTYPE compiled_block_1_1430( CONT_PARAMS );
static RTYPE compiled_block_1_1429( CONT_PARAMS );
static RTYPE compiled_block_1_1426( CONT_PARAMS );
static RTYPE compiled_block_1_1348( CONT_PARAMS );
static RTYPE compiled_block_1_1371( CONT_PARAMS );
static RTYPE compiled_block_1_1373( CONT_PARAMS );
static RTYPE compiled_block_1_1375( CONT_PARAMS );
static RTYPE compiled_block_1_1377( CONT_PARAMS );
static RTYPE compiled_block_1_1379( CONT_PARAMS );
static RTYPE compiled_block_1_1381( CONT_PARAMS );
static RTYPE compiled_block_1_1384( CONT_PARAMS );
static RTYPE compiled_block_1_1387( CONT_PARAMS );
static RTYPE compiled_block_1_1389( CONT_PARAMS );
static RTYPE compiled_block_1_1404( CONT_PARAMS );
static RTYPE compiled_block_1_1403( CONT_PARAMS );
static RTYPE compiled_block_1_1402( CONT_PARAMS );
static RTYPE compiled_block_1_1401( CONT_PARAMS );
static RTYPE compiled_block_1_1400( CONT_PARAMS );
static RTYPE compiled_block_1_1399( CONT_PARAMS );
static RTYPE compiled_block_1_1398( CONT_PARAMS );
static RTYPE compiled_block_1_1397( CONT_PARAMS );
static RTYPE compiled_block_1_1396( CONT_PARAMS );
static RTYPE compiled_block_1_1395( CONT_PARAMS );
static RTYPE compiled_block_1_1394( CONT_PARAMS );
static RTYPE compiled_block_1_1393( CONT_PARAMS );
static RTYPE compiled_block_1_1392( CONT_PARAMS );
static RTYPE compiled_block_1_1391( CONT_PARAMS );
static RTYPE compiled_block_1_1390( CONT_PARAMS );
static RTYPE compiled_block_1_1385( CONT_PARAMS );
static RTYPE compiled_block_1_1382( CONT_PARAMS );
static RTYPE compiled_block_1_1347( CONT_PARAMS );
static RTYPE compiled_block_1_1352( CONT_PARAMS );
static RTYPE compiled_block_1_1354( CONT_PARAMS );
static RTYPE compiled_block_1_1356( CONT_PARAMS );
static RTYPE compiled_block_1_1359( CONT_PARAMS );
static RTYPE compiled_block_1_1365( CONT_PARAMS );
static RTYPE compiled_block_1_1364( CONT_PARAMS );
static RTYPE compiled_block_1_1363( CONT_PARAMS );
static RTYPE compiled_block_1_1362( CONT_PARAMS );
static RTYPE compiled_block_1_1361( CONT_PARAMS );
static RTYPE compiled_block_1_1360( CONT_PARAMS );
static RTYPE compiled_block_1_1357( CONT_PARAMS );
static RTYPE compiled_start_1_415( CONT_PARAMS );
static RTYPE compiled_block_1_1338( CONT_PARAMS );
static RTYPE compiled_block_1_1340( CONT_PARAMS );
static RTYPE compiled_block_1_1342( CONT_PARAMS );
static RTYPE compiled_block_1_1314( CONT_PARAMS );
static RTYPE compiled_block_1_1323( CONT_PARAMS );
static RTYPE compiled_block_1_1325( CONT_PARAMS );
static RTYPE compiled_block_1_1327( CONT_PARAMS );
static RTYPE compiled_block_1_1330( CONT_PARAMS );
static RTYPE compiled_block_1_1332( CONT_PARAMS );
static RTYPE compiled_block_1_1331( CONT_PARAMS );
static RTYPE compiled_block_1_1328( CONT_PARAMS );
static RTYPE compiled_block_1_1313( CONT_PARAMS );
static RTYPE compiled_block_1_1317( CONT_PARAMS );
static RTYPE compiled_block_1_1319( CONT_PARAMS );
static RTYPE compiled_start_1_414( CONT_PARAMS );
static RTYPE compiled_block_1_1240( CONT_PARAMS );
static RTYPE compiled_block_1_1242( CONT_PARAMS );
static RTYPE compiled_block_1_1244( CONT_PARAMS );
static RTYPE compiled_block_1_1246( CONT_PARAMS );
static RTYPE compiled_block_1_1307( CONT_PARAMS );
static RTYPE compiled_block_1_1306( CONT_PARAMS );
static RTYPE compiled_block_1_1305( CONT_PARAMS );
static RTYPE compiled_block_1_1304( CONT_PARAMS );
static RTYPE compiled_block_1_1303( CONT_PARAMS );
static RTYPE compiled_block_1_1302( CONT_PARAMS );
static RTYPE compiled_block_1_1301( CONT_PARAMS );
static RTYPE compiled_block_1_1300( CONT_PARAMS );
static RTYPE compiled_block_1_1299( CONT_PARAMS );
static RTYPE compiled_block_1_1298( CONT_PARAMS );
static RTYPE compiled_block_1_1297( CONT_PARAMS );
static RTYPE compiled_block_1_1296( CONT_PARAMS );
static RTYPE compiled_block_1_1295( CONT_PARAMS );
static RTYPE compiled_block_1_1294( CONT_PARAMS );
static RTYPE compiled_block_1_1293( CONT_PARAMS );
static RTYPE compiled_block_1_1292( CONT_PARAMS );
static RTYPE compiled_block_1_1291( CONT_PARAMS );
static RTYPE compiled_block_1_1290( CONT_PARAMS );
static RTYPE compiled_block_1_1289( CONT_PARAMS );
static RTYPE compiled_block_1_1288( CONT_PARAMS );
static RTYPE compiled_block_1_1287( CONT_PARAMS );
static RTYPE compiled_block_1_1286( CONT_PARAMS );
static RTYPE compiled_block_1_1285( CONT_PARAMS );
static RTYPE compiled_block_1_1284( CONT_PARAMS );
static RTYPE compiled_block_1_1283( CONT_PARAMS );
static RTYPE compiled_block_1_1282( CONT_PARAMS );
static RTYPE compiled_block_1_1281( CONT_PARAMS );
static RTYPE compiled_block_1_1280( CONT_PARAMS );
static RTYPE compiled_block_1_1279( CONT_PARAMS );
static RTYPE compiled_block_1_1278( CONT_PARAMS );
static RTYPE compiled_block_1_1277( CONT_PARAMS );
static RTYPE compiled_block_1_1276( CONT_PARAMS );
static RTYPE compiled_block_1_1275( CONT_PARAMS );
static RTYPE compiled_block_1_1274( CONT_PARAMS );
static RTYPE compiled_block_1_1273( CONT_PARAMS );
static RTYPE compiled_block_1_1272( CONT_PARAMS );
static RTYPE compiled_block_1_1271( CONT_PARAMS );
static RTYPE compiled_block_1_1270( CONT_PARAMS );
static RTYPE compiled_block_1_1269( CONT_PARAMS );
static RTYPE compiled_block_1_1268( CONT_PARAMS );
static RTYPE compiled_block_1_1267( CONT_PARAMS );
static RTYPE compiled_block_1_1266( CONT_PARAMS );
static RTYPE compiled_block_1_1265( CONT_PARAMS );
static RTYPE compiled_block_1_1264( CONT_PARAMS );
static RTYPE compiled_block_1_1263( CONT_PARAMS );
static RTYPE compiled_block_1_1262( CONT_PARAMS );
static RTYPE compiled_block_1_1261( CONT_PARAMS );
static RTYPE compiled_block_1_1260( CONT_PARAMS );
static RTYPE compiled_block_1_1259( CONT_PARAMS );
static RTYPE compiled_block_1_1258( CONT_PARAMS );
static RTYPE compiled_block_1_1257( CONT_PARAMS );
static RTYPE compiled_block_1_1256( CONT_PARAMS );
static RTYPE compiled_block_1_1255( CONT_PARAMS );
static RTYPE compiled_block_1_1254( CONT_PARAMS );
static RTYPE compiled_block_1_1253( CONT_PARAMS );
static RTYPE compiled_block_1_1252( CONT_PARAMS );
static RTYPE compiled_block_1_1251( CONT_PARAMS );
static RTYPE compiled_block_1_1250( CONT_PARAMS );
static RTYPE compiled_block_1_1249( CONT_PARAMS );
static RTYPE compiled_block_1_1248( CONT_PARAMS );
static RTYPE compiled_block_1_1247( CONT_PARAMS );
static RTYPE compiled_start_1_413( CONT_PARAMS );
static RTYPE compiled_block_1_1170( CONT_PARAMS );
static RTYPE compiled_block_1_1172( CONT_PARAMS );
static RTYPE compiled_block_1_1174( CONT_PARAMS );
static RTYPE compiled_block_1_1176( CONT_PARAMS );
static RTYPE compiled_block_1_1178( CONT_PARAMS );
static RTYPE compiled_block_1_1232( CONT_PARAMS );
static RTYPE compiled_block_1_1231( CONT_PARAMS );
static RTYPE compiled_block_1_1230( CONT_PARAMS );
static RTYPE compiled_block_1_1229( CONT_PARAMS );
static RTYPE compiled_block_1_1228( CONT_PARAMS );
static RTYPE compiled_block_1_1227( CONT_PARAMS );
static RTYPE compiled_block_1_1226( CONT_PARAMS );
static RTYPE compiled_block_1_1225( CONT_PARAMS );
static RTYPE compiled_block_1_1224( CONT_PARAMS );
static RTYPE compiled_block_1_1223( CONT_PARAMS );
static RTYPE compiled_block_1_1222( CONT_PARAMS );
static RTYPE compiled_block_1_1221( CONT_PARAMS );
static RTYPE compiled_block_1_1220( CONT_PARAMS );
static RTYPE compiled_block_1_1219( CONT_PARAMS );
static RTYPE compiled_block_1_1218( CONT_PARAMS );
static RTYPE compiled_block_1_1217( CONT_PARAMS );
static RTYPE compiled_block_1_1216( CONT_PARAMS );
static RTYPE compiled_block_1_1215( CONT_PARAMS );
static RTYPE compiled_block_1_1214( CONT_PARAMS );
static RTYPE compiled_block_1_1213( CONT_PARAMS );
static RTYPE compiled_block_1_1212( CONT_PARAMS );
static RTYPE compiled_block_1_1211( CONT_PARAMS );
static RTYPE compiled_block_1_1210( CONT_PARAMS );
static RTYPE compiled_block_1_1209( CONT_PARAMS );
static RTYPE compiled_block_1_1208( CONT_PARAMS );
static RTYPE compiled_block_1_1207( CONT_PARAMS );
static RTYPE compiled_block_1_1206( CONT_PARAMS );
static RTYPE compiled_block_1_1205( CONT_PARAMS );
static RTYPE compiled_block_1_1204( CONT_PARAMS );
static RTYPE compiled_block_1_1203( CONT_PARAMS );
static RTYPE compiled_block_1_1202( CONT_PARAMS );
static RTYPE compiled_block_1_1201( CONT_PARAMS );
static RTYPE compiled_block_1_1200( CONT_PARAMS );
static RTYPE compiled_block_1_1199( CONT_PARAMS );
static RTYPE compiled_block_1_1198( CONT_PARAMS );
static RTYPE compiled_block_1_1197( CONT_PARAMS );
static RTYPE compiled_block_1_1196( CONT_PARAMS );
static RTYPE compiled_block_1_1195( CONT_PARAMS );
static RTYPE compiled_block_1_1194( CONT_PARAMS );
static RTYPE compiled_block_1_1193( CONT_PARAMS );
static RTYPE compiled_block_1_1192( CONT_PARAMS );
static RTYPE compiled_block_1_1191( CONT_PARAMS );
static RTYPE compiled_block_1_1190( CONT_PARAMS );
static RTYPE compiled_block_1_1189( CONT_PARAMS );
static RTYPE compiled_block_1_1188( CONT_PARAMS );
static RTYPE compiled_block_1_1187( CONT_PARAMS );
static RTYPE compiled_block_1_1186( CONT_PARAMS );
static RTYPE compiled_block_1_1185( CONT_PARAMS );
static RTYPE compiled_block_1_1184( CONT_PARAMS );
static RTYPE compiled_block_1_1183( CONT_PARAMS );
static RTYPE compiled_block_1_1182( CONT_PARAMS );
static RTYPE compiled_block_1_1181( CONT_PARAMS );
static RTYPE compiled_block_1_1180( CONT_PARAMS );
static RTYPE compiled_block_1_1179( CONT_PARAMS );
static RTYPE compiled_start_1_412( CONT_PARAMS );
static RTYPE compiled_block_1_1126( CONT_PARAMS );
static RTYPE compiled_block_1_1128( CONT_PARAMS );
static RTYPE compiled_block_1_1130( CONT_PARAMS );
static RTYPE compiled_block_1_1132( CONT_PARAMS );
static RTYPE compiled_block_1_1163( CONT_PARAMS );
static RTYPE compiled_block_1_1162( CONT_PARAMS );
static RTYPE compiled_block_1_1161( CONT_PARAMS );
static RTYPE compiled_block_1_1160( CONT_PARAMS );
static RTYPE compiled_block_1_1159( CONT_PARAMS );
static RTYPE compiled_block_1_1158( CONT_PARAMS );
static RTYPE compiled_block_1_1157( CONT_PARAMS );
static RTYPE compiled_block_1_1156( CONT_PARAMS );
static RTYPE compiled_block_1_1155( CONT_PARAMS );
static RTYPE compiled_block_1_1154( CONT_PARAMS );
static RTYPE compiled_block_1_1153( CONT_PARAMS );
static RTYPE compiled_block_1_1152( CONT_PARAMS );
static RTYPE compiled_block_1_1151( CONT_PARAMS );
static RTYPE compiled_block_1_1150( CONT_PARAMS );
static RTYPE compiled_block_1_1149( CONT_PARAMS );
static RTYPE compiled_block_1_1148( CONT_PARAMS );
static RTYPE compiled_block_1_1147( CONT_PARAMS );
static RTYPE compiled_block_1_1146( CONT_PARAMS );
static RTYPE compiled_block_1_1145( CONT_PARAMS );
static RTYPE compiled_block_1_1144( CONT_PARAMS );
static RTYPE compiled_block_1_1143( CONT_PARAMS );
static RTYPE compiled_block_1_1142( CONT_PARAMS );
static RTYPE compiled_block_1_1141( CONT_PARAMS );
static RTYPE compiled_block_1_1140( CONT_PARAMS );
static RTYPE compiled_block_1_1139( CONT_PARAMS );
static RTYPE compiled_block_1_1138( CONT_PARAMS );
static RTYPE compiled_block_1_1137( CONT_PARAMS );
static RTYPE compiled_block_1_1136( CONT_PARAMS );
static RTYPE compiled_block_1_1135( CONT_PARAMS );
static RTYPE compiled_block_1_1134( CONT_PARAMS );
static RTYPE compiled_block_1_1133( CONT_PARAMS );
static RTYPE compiled_start_1_411( CONT_PARAMS );
static RTYPE compiled_block_1_1117( CONT_PARAMS );
static RTYPE compiled_block_1_1120( CONT_PARAMS );
static RTYPE compiled_block_1_1121( CONT_PARAMS );
static RTYPE compiled_block_1_1118( CONT_PARAMS );
static RTYPE compiled_start_1_410( CONT_PARAMS );
static RTYPE compiled_block_1_1108( CONT_PARAMS );
static RTYPE compiled_block_1_1111( CONT_PARAMS );
static RTYPE compiled_block_1_1112( CONT_PARAMS );
static RTYPE compiled_block_1_1109( CONT_PARAMS );
static RTYPE compiled_start_1_409( CONT_PARAMS );
static RTYPE compiled_block_1_1099( CONT_PARAMS );
static RTYPE compiled_block_1_1102( CONT_PARAMS );
static RTYPE compiled_block_1_1103( CONT_PARAMS );
static RTYPE compiled_block_1_1100( CONT_PARAMS );
static RTYPE compiled_start_1_408( CONT_PARAMS );
static RTYPE compiled_block_1_1090( CONT_PARAMS );
static RTYPE compiled_block_1_1093( CONT_PARAMS );
static RTYPE compiled_block_1_1094( CONT_PARAMS );
static RTYPE compiled_block_1_1091( CONT_PARAMS );
static RTYPE compiled_start_1_407( CONT_PARAMS );
static RTYPE compiled_block_1_1081( CONT_PARAMS );
static RTYPE compiled_block_1_1084( CONT_PARAMS );
static RTYPE compiled_block_1_1085( CONT_PARAMS );
static RTYPE compiled_block_1_1082( CONT_PARAMS );
static RTYPE compiled_start_1_406( CONT_PARAMS );
static RTYPE compiled_block_1_1072( CONT_PARAMS );
static RTYPE compiled_block_1_1075( CONT_PARAMS );
static RTYPE compiled_block_1_1076( CONT_PARAMS );
static RTYPE compiled_block_1_1073( CONT_PARAMS );
static RTYPE compiled_start_1_405( CONT_PARAMS );
static RTYPE compiled_block_1_1047( CONT_PARAMS );
static RTYPE compiled_block_1_1049( CONT_PARAMS );
static RTYPE compiled_block_1_1051( CONT_PARAMS );
static RTYPE compiled_block_1_1053( CONT_PARAMS );
static RTYPE compiled_block_1_1055( CONT_PARAMS );
static RTYPE compiled_block_1_1057( CONT_PARAMS );
static RTYPE compiled_block_1_1059( CONT_PARAMS );
static RTYPE compiled_block_1_1062( CONT_PARAMS );
static RTYPE compiled_block_1_1061( CONT_PARAMS );
static RTYPE compiled_block_1_1060( CONT_PARAMS );
static RTYPE compiled_block_1_1024( CONT_PARAMS );
static RTYPE compiled_block_1_1027( CONT_PARAMS );
static RTYPE compiled_block_1_1029( CONT_PARAMS );
static RTYPE compiled_block_1_1031( CONT_PARAMS );
static RTYPE compiled_block_1_1033( CONT_PARAMS );
static RTYPE compiled_block_1_1035( CONT_PARAMS );
static RTYPE compiled_block_1_1037( CONT_PARAMS );
static RTYPE compiled_block_1_1039( CONT_PARAMS );
static RTYPE compiled_block_1_1038( CONT_PARAMS );
static RTYPE compiled_start_1_404( CONT_PARAMS );
static RTYPE compiled_block_1_1003( CONT_PARAMS );
static RTYPE compiled_block_1_1005( CONT_PARAMS );
static RTYPE compiled_block_1_1007( CONT_PARAMS );
static RTYPE compiled_block_1_1009( CONT_PARAMS );
static RTYPE compiled_block_1_1011( CONT_PARAMS );
static RTYPE compiled_block_1_1013( CONT_PARAMS );
static RTYPE compiled_block_1_1016( CONT_PARAMS );
static RTYPE compiled_block_1_1015( CONT_PARAMS );
static RTYPE compiled_block_1_1014( CONT_PARAMS );
static RTYPE compiled_start_1_403( CONT_PARAMS );
static RTYPE compiled_start_1_1( CONT_PARAMS );

static RTYPE compiled_start_1_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 2 ); /*  debug-compare~1ayXVW~31904 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 3 ); /*  default-compare~1ayXVW~31903 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 4 ); /*  vector-compare-as-list~1ayXVW~31902 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 5 ); /*  vector-compare~1ayXVW~31901 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 6 ); /*  list-compare-as-vector~1ayXVW~31900 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 7 ); /*  list-compare~1ayXVW~31899 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 8 ); /*  pair-compare~1ayXVW~31898 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 9 ); /*  pair-compare-cdr~1ayXVW~31897 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 10 ); /*  pair-compare-car~1ayXVW~31896 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 11 ); /*  number-compare~1ayXVW~31895 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 12 ); /*  complex-compare~1ayXVW~31894 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 13 ); /*  real-compare~1ayXVW~31893 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 14 ); /*  rational-compare~1ayXVW~31891 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 15 ); /*  integer-compare~1ayXVW~31889 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 16 ); /*  symbol-compare~1ayXVW~31887 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 17 ); /*  string-compare-ci~1ayXVW~31886 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 18 ); /*  string-compare~1ayXVW~31884 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 19 ); /*  char-compare-ci~1ayXVW~31882 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 20 ); /*  char-compare~1ayXVW~31880 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 21 ); /*  boolean-compare~1ayXVW~31878 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 22 ); /*  compare-by=/>~1ayXVW~31667 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 23 ); /*  compare-by=/<~1ayXVW~31666 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 24 ); /*  compare-by>=~1ayXVW~31665 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 25 ); /*  compare-by<=~1ayXVW~31664 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 26 ); /*  compare-by>~1ayXVW~31663 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 27 ); /*  compare-by<~1ayXVW~31662 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 28 ); /*  kth-largest~1ayXVW~31661 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 29 ); /*  max-compare~1ayXVW~31660 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 30 ); /*  min-compare~1ayXVW~31659 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 31 ); /*  pairwise-not=?~1ayXVW~31658 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 32 ); /*  chain>=?~1ayXVW~31657 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 33 ); /*  chain<=?~1ayXVW~31655 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 34 ); /*  chain>?~1ayXVW~31653 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 35 ); /*  chain<?~1ayXVW~31651 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 36 ); /*  chain=?~1ayXVW~31649 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 37 ); /*  >=/>=?~1ayXVW~31629 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 38 ); /*  >=/>?~1ayXVW~31627 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 39 ); /*  >/>=?~1ayXVW~31625 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 40 ); /*  >/>?~1ayXVW~31623 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 41 ); /*  <=/<=?~1ayXVW~31621 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 42 ); /*  <=/<?~1ayXVW~31619 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 43 ); /*  </<=?~1ayXVW~31617 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 44 ); /*  </<?~1ayXVW~31615 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 45 ); /*  not=?~1ayXVW~31592 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 46 ); /*  >=?~1ayXVW~31590 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 47 ); /*  <=?~1ayXVW~31588 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 48 ); /*  >?~1ayXVW~31586 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 49 ); /*  <?~1ayXVW~31584 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 50 ); /*  =?~1ayXVW~31582 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 51 ); /*  compare:checked~1ayXVW~31415 */
  twobit_lambda( compiled_start_1_1, 53, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_2, 55, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_3, 57, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 58 );
  twobit_setreg( 1 );
  twobit_const( 59 );
  twobit_setreg( 3 );
  twobit_const( 60 );
  twobit_setreg( 4 );
  twobit_const( 61 );
  twobit_setreg( 5 );
  twobit_const( 62 );
  twobit_setreg( 8 );
  twobit_global( 63 ); /* ex:make-library */
  twobit_setrtn( 4078, compiled_block_1_4078 );
  twobit_invoke( 8 );
  twobit_label( 4078, compiled_block_1_4078 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 64 ); /* ex:register-library! */
  twobit_setrtn( 4079, compiled_block_1_4079 );
  twobit_invoke( 1 );
  twobit_label( 4079, compiled_block_1_4079 );
  twobit_load( 0, 0 );
  twobit_global( 65 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* ex:uncompress */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_403, 2, 0 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1023, compiled_block_1_1023 );
  twobit_invoke( 2 );
  twobit_label( 1023, compiled_block_1_1023 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_404, 6, 0 );
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1070, compiled_block_1_1070 );
  twobit_invoke( 2 );
  twobit_label( 1070, compiled_block_1_1070 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_405, 9, 0 );
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1079, compiled_block_1_1079 );
  twobit_invoke( 2 );
  twobit_label( 1079, compiled_block_1_1079 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_406, 12, 0 );
  twobit_setreg( 2 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1088, compiled_block_1_1088 );
  twobit_invoke( 2 );
  twobit_label( 1088, compiled_block_1_1088 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_407, 15, 0 );
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1097, compiled_block_1_1097 );
  twobit_invoke( 2 );
  twobit_label( 1097, compiled_block_1_1097 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_408, 18, 0 );
  twobit_setreg( 2 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1106, compiled_block_1_1106 );
  twobit_invoke( 2 );
  twobit_label( 1106, compiled_block_1_1106 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_409, 21, 0 );
  twobit_setreg( 2 );
  twobit_const( 22 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1115, compiled_block_1_1115 );
  twobit_invoke( 2 );
  twobit_label( 1115, compiled_block_1_1115 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_410, 24, 0 );
  twobit_setreg( 2 );
  twobit_const( 25 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1124, compiled_block_1_1124 );
  twobit_invoke( 2 );
  twobit_label( 1124, compiled_block_1_1124 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_411, 27, 0 );
  twobit_setreg( 2 );
  twobit_const( 28 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1168, compiled_block_1_1168 );
  twobit_invoke( 2 );
  twobit_label( 1168, compiled_block_1_1168 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_412, 30, 0 );
  twobit_setreg( 2 );
  twobit_const( 31 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1238, compiled_block_1_1238 );
  twobit_invoke( 2 );
  twobit_label( 1238, compiled_block_1_1238 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_413, 33, 0 );
  twobit_setreg( 2 );
  twobit_const( 34 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1312, compiled_block_1_1312 );
  twobit_invoke( 2 );
  twobit_label( 1312, compiled_block_1_1312 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_414, 36, 0 );
  twobit_setreg( 2 );
  twobit_const( 37 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1346, compiled_block_1_1346 );
  twobit_invoke( 2 );
  twobit_label( 1346, compiled_block_1_1346 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_415, 39, 0 );
  twobit_setreg( 2 );
  twobit_const( 40 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1469, compiled_block_1_1469 );
  twobit_invoke( 2 );
  twobit_label( 1469, compiled_block_1_1469 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_416, 42, 0 );
  twobit_setreg( 2 );
  twobit_const( 43 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1541, compiled_block_1_1541 );
  twobit_invoke( 2 );
  twobit_label( 1541, compiled_block_1_1541 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_417, 45, 0 );
  twobit_setreg( 2 );
  twobit_const( 46 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1584, compiled_block_1_1584 );
  twobit_invoke( 2 );
  twobit_label( 1584, compiled_block_1_1584 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_418, 48, 0 );
  twobit_setreg( 2 );
  twobit_const( 49 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1631, compiled_block_1_1631 );
  twobit_invoke( 2 );
  twobit_label( 1631, compiled_block_1_1631 );
  twobit_load( 0, 0 );
  twobit_global( 50 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_403( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1003, compiled_block_1_1003 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1005, compiled_block_1_1005 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1007, compiled_block_1_1007 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1009, compiled_block_1_1009 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1011, compiled_block_1_1011 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1013, compiled_block_1_1013 ); /* internal:branchf-null? */
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 6 );
  twobit_store( 30, 3 );
  twobit_store( 31, 2 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1014, compiled_block_1_1014 );
  twobit_invoke( 5 );
  twobit_label( 1014, compiled_block_1_1014 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_58( 2 ); /* cons */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_58( 1 ); /* cons */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_store( 1, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_58( 3 ); /* cons */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1015, compiled_block_1_1015 );
  twobit_invoke( 5 );
  twobit_label( 1015, compiled_block_1_1015 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_const( 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1016, compiled_block_1_1016 );
  twobit_invoke( 5 );
  twobit_label( 1016, compiled_block_1_1016 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1013, compiled_block_1_1013 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1011, compiled_block_1_1011 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1009, compiled_block_1_1009 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1007, compiled_block_1_1007 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1005, compiled_block_1_1005 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1003, compiled_block_1_1003 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_404( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1027, compiled_block_1_1027 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1029, compiled_block_1_1029 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1031, compiled_block_1_1031 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1033, compiled_block_1_1033 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1035, compiled_block_1_1035 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1037, compiled_block_1_1037 ); /* internal:branchf-null? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 2, 4 );
  twobit_store( 3, 5 );
  twobit_store( 30, 2 );
  twobit_store( 31, 3 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1038, compiled_block_1_1038 );
  twobit_invoke( 5 );
  twobit_label( 1038, compiled_block_1_1038 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1039, compiled_block_1_1039 );
  twobit_invoke( 5 );
  twobit_label( 1039, compiled_block_1_1039 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1037, compiled_block_1_1037 );
  twobit_branch( 1024, compiled_block_1_1024 );
  twobit_label( 1035, compiled_block_1_1035 );
  twobit_branch( 1024, compiled_block_1_1024 );
  twobit_label( 1033, compiled_block_1_1033 );
  twobit_branch( 1024, compiled_block_1_1024 );
  twobit_label( 1031, compiled_block_1_1031 );
  twobit_branch( 1024, compiled_block_1_1024 );
  twobit_label( 1029, compiled_block_1_1029 );
  twobit_branch( 1024, compiled_block_1_1024 );
  twobit_label( 1027, compiled_block_1_1027 );
  twobit_label( 1024, compiled_block_1_1024 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1047, compiled_block_1_1047 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1049, compiled_block_1_1049 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1051, compiled_block_1_1051 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1053, compiled_block_1_1053 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1055, compiled_block_1_1055 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1057, compiled_block_1_1057 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 29 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1059, compiled_block_1_1059 ); /* internal:branchf-null? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 2, 4 );
  twobit_store( 3, 2 );
  twobit_store( 29, 3 );
  twobit_store( 30, 1 );
  twobit_store( 31, 5 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1060, compiled_block_1_1060 );
  twobit_invoke( 5 );
  twobit_label( 1060, compiled_block_1_1060 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 3 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_stack( 4 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1061, compiled_block_1_1061 );
  twobit_invoke( 5 );
  twobit_label( 1061, compiled_block_1_1061 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1062, compiled_block_1_1062 );
  twobit_invoke( 5 );
  twobit_label( 1062, compiled_block_1_1062 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1059, compiled_block_1_1059 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1057, compiled_block_1_1057 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1055, compiled_block_1_1055 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1053, compiled_block_1_1053 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1051, compiled_block_1_1051 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1049, compiled_block_1_1049 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1047, compiled_block_1_1047 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_405( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1072, compiled_block_1_1072 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1073, compiled_block_1_1073 );
  twobit_invoke( 1 );
  twobit_label( 1073, compiled_block_1_1073 );
  twobit_load( 0, 0 );
  twobit_branchf( 1075, compiled_block_1_1075 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_58( 3 ); /* cons */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1076, compiled_block_1_1076 );
  twobit_invoke( 5 );
  twobit_label( 1076, compiled_block_1_1076 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1075, compiled_block_1_1075 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1072, compiled_block_1_1072 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_406( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1081, compiled_block_1_1081 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1082, compiled_block_1_1082 );
  twobit_invoke( 1 );
  twobit_label( 1082, compiled_block_1_1082 );
  twobit_load( 0, 0 );
  twobit_branchf( 1084, compiled_block_1_1084 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_58( 3 ); /* cons */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1085, compiled_block_1_1085 );
  twobit_invoke( 5 );
  twobit_label( 1085, compiled_block_1_1085 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1084, compiled_block_1_1084 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1081, compiled_block_1_1081 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_407( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1090, compiled_block_1_1090 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1091, compiled_block_1_1091 );
  twobit_invoke( 1 );
  twobit_label( 1091, compiled_block_1_1091 );
  twobit_load( 0, 0 );
  twobit_branchf( 1093, compiled_block_1_1093 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_58( 3 ); /* cons */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1094, compiled_block_1_1094 );
  twobit_invoke( 5 );
  twobit_label( 1094, compiled_block_1_1094 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1093, compiled_block_1_1093 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1090, compiled_block_1_1090 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_408( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1099, compiled_block_1_1099 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1100, compiled_block_1_1100 );
  twobit_invoke( 1 );
  twobit_label( 1100, compiled_block_1_1100 );
  twobit_load( 0, 0 );
  twobit_branchf( 1102, compiled_block_1_1102 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_58( 3 ); /* cons */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1103, compiled_block_1_1103 );
  twobit_invoke( 5 );
  twobit_label( 1103, compiled_block_1_1103 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1102, compiled_block_1_1102 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1099, compiled_block_1_1099 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_409( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1108, compiled_block_1_1108 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1109, compiled_block_1_1109 );
  twobit_invoke( 1 );
  twobit_label( 1109, compiled_block_1_1109 );
  twobit_load( 0, 0 );
  twobit_branchf( 1111, compiled_block_1_1111 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_58( 3 ); /* cons */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1112, compiled_block_1_1112 );
  twobit_invoke( 5 );
  twobit_label( 1112, compiled_block_1_1112 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1111, compiled_block_1_1111 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1108, compiled_block_1_1108 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_410( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1117, compiled_block_1_1117 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1118, compiled_block_1_1118 );
  twobit_invoke( 1 );
  twobit_label( 1118, compiled_block_1_1118 );
  twobit_load( 0, 0 );
  twobit_branchf( 1120, compiled_block_1_1120 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_58( 3 ); /* cons */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1121, compiled_block_1_1121 );
  twobit_invoke( 5 );
  twobit_label( 1121, compiled_block_1_1121 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1120, compiled_block_1_1120 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1117, compiled_block_1_1117 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_411( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1126, compiled_block_1_1126 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1128, compiled_block_1_1128 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1130, compiled_block_1_1130 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1132, compiled_block_1_1132 ); /* internal:branchf-null? */
  twobit_save( 13 );
  twobit_store( 0, 0 );
  twobit_store( 2, 4 );
  twobit_store( 3, 12 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1133, compiled_block_1_1133 );
  twobit_invoke( 5 );
  twobit_label( 1133, compiled_block_1_1133 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 13 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1134, compiled_block_1_1134 );
  twobit_invoke( 5 );
  twobit_label( 1134, compiled_block_1_1134 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1135, compiled_block_1_1135 );
  twobit_invoke( 5 );
  twobit_label( 1135, compiled_block_1_1135 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1136, compiled_block_1_1136 );
  twobit_invoke( 5 );
  twobit_label( 1136, compiled_block_1_1136 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1137, compiled_block_1_1137 );
  twobit_invoke( 5 );
  twobit_label( 1137, compiled_block_1_1137 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1138, compiled_block_1_1138 );
  twobit_invoke( 5 );
  twobit_label( 1138, compiled_block_1_1138 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1139, compiled_block_1_1139 );
  twobit_invoke( 5 );
  twobit_label( 1139, compiled_block_1_1139 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1140, compiled_block_1_1140 );
  twobit_invoke( 5 );
  twobit_label( 1140, compiled_block_1_1140 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1141, compiled_block_1_1141 );
  twobit_invoke( 5 );
  twobit_label( 1141, compiled_block_1_1141 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1142, compiled_block_1_1142 );
  twobit_invoke( 5 );
  twobit_label( 1142, compiled_block_1_1142 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1143, compiled_block_1_1143 );
  twobit_invoke( 5 );
  twobit_label( 1143, compiled_block_1_1143 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1144, compiled_block_1_1144 );
  twobit_invoke( 5 );
  twobit_label( 1144, compiled_block_1_1144 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1145, compiled_block_1_1145 );
  twobit_invoke( 5 );
  twobit_label( 1145, compiled_block_1_1145 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1146, compiled_block_1_1146 );
  twobit_invoke( 5 );
  twobit_label( 1146, compiled_block_1_1146 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1147, compiled_block_1_1147 );
  twobit_invoke( 5 );
  twobit_label( 1147, compiled_block_1_1147 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1148, compiled_block_1_1148 );
  twobit_invoke( 5 );
  twobit_label( 1148, compiled_block_1_1148 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1149, compiled_block_1_1149 );
  twobit_invoke( 5 );
  twobit_label( 1149, compiled_block_1_1149 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1150, compiled_block_1_1150 );
  twobit_invoke( 5 );
  twobit_label( 1150, compiled_block_1_1150 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1151, compiled_block_1_1151 );
  twobit_invoke( 5 );
  twobit_label( 1151, compiled_block_1_1151 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1152, compiled_block_1_1152 );
  twobit_invoke( 5 );
  twobit_label( 1152, compiled_block_1_1152 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1153, compiled_block_1_1153 );
  twobit_invoke( 5 );
  twobit_label( 1153, compiled_block_1_1153 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1154, compiled_block_1_1154 );
  twobit_invoke( 5 );
  twobit_label( 1154, compiled_block_1_1154 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1155, compiled_block_1_1155 );
  twobit_invoke( 5 );
  twobit_label( 1155, compiled_block_1_1155 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1156, compiled_block_1_1156 );
  twobit_invoke( 5 );
  twobit_label( 1156, compiled_block_1_1156 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1157, compiled_block_1_1157 );
  twobit_invoke( 5 );
  twobit_label( 1157, compiled_block_1_1157 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1158, compiled_block_1_1158 );
  twobit_invoke( 5 );
  twobit_label( 1158, compiled_block_1_1158 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1159, compiled_block_1_1159 );
  twobit_invoke( 5 );
  twobit_label( 1159, compiled_block_1_1159 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1160, compiled_block_1_1160 );
  twobit_invoke( 5 );
  twobit_label( 1160, compiled_block_1_1160 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1161, compiled_block_1_1161 );
  twobit_invoke( 5 );
  twobit_label( 1161, compiled_block_1_1161 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1162, compiled_block_1_1162 );
  twobit_invoke( 5 );
  twobit_label( 1162, compiled_block_1_1162 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1163, compiled_block_1_1163 );
  twobit_invoke( 5 );
  twobit_label( 1163, compiled_block_1_1163 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 14 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 13 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 13 );
  twobit_return();
  twobit_label( 1132, compiled_block_1_1132 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1130, compiled_block_1_1130 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1128, compiled_block_1_1128 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1126, compiled_block_1_1126 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_412( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1170, compiled_block_1_1170 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1172, compiled_block_1_1172 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1174, compiled_block_1_1174 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1176, compiled_block_1_1176 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1178, compiled_block_1_1178 ); /* internal:branchf-null? */
  twobit_save( 13 );
  twobit_store( 0, 0 );
  twobit_store( 2, 6 );
  twobit_store( 3, 12 );
  twobit_store( 31, 4 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1179, compiled_block_1_1179 );
  twobit_invoke( 5 );
  twobit_label( 1179, compiled_block_1_1179 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 13 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1180, compiled_block_1_1180 );
  twobit_invoke( 5 );
  twobit_label( 1180, compiled_block_1_1180 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1181, compiled_block_1_1181 );
  twobit_invoke( 5 );
  twobit_label( 1181, compiled_block_1_1181 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1182, compiled_block_1_1182 );
  twobit_invoke( 5 );
  twobit_label( 1182, compiled_block_1_1182 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1183, compiled_block_1_1183 );
  twobit_invoke( 5 );
  twobit_label( 1183, compiled_block_1_1183 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1184, compiled_block_1_1184 );
  twobit_invoke( 5 );
  twobit_label( 1184, compiled_block_1_1184 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1185, compiled_block_1_1185 );
  twobit_invoke( 5 );
  twobit_label( 1185, compiled_block_1_1185 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1186, compiled_block_1_1186 );
  twobit_invoke( 5 );
  twobit_label( 1186, compiled_block_1_1186 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1187, compiled_block_1_1187 );
  twobit_invoke( 5 );
  twobit_label( 1187, compiled_block_1_1187 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1188, compiled_block_1_1188 );
  twobit_invoke( 5 );
  twobit_label( 1188, compiled_block_1_1188 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1189, compiled_block_1_1189 );
  twobit_invoke( 5 );
  twobit_label( 1189, compiled_block_1_1189 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1190, compiled_block_1_1190 );
  twobit_invoke( 5 );
  twobit_label( 1190, compiled_block_1_1190 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1191, compiled_block_1_1191 );
  twobit_invoke( 5 );
  twobit_label( 1191, compiled_block_1_1191 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1192, compiled_block_1_1192 );
  twobit_invoke( 5 );
  twobit_label( 1192, compiled_block_1_1192 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1193, compiled_block_1_1193 );
  twobit_invoke( 5 );
  twobit_label( 1193, compiled_block_1_1193 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1194, compiled_block_1_1194 );
  twobit_invoke( 5 );
  twobit_label( 1194, compiled_block_1_1194 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1195, compiled_block_1_1195 );
  twobit_invoke( 5 );
  twobit_label( 1195, compiled_block_1_1195 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1196, compiled_block_1_1196 );
  twobit_invoke( 5 );
  twobit_label( 1196, compiled_block_1_1196 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1197, compiled_block_1_1197 );
  twobit_invoke( 5 );
  twobit_label( 1197, compiled_block_1_1197 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1198, compiled_block_1_1198 );
  twobit_invoke( 5 );
  twobit_label( 1198, compiled_block_1_1198 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1199, compiled_block_1_1199 );
  twobit_invoke( 5 );
  twobit_label( 1199, compiled_block_1_1199 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1200, compiled_block_1_1200 );
  twobit_invoke( 5 );
  twobit_label( 1200, compiled_block_1_1200 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1201, compiled_block_1_1201 );
  twobit_invoke( 5 );
  twobit_label( 1201, compiled_block_1_1201 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1202, compiled_block_1_1202 );
  twobit_invoke( 5 );
  twobit_label( 1202, compiled_block_1_1202 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1203, compiled_block_1_1203 );
  twobit_invoke( 5 );
  twobit_label( 1203, compiled_block_1_1203 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1204, compiled_block_1_1204 );
  twobit_invoke( 5 );
  twobit_label( 1204, compiled_block_1_1204 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1205, compiled_block_1_1205 );
  twobit_invoke( 5 );
  twobit_label( 1205, compiled_block_1_1205 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1206, compiled_block_1_1206 );
  twobit_invoke( 5 );
  twobit_label( 1206, compiled_block_1_1206 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1207, compiled_block_1_1207 );
  twobit_invoke( 5 );
  twobit_label( 1207, compiled_block_1_1207 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1208, compiled_block_1_1208 );
  twobit_invoke( 5 );
  twobit_label( 1208, compiled_block_1_1208 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1209, compiled_block_1_1209 );
  twobit_invoke( 5 );
  twobit_label( 1209, compiled_block_1_1209 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1210, compiled_block_1_1210 );
  twobit_invoke( 5 );
  twobit_label( 1210, compiled_block_1_1210 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1211, compiled_block_1_1211 );
  twobit_invoke( 5 );
  twobit_label( 1211, compiled_block_1_1211 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1212, compiled_block_1_1212 );
  twobit_invoke( 5 );
  twobit_label( 1212, compiled_block_1_1212 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1213, compiled_block_1_1213 );
  twobit_invoke( 5 );
  twobit_label( 1213, compiled_block_1_1213 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1214, compiled_block_1_1214 );
  twobit_invoke( 5 );
  twobit_label( 1214, compiled_block_1_1214 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1215, compiled_block_1_1215 );
  twobit_invoke( 5 );
  twobit_label( 1215, compiled_block_1_1215 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1216, compiled_block_1_1216 );
  twobit_invoke( 5 );
  twobit_label( 1216, compiled_block_1_1216 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1217, compiled_block_1_1217 );
  twobit_invoke( 5 );
  twobit_label( 1217, compiled_block_1_1217 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1218, compiled_block_1_1218 );
  twobit_invoke( 5 );
  twobit_label( 1218, compiled_block_1_1218 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1219, compiled_block_1_1219 );
  twobit_invoke( 5 );
  twobit_label( 1219, compiled_block_1_1219 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1220, compiled_block_1_1220 );
  twobit_invoke( 5 );
  twobit_label( 1220, compiled_block_1_1220 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1221, compiled_block_1_1221 );
  twobit_invoke( 5 );
  twobit_label( 1221, compiled_block_1_1221 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1222, compiled_block_1_1222 );
  twobit_invoke( 5 );
  twobit_label( 1222, compiled_block_1_1222 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1223, compiled_block_1_1223 );
  twobit_invoke( 5 );
  twobit_label( 1223, compiled_block_1_1223 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1224, compiled_block_1_1224 );
  twobit_invoke( 5 );
  twobit_label( 1224, compiled_block_1_1224 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1225, compiled_block_1_1225 );
  twobit_invoke( 5 );
  twobit_label( 1225, compiled_block_1_1225 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1226, compiled_block_1_1226 );
  twobit_invoke( 5 );
  twobit_label( 1226, compiled_block_1_1226 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 8 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1227, compiled_block_1_1227 );
  twobit_invoke( 5 );
  twobit_label( 1227, compiled_block_1_1227 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1228, compiled_block_1_1228 );
  twobit_invoke( 5 );
  twobit_label( 1228, compiled_block_1_1228 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1229, compiled_block_1_1229 );
  twobit_invoke( 5 );
  twobit_label( 1229, compiled_block_1_1229 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 8 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1230, compiled_block_1_1230 );
  twobit_invoke( 5 );
  twobit_label( 1230, compiled_block_1_1230 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1231, compiled_block_1_1231 );
  twobit_invoke( 5 );
  twobit_label( 1231, compiled_block_1_1231 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1232, compiled_block_1_1232 );
  twobit_invoke( 5 );
  twobit_label( 1232, compiled_block_1_1232 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 13 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 13 );
  twobit_return();
  twobit_label( 1178, compiled_block_1_1178 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1176, compiled_block_1_1176 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1174, compiled_block_1_1174 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1172, compiled_block_1_1172 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1170, compiled_block_1_1170 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_413( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1240, compiled_block_1_1240 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1242, compiled_block_1_1242 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1244, compiled_block_1_1244 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1246, compiled_block_1_1246 ); /* internal:branchf-null? */
  twobit_save( 21 );
  twobit_store( 0, 0 );
  twobit_store( 2, 4 );
  twobit_store( 3, 20 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1247, compiled_block_1_1247 );
  twobit_invoke( 5 );
  twobit_label( 1247, compiled_block_1_1247 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 21 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1248, compiled_block_1_1248 );
  twobit_invoke( 5 );
  twobit_label( 1248, compiled_block_1_1248 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 19 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1249, compiled_block_1_1249 );
  twobit_invoke( 5 );
  twobit_label( 1249, compiled_block_1_1249 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 18 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1250, compiled_block_1_1250 );
  twobit_invoke( 5 );
  twobit_label( 1250, compiled_block_1_1250 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1251, compiled_block_1_1251 );
  twobit_invoke( 5 );
  twobit_label( 1251, compiled_block_1_1251 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1252, compiled_block_1_1252 );
  twobit_invoke( 5 );
  twobit_label( 1252, compiled_block_1_1252 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1253, compiled_block_1_1253 );
  twobit_invoke( 5 );
  twobit_label( 1253, compiled_block_1_1253 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1254, compiled_block_1_1254 );
  twobit_invoke( 5 );
  twobit_label( 1254, compiled_block_1_1254 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 17 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1255, compiled_block_1_1255 );
  twobit_invoke( 5 );
  twobit_label( 1255, compiled_block_1_1255 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1256, compiled_block_1_1256 );
  twobit_invoke( 5 );
  twobit_label( 1256, compiled_block_1_1256 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1257, compiled_block_1_1257 );
  twobit_invoke( 5 );
  twobit_label( 1257, compiled_block_1_1257 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1258, compiled_block_1_1258 );
  twobit_invoke( 5 );
  twobit_label( 1258, compiled_block_1_1258 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1259, compiled_block_1_1259 );
  twobit_invoke( 5 );
  twobit_label( 1259, compiled_block_1_1259 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1260, compiled_block_1_1260 );
  twobit_invoke( 5 );
  twobit_label( 1260, compiled_block_1_1260 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 16 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1261, compiled_block_1_1261 );
  twobit_invoke( 5 );
  twobit_label( 1261, compiled_block_1_1261 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1262, compiled_block_1_1262 );
  twobit_invoke( 5 );
  twobit_label( 1262, compiled_block_1_1262 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1263, compiled_block_1_1263 );
  twobit_invoke( 5 );
  twobit_label( 1263, compiled_block_1_1263 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1264, compiled_block_1_1264 );
  twobit_invoke( 5 );
  twobit_label( 1264, compiled_block_1_1264 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1265, compiled_block_1_1265 );
  twobit_invoke( 5 );
  twobit_label( 1265, compiled_block_1_1265 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1266, compiled_block_1_1266 );
  twobit_invoke( 5 );
  twobit_label( 1266, compiled_block_1_1266 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1267, compiled_block_1_1267 );
  twobit_invoke( 5 );
  twobit_label( 1267, compiled_block_1_1267 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1268, compiled_block_1_1268 );
  twobit_invoke( 5 );
  twobit_label( 1268, compiled_block_1_1268 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1269, compiled_block_1_1269 );
  twobit_invoke( 5 );
  twobit_label( 1269, compiled_block_1_1269 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1270, compiled_block_1_1270 );
  twobit_invoke( 5 );
  twobit_label( 1270, compiled_block_1_1270 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1271, compiled_block_1_1271 );
  twobit_invoke( 5 );
  twobit_label( 1271, compiled_block_1_1271 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1272, compiled_block_1_1272 );
  twobit_invoke( 5 );
  twobit_label( 1272, compiled_block_1_1272 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1273, compiled_block_1_1273 );
  twobit_invoke( 5 );
  twobit_label( 1273, compiled_block_1_1273 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 15 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1274, compiled_block_1_1274 );
  twobit_invoke( 5 );
  twobit_label( 1274, compiled_block_1_1274 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1275, compiled_block_1_1275 );
  twobit_invoke( 5 );
  twobit_label( 1275, compiled_block_1_1275 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1276, compiled_block_1_1276 );
  twobit_invoke( 5 );
  twobit_label( 1276, compiled_block_1_1276 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1277, compiled_block_1_1277 );
  twobit_invoke( 5 );
  twobit_label( 1277, compiled_block_1_1277 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 14 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1278, compiled_block_1_1278 );
  twobit_invoke( 5 );
  twobit_label( 1278, compiled_block_1_1278 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1279, compiled_block_1_1279 );
  twobit_invoke( 5 );
  twobit_label( 1279, compiled_block_1_1279 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1280, compiled_block_1_1280 );
  twobit_invoke( 5 );
  twobit_label( 1280, compiled_block_1_1280 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 13 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1281, compiled_block_1_1281 );
  twobit_invoke( 5 );
  twobit_label( 1281, compiled_block_1_1281 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1282, compiled_block_1_1282 );
  twobit_invoke( 5 );
  twobit_label( 1282, compiled_block_1_1282 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1283, compiled_block_1_1283 );
  twobit_invoke( 5 );
  twobit_label( 1283, compiled_block_1_1283 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1284, compiled_block_1_1284 );
  twobit_invoke( 5 );
  twobit_label( 1284, compiled_block_1_1284 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1285, compiled_block_1_1285 );
  twobit_invoke( 5 );
  twobit_label( 1285, compiled_block_1_1285 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1286, compiled_block_1_1286 );
  twobit_invoke( 5 );
  twobit_label( 1286, compiled_block_1_1286 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1287, compiled_block_1_1287 );
  twobit_invoke( 5 );
  twobit_label( 1287, compiled_block_1_1287 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 17 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1288, compiled_block_1_1288 );
  twobit_invoke( 5 );
  twobit_label( 1288, compiled_block_1_1288 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1289, compiled_block_1_1289 );
  twobit_invoke( 5 );
  twobit_label( 1289, compiled_block_1_1289 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1290, compiled_block_1_1290 );
  twobit_invoke( 5 );
  twobit_label( 1290, compiled_block_1_1290 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1291, compiled_block_1_1291 );
  twobit_invoke( 5 );
  twobit_label( 1291, compiled_block_1_1291 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 18 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1292, compiled_block_1_1292 );
  twobit_invoke( 5 );
  twobit_label( 1292, compiled_block_1_1292 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1293, compiled_block_1_1293 );
  twobit_invoke( 5 );
  twobit_label( 1293, compiled_block_1_1293 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1294, compiled_block_1_1294 );
  twobit_invoke( 5 );
  twobit_label( 1294, compiled_block_1_1294 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 18 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1295, compiled_block_1_1295 );
  twobit_invoke( 5 );
  twobit_label( 1295, compiled_block_1_1295 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1296, compiled_block_1_1296 );
  twobit_invoke( 5 );
  twobit_label( 1296, compiled_block_1_1296 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1297, compiled_block_1_1297 );
  twobit_invoke( 5 );
  twobit_label( 1297, compiled_block_1_1297 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1298, compiled_block_1_1298 );
  twobit_invoke( 5 );
  twobit_label( 1298, compiled_block_1_1298 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 20 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1299, compiled_block_1_1299 );
  twobit_invoke( 5 );
  twobit_label( 1299, compiled_block_1_1299 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1300, compiled_block_1_1300 );
  twobit_invoke( 5 );
  twobit_label( 1300, compiled_block_1_1300 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1301, compiled_block_1_1301 );
  twobit_invoke( 5 );
  twobit_label( 1301, compiled_block_1_1301 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1302, compiled_block_1_1302 );
  twobit_invoke( 5 );
  twobit_label( 1302, compiled_block_1_1302 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1303, compiled_block_1_1303 );
  twobit_invoke( 5 );
  twobit_label( 1303, compiled_block_1_1303 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 20 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1304, compiled_block_1_1304 );
  twobit_invoke( 5 );
  twobit_label( 1304, compiled_block_1_1304 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1305, compiled_block_1_1305 );
  twobit_invoke( 5 );
  twobit_label( 1305, compiled_block_1_1305 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1306, compiled_block_1_1306 );
  twobit_invoke( 5 );
  twobit_label( 1306, compiled_block_1_1306 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1307, compiled_block_1_1307 );
  twobit_invoke( 5 );
  twobit_label( 1307, compiled_block_1_1307 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 13 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 14 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 15 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 16 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 17 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 18 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 19 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 20 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 21 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 21 );
  twobit_return();
  twobit_label( 1246, compiled_block_1_1246 );
  twobit_global( 21 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1244, compiled_block_1_1244 );
  twobit_global( 21 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1242, compiled_block_1_1242 );
  twobit_global( 21 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1240, compiled_block_1_1240 );
  twobit_global( 21 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_414( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1317, compiled_block_1_1317 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1319, compiled_block_1_1319 ); /* internal:branchf-null? */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_return();
  twobit_label( 1319, compiled_block_1_1319 );
  twobit_branch( 1314, compiled_block_1_1314 );
  twobit_label( 1317, compiled_block_1_1317 );
  twobit_branch( 1314, compiled_block_1_1314 );
  twobit_label( 1313, compiled_block_1_1313 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1323, compiled_block_1_1323 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1325, compiled_block_1_1325 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1327, compiled_block_1_1327 ); /* internal:branchf-pair? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 3, 4 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1328, compiled_block_1_1328 );
  twobit_invoke( 1 );
  twobit_label( 1328, compiled_block_1_1328 );
  twobit_load( 0, 0 );
  twobit_branchf( 1330, compiled_block_1_1330 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1331, compiled_block_1_1331 );
  twobit_invoke( 5 );
  twobit_label( 1331, compiled_block_1_1331 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_load( 2, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1332, compiled_block_1_1332 );
  twobit_invoke( 5 );
  twobit_label( 1332, compiled_block_1_1332 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1330, compiled_block_1_1330 );
  twobit_load( 1, 6 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_pop( 6 );
  twobit_invoke( 1 );
  twobit_label( 1327, compiled_block_1_1327 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1325, compiled_block_1_1325 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1323, compiled_block_1_1323 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1314, compiled_block_1_1314 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1338, compiled_block_1_1338 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1340, compiled_block_1_1340 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1342, compiled_block_1_1342 ); /* internal:branchf-null? */
  twobit_reg( 3 );
  twobit_return();
  twobit_label( 1342, compiled_block_1_1342 );
  twobit_branch( 1313, compiled_block_1_1313 );
  twobit_label( 1340, compiled_block_1_1340 );
  twobit_branch( 1313, compiled_block_1_1313 );
  twobit_label( 1338, compiled_block_1_1338 );
  twobit_branch( 1313, compiled_block_1_1313 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_415( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1352, compiled_block_1_1352 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1354, compiled_block_1_1354 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1356, compiled_block_1_1356 ); /* internal:branchf-pair? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1357, compiled_block_1_1357 );
  twobit_invoke( 1 );
  twobit_label( 1357, compiled_block_1_1357 );
  twobit_load( 0, 0 );
  twobit_branchf( 1359, compiled_block_1_1359 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1360, compiled_block_1_1360 );
  twobit_invoke( 5 );
  twobit_label( 1360, compiled_block_1_1360 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1361, compiled_block_1_1361 );
  twobit_invoke( 5 );
  twobit_label( 1361, compiled_block_1_1361 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1362, compiled_block_1_1362 );
  twobit_invoke( 5 );
  twobit_label( 1362, compiled_block_1_1362 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1363, compiled_block_1_1363 );
  twobit_invoke( 5 );
  twobit_label( 1363, compiled_block_1_1363 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1364, compiled_block_1_1364 );
  twobit_invoke( 5 );
  twobit_label( 1364, compiled_block_1_1364 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1365, compiled_block_1_1365 );
  twobit_invoke( 5 );
  twobit_label( 1365, compiled_block_1_1365 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1359, compiled_block_1_1359 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1349, compiled_block_1_1349 );
  twobit_label( 1356, compiled_block_1_1356 );
  twobit_branch( 1349, compiled_block_1_1349 );
  twobit_label( 1354, compiled_block_1_1354 );
  twobit_branch( 1349, compiled_block_1_1349 );
  twobit_label( 1352, compiled_block_1_1352 );
  twobit_branch( 1349, compiled_block_1_1349 );
  twobit_label( 1347, compiled_block_1_1347 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1371, compiled_block_1_1371 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1373, compiled_block_1_1373 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1375, compiled_block_1_1375 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1377, compiled_block_1_1377 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1379, compiled_block_1_1379 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 30 );
  twobit_op1_branchf_611( 1381, compiled_block_1_1381 ); /* internal:branchf-pair? */
  twobit_save( 14 );
  twobit_store( 0, 0 );
  twobit_store( 1, 14 );
  twobit_store( 2, 4 );
  twobit_store( 3, 1 );
  twobit_store( 4, 2 );
  twobit_store( 31, 5 );
  twobit_reg( 30 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 29 );
  twobit_store( 29, 3 );
  twobit_reg( 30 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 30 );
  twobit_store( 30, 6 );
  twobit_movereg( 30, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1382, compiled_block_1_1382 );
  twobit_invoke( 1 );
  twobit_label( 1382, compiled_block_1_1382 );
  twobit_load( 0, 0 );
  twobit_branchf( 1384, compiled_block_1_1384 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1385, compiled_block_1_1385 );
  twobit_invoke( 1 );
  twobit_label( 1385, compiled_block_1_1385 );
  twobit_load( 0, 0 );
  twobit_branchf( 1387, compiled_block_1_1387 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1389, compiled_block_1_1389 ); /* internal:branchf-null? */
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1390, compiled_block_1_1390 );
  twobit_invoke( 5 );
  twobit_label( 1390, compiled_block_1_1390 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 13 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1391, compiled_block_1_1391 );
  twobit_invoke( 5 );
  twobit_label( 1391, compiled_block_1_1391 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1392, compiled_block_1_1392 );
  twobit_invoke( 5 );
  twobit_label( 1392, compiled_block_1_1392 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1393, compiled_block_1_1393 );
  twobit_invoke( 5 );
  twobit_label( 1393, compiled_block_1_1393 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1394, compiled_block_1_1394 );
  twobit_invoke( 5 );
  twobit_label( 1394, compiled_block_1_1394 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1395, compiled_block_1_1395 );
  twobit_invoke( 5 );
  twobit_label( 1395, compiled_block_1_1395 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1396, compiled_block_1_1396 );
  twobit_invoke( 5 );
  twobit_label( 1396, compiled_block_1_1396 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1397, compiled_block_1_1397 );
  twobit_invoke( 5 );
  twobit_label( 1397, compiled_block_1_1397 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1398, compiled_block_1_1398 );
  twobit_invoke( 5 );
  twobit_label( 1398, compiled_block_1_1398 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1399, compiled_block_1_1399 );
  twobit_invoke( 5 );
  twobit_label( 1399, compiled_block_1_1399 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1400, compiled_block_1_1400 );
  twobit_invoke( 5 );
  twobit_label( 1400, compiled_block_1_1400 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1401, compiled_block_1_1401 );
  twobit_invoke( 5 );
  twobit_label( 1401, compiled_block_1_1401 );
  twobit_load( 0, 0 );
  twobit_load( 3, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1402, compiled_block_1_1402 );
  twobit_invoke( 5 );
  twobit_label( 1402, compiled_block_1_1402 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1403, compiled_block_1_1403 );
  twobit_invoke( 5 );
  twobit_label( 1403, compiled_block_1_1403 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 3, 7 );
  twobit_stack( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 2 ); /* () */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1404, compiled_block_1_1404 );
  twobit_invoke( 5 );
  twobit_label( 1404, compiled_block_1_1404 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 13 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 14 );
  twobit_return();
  twobit_label( 1389, compiled_block_1_1389 );
  twobit_load( 1, 14 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_pop( 14 );
  twobit_invoke( 1 );
  twobit_label( 1387, compiled_block_1_1387 );
  twobit_load( 1, 14 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_pop( 14 );
  twobit_invoke( 1 );
  twobit_label( 1384, compiled_block_1_1384 );
  twobit_load( 1, 14 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_pop( 14 );
  twobit_invoke( 1 );
  twobit_label( 1381, compiled_block_1_1381 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1379, compiled_block_1_1379 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1377, compiled_block_1_1377 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1375, compiled_block_1_1375 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1373, compiled_block_1_1373 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1371, compiled_block_1_1371 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1348, compiled_block_1_1348 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1415, compiled_block_1_1415 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1417, compiled_block_1_1417 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1419, compiled_block_1_1419 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1421, compiled_block_1_1421 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1423, compiled_block_1_1423 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1425, compiled_block_1_1425 ); /* internal:branchf-pair? */
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 5 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_store( 4, 4 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 1 );
  twobit_movereg( 31, 1 );
  twobit_global( 16 ); /* ex:identifier? */
  twobit_setrtn( 1426, compiled_block_1_1426 );
  twobit_invoke( 1 );
  twobit_label( 1426, compiled_block_1_1426 );
  twobit_load( 0, 0 );
  twobit_branchf( 1428, compiled_block_1_1428 );
  twobit_const( 17 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 18 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1429, compiled_block_1_1429 );
  twobit_invoke( 5 );
  twobit_label( 1429, compiled_block_1_1429 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 19 ); /* ex:free-identifier=? */
  twobit_setrtn( 1430, compiled_block_1_1430 );
  twobit_invoke( 2 );
  twobit_label( 1430, compiled_block_1_1430 );
  twobit_load( 0, 0 );
  twobit_skip( 1427, compiled_block_1_1427 );
  twobit_label( 1428, compiled_block_1_1428 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1427, compiled_block_1_1427 );
  twobit_branchf( 1432, compiled_block_1_1432 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1433, compiled_block_1_1433 );
  twobit_invoke( 1 );
  twobit_label( 1433, compiled_block_1_1433 );
  twobit_load( 0, 0 );
  twobit_branchf( 1435, compiled_block_1_1435 );
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1437, compiled_block_1_1437 ); /* internal:branchf-null? */
  twobit_stack( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1439, compiled_block_1_1439 ); /* internal:branchf-null? */
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 18 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1440, compiled_block_1_1440 );
  twobit_invoke( 5 );
  twobit_label( 1440, compiled_block_1_1440 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1439, compiled_block_1_1439 );
  twobit_load( 1, 5 );
  twobit_pop( 5 );
  twobit_branch( 1347, compiled_block_1_1347 );
  twobit_label( 1437, compiled_block_1_1437 );
  twobit_load( 1, 5 );
  twobit_pop( 5 );
  twobit_branch( 1347, compiled_block_1_1347 );
  twobit_label( 1435, compiled_block_1_1435 );
  twobit_load( 1, 5 );
  twobit_pop( 5 );
  twobit_branch( 1347, compiled_block_1_1347 );
  twobit_label( 1432, compiled_block_1_1432 );
  twobit_load( 1, 5 );
  twobit_pop( 5 );
  twobit_branch( 1347, compiled_block_1_1347 );
  twobit_label( 1425, compiled_block_1_1425 );
  twobit_branch( 1347, compiled_block_1_1347 );
  twobit_label( 1423, compiled_block_1_1423 );
  twobit_branch( 1347, compiled_block_1_1347 );
  twobit_label( 1421, compiled_block_1_1421 );
  twobit_branch( 1347, compiled_block_1_1347 );
  twobit_label( 1419, compiled_block_1_1419 );
  twobit_branch( 1347, compiled_block_1_1347 );
  twobit_label( 1417, compiled_block_1_1417 );
  twobit_branch( 1347, compiled_block_1_1347 );
  twobit_label( 1415, compiled_block_1_1415 );
  twobit_branch( 1347, compiled_block_1_1347 );
  twobit_label( 1349, compiled_block_1_1349 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1452, compiled_block_1_1452 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1454, compiled_block_1_1454 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1456, compiled_block_1_1456 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1458, compiled_block_1_1458 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1460, compiled_block_1_1460 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1462, compiled_block_1_1462 ); /* internal:branchf-null? */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_return();
  twobit_label( 1462, compiled_block_1_1462 );
  twobit_branch( 1348, compiled_block_1_1348 );
  twobit_label( 1460, compiled_block_1_1460 );
  twobit_branch( 1348, compiled_block_1_1348 );
  twobit_label( 1458, compiled_block_1_1458 );
  twobit_branch( 1348, compiled_block_1_1348 );
  twobit_label( 1456, compiled_block_1_1456 );
  twobit_branch( 1348, compiled_block_1_1348 );
  twobit_label( 1454, compiled_block_1_1454 );
  twobit_branch( 1348, compiled_block_1_1348 );
  twobit_label( 1452, compiled_block_1_1452 );
  twobit_branch( 1348, compiled_block_1_1348 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_416( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1474, compiled_block_1_1474 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1476, compiled_block_1_1476 ); /* internal:branchf-null? */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_return();
  twobit_label( 1476, compiled_block_1_1476 );
  twobit_branch( 1471, compiled_block_1_1471 );
  twobit_label( 1474, compiled_block_1_1474 );
  twobit_branch( 1471, compiled_block_1_1471 );
  twobit_label( 1470, compiled_block_1_1470 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1480, compiled_block_1_1480 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1482, compiled_block_1_1482 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1484, compiled_block_1_1484 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1486, compiled_block_1_1486 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1488, compiled_block_1_1488 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1490, compiled_block_1_1490 ); /* internal:branchf-null? */
  twobit_save( 10 );
  twobit_store( 0, 0 );
  twobit_store( 1, 10 );
  twobit_store( 4, 1 );
  twobit_store( 30, 3 );
  twobit_store( 31, 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1491, compiled_block_1_1491 );
  twobit_invoke( 1 );
  twobit_label( 1491, compiled_block_1_1491 );
  twobit_load( 0, 0 );
  twobit_branchf( 1493, compiled_block_1_1493 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1494, compiled_block_1_1494 );
  twobit_invoke( 1 );
  twobit_label( 1494, compiled_block_1_1494 );
  twobit_load( 0, 0 );
  twobit_branchf( 1496, compiled_block_1_1496 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1497, compiled_block_1_1497 );
  twobit_invoke( 5 );
  twobit_label( 1497, compiled_block_1_1497 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1498, compiled_block_1_1498 );
  twobit_invoke( 5 );
  twobit_label( 1498, compiled_block_1_1498 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1499, compiled_block_1_1499 );
  twobit_invoke( 5 );
  twobit_label( 1499, compiled_block_1_1499 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1500, compiled_block_1_1500 );
  twobit_invoke( 5 );
  twobit_label( 1500, compiled_block_1_1500 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1501, compiled_block_1_1501 );
  twobit_invoke( 5 );
  twobit_label( 1501, compiled_block_1_1501 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1502, compiled_block_1_1502 );
  twobit_invoke( 5 );
  twobit_label( 1502, compiled_block_1_1502 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1503, compiled_block_1_1503 );
  twobit_invoke( 5 );
  twobit_label( 1503, compiled_block_1_1503 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1504, compiled_block_1_1504 );
  twobit_invoke( 5 );
  twobit_label( 1504, compiled_block_1_1504 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1505, compiled_block_1_1505 );
  twobit_invoke( 5 );
  twobit_label( 1505, compiled_block_1_1505 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1506, compiled_block_1_1506 );
  twobit_invoke( 5 );
  twobit_label( 1506, compiled_block_1_1506 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1507, compiled_block_1_1507 );
  twobit_invoke( 5 );
  twobit_label( 1507, compiled_block_1_1507 );
  twobit_load( 0, 0 );
  twobit_load( 3, 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 10 );
  twobit_return();
  twobit_label( 1496, compiled_block_1_1496 );
  twobit_load( 1, 10 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_pop( 10 );
  twobit_invoke( 1 );
  twobit_label( 1493, compiled_block_1_1493 );
  twobit_load( 1, 10 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_pop( 10 );
  twobit_invoke( 1 );
  twobit_label( 1490, compiled_block_1_1490 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1488, compiled_block_1_1488 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1486, compiled_block_1_1486 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1484, compiled_block_1_1484 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1482, compiled_block_1_1482 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1480, compiled_block_1_1480 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1471, compiled_block_1_1471 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1517, compiled_block_1_1517 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1519, compiled_block_1_1519 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1521, compiled_block_1_1521 ); /* internal:branchf-pair? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 3, 2 );
  twobit_store( 4, 3 );
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 12 ); /* ex:identifier? */
  twobit_setrtn( 1522, compiled_block_1_1522 );
  twobit_invoke( 1 );
  twobit_label( 1522, compiled_block_1_1522 );
  twobit_load( 0, 0 );
  twobit_branchf( 1524, compiled_block_1_1524 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1525, compiled_block_1_1525 );
  twobit_invoke( 5 );
  twobit_label( 1525, compiled_block_1_1525 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 15 ); /* ex:free-identifier=? */
  twobit_setrtn( 1526, compiled_block_1_1526 );
  twobit_invoke( 2 );
  twobit_label( 1526, compiled_block_1_1526 );
  twobit_load( 0, 0 );
  twobit_skip( 1523, compiled_block_1_1523 );
  twobit_label( 1524, compiled_block_1_1524 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1523, compiled_block_1_1523 );
  twobit_branchf( 1528, compiled_block_1_1528 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1529, compiled_block_1_1529 );
  twobit_invoke( 1 );
  twobit_label( 1529, compiled_block_1_1529 );
  twobit_load( 0, 0 );
  twobit_branchf( 1531, compiled_block_1_1531 );
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1533, compiled_block_1_1533 ); /* internal:branchf-null? */
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1534, compiled_block_1_1534 );
  twobit_invoke( 5 );
  twobit_label( 1534, compiled_block_1_1534 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1533, compiled_block_1_1533 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1470, compiled_block_1_1470 );
  twobit_label( 1531, compiled_block_1_1531 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1470, compiled_block_1_1470 );
  twobit_label( 1528, compiled_block_1_1528 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1470, compiled_block_1_1470 );
  twobit_label( 1521, compiled_block_1_1521 );
  twobit_branch( 1470, compiled_block_1_1470 );
  twobit_label( 1519, compiled_block_1_1519 );
  twobit_branch( 1470, compiled_block_1_1470 );
  twobit_label( 1517, compiled_block_1_1517 );
  twobit_branch( 1470, compiled_block_1_1470 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_417( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1545, compiled_block_1_1545 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1547, compiled_block_1_1547 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1549, compiled_block_1_1549 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1551, compiled_block_1_1551 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1553, compiled_block_1_1553 ); /* internal:branchf-null? */
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 2, 3 );
  twobit_store( 3, 2 );
  twobit_store( 31, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1554, compiled_block_1_1554 );
  twobit_invoke( 5 );
  twobit_label( 1554, compiled_block_1_1554 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 2 ); /* () */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1555, compiled_block_1_1555 );
  twobit_invoke( 5 );
  twobit_label( 1555, compiled_block_1_1555 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1556, compiled_block_1_1556 );
  twobit_invoke( 5 );
  twobit_label( 1556, compiled_block_1_1556 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_stack( 3 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1557, compiled_block_1_1557 );
  twobit_invoke( 5 );
  twobit_label( 1557, compiled_block_1_1557 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1553, compiled_block_1_1553 );
  twobit_branch( 1542, compiled_block_1_1542 );
  twobit_label( 1551, compiled_block_1_1551 );
  twobit_branch( 1542, compiled_block_1_1542 );
  twobit_label( 1549, compiled_block_1_1549 );
  twobit_branch( 1542, compiled_block_1_1542 );
  twobit_label( 1547, compiled_block_1_1547 );
  twobit_branch( 1542, compiled_block_1_1542 );
  twobit_label( 1545, compiled_block_1_1545 );
  twobit_label( 1542, compiled_block_1_1542 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1564, compiled_block_1_1564 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1566, compiled_block_1_1566 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1568, compiled_block_1_1568 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1570, compiled_block_1_1570 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1572, compiled_block_1_1572 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1574, compiled_block_1_1574 ); /* internal:branchf-null? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_store( 30, 4 );
  twobit_store( 31, 1 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1575, compiled_block_1_1575 );
  twobit_invoke( 5 );
  twobit_label( 1575, compiled_block_1_1575 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1576, compiled_block_1_1576 );
  twobit_invoke( 5 );
  twobit_label( 1576, compiled_block_1_1576 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1577, compiled_block_1_1577 );
  twobit_invoke( 5 );
  twobit_label( 1577, compiled_block_1_1577 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1574, compiled_block_1_1574 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1572, compiled_block_1_1572 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1570, compiled_block_1_1570 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1568, compiled_block_1_1568 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1566, compiled_block_1_1566 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1564, compiled_block_1_1564 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_418( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1586, compiled_block_1_1586 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1588, compiled_block_1_1588 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1590, compiled_block_1_1590 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1592, compiled_block_1_1592 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1594, compiled_block_1_1594 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1596, compiled_block_1_1596 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 29 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1598, compiled_block_1_1598 ); /* internal:branchf-null? */
  twobit_save( 19 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 3, 18 );
  twobit_store( 29, 7 );
  twobit_store( 30, 4 );
  twobit_store( 31, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1599, compiled_block_1_1599 );
  twobit_invoke( 5 );
  twobit_label( 1599, compiled_block_1_1599 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 19 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1600, compiled_block_1_1600 );
  twobit_invoke( 5 );
  twobit_label( 1600, compiled_block_1_1600 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 17 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 2 ); /* () */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 2 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_stack( 2 );
  twobit_op2_58( 2 ); /* cons */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 16 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1601, compiled_block_1_1601 );
  twobit_invoke( 5 );
  twobit_label( 1601, compiled_block_1_1601 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 15 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1602, compiled_block_1_1602 );
  twobit_invoke( 5 );
  twobit_label( 1602, compiled_block_1_1602 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1603, compiled_block_1_1603 );
  twobit_invoke( 5 );
  twobit_label( 1603, compiled_block_1_1603 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 14 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1604, compiled_block_1_1604 );
  twobit_invoke( 5 );
  twobit_label( 1604, compiled_block_1_1604 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 13 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1605, compiled_block_1_1605 );
  twobit_invoke( 5 );
  twobit_label( 1605, compiled_block_1_1605 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1606, compiled_block_1_1606 );
  twobit_invoke( 5 );
  twobit_label( 1606, compiled_block_1_1606 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1607, compiled_block_1_1607 );
  twobit_invoke( 5 );
  twobit_label( 1607, compiled_block_1_1607 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1608, compiled_block_1_1608 );
  twobit_invoke( 5 );
  twobit_label( 1608, compiled_block_1_1608 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1609, compiled_block_1_1609 );
  twobit_invoke( 5 );
  twobit_label( 1609, compiled_block_1_1609 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1610, compiled_block_1_1610 );
  twobit_invoke( 5 );
  twobit_label( 1610, compiled_block_1_1610 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1611, compiled_block_1_1611 );
  twobit_invoke( 5 );
  twobit_label( 1611, compiled_block_1_1611 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1612, compiled_block_1_1612 );
  twobit_invoke( 5 );
  twobit_label( 1612, compiled_block_1_1612 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1613, compiled_block_1_1613 );
  twobit_invoke( 5 );
  twobit_label( 1613, compiled_block_1_1613 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1614, compiled_block_1_1614 );
  twobit_invoke( 5 );
  twobit_label( 1614, compiled_block_1_1614 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1615, compiled_block_1_1615 );
  twobit_invoke( 5 );
  twobit_label( 1615, compiled_block_1_1615 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1616, compiled_block_1_1616 );
  twobit_invoke( 5 );
  twobit_label( 1616, compiled_block_1_1616 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1617, compiled_block_1_1617 );
  twobit_invoke( 5 );
  twobit_label( 1617, compiled_block_1_1617 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1618, compiled_block_1_1618 );
  twobit_invoke( 5 );
  twobit_label( 1618, compiled_block_1_1618 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_const( 12 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 7 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 13 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1619, compiled_block_1_1619 );
  twobit_invoke( 5 );
  twobit_label( 1619, compiled_block_1_1619 );
  twobit_load( 0, 0 );
  twobit_load( 3, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1620, compiled_block_1_1620 );
  twobit_invoke( 5 );
  twobit_label( 1620, compiled_block_1_1620 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1621, compiled_block_1_1621 );
  twobit_invoke( 5 );
  twobit_label( 1621, compiled_block_1_1621 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_const( 12 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 7 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 13 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 7 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1622, compiled_block_1_1622 );
  twobit_invoke( 5 );
  twobit_label( 1622, compiled_block_1_1622 );
  twobit_load( 0, 0 );
  twobit_load( 3, 7 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1623, compiled_block_1_1623 );
  twobit_invoke( 5 );
  twobit_label( 1623, compiled_block_1_1623 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 13 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 14 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 15 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 16 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 17 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 18 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 19 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 19 );
  twobit_return();
  twobit_label( 1598, compiled_block_1_1598 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1596, compiled_block_1_1596 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1594, compiled_block_1_1594 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1592, compiled_block_1_1592 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1590, compiled_block_1_1590 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1588, compiled_block_1_1588 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1586, compiled_block_1_1586 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 2 ); /*  debug-compare~1ayXVW~31904 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 3 ); /*  default-compare~1ayXVW~31903 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 4 ); /*  vector-compare-as-list~1ayXVW~31902 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 5 ); /*  vector-compare~1ayXVW~31901 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 6 ); /*  list-compare-as-vector~1ayXVW~31900 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 7 ); /*  list-compare~1ayXVW~31899 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 8 ); /*  pair-compare~1ayXVW~31898 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 9 ); /*  pair-compare-cdr~1ayXVW~31897 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 10 ); /*  pair-compare-car~1ayXVW~31896 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 11 ); /*  number-compare~1ayXVW~31895 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 12 ); /*  complex-compare~1ayXVW~31894 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 13 ); /*  real-compare~1ayXVW~31893 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 14 ); /*  rational-compare~1ayXVW~31891 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 15 ); /*  integer-compare~1ayXVW~31889 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 16 ); /*  symbol-compare~1ayXVW~31887 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 17 ); /*  string-compare-ci~1ayXVW~31886 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 18 ); /*  string-compare~1ayXVW~31884 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 19 ); /*  char-compare-ci~1ayXVW~31882 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 20 ); /*  char-compare~1ayXVW~31880 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 21 ); /*  boolean-compare~1ayXVW~31878 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 22 ); /*  compare-by=/>~1ayXVW~31667 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 23 ); /*  compare-by=/<~1ayXVW~31666 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 24 ); /*  compare-by>=~1ayXVW~31665 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 25 ); /*  compare-by<=~1ayXVW~31664 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 26 ); /*  compare-by>~1ayXVW~31663 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 27 ); /*  compare-by<~1ayXVW~31662 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 28 ); /*  kth-largest~1ayXVW~31661 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 29 ); /*  max-compare~1ayXVW~31660 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 30 ); /*  min-compare~1ayXVW~31659 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 31 ); /*  pairwise-not=?~1ayXVW~31658 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 32 ); /*  chain>=?~1ayXVW~31657 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 33 ); /*  chain<=?~1ayXVW~31655 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 34 ); /*  chain>?~1ayXVW~31653 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 35 ); /*  chain<?~1ayXVW~31651 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 36 ); /*  chain=?~1ayXVW~31649 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 37 ); /*  >=/>=?~1ayXVW~31629 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 38 ); /*  >=/>?~1ayXVW~31627 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 39 ); /*  >/>=?~1ayXVW~31625 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 40 ); /*  >/>?~1ayXVW~31623 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 41 ); /*  <=/<=?~1ayXVW~31621 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 42 ); /*  <=/<?~1ayXVW~31619 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 43 ); /*  </<=?~1ayXVW~31617 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 44 ); /*  </<?~1ayXVW~31615 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 45 ); /*  not=?~1ayXVW~31592 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 46 ); /*  >=?~1ayXVW~31590 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 47 ); /*  <=?~1ayXVW~31588 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 48 ); /*  >?~1ayXVW~31586 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 49 ); /*  <?~1ayXVW~31584 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 50 ); /*  =?~1ayXVW~31582 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 51 ); /*  compare:checked~1ayXVW~31415 */
  twobit_lambda( compiled_start_1_4, 53, 0 );
  twobit_setglbl( 54 ); /*  compare:checked~1ayXVW~31415 */
  twobit_lambda( compiled_start_1_5, 56, 0 );
  twobit_setglbl( 57 ); /*  =?~1ayXVW~31582 */
  twobit_lambda( compiled_start_1_6, 59, 0 );
  twobit_setglbl( 49 ); /*  <?~1ayXVW~31584 */
  twobit_lambda( compiled_start_1_7, 61, 0 );
  twobit_setglbl( 48 ); /*  >?~1ayXVW~31586 */
  twobit_lambda( compiled_start_1_8, 63, 0 );
  twobit_setglbl( 47 ); /*  <=?~1ayXVW~31588 */
  twobit_lambda( compiled_start_1_9, 65, 0 );
  twobit_setglbl( 46 ); /*  >=?~1ayXVW~31590 */
  twobit_lambda( compiled_start_1_10, 67, 0 );
  twobit_setglbl( 45 ); /*  not=?~1ayXVW~31592 */
  twobit_lambda( compiled_start_1_11, 69, 0 );
  twobit_setglbl( 44 ); /*  </<?~1ayXVW~31615 */
  twobit_lambda( compiled_start_1_12, 71, 0 );
  twobit_setglbl( 43 ); /*  </<=?~1ayXVW~31617 */
  twobit_lambda( compiled_start_1_13, 73, 0 );
  twobit_setglbl( 42 ); /*  <=/<?~1ayXVW~31619 */
  twobit_lambda( compiled_start_1_14, 75, 0 );
  twobit_setglbl( 41 ); /*  <=/<=?~1ayXVW~31621 */
  twobit_lambda( compiled_start_1_15, 77, 0 );
  twobit_setglbl( 40 ); /*  >/>?~1ayXVW~31623 */
  twobit_lambda( compiled_start_1_16, 79, 0 );
  twobit_setglbl( 39 ); /*  >/>=?~1ayXVW~31625 */
  twobit_lambda( compiled_start_1_17, 81, 0 );
  twobit_setglbl( 38 ); /*  >=/>?~1ayXVW~31627 */
  twobit_lambda( compiled_start_1_18, 83, 0 );
  twobit_setglbl( 37 ); /*  >=/>=?~1ayXVW~31629 */
  twobit_lambda( compiled_start_1_19, 85, 0 );
  twobit_setglbl( 36 ); /*  chain=?~1ayXVW~31649 */
  twobit_lambda( compiled_start_1_20, 87, 0 );
  twobit_setglbl( 35 ); /*  chain<?~1ayXVW~31651 */
  twobit_lambda( compiled_start_1_21, 89, 0 );
  twobit_setglbl( 34 ); /*  chain>?~1ayXVW~31653 */
  twobit_lambda( compiled_start_1_22, 91, 0 );
  twobit_setglbl( 33 ); /*  chain<=?~1ayXVW~31655 */
  twobit_lambda( compiled_start_1_23, 93, 0 );
  twobit_setglbl( 32 ); /*  chain>=?~1ayXVW~31657 */
  twobit_global( 94 ); /* = */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_24, 96, 1 );
  twobit_setglbl( 31 ); /*  pairwise-not=?~1ayXVW~31658 */
  twobit_lambda( compiled_start_1_25, 98, 0 );
  twobit_setglbl( 30 ); /*  min-compare~1ayXVW~31659 */
  twobit_lambda( compiled_start_1_26, 100, 0 );
  twobit_setglbl( 29 ); /*  max-compare~1ayXVW~31660 */
  twobit_global( 101 ); /* < */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_27, 103, 1 );
  twobit_setglbl( 28 ); /*  kth-largest~1ayXVW~31661 */
  twobit_lambda( compiled_start_1_28, 105, 0 );
  twobit_setglbl( 27 ); /*  compare-by<~1ayXVW~31662 */
  twobit_lambda( compiled_start_1_29, 107, 0 );
  twobit_setglbl( 26 ); /*  compare-by>~1ayXVW~31663 */
  twobit_lambda( compiled_start_1_30, 109, 0 );
  twobit_setglbl( 25 ); /*  compare-by<=~1ayXVW~31664 */
  twobit_lambda( compiled_start_1_31, 111, 0 );
  twobit_setglbl( 24 ); /*  compare-by>=~1ayXVW~31665 */
  twobit_lambda( compiled_start_1_32, 113, 0 );
  twobit_setglbl( 23 ); /*  compare-by=/<~1ayXVW~31666 */
  twobit_lambda( compiled_start_1_33, 115, 0 );
  twobit_setglbl( 22 ); /*  compare-by=/>~1ayXVW~31667 */
  twobit_lambda( compiled_start_1_34, 117, 0 );
  twobit_setglbl( 21 ); /*  boolean-compare~1ayXVW~31878 */
  twobit_global( 118 ); /* char<? */
  twobit_setreg( 4 );
  twobit_global( 119 ); /* char=? */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_35, 121, 2 );
  twobit_setglbl( 20 ); /*  char-compare~1ayXVW~31880 */
  twobit_global( 122 ); /* char-ci<? */
  twobit_setreg( 4 );
  twobit_global( 123 ); /* char-ci=? */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_36, 125, 2 );
  twobit_setglbl( 19 ); /*  char-compare-ci~1ayXVW~31882 */
  twobit_global( 126 ); /* string<? */
  twobit_setreg( 4 );
  twobit_global( 127 ); /* string=? */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_37, 129, 2 );
  twobit_setglbl( 18 ); /*  string-compare~1ayXVW~31884 */
  twobit_global( 130 ); /* string-ci<? */
  twobit_setreg( 4 );
  twobit_global( 131 ); /* string-ci=? */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_38, 133, 2 );
  twobit_setglbl( 17 ); /*  string-compare-ci~1ayXVW~31886 */
  twobit_lambda( compiled_start_1_39, 135, 0 );
  twobit_setglbl( 16 ); /*  symbol-compare~1ayXVW~31887 */
  twobit_global( 136 ); /* < */
  twobit_setreg( 4 );
  twobit_global( 137 ); /* = */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_40, 139, 2 );
  twobit_setglbl( 15 ); /*  integer-compare~1ayXVW~31889 */
  twobit_global( 140 ); /* < */
  twobit_setreg( 4 );
  twobit_global( 141 ); /* = */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_41, 143, 2 );
  twobit_setglbl( 14 ); /*  rational-compare~1ayXVW~31891 */
  twobit_global( 144 ); /* < */
  twobit_setreg( 4 );
  twobit_global( 145 ); /* = */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_42, 147, 2 );
  twobit_setglbl( 13 ); /*  real-compare~1ayXVW~31893 */
  twobit_lambda( compiled_start_1_43, 149, 0 );
  twobit_setglbl( 12 ); /*  complex-compare~1ayXVW~31894 */
  twobit_lambda( compiled_start_1_44, 151, 0 );
  twobit_setglbl( 11 ); /*  number-compare~1ayXVW~31895 */
  twobit_lambda( compiled_start_1_45, 153, 0 );
  twobit_setglbl( 10 ); /*  pair-compare-car~1ayXVW~31896 */
  twobit_lambda( compiled_start_1_46, 155, 0 );
  twobit_setglbl( 9 ); /*  pair-compare-cdr~1ayXVW~31897 */
  twobit_lambda( compiled_start_1_47, 157, 0 );
  twobit_setglbl( 8 ); /*  pair-compare~1ayXVW~31898 */
  twobit_lambda( compiled_start_1_48, 159, 0 );
  twobit_setglbl( 7 ); /*  list-compare~1ayXVW~31899 */
  twobit_lambda( compiled_start_1_49, 161, 0 );
  twobit_setglbl( 6 ); /*  list-compare-as-vector~1ayXVW~31900 */
  twobit_global( 162 ); /* = */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_50, 164, 1 );
  twobit_setglbl( 5 ); /*  vector-compare~1ayXVW~31901 */
  twobit_global( 165 ); /* = */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_51, 167, 1 );
  twobit_setglbl( 4 ); /*  vector-compare-as-list~1ayXVW~31902 */
  twobit_lambda( compiled_start_1_52, 169, 0 );
  twobit_setglbl( 3 ); /*  default-compare~1ayXVW~31903 */
  twobit_lambda( compiled_start_1_53, 171, 0 );
  twobit_setglbl( 2 ); /*  debug-compare~1ayXVW~31904 */
  twobit_global( 172 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_402, 2, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 3, 2 );
  twobit_global( 3 ); /*  for-each~1ayXVW~1382 */
  twobit_setrtn( 1634, compiled_block_1_1634 );
  twobit_invoke( 2 );
  twobit_label( 1634, compiled_block_1_1634 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_402( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 1635, compiled_block_1_1635 );
  twobit_invoke( 1 );
  twobit_label( 1635, compiled_block_1_1635 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(0), 392, compiled_temp_1_392, 1637, compiled_block_1_1637 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_393, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1637, compiled_block_1_1637 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 394, compiled_temp_1_394, 1648, compiled_block_1_1648 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_395, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1648, compiled_block_1_1648 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(2), 396, compiled_temp_1_396, 1659, compiled_block_1_1659 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_397, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1659, compiled_block_1_1659 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 398, compiled_temp_1_398, 1670, compiled_block_1_1670 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_399, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1670, compiled_block_1_1670 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 11 );
  twobit_setreg( 2 );
  twobit_global( 12 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_393( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lambda( compiled_start_1_401, 2, 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_401( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 1638, compiled_block_1_1638 );
  twobit_invoke( 2 );
  twobit_label( 1638, compiled_block_1_1638 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 1640, compiled_block_1_1640 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1640, compiled_block_1_1640 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1642, compiled_block_1_1642 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1641, compiled_block_1_1641 );
  twobit_label( 1642, compiled_block_1_1642 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 1641, compiled_block_1_1641 );
  twobit_branchf( 1644, compiled_block_1_1644 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1644, compiled_block_1_1644 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_395( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_400, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_400( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1649, compiled_block_1_1649 );
  twobit_invoke( 2 );
  twobit_label( 1649, compiled_block_1_1649 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 1651, compiled_block_1_1651 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1651, compiled_block_1_1651 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1653, compiled_block_1_1653 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1652, compiled_block_1_1652 );
  twobit_label( 1653, compiled_block_1_1653 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 1652, compiled_block_1_1652 );
  twobit_branchf( 1655, compiled_block_1_1655 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1655, compiled_block_1_1655 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_397( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 1660, compiled_block_1_1660 );
  twobit_invoke( 2 );
  twobit_label( 1660, compiled_block_1_1660 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 1662, compiled_block_1_1662 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1662, compiled_block_1_1662 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1664, compiled_block_1_1664 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1663, compiled_block_1_1663 );
  twobit_label( 1664, compiled_block_1_1664 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 1663, compiled_block_1_1663 );
  twobit_branchf( 1666, compiled_block_1_1666 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1666, compiled_block_1_1666 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_399( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1672, compiled_block_1_1672 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1673, compiled_block_1_1673 );
  twobit_invoke( 2 );
  twobit_label( 1673, compiled_block_1_1673 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 1675, compiled_block_1_1675 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1675, compiled_block_1_1675 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1677, compiled_block_1_1677 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1676, compiled_block_1_1676 );
  twobit_label( 1677, compiled_block_1_1677 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 1676, compiled_block_1_1676 );
  twobit_branchf( 1679, compiled_block_1_1679 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1679, compiled_block_1_1679 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1672, compiled_block_1_1672 );
  twobit_movereg( 1, 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_6( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 1684, compiled_block_1_1684 );
  twobit_invoke( 1 );
  twobit_label( 1684, compiled_block_1_1684 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(0), 382, compiled_temp_1_382, 1686, compiled_block_1_1686 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_383, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1686, compiled_block_1_1686 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 384, compiled_temp_1_384, 1697, compiled_block_1_1697 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_385, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1697, compiled_block_1_1697 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(2), 386, compiled_temp_1_386, 1708, compiled_block_1_1708 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_387, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1708, compiled_block_1_1708 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 388, compiled_temp_1_388, 1719, compiled_block_1_1719 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_389, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1719, compiled_block_1_1719 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 11 );
  twobit_setreg( 2 );
  twobit_global( 12 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_383( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lambda( compiled_start_1_391, 2, 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_391( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 1687, compiled_block_1_1687 );
  twobit_invoke( 2 );
  twobit_label( 1687, compiled_block_1_1687 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 1689, compiled_block_1_1689 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1689, compiled_block_1_1689 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1691, compiled_block_1_1691 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1690, compiled_block_1_1690 );
  twobit_label( 1691, compiled_block_1_1691 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 1690, compiled_block_1_1690 );
  twobit_branchf( 1693, compiled_block_1_1693 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1693, compiled_block_1_1693 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_385( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_390, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_390( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1698, compiled_block_1_1698 );
  twobit_invoke( 2 );
  twobit_label( 1698, compiled_block_1_1698 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 1700, compiled_block_1_1700 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1700, compiled_block_1_1700 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1702, compiled_block_1_1702 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1701, compiled_block_1_1701 );
  twobit_label( 1702, compiled_block_1_1702 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 1701, compiled_block_1_1701 );
  twobit_branchf( 1704, compiled_block_1_1704 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1704, compiled_block_1_1704 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_387( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 1709, compiled_block_1_1709 );
  twobit_invoke( 2 );
  twobit_label( 1709, compiled_block_1_1709 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 1711, compiled_block_1_1711 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1711, compiled_block_1_1711 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1713, compiled_block_1_1713 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1712, compiled_block_1_1712 );
  twobit_label( 1713, compiled_block_1_1713 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 1712, compiled_block_1_1712 );
  twobit_branchf( 1715, compiled_block_1_1715 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1715, compiled_block_1_1715 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_389( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1721, compiled_block_1_1721 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1722, compiled_block_1_1722 );
  twobit_invoke( 2 );
  twobit_label( 1722, compiled_block_1_1722 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 1724, compiled_block_1_1724 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1724, compiled_block_1_1724 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1726, compiled_block_1_1726 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1725, compiled_block_1_1725 );
  twobit_label( 1726, compiled_block_1_1726 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 1725, compiled_block_1_1725 );
  twobit_branchf( 1728, compiled_block_1_1728 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1728, compiled_block_1_1728 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1721, compiled_block_1_1721 );
  twobit_movereg( 1, 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_7( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 1733, compiled_block_1_1733 );
  twobit_invoke( 1 );
  twobit_label( 1733, compiled_block_1_1733 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(0), 372, compiled_temp_1_372, 1735, compiled_block_1_1735 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_373, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1735, compiled_block_1_1735 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 374, compiled_temp_1_374, 1746, compiled_block_1_1746 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_375, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1746, compiled_block_1_1746 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(2), 376, compiled_temp_1_376, 1757, compiled_block_1_1757 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_377, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1757, compiled_block_1_1757 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 378, compiled_temp_1_378, 1768, compiled_block_1_1768 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_379, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1768, compiled_block_1_1768 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 11 );
  twobit_setreg( 2 );
  twobit_global( 12 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_373( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lambda( compiled_start_1_381, 2, 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_381( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 1736, compiled_block_1_1736 );
  twobit_invoke( 2 );
  twobit_label( 1736, compiled_block_1_1736 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1738, compiled_block_1_1738 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1738, compiled_block_1_1738 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 1740, compiled_block_1_1740 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1739, compiled_block_1_1739 );
  twobit_label( 1740, compiled_block_1_1740 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 1739, compiled_block_1_1739 );
  twobit_branchf( 1742, compiled_block_1_1742 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1742, compiled_block_1_1742 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_375( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_380, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_380( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1747, compiled_block_1_1747 );
  twobit_invoke( 2 );
  twobit_label( 1747, compiled_block_1_1747 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1749, compiled_block_1_1749 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1749, compiled_block_1_1749 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 1751, compiled_block_1_1751 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1750, compiled_block_1_1750 );
  twobit_label( 1751, compiled_block_1_1751 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 1750, compiled_block_1_1750 );
  twobit_branchf( 1753, compiled_block_1_1753 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1753, compiled_block_1_1753 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_377( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 1758, compiled_block_1_1758 );
  twobit_invoke( 2 );
  twobit_label( 1758, compiled_block_1_1758 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1760, compiled_block_1_1760 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1760, compiled_block_1_1760 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 1762, compiled_block_1_1762 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1761, compiled_block_1_1761 );
  twobit_label( 1762, compiled_block_1_1762 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 1761, compiled_block_1_1761 );
  twobit_branchf( 1764, compiled_block_1_1764 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1764, compiled_block_1_1764 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_379( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1770, compiled_block_1_1770 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1771, compiled_block_1_1771 );
  twobit_invoke( 2 );
  twobit_label( 1771, compiled_block_1_1771 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1773, compiled_block_1_1773 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1773, compiled_block_1_1773 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 1775, compiled_block_1_1775 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1774, compiled_block_1_1774 );
  twobit_label( 1775, compiled_block_1_1775 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 1774, compiled_block_1_1774 );
  twobit_branchf( 1777, compiled_block_1_1777 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1777, compiled_block_1_1777 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1770, compiled_block_1_1770 );
  twobit_movereg( 1, 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_8( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 1782, compiled_block_1_1782 );
  twobit_invoke( 1 );
  twobit_label( 1782, compiled_block_1_1782 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(0), 362, compiled_temp_1_362, 1784, compiled_block_1_1784 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_363, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1784, compiled_block_1_1784 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 364, compiled_temp_1_364, 1795, compiled_block_1_1795 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_365, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1795, compiled_block_1_1795 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(2), 366, compiled_temp_1_366, 1806, compiled_block_1_1806 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_367, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1806, compiled_block_1_1806 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 368, compiled_temp_1_368, 1817, compiled_block_1_1817 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_369, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1817, compiled_block_1_1817 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 11 );
  twobit_setreg( 2 );
  twobit_global( 12 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_363( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lambda( compiled_start_1_371, 2, 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_371( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 1785, compiled_block_1_1785 );
  twobit_invoke( 2 );
  twobit_label( 1785, compiled_block_1_1785 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 1787, compiled_block_1_1787 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1786, compiled_block_1_1786 );
  twobit_label( 1787, compiled_block_1_1787 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 1786, compiled_block_1_1786 );
  twobit_branchf( 1789, compiled_block_1_1789 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1789, compiled_block_1_1789 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1791, compiled_block_1_1791 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1791, compiled_block_1_1791 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_365( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_370, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_370( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1796, compiled_block_1_1796 );
  twobit_invoke( 2 );
  twobit_label( 1796, compiled_block_1_1796 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 1798, compiled_block_1_1798 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1797, compiled_block_1_1797 );
  twobit_label( 1798, compiled_block_1_1798 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 1797, compiled_block_1_1797 );
  twobit_branchf( 1800, compiled_block_1_1800 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1800, compiled_block_1_1800 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1802, compiled_block_1_1802 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1802, compiled_block_1_1802 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_367( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 1807, compiled_block_1_1807 );
  twobit_invoke( 2 );
  twobit_label( 1807, compiled_block_1_1807 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 1809, compiled_block_1_1809 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1808, compiled_block_1_1808 );
  twobit_label( 1809, compiled_block_1_1809 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 1808, compiled_block_1_1808 );
  twobit_branchf( 1811, compiled_block_1_1811 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1811, compiled_block_1_1811 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1813, compiled_block_1_1813 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1813, compiled_block_1_1813 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_369( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1819, compiled_block_1_1819 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1820, compiled_block_1_1820 );
  twobit_invoke( 2 );
  twobit_label( 1820, compiled_block_1_1820 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 1822, compiled_block_1_1822 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1821, compiled_block_1_1821 );
  twobit_label( 1822, compiled_block_1_1822 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 1821, compiled_block_1_1821 );
  twobit_branchf( 1824, compiled_block_1_1824 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1824, compiled_block_1_1824 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1826, compiled_block_1_1826 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1826, compiled_block_1_1826 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1819, compiled_block_1_1819 );
  twobit_movereg( 1, 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_9( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 1831, compiled_block_1_1831 );
  twobit_invoke( 1 );
  twobit_label( 1831, compiled_block_1_1831 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(0), 352, compiled_temp_1_352, 1833, compiled_block_1_1833 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_353, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1833, compiled_block_1_1833 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 354, compiled_temp_1_354, 1844, compiled_block_1_1844 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_355, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1844, compiled_block_1_1844 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(2), 356, compiled_temp_1_356, 1855, compiled_block_1_1855 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_357, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1855, compiled_block_1_1855 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 358, compiled_temp_1_358, 1866, compiled_block_1_1866 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_359, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1866, compiled_block_1_1866 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 11 );
  twobit_setreg( 2 );
  twobit_global( 12 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_353( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lambda( compiled_start_1_361, 2, 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_361( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 1834, compiled_block_1_1834 );
  twobit_invoke( 2 );
  twobit_label( 1834, compiled_block_1_1834 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1836, compiled_block_1_1836 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1835, compiled_block_1_1835 );
  twobit_label( 1836, compiled_block_1_1836 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 1835, compiled_block_1_1835 );
  twobit_branchf( 1838, compiled_block_1_1838 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1838, compiled_block_1_1838 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 1840, compiled_block_1_1840 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1840, compiled_block_1_1840 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_355( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_360, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_360( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1845, compiled_block_1_1845 );
  twobit_invoke( 2 );
  twobit_label( 1845, compiled_block_1_1845 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1847, compiled_block_1_1847 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1846, compiled_block_1_1846 );
  twobit_label( 1847, compiled_block_1_1847 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 1846, compiled_block_1_1846 );
  twobit_branchf( 1849, compiled_block_1_1849 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1849, compiled_block_1_1849 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 1851, compiled_block_1_1851 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1851, compiled_block_1_1851 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_357( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 1856, compiled_block_1_1856 );
  twobit_invoke( 2 );
  twobit_label( 1856, compiled_block_1_1856 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1858, compiled_block_1_1858 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1857, compiled_block_1_1857 );
  twobit_label( 1858, compiled_block_1_1858 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 1857, compiled_block_1_1857 );
  twobit_branchf( 1860, compiled_block_1_1860 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1860, compiled_block_1_1860 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 1862, compiled_block_1_1862 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1862, compiled_block_1_1862 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_359( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1868, compiled_block_1_1868 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1869, compiled_block_1_1869 );
  twobit_invoke( 2 );
  twobit_label( 1869, compiled_block_1_1869 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1871, compiled_block_1_1871 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1870, compiled_block_1_1870 );
  twobit_label( 1871, compiled_block_1_1871 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 1870, compiled_block_1_1870 );
  twobit_branchf( 1873, compiled_block_1_1873 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1873, compiled_block_1_1873 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 1875, compiled_block_1_1875 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1875, compiled_block_1_1875 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1868, compiled_block_1_1868 );
  twobit_movereg( 1, 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_10( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 1880, compiled_block_1_1880 );
  twobit_invoke( 1 );
  twobit_label( 1880, compiled_block_1_1880 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(0), 342, compiled_temp_1_342, 1882, compiled_block_1_1882 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_343, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1882, compiled_block_1_1882 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 344, compiled_temp_1_344, 1893, compiled_block_1_1893 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_345, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1893, compiled_block_1_1893 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(2), 346, compiled_temp_1_346, 1904, compiled_block_1_1904 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_347, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1904, compiled_block_1_1904 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 348, compiled_temp_1_348, 1915, compiled_block_1_1915 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_349, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1915, compiled_block_1_1915 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 11 );
  twobit_setreg( 2 );
  twobit_global( 12 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_343( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lambda( compiled_start_1_351, 2, 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_351( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 1883, compiled_block_1_1883 );
  twobit_invoke( 2 );
  twobit_label( 1883, compiled_block_1_1883 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1885, compiled_block_1_1885 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1884, compiled_block_1_1884 );
  twobit_label( 1885, compiled_block_1_1885 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 1884, compiled_block_1_1884 );
  twobit_branchf( 1887, compiled_block_1_1887 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1887, compiled_block_1_1887 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 1889, compiled_block_1_1889 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1889, compiled_block_1_1889 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_345( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_350, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_350( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1894, compiled_block_1_1894 );
  twobit_invoke( 2 );
  twobit_label( 1894, compiled_block_1_1894 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1896, compiled_block_1_1896 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1895, compiled_block_1_1895 );
  twobit_label( 1896, compiled_block_1_1896 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 1895, compiled_block_1_1895 );
  twobit_branchf( 1898, compiled_block_1_1898 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1898, compiled_block_1_1898 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 1900, compiled_block_1_1900 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1900, compiled_block_1_1900 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_347( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 1905, compiled_block_1_1905 );
  twobit_invoke( 2 );
  twobit_label( 1905, compiled_block_1_1905 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1907, compiled_block_1_1907 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1906, compiled_block_1_1906 );
  twobit_label( 1907, compiled_block_1_1907 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 1906, compiled_block_1_1906 );
  twobit_branchf( 1909, compiled_block_1_1909 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1909, compiled_block_1_1909 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 1911, compiled_block_1_1911 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1911, compiled_block_1_1911 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_349( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1917, compiled_block_1_1917 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1918, compiled_block_1_1918 );
  twobit_invoke( 2 );
  twobit_label( 1918, compiled_block_1_1918 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1920, compiled_block_1_1920 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1919, compiled_block_1_1919 );
  twobit_label( 1920, compiled_block_1_1920 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 1919, compiled_block_1_1919 );
  twobit_branchf( 1922, compiled_block_1_1922 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1922, compiled_block_1_1922 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 1924, compiled_block_1_1924 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1924, compiled_block_1_1924 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1917, compiled_block_1_1917 );
  twobit_movereg( 1, 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_11( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 1929, compiled_block_1_1929 );
  twobit_invoke( 1 );
  twobit_label( 1929, compiled_block_1_1929 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(0), 332, compiled_temp_1_332, 1931, compiled_block_1_1931 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_333, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1931, compiled_block_1_1931 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 334, compiled_temp_1_334, 1951, compiled_block_1_1951 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_335, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1951, compiled_block_1_1951 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 336, compiled_temp_1_336, 1971, compiled_block_1_1971 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_337, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1971, compiled_block_1_1971 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(4), 338, compiled_temp_1_338, 1991, compiled_block_1_1991 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_339, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1991, compiled_block_1_1991 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 11 );
  twobit_setreg( 2 );
  twobit_global( 12 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_333( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lambda( compiled_start_1_341, 2, 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_341( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 1932, compiled_block_1_1932 );
  twobit_invoke( 2 );
  twobit_label( 1932, compiled_block_1_1932 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 1934, compiled_block_1_1934 ); /* internal:branchf-eq?/imm */
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 1935, compiled_block_1_1935 );
  twobit_invoke( 2 );
  twobit_label( 1935, compiled_block_1_1935 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 1937, compiled_block_1_1937 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1937, compiled_block_1_1937 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1939, compiled_block_1_1939 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1938, compiled_block_1_1938 );
  twobit_label( 1939, compiled_block_1_1939 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 1938, compiled_block_1_1938 );
  twobit_branchf( 1941, compiled_block_1_1941 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1941, compiled_block_1_1941 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1934, compiled_block_1_1934 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1944, compiled_block_1_1944 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1943, compiled_block_1_1943 );
  twobit_label( 1944, compiled_block_1_1944 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 1943, compiled_block_1_1943 );
  twobit_branchf( 1946, compiled_block_1_1946 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_load( 3, 2 );
  twobit_global( 4 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1946, compiled_block_1_1946 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_335( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_340, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_340( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1952, compiled_block_1_1952 );
  twobit_invoke( 2 );
  twobit_label( 1952, compiled_block_1_1952 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 1954, compiled_block_1_1954 ); /* internal:branchf-eq?/imm */
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1955, compiled_block_1_1955 );
  twobit_invoke( 2 );
  twobit_label( 1955, compiled_block_1_1955 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 1957, compiled_block_1_1957 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1957, compiled_block_1_1957 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1959, compiled_block_1_1959 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1958, compiled_block_1_1958 );
  twobit_label( 1959, compiled_block_1_1959 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 1958, compiled_block_1_1958 );
  twobit_branchf( 1961, compiled_block_1_1961 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1961, compiled_block_1_1961 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1954, compiled_block_1_1954 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1964, compiled_block_1_1964 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1963, compiled_block_1_1963 );
  twobit_label( 1964, compiled_block_1_1964 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 1963, compiled_block_1_1963 );
  twobit_branchf( 1966, compiled_block_1_1966 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_load( 3, 2 );
  twobit_global( 3 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1966, compiled_block_1_1966 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_337( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 1972, compiled_block_1_1972 );
  twobit_invoke( 2 );
  twobit_label( 1972, compiled_block_1_1972 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 1974, compiled_block_1_1974 ); /* internal:branchf-eq?/imm */
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 1975, compiled_block_1_1975 );
  twobit_invoke( 2 );
  twobit_label( 1975, compiled_block_1_1975 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 1977, compiled_block_1_1977 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1977, compiled_block_1_1977 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1979, compiled_block_1_1979 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1978, compiled_block_1_1978 );
  twobit_label( 1979, compiled_block_1_1979 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 1978, compiled_block_1_1978 );
  twobit_branchf( 1981, compiled_block_1_1981 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1981, compiled_block_1_1981 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1974, compiled_block_1_1974 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1984, compiled_block_1_1984 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1983, compiled_block_1_1983 );
  twobit_label( 1984, compiled_block_1_1984 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 1983, compiled_block_1_1983 );
  twobit_branchf( 1986, compiled_block_1_1986 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_load( 3, 2 );
  twobit_global( 4 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1986, compiled_block_1_1986 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_339( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 1992, compiled_block_1_1992 );
  twobit_invoke( 2 );
  twobit_label( 1992, compiled_block_1_1992 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 1994, compiled_block_1_1994 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1995, compiled_block_1_1995 );
  twobit_invoke( 2 );
  twobit_label( 1995, compiled_block_1_1995 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 1997, compiled_block_1_1997 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1997, compiled_block_1_1997 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1999, compiled_block_1_1999 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1998, compiled_block_1_1998 );
  twobit_label( 1999, compiled_block_1_1999 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 1998, compiled_block_1_1998 );
  twobit_branchf( 2001, compiled_block_1_2001 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2001, compiled_block_1_2001 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 1994, compiled_block_1_1994 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2004, compiled_block_1_2004 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2003, compiled_block_1_2003 );
  twobit_label( 2004, compiled_block_1_2004 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2003, compiled_block_1_2003 );
  twobit_branchf( 2006, compiled_block_1_2006 );
  twobit_load( 2, 3 );
  twobit_load( 3, 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 2006, compiled_block_1_2006 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_12( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 2011, compiled_block_1_2011 );
  twobit_invoke( 1 );
  twobit_label( 2011, compiled_block_1_2011 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(0), 322, compiled_temp_1_322, 2013, compiled_block_1_2013 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_323, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2013, compiled_block_1_2013 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 324, compiled_temp_1_324, 2033, compiled_block_1_2033 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_325, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2033, compiled_block_1_2033 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 326, compiled_temp_1_326, 2053, compiled_block_1_2053 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_327, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2053, compiled_block_1_2053 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(4), 328, compiled_temp_1_328, 2073, compiled_block_1_2073 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_329, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2073, compiled_block_1_2073 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 11 );
  twobit_setreg( 2 );
  twobit_global( 12 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_323( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lambda( compiled_start_1_331, 2, 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_331( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2014, compiled_block_1_2014 );
  twobit_invoke( 2 );
  twobit_label( 2014, compiled_block_1_2014 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2016, compiled_block_1_2016 ); /* internal:branchf-eq?/imm */
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2017, compiled_block_1_2017 );
  twobit_invoke( 2 );
  twobit_label( 2017, compiled_block_1_2017 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2019, compiled_block_1_2019 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2018, compiled_block_1_2018 );
  twobit_label( 2019, compiled_block_1_2019 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2018, compiled_block_1_2018 );
  twobit_branchf( 2021, compiled_block_1_2021 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2021, compiled_block_1_2021 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2023, compiled_block_1_2023 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2023, compiled_block_1_2023 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2016, compiled_block_1_2016 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2026, compiled_block_1_2026 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2025, compiled_block_1_2025 );
  twobit_label( 2026, compiled_block_1_2026 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2025, compiled_block_1_2025 );
  twobit_branchf( 2028, compiled_block_1_2028 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_load( 3, 2 );
  twobit_global( 4 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2028, compiled_block_1_2028 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_325( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_330, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_330( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 2034, compiled_block_1_2034 );
  twobit_invoke( 2 );
  twobit_label( 2034, compiled_block_1_2034 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2036, compiled_block_1_2036 ); /* internal:branchf-eq?/imm */
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 2037, compiled_block_1_2037 );
  twobit_invoke( 2 );
  twobit_label( 2037, compiled_block_1_2037 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2039, compiled_block_1_2039 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2038, compiled_block_1_2038 );
  twobit_label( 2039, compiled_block_1_2039 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2038, compiled_block_1_2038 );
  twobit_branchf( 2041, compiled_block_1_2041 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2041, compiled_block_1_2041 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2043, compiled_block_1_2043 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2043, compiled_block_1_2043 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2036, compiled_block_1_2036 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2046, compiled_block_1_2046 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2045, compiled_block_1_2045 );
  twobit_label( 2046, compiled_block_1_2046 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2045, compiled_block_1_2045 );
  twobit_branchf( 2048, compiled_block_1_2048 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_load( 3, 2 );
  twobit_global( 3 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2048, compiled_block_1_2048 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_327( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2054, compiled_block_1_2054 );
  twobit_invoke( 2 );
  twobit_label( 2054, compiled_block_1_2054 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2056, compiled_block_1_2056 ); /* internal:branchf-eq?/imm */
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2057, compiled_block_1_2057 );
  twobit_invoke( 2 );
  twobit_label( 2057, compiled_block_1_2057 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2059, compiled_block_1_2059 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2058, compiled_block_1_2058 );
  twobit_label( 2059, compiled_block_1_2059 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2058, compiled_block_1_2058 );
  twobit_branchf( 2061, compiled_block_1_2061 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2061, compiled_block_1_2061 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2063, compiled_block_1_2063 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2063, compiled_block_1_2063 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2056, compiled_block_1_2056 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2066, compiled_block_1_2066 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2065, compiled_block_1_2065 );
  twobit_label( 2066, compiled_block_1_2066 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2065, compiled_block_1_2065 );
  twobit_branchf( 2068, compiled_block_1_2068 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_load( 3, 2 );
  twobit_global( 4 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2068, compiled_block_1_2068 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_329( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 2074, compiled_block_1_2074 );
  twobit_invoke( 2 );
  twobit_label( 2074, compiled_block_1_2074 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2076, compiled_block_1_2076 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_setrtn( 2077, compiled_block_1_2077 );
  twobit_invoke( 2 );
  twobit_label( 2077, compiled_block_1_2077 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2079, compiled_block_1_2079 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2078, compiled_block_1_2078 );
  twobit_label( 2079, compiled_block_1_2079 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2078, compiled_block_1_2078 );
  twobit_branchf( 2081, compiled_block_1_2081 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2081, compiled_block_1_2081 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2083, compiled_block_1_2083 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2083, compiled_block_1_2083 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 2076, compiled_block_1_2076 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2086, compiled_block_1_2086 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2085, compiled_block_1_2085 );
  twobit_label( 2086, compiled_block_1_2086 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2085, compiled_block_1_2085 );
  twobit_branchf( 2088, compiled_block_1_2088 );
  twobit_load( 2, 3 );
  twobit_load( 3, 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 2088, compiled_block_1_2088 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_13( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 2093, compiled_block_1_2093 );
  twobit_invoke( 1 );
  twobit_label( 2093, compiled_block_1_2093 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(0), 312, compiled_temp_1_312, 2095, compiled_block_1_2095 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_313, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2095, compiled_block_1_2095 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 314, compiled_temp_1_314, 2115, compiled_block_1_2115 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_315, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2115, compiled_block_1_2115 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 316, compiled_temp_1_316, 2135, compiled_block_1_2135 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_317, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2135, compiled_block_1_2135 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(4), 318, compiled_temp_1_318, 2155, compiled_block_1_2155 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_319, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2155, compiled_block_1_2155 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 11 );
  twobit_setreg( 2 );
  twobit_global( 12 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_313( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lambda( compiled_start_1_321, 2, 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_321( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2096, compiled_block_1_2096 );
  twobit_invoke( 2 );
  twobit_label( 2096, compiled_block_1_2096 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2098, compiled_block_1_2098 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2097, compiled_block_1_2097 );
  twobit_label( 2098, compiled_block_1_2098 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2097, compiled_block_1_2097 );
  twobit_branchf( 2100, compiled_block_1_2100 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2101, compiled_block_1_2101 );
  twobit_invoke( 2 );
  twobit_label( 2101, compiled_block_1_2101 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2103, compiled_block_1_2103 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2103, compiled_block_1_2103 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2105, compiled_block_1_2105 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2104, compiled_block_1_2104 );
  twobit_label( 2105, compiled_block_1_2105 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2104, compiled_block_1_2104 );
  twobit_branchf( 2107, compiled_block_1_2107 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2107, compiled_block_1_2107 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2100, compiled_block_1_2100 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2110, compiled_block_1_2110 ); /* internal:branchf-eq?/imm */
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_load( 3, 2 );
  twobit_global( 4 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2110, compiled_block_1_2110 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_315( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_320, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_320( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 2116, compiled_block_1_2116 );
  twobit_invoke( 2 );
  twobit_label( 2116, compiled_block_1_2116 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2118, compiled_block_1_2118 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2117, compiled_block_1_2117 );
  twobit_label( 2118, compiled_block_1_2118 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2117, compiled_block_1_2117 );
  twobit_branchf( 2120, compiled_block_1_2120 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 2121, compiled_block_1_2121 );
  twobit_invoke( 2 );
  twobit_label( 2121, compiled_block_1_2121 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2123, compiled_block_1_2123 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2123, compiled_block_1_2123 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2125, compiled_block_1_2125 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2124, compiled_block_1_2124 );
  twobit_label( 2125, compiled_block_1_2125 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2124, compiled_block_1_2124 );
  twobit_branchf( 2127, compiled_block_1_2127 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2127, compiled_block_1_2127 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2120, compiled_block_1_2120 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2130, compiled_block_1_2130 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_load( 3, 2 );
  twobit_global( 3 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2130, compiled_block_1_2130 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_317( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2136, compiled_block_1_2136 );
  twobit_invoke( 2 );
  twobit_label( 2136, compiled_block_1_2136 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2138, compiled_block_1_2138 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2137, compiled_block_1_2137 );
  twobit_label( 2138, compiled_block_1_2138 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2137, compiled_block_1_2137 );
  twobit_branchf( 2140, compiled_block_1_2140 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2141, compiled_block_1_2141 );
  twobit_invoke( 2 );
  twobit_label( 2141, compiled_block_1_2141 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2143, compiled_block_1_2143 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2143, compiled_block_1_2143 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2145, compiled_block_1_2145 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2144, compiled_block_1_2144 );
  twobit_label( 2145, compiled_block_1_2145 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2144, compiled_block_1_2144 );
  twobit_branchf( 2147, compiled_block_1_2147 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2147, compiled_block_1_2147 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2140, compiled_block_1_2140 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2150, compiled_block_1_2150 ); /* internal:branchf-eq?/imm */
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_load( 3, 2 );
  twobit_global( 4 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2150, compiled_block_1_2150 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_319( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 2156, compiled_block_1_2156 );
  twobit_invoke( 2 );
  twobit_label( 2156, compiled_block_1_2156 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2158, compiled_block_1_2158 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2157, compiled_block_1_2157 );
  twobit_label( 2158, compiled_block_1_2158 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2157, compiled_block_1_2157 );
  twobit_branchf( 2160, compiled_block_1_2160 );
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_setrtn( 2161, compiled_block_1_2161 );
  twobit_invoke( 2 );
  twobit_label( 2161, compiled_block_1_2161 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2163, compiled_block_1_2163 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2163, compiled_block_1_2163 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2165, compiled_block_1_2165 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2164, compiled_block_1_2164 );
  twobit_label( 2165, compiled_block_1_2165 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2164, compiled_block_1_2164 );
  twobit_branchf( 2167, compiled_block_1_2167 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2167, compiled_block_1_2167 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 2160, compiled_block_1_2160 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2170, compiled_block_1_2170 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 3 );
  twobit_load( 3, 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 2170, compiled_block_1_2170 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_14( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 2175, compiled_block_1_2175 );
  twobit_invoke( 1 );
  twobit_label( 2175, compiled_block_1_2175 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(0), 302, compiled_temp_1_302, 2177, compiled_block_1_2177 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_303, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2177, compiled_block_1_2177 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 304, compiled_temp_1_304, 2197, compiled_block_1_2197 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_305, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2197, compiled_block_1_2197 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 306, compiled_temp_1_306, 2217, compiled_block_1_2217 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_307, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2217, compiled_block_1_2217 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(4), 308, compiled_temp_1_308, 2237, compiled_block_1_2237 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_309, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2237, compiled_block_1_2237 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 11 );
  twobit_setreg( 2 );
  twobit_global( 12 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_303( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lambda( compiled_start_1_311, 2, 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_311( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2178, compiled_block_1_2178 );
  twobit_invoke( 2 );
  twobit_label( 2178, compiled_block_1_2178 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2180, compiled_block_1_2180 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2179, compiled_block_1_2179 );
  twobit_label( 2180, compiled_block_1_2180 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2179, compiled_block_1_2179 );
  twobit_branchf( 2182, compiled_block_1_2182 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2183, compiled_block_1_2183 );
  twobit_invoke( 2 );
  twobit_label( 2183, compiled_block_1_2183 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2185, compiled_block_1_2185 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2184, compiled_block_1_2184 );
  twobit_label( 2185, compiled_block_1_2185 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2184, compiled_block_1_2184 );
  twobit_branchf( 2187, compiled_block_1_2187 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2187, compiled_block_1_2187 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2189, compiled_block_1_2189 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2189, compiled_block_1_2189 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2182, compiled_block_1_2182 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2192, compiled_block_1_2192 ); /* internal:branchf-eq?/imm */
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_load( 3, 2 );
  twobit_global( 4 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2192, compiled_block_1_2192 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_305( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_310, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_310( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 2198, compiled_block_1_2198 );
  twobit_invoke( 2 );
  twobit_label( 2198, compiled_block_1_2198 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2200, compiled_block_1_2200 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2199, compiled_block_1_2199 );
  twobit_label( 2200, compiled_block_1_2200 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2199, compiled_block_1_2199 );
  twobit_branchf( 2202, compiled_block_1_2202 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 2203, compiled_block_1_2203 );
  twobit_invoke( 2 );
  twobit_label( 2203, compiled_block_1_2203 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2205, compiled_block_1_2205 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2204, compiled_block_1_2204 );
  twobit_label( 2205, compiled_block_1_2205 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2204, compiled_block_1_2204 );
  twobit_branchf( 2207, compiled_block_1_2207 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2207, compiled_block_1_2207 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2209, compiled_block_1_2209 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2209, compiled_block_1_2209 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2202, compiled_block_1_2202 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2212, compiled_block_1_2212 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_load( 3, 2 );
  twobit_global( 3 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2212, compiled_block_1_2212 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_307( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2218, compiled_block_1_2218 );
  twobit_invoke( 2 );
  twobit_label( 2218, compiled_block_1_2218 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2220, compiled_block_1_2220 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2219, compiled_block_1_2219 );
  twobit_label( 2220, compiled_block_1_2220 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2219, compiled_block_1_2219 );
  twobit_branchf( 2222, compiled_block_1_2222 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2223, compiled_block_1_2223 );
  twobit_invoke( 2 );
  twobit_label( 2223, compiled_block_1_2223 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2225, compiled_block_1_2225 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2224, compiled_block_1_2224 );
  twobit_label( 2225, compiled_block_1_2225 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2224, compiled_block_1_2224 );
  twobit_branchf( 2227, compiled_block_1_2227 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2227, compiled_block_1_2227 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2229, compiled_block_1_2229 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2229, compiled_block_1_2229 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2222, compiled_block_1_2222 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2232, compiled_block_1_2232 ); /* internal:branchf-eq?/imm */
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_load( 3, 2 );
  twobit_global( 4 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2232, compiled_block_1_2232 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_309( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 2238, compiled_block_1_2238 );
  twobit_invoke( 2 );
  twobit_label( 2238, compiled_block_1_2238 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2240, compiled_block_1_2240 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2239, compiled_block_1_2239 );
  twobit_label( 2240, compiled_block_1_2240 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2239, compiled_block_1_2239 );
  twobit_branchf( 2242, compiled_block_1_2242 );
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_setrtn( 2243, compiled_block_1_2243 );
  twobit_invoke( 2 );
  twobit_label( 2243, compiled_block_1_2243 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2245, compiled_block_1_2245 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2244, compiled_block_1_2244 );
  twobit_label( 2245, compiled_block_1_2245 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2244, compiled_block_1_2244 );
  twobit_branchf( 2247, compiled_block_1_2247 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2247, compiled_block_1_2247 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2249, compiled_block_1_2249 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2249, compiled_block_1_2249 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 2242, compiled_block_1_2242 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2252, compiled_block_1_2252 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 3 );
  twobit_load( 3, 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 2252, compiled_block_1_2252 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_15( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 2257, compiled_block_1_2257 );
  twobit_invoke( 1 );
  twobit_label( 2257, compiled_block_1_2257 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(0), 292, compiled_temp_1_292, 2259, compiled_block_1_2259 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_293, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2259, compiled_block_1_2259 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 294, compiled_temp_1_294, 2279, compiled_block_1_2279 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_295, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2279, compiled_block_1_2279 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 296, compiled_temp_1_296, 2299, compiled_block_1_2299 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_297, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2299, compiled_block_1_2299 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(4), 298, compiled_temp_1_298, 2319, compiled_block_1_2319 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_299, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2319, compiled_block_1_2319 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 11 );
  twobit_setreg( 2 );
  twobit_global( 12 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_293( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lambda( compiled_start_1_301, 2, 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_301( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2260, compiled_block_1_2260 );
  twobit_invoke( 2 );
  twobit_label( 2260, compiled_block_1_2260 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2262, compiled_block_1_2262 ); /* internal:branchf-eq?/imm */
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2263, compiled_block_1_2263 );
  twobit_invoke( 2 );
  twobit_label( 2263, compiled_block_1_2263 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2265, compiled_block_1_2265 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2265, compiled_block_1_2265 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2267, compiled_block_1_2267 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2266, compiled_block_1_2266 );
  twobit_label( 2267, compiled_block_1_2267 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2266, compiled_block_1_2266 );
  twobit_branchf( 2269, compiled_block_1_2269 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2269, compiled_block_1_2269 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2262, compiled_block_1_2262 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2272, compiled_block_1_2272 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2271, compiled_block_1_2271 );
  twobit_label( 2272, compiled_block_1_2272 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2271, compiled_block_1_2271 );
  twobit_branchf( 2274, compiled_block_1_2274 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_load( 3, 2 );
  twobit_global( 4 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2274, compiled_block_1_2274 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_295( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_300, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_300( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 2280, compiled_block_1_2280 );
  twobit_invoke( 2 );
  twobit_label( 2280, compiled_block_1_2280 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2282, compiled_block_1_2282 ); /* internal:branchf-eq?/imm */
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 2283, compiled_block_1_2283 );
  twobit_invoke( 2 );
  twobit_label( 2283, compiled_block_1_2283 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2285, compiled_block_1_2285 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2285, compiled_block_1_2285 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2287, compiled_block_1_2287 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2286, compiled_block_1_2286 );
  twobit_label( 2287, compiled_block_1_2287 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2286, compiled_block_1_2286 );
  twobit_branchf( 2289, compiled_block_1_2289 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2289, compiled_block_1_2289 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2282, compiled_block_1_2282 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2292, compiled_block_1_2292 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2291, compiled_block_1_2291 );
  twobit_label( 2292, compiled_block_1_2292 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2291, compiled_block_1_2291 );
  twobit_branchf( 2294, compiled_block_1_2294 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_load( 3, 2 );
  twobit_global( 3 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2294, compiled_block_1_2294 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_297( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2300, compiled_block_1_2300 );
  twobit_invoke( 2 );
  twobit_label( 2300, compiled_block_1_2300 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2302, compiled_block_1_2302 ); /* internal:branchf-eq?/imm */
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2303, compiled_block_1_2303 );
  twobit_invoke( 2 );
  twobit_label( 2303, compiled_block_1_2303 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2305, compiled_block_1_2305 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2305, compiled_block_1_2305 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2307, compiled_block_1_2307 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2306, compiled_block_1_2306 );
  twobit_label( 2307, compiled_block_1_2307 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2306, compiled_block_1_2306 );
  twobit_branchf( 2309, compiled_block_1_2309 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2309, compiled_block_1_2309 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2302, compiled_block_1_2302 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2312, compiled_block_1_2312 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2311, compiled_block_1_2311 );
  twobit_label( 2312, compiled_block_1_2312 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2311, compiled_block_1_2311 );
  twobit_branchf( 2314, compiled_block_1_2314 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_load( 3, 2 );
  twobit_global( 4 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2314, compiled_block_1_2314 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_299( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 2320, compiled_block_1_2320 );
  twobit_invoke( 2 );
  twobit_label( 2320, compiled_block_1_2320 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2322, compiled_block_1_2322 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_setrtn( 2323, compiled_block_1_2323 );
  twobit_invoke( 2 );
  twobit_label( 2323, compiled_block_1_2323 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2325, compiled_block_1_2325 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2325, compiled_block_1_2325 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2327, compiled_block_1_2327 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2326, compiled_block_1_2326 );
  twobit_label( 2327, compiled_block_1_2327 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2326, compiled_block_1_2326 );
  twobit_branchf( 2329, compiled_block_1_2329 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2329, compiled_block_1_2329 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 2322, compiled_block_1_2322 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2332, compiled_block_1_2332 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2331, compiled_block_1_2331 );
  twobit_label( 2332, compiled_block_1_2332 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2331, compiled_block_1_2331 );
  twobit_branchf( 2334, compiled_block_1_2334 );
  twobit_load( 2, 3 );
  twobit_load( 3, 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 2334, compiled_block_1_2334 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_16( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 2339, compiled_block_1_2339 );
  twobit_invoke( 1 );
  twobit_label( 2339, compiled_block_1_2339 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(0), 282, compiled_temp_1_282, 2341, compiled_block_1_2341 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_283, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2341, compiled_block_1_2341 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 284, compiled_temp_1_284, 2361, compiled_block_1_2361 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_285, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2361, compiled_block_1_2361 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 286, compiled_temp_1_286, 2381, compiled_block_1_2381 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_287, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2381, compiled_block_1_2381 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(4), 288, compiled_temp_1_288, 2401, compiled_block_1_2401 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_289, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2401, compiled_block_1_2401 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 11 );
  twobit_setreg( 2 );
  twobit_global( 12 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_283( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lambda( compiled_start_1_291, 2, 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_291( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2342, compiled_block_1_2342 );
  twobit_invoke( 2 );
  twobit_label( 2342, compiled_block_1_2342 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2344, compiled_block_1_2344 ); /* internal:branchf-eq?/imm */
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2345, compiled_block_1_2345 );
  twobit_invoke( 2 );
  twobit_label( 2345, compiled_block_1_2345 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2347, compiled_block_1_2347 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2346, compiled_block_1_2346 );
  twobit_label( 2347, compiled_block_1_2347 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2346, compiled_block_1_2346 );
  twobit_branchf( 2349, compiled_block_1_2349 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2349, compiled_block_1_2349 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2351, compiled_block_1_2351 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2351, compiled_block_1_2351 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2344, compiled_block_1_2344 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2354, compiled_block_1_2354 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2353, compiled_block_1_2353 );
  twobit_label( 2354, compiled_block_1_2354 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2353, compiled_block_1_2353 );
  twobit_branchf( 2356, compiled_block_1_2356 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_load( 3, 2 );
  twobit_global( 4 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2356, compiled_block_1_2356 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_285( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_290, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_290( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 2362, compiled_block_1_2362 );
  twobit_invoke( 2 );
  twobit_label( 2362, compiled_block_1_2362 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2364, compiled_block_1_2364 ); /* internal:branchf-eq?/imm */
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 2365, compiled_block_1_2365 );
  twobit_invoke( 2 );
  twobit_label( 2365, compiled_block_1_2365 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2367, compiled_block_1_2367 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2366, compiled_block_1_2366 );
  twobit_label( 2367, compiled_block_1_2367 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2366, compiled_block_1_2366 );
  twobit_branchf( 2369, compiled_block_1_2369 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2369, compiled_block_1_2369 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2371, compiled_block_1_2371 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2371, compiled_block_1_2371 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2364, compiled_block_1_2364 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2374, compiled_block_1_2374 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2373, compiled_block_1_2373 );
  twobit_label( 2374, compiled_block_1_2374 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2373, compiled_block_1_2373 );
  twobit_branchf( 2376, compiled_block_1_2376 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_load( 3, 2 );
  twobit_global( 3 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2376, compiled_block_1_2376 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_287( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2382, compiled_block_1_2382 );
  twobit_invoke( 2 );
  twobit_label( 2382, compiled_block_1_2382 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2384, compiled_block_1_2384 ); /* internal:branchf-eq?/imm */
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2385, compiled_block_1_2385 );
  twobit_invoke( 2 );
  twobit_label( 2385, compiled_block_1_2385 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2387, compiled_block_1_2387 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2386, compiled_block_1_2386 );
  twobit_label( 2387, compiled_block_1_2387 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2386, compiled_block_1_2386 );
  twobit_branchf( 2389, compiled_block_1_2389 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2389, compiled_block_1_2389 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2391, compiled_block_1_2391 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2391, compiled_block_1_2391 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2384, compiled_block_1_2384 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2394, compiled_block_1_2394 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2393, compiled_block_1_2393 );
  twobit_label( 2394, compiled_block_1_2394 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2393, compiled_block_1_2393 );
  twobit_branchf( 2396, compiled_block_1_2396 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_load( 3, 2 );
  twobit_global( 4 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2396, compiled_block_1_2396 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_289( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 2402, compiled_block_1_2402 );
  twobit_invoke( 2 );
  twobit_label( 2402, compiled_block_1_2402 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2404, compiled_block_1_2404 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_setrtn( 2405, compiled_block_1_2405 );
  twobit_invoke( 2 );
  twobit_label( 2405, compiled_block_1_2405 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2407, compiled_block_1_2407 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2406, compiled_block_1_2406 );
  twobit_label( 2407, compiled_block_1_2407 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2406, compiled_block_1_2406 );
  twobit_branchf( 2409, compiled_block_1_2409 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2409, compiled_block_1_2409 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2411, compiled_block_1_2411 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2411, compiled_block_1_2411 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 2404, compiled_block_1_2404 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2414, compiled_block_1_2414 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2413, compiled_block_1_2413 );
  twobit_label( 2414, compiled_block_1_2414 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2413, compiled_block_1_2413 );
  twobit_branchf( 2416, compiled_block_1_2416 );
  twobit_load( 2, 3 );
  twobit_load( 3, 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 2416, compiled_block_1_2416 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_17( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 2421, compiled_block_1_2421 );
  twobit_invoke( 1 );
  twobit_label( 2421, compiled_block_1_2421 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(0), 272, compiled_temp_1_272, 2423, compiled_block_1_2423 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_273, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2423, compiled_block_1_2423 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 274, compiled_temp_1_274, 2443, compiled_block_1_2443 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_275, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2443, compiled_block_1_2443 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 276, compiled_temp_1_276, 2463, compiled_block_1_2463 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_277, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2463, compiled_block_1_2463 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(4), 278, compiled_temp_1_278, 2483, compiled_block_1_2483 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_279, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2483, compiled_block_1_2483 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 11 );
  twobit_setreg( 2 );
  twobit_global( 12 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_273( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lambda( compiled_start_1_281, 2, 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_281( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2424, compiled_block_1_2424 );
  twobit_invoke( 2 );
  twobit_label( 2424, compiled_block_1_2424 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2426, compiled_block_1_2426 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2425, compiled_block_1_2425 );
  twobit_label( 2426, compiled_block_1_2426 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2425, compiled_block_1_2425 );
  twobit_branchf( 2428, compiled_block_1_2428 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2429, compiled_block_1_2429 );
  twobit_invoke( 2 );
  twobit_label( 2429, compiled_block_1_2429 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2431, compiled_block_1_2431 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2431, compiled_block_1_2431 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2433, compiled_block_1_2433 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2432, compiled_block_1_2432 );
  twobit_label( 2433, compiled_block_1_2433 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2432, compiled_block_1_2432 );
  twobit_branchf( 2435, compiled_block_1_2435 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2435, compiled_block_1_2435 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2428, compiled_block_1_2428 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2438, compiled_block_1_2438 ); /* internal:branchf-eq?/imm */
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_load( 3, 2 );
  twobit_global( 4 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2438, compiled_block_1_2438 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_275( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_280, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_280( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 2444, compiled_block_1_2444 );
  twobit_invoke( 2 );
  twobit_label( 2444, compiled_block_1_2444 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2446, compiled_block_1_2446 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2445, compiled_block_1_2445 );
  twobit_label( 2446, compiled_block_1_2446 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2445, compiled_block_1_2445 );
  twobit_branchf( 2448, compiled_block_1_2448 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 2449, compiled_block_1_2449 );
  twobit_invoke( 2 );
  twobit_label( 2449, compiled_block_1_2449 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2451, compiled_block_1_2451 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2451, compiled_block_1_2451 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2453, compiled_block_1_2453 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2452, compiled_block_1_2452 );
  twobit_label( 2453, compiled_block_1_2453 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2452, compiled_block_1_2452 );
  twobit_branchf( 2455, compiled_block_1_2455 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2455, compiled_block_1_2455 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2448, compiled_block_1_2448 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2458, compiled_block_1_2458 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_load( 3, 2 );
  twobit_global( 3 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2458, compiled_block_1_2458 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_277( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2464, compiled_block_1_2464 );
  twobit_invoke( 2 );
  twobit_label( 2464, compiled_block_1_2464 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2466, compiled_block_1_2466 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2465, compiled_block_1_2465 );
  twobit_label( 2466, compiled_block_1_2466 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2465, compiled_block_1_2465 );
  twobit_branchf( 2468, compiled_block_1_2468 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2469, compiled_block_1_2469 );
  twobit_invoke( 2 );
  twobit_label( 2469, compiled_block_1_2469 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2471, compiled_block_1_2471 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2471, compiled_block_1_2471 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2473, compiled_block_1_2473 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2472, compiled_block_1_2472 );
  twobit_label( 2473, compiled_block_1_2473 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2472, compiled_block_1_2472 );
  twobit_branchf( 2475, compiled_block_1_2475 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2475, compiled_block_1_2475 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2468, compiled_block_1_2468 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2478, compiled_block_1_2478 ); /* internal:branchf-eq?/imm */
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_load( 3, 2 );
  twobit_global( 4 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2478, compiled_block_1_2478 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_279( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 2484, compiled_block_1_2484 );
  twobit_invoke( 2 );
  twobit_label( 2484, compiled_block_1_2484 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2486, compiled_block_1_2486 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2485, compiled_block_1_2485 );
  twobit_label( 2486, compiled_block_1_2486 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2485, compiled_block_1_2485 );
  twobit_branchf( 2488, compiled_block_1_2488 );
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_setrtn( 2489, compiled_block_1_2489 );
  twobit_invoke( 2 );
  twobit_label( 2489, compiled_block_1_2489 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2491, compiled_block_1_2491 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2491, compiled_block_1_2491 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2493, compiled_block_1_2493 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2492, compiled_block_1_2492 );
  twobit_label( 2493, compiled_block_1_2493 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2492, compiled_block_1_2492 );
  twobit_branchf( 2495, compiled_block_1_2495 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2495, compiled_block_1_2495 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 2488, compiled_block_1_2488 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2498, compiled_block_1_2498 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 3 );
  twobit_load( 3, 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 2498, compiled_block_1_2498 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_18( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 2503, compiled_block_1_2503 );
  twobit_invoke( 1 );
  twobit_label( 2503, compiled_block_1_2503 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(0), 262, compiled_temp_1_262, 2505, compiled_block_1_2505 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_263, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2505, compiled_block_1_2505 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 264, compiled_temp_1_264, 2525, compiled_block_1_2525 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_265, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2525, compiled_block_1_2525 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 266, compiled_temp_1_266, 2545, compiled_block_1_2545 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_267, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2545, compiled_block_1_2545 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(4), 268, compiled_temp_1_268, 2565, compiled_block_1_2565 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_269, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2565, compiled_block_1_2565 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 11 );
  twobit_setreg( 2 );
  twobit_global( 12 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_263( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lambda( compiled_start_1_271, 2, 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_271( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2506, compiled_block_1_2506 );
  twobit_invoke( 2 );
  twobit_label( 2506, compiled_block_1_2506 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2508, compiled_block_1_2508 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2507, compiled_block_1_2507 );
  twobit_label( 2508, compiled_block_1_2508 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2507, compiled_block_1_2507 );
  twobit_branchf( 2510, compiled_block_1_2510 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2511, compiled_block_1_2511 );
  twobit_invoke( 2 );
  twobit_label( 2511, compiled_block_1_2511 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2513, compiled_block_1_2513 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2512, compiled_block_1_2512 );
  twobit_label( 2513, compiled_block_1_2513 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2512, compiled_block_1_2512 );
  twobit_branchf( 2515, compiled_block_1_2515 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2515, compiled_block_1_2515 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2517, compiled_block_1_2517 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2517, compiled_block_1_2517 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2510, compiled_block_1_2510 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2520, compiled_block_1_2520 ); /* internal:branchf-eq?/imm */
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_load( 3, 2 );
  twobit_global( 4 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2520, compiled_block_1_2520 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_265( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_270, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_270( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 2526, compiled_block_1_2526 );
  twobit_invoke( 2 );
  twobit_label( 2526, compiled_block_1_2526 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2528, compiled_block_1_2528 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2527, compiled_block_1_2527 );
  twobit_label( 2528, compiled_block_1_2528 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2527, compiled_block_1_2527 );
  twobit_branchf( 2530, compiled_block_1_2530 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 2531, compiled_block_1_2531 );
  twobit_invoke( 2 );
  twobit_label( 2531, compiled_block_1_2531 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2533, compiled_block_1_2533 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2532, compiled_block_1_2532 );
  twobit_label( 2533, compiled_block_1_2533 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2532, compiled_block_1_2532 );
  twobit_branchf( 2535, compiled_block_1_2535 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2535, compiled_block_1_2535 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2537, compiled_block_1_2537 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2537, compiled_block_1_2537 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2530, compiled_block_1_2530 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2540, compiled_block_1_2540 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_load( 3, 2 );
  twobit_global( 3 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2540, compiled_block_1_2540 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_267( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2546, compiled_block_1_2546 );
  twobit_invoke( 2 );
  twobit_label( 2546, compiled_block_1_2546 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2548, compiled_block_1_2548 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2547, compiled_block_1_2547 );
  twobit_label( 2548, compiled_block_1_2548 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2547, compiled_block_1_2547 );
  twobit_branchf( 2550, compiled_block_1_2550 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 2551, compiled_block_1_2551 );
  twobit_invoke( 2 );
  twobit_label( 2551, compiled_block_1_2551 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2553, compiled_block_1_2553 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2552, compiled_block_1_2552 );
  twobit_label( 2553, compiled_block_1_2553 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2552, compiled_block_1_2552 );
  twobit_branchf( 2555, compiled_block_1_2555 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2555, compiled_block_1_2555 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2557, compiled_block_1_2557 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2557, compiled_block_1_2557 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2550, compiled_block_1_2550 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2560, compiled_block_1_2560 ); /* internal:branchf-eq?/imm */
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_load( 3, 2 );
  twobit_global( 4 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2560, compiled_block_1_2560 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_269( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 2566, compiled_block_1_2566 );
  twobit_invoke( 2 );
  twobit_label( 2566, compiled_block_1_2566 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2568, compiled_block_1_2568 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2567, compiled_block_1_2567 );
  twobit_label( 2568, compiled_block_1_2568 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2567, compiled_block_1_2567 );
  twobit_branchf( 2570, compiled_block_1_2570 );
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_setrtn( 2571, compiled_block_1_2571 );
  twobit_invoke( 2 );
  twobit_label( 2571, compiled_block_1_2571 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2573, compiled_block_1_2573 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2572, compiled_block_1_2572 );
  twobit_label( 2573, compiled_block_1_2573 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2572, compiled_block_1_2572 );
  twobit_branchf( 2575, compiled_block_1_2575 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2575, compiled_block_1_2575 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2577, compiled_block_1_2577 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2577, compiled_block_1_2577 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 2570, compiled_block_1_2570 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2580, compiled_block_1_2580 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 3 );
  twobit_load( 3, 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 2580, compiled_block_1_2580 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_19( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 2585, compiled_block_1_2585 );
  twobit_invoke( 1 );
  twobit_label( 2585, compiled_block_1_2585 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 251, compiled_temp_1_251, 2587, compiled_block_1_2587 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_252, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2587, compiled_block_1_2587 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(2), 253, compiled_temp_1_253, 2590, compiled_block_1_2590 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_254, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2590, compiled_block_1_2590 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 255, compiled_temp_1_255, 2594, compiled_block_1_2594 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_256, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2594, compiled_block_1_2594 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(4), 257, compiled_temp_1_257, 2605, compiled_block_1_2605 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_258, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2605, compiled_block_1_2605 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_637( fixnum(3), 259, compiled_temp_1_259, 2625, compiled_block_1_2625 ); /* internal:branchf->=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_260, 12, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2625, compiled_block_1_2625 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 13 );
  twobit_setreg( 2 );
  twobit_global( 14 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_252( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_254( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_256( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 2595, compiled_block_1_2595 );
  twobit_invoke( 2 );
  twobit_label( 2595, compiled_block_1_2595 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2597, compiled_block_1_2597 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2597, compiled_block_1_2597 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2599, compiled_block_1_2599 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2598, compiled_block_1_2598 );
  twobit_label( 2599, compiled_block_1_2599 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2598, compiled_block_1_2598 );
  twobit_branchf( 2601, compiled_block_1_2601 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2601, compiled_block_1_2601 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_258( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 2606, compiled_block_1_2606 );
  twobit_invoke( 2 );
  twobit_label( 2606, compiled_block_1_2606 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2608, compiled_block_1_2608 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_setrtn( 2609, compiled_block_1_2609 );
  twobit_invoke( 2 );
  twobit_label( 2609, compiled_block_1_2609 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2611, compiled_block_1_2611 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2611, compiled_block_1_2611 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2613, compiled_block_1_2613 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2612, compiled_block_1_2612 );
  twobit_label( 2613, compiled_block_1_2613 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2612, compiled_block_1_2612 );
  twobit_branchf( 2615, compiled_block_1_2615 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2615, compiled_block_1_2615 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 2608, compiled_block_1_2608 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2618, compiled_block_1_2618 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2617, compiled_block_1_2617 );
  twobit_label( 2618, compiled_block_1_2618 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2617, compiled_block_1_2617 );
  twobit_branchf( 2620, compiled_block_1_2620 );
  twobit_load( 2, 3 );
  twobit_load( 3, 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 2620, compiled_block_1_2620 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_260( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 3 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 2626, compiled_block_1_2626 );
  twobit_invoke( 2 );
  twobit_label( 2626, compiled_block_1_2626 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2628, compiled_block_1_2628 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_261, 3, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 2628, compiled_block_1_2628 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2644, compiled_block_1_2644 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2643, compiled_block_1_2643 );
  twobit_label( 2644, compiled_block_1_2644 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2643, compiled_block_1_2643 );
  twobit_branchf( 2646, compiled_block_1_2646 );
  twobit_load( 3, 3 );
  twobit_global( 4 ); /*  compare:checked~1ayXVW~31415 */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_load( 4, 2 );
  twobit_global( 5 ); /* apply */
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 2646, compiled_block_1_2646 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_261( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 2630, compiled_block_1_2630 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_return();
  twobit_label( 2630, compiled_block_1_2630 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_reg_op1_check_652(reg(2),2631,compiled_block_1_2631); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 2632, compiled_block_1_2632 );
  twobit_invoke( 2 );
  twobit_label( 2632, compiled_block_1_2632 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2634, compiled_block_1_2634 ); /* internal:branchf-eq?/imm */
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2634, compiled_block_1_2634 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2637, compiled_block_1_2637 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2636, compiled_block_1_2636 );
  twobit_label( 2637, compiled_block_1_2637 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2636, compiled_block_1_2636 );
  twobit_branchf( 2639, compiled_block_1_2639 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  compare:checked~1ayXVW~31415 */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 4 );
  twobit_label( 2639, compiled_block_1_2639 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 2631, compiled_block_1_2631 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_20( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 2651, compiled_block_1_2651 );
  twobit_invoke( 1 );
  twobit_label( 2651, compiled_block_1_2651 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 240, compiled_temp_1_240, 2653, compiled_block_1_2653 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_241, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2653, compiled_block_1_2653 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(2), 242, compiled_temp_1_242, 2656, compiled_block_1_2656 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_243, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2656, compiled_block_1_2656 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 244, compiled_temp_1_244, 2660, compiled_block_1_2660 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_245, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2660, compiled_block_1_2660 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(4), 246, compiled_temp_1_246, 2671, compiled_block_1_2671 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_247, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2671, compiled_block_1_2671 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_637( fixnum(3), 248, compiled_temp_1_248, 2691, compiled_block_1_2691 ); /* internal:branchf->=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_249, 12, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2691, compiled_block_1_2691 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 13 );
  twobit_setreg( 2 );
  twobit_global( 14 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_241( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_243( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_245( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 2661, compiled_block_1_2661 );
  twobit_invoke( 2 );
  twobit_label( 2661, compiled_block_1_2661 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2663, compiled_block_1_2663 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2663, compiled_block_1_2663 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2665, compiled_block_1_2665 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2664, compiled_block_1_2664 );
  twobit_label( 2665, compiled_block_1_2665 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2664, compiled_block_1_2664 );
  twobit_branchf( 2667, compiled_block_1_2667 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2667, compiled_block_1_2667 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_247( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 2672, compiled_block_1_2672 );
  twobit_invoke( 2 );
  twobit_label( 2672, compiled_block_1_2672 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2674, compiled_block_1_2674 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_setrtn( 2675, compiled_block_1_2675 );
  twobit_invoke( 2 );
  twobit_label( 2675, compiled_block_1_2675 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2677, compiled_block_1_2677 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2677, compiled_block_1_2677 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2679, compiled_block_1_2679 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2678, compiled_block_1_2678 );
  twobit_label( 2679, compiled_block_1_2679 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2678, compiled_block_1_2678 );
  twobit_branchf( 2681, compiled_block_1_2681 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2681, compiled_block_1_2681 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 2674, compiled_block_1_2674 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2684, compiled_block_1_2684 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2683, compiled_block_1_2683 );
  twobit_label( 2684, compiled_block_1_2684 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2683, compiled_block_1_2683 );
  twobit_branchf( 2686, compiled_block_1_2686 );
  twobit_load( 2, 3 );
  twobit_load( 3, 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 2686, compiled_block_1_2686 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_249( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 3 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 2692, compiled_block_1_2692 );
  twobit_invoke( 2 );
  twobit_label( 2692, compiled_block_1_2692 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2694, compiled_block_1_2694 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_250, 3, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 2694, compiled_block_1_2694 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2710, compiled_block_1_2710 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2709, compiled_block_1_2709 );
  twobit_label( 2710, compiled_block_1_2710 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2709, compiled_block_1_2709 );
  twobit_branchf( 2712, compiled_block_1_2712 );
  twobit_load( 3, 3 );
  twobit_global( 4 ); /*  compare:checked~1ayXVW~31415 */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_load( 4, 2 );
  twobit_global( 5 ); /* apply */
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 2712, compiled_block_1_2712 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_250( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 2696, compiled_block_1_2696 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_return();
  twobit_label( 2696, compiled_block_1_2696 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_reg_op1_check_652(reg(2),2697,compiled_block_1_2697); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 2698, compiled_block_1_2698 );
  twobit_invoke( 2 );
  twobit_label( 2698, compiled_block_1_2698 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2700, compiled_block_1_2700 ); /* internal:branchf-eq?/imm */
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2700, compiled_block_1_2700 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2703, compiled_block_1_2703 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2702, compiled_block_1_2702 );
  twobit_label( 2703, compiled_block_1_2703 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2702, compiled_block_1_2702 );
  twobit_branchf( 2705, compiled_block_1_2705 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  compare:checked~1ayXVW~31415 */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 4 );
  twobit_label( 2705, compiled_block_1_2705 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 2697, compiled_block_1_2697 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_21( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 2717, compiled_block_1_2717 );
  twobit_invoke( 1 );
  twobit_label( 2717, compiled_block_1_2717 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 229, compiled_temp_1_229, 2719, compiled_block_1_2719 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_230, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2719, compiled_block_1_2719 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(2), 231, compiled_temp_1_231, 2722, compiled_block_1_2722 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_232, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2722, compiled_block_1_2722 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 233, compiled_temp_1_233, 2726, compiled_block_1_2726 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_234, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2726, compiled_block_1_2726 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(4), 235, compiled_temp_1_235, 2737, compiled_block_1_2737 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_236, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2737, compiled_block_1_2737 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_637( fixnum(3), 237, compiled_temp_1_237, 2757, compiled_block_1_2757 ); /* internal:branchf->=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_238, 12, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2757, compiled_block_1_2757 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 13 );
  twobit_setreg( 2 );
  twobit_global( 14 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_230( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_232( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_234( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 2727, compiled_block_1_2727 );
  twobit_invoke( 2 );
  twobit_label( 2727, compiled_block_1_2727 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2729, compiled_block_1_2729 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2729, compiled_block_1_2729 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2731, compiled_block_1_2731 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2730, compiled_block_1_2730 );
  twobit_label( 2731, compiled_block_1_2731 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2730, compiled_block_1_2730 );
  twobit_branchf( 2733, compiled_block_1_2733 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2733, compiled_block_1_2733 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_236( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 2738, compiled_block_1_2738 );
  twobit_invoke( 2 );
  twobit_label( 2738, compiled_block_1_2738 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2740, compiled_block_1_2740 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_setrtn( 2741, compiled_block_1_2741 );
  twobit_invoke( 2 );
  twobit_label( 2741, compiled_block_1_2741 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2743, compiled_block_1_2743 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2743, compiled_block_1_2743 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2745, compiled_block_1_2745 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2744, compiled_block_1_2744 );
  twobit_label( 2745, compiled_block_1_2745 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2744, compiled_block_1_2744 );
  twobit_branchf( 2747, compiled_block_1_2747 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2747, compiled_block_1_2747 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 2740, compiled_block_1_2740 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2750, compiled_block_1_2750 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2749, compiled_block_1_2749 );
  twobit_label( 2750, compiled_block_1_2750 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2749, compiled_block_1_2749 );
  twobit_branchf( 2752, compiled_block_1_2752 );
  twobit_load( 2, 3 );
  twobit_load( 3, 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 2752, compiled_block_1_2752 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_238( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 3 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 2758, compiled_block_1_2758 );
  twobit_invoke( 2 );
  twobit_label( 2758, compiled_block_1_2758 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2760, compiled_block_1_2760 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_239, 3, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 2760, compiled_block_1_2760 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2776, compiled_block_1_2776 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2775, compiled_block_1_2775 );
  twobit_label( 2776, compiled_block_1_2776 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2775, compiled_block_1_2775 );
  twobit_branchf( 2778, compiled_block_1_2778 );
  twobit_load( 3, 3 );
  twobit_global( 4 ); /*  compare:checked~1ayXVW~31415 */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_load( 4, 2 );
  twobit_global( 5 ); /* apply */
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 2778, compiled_block_1_2778 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_239( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 2762, compiled_block_1_2762 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_return();
  twobit_label( 2762, compiled_block_1_2762 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_reg_op1_check_652(reg(2),2763,compiled_block_1_2763); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 2764, compiled_block_1_2764 );
  twobit_invoke( 2 );
  twobit_label( 2764, compiled_block_1_2764 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2766, compiled_block_1_2766 ); /* internal:branchf-eq?/imm */
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2766, compiled_block_1_2766 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2769, compiled_block_1_2769 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2768, compiled_block_1_2768 );
  twobit_label( 2769, compiled_block_1_2769 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2768, compiled_block_1_2768 );
  twobit_branchf( 2771, compiled_block_1_2771 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  compare:checked~1ayXVW~31415 */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 4 );
  twobit_label( 2771, compiled_block_1_2771 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 2763, compiled_block_1_2763 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_22( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 2783, compiled_block_1_2783 );
  twobit_invoke( 1 );
  twobit_label( 2783, compiled_block_1_2783 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 218, compiled_temp_1_218, 2785, compiled_block_1_2785 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_219, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2785, compiled_block_1_2785 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(2), 220, compiled_temp_1_220, 2788, compiled_block_1_2788 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_221, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2788, compiled_block_1_2788 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 222, compiled_temp_1_222, 2792, compiled_block_1_2792 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_223, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2792, compiled_block_1_2792 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(4), 224, compiled_temp_1_224, 2803, compiled_block_1_2803 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_225, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2803, compiled_block_1_2803 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_637( fixnum(3), 226, compiled_temp_1_226, 2823, compiled_block_1_2823 ); /* internal:branchf->=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_227, 12, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2823, compiled_block_1_2823 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 13 );
  twobit_setreg( 2 );
  twobit_global( 14 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_219( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_221( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_223( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 2793, compiled_block_1_2793 );
  twobit_invoke( 2 );
  twobit_label( 2793, compiled_block_1_2793 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2795, compiled_block_1_2795 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2794, compiled_block_1_2794 );
  twobit_label( 2795, compiled_block_1_2795 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2794, compiled_block_1_2794 );
  twobit_branchf( 2797, compiled_block_1_2797 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2797, compiled_block_1_2797 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2799, compiled_block_1_2799 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2799, compiled_block_1_2799 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_225( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 2804, compiled_block_1_2804 );
  twobit_invoke( 2 );
  twobit_label( 2804, compiled_block_1_2804 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2806, compiled_block_1_2806 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2805, compiled_block_1_2805 );
  twobit_label( 2806, compiled_block_1_2806 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2805, compiled_block_1_2805 );
  twobit_branchf( 2808, compiled_block_1_2808 );
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_setrtn( 2809, compiled_block_1_2809 );
  twobit_invoke( 2 );
  twobit_label( 2809, compiled_block_1_2809 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2811, compiled_block_1_2811 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2810, compiled_block_1_2810 );
  twobit_label( 2811, compiled_block_1_2811 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2810, compiled_block_1_2810 );
  twobit_branchf( 2813, compiled_block_1_2813 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2813, compiled_block_1_2813 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2815, compiled_block_1_2815 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2815, compiled_block_1_2815 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 2808, compiled_block_1_2808 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2818, compiled_block_1_2818 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 3 );
  twobit_load( 3, 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 2818, compiled_block_1_2818 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_227( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 3 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 2824, compiled_block_1_2824 );
  twobit_invoke( 2 );
  twobit_label( 2824, compiled_block_1_2824 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2826, compiled_block_1_2826 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2825, compiled_block_1_2825 );
  twobit_label( 2826, compiled_block_1_2826 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2825, compiled_block_1_2825 );
  twobit_branchf( 2828, compiled_block_1_2828 );
  twobit_load( 2, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_228, 3, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 2828, compiled_block_1_2828 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2844, compiled_block_1_2844 ); /* internal:branchf-eq?/imm */
  twobit_load( 3, 3 );
  twobit_global( 4 ); /*  compare:checked~1ayXVW~31415 */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_load( 4, 2 );
  twobit_global( 5 ); /* apply */
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 2844, compiled_block_1_2844 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_228( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 2830, compiled_block_1_2830 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_return();
  twobit_label( 2830, compiled_block_1_2830 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_reg_op1_check_652(reg(2),2831,compiled_block_1_2831); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 2832, compiled_block_1_2832 );
  twobit_invoke( 2 );
  twobit_label( 2832, compiled_block_1_2832 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2834, compiled_block_1_2834 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2833, compiled_block_1_2833 );
  twobit_label( 2834, compiled_block_1_2834 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2833, compiled_block_1_2833 );
  twobit_branchf( 2836, compiled_block_1_2836 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2836, compiled_block_1_2836 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2839, compiled_block_1_2839 ); /* internal:branchf-eq?/imm */
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  compare:checked~1ayXVW~31415 */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 4 );
  twobit_label( 2839, compiled_block_1_2839 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 2831, compiled_block_1_2831 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_23( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 2849, compiled_block_1_2849 );
  twobit_invoke( 1 );
  twobit_label( 2849, compiled_block_1_2849 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 207, compiled_temp_1_207, 2851, compiled_block_1_2851 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_208, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2851, compiled_block_1_2851 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(2), 209, compiled_temp_1_209, 2854, compiled_block_1_2854 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_210, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2854, compiled_block_1_2854 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 211, compiled_temp_1_211, 2858, compiled_block_1_2858 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_212, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2858, compiled_block_1_2858 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(4), 213, compiled_temp_1_213, 2869, compiled_block_1_2869 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_214, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2869, compiled_block_1_2869 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_637( fixnum(3), 215, compiled_temp_1_215, 2889, compiled_block_1_2889 ); /* internal:branchf->=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_216, 12, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2889, compiled_block_1_2889 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 13 );
  twobit_setreg( 2 );
  twobit_global( 14 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_208( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_210( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_212( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 2859, compiled_block_1_2859 );
  twobit_invoke( 2 );
  twobit_label( 2859, compiled_block_1_2859 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2861, compiled_block_1_2861 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2860, compiled_block_1_2860 );
  twobit_label( 2861, compiled_block_1_2861 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2860, compiled_block_1_2860 );
  twobit_branchf( 2863, compiled_block_1_2863 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2863, compiled_block_1_2863 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2865, compiled_block_1_2865 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2865, compiled_block_1_2865 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_214( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 2870, compiled_block_1_2870 );
  twobit_invoke( 2 );
  twobit_label( 2870, compiled_block_1_2870 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2872, compiled_block_1_2872 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2871, compiled_block_1_2871 );
  twobit_label( 2872, compiled_block_1_2872 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2871, compiled_block_1_2871 );
  twobit_branchf( 2874, compiled_block_1_2874 );
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_setrtn( 2875, compiled_block_1_2875 );
  twobit_invoke( 2 );
  twobit_label( 2875, compiled_block_1_2875 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2877, compiled_block_1_2877 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2876, compiled_block_1_2876 );
  twobit_label( 2877, compiled_block_1_2877 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2876, compiled_block_1_2876 );
  twobit_branchf( 2879, compiled_block_1_2879 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2879, compiled_block_1_2879 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2881, compiled_block_1_2881 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2881, compiled_block_1_2881 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 2874, compiled_block_1_2874 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2884, compiled_block_1_2884 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 3 );
  twobit_load( 3, 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 2884, compiled_block_1_2884 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_216( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 3 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 2890, compiled_block_1_2890 );
  twobit_invoke( 2 );
  twobit_label( 2890, compiled_block_1_2890 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2892, compiled_block_1_2892 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2891, compiled_block_1_2891 );
  twobit_label( 2892, compiled_block_1_2892 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2891, compiled_block_1_2891 );
  twobit_branchf( 2894, compiled_block_1_2894 );
  twobit_load( 2, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_217, 3, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 2894, compiled_block_1_2894 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2910, compiled_block_1_2910 ); /* internal:branchf-eq?/imm */
  twobit_load( 3, 3 );
  twobit_global( 4 ); /*  compare:checked~1ayXVW~31415 */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_load( 4, 2 );
  twobit_global( 5 ); /* apply */
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 2910, compiled_block_1_2910 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_217( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 2896, compiled_block_1_2896 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_return();
  twobit_label( 2896, compiled_block_1_2896 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_reg_op1_check_652(reg(2),2897,compiled_block_1_2897); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 2898, compiled_block_1_2898 );
  twobit_invoke( 2 );
  twobit_label( 2898, compiled_block_1_2898 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2900, compiled_block_1_2900 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2899, compiled_block_1_2899 );
  twobit_label( 2900, compiled_block_1_2900 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 2899, compiled_block_1_2899 );
  twobit_branchf( 2902, compiled_block_1_2902 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2902, compiled_block_1_2902 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2905, compiled_block_1_2905 ); /* internal:branchf-eq?/imm */
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  compare:checked~1ayXVW~31415 */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 4 );
  twobit_label( 2905, compiled_block_1_2905 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 2897, compiled_block_1_2897 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_24( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 2915, compiled_block_1_2915 );
  twobit_invoke( 1 );
  twobit_label( 2915, compiled_block_1_2915 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 191, compiled_temp_1_191, 2917, compiled_block_1_2917 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_192, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2917, compiled_block_1_2917 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(2), 193, compiled_temp_1_193, 2920, compiled_block_1_2920 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_194, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2920, compiled_block_1_2920 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 195, compiled_temp_1_195, 2924, compiled_block_1_2924 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_196, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2924, compiled_block_1_2924 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(4), 197, compiled_temp_1_197, 2935, compiled_block_1_2935 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_198, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2935, compiled_block_1_2935 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_637( fixnum(1), 199, compiled_temp_1_199, 2963, compiled_block_1_2963 ); /* internal:branchf->=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_200, 12, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2963, compiled_block_1_2963 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 13 );
  twobit_setreg( 2 );
  twobit_global( 14 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_192( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_194( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_196( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 2925, compiled_block_1_2925 );
  twobit_invoke( 2 );
  twobit_label( 2925, compiled_block_1_2925 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2927, compiled_block_1_2927 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2926, compiled_block_1_2926 );
  twobit_label( 2927, compiled_block_1_2927 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2926, compiled_block_1_2926 );
  twobit_branchf( 2929, compiled_block_1_2929 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2929, compiled_block_1_2929 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2931, compiled_block_1_2931 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2931, compiled_block_1_2931 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_198( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 2936, compiled_block_1_2936 );
  twobit_invoke( 2 );
  twobit_label( 2936, compiled_block_1_2936 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2938, compiled_block_1_2938 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2937, compiled_block_1_2937 );
  twobit_label( 2938, compiled_block_1_2938 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2937, compiled_block_1_2937 );
  twobit_branchf( 2940, compiled_block_1_2940 );
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_setrtn( 2941, compiled_block_1_2941 );
  twobit_invoke( 2 );
  twobit_label( 2941, compiled_block_1_2941 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2943, compiled_block_1_2943 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2942, compiled_block_1_2942 );
  twobit_label( 2943, compiled_block_1_2943 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2942, compiled_block_1_2942 );
  twobit_branchf( 2945, compiled_block_1_2945 );
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 2946, compiled_block_1_2946 );
  twobit_invoke( 2 );
  twobit_label( 2946, compiled_block_1_2946 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 2948, compiled_block_1_2948 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2947, compiled_block_1_2947 );
  twobit_label( 2948, compiled_block_1_2948 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 2947, compiled_block_1_2947 );
  twobit_branchf( 2950, compiled_block_1_2950 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2950, compiled_block_1_2950 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2952, compiled_block_1_2952 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2952, compiled_block_1_2952 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 2945, compiled_block_1_2945 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2955, compiled_block_1_2955 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2955, compiled_block_1_2955 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 2940, compiled_block_1_2940 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2958, compiled_block_1_2958 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 3 );
  twobit_load( 3, 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 2958, compiled_block_1_2958 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_200( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 2964, compiled_block_1_2964 );
  twobit_invoke( 1 );
  twobit_label( 2964, compiled_block_1_2964 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_201, 4, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_201( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 2 );
  twobit_op2imm_branchf_635( fixnum(2), 202, compiled_temp_1_202, 2966, compiled_block_1_2966 ); /* internal:branchf-</imm */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 3 );
  twobit_branchf( 2968, compiled_block_1_2968 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_lexical( 2, 1 );
  twobit_setrtn( 2969, compiled_block_1_2969 );
  twobit_invoke( 2 );
  twobit_label( 2969, compiled_block_1_2969 );
  twobit_load( 0, 0 );
  twobit_skip( 2967, compiled_block_1_2967 );
  twobit_label( 2968, compiled_block_1_2968 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2967, compiled_block_1_2967 );
  twobit_branchf( 2971, compiled_block_1_2971 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 2972, compiled_block_1_2972 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_label( 2971, compiled_block_1_2971 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2966, compiled_block_1_2966 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 3, 3 );
  twobit_movereg( 2, 1 );
  twobit_global( 2 ); /*  random-integer~1ayXVW~13282 */
  twobit_setrtn( 2974, compiled_block_1_2974 );
  twobit_invoke( 1 );
  twobit_label( 2974, compiled_block_1_2974 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /* list-ref */
  twobit_setrtn( 2975, compiled_block_1_2975 );
  twobit_invoke( 2 );
  twobit_label( 2975, compiled_block_1_2975 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_store( 2, 4 );
  twobit_global( 4 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_203, 6, 4 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 5 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_load( 2, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_reg( 5 );
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 2972, compiled_block_1_2972 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_203( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 2977, compiled_block_1_2977 ); /* internal:branchf-null? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 2978, compiled_block_1_2978 );
  twobit_invoke( 1 );
  twobit_label( 2978, compiled_block_1_2978 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_setrtn( 2979, compiled_block_1_2979 );
  twobit_invoke( 3 );
  twobit_label( 2979, compiled_block_1_2979 );
  twobit_load( 0, 0 );
  twobit_branchf( 2981, compiled_block_1_2981 );
  twobit_load( 1, 2 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 2982, compiled_block_1_2982 );
  twobit_invoke( 1 );
  twobit_label( 2982, compiled_block_1_2982 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2981, compiled_block_1_2981 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2977, compiled_block_1_2977 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_store( 4, 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 3, 1 );
  twobit_setrtn( 2984, compiled_block_1_2984 );
  twobit_invoke( 2 );
  twobit_label( 2984, compiled_block_1_2984 );
  twobit_load( 0, 0 );
  twobit_branchf( 2986, compiled_block_1_2986 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 204, compiled_temp_1_204 ); /* + */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 2 );
  twobit_check( 3, 0, 0, 2987, compiled_block_1_2987 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 5 );
  twobit_load( 3, 3 );
  twobit_load( 4, 4 );
  twobit_reg( 5 );
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 2986, compiled_block_1_2986 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 2 );
  twobit_check( 3, 0, 0, 2989, compiled_block_1_2989 );
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setrtn( 2990, compiled_block_1_2990 );
  twobit_invoke( 2 );
  twobit_label( 2990, compiled_block_1_2990 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 2992, compiled_block_1_2992 ); /* internal:branchf-eq?/imm */
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 205, compiled_temp_1_205 ); /* + */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 5 );
  twobit_load( 4, 4 );
  twobit_reg( 5 );
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 2992, compiled_block_1_2992 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 2995, compiled_block_1_2995 ); /* internal:branchf-eq?/imm */
  twobit_lexical( 0, 1 );
  twobit_branchf( 2997, compiled_block_1_2997 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_global( 2 ); /*  compare:checked~1ayXVW~31415 */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_global( 3 ); /* apply */
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 2997, compiled_block_1_2997 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2995, compiled_block_1_2995 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3000, compiled_block_1_3000 ); /* internal:branchf-eq?/imm */
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 206, compiled_temp_1_206 ); /* + */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_movereg( 3, 5 );
  twobit_load( 3, 3 );
  twobit_reg( 5 );
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 3000, compiled_block_1_3000 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 2987, compiled_block_1_2987 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_label( 2989, compiled_block_1_2989 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_25( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 3007, compiled_block_1_3007 );
  twobit_invoke( 1 );
  twobit_label( 3007, compiled_block_1_3007 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(2), 180, compiled_temp_1_180, 3009, compiled_block_1_3009 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_181, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3009, compiled_block_1_3009 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 182, compiled_temp_1_182, 3013, compiled_block_1_3013 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_183, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3013, compiled_block_1_3013 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(4), 184, compiled_temp_1_184, 3024, compiled_block_1_3024 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_185, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3024, compiled_block_1_3024 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(5), 186, compiled_temp_1_186, 3051, compiled_block_1_3051 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_187, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3051, compiled_block_1_3051 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_637( fixnum(3), 188, compiled_temp_1_188, 3110, compiled_block_1_3110 ); /* internal:branchf->=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_189, 12, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3110, compiled_block_1_3110 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 13 );
  twobit_setreg( 2 );
  twobit_global( 14 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_181( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_load( 2, 1 );
  twobit_load( 3, 2 );
  twobit_global( 1 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_183( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 3014, compiled_block_1_3014 );
  twobit_invoke( 2 );
  twobit_label( 3014, compiled_block_1_3014 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3016, compiled_block_1_3016 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3015, compiled_block_1_3015 );
  twobit_label( 3016, compiled_block_1_3016 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3015, compiled_block_1_3015 );
  twobit_branchf( 3018, compiled_block_1_3018 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3018, compiled_block_1_3018 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3020, compiled_block_1_3020 ); /* internal:branchf-eq?/imm */
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3020, compiled_block_1_3020 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_185( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 3025, compiled_block_1_3025 );
  twobit_invoke( 2 );
  twobit_label( 3025, compiled_block_1_3025 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3027, compiled_block_1_3027 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3026, compiled_block_1_3026 );
  twobit_label( 3027, compiled_block_1_3027 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3026, compiled_block_1_3026 );
  twobit_branchf( 3029, compiled_block_1_3029 );
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 3030, compiled_block_1_3030 );
  twobit_invoke( 2 );
  twobit_label( 3030, compiled_block_1_3030 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3032, compiled_block_1_3032 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3031, compiled_block_1_3031 );
  twobit_label( 3032, compiled_block_1_3032 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3031, compiled_block_1_3031 );
  twobit_branchf( 3034, compiled_block_1_3034 );
  twobit_stack( 1 );
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3034, compiled_block_1_3034 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3036, compiled_block_1_3036 ); /* internal:branchf-eq?/imm */
  twobit_stack( 2 );
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3036, compiled_block_1_3036 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 3029, compiled_block_1_3029 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3039, compiled_block_1_3039 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_setrtn( 3040, compiled_block_1_3040 );
  twobit_invoke( 2 );
  twobit_label( 3040, compiled_block_1_3040 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3042, compiled_block_1_3042 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3041, compiled_block_1_3041 );
  twobit_label( 3042, compiled_block_1_3042 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3041, compiled_block_1_3041 );
  twobit_branchf( 3044, compiled_block_1_3044 );
  twobit_stack( 4 );
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3044, compiled_block_1_3044 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3046, compiled_block_1_3046 ); /* internal:branchf-eq?/imm */
  twobit_stack( 2 );
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3046, compiled_block_1_3046 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 3039, compiled_block_1_3039 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_187( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 5 );
  twobit_store( 4, 2 );
  twobit_store( 5, 4 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 3052, compiled_block_1_3052 );
  twobit_invoke( 2 );
  twobit_label( 3052, compiled_block_1_3052 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3054, compiled_block_1_3054 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3053, compiled_block_1_3053 );
  twobit_label( 3054, compiled_block_1_3054 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3053, compiled_block_1_3053 );
  twobit_branchf( 3056, compiled_block_1_3056 );
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 3057, compiled_block_1_3057 );
  twobit_invoke( 2 );
  twobit_label( 3057, compiled_block_1_3057 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3059, compiled_block_1_3059 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3058, compiled_block_1_3058 );
  twobit_label( 3059, compiled_block_1_3059 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3058, compiled_block_1_3058 );
  twobit_branchf( 3061, compiled_block_1_3061 );
  twobit_load( 2, 4 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 3062, compiled_block_1_3062 );
  twobit_invoke( 2 );
  twobit_label( 3062, compiled_block_1_3062 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3064, compiled_block_1_3064 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3063, compiled_block_1_3063 );
  twobit_label( 3064, compiled_block_1_3064 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3063, compiled_block_1_3063 );
  twobit_branchf( 3066, compiled_block_1_3066 );
  twobit_stack( 1 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3066, compiled_block_1_3066 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3068, compiled_block_1_3068 ); /* internal:branchf-eq?/imm */
  twobit_stack( 4 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3068, compiled_block_1_3068 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 3061, compiled_block_1_3061 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3071, compiled_block_1_3071 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 4 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_setrtn( 3072, compiled_block_1_3072 );
  twobit_invoke( 2 );
  twobit_label( 3072, compiled_block_1_3072 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3074, compiled_block_1_3074 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3073, compiled_block_1_3073 );
  twobit_label( 3074, compiled_block_1_3074 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3073, compiled_block_1_3073 );
  twobit_branchf( 3076, compiled_block_1_3076 );
  twobit_stack( 2 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3076, compiled_block_1_3076 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3078, compiled_block_1_3078 ); /* internal:branchf-eq?/imm */
  twobit_stack( 4 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3078, compiled_block_1_3078 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 3071, compiled_block_1_3071 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 3056, compiled_block_1_3056 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3082, compiled_block_1_3082 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 5 );
  twobit_reg( 4 );
  twobit_setrtn( 3083, compiled_block_1_3083 );
  twobit_invoke( 2 );
  twobit_label( 3083, compiled_block_1_3083 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3085, compiled_block_1_3085 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3084, compiled_block_1_3084 );
  twobit_label( 3085, compiled_block_1_3085 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3084, compiled_block_1_3084 );
  twobit_branchf( 3087, compiled_block_1_3087 );
  twobit_load( 2, 4 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 5 );
  twobit_reg( 4 );
  twobit_setrtn( 3088, compiled_block_1_3088 );
  twobit_invoke( 2 );
  twobit_label( 3088, compiled_block_1_3088 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3090, compiled_block_1_3090 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3089, compiled_block_1_3089 );
  twobit_label( 3090, compiled_block_1_3090 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3089, compiled_block_1_3089 );
  twobit_branchf( 3092, compiled_block_1_3092 );
  twobit_stack( 5 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3092, compiled_block_1_3092 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3094, compiled_block_1_3094 ); /* internal:branchf-eq?/imm */
  twobit_stack( 4 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3094, compiled_block_1_3094 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 3087, compiled_block_1_3087 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3097, compiled_block_1_3097 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 4 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_setrtn( 3098, compiled_block_1_3098 );
  twobit_invoke( 2 );
  twobit_label( 3098, compiled_block_1_3098 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3100, compiled_block_1_3100 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3099, compiled_block_1_3099 );
  twobit_label( 3100, compiled_block_1_3100 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3099, compiled_block_1_3099 );
  twobit_branchf( 3102, compiled_block_1_3102 );
  twobit_stack( 2 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3102, compiled_block_1_3102 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3104, compiled_block_1_3104 ); /* internal:branchf-eq?/imm */
  twobit_stack( 4 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3104, compiled_block_1_3104 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 3097, compiled_block_1_3097 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 3082, compiled_block_1_3082 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_189( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 3 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_store( 4, 3 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 3111, compiled_block_1_3111 );
  twobit_invoke( 2 );
  twobit_label( 3111, compiled_block_1_3111 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3113, compiled_block_1_3113 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3112, compiled_block_1_3112 );
  twobit_label( 3113, compiled_block_1_3113 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3112, compiled_block_1_3112 );
  twobit_branchf( 3115, compiled_block_1_3115 );
  twobit_stack( 1 );
  twobit_skip( 3114, compiled_block_1_3114 );
  twobit_label( 3115, compiled_block_1_3115 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3117, compiled_block_1_3117 ); /* internal:branchf-eq?/imm */
  twobit_stack( 2 );
  twobit_skip( 3114, compiled_block_1_3114 );
  twobit_label( 3117, compiled_block_1_3117 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 3118, compiled_block_1_3118 );
  twobit_invoke( 1 );
  twobit_label( 3118, compiled_block_1_3118 );
  twobit_load( 0, 0 );
  twobit_label( 3114, compiled_block_1_3114 );
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_store( 2, 5 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 2, 4 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_190, 5, 2 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 5 );
  twobit_reg( 4 );
  twobit_pop( 5 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_190( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 3120, compiled_block_1_3120 ); /* internal:branchf-null? */
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 3120, compiled_block_1_3120 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_reg_op1_check_652(reg(2),3121,compiled_block_1_3121); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 3122, compiled_block_1_3122 );
  twobit_invoke( 2 );
  twobit_label( 3122, compiled_block_1_3122 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3124, compiled_block_1_3124 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3123, compiled_block_1_3123 );
  twobit_label( 3124, compiled_block_1_3124 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3123, compiled_block_1_3123 );
  twobit_branchf( 3126, compiled_block_1_3126 );
  twobit_stack( 1 );
  twobit_skip( 3125, compiled_block_1_3125 );
  twobit_label( 3126, compiled_block_1_3126 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3128, compiled_block_1_3128 ); /* internal:branchf-eq?/imm */
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 3125, compiled_block_1_3125 );
  twobit_label( 3128, compiled_block_1_3128 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 3129, compiled_block_1_3129 );
  twobit_invoke( 1 );
  twobit_label( 3129, compiled_block_1_3129 );
  twobit_load( 0, 0 );
  twobit_label( 3125, compiled_block_1_3125 );
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 3121, compiled_block_1_3121 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_26( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 3134, compiled_block_1_3134 );
  twobit_invoke( 1 );
  twobit_label( 3134, compiled_block_1_3134 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(2), 169, compiled_temp_1_169, 3136, compiled_block_1_3136 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_170, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3136, compiled_block_1_3136 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 171, compiled_temp_1_171, 3140, compiled_block_1_3140 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_172, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3140, compiled_block_1_3140 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(4), 173, compiled_temp_1_173, 3151, compiled_block_1_3151 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_174, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3151, compiled_block_1_3151 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(5), 175, compiled_temp_1_175, 3178, compiled_block_1_3178 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_176, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3178, compiled_block_1_3178 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_637( fixnum(3), 177, compiled_temp_1_177, 3237, compiled_block_1_3237 ); /* internal:branchf->=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_178, 12, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3237, compiled_block_1_3237 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 13 );
  twobit_setreg( 2 );
  twobit_global( 14 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_170( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_load( 2, 1 );
  twobit_load( 3, 2 );
  twobit_global( 1 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_172( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 3141, compiled_block_1_3141 );
  twobit_invoke( 2 );
  twobit_label( 3141, compiled_block_1_3141 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3143, compiled_block_1_3143 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3142, compiled_block_1_3142 );
  twobit_label( 3143, compiled_block_1_3143 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 3142, compiled_block_1_3142 );
  twobit_branchf( 3145, compiled_block_1_3145 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3145, compiled_block_1_3145 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 3147, compiled_block_1_3147 ); /* internal:branchf-eq?/imm */
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3147, compiled_block_1_3147 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_174( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 3152, compiled_block_1_3152 );
  twobit_invoke( 2 );
  twobit_label( 3152, compiled_block_1_3152 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3154, compiled_block_1_3154 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3153, compiled_block_1_3153 );
  twobit_label( 3154, compiled_block_1_3154 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 3153, compiled_block_1_3153 );
  twobit_branchf( 3156, compiled_block_1_3156 );
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 3157, compiled_block_1_3157 );
  twobit_invoke( 2 );
  twobit_label( 3157, compiled_block_1_3157 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3159, compiled_block_1_3159 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3158, compiled_block_1_3158 );
  twobit_label( 3159, compiled_block_1_3159 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 3158, compiled_block_1_3158 );
  twobit_branchf( 3161, compiled_block_1_3161 );
  twobit_stack( 1 );
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3161, compiled_block_1_3161 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 3163, compiled_block_1_3163 ); /* internal:branchf-eq?/imm */
  twobit_stack( 2 );
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3163, compiled_block_1_3163 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 3156, compiled_block_1_3156 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 3166, compiled_block_1_3166 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_setrtn( 3167, compiled_block_1_3167 );
  twobit_invoke( 2 );
  twobit_label( 3167, compiled_block_1_3167 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3169, compiled_block_1_3169 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3168, compiled_block_1_3168 );
  twobit_label( 3169, compiled_block_1_3169 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 3168, compiled_block_1_3168 );
  twobit_branchf( 3171, compiled_block_1_3171 );
  twobit_stack( 4 );
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3171, compiled_block_1_3171 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 3173, compiled_block_1_3173 ); /* internal:branchf-eq?/imm */
  twobit_stack( 2 );
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3173, compiled_block_1_3173 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 3166, compiled_block_1_3166 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_176( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 5 );
  twobit_store( 4, 2 );
  twobit_store( 5, 4 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 3179, compiled_block_1_3179 );
  twobit_invoke( 2 );
  twobit_label( 3179, compiled_block_1_3179 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3181, compiled_block_1_3181 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3180, compiled_block_1_3180 );
  twobit_label( 3181, compiled_block_1_3181 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 3180, compiled_block_1_3180 );
  twobit_branchf( 3183, compiled_block_1_3183 );
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 3184, compiled_block_1_3184 );
  twobit_invoke( 2 );
  twobit_label( 3184, compiled_block_1_3184 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3186, compiled_block_1_3186 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3185, compiled_block_1_3185 );
  twobit_label( 3186, compiled_block_1_3186 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 3185, compiled_block_1_3185 );
  twobit_branchf( 3188, compiled_block_1_3188 );
  twobit_load( 2, 4 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 3189, compiled_block_1_3189 );
  twobit_invoke( 2 );
  twobit_label( 3189, compiled_block_1_3189 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3191, compiled_block_1_3191 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3190, compiled_block_1_3190 );
  twobit_label( 3191, compiled_block_1_3191 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 3190, compiled_block_1_3190 );
  twobit_branchf( 3193, compiled_block_1_3193 );
  twobit_stack( 1 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3193, compiled_block_1_3193 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 3195, compiled_block_1_3195 ); /* internal:branchf-eq?/imm */
  twobit_stack( 4 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3195, compiled_block_1_3195 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 3188, compiled_block_1_3188 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 3198, compiled_block_1_3198 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 4 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_setrtn( 3199, compiled_block_1_3199 );
  twobit_invoke( 2 );
  twobit_label( 3199, compiled_block_1_3199 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3201, compiled_block_1_3201 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3200, compiled_block_1_3200 );
  twobit_label( 3201, compiled_block_1_3201 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 3200, compiled_block_1_3200 );
  twobit_branchf( 3203, compiled_block_1_3203 );
  twobit_stack( 2 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3203, compiled_block_1_3203 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 3205, compiled_block_1_3205 ); /* internal:branchf-eq?/imm */
  twobit_stack( 4 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3205, compiled_block_1_3205 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 3198, compiled_block_1_3198 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 3183, compiled_block_1_3183 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 3209, compiled_block_1_3209 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 5 );
  twobit_reg( 4 );
  twobit_setrtn( 3210, compiled_block_1_3210 );
  twobit_invoke( 2 );
  twobit_label( 3210, compiled_block_1_3210 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3212, compiled_block_1_3212 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3211, compiled_block_1_3211 );
  twobit_label( 3212, compiled_block_1_3212 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 3211, compiled_block_1_3211 );
  twobit_branchf( 3214, compiled_block_1_3214 );
  twobit_load( 2, 4 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 5 );
  twobit_reg( 4 );
  twobit_setrtn( 3215, compiled_block_1_3215 );
  twobit_invoke( 2 );
  twobit_label( 3215, compiled_block_1_3215 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3217, compiled_block_1_3217 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3216, compiled_block_1_3216 );
  twobit_label( 3217, compiled_block_1_3217 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 3216, compiled_block_1_3216 );
  twobit_branchf( 3219, compiled_block_1_3219 );
  twobit_stack( 5 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3219, compiled_block_1_3219 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 3221, compiled_block_1_3221 ); /* internal:branchf-eq?/imm */
  twobit_stack( 4 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3221, compiled_block_1_3221 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 3214, compiled_block_1_3214 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 3224, compiled_block_1_3224 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 4 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_setrtn( 3225, compiled_block_1_3225 );
  twobit_invoke( 2 );
  twobit_label( 3225, compiled_block_1_3225 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3227, compiled_block_1_3227 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3226, compiled_block_1_3226 );
  twobit_label( 3227, compiled_block_1_3227 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 3226, compiled_block_1_3226 );
  twobit_branchf( 3229, compiled_block_1_3229 );
  twobit_stack( 2 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3229, compiled_block_1_3229 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 3231, compiled_block_1_3231 ); /* internal:branchf-eq?/imm */
  twobit_stack( 4 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3231, compiled_block_1_3231 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 3224, compiled_block_1_3224 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 3209, compiled_block_1_3209 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_178( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 3 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_store( 4, 3 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 31 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 3238, compiled_block_1_3238 );
  twobit_invoke( 2 );
  twobit_label( 3238, compiled_block_1_3238 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3240, compiled_block_1_3240 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3239, compiled_block_1_3239 );
  twobit_label( 3240, compiled_block_1_3240 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 3239, compiled_block_1_3239 );
  twobit_branchf( 3242, compiled_block_1_3242 );
  twobit_stack( 1 );
  twobit_skip( 3241, compiled_block_1_3241 );
  twobit_label( 3242, compiled_block_1_3242 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 3244, compiled_block_1_3244 ); /* internal:branchf-eq?/imm */
  twobit_stack( 2 );
  twobit_skip( 3241, compiled_block_1_3241 );
  twobit_label( 3244, compiled_block_1_3244 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 3245, compiled_block_1_3245 );
  twobit_invoke( 1 );
  twobit_label( 3245, compiled_block_1_3245 );
  twobit_load( 0, 0 );
  twobit_label( 3241, compiled_block_1_3241 );
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_store( 2, 5 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 2, 4 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_179, 5, 2 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 5 );
  twobit_reg( 4 );
  twobit_pop( 5 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_179( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 3247, compiled_block_1_3247 ); /* internal:branchf-null? */
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 3247, compiled_block_1_3247 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_reg_op1_check_652(reg(2),3248,compiled_block_1_3248); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 3249, compiled_block_1_3249 );
  twobit_invoke( 2 );
  twobit_label( 3249, compiled_block_1_3249 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3251, compiled_block_1_3251 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3250, compiled_block_1_3250 );
  twobit_label( 3251, compiled_block_1_3251 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(0) ); /* eq? */
  twobit_label( 3250, compiled_block_1_3250 );
  twobit_branchf( 3253, compiled_block_1_3253 );
  twobit_stack( 1 );
  twobit_skip( 3252, compiled_block_1_3252 );
  twobit_label( 3253, compiled_block_1_3253 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 3255, compiled_block_1_3255 ); /* internal:branchf-eq?/imm */
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 3252, compiled_block_1_3252 );
  twobit_label( 3255, compiled_block_1_3255 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 3256, compiled_block_1_3256 );
  twobit_invoke( 1 );
  twobit_label( 3256, compiled_block_1_3256 );
  twobit_load( 0, 0 );
  twobit_label( 3252, compiled_block_1_3252 );
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 3248, compiled_block_1_3248 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_27( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 3261, compiled_block_1_3261 );
  twobit_invoke( 1 );
  twobit_label( 3261, compiled_block_1_3261 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 149, compiled_temp_1_149, 3263, compiled_block_1_3263 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_150, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3263, compiled_block_1_3263 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(4), 151, compiled_temp_1_151, 3271, compiled_block_1_3271 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_152, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3271, compiled_block_1_3271 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(5), 153, compiled_temp_1_153, 3296, compiled_block_1_3296 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_154, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3296, compiled_block_1_3296 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_637( fixnum(3), 155, compiled_temp_1_155, 3403, compiled_block_1_3403 ); /* internal:branchf->=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_156, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3403, compiled_block_1_3403 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 11 );
  twobit_setreg( 2 );
  twobit_global( 12 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_150( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* modulo */
  twobit_setrtn( 3264, compiled_block_1_3264 );
  twobit_invoke( 2 );
  twobit_label( 3264, compiled_block_1_3264 );
  twobit_load( 0, 0 );
  twobit_op2imm_branchf_640( fixnum(0), 3266, compiled_block_1_3266 ); /* internal:branchf-eq?/imm */
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_load( 3, 1 );
  twobit_global( 2 ); /*  compare:checked~1ayXVW~31415 */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 3266, compiled_block_1_3266 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_global( 4 ); /*  error~1ayXVW~11537 */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_152( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 4 );
  twobit_store( 3, 3 );
  twobit_store( 4, 1 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* modulo */
  twobit_setrtn( 3272, compiled_block_1_3272 );
  twobit_invoke( 2 );
  twobit_label( 3272, compiled_block_1_3272 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3274, compiled_block_1_3274 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 1 );
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_setrtn( 3275, compiled_block_1_3275 );
  twobit_invoke( 2 );
  twobit_label( 3275, compiled_block_1_3275 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3277, compiled_block_1_3277 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3276, compiled_block_1_3276 );
  twobit_label( 3277, compiled_block_1_3277 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3276, compiled_block_1_3276 );
  twobit_branchf( 3279, compiled_block_1_3279 );
  twobit_stack( 3 );
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3279, compiled_block_1_3279 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3281, compiled_block_1_3281 ); /* internal:branchf-eq?/imm */
  twobit_stack( 1 );
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3281, compiled_block_1_3281 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 3274, compiled_block_1_3274 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3284, compiled_block_1_3284 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 1 );
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_setrtn( 3285, compiled_block_1_3285 );
  twobit_invoke( 2 );
  twobit_label( 3285, compiled_block_1_3285 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3287, compiled_block_1_3287 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3286, compiled_block_1_3286 );
  twobit_label( 3287, compiled_block_1_3287 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3286, compiled_block_1_3286 );
  twobit_branchf( 3289, compiled_block_1_3289 );
  twobit_stack( 1 );
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3289, compiled_block_1_3289 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3291, compiled_block_1_3291 ); /* internal:branchf-eq?/imm */
  twobit_stack( 3 );
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3291, compiled_block_1_3291 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 3284, compiled_block_1_3284 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_load( 2, 4 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_154( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 5 );
  twobit_store( 3, 3 );
  twobit_store( 4, 1 );
  twobit_store( 5, 4 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* modulo */
  twobit_setrtn( 3297, compiled_block_1_3297 );
  twobit_invoke( 2 );
  twobit_label( 3297, compiled_block_1_3297 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3299, compiled_block_1_3299 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 1 );
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_setrtn( 3300, compiled_block_1_3300 );
  twobit_invoke( 2 );
  twobit_label( 3300, compiled_block_1_3300 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3302, compiled_block_1_3302 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3301, compiled_block_1_3301 );
  twobit_label( 3302, compiled_block_1_3302 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3301, compiled_block_1_3301 );
  twobit_branchf( 3304, compiled_block_1_3304 );
  twobit_load( 2, 4 );
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_setrtn( 3305, compiled_block_1_3305 );
  twobit_invoke( 2 );
  twobit_label( 3305, compiled_block_1_3305 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3307, compiled_block_1_3307 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3306, compiled_block_1_3306 );
  twobit_label( 3307, compiled_block_1_3307 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3306, compiled_block_1_3306 );
  twobit_branchf( 3309, compiled_block_1_3309 );
  twobit_stack( 3 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3309, compiled_block_1_3309 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3311, compiled_block_1_3311 ); /* internal:branchf-eq?/imm */
  twobit_stack( 4 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3311, compiled_block_1_3311 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 3304, compiled_block_1_3304 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3314, compiled_block_1_3314 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 4 );
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 3315, compiled_block_1_3315 );
  twobit_invoke( 2 );
  twobit_label( 3315, compiled_block_1_3315 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3317, compiled_block_1_3317 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3316, compiled_block_1_3316 );
  twobit_label( 3317, compiled_block_1_3317 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3316, compiled_block_1_3316 );
  twobit_branchf( 3319, compiled_block_1_3319 );
  twobit_stack( 1 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3319, compiled_block_1_3319 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3321, compiled_block_1_3321 ); /* internal:branchf-eq?/imm */
  twobit_stack( 4 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3321, compiled_block_1_3321 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 3314, compiled_block_1_3314 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 3299, compiled_block_1_3299 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3325, compiled_block_1_3325 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 1 );
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_setrtn( 3326, compiled_block_1_3326 );
  twobit_invoke( 2 );
  twobit_label( 3326, compiled_block_1_3326 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 3328, compiled_block_1_3328 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 4 );
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 3329, compiled_block_1_3329 );
  twobit_invoke( 2 );
  twobit_label( 3329, compiled_block_1_3329 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3331, compiled_block_1_3331 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3330, compiled_block_1_3330 );
  twobit_label( 3331, compiled_block_1_3331 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3330, compiled_block_1_3330 );
  twobit_branchf( 3333, compiled_block_1_3333 );
  twobit_stack( 1 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3333, compiled_block_1_3333 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3335, compiled_block_1_3335 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 4 );
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_setrtn( 3336, compiled_block_1_3336 );
  twobit_invoke( 2 );
  twobit_label( 3336, compiled_block_1_3336 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3338, compiled_block_1_3338 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3337, compiled_block_1_3337 );
  twobit_label( 3338, compiled_block_1_3338 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3337, compiled_block_1_3337 );
  twobit_branchf( 3340, compiled_block_1_3340 );
  twobit_stack( 4 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3340, compiled_block_1_3340 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3342, compiled_block_1_3342 ); /* internal:branchf-eq?/imm */
  twobit_stack( 3 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3342, compiled_block_1_3342 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 3335, compiled_block_1_3335 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 3328, compiled_block_1_3328 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3346, compiled_block_1_3346 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 4 );
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_setrtn( 3347, compiled_block_1_3347 );
  twobit_invoke( 2 );
  twobit_label( 3347, compiled_block_1_3347 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3349, compiled_block_1_3349 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3348, compiled_block_1_3348 );
  twobit_label( 3349, compiled_block_1_3349 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3348, compiled_block_1_3348 );
  twobit_branchf( 3351, compiled_block_1_3351 );
  twobit_stack( 1 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3351, compiled_block_1_3351 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3353, compiled_block_1_3353 ); /* internal:branchf-eq?/imm */
  twobit_stack( 3 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3353, compiled_block_1_3353 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 3346, compiled_block_1_3346 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3356, compiled_block_1_3356 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 4 );
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_setrtn( 3357, compiled_block_1_3357 );
  twobit_invoke( 2 );
  twobit_label( 3357, compiled_block_1_3357 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3359, compiled_block_1_3359 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3358, compiled_block_1_3358 );
  twobit_label( 3359, compiled_block_1_3359 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3358, compiled_block_1_3358 );
  twobit_branchf( 3361, compiled_block_1_3361 );
  twobit_stack( 3 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3361, compiled_block_1_3361 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3363, compiled_block_1_3363 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 4 );
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 3364, compiled_block_1_3364 );
  twobit_invoke( 2 );
  twobit_label( 3364, compiled_block_1_3364 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3366, compiled_block_1_3366 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3365, compiled_block_1_3365 );
  twobit_label( 3366, compiled_block_1_3366 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3365, compiled_block_1_3365 );
  twobit_branchf( 3368, compiled_block_1_3368 );
  twobit_stack( 4 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3368, compiled_block_1_3368 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3370, compiled_block_1_3370 ); /* internal:branchf-eq?/imm */
  twobit_stack( 1 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3370, compiled_block_1_3370 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 3363, compiled_block_1_3363 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 3356, compiled_block_1_3356 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 3325, compiled_block_1_3325 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(2), 3375, compiled_block_1_3375 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 1 );
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_setrtn( 3376, compiled_block_1_3376 );
  twobit_invoke( 2 );
  twobit_label( 3376, compiled_block_1_3376 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3378, compiled_block_1_3378 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3377, compiled_block_1_3377 );
  twobit_label( 3378, compiled_block_1_3378 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3377, compiled_block_1_3377 );
  twobit_branchf( 3380, compiled_block_1_3380 );
  twobit_load( 2, 4 );
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 3381, compiled_block_1_3381 );
  twobit_invoke( 2 );
  twobit_label( 3381, compiled_block_1_3381 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3383, compiled_block_1_3383 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3382, compiled_block_1_3382 );
  twobit_label( 3383, compiled_block_1_3383 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3382, compiled_block_1_3382 );
  twobit_branchf( 3385, compiled_block_1_3385 );
  twobit_stack( 4 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3385, compiled_block_1_3385 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3387, compiled_block_1_3387 ); /* internal:branchf-eq?/imm */
  twobit_stack( 1 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3387, compiled_block_1_3387 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 3380, compiled_block_1_3380 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3390, compiled_block_1_3390 ); /* internal:branchf-eq?/imm */
  twobit_load( 2, 4 );
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_setrtn( 3391, compiled_block_1_3391 );
  twobit_invoke( 2 );
  twobit_label( 3391, compiled_block_1_3391 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3393, compiled_block_1_3393 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3392, compiled_block_1_3392 );
  twobit_label( 3393, compiled_block_1_3393 );
  twobit_reg( 4 );
  twobit_op2imm_129( fixnum(-1) ); /* eq? */
  twobit_label( 3392, compiled_block_1_3392 );
  twobit_branchf( 3395, compiled_block_1_3395 );
  twobit_stack( 4 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3395, compiled_block_1_3395 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3397, compiled_block_1_3397 ); /* internal:branchf-eq?/imm */
  twobit_stack( 3 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 3397, compiled_block_1_3397 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 3390, compiled_block_1_3390 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 3375, compiled_block_1_3375 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_load( 2, 5 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_156( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 3 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_store( 4, 1 );
  twobit_reg( 2 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 3405, compiled_block_1_3405 );
  twobit_reg( 2 );
  twobit_op1_25(); /* exact? */
  twobit_skip( 3404, compiled_block_1_3404 );
  twobit_label( 3405, compiled_block_1_3405 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 3404, compiled_block_1_3404 );
  twobit_branchf( 3407, compiled_block_1_3407 );
  twobit_op1_3(); /* unspecified */
  twobit_skip( 3406, compiled_block_1_3406 );
  twobit_label( 3407, compiled_block_1_3407 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 3408, compiled_block_1_3408 );
  twobit_invoke( 2 );
  twobit_label( 3408, compiled_block_1_3408 );
  twobit_load( 0, 0 );
  twobit_label( 3406, compiled_block_1_3406 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /* length */
  twobit_setrtn( 3409, compiled_block_1_3409 );
  twobit_invoke( 1 );
  twobit_label( 3409, compiled_block_1_3409 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 4, 157, compiled_temp_1_157 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 2 );
  twobit_load( 3, 1 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_global( 4 ); /* modulo */
  twobit_setrtn( 3410, compiled_block_1_3410 );
  twobit_invoke( 2 );
  twobit_label( 3410, compiled_block_1_3410 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 4, 1 );
  twobit_global( 5 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 2, 4 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_158, 7, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_reg( 3 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_movereg( 3, 5 );
  twobit_load( 2, 2 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 3 );
  twobit_reg( 5 );
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_158( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 3, 2 );
  twobit_store( 4, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  random-integer~1ayXVW~13282 */
  twobit_setrtn( 3411, compiled_block_1_3411 );
  twobit_invoke( 1 );
  twobit_label( 3411, compiled_block_1_3411 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* list-ref */
  twobit_setrtn( 3412, compiled_block_1_3412 );
  twobit_invoke( 2 );
  twobit_label( 3412, compiled_block_1_3412 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_159, 5, 4 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 8 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 6 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 7 );
  twobit_reg( 8 );
  twobit_pop( 3 );
  twobit_invoke( 7 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_159( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 7 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 3414, compiled_block_1_3414 ); /* internal:branchf-null? */
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 3, 1 );
  twobit_store( 4, 4 );
  twobit_store( 5, 3 );
  twobit_store( 6, 5 );
  twobit_store( 7, 6 );
  twobit_movereg( 3, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 3, 1 );
  twobit_setrtn( 3415, compiled_block_1_3415 );
  twobit_invoke( 2 );
  twobit_label( 3415, compiled_block_1_3415 );
  twobit_load( 0, 0 );
  twobit_branchf( 3417, compiled_block_1_3417 );
  twobit_load( 2, 1 );
  twobit_load( 4, 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_9(); /* not */
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_movereg( 1, 5 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_reg( 5 );
  twobit_pop( 7 );
  twobit_invoke( 4 );
  twobit_label( 3417, compiled_block_1_3417 );
  twobit_load( 4, 3 );
  twobit_stack( 1 );
  twobit_op2_61( 4, 160, compiled_temp_1_160 ); /* + */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_movereg( 3, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 3, 1 );
  twobit_setrtn( 3419, compiled_block_1_3419 );
  twobit_invoke( 2 );
  twobit_label( 3419, compiled_block_1_3419 );
  twobit_load( 0, 0 );
  twobit_branchf( 3421, compiled_block_1_3421 );
  twobit_lexical( 0, 2 );
  twobit_branchf( 3423, compiled_block_1_3423 );
  twobit_load( 1, 4 );
  twobit_load( 4, 1 );
  twobit_lexical( 0, 1 );
  twobit_op2_62( 4, 161, compiled_temp_1_161 ); /* - */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2imm_131( fixnum(1), 162, compiled_temp_1_162 ); /* - */
  twobit_op2_62( 4, 163, compiled_temp_1_163 ); /* - */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* list-ref */
  twobit_pop( 7 );
  twobit_invoke( 2 );
  twobit_label( 3423, compiled_block_1_3423 );
  twobit_load( 1, 4 );
  twobit_load( 4, 1 );
  twobit_lexical( 0, 1 );
  twobit_op2_62( 4, 164, compiled_temp_1_164 ); /* - */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* list-ref */
  twobit_pop( 7 );
  twobit_invoke( 2 );
  twobit_label( 3421, compiled_block_1_3421 );
  twobit_load( 4, 5 );
  twobit_store( 4, 7 );
  twobit_load( 2, 6 );
  twobit_load( 3, 2 );
  twobit_lexical( 0, 1 );
  twobit_op2_62( 3, 165, compiled_temp_1_165 ); /* - */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_9(); /* not */
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 5 );
  twobit_load( 4, 7 );
  twobit_reg( 5 );
  twobit_pop( 7 );
  twobit_invoke( 4 );
  twobit_label( 3414, compiled_block_1_3414 );
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_store( 4, 4 );
  twobit_store( 5, 5 );
  twobit_store( 6, 6 );
  twobit_store( 7, 7 );
  twobit_reg_op1_check_652(reg(1),3427,compiled_block_1_3427); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setrtn( 3428, compiled_block_1_3428 );
  twobit_invoke( 2 );
  twobit_label( 3428, compiled_block_1_3428 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 3430, compiled_block_1_3430 ); /* internal:branchf-eq?/imm */
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_stack( 3 );
  twobit_op2imm_130( fixnum(1), 166, compiled_temp_1_166 ); /* + */
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 8 );
  twobit_load( 4, 4 );
  twobit_load( 5, 5 );
  twobit_load( 6, 6 );
  twobit_load( 7, 7 );
  twobit_reg( 8 );
  twobit_pop( 7 );
  twobit_invoke( 7 );
  twobit_label( 3430, compiled_block_1_3430 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3433, compiled_block_1_3433 ); /* internal:branchf-eq?/imm */
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_stack( 5 );
  twobit_op2imm_130( fixnum(1), 167, compiled_temp_1_167 ); /* + */
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_movereg( 3, 5 );
  twobit_movereg( 2, 8 );
  twobit_load( 2, 2 );
  twobit_load( 3, 3 );
  twobit_load( 6, 6 );
  twobit_load( 7, 7 );
  twobit_reg( 8 );
  twobit_pop( 7 );
  twobit_invoke( 7 );
  twobit_label( 3433, compiled_block_1_3433 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3436, compiled_block_1_3436 ); /* internal:branchf-eq?/imm */
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_load( 3, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_stack( 7 );
  twobit_op2imm_130( fixnum(1), 168, compiled_temp_1_168 ); /* + */
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_movereg( 2, 8 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_load( 2, 2 );
  twobit_load( 3, 3 );
  twobit_load( 4, 4 );
  twobit_load( 5, 5 );
  twobit_reg( 8 );
  twobit_pop( 7 );
  twobit_invoke( 7 );
  twobit_label( 3436, compiled_block_1_3436 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 7 );
  twobit_invoke( 1 );
  twobit_label( 3427, compiled_block_1_3427 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_28( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 3443, compiled_block_1_3443 );
  twobit_invoke( 1 );
  twobit_label( 3443, compiled_block_1_3443 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 144, compiled_temp_1_144, 3445, compiled_block_1_3445 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_145, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3445, compiled_block_1_3445 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 146, compiled_temp_1_146, 3454, compiled_block_1_3454 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_147, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3454, compiled_block_1_3454 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 7 );
  twobit_setreg( 2 );
  twobit_global( 8 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_145( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_148, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_148( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 3446, compiled_block_1_3446 );
  twobit_invoke( 2 );
  twobit_label( 3446, compiled_block_1_3446 );
  twobit_load( 0, 0 );
  twobit_branchf( 3448, compiled_block_1_3448 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3448, compiled_block_1_3448 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 3449, compiled_block_1_3449 );
  twobit_invoke( 2 );
  twobit_label( 3449, compiled_block_1_3449 );
  twobit_load( 0, 0 );
  twobit_branchf( 3451, compiled_block_1_3451 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3451, compiled_block_1_3451 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_147( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_store( 3, 3 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 3455, compiled_block_1_3455 );
  twobit_invoke( 2 );
  twobit_label( 3455, compiled_block_1_3455 );
  twobit_load( 0, 0 );
  twobit_branchf( 3457, compiled_block_1_3457 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 3457, compiled_block_1_3457 );
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 3458, compiled_block_1_3458 );
  twobit_invoke( 2 );
  twobit_label( 3458, compiled_block_1_3458 );
  twobit_load( 0, 0 );
  twobit_branchf( 3460, compiled_block_1_3460 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 3460, compiled_block_1_3460 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 3 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_29( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 3463, compiled_block_1_3463 );
  twobit_invoke( 1 );
  twobit_label( 3463, compiled_block_1_3463 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 139, compiled_temp_1_139, 3465, compiled_block_1_3465 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_140, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3465, compiled_block_1_3465 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 141, compiled_temp_1_141, 3474, compiled_block_1_3474 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_142, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3474, compiled_block_1_3474 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 7 );
  twobit_setreg( 2 );
  twobit_global( 8 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_140( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_143, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_143( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 3466, compiled_block_1_3466 );
  twobit_invoke( 2 );
  twobit_label( 3466, compiled_block_1_3466 );
  twobit_load( 0, 0 );
  twobit_branchf( 3468, compiled_block_1_3468 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3468, compiled_block_1_3468 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 3469, compiled_block_1_3469 );
  twobit_invoke( 2 );
  twobit_label( 3469, compiled_block_1_3469 );
  twobit_load( 0, 0 );
  twobit_branchf( 3471, compiled_block_1_3471 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3471, compiled_block_1_3471 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_142( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_store( 3, 3 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 3475, compiled_block_1_3475 );
  twobit_invoke( 2 );
  twobit_label( 3475, compiled_block_1_3475 );
  twobit_load( 0, 0 );
  twobit_branchf( 3477, compiled_block_1_3477 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 3477, compiled_block_1_3477 );
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 3478, compiled_block_1_3478 );
  twobit_invoke( 2 );
  twobit_label( 3478, compiled_block_1_3478 );
  twobit_load( 0, 0 );
  twobit_branchf( 3480, compiled_block_1_3480 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 3480, compiled_block_1_3480 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 3 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_30( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 3483, compiled_block_1_3483 );
  twobit_invoke( 1 );
  twobit_label( 3483, compiled_block_1_3483 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 134, compiled_temp_1_134, 3485, compiled_block_1_3485 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_135, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3485, compiled_block_1_3485 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 136, compiled_temp_1_136, 3494, compiled_block_1_3494 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_137, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3494, compiled_block_1_3494 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 7 );
  twobit_setreg( 2 );
  twobit_global( 8 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_135( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_138, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_138( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 3486, compiled_block_1_3486 );
  twobit_invoke( 2 );
  twobit_label( 3486, compiled_block_1_3486 );
  twobit_load( 0, 0 );
  twobit_branchf( 3488, compiled_block_1_3488 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 3489, compiled_block_1_3489 );
  twobit_invoke( 2 );
  twobit_label( 3489, compiled_block_1_3489 );
  twobit_load( 0, 0 );
  twobit_branchf( 3491, compiled_block_1_3491 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3491, compiled_block_1_3491 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3488, compiled_block_1_3488 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_137( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_store( 3, 3 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 3495, compiled_block_1_3495 );
  twobit_invoke( 2 );
  twobit_label( 3495, compiled_block_1_3495 );
  twobit_load( 0, 0 );
  twobit_branchf( 3497, compiled_block_1_3497 );
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 3498, compiled_block_1_3498 );
  twobit_invoke( 2 );
  twobit_label( 3498, compiled_block_1_3498 );
  twobit_load( 0, 0 );
  twobit_branchf( 3500, compiled_block_1_3500 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 3500, compiled_block_1_3500 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 3497, compiled_block_1_3497 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 3 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_31( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 3503, compiled_block_1_3503 );
  twobit_invoke( 1 );
  twobit_label( 3503, compiled_block_1_3503 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 129, compiled_temp_1_129, 3505, compiled_block_1_3505 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_130, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3505, compiled_block_1_3505 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 131, compiled_temp_1_131, 3514, compiled_block_1_3514 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_132, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3514, compiled_block_1_3514 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 7 );
  twobit_setreg( 2 );
  twobit_global( 8 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_130( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_133, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_133( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 3506, compiled_block_1_3506 );
  twobit_invoke( 2 );
  twobit_label( 3506, compiled_block_1_3506 );
  twobit_load( 0, 0 );
  twobit_branchf( 3508, compiled_block_1_3508 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 3509, compiled_block_1_3509 );
  twobit_invoke( 2 );
  twobit_label( 3509, compiled_block_1_3509 );
  twobit_load( 0, 0 );
  twobit_branchf( 3511, compiled_block_1_3511 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3511, compiled_block_1_3511 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3508, compiled_block_1_3508 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_132( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_store( 3, 3 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 3515, compiled_block_1_3515 );
  twobit_invoke( 2 );
  twobit_label( 3515, compiled_block_1_3515 );
  twobit_load( 0, 0 );
  twobit_branchf( 3517, compiled_block_1_3517 );
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 3518, compiled_block_1_3518 );
  twobit_invoke( 2 );
  twobit_label( 3518, compiled_block_1_3518 );
  twobit_load( 0, 0 );
  twobit_branchf( 3520, compiled_block_1_3520 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 3520, compiled_block_1_3520 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 3517, compiled_block_1_3517 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 3 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_32( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 3523, compiled_block_1_3523 );
  twobit_invoke( 1 );
  twobit_label( 3523, compiled_block_1_3523 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(2), 124, compiled_temp_1_124, 3525, compiled_block_1_3525 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_125, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3525, compiled_block_1_3525 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(4), 126, compiled_temp_1_126, 3534, compiled_block_1_3534 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_127, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3534, compiled_block_1_3534 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 7 );
  twobit_setreg( 2 );
  twobit_global( 8 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_125( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lambda( compiled_start_1_128, 2, 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_128( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 3526, compiled_block_1_3526 );
  twobit_invoke( 2 );
  twobit_label( 3526, compiled_block_1_3526 );
  twobit_load( 0, 0 );
  twobit_branchf( 3528, compiled_block_1_3528 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3528, compiled_block_1_3528 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 3529, compiled_block_1_3529 );
  twobit_invoke( 2 );
  twobit_label( 3529, compiled_block_1_3529 );
  twobit_load( 0, 0 );
  twobit_branchf( 3531, compiled_block_1_3531 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3531, compiled_block_1_3531 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_127( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 2, 3 );
  twobit_store( 3, 2 );
  twobit_store( 4, 4 );
  twobit_movereg( 4, 2 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_stack( 1 );
  twobit_setrtn( 3535, compiled_block_1_3535 );
  twobit_invoke( 2 );
  twobit_label( 3535, compiled_block_1_3535 );
  twobit_load( 0, 0 );
  twobit_branchf( 3537, compiled_block_1_3537 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3537, compiled_block_1_3537 );
  twobit_load( 1, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 2, 4 );
  twobit_reg( 4 );
  twobit_setrtn( 3538, compiled_block_1_3538 );
  twobit_invoke( 2 );
  twobit_label( 3538, compiled_block_1_3538 );
  twobit_load( 0, 0 );
  twobit_branchf( 3540, compiled_block_1_3540 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3540, compiled_block_1_3540 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 4 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_33( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 3543, compiled_block_1_3543 );
  twobit_invoke( 1 );
  twobit_label( 3543, compiled_block_1_3543 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(2), 119, compiled_temp_1_119, 3545, compiled_block_1_3545 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_120, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3545, compiled_block_1_3545 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(4), 121, compiled_temp_1_121, 3554, compiled_block_1_3554 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_122, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3554, compiled_block_1_3554 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 7 );
  twobit_setreg( 2 );
  twobit_global( 8 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_120( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lambda( compiled_start_1_123, 2, 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_123( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 3546, compiled_block_1_3546 );
  twobit_invoke( 2 );
  twobit_label( 3546, compiled_block_1_3546 );
  twobit_load( 0, 0 );
  twobit_branchf( 3548, compiled_block_1_3548 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3548, compiled_block_1_3548 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 3549, compiled_block_1_3549 );
  twobit_invoke( 2 );
  twobit_label( 3549, compiled_block_1_3549 );
  twobit_load( 0, 0 );
  twobit_branchf( 3551, compiled_block_1_3551 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3551, compiled_block_1_3551 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_122( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 2, 3 );
  twobit_store( 3, 2 );
  twobit_store( 4, 4 );
  twobit_movereg( 4, 2 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_stack( 1 );
  twobit_setrtn( 3555, compiled_block_1_3555 );
  twobit_invoke( 2 );
  twobit_label( 3555, compiled_block_1_3555 );
  twobit_load( 0, 0 );
  twobit_branchf( 3557, compiled_block_1_3557 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3557, compiled_block_1_3557 );
  twobit_load( 1, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 2, 4 );
  twobit_reg( 4 );
  twobit_setrtn( 3558, compiled_block_1_3558 );
  twobit_invoke( 2 );
  twobit_label( 3558, compiled_block_1_3558 );
  twobit_load( 0, 0 );
  twobit_branchf( 3560, compiled_block_1_3560 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3560, compiled_block_1_3560 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 4 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_34( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_reg( 1 );
  twobit_op2imm_129( TRUE_CONST ); /* eq? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 3564, compiled_block_1_3564 );
  twobit_reg( 4 );
  twobit_skip( 3563, compiled_block_1_3563 );
  twobit_label( 3564, compiled_block_1_3564 );
  twobit_reg( 1 );
  twobit_op2imm_129( FALSE_CONST ); /* eq? */
  twobit_label( 3563, compiled_block_1_3563 );
  twobit_branchf( 3566, compiled_block_1_3566 );
  twobit_op1_3(); /* unspecified */
  twobit_skip( 3565, compiled_block_1_3565 );
  twobit_label( 3566, compiled_block_1_3566 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /* string-append */
  twobit_setrtn( 3567, compiled_block_1_3567 );
  twobit_invoke( 3 );
  twobit_label( 3567, compiled_block_1_3567 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 3568, compiled_block_1_3568 );
  twobit_invoke( 2 );
  twobit_label( 3568, compiled_block_1_3568 );
  twobit_load( 0, 0 );
  twobit_label( 3565, compiled_block_1_3565 );
  twobit_stack( 2 );
  twobit_op2imm_129( TRUE_CONST ); /* eq? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 3570, compiled_block_1_3570 );
  twobit_reg( 4 );
  twobit_skip( 3569, compiled_block_1_3569 );
  twobit_label( 3570, compiled_block_1_3570 );
  twobit_stack( 2 );
  twobit_op2imm_129( FALSE_CONST ); /* eq? */
  twobit_label( 3569, compiled_block_1_3569 );
  twobit_branchf( 3572, compiled_block_1_3572 );
  twobit_op1_3(); /* unspecified */
  twobit_skip( 3571, compiled_block_1_3571 );
  twobit_label( 3572, compiled_block_1_3572 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /* string-append */
  twobit_setrtn( 3573, compiled_block_1_3573 );
  twobit_invoke( 3 );
  twobit_label( 3573, compiled_block_1_3573 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 5 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 3574, compiled_block_1_3574 );
  twobit_invoke( 2 );
  twobit_label( 3574, compiled_block_1_3574 );
  twobit_load( 0, 0 );
  twobit_label( 3571, compiled_block_1_3571 );
  twobit_stack( 1 );
  twobit_branchf( 3576, compiled_block_1_3576 );
  twobit_stack( 2 );
  twobit_branchf( 3578, compiled_block_1_3578 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3578, compiled_block_1_3578 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3576, compiled_block_1_3576 );
  twobit_stack( 2 );
  twobit_branchf( 3580, compiled_block_1_3580 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3580, compiled_block_1_3580 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_35( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_615( 3582, compiled_block_1_3582 ); /* internal:branchf-char? */
  twobit_reg( 1 );
  twobit_op2_branchf_624( 2, 3584, compiled_block_1_3584 ); /* internal:branchf-eq? */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_return();
  twobit_label( 3584, compiled_block_1_3584 );
  twobit_reg( 2 );
  twobit_op1_branchf_615( 3586, compiled_block_1_3586 ); /* internal:branchf-char? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 3587, compiled_block_1_3587 );
  twobit_invoke( 2 );
  twobit_label( 3587, compiled_block_1_3587 );
  twobit_load( 0, 0 );
  twobit_branchf( 3589, compiled_block_1_3589 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3589, compiled_block_1_3589 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 3590, compiled_block_1_3590 );
  twobit_invoke( 2 );
  twobit_label( 3590, compiled_block_1_3590 );
  twobit_load( 0, 0 );
  twobit_branchf( 3592, compiled_block_1_3592 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3592, compiled_block_1_3592 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3586, compiled_block_1_3586 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /* string-append */
  twobit_setrtn( 3593, compiled_block_1_3593 );
  twobit_invoke( 3 );
  twobit_label( 3593, compiled_block_1_3593 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3582, compiled_block_1_3582 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /* string-append */
  twobit_setrtn( 3595, compiled_block_1_3595 );
  twobit_invoke( 3 );
  twobit_label( 3595, compiled_block_1_3595 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_36( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_615( 3598, compiled_block_1_3598 ); /* internal:branchf-char? */
  twobit_reg( 1 );
  twobit_op2_branchf_624( 2, 3600, compiled_block_1_3600 ); /* internal:branchf-eq? */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_return();
  twobit_label( 3600, compiled_block_1_3600 );
  twobit_reg( 2 );
  twobit_op1_branchf_615( 3602, compiled_block_1_3602 ); /* internal:branchf-char? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 3603, compiled_block_1_3603 );
  twobit_invoke( 2 );
  twobit_label( 3603, compiled_block_1_3603 );
  twobit_load( 0, 0 );
  twobit_branchf( 3605, compiled_block_1_3605 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3605, compiled_block_1_3605 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 3606, compiled_block_1_3606 );
  twobit_invoke( 2 );
  twobit_label( 3606, compiled_block_1_3606 );
  twobit_load( 0, 0 );
  twobit_branchf( 3608, compiled_block_1_3608 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3608, compiled_block_1_3608 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3602, compiled_block_1_3602 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /* string-append */
  twobit_setrtn( 3609, compiled_block_1_3609 );
  twobit_invoke( 3 );
  twobit_label( 3609, compiled_block_1_3609 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3598, compiled_block_1_3598 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /* string-append */
  twobit_setrtn( 3611, compiled_block_1_3611 );
  twobit_invoke( 3 );
  twobit_label( 3611, compiled_block_1_3611 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_37( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 3614, compiled_block_1_3614 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 2, 3616, compiled_block_1_3616 ); /* internal:branchf-eq? */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_return();
  twobit_label( 3616, compiled_block_1_3616 );
  twobit_reg( 2 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 3618, compiled_block_1_3618 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 3619, compiled_block_1_3619 );
  twobit_invoke( 2 );
  twobit_label( 3619, compiled_block_1_3619 );
  twobit_load( 0, 0 );
  twobit_branchf( 3621, compiled_block_1_3621 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3621, compiled_block_1_3621 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 3622, compiled_block_1_3622 );
  twobit_invoke( 2 );
  twobit_label( 3622, compiled_block_1_3622 );
  twobit_load( 0, 0 );
  twobit_branchf( 3624, compiled_block_1_3624 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3624, compiled_block_1_3624 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3618, compiled_block_1_3618 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /* string-append */
  twobit_setrtn( 3625, compiled_block_1_3625 );
  twobit_invoke( 3 );
  twobit_label( 3625, compiled_block_1_3625 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3614, compiled_block_1_3614 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /* string-append */
  twobit_setrtn( 3627, compiled_block_1_3627 );
  twobit_invoke( 3 );
  twobit_label( 3627, compiled_block_1_3627 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_38( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 3630, compiled_block_1_3630 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 2, 3632, compiled_block_1_3632 ); /* internal:branchf-eq? */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_return();
  twobit_label( 3632, compiled_block_1_3632 );
  twobit_reg( 2 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 3634, compiled_block_1_3634 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 3635, compiled_block_1_3635 );
  twobit_invoke( 2 );
  twobit_label( 3635, compiled_block_1_3635 );
  twobit_load( 0, 0 );
  twobit_branchf( 3637, compiled_block_1_3637 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3637, compiled_block_1_3637 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 3638, compiled_block_1_3638 );
  twobit_invoke( 2 );
  twobit_label( 3638, compiled_block_1_3638 );
  twobit_load( 0, 0 );
  twobit_branchf( 3640, compiled_block_1_3640 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3640, compiled_block_1_3640 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3634, compiled_block_1_3634 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /* string-append */
  twobit_setrtn( 3641, compiled_block_1_3641 );
  twobit_invoke( 3 );
  twobit_label( 3641, compiled_block_1_3641 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3630, compiled_block_1_3630 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /* string-append */
  twobit_setrtn( 3643, compiled_block_1_3643 );
  twobit_invoke( 3 );
  twobit_label( 3643, compiled_block_1_3643 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_39( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_reg( 1 );
  twobit_op1_17(); /* symbol? */
  twobit_branchf( 3646, compiled_block_1_3646 );
  twobit_op1_3(); /* unspecified */
  twobit_skip( 3645, compiled_block_1_3645 );
  twobit_label( 3646, compiled_block_1_3646 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /* string-append */
  twobit_setrtn( 3647, compiled_block_1_3647 );
  twobit_invoke( 3 );
  twobit_label( 3647, compiled_block_1_3647 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 3648, compiled_block_1_3648 );
  twobit_invoke( 2 );
  twobit_label( 3648, compiled_block_1_3648 );
  twobit_load( 0, 0 );
  twobit_label( 3645, compiled_block_1_3645 );
  twobit_stack( 2 );
  twobit_op1_17(); /* symbol? */
  twobit_branchf( 3650, compiled_block_1_3650 );
  twobit_op1_3(); /* unspecified */
  twobit_skip( 3649, compiled_block_1_3649 );
  twobit_label( 3650, compiled_block_1_3650 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /* string-append */
  twobit_setrtn( 3651, compiled_block_1_3651 );
  twobit_invoke( 3 );
  twobit_label( 3651, compiled_block_1_3651 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 5 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 3652, compiled_block_1_3652 );
  twobit_invoke( 2 );
  twobit_label( 3652, compiled_block_1_3652 );
  twobit_load( 0, 0 );
  twobit_label( 3649, compiled_block_1_3649 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* symbol->string */
  twobit_setrtn( 3653, compiled_block_1_3653 );
  twobit_invoke( 1 );
  twobit_label( 3653, compiled_block_1_3653 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /* symbol->string */
  twobit_setrtn( 3654, compiled_block_1_3654 );
  twobit_invoke( 1 );
  twobit_label( 3654, compiled_block_1_3654 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 7 ); /*  string-compare~1ayXVW~31884 */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_40( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 3657, compiled_block_1_3657 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 2, 3659, compiled_block_1_3659 ); /* internal:branchf-eq? */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_return();
  twobit_label( 3659, compiled_block_1_3659 );
  twobit_reg( 2 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 3661, compiled_block_1_3661 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 3662, compiled_block_1_3662 );
  twobit_invoke( 2 );
  twobit_label( 3662, compiled_block_1_3662 );
  twobit_load( 0, 0 );
  twobit_branchf( 3664, compiled_block_1_3664 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3664, compiled_block_1_3664 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 3665, compiled_block_1_3665 );
  twobit_invoke( 2 );
  twobit_label( 3665, compiled_block_1_3665 );
  twobit_load( 0, 0 );
  twobit_branchf( 3667, compiled_block_1_3667 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3667, compiled_block_1_3667 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3661, compiled_block_1_3661 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /* string-append */
  twobit_setrtn( 3668, compiled_block_1_3668 );
  twobit_invoke( 3 );
  twobit_label( 3668, compiled_block_1_3668 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3657, compiled_block_1_3657 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /* string-append */
  twobit_setrtn( 3670, compiled_block_1_3670 );
  twobit_invoke( 3 );
  twobit_label( 3670, compiled_block_1_3670 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_41( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* rational? */
  twobit_setrtn( 3672, compiled_block_1_3672 );
  twobit_invoke( 1 );
  twobit_label( 3672, compiled_block_1_3672 );
  twobit_load( 0, 0 );
  twobit_branchf( 3674, compiled_block_1_3674 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_op2_branchf_624( 4, 3676, compiled_block_1_3676 ); /* internal:branchf-eq? */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3676, compiled_block_1_3676 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* rational? */
  twobit_setrtn( 3677, compiled_block_1_3677 );
  twobit_invoke( 1 );
  twobit_label( 3677, compiled_block_1_3677 );
  twobit_load( 0, 0 );
  twobit_branchf( 3679, compiled_block_1_3679 );
  twobit_load( 1, 2 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 3680, compiled_block_1_3680 );
  twobit_invoke( 2 );
  twobit_label( 3680, compiled_block_1_3680 );
  twobit_load( 0, 0 );
  twobit_branchf( 3682, compiled_block_1_3682 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3682, compiled_block_1_3682 );
  twobit_load( 1, 2 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 3683, compiled_block_1_3683 );
  twobit_invoke( 2 );
  twobit_label( 3683, compiled_block_1_3683 );
  twobit_load( 0, 0 );
  twobit_branchf( 3685, compiled_block_1_3685 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3685, compiled_block_1_3685 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3679, compiled_block_1_3679 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 3 );
  twobit_setreg( 2 );
  twobit_const( 4 );
  twobit_setreg( 3 );
  twobit_global( 5 ); /* string-append */
  twobit_setrtn( 3686, compiled_block_1_3686 );
  twobit_invoke( 3 );
  twobit_label( 3686, compiled_block_1_3686 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 6 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 3674, compiled_block_1_3674 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 3 );
  twobit_setreg( 2 );
  twobit_const( 4 );
  twobit_setreg( 3 );
  twobit_global( 5 ); /* string-append */
  twobit_setrtn( 3688, compiled_block_1_3688 );
  twobit_invoke( 3 );
  twobit_label( 3688, compiled_block_1_3688 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_42( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_20(); /* rational? */
  twobit_branchf( 3691, compiled_block_1_3691 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 2, 3693, compiled_block_1_3693 ); /* internal:branchf-eq? */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_return();
  twobit_label( 3693, compiled_block_1_3693 );
  twobit_reg( 2 );
  twobit_op1_20(); /* rational? */
  twobit_branchf( 3695, compiled_block_1_3695 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 3696, compiled_block_1_3696 );
  twobit_invoke( 2 );
  twobit_label( 3696, compiled_block_1_3696 );
  twobit_load( 0, 0 );
  twobit_branchf( 3698, compiled_block_1_3698 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3698, compiled_block_1_3698 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 3699, compiled_block_1_3699 );
  twobit_invoke( 2 );
  twobit_label( 3699, compiled_block_1_3699 );
  twobit_load( 0, 0 );
  twobit_branchf( 3701, compiled_block_1_3701 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3701, compiled_block_1_3701 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3695, compiled_block_1_3695 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /* string-append */
  twobit_setrtn( 3702, compiled_block_1_3702 );
  twobit_invoke( 3 );
  twobit_label( 3702, compiled_block_1_3702 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3691, compiled_block_1_3691 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /* string-append */
  twobit_setrtn( 3704, compiled_block_1_3704 );
  twobit_invoke( 3 );
  twobit_label( 3704, compiled_block_1_3704 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_43( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_reg( 1 );
  twobit_op1_18(); /* complex? */
  twobit_branchf( 3707, compiled_block_1_3707 );
  twobit_op1_3(); /* unspecified */
  twobit_skip( 3706, compiled_block_1_3706 );
  twobit_label( 3707, compiled_block_1_3707 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /* string-append */
  twobit_setrtn( 3708, compiled_block_1_3708 );
  twobit_invoke( 3 );
  twobit_label( 3708, compiled_block_1_3708 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 3709, compiled_block_1_3709 );
  twobit_invoke( 2 );
  twobit_label( 3709, compiled_block_1_3709 );
  twobit_load( 0, 0 );
  twobit_label( 3706, compiled_block_1_3706 );
  twobit_stack( 2 );
  twobit_op1_18(); /* complex? */
  twobit_branchf( 3711, compiled_block_1_3711 );
  twobit_op1_3(); /* unspecified */
  twobit_skip( 3710, compiled_block_1_3710 );
  twobit_label( 3711, compiled_block_1_3711 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /* string-append */
  twobit_setrtn( 3712, compiled_block_1_3712 );
  twobit_invoke( 3 );
  twobit_label( 3712, compiled_block_1_3712 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 5 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 3713, compiled_block_1_3713 );
  twobit_invoke( 2 );
  twobit_label( 3713, compiled_block_1_3713 );
  twobit_load( 0, 0 );
  twobit_label( 3710, compiled_block_1_3710 );
  twobit_stack( 1 );
  twobit_op1_20(); /* rational? */
  twobit_branchf( 3715, compiled_block_1_3715 );
  twobit_stack( 2 );
  twobit_op1_20(); /* rational? */
  twobit_skip( 3714, compiled_block_1_3714 );
  twobit_label( 3715, compiled_block_1_3715 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 3714, compiled_block_1_3714 );
  twobit_branchf( 3717, compiled_block_1_3717 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /*  real-compare~1ayXVW~31893 */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 3717, compiled_block_1_3717 );
  twobit_stack( 1 );
  twobit_op1_34(); /* real-part */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op1_34(); /* real-part */
  twobit_setreg( 2 );
  twobit_global( 6 ); /*  real-compare~1ayXVW~31893 */
  twobit_setrtn( 3719, compiled_block_1_3719 );
  twobit_invoke( 2 );
  twobit_label( 3719, compiled_block_1_3719 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 3721, compiled_block_1_3721 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3721, compiled_block_1_3721 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3723, compiled_block_1_3723 ); /* internal:branchf-eq?/imm */
  twobit_stack( 1 );
  twobit_op1_35(); /* imag-part */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op1_35(); /* imag-part */
  twobit_setreg( 2 );
  twobit_global( 6 ); /*  real-compare~1ayXVW~31893 */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 3723, compiled_block_1_3723 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3726, compiled_block_1_3726 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3726, compiled_block_1_3726 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_44( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_reg( 1 );
  twobit_op1_18(); /* complex? */
  twobit_branchf( 3729, compiled_block_1_3729 );
  twobit_op1_3(); /* unspecified */
  twobit_skip( 3728, compiled_block_1_3728 );
  twobit_label( 3729, compiled_block_1_3729 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /* string-append */
  twobit_setrtn( 3730, compiled_block_1_3730 );
  twobit_invoke( 3 );
  twobit_label( 3730, compiled_block_1_3730 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 3731, compiled_block_1_3731 );
  twobit_invoke( 2 );
  twobit_label( 3731, compiled_block_1_3731 );
  twobit_load( 0, 0 );
  twobit_label( 3728, compiled_block_1_3728 );
  twobit_stack( 2 );
  twobit_op1_18(); /* complex? */
  twobit_branchf( 3733, compiled_block_1_3733 );
  twobit_op1_3(); /* unspecified */
  twobit_skip( 3732, compiled_block_1_3732 );
  twobit_label( 3733, compiled_block_1_3733 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /* string-append */
  twobit_setrtn( 3734, compiled_block_1_3734 );
  twobit_invoke( 3 );
  twobit_label( 3734, compiled_block_1_3734 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 5 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 3735, compiled_block_1_3735 );
  twobit_invoke( 2 );
  twobit_label( 3735, compiled_block_1_3735 );
  twobit_load( 0, 0 );
  twobit_label( 3732, compiled_block_1_3732 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /*  complex-compare~1ayXVW~31894 */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_45( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_118, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_118( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op1_check_652(reg(1),3737,compiled_block_1_3737); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg_op1_check_652(reg(2),3738,compiled_block_1_3738); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_invoke( 2 );
  twobit_label( 3738, compiled_block_1_3738 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 3737, compiled_block_1_3737 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_46( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_117, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_117( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op1_check_652(reg(1),3740,compiled_block_1_3740); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg_op1_check_652(reg(2),3741,compiled_block_1_3741); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_invoke( 2 );
  twobit_label( 3740, compiled_block_1_3740 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_label( 3741, compiled_block_1_3741 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_47( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 3743, compiled_block_1_3743 );
  twobit_invoke( 1 );
  twobit_label( 3743, compiled_block_1_3743 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(4), 111, compiled_temp_1_111, 3745, compiled_block_1_3745 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_112, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3745, compiled_block_1_3745 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 113, compiled_temp_1_113, 3759, compiled_block_1_3759 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_114, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3759, compiled_block_1_3759 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(2), 115, compiled_temp_1_115, 3784, compiled_block_1_3784 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_116, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3784, compiled_block_1_3784 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 9 );
  twobit_setreg( 2 );
  twobit_global( 10 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_112( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_store( 4, 4 );
  twobit_store( 1, 1 );
  twobit_reg_op1_check_652(reg(3),3746,compiled_block_1_3746); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg_op1_check_652(reg(4),3747,compiled_block_1_3747); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_stack( 1 );
  twobit_setrtn( 3748, compiled_block_1_3748 );
  twobit_invoke( 2 );
  twobit_label( 3748, compiled_block_1_3748 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 3750, compiled_block_1_3750 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3750, compiled_block_1_3750 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3752, compiled_block_1_3752 ); /* internal:branchf-eq?/imm */
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_stack( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 3752, compiled_block_1_3752 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3755, compiled_block_1_3755 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3755, compiled_block_1_3755 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 3747, compiled_block_1_3747 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 3746, compiled_block_1_3746 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_114( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 3 );
  twobit_op1_10(); /* null? */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 3761, compiled_block_1_3761 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_branchf( 3763, compiled_block_1_3763 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_return();
  twobit_label( 3763, compiled_block_1_3763 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_return();
  twobit_label( 3761, compiled_block_1_3761 );
  twobit_reg( 4 );
  twobit_branchf( 3765, compiled_block_1_3765 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_return();
  twobit_label( 3765, compiled_block_1_3765 );
  twobit_reg( 3 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 3767, compiled_block_1_3767 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_branchf( 3769, compiled_block_1_3769 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_movereg( 1, 4 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_setrtn( 3770, compiled_block_1_3770 );
  twobit_invoke( 2 );
  twobit_label( 3770, compiled_block_1_3770 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 3772, compiled_block_1_3772 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 3772, compiled_block_1_3772 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3774, compiled_block_1_3774 ); /* internal:branchf-eq?/imm */
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_load( 1, 3 );
  twobit_global( 1 ); /*  pair-compare~1ayXVW~31898 */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 3774, compiled_block_1_3774 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3777, compiled_block_1_3777 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 3777, compiled_block_1_3777 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 3 );
  twobit_invoke( 1 );
  twobit_label( 3769, compiled_block_1_3769 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_return();
  twobit_label( 3767, compiled_block_1_3767 );
  twobit_reg( 4 );
  twobit_branchf( 3780, compiled_block_1_3780 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_return();
  twobit_label( 3780, compiled_block_1_3780 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_116( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  pair-compare~1ayXVW~31898 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_48( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 3788, compiled_block_1_3788 );
  twobit_invoke( 1 );
  twobit_label( 3788, compiled_block_1_3788 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(6), 103, compiled_temp_1_103, 3790, compiled_block_1_3790 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_104, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3790, compiled_block_1_3790 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(5), 105, compiled_temp_1_105, 3814, compiled_block_1_3814 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_106, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3814, compiled_block_1_3814 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 107, compiled_temp_1_107, 3818, compiled_block_1_3818 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_108, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3818, compiled_block_1_3818 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(2), 109, compiled_temp_1_109, 3822, compiled_block_1_3822 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_110, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3822, compiled_block_1_3822 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 11 );
  twobit_setreg( 2 );
  twobit_global( 12 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_104( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 6 );
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 2, 1 );
  twobit_store( 3, 5 );
  twobit_store( 4, 2 );
  twobit_store( 5, 4 );
  twobit_store( 6, 7 );
  twobit_movereg( 3, 1 );
  twobit_movereg( 4, 31 );
  twobit_reg( 31 );
  twobit_setrtn( 3791, compiled_block_1_3791 );
  twobit_invoke( 1 );
  twobit_label( 3791, compiled_block_1_3791 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_stack( 2 );
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 3792, compiled_block_1_3792 );
  twobit_invoke( 1 );
  twobit_label( 3792, compiled_block_1_3792 );
  twobit_load( 0, 0 );
  twobit_branchf( 3794, compiled_block_1_3794 );
  twobit_stack( 3 );
  twobit_branchf( 3796, compiled_block_1_3796 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 3796, compiled_block_1_3796 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 3794, compiled_block_1_3794 );
  twobit_stack( 3 );
  twobit_branchf( 3798, compiled_block_1_3798 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 3798, compiled_block_1_3798 );
  twobit_load( 1, 1 );
  twobit_stack( 4 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 3799, compiled_block_1_3799 );
  twobit_invoke( 1 );
  twobit_label( 3799, compiled_block_1_3799 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 5 );
  twobit_stack( 4 );
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 3800, compiled_block_1_3800 );
  twobit_invoke( 1 );
  twobit_label( 3800, compiled_block_1_3800 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_stack( 6 );
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_setrtn( 3801, compiled_block_1_3801 );
  twobit_invoke( 2 );
  twobit_label( 3801, compiled_block_1_3801 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 3803, compiled_block_1_3803 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 3803, compiled_block_1_3803 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3805, compiled_block_1_3805 ); /* internal:branchf-eq?/imm */
  twobit_load( 1, 1 );
  twobit_stack( 7 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 3806, compiled_block_1_3806 );
  twobit_invoke( 1 );
  twobit_label( 3806, compiled_block_1_3806 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 5 );
  twobit_stack( 7 );
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 3807, compiled_block_1_3807 );
  twobit_invoke( 1 );
  twobit_label( 3807, compiled_block_1_3807 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_load( 1, 6 );
  twobit_load( 4, 2 );
  twobit_load( 5, 4 );
  twobit_load( 6, 7 );
  twobit_global( 1 ); /*  list-compare~1ayXVW~31899 */
  twobit_pop( 7 );
  twobit_invoke( 6 );
  twobit_label( 3805, compiled_block_1_3805 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3810, compiled_block_1_3810 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 3810, compiled_block_1_3810 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 7 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_106( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_movereg( 5, 31 );
  twobit_store( 4, 1 );
  twobit_movereg( 3, 4 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 1 );
  twobit_load( 5, 1 );
  twobit_movereg( 31, 6 );
  twobit_global( 2 ); /*  list-compare~1ayXVW~31899 */
  twobit_pop( 1 );
  twobit_invoke( 6 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_108( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_global( 1 ); /* null? */
  twobit_setreg( 4 );
  twobit_global( 2 ); /* car */
  twobit_setreg( 31 );
  twobit_global( 3 ); /* cdr */
  twobit_setreg( 30 );
  twobit_movereg( 31, 5 );
  twobit_movereg( 30, 6 );
  twobit_global( 4 ); /*  list-compare~1ayXVW~31899 */
  twobit_invoke( 6 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_110( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /* null? */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_global( 3 ); /* car */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_global( 4 ); /* cdr */
  twobit_setreg( 4 );
  twobit_movereg( 4, 6 );
  twobit_load( 4, 1 );
  twobit_load( 5, 2 );
  twobit_global( 5 ); /*  list-compare~1ayXVW~31899 */
  twobit_pop( 2 );
  twobit_invoke( 6 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_49( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 3826, compiled_block_1_3826 );
  twobit_invoke( 1 );
  twobit_label( 3826, compiled_block_1_3826 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(6), 94, compiled_temp_1_94, 3828, compiled_block_1_3828 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_95, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3828, compiled_block_1_3828 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(5), 96, compiled_temp_1_96, 3851, compiled_block_1_3851 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_97, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3851, compiled_block_1_3851 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 98, compiled_temp_1_98, 3855, compiled_block_1_3855 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_99, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3855, compiled_block_1_3855 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(2), 100, compiled_temp_1_100, 3859, compiled_block_1_3859 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_101, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3859, compiled_block_1_3859 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 11 );
  twobit_setreg( 2 );
  twobit_global( 12 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_95( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 6 );
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 5 );
  twobit_store( 2, 1 );
  twobit_store( 3, 6 );
  twobit_store( 4, 2 );
  twobit_store( 5, 7 );
  twobit_store( 6, 8 );
  twobit_movereg( 3, 2 );
  twobit_store( 2, 4 );
  twobit_load( 1, 1 );
  twobit_store( 1, 3 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_movereg( 6, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_102, 3, 3 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_load( 2, 4 );
  twobit_reg( 4 );
  twobit_setrtn( 3840, compiled_block_1_3840 );
  twobit_invoke( 2 );
  twobit_label( 3840, compiled_block_1_3840 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 3842, compiled_block_1_3842 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 3842, compiled_block_1_3842 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3844, compiled_block_1_3844 ); /* internal:branchf-eq?/imm */
  twobit_load( 1, 5 );
  twobit_load( 2, 1 );
  twobit_load( 3, 6 );
  twobit_load( 4, 2 );
  twobit_load( 5, 7 );
  twobit_load( 6, 8 );
  twobit_global( 4 ); /*  list-compare~1ayXVW~31899 */
  twobit_pop( 8 );
  twobit_invoke( 6 );
  twobit_label( 3844, compiled_block_1_3844 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3847, compiled_block_1_3847 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 3847, compiled_block_1_3847 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  error~1ayXVW~11537 */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_102( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 3 );
  twobit_movereg( 2, 1 );
  twobit_lexical( 0, 3 );
  twobit_setrtn( 3829, compiled_block_1_3829 );
  twobit_invoke( 1 );
  twobit_label( 3829, compiled_block_1_3829 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 3 );
  twobit_setrtn( 3830, compiled_block_1_3830 );
  twobit_invoke( 1 );
  twobit_label( 3830, compiled_block_1_3830 );
  twobit_load( 0, 0 );
  twobit_branchf( 3832, compiled_block_1_3832 );
  twobit_stack( 2 );
  twobit_branchf( 3834, compiled_block_1_3834 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 3834, compiled_block_1_3834 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 3832, compiled_block_1_3832 );
  twobit_stack( 2 );
  twobit_branchf( 3836, compiled_block_1_3836 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 3836, compiled_block_1_3836 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 3837, compiled_block_1_3837 );
  twobit_invoke( 1 );
  twobit_label( 3837, compiled_block_1_3837 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 3 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 3838, compiled_block_1_3838 );
  twobit_invoke( 1 );
  twobit_label( 3838, compiled_block_1_3838 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_97( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_movereg( 5, 31 );
  twobit_store( 4, 1 );
  twobit_movereg( 3, 4 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 1 );
  twobit_load( 5, 1 );
  twobit_movereg( 31, 6 );
  twobit_global( 2 ); /*  list-compare-as-vector~1ayXVW~31900 */
  twobit_pop( 1 );
  twobit_invoke( 6 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_99( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_global( 1 ); /* null? */
  twobit_setreg( 4 );
  twobit_global( 2 ); /* car */
  twobit_setreg( 31 );
  twobit_global( 3 ); /* cdr */
  twobit_setreg( 30 );
  twobit_movereg( 31, 5 );
  twobit_movereg( 30, 6 );
  twobit_global( 4 ); /*  list-compare-as-vector~1ayXVW~31900 */
  twobit_invoke( 6 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_101( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /* null? */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_global( 3 ); /* car */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_global( 4 ); /* cdr */
  twobit_setreg( 4 );
  twobit_movereg( 4, 6 );
  twobit_load( 4, 1 );
  twobit_load( 5, 2 );
  twobit_global( 5 ); /*  list-compare-as-vector~1ayXVW~31900 */
  twobit_pop( 2 );
  twobit_invoke( 6 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_50( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 3863, compiled_block_1_3863 );
  twobit_invoke( 1 );
  twobit_label( 3863, compiled_block_1_3863 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(5), 84, compiled_temp_1_84, 3865, compiled_block_1_3865 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_85, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3865, compiled_block_1_3865 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(4), 86, compiled_temp_1_86, 3893, compiled_block_1_3893 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_87, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3893, compiled_block_1_3893 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 88, compiled_temp_1_88, 3897, compiled_block_1_3897 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_89, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3897, compiled_block_1_3897 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(2), 90, compiled_temp_1_90, 3901, compiled_block_1_3901 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_91, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3901, compiled_block_1_3901 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 11 );
  twobit_setreg( 2 );
  twobit_global( 12 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_85( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 2, 1 );
  twobit_store( 3, 5 );
  twobit_store( 4, 2 );
  twobit_store( 5, 4 );
  twobit_movereg( 3, 1 );
  twobit_movereg( 4, 31 );
  twobit_reg( 31 );
  twobit_setrtn( 3866, compiled_block_1_3866 );
  twobit_invoke( 1 );
  twobit_label( 3866, compiled_block_1_3866 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_stack( 2 );
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 3867, compiled_block_1_3867 );
  twobit_invoke( 1 );
  twobit_label( 3867, compiled_block_1_3867 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 2, 3 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /*  integer-compare~1ayXVW~31889 */
  twobit_setrtn( 3868, compiled_block_1_3868 );
  twobit_invoke( 2 );
  twobit_label( 3868, compiled_block_1_3868 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 3870, compiled_block_1_3870 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 3870, compiled_block_1_3870 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3872, compiled_block_1_3872 ); /* internal:branchf-eq?/imm */
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 6, 2 );
  twobit_load( 5, 1 );
  twobit_load( 3, 4 );
  twobit_load( 2, 5 );
  twobit_load( 1, 6 );
  twobit_lambda( compiled_start_1_92, 4, 6 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_pop( 6 );
  twobit_invoke( 1 );
  twobit_label( 3872, compiled_block_1_3872 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3889, compiled_block_1_3889 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 3889, compiled_block_1_3889 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  error~1ayXVW~11537 */
  twobit_pop( 6 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_92( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_lexical( 0, 6 );
  twobit_setreg( 2 );
  twobit_lexical( 2, 1 );
  twobit_setrtn( 3873, compiled_block_1_3873 );
  twobit_invoke( 2 );
  twobit_label( 3873, compiled_block_1_3873 );
  twobit_load( 0, 0 );
  twobit_branchf( 3875, compiled_block_1_3875 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3875, compiled_block_1_3875 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_setrtn( 3876, compiled_block_1_3876 );
  twobit_invoke( 2 );
  twobit_label( 3876, compiled_block_1_3876 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_setrtn( 3877, compiled_block_1_3877 );
  twobit_invoke( 2 );
  twobit_label( 3877, compiled_block_1_3877 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 3878, compiled_block_1_3878 );
  twobit_invoke( 2 );
  twobit_label( 3878, compiled_block_1_3878 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 3880, compiled_block_1_3880 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3880, compiled_block_1_3880 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3882, compiled_block_1_3882 ); /* internal:branchf-eq?/imm */
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 93, compiled_temp_1_93 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 0, 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 3882, compiled_block_1_3882 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3885, compiled_block_1_3885 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3885, compiled_block_1_3885 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_87( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 4, 1 );
  twobit_movereg( 3, 4 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 1 );
  twobit_load( 5, 1 );
  twobit_global( 2 ); /*  vector-compare~1ayXVW~31901 */
  twobit_pop( 1 );
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_89( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_global( 1 ); /* vector-length */
  twobit_setreg( 4 );
  twobit_global( 2 ); /* vector-ref */
  twobit_setreg( 31 );
  twobit_movereg( 31, 5 );
  twobit_global( 3 ); /*  vector-compare~1ayXVW~31901 */
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_91( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /* vector-length */
  twobit_setreg( 4 );
  twobit_global( 3 ); /* vector-ref */
  twobit_setreg( 31 );
  twobit_movereg( 31, 5 );
  twobit_global( 4 ); /*  vector-compare~1ayXVW~31901 */
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_51( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 3905, compiled_block_1_3905 );
  twobit_invoke( 1 );
  twobit_label( 3905, compiled_block_1_3905 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(5), 72, compiled_temp_1_72, 3907, compiled_block_1_3907 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_73, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3907, compiled_block_1_3907 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(4), 74, compiled_temp_1_74, 3934, compiled_block_1_3934 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_75, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3934, compiled_block_1_3934 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(3), 76, compiled_temp_1_76, 3938, compiled_block_1_3938 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_77, 8, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3938, compiled_block_1_3938 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(2), 78, compiled_temp_1_78, 3942, compiled_block_1_3942 ); /* internal:branchf-=/imm */
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_79, 10, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 3942, compiled_block_1_3942 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 1 );
  twobit_const( 11 );
  twobit_setreg( 2 );
  twobit_global( 12 ); /* assertion-violation */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_73( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 2, 1 );
  twobit_store( 3, 5 );
  twobit_store( 4, 2 );
  twobit_store( 5, 4 );
  twobit_movereg( 3, 1 );
  twobit_movereg( 4, 31 );
  twobit_reg( 31 );
  twobit_setrtn( 3908, compiled_block_1_3908 );
  twobit_invoke( 1 );
  twobit_label( 3908, compiled_block_1_3908 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_stack( 2 );
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 3909, compiled_block_1_3909 );
  twobit_invoke( 1 );
  twobit_label( 3909, compiled_block_1_3909 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_622( 3, 80, compiled_temp_1_80, 3911, compiled_block_1_3911 ); /* internal:branchf-<= */
  twobit_reg( 4 );
  twobit_skip( 3910, compiled_block_1_3910 );
  twobit_label( 3911, compiled_block_1_3911 );
  twobit_reg( 3 );
  twobit_label( 3910, compiled_block_1_3910 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_26(); /* inexact? */
  twobit_branchf( 3913, compiled_block_1_3913 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 3912, compiled_block_1_3912 );
  twobit_label( 3913, compiled_block_1_3913 );
  twobit_reg( 3 );
  twobit_op1_26(); /* inexact? */
  twobit_label( 3912, compiled_block_1_3912 );
  twobit_branchf( 3915, compiled_block_1_3915 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op2_61( 1, 81, compiled_temp_1_81 ); /* + */
  twobit_skip( 3914, compiled_block_1_3914 );
  twobit_label( 3915, compiled_block_1_3915 );
  twobit_reg( 2 );
  twobit_label( 3914, compiled_block_1_3914 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 2 );
  twobit_load( 8, 1 );
  twobit_load( 7, 4 );
  twobit_load( 6, 5 );
  twobit_load( 5, 6 );
  twobit_lambda( compiled_start_1_82, 4, 8 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_pop( 6 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_82( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 2, 1 );
  twobit_setrtn( 3916, compiled_block_1_3916 );
  twobit_invoke( 2 );
  twobit_label( 3916, compiled_block_1_3916 );
  twobit_load( 0, 0 );
  twobit_branchf( 3918, compiled_block_1_3918 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  integer-compare~1ayXVW~31889 */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 3918, compiled_block_1_3918 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 8 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 7 );
  twobit_setrtn( 3920, compiled_block_1_3920 );
  twobit_invoke( 2 );
  twobit_label( 3920, compiled_block_1_3920 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 6 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 7 );
  twobit_setrtn( 3921, compiled_block_1_3921 );
  twobit_invoke( 2 );
  twobit_label( 3921, compiled_block_1_3921 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_lexical( 0, 5 );
  twobit_setrtn( 3922, compiled_block_1_3922 );
  twobit_invoke( 2 );
  twobit_label( 3922, compiled_block_1_3922 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 3924, compiled_block_1_3924 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3924, compiled_block_1_3924 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3926, compiled_block_1_3926 ); /* internal:branchf-eq?/imm */
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 83, compiled_temp_1_83 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 3926, compiled_block_1_3926 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3929, compiled_block_1_3929 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 3929, compiled_block_1_3929 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_75( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 4, 1 );
  twobit_movereg( 3, 4 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 1 );
  twobit_load( 5, 1 );
  twobit_global( 2 ); /*  vector-compare-as-list~1ayXVW~31902 */
  twobit_pop( 1 );
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_77( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_global( 1 ); /* vector-length */
  twobit_setreg( 4 );
  twobit_global( 2 ); /* vector-ref */
  twobit_setreg( 31 );
  twobit_movereg( 31, 5 );
  twobit_global( 3 ); /*  vector-compare-as-list~1ayXVW~31902 */
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_79( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /* vector-length */
  twobit_setreg( 4 );
  twobit_global( 3 ); /* vector-ref */
  twobit_setreg( 31 );
  twobit_movereg( 31, 5 );
  twobit_global( 4 ); /*  vector-compare-as-list~1ayXVW~31902 */
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_52( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 4 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /* null? */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 3946, compiled_block_1_3946 );
  twobit_invoke( 1 );
  twobit_label( 3946, compiled_block_1_3946 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 2 );
  twobit_stack( 1 );
  twobit_setrtn( 3947, compiled_block_1_3947 );
  twobit_invoke( 1 );
  twobit_label( 3947, compiled_block_1_3947 );
  twobit_load( 0, 0 );
  twobit_branchf( 3949, compiled_block_1_3949 );
  twobit_stack( 3 );
  twobit_branchf( 3951, compiled_block_1_3951 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3951, compiled_block_1_3951 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3949, compiled_block_1_3949 );
  twobit_stack( 3 );
  twobit_branchf( 3953, compiled_block_1_3953 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3953, compiled_block_1_3953 );
  twobit_load( 1, 4 );
  twobit_global( 2 ); /* pair? */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_setrtn( 3954, compiled_block_1_3954 );
  twobit_invoke( 1 );
  twobit_label( 3954, compiled_block_1_3954 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 2 );
  twobit_stack( 3 );
  twobit_setrtn( 3955, compiled_block_1_3955 );
  twobit_invoke( 1 );
  twobit_label( 3955, compiled_block_1_3955 );
  twobit_load( 0, 0 );
  twobit_branchf( 3957, compiled_block_1_3957 );
  twobit_stack( 1 );
  twobit_branchf( 3959, compiled_block_1_3959 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 2 );
  twobit_check( 3, 0, 0, 3960, compiled_block_1_3960 );
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_stack( 4 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 4 );
  twobit_check( 3, 0, 0, 3960, compiled_block_1_3960 );
  twobit_stack( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  default-compare~1ayXVW~31903 */
  twobit_setrtn( 3961, compiled_block_1_3961 );
  twobit_invoke( 2 );
  twobit_label( 3961, compiled_block_1_3961 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 3963, compiled_block_1_3963 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3963, compiled_block_1_3963 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 3965, compiled_block_1_3965 ); /* internal:branchf-eq?/imm */
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_stack( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  default-compare~1ayXVW~31903 */
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 3965, compiled_block_1_3965 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 3968, compiled_block_1_3968 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3968, compiled_block_1_3968 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 3959, compiled_block_1_3959 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3957, compiled_block_1_3957 );
  twobit_stack( 1 );
  twobit_branchf( 3971, compiled_block_1_3971 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3971, compiled_block_1_3971 );
  twobit_load( 1, 4 );
  twobit_global( 6 ); /* boolean? */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 3972, compiled_block_1_3972 );
  twobit_invoke( 1 );
  twobit_label( 3972, compiled_block_1_3972 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 2 );
  twobit_stack( 1 );
  twobit_setrtn( 3973, compiled_block_1_3973 );
  twobit_invoke( 1 );
  twobit_label( 3973, compiled_block_1_3973 );
  twobit_load( 0, 0 );
  twobit_branchf( 3975, compiled_block_1_3975 );
  twobit_stack( 3 );
  twobit_branchf( 3977, compiled_block_1_3977 );
  twobit_load( 1, 2 );
  twobit_load( 2, 4 );
  twobit_global( 7 ); /*  boolean-compare~1ayXVW~31878 */
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 3977, compiled_block_1_3977 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3975, compiled_block_1_3975 );
  twobit_stack( 3 );
  twobit_branchf( 3980, compiled_block_1_3980 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3980, compiled_block_1_3980 );
  twobit_load( 1, 4 );
  twobit_global( 8 ); /* char? */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_setrtn( 3981, compiled_block_1_3981 );
  twobit_invoke( 1 );
  twobit_label( 3981, compiled_block_1_3981 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 2 );
  twobit_stack( 3 );
  twobit_setrtn( 3982, compiled_block_1_3982 );
  twobit_invoke( 1 );
  twobit_label( 3982, compiled_block_1_3982 );
  twobit_load( 0, 0 );
  twobit_branchf( 3984, compiled_block_1_3984 );
  twobit_stack( 1 );
  twobit_branchf( 3986, compiled_block_1_3986 );
  twobit_load( 1, 2 );
  twobit_load( 2, 4 );
  twobit_global( 9 ); /*  char-compare~1ayXVW~31880 */
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 3986, compiled_block_1_3986 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3984, compiled_block_1_3984 );
  twobit_stack( 1 );
  twobit_branchf( 3989, compiled_block_1_3989 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3989, compiled_block_1_3989 );
  twobit_load( 1, 4 );
  twobit_global( 10 ); /* string? */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 3990, compiled_block_1_3990 );
  twobit_invoke( 1 );
  twobit_label( 3990, compiled_block_1_3990 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 2 );
  twobit_stack( 1 );
  twobit_setrtn( 3991, compiled_block_1_3991 );
  twobit_invoke( 1 );
  twobit_label( 3991, compiled_block_1_3991 );
  twobit_load( 0, 0 );
  twobit_branchf( 3993, compiled_block_1_3993 );
  twobit_stack( 3 );
  twobit_branchf( 3995, compiled_block_1_3995 );
  twobit_load( 1, 2 );
  twobit_load( 2, 4 );
  twobit_global( 11 ); /*  string-compare~1ayXVW~31884 */
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 3995, compiled_block_1_3995 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3993, compiled_block_1_3993 );
  twobit_stack( 3 );
  twobit_branchf( 3998, compiled_block_1_3998 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 3998, compiled_block_1_3998 );
  twobit_load( 1, 4 );
  twobit_global( 12 ); /* symbol? */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_setrtn( 3999, compiled_block_1_3999 );
  twobit_invoke( 1 );
  twobit_label( 3999, compiled_block_1_3999 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 2 );
  twobit_stack( 3 );
  twobit_setrtn( 4000, compiled_block_1_4000 );
  twobit_invoke( 1 );
  twobit_label( 4000, compiled_block_1_4000 );
  twobit_load( 0, 0 );
  twobit_branchf( 4002, compiled_block_1_4002 );
  twobit_stack( 1 );
  twobit_branchf( 4004, compiled_block_1_4004 );
  twobit_load( 1, 2 );
  twobit_load( 2, 4 );
  twobit_global( 13 ); /*  symbol-compare~1ayXVW~31887 */
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 4004, compiled_block_1_4004 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 4002, compiled_block_1_4002 );
  twobit_stack( 1 );
  twobit_branchf( 4007, compiled_block_1_4007 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 4007, compiled_block_1_4007 );
  twobit_load( 1, 4 );
  twobit_global( 14 ); /* number? */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 4008, compiled_block_1_4008 );
  twobit_invoke( 1 );
  twobit_label( 4008, compiled_block_1_4008 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 2 );
  twobit_stack( 1 );
  twobit_setrtn( 4009, compiled_block_1_4009 );
  twobit_invoke( 1 );
  twobit_label( 4009, compiled_block_1_4009 );
  twobit_load( 0, 0 );
  twobit_branchf( 4011, compiled_block_1_4011 );
  twobit_stack( 3 );
  twobit_branchf( 4013, compiled_block_1_4013 );
  twobit_load( 1, 2 );
  twobit_load( 2, 4 );
  twobit_global( 15 ); /*  number-compare~1ayXVW~31895 */
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 4013, compiled_block_1_4013 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 4011, compiled_block_1_4011 );
  twobit_stack( 3 );
  twobit_branchf( 4016, compiled_block_1_4016 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 4016, compiled_block_1_4016 );
  twobit_load( 1, 4 );
  twobit_global( 16 ); /* vector? */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_setrtn( 4017, compiled_block_1_4017 );
  twobit_invoke( 1 );
  twobit_label( 4017, compiled_block_1_4017 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 2 );
  twobit_stack( 3 );
  twobit_setrtn( 4018, compiled_block_1_4018 );
  twobit_invoke( 1 );
  twobit_label( 4018, compiled_block_1_4018 );
  twobit_load( 0, 0 );
  twobit_branchf( 4020, compiled_block_1_4020 );
  twobit_stack( 1 );
  twobit_branchf( 4022, compiled_block_1_4022 );
  twobit_load( 3, 4 );
  twobit_load( 2, 2 );
  twobit_global( 3 ); /*  default-compare~1ayXVW~31903 */
  twobit_setreg( 1 );
  twobit_global( 17 ); /*  vector-compare~1ayXVW~31901 */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 4022, compiled_block_1_4022 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 4020, compiled_block_1_4020 );
  twobit_stack( 1 );
  twobit_branchf( 4025, compiled_block_1_4025 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 4025, compiled_block_1_4025 );
  twobit_load( 2, 2 );
  twobit_load( 3, 4 );
  twobit_const( 18 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  error~1ayXVW~11537 */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 3960, compiled_block_1_3960 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_53( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_54, 2, 3 );
  twobit_return();
  twobit_label( 4027, compiled_block_1_4027 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 1, 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 4069, compiled_block_1_4069 );
  twobit_invoke( 2 );
  twobit_label( 4069, compiled_block_1_4069 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(-1), 4071, compiled_block_1_4071 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 4070, compiled_block_1_4070 );
  twobit_label( 4071, compiled_block_1_4071 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_57( 3, 55, compiled_temp_1_55 ); /* eqv? */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_branchf( 4073, compiled_block_1_4073 );
  twobit_reg( 3 );
  twobit_skip( 4070, compiled_block_1_4070 );
  twobit_label( 4073, compiled_block_1_4073 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_57( 2, 56, compiled_temp_1_56 ); /* eqv? */
  twobit_label( 4070, compiled_block_1_4070 );
  twobit_branchf( 4075, compiled_block_1_4075 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 4075, compiled_block_1_4075 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 4 ); /*  error~1ayXVW~11537 */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_54( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_setrtn( 4029, compiled_block_1_4029 );
  twobit_jump( 1, 4027, compiled_block_1_4027 );
  twobit_label( 4029, compiled_block_1_4029 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 3, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_setrtn( 4030, compiled_block_1_4030 );
  twobit_jump( 1, 4027, compiled_block_1_4027 );
  twobit_label( 4030, compiled_block_1_4030 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_setrtn( 4031, compiled_block_1_4031 );
  twobit_jump( 1, 4027, compiled_block_1_4027 );
  twobit_label( 4031, compiled_block_1_4031 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 3, 2 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_setrtn( 4032, compiled_block_1_4032 );
  twobit_jump( 1, 4027, compiled_block_1_4027 );
  twobit_label( 4032, compiled_block_1_4032 );
  twobit_load( 0, 0 );
  twobit_op1_branchf_612( 57, compiled_temp_1_57, 4034, compiled_block_1_4034 ); /* internal:branchf-zero? */
  twobit_op1_3(); /* unspecified */
  twobit_skip( 4033, compiled_block_1_4033 );
  twobit_label( 4034, compiled_block_1_4034 );
  twobit_load( 3, 2 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 4035, compiled_block_1_4035 );
  twobit_invoke( 3 );
  twobit_label( 4035, compiled_block_1_4035 );
  twobit_load( 0, 0 );
  twobit_label( 4033, compiled_block_1_4033 );
  twobit_stack( 3 );
  twobit_op1_branchf_612( 58, compiled_temp_1_58, 4037, compiled_block_1_4037 ); /* internal:branchf-zero? */
  twobit_op1_3(); /* unspecified */
  twobit_skip( 4036, compiled_block_1_4036 );
  twobit_label( 4037, compiled_block_1_4037 );
  twobit_load( 3, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 4038, compiled_block_1_4038 );
  twobit_invoke( 3 );
  twobit_label( 4038, compiled_block_1_4038 );
  twobit_load( 0, 0 );
  twobit_label( 4036, compiled_block_1_4036 );
  twobit_load( 4, 4 );
  twobit_stack( 5 );
  twobit_op2_61( 4, 59, compiled_temp_1_59 ); /* + */
  twobit_op1_branchf_612( 60, compiled_temp_1_60, 4040, compiled_block_1_4040 ); /* internal:branchf-zero? */
  twobit_op1_3(); /* unspecified */
  twobit_skip( 4039, compiled_block_1_4039 );
  twobit_label( 4040, compiled_block_1_4040 );
  twobit_load( 3, 2 );
  twobit_load( 4, 1 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 4041, compiled_block_1_4041 );
  twobit_invoke( 4 );
  twobit_label( 4041, compiled_block_1_4041 );
  twobit_load( 0, 0 );
  twobit_label( 4039, compiled_block_1_4039 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_branchf( 4043, compiled_block_1_4043 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_setrtn( 4044, compiled_block_1_4044 );
  twobit_jump( 1, 4027, compiled_block_1_4027 );
  twobit_label( 4044, compiled_block_1_4044 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_setrtn( 4045, compiled_block_1_4045 );
  twobit_jump( 1, 4027, compiled_block_1_4027 );
  twobit_label( 4045, compiled_block_1_4045 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 3, 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_setrtn( 4046, compiled_block_1_4046 );
  twobit_jump( 1, 4027, compiled_block_1_4027 );
  twobit_label( 4046, compiled_block_1_4046 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_setrtn( 4047, compiled_block_1_4047 );
  twobit_jump( 1, 4027, compiled_block_1_4027 );
  twobit_label( 4047, compiled_block_1_4047 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 3, 4 );
  twobit_reg( 4 );
  twobit_op2_61( 3, 61, compiled_temp_1_61 ); /* + */
  twobit_op1_branchf_612( 62, compiled_temp_1_62, 4049, compiled_block_1_4049 ); /* internal:branchf-zero? */
  twobit_op1_3(); /* unspecified */
  twobit_skip( 4048, compiled_block_1_4048 );
  twobit_label( 4049, compiled_block_1_4049 );
  twobit_load( 3, 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 4050, compiled_block_1_4050 );
  twobit_invoke( 4 );
  twobit_label( 4050, compiled_block_1_4050 );
  twobit_load( 0, 0 );
  twobit_label( 4048, compiled_block_1_4048 );
  twobit_load( 4, 3 );
  twobit_stack( 6 );
  twobit_op2_61( 4, 63, compiled_temp_1_63 ); /* + */
  twobit_op1_branchf_612( 64, compiled_temp_1_64, 4052, compiled_block_1_4052 ); /* internal:branchf-zero? */
  twobit_op1_3(); /* unspecified */
  twobit_skip( 4051, compiled_block_1_4051 );
  twobit_label( 4052, compiled_block_1_4052 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 4053, compiled_block_1_4053 );
  twobit_invoke( 4 );
  twobit_label( 4053, compiled_block_1_4053 );
  twobit_load( 0, 0 );
  twobit_label( 4051, compiled_block_1_4051 );
  twobit_load( 4, 6 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_op2_63( 4, 65, compiled_temp_1_65 ); /* * */
  twobit_setreg( 4 );
  twobit_load( 3, 7 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_op2_63( 3, 66, compiled_temp_1_66 ); /* * */
  twobit_op2imm_130( fixnum(13), 67, compiled_temp_1_67 ); /* + */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_61( 3, 68, compiled_temp_1_68 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_61( 4, 69, compiled_temp_1_69 ); /* + */
  twobit_setreg( 4 );
  twobit_reg_op1_check_651(reg(4),4054,compiled_block_1_4054); /* internal:check-fixnum? with (4 0 0) */
  twobit_const( 4 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_reg_op2_check_661(reg(4),reg(3),4054,compiled_block_1_4054); /* internal:check-range with (4 0 0) */
  twobit_const( 4 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* list? */
  twobit_setrtn( 4055, compiled_block_1_4055 );
  twobit_invoke( 1 );
  twobit_label( 4055, compiled_block_1_4055 );
  twobit_load( 0, 0 );
  twobit_branchf( 4057, compiled_block_1_4057 );
  twobit_load( 2, 2 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_70, 7, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 7 );
  twobit_global( 8 ); /*  map~1ayXVW~1381 */
  twobit_setrtn( 4064, compiled_block_1_4064 );
  twobit_invoke( 2 );
  twobit_label( 4064, compiled_block_1_4064 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_setreg( 1 );
  twobit_const( 9 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 10 ); /* apply */
  twobit_setrtn( 4065, compiled_block_1_4065 );
  twobit_invoke( 4 );
  twobit_label( 4065, compiled_block_1_4065 );
  twobit_load( 0, 0 );
  twobit_skip( 4042, compiled_block_1_4042 );
  twobit_label( 4057, compiled_block_1_4057 );
  twobit_op1_3(); /* unspecified */
  twobit_skip( 4042, compiled_block_1_4042 );
  twobit_label( 4043, compiled_block_1_4043 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_label( 4042, compiled_block_1_4042 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_global( 11 ); /*  random-integer~1ayXVW~13282 */
  twobit_setrtn( 4066, compiled_block_1_4066 );
  twobit_invoke( 1 );
  twobit_label( 4066, compiled_block_1_4066 );
  twobit_load( 0, 0 );
  twobit_op1_branchf_612( 71, compiled_temp_1_71, 4068, compiled_block_1_4068 ); /* internal:branchf-zero? */
  twobit_stack( 2 );
  twobit_skip( 4067, compiled_block_1_4067 );
  twobit_label( 4068, compiled_block_1_4068 );
  twobit_stack( 1 );
  twobit_label( 4067, compiled_block_1_4067 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_stack( 5 );
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 4054, compiled_block_1_4054 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_70( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_const( 1 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 4, 4059, compiled_block_1_4059 ); /* internal:branchf-eq? */
  twobit_lexical( 0, 2 );
  twobit_return();
  twobit_label( 4059, compiled_block_1_4059 );
  twobit_const( 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 4, 4061, compiled_block_1_4061 ); /* internal:branchf-eq? */
  twobit_lexical( 0, 1 );
  twobit_return();
  twobit_label( 4061, compiled_block_1_4061 );
  twobit_const( 3 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 4, 4063, compiled_block_1_4063 ); /* internal:branchf-eq? */
  twobit_lexical( 1, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_return();
  twobit_label( 4063, compiled_block_1_4063 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_epilogue();
}


RTYPE twobit_thunk_af401aeac9fecaed9cf182cbcc7ac865_0(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_1_0(CONT_ACTUALS));
}
static RTYPE compiled_block_2_1004( CONT_PARAMS );
static RTYPE compiled_block_2_1003( CONT_PARAMS );
static RTYPE compiled_start_2_0( CONT_PARAMS );
static RTYPE compiled_start_2_3( CONT_PARAMS );
static RTYPE compiled_start_2_2( CONT_PARAMS );
static RTYPE compiled_start_2_1( CONT_PARAMS );

static RTYPE compiled_start_2_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_2_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_2_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1003, compiled_block_2_1003 );
  twobit_invoke( 8 );
  twobit_label( 1003, compiled_block_2_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1004, compiled_block_2_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_2_1004 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_af401aeac9fecaed9cf182cbcc7ac865_1(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_2_0(CONT_ACTUALS));
}
codeptr_t CDECL twobit_load_table[] = { 
  twobit_thunk_af401aeac9fecaed9cf182cbcc7ac865_0,
  twobit_thunk_af401aeac9fecaed9cf182cbcc7ac865_1,
  0  /* The table may be empty; some compilers complain */
};

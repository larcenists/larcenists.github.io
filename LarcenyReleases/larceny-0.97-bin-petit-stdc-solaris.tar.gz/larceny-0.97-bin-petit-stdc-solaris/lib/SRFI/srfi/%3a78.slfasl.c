/* Generated from /proj/will/pnkfelix/larcenytest/larceny-petit-Nightly-2009-08-19/larceny_src/lib/SRFI/srfi/%3a78.slfasl */
#include "petit-instr.h"

static RTYPE compiled_block_1_1627( CONT_PARAMS );
static RTYPE compiled_block_1_1626( CONT_PARAMS );
static RTYPE compiled_start_1_0( CONT_PARAMS );
static RTYPE compiled_block_1_1527( CONT_PARAMS );
static RTYPE compiled_block_1_1526( CONT_PARAMS );
static RTYPE compiled_start_1_3( CONT_PARAMS );
static RTYPE compiled_block_1_1607( CONT_PARAMS );
static RTYPE compiled_block_1_1608( CONT_PARAMS );
static RTYPE compiled_block_1_1619( CONT_PARAMS );
static RTYPE compiled_block_1_1620( CONT_PARAMS );
static RTYPE compiled_block_1_1623( CONT_PARAMS );
static RTYPE compiled_block_1_1622( CONT_PARAMS );
static RTYPE compiled_block_1_1621( CONT_PARAMS );
static RTYPE compiled_temp_1_18( CONT_PARAMS );
static RTYPE compiled_block_1_1618( CONT_PARAMS );
static RTYPE compiled_block_1_1610( CONT_PARAMS );
static RTYPE compiled_block_1_1612( CONT_PARAMS );
static RTYPE compiled_block_1_1613( CONT_PARAMS );
static RTYPE compiled_block_1_1616( CONT_PARAMS );
static RTYPE compiled_block_1_1615( CONT_PARAMS );
static RTYPE compiled_block_1_1614( CONT_PARAMS );
static RTYPE compiled_temp_1_17( CONT_PARAMS );
static RTYPE compiled_block_1_1611( CONT_PARAMS );
static RTYPE compiled_start_1_16( CONT_PARAMS );
static RTYPE compiled_block_1_1572( CONT_PARAMS );
static RTYPE compiled_block_1_1606( CONT_PARAMS );
static RTYPE compiled_block_1_1605( CONT_PARAMS );
static RTYPE compiled_block_1_1594( CONT_PARAMS );
static RTYPE compiled_block_1_1604( CONT_PARAMS );
static RTYPE compiled_block_1_1603( CONT_PARAMS );
static RTYPE compiled_block_1_1600( CONT_PARAMS );
static RTYPE compiled_block_1_1602( CONT_PARAMS );
static RTYPE compiled_block_1_1601( CONT_PARAMS );
static RTYPE compiled_block_1_1598( CONT_PARAMS );
static RTYPE compiled_block_1_1597( CONT_PARAMS );
static RTYPE compiled_block_1_1596( CONT_PARAMS );
static RTYPE compiled_block_1_1595( CONT_PARAMS );
static RTYPE compiled_block_1_1583( CONT_PARAMS );
static RTYPE compiled_block_1_1592( CONT_PARAMS );
static RTYPE compiled_block_1_1591( CONT_PARAMS );
static RTYPE compiled_block_1_1590( CONT_PARAMS );
static RTYPE compiled_block_1_1589( CONT_PARAMS );
static RTYPE compiled_block_1_1587( CONT_PARAMS );
static RTYPE compiled_block_1_1588( CONT_PARAMS );
static RTYPE compiled_block_1_1585( CONT_PARAMS );
static RTYPE compiled_block_1_1584( CONT_PARAMS );
static RTYPE compiled_block_1_1575( CONT_PARAMS );
static RTYPE compiled_block_1_1581( CONT_PARAMS );
static RTYPE compiled_block_1_1579( CONT_PARAMS );
static RTYPE compiled_block_1_1580( CONT_PARAMS );
static RTYPE compiled_block_1_1577( CONT_PARAMS );
static RTYPE compiled_block_1_1576( CONT_PARAMS );
static RTYPE compiled_block_1_1573( CONT_PARAMS );
static RTYPE compiled_block_1_1571( CONT_PARAMS );
static RTYPE compiled_start_1_15( CONT_PARAMS );
static RTYPE compiled_block_1_1570( CONT_PARAMS );
static RTYPE compiled_temp_1_20( CONT_PARAMS );
static RTYPE compiled_temp_1_19( CONT_PARAMS );
static RTYPE compiled_block_1_1568( CONT_PARAMS );
static RTYPE compiled_start_1_14( CONT_PARAMS );
static RTYPE compiled_block_1_1562( CONT_PARAMS );
static RTYPE compiled_block_1_1547( CONT_PARAMS );
static RTYPE compiled_block_1_1566( CONT_PARAMS );
static RTYPE compiled_block_1_1565( CONT_PARAMS );
static RTYPE compiled_block_1_1564( CONT_PARAMS );
static RTYPE compiled_block_1_1563( CONT_PARAMS );
static RTYPE compiled_block_1_1561( CONT_PARAMS );
static RTYPE compiled_block_1_1559( CONT_PARAMS );
static RTYPE compiled_block_1_1555( CONT_PARAMS );
static RTYPE compiled_temp_1_22( CONT_PARAMS );
static RTYPE compiled_block_1_1557( CONT_PARAMS );
static RTYPE compiled_block_1_1556( CONT_PARAMS );
static RTYPE compiled_block_1_1554( CONT_PARAMS );
static RTYPE compiled_block_1_1553( CONT_PARAMS );
static RTYPE compiled_block_1_1552( CONT_PARAMS );
static RTYPE compiled_block_1_1551( CONT_PARAMS );
static RTYPE compiled_block_1_1550( CONT_PARAMS );
static RTYPE compiled_block_1_1549( CONT_PARAMS );
static RTYPE compiled_block_1_1548( CONT_PARAMS );
static RTYPE compiled_temp_1_21( CONT_PARAMS );
static RTYPE compiled_block_1_1545( CONT_PARAMS );
static RTYPE compiled_start_1_13( CONT_PARAMS );
static RTYPE compiled_block_1_1543( CONT_PARAMS );
static RTYPE compiled_block_1_1542( CONT_PARAMS );
static RTYPE compiled_block_1_1541( CONT_PARAMS );
static RTYPE compiled_block_1_1540( CONT_PARAMS );
static RTYPE compiled_start_1_12( CONT_PARAMS );
static RTYPE compiled_block_1_1534( CONT_PARAMS );
static RTYPE compiled_block_1_1538( CONT_PARAMS );
static RTYPE compiled_block_1_1537( CONT_PARAMS );
static RTYPE compiled_block_1_1536( CONT_PARAMS );
static RTYPE compiled_block_1_1535( CONT_PARAMS );
static RTYPE compiled_temp_1_23( CONT_PARAMS );
static RTYPE compiled_block_1_1533( CONT_PARAMS );
static RTYPE compiled_start_1_11( CONT_PARAMS );
static RTYPE compiled_block_1_1531( CONT_PARAMS );
static RTYPE compiled_start_1_10( CONT_PARAMS );
static RTYPE compiled_block_1_1529( CONT_PARAMS );
static RTYPE compiled_block_1_1528( CONT_PARAMS );
static RTYPE compiled_start_1_9( CONT_PARAMS );
static RTYPE compiled_start_1_8( CONT_PARAMS );
static RTYPE compiled_temp_1_24( CONT_PARAMS );
static RTYPE compiled_start_1_7( CONT_PARAMS );
static RTYPE compiled_start_1_6( CONT_PARAMS );
static RTYPE compiled_block_1_1517( CONT_PARAMS );
static RTYPE compiled_block_1_1525( CONT_PARAMS );
static RTYPE compiled_block_1_1524( CONT_PARAMS );
static RTYPE compiled_block_1_1522( CONT_PARAMS );
static RTYPE compiled_block_1_1520( CONT_PARAMS );
static RTYPE compiled_block_1_1518( CONT_PARAMS );
static RTYPE compiled_start_1_5( CONT_PARAMS );
static RTYPE compiled_start_1_4( CONT_PARAMS );
static RTYPE compiled_block_1_1515( CONT_PARAMS );
static RTYPE compiled_block_1_1174( CONT_PARAMS );
static RTYPE compiled_block_1_1068( CONT_PARAMS );
static RTYPE compiled_start_1_2( CONT_PARAMS );
static RTYPE compiled_block_1_1481( CONT_PARAMS );
static RTYPE compiled_block_1_1483( CONT_PARAMS );
static RTYPE compiled_block_1_1485( CONT_PARAMS );
static RTYPE compiled_block_1_1487( CONT_PARAMS );
static RTYPE compiled_block_1_1494( CONT_PARAMS );
static RTYPE compiled_block_1_1496( CONT_PARAMS );
static RTYPE compiled_block_1_1498( CONT_PARAMS );
static RTYPE compiled_block_1_1500( CONT_PARAMS );
static RTYPE compiled_block_1_1502( CONT_PARAMS );
static RTYPE compiled_block_1_1505( CONT_PARAMS );
static RTYPE compiled_block_1_1504( CONT_PARAMS );
static RTYPE compiled_block_1_1503( CONT_PARAMS );
static RTYPE compiled_block_1_1489( CONT_PARAMS );
static RTYPE compiled_block_1_1490( CONT_PARAMS );
static RTYPE compiled_block_1_1492( CONT_PARAMS );
static RTYPE compiled_block_1_1491( CONT_PARAMS );
static RTYPE compiled_block_1_1488( CONT_PARAMS );
static RTYPE compiled_block_1_1183( CONT_PARAMS );
static RTYPE compiled_block_1_1447( CONT_PARAMS );
static RTYPE compiled_block_1_1449( CONT_PARAMS );
static RTYPE compiled_block_1_1451( CONT_PARAMS );
static RTYPE compiled_block_1_1458( CONT_PARAMS );
static RTYPE compiled_block_1_1460( CONT_PARAMS );
static RTYPE compiled_block_1_1462( CONT_PARAMS );
static RTYPE compiled_block_1_1465( CONT_PARAMS );
static RTYPE compiled_block_1_1467( CONT_PARAMS );
static RTYPE compiled_block_1_1471( CONT_PARAMS );
static RTYPE compiled_block_1_1470( CONT_PARAMS );
static RTYPE compiled_block_1_1469( CONT_PARAMS );
static RTYPE compiled_block_1_1468( CONT_PARAMS );
static RTYPE compiled_block_1_1463( CONT_PARAMS );
static RTYPE compiled_block_1_1453( CONT_PARAMS );
static RTYPE compiled_block_1_1454( CONT_PARAMS );
static RTYPE compiled_block_1_1456( CONT_PARAMS );
static RTYPE compiled_block_1_1455( CONT_PARAMS );
static RTYPE compiled_block_1_1452( CONT_PARAMS );
static RTYPE compiled_block_1_1182( CONT_PARAMS );
static RTYPE compiled_block_1_1405( CONT_PARAMS );
static RTYPE compiled_block_1_1407( CONT_PARAMS );
static RTYPE compiled_block_1_1409( CONT_PARAMS );
static RTYPE compiled_block_1_1411( CONT_PARAMS );
static RTYPE compiled_block_1_1418( CONT_PARAMS );
static RTYPE compiled_block_1_1420( CONT_PARAMS );
static RTYPE compiled_block_1_1422( CONT_PARAMS );
static RTYPE compiled_block_1_1424( CONT_PARAMS );
static RTYPE compiled_block_1_1426( CONT_PARAMS );
static RTYPE compiled_block_1_1429( CONT_PARAMS );
static RTYPE compiled_block_1_1431( CONT_PARAMS );
static RTYPE compiled_block_1_1434( CONT_PARAMS );
static RTYPE compiled_block_1_1433( CONT_PARAMS );
static RTYPE compiled_block_1_1432( CONT_PARAMS );
static RTYPE compiled_block_1_1427( CONT_PARAMS );
static RTYPE compiled_block_1_1413( CONT_PARAMS );
static RTYPE compiled_block_1_1414( CONT_PARAMS );
static RTYPE compiled_block_1_1416( CONT_PARAMS );
static RTYPE compiled_block_1_1415( CONT_PARAMS );
static RTYPE compiled_block_1_1412( CONT_PARAMS );
static RTYPE compiled_block_1_1181( CONT_PARAMS );
static RTYPE compiled_block_1_1376( CONT_PARAMS );
static RTYPE compiled_block_1_1378( CONT_PARAMS );
static RTYPE compiled_block_1_1380( CONT_PARAMS );
static RTYPE compiled_block_1_1382( CONT_PARAMS );
static RTYPE compiled_block_1_1389( CONT_PARAMS );
static RTYPE compiled_block_1_1391( CONT_PARAMS );
static RTYPE compiled_block_1_1393( CONT_PARAMS );
static RTYPE compiled_block_1_1396( CONT_PARAMS );
static RTYPE compiled_block_1_1395( CONT_PARAMS );
static RTYPE compiled_block_1_1394( CONT_PARAMS );
static RTYPE compiled_block_1_1384( CONT_PARAMS );
static RTYPE compiled_block_1_1385( CONT_PARAMS );
static RTYPE compiled_block_1_1387( CONT_PARAMS );
static RTYPE compiled_block_1_1386( CONT_PARAMS );
static RTYPE compiled_block_1_1383( CONT_PARAMS );
static RTYPE compiled_block_1_1180( CONT_PARAMS );
static RTYPE compiled_block_1_1339( CONT_PARAMS );
static RTYPE compiled_block_1_1341( CONT_PARAMS );
static RTYPE compiled_block_1_1343( CONT_PARAMS );
static RTYPE compiled_block_1_1345( CONT_PARAMS );
static RTYPE compiled_block_1_1347( CONT_PARAMS );
static RTYPE compiled_block_1_1354( CONT_PARAMS );
static RTYPE compiled_block_1_1356( CONT_PARAMS );
static RTYPE compiled_block_1_1358( CONT_PARAMS );
static RTYPE compiled_block_1_1360( CONT_PARAMS );
static RTYPE compiled_block_1_1362( CONT_PARAMS );
static RTYPE compiled_block_1_1364( CONT_PARAMS );
static RTYPE compiled_block_1_1363( CONT_PARAMS );
static RTYPE compiled_block_1_1349( CONT_PARAMS );
static RTYPE compiled_block_1_1350( CONT_PARAMS );
static RTYPE compiled_block_1_1352( CONT_PARAMS );
static RTYPE compiled_block_1_1351( CONT_PARAMS );
static RTYPE compiled_block_1_1348( CONT_PARAMS );
static RTYPE compiled_block_1_1179( CONT_PARAMS );
static RTYPE compiled_block_1_1303( CONT_PARAMS );
static RTYPE compiled_block_1_1305( CONT_PARAMS );
static RTYPE compiled_block_1_1307( CONT_PARAMS );
static RTYPE compiled_block_1_1309( CONT_PARAMS );
static RTYPE compiled_block_1_1316( CONT_PARAMS );
static RTYPE compiled_block_1_1318( CONT_PARAMS );
static RTYPE compiled_block_1_1320( CONT_PARAMS );
static RTYPE compiled_block_1_1323( CONT_PARAMS );
static RTYPE compiled_block_1_1325( CONT_PARAMS );
static RTYPE compiled_block_1_1328( CONT_PARAMS );
static RTYPE compiled_block_1_1327( CONT_PARAMS );
static RTYPE compiled_block_1_1326( CONT_PARAMS );
static RTYPE compiled_block_1_1321( CONT_PARAMS );
static RTYPE compiled_block_1_1311( CONT_PARAMS );
static RTYPE compiled_block_1_1312( CONT_PARAMS );
static RTYPE compiled_block_1_1314( CONT_PARAMS );
static RTYPE compiled_block_1_1313( CONT_PARAMS );
static RTYPE compiled_block_1_1310( CONT_PARAMS );
static RTYPE compiled_block_1_1178( CONT_PARAMS );
static RTYPE compiled_block_1_1259( CONT_PARAMS );
static RTYPE compiled_block_1_1261( CONT_PARAMS );
static RTYPE compiled_block_1_1263( CONT_PARAMS );
static RTYPE compiled_block_1_1265( CONT_PARAMS );
static RTYPE compiled_block_1_1267( CONT_PARAMS );
static RTYPE compiled_block_1_1274( CONT_PARAMS );
static RTYPE compiled_block_1_1276( CONT_PARAMS );
static RTYPE compiled_block_1_1278( CONT_PARAMS );
static RTYPE compiled_block_1_1280( CONT_PARAMS );
static RTYPE compiled_block_1_1282( CONT_PARAMS );
static RTYPE compiled_block_1_1285( CONT_PARAMS );
static RTYPE compiled_block_1_1287( CONT_PARAMS );
static RTYPE compiled_block_1_1289( CONT_PARAMS );
static RTYPE compiled_block_1_1288( CONT_PARAMS );
static RTYPE compiled_block_1_1283( CONT_PARAMS );
static RTYPE compiled_block_1_1269( CONT_PARAMS );
static RTYPE compiled_block_1_1270( CONT_PARAMS );
static RTYPE compiled_block_1_1272( CONT_PARAMS );
static RTYPE compiled_block_1_1271( CONT_PARAMS );
static RTYPE compiled_block_1_1268( CONT_PARAMS );
static RTYPE compiled_block_1_1177( CONT_PARAMS );
static RTYPE compiled_block_1_1228( CONT_PARAMS );
static RTYPE compiled_block_1_1230( CONT_PARAMS );
static RTYPE compiled_block_1_1232( CONT_PARAMS );
static RTYPE compiled_block_1_1239( CONT_PARAMS );
static RTYPE compiled_block_1_1242( CONT_PARAMS );
static RTYPE compiled_block_1_1244( CONT_PARAMS );
static RTYPE compiled_block_1_1247( CONT_PARAMS );
static RTYPE compiled_block_1_1250( CONT_PARAMS );
static RTYPE compiled_block_1_1249( CONT_PARAMS );
static RTYPE compiled_block_1_1248( CONT_PARAMS );
static RTYPE compiled_block_1_1245( CONT_PARAMS );
static RTYPE compiled_block_1_1240( CONT_PARAMS );
static RTYPE compiled_block_1_1234( CONT_PARAMS );
static RTYPE compiled_block_1_1235( CONT_PARAMS );
static RTYPE compiled_block_1_1237( CONT_PARAMS );
static RTYPE compiled_block_1_1236( CONT_PARAMS );
static RTYPE compiled_block_1_1233( CONT_PARAMS );
static RTYPE compiled_block_1_1176( CONT_PARAMS );
static RTYPE compiled_block_1_1213( CONT_PARAMS );
static RTYPE compiled_block_1_1215( CONT_PARAMS );
static RTYPE compiled_block_1_1217( CONT_PARAMS );
static RTYPE compiled_block_1_1220( CONT_PARAMS );
static RTYPE compiled_block_1_1222( CONT_PARAMS );
static RTYPE compiled_block_1_1221( CONT_PARAMS );
static RTYPE compiled_block_1_1218( CONT_PARAMS );
static RTYPE compiled_block_1_1175( CONT_PARAMS );
static RTYPE compiled_block_1_1186( CONT_PARAMS );
static RTYPE compiled_block_1_1188( CONT_PARAMS );
static RTYPE compiled_block_1_1190( CONT_PARAMS );
static RTYPE compiled_block_1_1197( CONT_PARAMS );
static RTYPE compiled_block_1_1199( CONT_PARAMS );
static RTYPE compiled_block_1_1201( CONT_PARAMS );
static RTYPE compiled_block_1_1205( CONT_PARAMS );
static RTYPE compiled_block_1_1204( CONT_PARAMS );
static RTYPE compiled_block_1_1203( CONT_PARAMS );
static RTYPE compiled_block_1_1202( CONT_PARAMS );
static RTYPE compiled_block_1_1192( CONT_PARAMS );
static RTYPE compiled_block_1_1193( CONT_PARAMS );
static RTYPE compiled_block_1_1195( CONT_PARAMS );
static RTYPE compiled_block_1_1194( CONT_PARAMS );
static RTYPE compiled_block_1_1191( CONT_PARAMS );
static RTYPE compiled_start_1_27( CONT_PARAMS );
static RTYPE compiled_block_1_1172( CONT_PARAMS );
static RTYPE compiled_block_1_1165( CONT_PARAMS );
static RTYPE compiled_block_1_1170( CONT_PARAMS );
static RTYPE compiled_block_1_1070( CONT_PARAMS );
static RTYPE compiled_block_1_1167( CONT_PARAMS );
static RTYPE compiled_block_1_1166( CONT_PARAMS );
static RTYPE compiled_block_1_1163( CONT_PARAMS );
static RTYPE compiled_block_1_1069( CONT_PARAMS );
static RTYPE compiled_block_1_1073( CONT_PARAMS );
static RTYPE compiled_block_1_1075( CONT_PARAMS );
static RTYPE compiled_block_1_1077( CONT_PARAMS );
static RTYPE compiled_block_1_1079( CONT_PARAMS );
static RTYPE compiled_block_1_1081( CONT_PARAMS );
static RTYPE compiled_block_1_1088( CONT_PARAMS );
static RTYPE compiled_block_1_1090( CONT_PARAMS );
static RTYPE compiled_block_1_1092( CONT_PARAMS );
static RTYPE compiled_block_1_1094( CONT_PARAMS );
static RTYPE compiled_block_1_1096( CONT_PARAMS );
static RTYPE compiled_block_1_1099( CONT_PARAMS );
static RTYPE compiled_block_1_1101( CONT_PARAMS );
static RTYPE compiled_block_1_1149( CONT_PARAMS );
static RTYPE compiled_block_1_1148( CONT_PARAMS );
static RTYPE compiled_block_1_1147( CONT_PARAMS );
static RTYPE compiled_block_1_1146( CONT_PARAMS );
static RTYPE compiled_block_1_1145( CONT_PARAMS );
static RTYPE compiled_block_1_1144( CONT_PARAMS );
static RTYPE compiled_block_1_1143( CONT_PARAMS );
static RTYPE compiled_block_1_1142( CONT_PARAMS );
static RTYPE compiled_block_1_1141( CONT_PARAMS );
static RTYPE compiled_block_1_1140( CONT_PARAMS );
static RTYPE compiled_block_1_1139( CONT_PARAMS );
static RTYPE compiled_block_1_1138( CONT_PARAMS );
static RTYPE compiled_block_1_1137( CONT_PARAMS );
static RTYPE compiled_block_1_1136( CONT_PARAMS );
static RTYPE compiled_block_1_1135( CONT_PARAMS );
static RTYPE compiled_block_1_1134( CONT_PARAMS );
static RTYPE compiled_block_1_1133( CONT_PARAMS );
static RTYPE compiled_block_1_1132( CONT_PARAMS );
static RTYPE compiled_block_1_1131( CONT_PARAMS );
static RTYPE compiled_block_1_1130( CONT_PARAMS );
static RTYPE compiled_block_1_1129( CONT_PARAMS );
static RTYPE compiled_block_1_1128( CONT_PARAMS );
static RTYPE compiled_block_1_1127( CONT_PARAMS );
static RTYPE compiled_block_1_1126( CONT_PARAMS );
static RTYPE compiled_block_1_1125( CONT_PARAMS );
static RTYPE compiled_block_1_1124( CONT_PARAMS );
static RTYPE compiled_block_1_1123( CONT_PARAMS );
static RTYPE compiled_block_1_1122( CONT_PARAMS );
static RTYPE compiled_block_1_1121( CONT_PARAMS );
static RTYPE compiled_block_1_1120( CONT_PARAMS );
static RTYPE compiled_block_1_1119( CONT_PARAMS );
static RTYPE compiled_block_1_1118( CONT_PARAMS );
static RTYPE compiled_block_1_1117( CONT_PARAMS );
static RTYPE compiled_block_1_1116( CONT_PARAMS );
static RTYPE compiled_block_1_1115( CONT_PARAMS );
static RTYPE compiled_block_1_1114( CONT_PARAMS );
static RTYPE compiled_block_1_1113( CONT_PARAMS );
static RTYPE compiled_block_1_1112( CONT_PARAMS );
static RTYPE compiled_block_1_1111( CONT_PARAMS );
static RTYPE compiled_block_1_1110( CONT_PARAMS );
static RTYPE compiled_block_1_1109( CONT_PARAMS );
static RTYPE compiled_block_1_1108( CONT_PARAMS );
static RTYPE compiled_block_1_1107( CONT_PARAMS );
static RTYPE compiled_block_1_1106( CONT_PARAMS );
static RTYPE compiled_block_1_1105( CONT_PARAMS );
static RTYPE compiled_block_1_1104( CONT_PARAMS );
static RTYPE compiled_block_1_1103( CONT_PARAMS );
static RTYPE compiled_block_1_1102( CONT_PARAMS );
static RTYPE compiled_block_1_1097( CONT_PARAMS );
static RTYPE compiled_block_1_1083( CONT_PARAMS );
static RTYPE compiled_block_1_1084( CONT_PARAMS );
static RTYPE compiled_block_1_1086( CONT_PARAMS );
static RTYPE compiled_block_1_1085( CONT_PARAMS );
static RTYPE compiled_block_1_1082( CONT_PARAMS );
static RTYPE compiled_start_1_26( CONT_PARAMS );
static RTYPE compiled_block_1_1031( CONT_PARAMS );
static RTYPE compiled_block_1_1033( CONT_PARAMS );
static RTYPE compiled_block_1_1035( CONT_PARAMS );
static RTYPE compiled_block_1_1037( CONT_PARAMS );
static RTYPE compiled_block_1_1044( CONT_PARAMS );
static RTYPE compiled_block_1_1046( CONT_PARAMS );
static RTYPE compiled_block_1_1048( CONT_PARAMS );
static RTYPE compiled_block_1_1050( CONT_PARAMS );
static RTYPE compiled_block_1_1052( CONT_PARAMS );
static RTYPE compiled_block_1_1058( CONT_PARAMS );
static RTYPE compiled_block_1_1057( CONT_PARAMS );
static RTYPE compiled_block_1_1056( CONT_PARAMS );
static RTYPE compiled_block_1_1055( CONT_PARAMS );
static RTYPE compiled_block_1_1054( CONT_PARAMS );
static RTYPE compiled_block_1_1053( CONT_PARAMS );
static RTYPE compiled_block_1_1039( CONT_PARAMS );
static RTYPE compiled_block_1_1040( CONT_PARAMS );
static RTYPE compiled_block_1_1042( CONT_PARAMS );
static RTYPE compiled_block_1_1041( CONT_PARAMS );
static RTYPE compiled_block_1_1038( CONT_PARAMS );
static RTYPE compiled_block_1_1002( CONT_PARAMS );
static RTYPE compiled_block_1_1005( CONT_PARAMS );
static RTYPE compiled_block_1_1007( CONT_PARAMS );
static RTYPE compiled_block_1_1009( CONT_PARAMS );
static RTYPE compiled_block_1_1016( CONT_PARAMS );
static RTYPE compiled_block_1_1018( CONT_PARAMS );
static RTYPE compiled_block_1_1020( CONT_PARAMS );
static RTYPE compiled_block_1_1023( CONT_PARAMS );
static RTYPE compiled_block_1_1022( CONT_PARAMS );
static RTYPE compiled_block_1_1021( CONT_PARAMS );
static RTYPE compiled_block_1_1011( CONT_PARAMS );
static RTYPE compiled_block_1_1012( CONT_PARAMS );
static RTYPE compiled_block_1_1014( CONT_PARAMS );
static RTYPE compiled_block_1_1013( CONT_PARAMS );
static RTYPE compiled_block_1_1010( CONT_PARAMS );
static RTYPE compiled_start_1_25( CONT_PARAMS );
static RTYPE compiled_start_1_1( CONT_PARAMS );

static RTYPE compiled_start_1_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 2 ); /*  check:proc-ec~1ayXVW~37949 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 3 ); /*  check:proc~1ayXVW~37909 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 4 ); /*  check-passed?~1ayXVW~37908 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 5 ); /*  check-report~1ayXVW~37907 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 6 ); /*  check:report-failed~1ayXVW~37906 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 7 ); /*  check:report-correct~1ayXVW~37905 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 8 ); /*  check:report-actual-result~1ayXVW~37904 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 9 ); /*  check:report-expression~1ayXVW~37903 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 10 ); /*  ignored2~1ayXVW~37902 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 11 ); /*  check:add-failed!~1ayXVW~37901 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 12 ); /*  check:add-correct!~1ayXVW~37900 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 13 ); /*  check-reset!~1ayXVW~37899 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 14 ); /*  check:failed~1ayXVW~37898 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 15 ); /*  check:correct~1ayXVW~37897 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 16 ); /*  ignored1~1ayXVW~37896 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 17 ); /*  check-set-mode!~1ayXVW~37895 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 18 ); /*  check:mode~1ayXVW~37894 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 19 ); /*  check:mode:state~1ayXVW~37893 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 20 ); /*  check:write~1ayXVW~37892 */
  twobit_lambda( compiled_start_1_1, 22, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_2, 24, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_3, 26, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 27 );
  twobit_setreg( 1 );
  twobit_const( 28 );
  twobit_setreg( 3 );
  twobit_const( 29 );
  twobit_setreg( 4 );
  twobit_const( 30 );
  twobit_setreg( 5 );
  twobit_const( 31 );
  twobit_setreg( 8 );
  twobit_global( 32 ); /* ex:make-library */
  twobit_setrtn( 1626, compiled_block_1_1626 );
  twobit_invoke( 8 );
  twobit_label( 1626, compiled_block_1_1626 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 33 ); /* ex:register-library! */
  twobit_setrtn( 1627, compiled_block_1_1627 );
  twobit_invoke( 1 );
  twobit_label( 1627, compiled_block_1_1627 );
  twobit_load( 0, 0 );
  twobit_global( 34 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* ex:uncompress */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_25, 2, 0 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1068, compiled_block_1_1068 );
  twobit_invoke( 2 );
  twobit_label( 1068, compiled_block_1_1068 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_26, 6, 0 );
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1174, compiled_block_1_1174 );
  twobit_invoke( 2 );
  twobit_label( 1174, compiled_block_1_1174 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_27, 9, 0 );
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1515, compiled_block_1_1515 );
  twobit_invoke( 2 );
  twobit_label( 1515, compiled_block_1_1515 );
  twobit_load( 0, 0 );
  twobit_global( 11 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_25( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1005, compiled_block_1_1005 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1007, compiled_block_1_1007 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1009, compiled_block_1_1009 ); /* internal:branchf-pair? */
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 5 );
  twobit_store( 3, 3 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /* ex:identifier? */
  twobit_setrtn( 1010, compiled_block_1_1010 );
  twobit_invoke( 1 );
  twobit_label( 1010, compiled_block_1_1010 );
  twobit_load( 0, 0 );
  twobit_branchf( 1012, compiled_block_1_1012 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1013, compiled_block_1_1013 );
  twobit_invoke( 5 );
  twobit_label( 1013, compiled_block_1_1013 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* ex:free-identifier=? */
  twobit_setrtn( 1014, compiled_block_1_1014 );
  twobit_invoke( 2 );
  twobit_label( 1014, compiled_block_1_1014 );
  twobit_load( 0, 0 );
  twobit_skip( 1011, compiled_block_1_1011 );
  twobit_label( 1012, compiled_block_1_1012 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1011, compiled_block_1_1011 );
  twobit_branchf( 1016, compiled_block_1_1016 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1018, compiled_block_1_1018 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1020, compiled_block_1_1020 ); /* internal:branchf-null? */
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1021, compiled_block_1_1021 );
  twobit_invoke( 5 );
  twobit_label( 1021, compiled_block_1_1021 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1022, compiled_block_1_1022 );
  twobit_invoke( 5 );
  twobit_label( 1022, compiled_block_1_1022 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1023, compiled_block_1_1023 );
  twobit_invoke( 5 );
  twobit_label( 1023, compiled_block_1_1023 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1020, compiled_block_1_1020 );
  twobit_load( 1, 5 );
  twobit_pop( 5 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1018, compiled_block_1_1018 );
  twobit_load( 1, 5 );
  twobit_pop( 5 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1016, compiled_block_1_1016 );
  twobit_load( 1, 5 );
  twobit_pop( 5 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1009, compiled_block_1_1009 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1007, compiled_block_1_1007 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1005, compiled_block_1_1005 );
  twobit_label( 1002, compiled_block_1_1002 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1031, compiled_block_1_1031 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1033, compiled_block_1_1033 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1035, compiled_block_1_1035 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1037, compiled_block_1_1037 ); /* internal:branchf-pair? */
  twobit_save( 9 );
  twobit_store( 0, 0 );
  twobit_store( 1, 9 );
  twobit_store( 2, 2 );
  twobit_store( 3, 4 );
  twobit_store( 4, 3 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 1 );
  twobit_movereg( 31, 1 );
  twobit_global( 1 ); /* ex:identifier? */
  twobit_setrtn( 1038, compiled_block_1_1038 );
  twobit_invoke( 1 );
  twobit_label( 1038, compiled_block_1_1038 );
  twobit_load( 0, 0 );
  twobit_branchf( 1040, compiled_block_1_1040 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1041, compiled_block_1_1041 );
  twobit_invoke( 5 );
  twobit_label( 1041, compiled_block_1_1041 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* ex:free-identifier=? */
  twobit_setrtn( 1042, compiled_block_1_1042 );
  twobit_invoke( 2 );
  twobit_label( 1042, compiled_block_1_1042 );
  twobit_load( 0, 0 );
  twobit_skip( 1039, compiled_block_1_1039 );
  twobit_label( 1040, compiled_block_1_1040 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1039, compiled_block_1_1039 );
  twobit_branchf( 1044, compiled_block_1_1044 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1046, compiled_block_1_1046 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1048, compiled_block_1_1048 ); /* internal:branchf-null? */
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1050, compiled_block_1_1050 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1052, compiled_block_1_1052 ); /* internal:branchf-null? */
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1053, compiled_block_1_1053 );
  twobit_invoke( 5 );
  twobit_label( 1053, compiled_block_1_1053 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1054, compiled_block_1_1054 );
  twobit_invoke( 5 );
  twobit_label( 1054, compiled_block_1_1054 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1055, compiled_block_1_1055 );
  twobit_invoke( 5 );
  twobit_label( 1055, compiled_block_1_1055 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1056, compiled_block_1_1056 );
  twobit_invoke( 5 );
  twobit_label( 1056, compiled_block_1_1056 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1057, compiled_block_1_1057 );
  twobit_invoke( 5 );
  twobit_label( 1057, compiled_block_1_1057 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 4 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 4 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1058, compiled_block_1_1058 );
  twobit_invoke( 5 );
  twobit_label( 1058, compiled_block_1_1058 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 9 );
  twobit_return();
  twobit_label( 1052, compiled_block_1_1052 );
  twobit_load( 1, 9 );
  twobit_global( 16 ); /* ex:invalid-form */
  twobit_pop( 9 );
  twobit_invoke( 1 );
  twobit_label( 1050, compiled_block_1_1050 );
  twobit_load( 1, 9 );
  twobit_global( 16 ); /* ex:invalid-form */
  twobit_pop( 9 );
  twobit_invoke( 1 );
  twobit_label( 1048, compiled_block_1_1048 );
  twobit_load( 1, 9 );
  twobit_global( 16 ); /* ex:invalid-form */
  twobit_pop( 9 );
  twobit_invoke( 1 );
  twobit_label( 1046, compiled_block_1_1046 );
  twobit_load( 1, 9 );
  twobit_global( 16 ); /* ex:invalid-form */
  twobit_pop( 9 );
  twobit_invoke( 1 );
  twobit_label( 1044, compiled_block_1_1044 );
  twobit_load( 1, 9 );
  twobit_global( 16 ); /* ex:invalid-form */
  twobit_pop( 9 );
  twobit_invoke( 1 );
  twobit_label( 1037, compiled_block_1_1037 );
  twobit_global( 16 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1035, compiled_block_1_1035 );
  twobit_global( 16 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1033, compiled_block_1_1033 );
  twobit_global( 16 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1031, compiled_block_1_1031 );
  twobit_global( 16 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_26( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1073, compiled_block_1_1073 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1075, compiled_block_1_1075 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1077, compiled_block_1_1077 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1079, compiled_block_1_1079 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_branchf_611( 1081, compiled_block_1_1081 ); /* internal:branchf-pair? */
  twobit_save( 24 );
  twobit_store( 0, 0 );
  twobit_store( 1, 24 );
  twobit_store( 2, 5 );
  twobit_store( 3, 15 );
  twobit_store( 4, 3 );
  twobit_store( 31, 2 );
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_store( 30, 1 );
  twobit_movereg( 30, 1 );
  twobit_global( 1 ); /* ex:identifier? */
  twobit_setrtn( 1082, compiled_block_1_1082 );
  twobit_invoke( 1 );
  twobit_label( 1082, compiled_block_1_1082 );
  twobit_load( 0, 0 );
  twobit_branchf( 1084, compiled_block_1_1084 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1085, compiled_block_1_1085 );
  twobit_invoke( 5 );
  twobit_label( 1085, compiled_block_1_1085 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* ex:free-identifier=? */
  twobit_setrtn( 1086, compiled_block_1_1086 );
  twobit_invoke( 2 );
  twobit_label( 1086, compiled_block_1_1086 );
  twobit_load( 0, 0 );
  twobit_skip( 1083, compiled_block_1_1083 );
  twobit_label( 1084, compiled_block_1_1084 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1083, compiled_block_1_1083 );
  twobit_branchf( 1088, compiled_block_1_1088 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1090, compiled_block_1_1090 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1092, compiled_block_1_1092 ); /* internal:branchf-null? */
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1094, compiled_block_1_1094 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 4 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1096, compiled_block_1_1096 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 6 );
  twobit_global( 7 ); /* list? */
  twobit_setrtn( 1097, compiled_block_1_1097 );
  twobit_invoke( 1 );
  twobit_label( 1097, compiled_block_1_1097 );
  twobit_load( 0, 0 );
  twobit_branchf( 1099, compiled_block_1_1099 );
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1101, compiled_block_1_1101 ); /* internal:branchf-null? */
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1102, compiled_block_1_1102 );
  twobit_invoke( 5 );
  twobit_label( 1102, compiled_block_1_1102 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 23 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1103, compiled_block_1_1103 );
  twobit_invoke( 5 );
  twobit_label( 1103, compiled_block_1_1103 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1104, compiled_block_1_1104 );
  twobit_invoke( 5 );
  twobit_label( 1104, compiled_block_1_1104 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 22 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1105, compiled_block_1_1105 );
  twobit_invoke( 5 );
  twobit_label( 1105, compiled_block_1_1105 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 21 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1106, compiled_block_1_1106 );
  twobit_invoke( 5 );
  twobit_label( 1106, compiled_block_1_1106 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 20 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1107, compiled_block_1_1107 );
  twobit_invoke( 5 );
  twobit_label( 1107, compiled_block_1_1107 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 19 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1108, compiled_block_1_1108 );
  twobit_invoke( 5 );
  twobit_label( 1108, compiled_block_1_1108 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 18 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1109, compiled_block_1_1109 );
  twobit_invoke( 5 );
  twobit_label( 1109, compiled_block_1_1109 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 17 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1110, compiled_block_1_1110 );
  twobit_invoke( 5 );
  twobit_label( 1110, compiled_block_1_1110 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 16 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1111, compiled_block_1_1111 );
  twobit_invoke( 5 );
  twobit_label( 1111, compiled_block_1_1111 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 17 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1112, compiled_block_1_1112 );
  twobit_invoke( 5 );
  twobit_label( 1112, compiled_block_1_1112 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 14 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1113, compiled_block_1_1113 );
  twobit_invoke( 5 );
  twobit_label( 1113, compiled_block_1_1113 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 18 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1114, compiled_block_1_1114 );
  twobit_invoke( 5 );
  twobit_label( 1114, compiled_block_1_1114 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 13 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1115, compiled_block_1_1115 );
  twobit_invoke( 5 );
  twobit_label( 1115, compiled_block_1_1115 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1116, compiled_block_1_1116 );
  twobit_invoke( 5 );
  twobit_label( 1116, compiled_block_1_1116 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1117, compiled_block_1_1117 );
  twobit_invoke( 5 );
  twobit_label( 1117, compiled_block_1_1117 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_load( 1, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_setrtn( 1118, compiled_block_1_1118 );
  twobit_branch( 1070, compiled_block_1_1070 );
  twobit_label( 1118, compiled_block_1_1118 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_const( 20 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1119, compiled_block_1_1119 );
  twobit_invoke( 5 );
  twobit_label( 1119, compiled_block_1_1119 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 21 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1120, compiled_block_1_1120 );
  twobit_invoke( 5 );
  twobit_label( 1120, compiled_block_1_1120 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1121, compiled_block_1_1121 );
  twobit_invoke( 5 );
  twobit_label( 1121, compiled_block_1_1121 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 22 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1122, compiled_block_1_1122 );
  twobit_invoke( 5 );
  twobit_label( 1122, compiled_block_1_1122 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 8 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1123, compiled_block_1_1123 );
  twobit_invoke( 5 );
  twobit_label( 1123, compiled_block_1_1123 );
  twobit_load( 0, 0 );
  twobit_load( 3, 8 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1124, compiled_block_1_1124 );
  twobit_invoke( 5 );
  twobit_label( 1124, compiled_block_1_1124 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 23 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1125, compiled_block_1_1125 );
  twobit_invoke( 5 );
  twobit_label( 1125, compiled_block_1_1125 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 17 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1126, compiled_block_1_1126 );
  twobit_invoke( 5 );
  twobit_label( 1126, compiled_block_1_1126 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1127, compiled_block_1_1127 );
  twobit_invoke( 5 );
  twobit_label( 1127, compiled_block_1_1127 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 18 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1128, compiled_block_1_1128 );
  twobit_invoke( 5 );
  twobit_label( 1128, compiled_block_1_1128 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_const( 24 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1129, compiled_block_1_1129 );
  twobit_invoke( 5 );
  twobit_label( 1129, compiled_block_1_1129 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 24 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1130, compiled_block_1_1130 );
  twobit_invoke( 5 );
  twobit_label( 1130, compiled_block_1_1130 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 25 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1131, compiled_block_1_1131 );
  twobit_invoke( 5 );
  twobit_label( 1131, compiled_block_1_1131 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1132, compiled_block_1_1132 );
  twobit_invoke( 5 );
  twobit_label( 1132, compiled_block_1_1132 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 24 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1133, compiled_block_1_1133 );
  twobit_invoke( 5 );
  twobit_label( 1133, compiled_block_1_1133 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_load( 1, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_setrtn( 1134, compiled_block_1_1134 );
  twobit_branch( 1069, compiled_block_1_1069 );
  twobit_label( 1134, compiled_block_1_1134 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 8 );
  twobit_const( 25 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1135, compiled_block_1_1135 );
  twobit_invoke( 5 );
  twobit_label( 1135, compiled_block_1_1135 );
  twobit_load( 0, 0 );
  twobit_load( 3, 8 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1136, compiled_block_1_1136 );
  twobit_invoke( 5 );
  twobit_label( 1136, compiled_block_1_1136 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 18 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1137, compiled_block_1_1137 );
  twobit_invoke( 5 );
  twobit_label( 1137, compiled_block_1_1137 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1138, compiled_block_1_1138 );
  twobit_invoke( 5 );
  twobit_label( 1138, compiled_block_1_1138 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 13 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 14 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 15 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 16 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 17 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1139, compiled_block_1_1139 );
  twobit_invoke( 5 );
  twobit_label( 1139, compiled_block_1_1139 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1140, compiled_block_1_1140 );
  twobit_invoke( 5 );
  twobit_label( 1140, compiled_block_1_1140 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_const( 26 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1141, compiled_block_1_1141 );
  twobit_invoke( 5 );
  twobit_label( 1141, compiled_block_1_1141 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 17 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1142, compiled_block_1_1142 );
  twobit_invoke( 5 );
  twobit_label( 1142, compiled_block_1_1142 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 17 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 13 );
  twobit_const( 24 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1143, compiled_block_1_1143 );
  twobit_invoke( 5 );
  twobit_label( 1143, compiled_block_1_1143 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 14 );
  twobit_const( 25 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1144, compiled_block_1_1144 );
  twobit_invoke( 5 );
  twobit_label( 1144, compiled_block_1_1144 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 16 );
  twobit_const( 27 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1145, compiled_block_1_1145 );
  twobit_invoke( 5 );
  twobit_label( 1145, compiled_block_1_1145 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 17 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 2 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1146, compiled_block_1_1146 );
  twobit_invoke( 5 );
  twobit_label( 1146, compiled_block_1_1146 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 15 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 17 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 16 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 16 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1147, compiled_block_1_1147 );
  twobit_invoke( 5 );
  twobit_label( 1147, compiled_block_1_1147 );
  twobit_load( 0, 0 );
  twobit_load( 3, 16 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 15 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 16 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1148, compiled_block_1_1148 );
  twobit_invoke( 5 );
  twobit_label( 1148, compiled_block_1_1148 );
  twobit_load( 0, 0 );
  twobit_load( 3, 16 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 17 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1149, compiled_block_1_1149 );
  twobit_invoke( 5 );
  twobit_label( 1149, compiled_block_1_1149 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 17 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 15 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 14 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 13 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 18 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 19 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 20 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 21 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 22 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 23 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 24 );
  twobit_return();
  twobit_label( 1101, compiled_block_1_1101 );
  twobit_load( 1, 24 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_pop( 24 );
  twobit_invoke( 1 );
  twobit_label( 1099, compiled_block_1_1099 );
  twobit_load( 1, 24 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_pop( 24 );
  twobit_invoke( 1 );
  twobit_label( 1096, compiled_block_1_1096 );
  twobit_load( 1, 24 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_pop( 24 );
  twobit_invoke( 1 );
  twobit_label( 1094, compiled_block_1_1094 );
  twobit_load( 1, 24 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_pop( 24 );
  twobit_invoke( 1 );
  twobit_label( 1092, compiled_block_1_1092 );
  twobit_load( 1, 24 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_pop( 24 );
  twobit_invoke( 1 );
  twobit_label( 1090, compiled_block_1_1090 );
  twobit_load( 1, 24 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_pop( 24 );
  twobit_invoke( 1 );
  twobit_label( 1088, compiled_block_1_1088 );
  twobit_load( 1, 24 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_pop( 24 );
  twobit_invoke( 1 );
  twobit_label( 1081, compiled_block_1_1081 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1079, compiled_block_1_1079 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1077, compiled_block_1_1077 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1075, compiled_block_1_1075 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1073, compiled_block_1_1073 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1069, compiled_block_1_1069 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1163, compiled_block_1_1163 ); /* internal:branchf-null? */
  twobit_movereg( 2, 1 );
  twobit_global( 29 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1163, compiled_block_1_1163 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 2, 5 );
  twobit_reg_op1_check_652(reg(1),1165,compiled_block_1_1165); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 24 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1166, compiled_block_1_1166 );
  twobit_invoke( 5 );
  twobit_label( 1166, compiled_block_1_1166 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 1 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_const( 25 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1167, compiled_block_1_1167 );
  twobit_invoke( 5 );
  twobit_label( 1167, compiled_block_1_1167 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_load( 3, 1 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_pop( 5 );
  twobit_branch( 1069, compiled_block_1_1069 );
  twobit_label( 1070, compiled_block_1_1070 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1170, compiled_block_1_1170 ); /* internal:branchf-null? */
  twobit_movereg( 2, 1 );
  twobit_global( 29 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1170, compiled_block_1_1170 );
  twobit_reg_op1_check_652(reg(1),1172,compiled_block_1_1172); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_branch( 1070, compiled_block_1_1070 );
  twobit_label( 1165, compiled_block_1_1165 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_label( 1172, compiled_block_1_1172 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_27( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1186, compiled_block_1_1186 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1188, compiled_block_1_1188 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1190, compiled_block_1_1190 ); /* internal:branchf-pair? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 3, 3 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /* ex:identifier? */
  twobit_setrtn( 1191, compiled_block_1_1191 );
  twobit_invoke( 1 );
  twobit_label( 1191, compiled_block_1_1191 );
  twobit_load( 0, 0 );
  twobit_branchf( 1193, compiled_block_1_1193 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1194, compiled_block_1_1194 );
  twobit_invoke( 5 );
  twobit_label( 1194, compiled_block_1_1194 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* ex:free-identifier=? */
  twobit_setrtn( 1195, compiled_block_1_1195 );
  twobit_invoke( 2 );
  twobit_label( 1195, compiled_block_1_1195 );
  twobit_load( 0, 0 );
  twobit_skip( 1192, compiled_block_1_1192 );
  twobit_label( 1193, compiled_block_1_1193 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1192, compiled_block_1_1192 );
  twobit_branchf( 1197, compiled_block_1_1197 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1199, compiled_block_1_1199 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1201, compiled_block_1_1201 ); /* internal:branchf-null? */
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1202, compiled_block_1_1202 );
  twobit_invoke( 5 );
  twobit_label( 1202, compiled_block_1_1202 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1203, compiled_block_1_1203 );
  twobit_invoke( 5 );
  twobit_label( 1203, compiled_block_1_1203 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1204, compiled_block_1_1204 );
  twobit_invoke( 5 );
  twobit_label( 1204, compiled_block_1_1204 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1205, compiled_block_1_1205 );
  twobit_invoke( 5 );
  twobit_label( 1205, compiled_block_1_1205 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1201, compiled_block_1_1201 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1183, compiled_block_1_1183 );
  twobit_label( 1199, compiled_block_1_1199 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1183, compiled_block_1_1183 );
  twobit_label( 1197, compiled_block_1_1197 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1183, compiled_block_1_1183 );
  twobit_label( 1190, compiled_block_1_1190 );
  twobit_branch( 1183, compiled_block_1_1183 );
  twobit_label( 1188, compiled_block_1_1188 );
  twobit_branch( 1183, compiled_block_1_1183 );
  twobit_label( 1186, compiled_block_1_1186 );
  twobit_branch( 1183, compiled_block_1_1183 );
  twobit_label( 1175, compiled_block_1_1175 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1213, compiled_block_1_1213 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1215, compiled_block_1_1215 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1217, compiled_block_1_1217 ); /* internal:branchf-pair? */
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 5 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_movereg( 4, 1 );
  twobit_global( 10 ); /* list? */
  twobit_setrtn( 1218, compiled_block_1_1218 );
  twobit_invoke( 1 );
  twobit_label( 1218, compiled_block_1_1218 );
  twobit_load( 0, 0 );
  twobit_branchf( 1220, compiled_block_1_1220 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1221, compiled_block_1_1221 );
  twobit_invoke( 5 );
  twobit_label( 1221, compiled_block_1_1221 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1222, compiled_block_1_1222 );
  twobit_invoke( 5 );
  twobit_label( 1222, compiled_block_1_1222 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1220, compiled_block_1_1220 );
  twobit_load( 1, 5 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 1217, compiled_block_1_1217 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1215, compiled_block_1_1215 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1213, compiled_block_1_1213 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1176, compiled_block_1_1176 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1228, compiled_block_1_1228 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1230, compiled_block_1_1230 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1232, compiled_block_1_1232 ); /* internal:branchf-pair? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 3, 2 );
  twobit_store( 4, 3 );
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /* ex:identifier? */
  twobit_setrtn( 1233, compiled_block_1_1233 );
  twobit_invoke( 1 );
  twobit_label( 1233, compiled_block_1_1233 );
  twobit_load( 0, 0 );
  twobit_branchf( 1235, compiled_block_1_1235 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1236, compiled_block_1_1236 );
  twobit_invoke( 5 );
  twobit_label( 1236, compiled_block_1_1236 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* ex:free-identifier=? */
  twobit_setrtn( 1237, compiled_block_1_1237 );
  twobit_invoke( 2 );
  twobit_label( 1237, compiled_block_1_1237 );
  twobit_load( 0, 0 );
  twobit_skip( 1234, compiled_block_1_1234 );
  twobit_label( 1235, compiled_block_1_1235 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1234, compiled_block_1_1234 );
  twobit_branchf( 1239, compiled_block_1_1239 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 10 ); /* list? */
  twobit_setrtn( 1240, compiled_block_1_1240 );
  twobit_invoke( 1 );
  twobit_label( 1240, compiled_block_1_1240 );
  twobit_load( 0, 0 );
  twobit_branchf( 1242, compiled_block_1_1242 );
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1244, compiled_block_1_1244 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_movereg( 4, 1 );
  twobit_global( 10 ); /* list? */
  twobit_setrtn( 1245, compiled_block_1_1245 );
  twobit_invoke( 1 );
  twobit_label( 1245, compiled_block_1_1245 );
  twobit_load( 0, 0 );
  twobit_branchf( 1247, compiled_block_1_1247 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1248, compiled_block_1_1248 );
  twobit_invoke( 5 );
  twobit_label( 1248, compiled_block_1_1248 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1249, compiled_block_1_1249 );
  twobit_invoke( 5 );
  twobit_label( 1249, compiled_block_1_1249 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 15 ); /* append */
  twobit_setrtn( 1250, compiled_block_1_1250 );
  twobit_invoke( 2 );
  twobit_label( 1250, compiled_block_1_1250 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1247, compiled_block_1_1247 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1175, compiled_block_1_1175 );
  twobit_label( 1244, compiled_block_1_1244 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1175, compiled_block_1_1175 );
  twobit_label( 1242, compiled_block_1_1242 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1175, compiled_block_1_1175 );
  twobit_label( 1239, compiled_block_1_1239 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1175, compiled_block_1_1175 );
  twobit_label( 1232, compiled_block_1_1232 );
  twobit_branch( 1175, compiled_block_1_1175 );
  twobit_label( 1230, compiled_block_1_1230 );
  twobit_branch( 1175, compiled_block_1_1175 );
  twobit_label( 1228, compiled_block_1_1228 );
  twobit_branch( 1175, compiled_block_1_1175 );
  twobit_label( 1177, compiled_block_1_1177 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1259, compiled_block_1_1259 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1261, compiled_block_1_1261 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1263, compiled_block_1_1263 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1265, compiled_block_1_1265 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_branchf_611( 1267, compiled_block_1_1267 ); /* internal:branchf-pair? */
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 7 );
  twobit_store( 2, 5 );
  twobit_store( 3, 6 );
  twobit_store( 4, 3 );
  twobit_store( 31, 2 );
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_store( 30, 1 );
  twobit_movereg( 30, 1 );
  twobit_global( 1 ); /* ex:identifier? */
  twobit_setrtn( 1268, compiled_block_1_1268 );
  twobit_invoke( 1 );
  twobit_label( 1268, compiled_block_1_1268 );
  twobit_load( 0, 0 );
  twobit_branchf( 1270, compiled_block_1_1270 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1271, compiled_block_1_1271 );
  twobit_invoke( 5 );
  twobit_label( 1271, compiled_block_1_1271 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* ex:free-identifier=? */
  twobit_setrtn( 1272, compiled_block_1_1272 );
  twobit_invoke( 2 );
  twobit_label( 1272, compiled_block_1_1272 );
  twobit_load( 0, 0 );
  twobit_skip( 1269, compiled_block_1_1269 );
  twobit_label( 1270, compiled_block_1_1270 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1269, compiled_block_1_1269 );
  twobit_branchf( 1274, compiled_block_1_1274 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1276, compiled_block_1_1276 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1278, compiled_block_1_1278 ); /* internal:branchf-null? */
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1280, compiled_block_1_1280 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1282, compiled_block_1_1282 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_global( 10 ); /* list? */
  twobit_setrtn( 1283, compiled_block_1_1283 );
  twobit_invoke( 1 );
  twobit_label( 1283, compiled_block_1_1283 );
  twobit_load( 0, 0 );
  twobit_branchf( 1285, compiled_block_1_1285 );
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1287, compiled_block_1_1287 ); /* internal:branchf-null? */
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1288, compiled_block_1_1288 );
  twobit_invoke( 5 );
  twobit_label( 1288, compiled_block_1_1288 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 4 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 4 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1289, compiled_block_1_1289 );
  twobit_invoke( 5 );
  twobit_label( 1289, compiled_block_1_1289 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1287, compiled_block_1_1287 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1176, compiled_block_1_1176 );
  twobit_label( 1285, compiled_block_1_1285 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1176, compiled_block_1_1176 );
  twobit_label( 1282, compiled_block_1_1282 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1176, compiled_block_1_1176 );
  twobit_label( 1280, compiled_block_1_1280 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1176, compiled_block_1_1176 );
  twobit_label( 1278, compiled_block_1_1278 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1176, compiled_block_1_1176 );
  twobit_label( 1276, compiled_block_1_1276 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1176, compiled_block_1_1176 );
  twobit_label( 1274, compiled_block_1_1274 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1176, compiled_block_1_1176 );
  twobit_label( 1267, compiled_block_1_1267 );
  twobit_branch( 1176, compiled_block_1_1176 );
  twobit_label( 1265, compiled_block_1_1265 );
  twobit_branch( 1176, compiled_block_1_1176 );
  twobit_label( 1263, compiled_block_1_1263 );
  twobit_branch( 1176, compiled_block_1_1176 );
  twobit_label( 1261, compiled_block_1_1261 );
  twobit_branch( 1176, compiled_block_1_1176 );
  twobit_label( 1259, compiled_block_1_1259 );
  twobit_branch( 1176, compiled_block_1_1176 );
  twobit_label( 1178, compiled_block_1_1178 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1303, compiled_block_1_1303 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1305, compiled_block_1_1305 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1307, compiled_block_1_1307 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1309, compiled_block_1_1309 ); /* internal:branchf-pair? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 2, 4 );
  twobit_store( 3, 5 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 1 );
  twobit_movereg( 31, 1 );
  twobit_global( 1 ); /* ex:identifier? */
  twobit_setrtn( 1310, compiled_block_1_1310 );
  twobit_invoke( 1 );
  twobit_label( 1310, compiled_block_1_1310 );
  twobit_load( 0, 0 );
  twobit_branchf( 1312, compiled_block_1_1312 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 17 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1313, compiled_block_1_1313 );
  twobit_invoke( 5 );
  twobit_label( 1313, compiled_block_1_1313 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* ex:free-identifier=? */
  twobit_setrtn( 1314, compiled_block_1_1314 );
  twobit_invoke( 2 );
  twobit_label( 1314, compiled_block_1_1314 );
  twobit_load( 0, 0 );
  twobit_skip( 1311, compiled_block_1_1311 );
  twobit_label( 1312, compiled_block_1_1312 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1311, compiled_block_1_1311 );
  twobit_branchf( 1316, compiled_block_1_1316 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1318, compiled_block_1_1318 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1320, compiled_block_1_1320 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 10 ); /* list? */
  twobit_setrtn( 1321, compiled_block_1_1321 );
  twobit_invoke( 1 );
  twobit_label( 1321, compiled_block_1_1321 );
  twobit_load( 0, 0 );
  twobit_branchf( 1323, compiled_block_1_1323 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1325, compiled_block_1_1325 ); /* internal:branchf-null? */
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 17 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1326, compiled_block_1_1326 );
  twobit_invoke( 5 );
  twobit_label( 1326, compiled_block_1_1326 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 17 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1327, compiled_block_1_1327 );
  twobit_invoke( 5 );
  twobit_label( 1327, compiled_block_1_1327 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 17 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1328, compiled_block_1_1328 );
  twobit_invoke( 5 );
  twobit_label( 1328, compiled_block_1_1328 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1325, compiled_block_1_1325 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1177, compiled_block_1_1177 );
  twobit_label( 1323, compiled_block_1_1323 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1177, compiled_block_1_1177 );
  twobit_label( 1320, compiled_block_1_1320 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1177, compiled_block_1_1177 );
  twobit_label( 1318, compiled_block_1_1318 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1177, compiled_block_1_1177 );
  twobit_label( 1316, compiled_block_1_1316 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1177, compiled_block_1_1177 );
  twobit_label( 1309, compiled_block_1_1309 );
  twobit_branch( 1177, compiled_block_1_1177 );
  twobit_label( 1307, compiled_block_1_1307 );
  twobit_branch( 1177, compiled_block_1_1177 );
  twobit_label( 1305, compiled_block_1_1305 );
  twobit_branch( 1177, compiled_block_1_1177 );
  twobit_label( 1303, compiled_block_1_1303 );
  twobit_branch( 1177, compiled_block_1_1177 );
  twobit_label( 1179, compiled_block_1_1179 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1339, compiled_block_1_1339 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1341, compiled_block_1_1341 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1343, compiled_block_1_1343 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1345, compiled_block_1_1345 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_branchf_611( 1347, compiled_block_1_1347 ); /* internal:branchf-pair? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 2, 4 );
  twobit_store( 3, 5 );
  twobit_store( 4, 3 );
  twobit_store( 31, 2 );
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_store( 30, 1 );
  twobit_movereg( 30, 1 );
  twobit_global( 1 ); /* ex:identifier? */
  twobit_setrtn( 1348, compiled_block_1_1348 );
  twobit_invoke( 1 );
  twobit_label( 1348, compiled_block_1_1348 );
  twobit_load( 0, 0 );
  twobit_branchf( 1350, compiled_block_1_1350 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 18 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1351, compiled_block_1_1351 );
  twobit_invoke( 5 );
  twobit_label( 1351, compiled_block_1_1351 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* ex:free-identifier=? */
  twobit_setrtn( 1352, compiled_block_1_1352 );
  twobit_invoke( 2 );
  twobit_label( 1352, compiled_block_1_1352 );
  twobit_load( 0, 0 );
  twobit_skip( 1349, compiled_block_1_1349 );
  twobit_label( 1350, compiled_block_1_1350 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1349, compiled_block_1_1349 );
  twobit_branchf( 1354, compiled_block_1_1354 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1356, compiled_block_1_1356 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1358, compiled_block_1_1358 ); /* internal:branchf-null? */
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1360, compiled_block_1_1360 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1362, compiled_block_1_1362 ); /* internal:branchf-null? */
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 18 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1363, compiled_block_1_1363 );
  twobit_invoke( 5 );
  twobit_label( 1363, compiled_block_1_1363 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 1 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 18 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1364, compiled_block_1_1364 );
  twobit_invoke( 5 );
  twobit_label( 1364, compiled_block_1_1364 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1362, compiled_block_1_1362 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1178, compiled_block_1_1178 );
  twobit_label( 1360, compiled_block_1_1360 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1178, compiled_block_1_1178 );
  twobit_label( 1358, compiled_block_1_1358 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1178, compiled_block_1_1178 );
  twobit_label( 1356, compiled_block_1_1356 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1178, compiled_block_1_1178 );
  twobit_label( 1354, compiled_block_1_1354 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1178, compiled_block_1_1178 );
  twobit_label( 1347, compiled_block_1_1347 );
  twobit_branch( 1178, compiled_block_1_1178 );
  twobit_label( 1345, compiled_block_1_1345 );
  twobit_branch( 1178, compiled_block_1_1178 );
  twobit_label( 1343, compiled_block_1_1343 );
  twobit_branch( 1178, compiled_block_1_1178 );
  twobit_label( 1341, compiled_block_1_1341 );
  twobit_branch( 1178, compiled_block_1_1178 );
  twobit_label( 1339, compiled_block_1_1339 );
  twobit_branch( 1178, compiled_block_1_1178 );
  twobit_label( 1180, compiled_block_1_1180 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1376, compiled_block_1_1376 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1378, compiled_block_1_1378 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1380, compiled_block_1_1380 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1382, compiled_block_1_1382 ); /* internal:branchf-pair? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 2, 3 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 1 );
  twobit_movereg( 31, 1 );
  twobit_global( 1 ); /* ex:identifier? */
  twobit_setrtn( 1383, compiled_block_1_1383 );
  twobit_invoke( 1 );
  twobit_label( 1383, compiled_block_1_1383 );
  twobit_load( 0, 0 );
  twobit_branchf( 1385, compiled_block_1_1385 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 19 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1386, compiled_block_1_1386 );
  twobit_invoke( 5 );
  twobit_label( 1386, compiled_block_1_1386 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* ex:free-identifier=? */
  twobit_setrtn( 1387, compiled_block_1_1387 );
  twobit_invoke( 2 );
  twobit_label( 1387, compiled_block_1_1387 );
  twobit_load( 0, 0 );
  twobit_skip( 1384, compiled_block_1_1384 );
  twobit_label( 1385, compiled_block_1_1385 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1384, compiled_block_1_1384 );
  twobit_branchf( 1389, compiled_block_1_1389 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1391, compiled_block_1_1391 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1393, compiled_block_1_1393 ); /* internal:branchf-null? */
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 19 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1394, compiled_block_1_1394 );
  twobit_invoke( 5 );
  twobit_label( 1394, compiled_block_1_1394 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 19 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1395, compiled_block_1_1395 );
  twobit_invoke( 5 );
  twobit_label( 1395, compiled_block_1_1395 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 19 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1396, compiled_block_1_1396 );
  twobit_invoke( 5 );
  twobit_label( 1396, compiled_block_1_1396 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1393, compiled_block_1_1393 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1179, compiled_block_1_1179 );
  twobit_label( 1391, compiled_block_1_1391 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1179, compiled_block_1_1179 );
  twobit_label( 1389, compiled_block_1_1389 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1179, compiled_block_1_1179 );
  twobit_label( 1382, compiled_block_1_1382 );
  twobit_branch( 1179, compiled_block_1_1179 );
  twobit_label( 1380, compiled_block_1_1380 );
  twobit_branch( 1179, compiled_block_1_1179 );
  twobit_label( 1378, compiled_block_1_1378 );
  twobit_branch( 1179, compiled_block_1_1179 );
  twobit_label( 1376, compiled_block_1_1376 );
  twobit_branch( 1179, compiled_block_1_1179 );
  twobit_label( 1181, compiled_block_1_1181 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1405, compiled_block_1_1405 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1407, compiled_block_1_1407 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1409, compiled_block_1_1409 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1411, compiled_block_1_1411 ); /* internal:branchf-pair? */
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 7 );
  twobit_store( 2, 2 );
  twobit_store( 3, 5 );
  twobit_store( 4, 3 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 1 );
  twobit_movereg( 31, 1 );
  twobit_global( 1 ); /* ex:identifier? */
  twobit_setrtn( 1412, compiled_block_1_1412 );
  twobit_invoke( 1 );
  twobit_label( 1412, compiled_block_1_1412 );
  twobit_load( 0, 0 );
  twobit_branchf( 1414, compiled_block_1_1414 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 20 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1415, compiled_block_1_1415 );
  twobit_invoke( 5 );
  twobit_label( 1415, compiled_block_1_1415 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* ex:free-identifier=? */
  twobit_setrtn( 1416, compiled_block_1_1416 );
  twobit_invoke( 2 );
  twobit_label( 1416, compiled_block_1_1416 );
  twobit_load( 0, 0 );
  twobit_skip( 1413, compiled_block_1_1413 );
  twobit_label( 1414, compiled_block_1_1414 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1413, compiled_block_1_1413 );
  twobit_branchf( 1418, compiled_block_1_1418 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1420, compiled_block_1_1420 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1422, compiled_block_1_1422 ); /* internal:branchf-null? */
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1424, compiled_block_1_1424 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1426, compiled_block_1_1426 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_global( 10 ); /* list? */
  twobit_setrtn( 1427, compiled_block_1_1427 );
  twobit_invoke( 1 );
  twobit_label( 1427, compiled_block_1_1427 );
  twobit_load( 0, 0 );
  twobit_branchf( 1429, compiled_block_1_1429 );
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1431, compiled_block_1_1431 ); /* internal:branchf-null? */
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 20 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1432, compiled_block_1_1432 );
  twobit_invoke( 5 );
  twobit_label( 1432, compiled_block_1_1432 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 20 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1433, compiled_block_1_1433 );
  twobit_invoke( 5 );
  twobit_label( 1433, compiled_block_1_1433 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 4 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 4 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 20 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1434, compiled_block_1_1434 );
  twobit_invoke( 5 );
  twobit_label( 1434, compiled_block_1_1434 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1431, compiled_block_1_1431 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1180, compiled_block_1_1180 );
  twobit_label( 1429, compiled_block_1_1429 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1180, compiled_block_1_1180 );
  twobit_label( 1426, compiled_block_1_1426 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1180, compiled_block_1_1180 );
  twobit_label( 1424, compiled_block_1_1424 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1180, compiled_block_1_1180 );
  twobit_label( 1422, compiled_block_1_1422 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1180, compiled_block_1_1180 );
  twobit_label( 1420, compiled_block_1_1420 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1180, compiled_block_1_1180 );
  twobit_label( 1418, compiled_block_1_1418 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1180, compiled_block_1_1180 );
  twobit_label( 1411, compiled_block_1_1411 );
  twobit_branch( 1180, compiled_block_1_1180 );
  twobit_label( 1409, compiled_block_1_1409 );
  twobit_branch( 1180, compiled_block_1_1180 );
  twobit_label( 1407, compiled_block_1_1407 );
  twobit_branch( 1180, compiled_block_1_1180 );
  twobit_label( 1405, compiled_block_1_1405 );
  twobit_branch( 1180, compiled_block_1_1180 );
  twobit_label( 1182, compiled_block_1_1182 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1447, compiled_block_1_1447 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1449, compiled_block_1_1449 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1451, compiled_block_1_1451 ); /* internal:branchf-pair? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /* ex:identifier? */
  twobit_setrtn( 1452, compiled_block_1_1452 );
  twobit_invoke( 1 );
  twobit_label( 1452, compiled_block_1_1452 );
  twobit_load( 0, 0 );
  twobit_branchf( 1454, compiled_block_1_1454 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1455, compiled_block_1_1455 );
  twobit_invoke( 5 );
  twobit_label( 1455, compiled_block_1_1455 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* ex:free-identifier=? */
  twobit_setrtn( 1456, compiled_block_1_1456 );
  twobit_invoke( 2 );
  twobit_label( 1456, compiled_block_1_1456 );
  twobit_load( 0, 0 );
  twobit_skip( 1453, compiled_block_1_1453 );
  twobit_label( 1454, compiled_block_1_1454 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1453, compiled_block_1_1453 );
  twobit_branchf( 1458, compiled_block_1_1458 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1460, compiled_block_1_1460 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1462, compiled_block_1_1462 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 10 ); /* list? */
  twobit_setrtn( 1463, compiled_block_1_1463 );
  twobit_invoke( 1 );
  twobit_label( 1463, compiled_block_1_1463 );
  twobit_load( 0, 0 );
  twobit_branchf( 1465, compiled_block_1_1465 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1467, compiled_block_1_1467 ); /* internal:branchf-null? */
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1468, compiled_block_1_1468 );
  twobit_invoke( 5 );
  twobit_label( 1468, compiled_block_1_1468 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1469, compiled_block_1_1469 );
  twobit_invoke( 5 );
  twobit_label( 1469, compiled_block_1_1469 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1470, compiled_block_1_1470 );
  twobit_invoke( 5 );
  twobit_label( 1470, compiled_block_1_1470 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1471, compiled_block_1_1471 );
  twobit_invoke( 5 );
  twobit_label( 1471, compiled_block_1_1471 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1467, compiled_block_1_1467 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1181, compiled_block_1_1181 );
  twobit_label( 1465, compiled_block_1_1465 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1181, compiled_block_1_1181 );
  twobit_label( 1462, compiled_block_1_1462 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1181, compiled_block_1_1181 );
  twobit_label( 1460, compiled_block_1_1460 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1181, compiled_block_1_1181 );
  twobit_label( 1458, compiled_block_1_1458 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1181, compiled_block_1_1181 );
  twobit_label( 1451, compiled_block_1_1451 );
  twobit_branch( 1181, compiled_block_1_1181 );
  twobit_label( 1449, compiled_block_1_1449 );
  twobit_branch( 1181, compiled_block_1_1181 );
  twobit_label( 1447, compiled_block_1_1447 );
  twobit_branch( 1181, compiled_block_1_1181 );
  twobit_label( 1183, compiled_block_1_1183 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1481, compiled_block_1_1481 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1483, compiled_block_1_1483 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1485, compiled_block_1_1485 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1487, compiled_block_1_1487 ); /* internal:branchf-pair? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 2, 2 );
  twobit_store( 3, 4 );
  twobit_store( 4, 3 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 1 );
  twobit_movereg( 31, 1 );
  twobit_global( 1 ); /* ex:identifier? */
  twobit_setrtn( 1488, compiled_block_1_1488 );
  twobit_invoke( 1 );
  twobit_label( 1488, compiled_block_1_1488 );
  twobit_load( 0, 0 );
  twobit_branchf( 1490, compiled_block_1_1490 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 22 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1491, compiled_block_1_1491 );
  twobit_invoke( 5 );
  twobit_label( 1491, compiled_block_1_1491 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* ex:free-identifier=? */
  twobit_setrtn( 1492, compiled_block_1_1492 );
  twobit_invoke( 2 );
  twobit_label( 1492, compiled_block_1_1492 );
  twobit_load( 0, 0 );
  twobit_skip( 1489, compiled_block_1_1489 );
  twobit_label( 1490, compiled_block_1_1490 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1489, compiled_block_1_1489 );
  twobit_branchf( 1494, compiled_block_1_1494 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1496, compiled_block_1_1496 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1498, compiled_block_1_1498 ); /* internal:branchf-null? */
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1500, compiled_block_1_1500 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1502, compiled_block_1_1502 ); /* internal:branchf-null? */
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 22 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1503, compiled_block_1_1503 );
  twobit_invoke( 5 );
  twobit_label( 1503, compiled_block_1_1503 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 22 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1504, compiled_block_1_1504 );
  twobit_invoke( 5 );
  twobit_label( 1504, compiled_block_1_1504 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 1 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 22 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1505, compiled_block_1_1505 );
  twobit_invoke( 5 );
  twobit_label( 1505, compiled_block_1_1505 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1502, compiled_block_1_1502 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1182, compiled_block_1_1182 );
  twobit_label( 1500, compiled_block_1_1500 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1182, compiled_block_1_1182 );
  twobit_label( 1498, compiled_block_1_1498 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1182, compiled_block_1_1182 );
  twobit_label( 1496, compiled_block_1_1496 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1182, compiled_block_1_1182 );
  twobit_label( 1494, compiled_block_1_1494 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1182, compiled_block_1_1182 );
  twobit_label( 1487, compiled_block_1_1487 );
  twobit_branch( 1182, compiled_block_1_1182 );
  twobit_label( 1485, compiled_block_1_1485 );
  twobit_branch( 1182, compiled_block_1_1182 );
  twobit_label( 1483, compiled_block_1_1483 );
  twobit_branch( 1182, compiled_block_1_1182 );
  twobit_label( 1481, compiled_block_1_1481 );
  twobit_branch( 1182, compiled_block_1_1182 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 2 ); /*  check:proc-ec~1ayXVW~37949 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 3 ); /*  check:proc~1ayXVW~37909 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 4 ); /*  check-passed?~1ayXVW~37908 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 5 ); /*  check-report~1ayXVW~37907 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 6 ); /*  check:report-failed~1ayXVW~37906 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 7 ); /*  check:report-correct~1ayXVW~37905 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 8 ); /*  check:report-actual-result~1ayXVW~37904 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 9 ); /*  check:report-expression~1ayXVW~37903 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 10 ); /*  ignored2~1ayXVW~37902 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 11 ); /*  check:add-failed!~1ayXVW~37901 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 12 ); /*  check:add-correct!~1ayXVW~37900 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 13 ); /*  check-reset!~1ayXVW~37899 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 14 ); /*  check:failed~1ayXVW~37898 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 15 ); /*  check:correct~1ayXVW~37897 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 16 ); /*  ignored1~1ayXVW~37896 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 17 ); /*  check-set-mode!~1ayXVW~37895 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 18 ); /*  check:mode~1ayXVW~37894 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 19 ); /*  check:mode:state~1ayXVW~37893 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 20 ); /*  check:write~1ayXVW~37892 */
  twobit_global( 21 ); /* write */
  twobit_setglbl( 20 ); /*  check:write~1ayXVW~37892 */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setglbl( 19 ); /*  check:mode:state~1ayXVW~37893 */
  twobit_lambda( compiled_start_1_4, 23, 0 );
  twobit_setglbl( 18 ); /*  check:mode~1ayXVW~37894 */
  twobit_lambda( compiled_start_1_5, 25, 0 );
  twobit_setglbl( 17 ); /*  check-set-mode!~1ayXVW~37895 */
  twobit_const( 26 );
  twobit_setreg( 1 );
  twobit_global( 17 ); /*  check-set-mode!~1ayXVW~37895 */
  twobit_setrtn( 1526, compiled_block_1_1526 );
  twobit_invoke( 1 );
  twobit_label( 1526, compiled_block_1_1526 );
  twobit_load( 0, 0 );
  twobit_setglbl( 16 ); /*  ignored1~1ayXVW~37896 */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setglbl( 15 ); /*  check:correct~1ayXVW~37897 */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setglbl( 14 ); /*  check:failed~1ayXVW~37898 */
  twobit_lambda( compiled_start_1_6, 28, 0 );
  twobit_setglbl( 13 ); /*  check-reset!~1ayXVW~37899 */
  twobit_lambda( compiled_start_1_7, 30, 0 );
  twobit_setglbl( 12 ); /*  check:add-correct!~1ayXVW~37900 */
  twobit_lambda( compiled_start_1_8, 32, 0 );
  twobit_setglbl( 11 ); /*  check:add-failed!~1ayXVW~37901 */
  twobit_global( 13 ); /*  check-reset!~1ayXVW~37899 */
  twobit_setrtn( 1527, compiled_block_1_1527 );
  twobit_invoke( 0 );
  twobit_label( 1527, compiled_block_1_1527 );
  twobit_load( 0, 0 );
  twobit_setglbl( 10 ); /*  ignored2~1ayXVW~37902 */
  twobit_lambda( compiled_start_1_9, 34, 0 );
  twobit_setglbl( 9 ); /*  check:report-expression~1ayXVW~37903 */
  twobit_lambda( compiled_start_1_10, 36, 0 );
  twobit_setglbl( 8 ); /*  check:report-actual-result~1ayXVW~37904 */
  twobit_lambda( compiled_start_1_11, 38, 0 );
  twobit_setglbl( 7 ); /*  check:report-correct~1ayXVW~37905 */
  twobit_lambda( compiled_start_1_12, 40, 0 );
  twobit_setglbl( 6 ); /*  check:report-failed~1ayXVW~37906 */
  twobit_lambda( compiled_start_1_13, 42, 0 );
  twobit_setglbl( 5 ); /*  check-report~1ayXVW~37907 */
  twobit_lambda( compiled_start_1_14, 44, 0 );
  twobit_setglbl( 4 ); /*  check-passed?~1ayXVW~37908 */
  twobit_lambda( compiled_start_1_15, 46, 0 );
  twobit_setglbl( 3 ); /*  check:proc~1ayXVW~37909 */
  twobit_lambda( compiled_start_1_16, 48, 0 );
  twobit_setglbl( 2 ); /*  check:proc-ec~1ayXVW~37949 */
  twobit_global( 49 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  check:mode:state~1ayXVW~37893 */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_const( 1 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 4, 1518, compiled_block_1_1518 ); /* internal:branchf-eq? */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_skip( 1517, compiled_block_1_1517 );
  twobit_label( 1518, compiled_block_1_1518 );
  twobit_const( 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 4, 1520, compiled_block_1_1520 ); /* internal:branchf-eq? */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_skip( 1517, compiled_block_1_1517 );
  twobit_label( 1520, compiled_block_1_1520 );
  twobit_const( 3 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 4, 1522, compiled_block_1_1522 ); /* internal:branchf-eq? */
  twobit_imm_const( fixnum(10) ); /* 10 */
  twobit_skip( 1517, compiled_block_1_1517 );
  twobit_label( 1522, compiled_block_1_1522 );
  twobit_const( 4 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 4, 1524, compiled_block_1_1524 ); /* internal:branchf-eq? */
  twobit_imm_const( fixnum(100) ); /* 100 */
  twobit_skip( 1517, compiled_block_1_1517 );
  twobit_label( 1524, compiled_block_1_1524 );
  twobit_movereg( 1, 2 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 1525, compiled_block_1_1525 );
  twobit_invoke( 2 );
  twobit_label( 1525, compiled_block_1_1525 );
  twobit_load( 0, 0 );
  twobit_label( 1517, compiled_block_1_1517 );
  twobit_setglbl( 7 ); /*  check:mode:state~1ayXVW~37893 */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_6( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setglbl( 1 ); /*  check:correct~1ayXVW~37897 */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setglbl( 2 ); /*  check:failed~1ayXVW~37898 */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_7( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  check:correct~1ayXVW~37897 */
  twobit_op2imm_130( fixnum(1), 24, compiled_temp_1_24 ); /* + */
  twobit_setglbl( 1 ); /*  check:correct~1ayXVW~37897 */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_8( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_global( 1 ); /*  check:failed~1ayXVW~37898 */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op2_58( 31 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_op2_58( 4 ); /* cons */
  twobit_setglbl( 1 ); /*  check:failed~1ayXVW~37898 */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_9( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* newline */
  twobit_setrtn( 1528, compiled_block_1_1528 );
  twobit_invoke( 0 );
  twobit_label( 1528, compiled_block_1_1528 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  check:write~1ayXVW~37892 */
  twobit_setrtn( 1529, compiled_block_1_1529 );
  twobit_invoke( 1 );
  twobit_label( 1529, compiled_block_1_1529 );
  twobit_load( 0, 0 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* display */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_10( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  check:write~1ayXVW~37892 */
  twobit_setrtn( 1531, compiled_block_1_1531 );
  twobit_invoke( 1 );
  twobit_label( 1531, compiled_block_1_1531 );
  twobit_load( 0, 0 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* display */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_11( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* display */
  twobit_setrtn( 1533, compiled_block_1_1533 );
  twobit_invoke( 1 );
  twobit_label( 1533, compiled_block_1_1533 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op2imm_branchf_639( fixnum(1), 23, compiled_temp_1_23, 1535, compiled_block_1_1535 ); /* internal:branchf-=/imm */
  twobit_op1_3(); /* unspecified */
  twobit_skip( 1534, compiled_block_1_1534 );
  twobit_label( 1535, compiled_block_1_1535 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* display */
  twobit_setrtn( 1536, compiled_block_1_1536 );
  twobit_invoke( 1 );
  twobit_label( 1536, compiled_block_1_1536 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* display */
  twobit_setrtn( 1537, compiled_block_1_1537 );
  twobit_invoke( 1 );
  twobit_label( 1537, compiled_block_1_1537 );
  twobit_load( 0, 0 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* display */
  twobit_setrtn( 1538, compiled_block_1_1538 );
  twobit_invoke( 1 );
  twobit_label( 1538, compiled_block_1_1538 );
  twobit_load( 0, 0 );
  twobit_label( 1534, compiled_block_1_1534 );
  twobit_global( 5 ); /* newline */
  twobit_pop( 1 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_12( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* display */
  twobit_setrtn( 1540, compiled_block_1_1540 );
  twobit_invoke( 1 );
  twobit_label( 1540, compiled_block_1_1540 );
  twobit_load( 0, 0 );
  twobit_global( 3 ); /* newline */
  twobit_setrtn( 1541, compiled_block_1_1541 );
  twobit_invoke( 0 );
  twobit_label( 1541, compiled_block_1_1541 );
  twobit_load( 0, 0 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* display */
  twobit_setrtn( 1542, compiled_block_1_1542 );
  twobit_invoke( 1 );
  twobit_label( 1542, compiled_block_1_1542 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /*  check:write~1ayXVW~37892 */
  twobit_setrtn( 1543, compiled_block_1_1543 );
  twobit_invoke( 1 );
  twobit_label( 1543, compiled_block_1_1543 );
  twobit_load( 0, 0 );
  twobit_global( 3 ); /* newline */
  twobit_pop( 1 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_13( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  check:mode~1ayXVW~37894 */
  twobit_setrtn( 1545, compiled_block_1_1545 );
  twobit_invoke( 0 );
  twobit_label( 1545, compiled_block_1_1545 );
  twobit_load( 0, 0 );
  twobit_op2imm_branchf_637( fixnum(1), 21, compiled_temp_1_21, 1547, compiled_block_1_1547 ); /* internal:branchf->=/imm */
  twobit_global( 2 ); /* newline */
  twobit_setrtn( 1548, compiled_block_1_1548 );
  twobit_invoke( 0 );
  twobit_label( 1548, compiled_block_1_1548 );
  twobit_load( 0, 0 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* display */
  twobit_setrtn( 1549, compiled_block_1_1549 );
  twobit_invoke( 1 );
  twobit_label( 1549, compiled_block_1_1549 );
  twobit_load( 0, 0 );
  twobit_global( 5 ); /*  check:correct~1ayXVW~37897 */
  twobit_setreg( 1 );
  twobit_global( 4 ); /* display */
  twobit_setrtn( 1550, compiled_block_1_1550 );
  twobit_invoke( 1 );
  twobit_label( 1550, compiled_block_1_1550 );
  twobit_load( 0, 0 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* display */
  twobit_setrtn( 1551, compiled_block_1_1551 );
  twobit_invoke( 1 );
  twobit_label( 1551, compiled_block_1_1551 );
  twobit_load( 0, 0 );
  twobit_global( 7 ); /*  check:failed~1ayXVW~37898 */
  twobit_setreg( 1 );
  twobit_global( 8 ); /* length */
  twobit_setrtn( 1552, compiled_block_1_1552 );
  twobit_invoke( 1 );
  twobit_label( 1552, compiled_block_1_1552 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* display */
  twobit_setrtn( 1553, compiled_block_1_1553 );
  twobit_invoke( 1 );
  twobit_label( 1553, compiled_block_1_1553 );
  twobit_load( 0, 0 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* display */
  twobit_setrtn( 1554, compiled_block_1_1554 );
  twobit_invoke( 1 );
  twobit_label( 1554, compiled_block_1_1554 );
  twobit_load( 0, 0 );
  twobit_global( 7 ); /*  check:failed~1ayXVW~37898 */
  twobit_op1_branchf_610( 1556, compiled_block_1_1556 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1555, compiled_block_1_1555 );
  twobit_label( 1556, compiled_block_1_1556 );
  twobit_global( 1 ); /*  check:mode~1ayXVW~37894 */
  twobit_setrtn( 1557, compiled_block_1_1557 );
  twobit_invoke( 0 );
  twobit_label( 1557, compiled_block_1_1557 );
  twobit_load( 0, 0 );
  twobit_op2imm_133( fixnum(1), 22, compiled_temp_1_22 ); /* <= */
  twobit_label( 1555, compiled_block_1_1555 );
  twobit_branchf( 1559, compiled_block_1_1559 );
  twobit_global( 2 ); /* newline */
  twobit_pop( 3 );
  twobit_invoke( 0 );
  twobit_label( 1559, compiled_block_1_1559 );
  twobit_global( 7 ); /*  check:failed~1ayXVW~37898 */
  twobit_setreg( 1 );
  twobit_global( 10 ); /* reverse */
  twobit_setrtn( 1561, compiled_block_1_1561 );
  twobit_invoke( 1 );
  twobit_label( 1561, compiled_block_1_1561 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1562,compiled_block_1_1562); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1562,compiled_block_1_1562); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1562,compiled_block_1_1562); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1562,compiled_block_1_1562); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* display */
  twobit_setrtn( 1563, compiled_block_1_1563 );
  twobit_invoke( 1 );
  twobit_label( 1563, compiled_block_1_1563 );
  twobit_load( 0, 0 );
  twobit_global( 2 ); /* newline */
  twobit_setrtn( 1564, compiled_block_1_1564 );
  twobit_invoke( 0 );
  twobit_label( 1564, compiled_block_1_1564 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 12 ); /*  check:report-expression~1ayXVW~37903 */
  twobit_setrtn( 1565, compiled_block_1_1565 );
  twobit_invoke( 1 );
  twobit_label( 1565, compiled_block_1_1565 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_global( 13 ); /*  check:report-actual-result~1ayXVW~37904 */
  twobit_setrtn( 1566, compiled_block_1_1566 );
  twobit_invoke( 1 );
  twobit_label( 1566, compiled_block_1_1566 );
  twobit_load( 0, 0 );
  twobit_load( 1, 3 );
  twobit_global( 14 ); /*  check:report-failed~1ayXVW~37906 */
  twobit_pop( 3 );
  twobit_invoke( 1 );
  twobit_label( 1547, compiled_block_1_1547 );
  twobit_op1_3(); /* unspecified */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1562, compiled_block_1_1562 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_14( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  check:failed~1ayXVW~37898 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /* length */
  twobit_setrtn( 1568, compiled_block_1_1568 );
  twobit_invoke( 1 );
  twobit_label( 1568, compiled_block_1_1568 );
  twobit_load( 0, 0 );
  twobit_op2imm_branchf_639( fixnum(0), 19, compiled_temp_1_19, 1570, compiled_block_1_1570 ); /* internal:branchf-=/imm */
  twobit_global( 3 ); /*  check:correct~1ayXVW~37897 */
  twobit_load( 3, 1 );
  twobit_op2_68( 3, 20, compiled_temp_1_20 ); /* = */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1570, compiled_block_1_1570 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_15( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 1 );
  twobit_store( 3, 3 );
  twobit_store( 4, 2 );
  twobit_global( 1 ); /*  check:mode~1ayXVW~37894 */
  twobit_setrtn( 1571, compiled_block_1_1571 );
  twobit_invoke( 0 );
  twobit_label( 1571, compiled_block_1_1571 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 1573, compiled_block_1_1573 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1572, compiled_block_1_1572 );
  twobit_label( 1573, compiled_block_1_1573 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1575, compiled_block_1_1575 ); /* internal:branchf-eq?/imm */
  twobit_stack( 1 );
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1576, compiled_block_1_1576 );
  twobit_invoke( 0 );
  twobit_label( 1576, compiled_block_1_1576 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 2, 2 );
  twobit_movereg( 4, 1 );
  twobit_stack( 3 );
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1577, compiled_block_1_1577 );
  twobit_invoke( 2 );
  twobit_label( 1577, compiled_block_1_1577 );
  twobit_load( 0, 0 );
  twobit_branchf( 1579, compiled_block_1_1579 );
  twobit_global( 2 ); /*  check:add-correct!~1ayXVW~37900 */
  twobit_setrtn( 1580, compiled_block_1_1580 );
  twobit_invoke( 0 );
  twobit_label( 1580, compiled_block_1_1580 );
  twobit_load( 0, 0 );
  twobit_skip( 1572, compiled_block_1_1572 );
  twobit_label( 1579, compiled_block_1_1579 );
  twobit_load( 3, 2 );
  twobit_load( 1, 4 );
  twobit_load( 2, 5 );
  twobit_global( 3 ); /*  check:add-failed!~1ayXVW~37901 */
  twobit_setrtn( 1581, compiled_block_1_1581 );
  twobit_invoke( 3 );
  twobit_label( 1581, compiled_block_1_1581 );
  twobit_load( 0, 0 );
  twobit_skip( 1572, compiled_block_1_1572 );
  twobit_label( 1575, compiled_block_1_1575 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(10), 1583, compiled_block_1_1583 ); /* internal:branchf-eq?/imm */
  twobit_stack( 1 );
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1584, compiled_block_1_1584 );
  twobit_invoke( 0 );
  twobit_label( 1584, compiled_block_1_1584 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 2, 2 );
  twobit_movereg( 4, 1 );
  twobit_stack( 3 );
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1585, compiled_block_1_1585 );
  twobit_invoke( 2 );
  twobit_label( 1585, compiled_block_1_1585 );
  twobit_load( 0, 0 );
  twobit_branchf( 1587, compiled_block_1_1587 );
  twobit_global( 2 ); /*  check:add-correct!~1ayXVW~37900 */
  twobit_setrtn( 1588, compiled_block_1_1588 );
  twobit_invoke( 0 );
  twobit_label( 1588, compiled_block_1_1588 );
  twobit_load( 0, 0 );
  twobit_skip( 1572, compiled_block_1_1572 );
  twobit_label( 1587, compiled_block_1_1587 );
  twobit_load( 1, 4 );
  twobit_global( 4 ); /*  check:report-expression~1ayXVW~37903 */
  twobit_setrtn( 1589, compiled_block_1_1589 );
  twobit_invoke( 1 );
  twobit_label( 1589, compiled_block_1_1589 );
  twobit_load( 0, 0 );
  twobit_load( 1, 5 );
  twobit_global( 5 ); /*  check:report-actual-result~1ayXVW~37904 */
  twobit_setrtn( 1590, compiled_block_1_1590 );
  twobit_invoke( 1 );
  twobit_label( 1590, compiled_block_1_1590 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /*  check:report-failed~1ayXVW~37906 */
  twobit_setrtn( 1591, compiled_block_1_1591 );
  twobit_invoke( 1 );
  twobit_label( 1591, compiled_block_1_1591 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_load( 1, 4 );
  twobit_load( 2, 5 );
  twobit_global( 3 ); /*  check:add-failed!~1ayXVW~37901 */
  twobit_setrtn( 1592, compiled_block_1_1592 );
  twobit_invoke( 3 );
  twobit_label( 1592, compiled_block_1_1592 );
  twobit_load( 0, 0 );
  twobit_skip( 1572, compiled_block_1_1572 );
  twobit_label( 1583, compiled_block_1_1583 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(100), 1594, compiled_block_1_1594 ); /* internal:branchf-eq?/imm */
  twobit_load( 1, 4 );
  twobit_global( 4 ); /*  check:report-expression~1ayXVW~37903 */
  twobit_setrtn( 1595, compiled_block_1_1595 );
  twobit_invoke( 1 );
  twobit_label( 1595, compiled_block_1_1595 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1596, compiled_block_1_1596 );
  twobit_invoke( 0 );
  twobit_label( 1596, compiled_block_1_1596 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /*  check:report-actual-result~1ayXVW~37904 */
  twobit_setrtn( 1597, compiled_block_1_1597 );
  twobit_invoke( 1 );
  twobit_label( 1597, compiled_block_1_1597 );
  twobit_load( 0, 0 );
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 5 );
  twobit_reg( 4 );
  twobit_setrtn( 1598, compiled_block_1_1598 );
  twobit_invoke( 2 );
  twobit_label( 1598, compiled_block_1_1598 );
  twobit_load( 0, 0 );
  twobit_branchf( 1600, compiled_block_1_1600 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_global( 7 ); /*  check:report-correct~1ayXVW~37905 */
  twobit_setrtn( 1601, compiled_block_1_1601 );
  twobit_invoke( 1 );
  twobit_label( 1601, compiled_block_1_1601 );
  twobit_load( 0, 0 );
  twobit_global( 2 ); /*  check:add-correct!~1ayXVW~37900 */
  twobit_setrtn( 1602, compiled_block_1_1602 );
  twobit_invoke( 0 );
  twobit_label( 1602, compiled_block_1_1602 );
  twobit_load( 0, 0 );
  twobit_skip( 1572, compiled_block_1_1572 );
  twobit_label( 1600, compiled_block_1_1600 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /*  check:report-failed~1ayXVW~37906 */
  twobit_setrtn( 1603, compiled_block_1_1603 );
  twobit_invoke( 1 );
  twobit_label( 1603, compiled_block_1_1603 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_load( 1, 4 );
  twobit_load( 2, 5 );
  twobit_global( 3 ); /*  check:add-failed!~1ayXVW~37901 */
  twobit_setrtn( 1604, compiled_block_1_1604 );
  twobit_invoke( 3 );
  twobit_label( 1604, compiled_block_1_1604 );
  twobit_load( 0, 0 );
  twobit_skip( 1572, compiled_block_1_1572 );
  twobit_label( 1594, compiled_block_1_1594 );
  twobit_global( 1 ); /*  check:mode~1ayXVW~37894 */
  twobit_setrtn( 1605, compiled_block_1_1605 );
  twobit_invoke( 0 );
  twobit_label( 1605, compiled_block_1_1605 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 1606, compiled_block_1_1606 );
  twobit_invoke( 2 );
  twobit_label( 1606, compiled_block_1_1606 );
  twobit_load( 0, 0 );
  twobit_label( 1572, compiled_block_1_1572 );
  twobit_op1_3(); /* unspecified */
  twobit_pop( 5 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_16( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op1_check_652(reg(1),1607,compiled_block_1_1607); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg_op1_check_652(reg(3),1608,compiled_block_1_1608); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg_op1_check_652(reg(3),1608,compiled_block_1_1608); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg_op1_check_652(reg(3),1608,compiled_block_1_1608); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg_op1_check_652(reg(3),1608,compiled_block_1_1608); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_branchf( 1610, compiled_block_1_1610 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_store( 3, 3 );
  twobit_global( 1 ); /*  check:mode~1ayXVW~37894 */
  twobit_setrtn( 1611, compiled_block_1_1611 );
  twobit_invoke( 0 );
  twobit_label( 1611, compiled_block_1_1611 );
  twobit_load( 0, 0 );
  twobit_op2imm_branchf_637( fixnum(100), 17, compiled_temp_1_17, 1613, compiled_block_1_1613 ); /* internal:branchf->=/imm */
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  check:report-expression~1ayXVW~37903 */
  twobit_setrtn( 1614, compiled_block_1_1614 );
  twobit_invoke( 1 );
  twobit_label( 1614, compiled_block_1_1614 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_global( 3 ); /*  check:report-actual-result~1ayXVW~37904 */
  twobit_setrtn( 1615, compiled_block_1_1615 );
  twobit_invoke( 1 );
  twobit_label( 1615, compiled_block_1_1615 );
  twobit_load( 0, 0 );
  twobit_load( 1, 3 );
  twobit_global( 4 ); /*  check:report-correct~1ayXVW~37905 */
  twobit_setrtn( 1616, compiled_block_1_1616 );
  twobit_invoke( 1 );
  twobit_label( 1616, compiled_block_1_1616 );
  twobit_load( 0, 0 );
  twobit_skip( 1612, compiled_block_1_1612 );
  twobit_label( 1613, compiled_block_1_1613 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 1612, compiled_block_1_1612 );
  twobit_global( 5 ); /*  check:add-correct!~1ayXVW~37900 */
  twobit_pop( 3 );
  twobit_invoke( 0 );
  twobit_label( 1610, compiled_block_1_1610 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_store( 31, 3 );
  twobit_global( 1 ); /*  check:mode~1ayXVW~37894 */
  twobit_setrtn( 1618, compiled_block_1_1618 );
  twobit_invoke( 0 );
  twobit_label( 1618, compiled_block_1_1618 );
  twobit_load( 0, 0 );
  twobit_op2imm_branchf_637( fixnum(10), 18, compiled_temp_1_18, 1620, compiled_block_1_1620 ); /* internal:branchf->=/imm */
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  check:report-expression~1ayXVW~37903 */
  twobit_setrtn( 1621, compiled_block_1_1621 );
  twobit_invoke( 1 );
  twobit_label( 1621, compiled_block_1_1621 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_global( 3 ); /*  check:report-actual-result~1ayXVW~37904 */
  twobit_setrtn( 1622, compiled_block_1_1622 );
  twobit_invoke( 1 );
  twobit_label( 1622, compiled_block_1_1622 );
  twobit_load( 0, 0 );
  twobit_load( 1, 3 );
  twobit_global( 6 ); /*  check:report-failed~1ayXVW~37906 */
  twobit_setrtn( 1623, compiled_block_1_1623 );
  twobit_invoke( 1 );
  twobit_label( 1623, compiled_block_1_1623 );
  twobit_load( 0, 0 );
  twobit_skip( 1619, compiled_block_1_1619 );
  twobit_label( 1620, compiled_block_1_1620 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 1619, compiled_block_1_1619 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_load( 3, 3 );
  twobit_global( 7 ); /*  check:add-failed!~1ayXVW~37901 */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1608, compiled_block_1_1608 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_label( 1607, compiled_block_1_1607 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_b4599c0099b338bbeed05a476a66a692_0(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_1_0(CONT_ACTUALS));
}
static RTYPE compiled_block_2_1004( CONT_PARAMS );
static RTYPE compiled_block_2_1003( CONT_PARAMS );
static RTYPE compiled_start_2_0( CONT_PARAMS );
static RTYPE compiled_start_2_3( CONT_PARAMS );
static RTYPE compiled_start_2_2( CONT_PARAMS );
static RTYPE compiled_start_2_1( CONT_PARAMS );

static RTYPE compiled_start_2_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_2_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_2_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1003, compiled_block_2_1003 );
  twobit_invoke( 8 );
  twobit_label( 1003, compiled_block_2_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1004, compiled_block_2_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_2_1004 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_b4599c0099b338bbeed05a476a66a692_1(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_2_0(CONT_ACTUALS));
}
codeptr_t CDECL twobit_load_table[] = { 
  twobit_thunk_b4599c0099b338bbeed05a476a66a692_0,
  twobit_thunk_b4599c0099b338bbeed05a476a66a692_1,
  0  /* The table may be empty; some compilers complain */
};

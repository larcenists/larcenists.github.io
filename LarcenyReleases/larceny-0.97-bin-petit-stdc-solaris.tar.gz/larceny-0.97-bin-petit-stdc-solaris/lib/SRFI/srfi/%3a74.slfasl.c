/* Generated from /proj/will/pnkfelix/larcenytest/larceny-petit-Nightly-2009-08-19/larceny_src/lib/SRFI/srfi/%3a74.slfasl */
#include "petit-instr.h"

static RTYPE compiled_block_1_1174( CONT_PARAMS );
static RTYPE compiled_block_1_1173( CONT_PARAMS );
static RTYPE compiled_start_1_0( CONT_PARAMS );
static RTYPE compiled_block_1_1171( CONT_PARAMS );
static RTYPE compiled_block_1_1170( CONT_PARAMS );
static RTYPE compiled_block_1_1161( CONT_PARAMS );
static RTYPE compiled_block_1_1160( CONT_PARAMS );
static RTYPE compiled_block_1_1143( CONT_PARAMS );
static RTYPE compiled_block_1_1142( CONT_PARAMS );
static RTYPE compiled_block_1_1141( CONT_PARAMS );
static RTYPE compiled_block_1_1140( CONT_PARAMS );
static RTYPE compiled_block_1_1139( CONT_PARAMS );
static RTYPE compiled_block_1_1138( CONT_PARAMS );
static RTYPE compiled_block_1_1137( CONT_PARAMS );
static RTYPE compiled_block_1_1136( CONT_PARAMS );
static RTYPE compiled_block_1_1135( CONT_PARAMS );
static RTYPE compiled_block_1_1134( CONT_PARAMS );
static RTYPE compiled_block_1_1133( CONT_PARAMS );
static RTYPE compiled_block_1_1132( CONT_PARAMS );
static RTYPE compiled_block_1_1131( CONT_PARAMS );
static RTYPE compiled_block_1_1130( CONT_PARAMS );
static RTYPE compiled_block_1_1129( CONT_PARAMS );
static RTYPE compiled_block_1_1128( CONT_PARAMS );
static RTYPE compiled_block_1_1127( CONT_PARAMS );
static RTYPE compiled_block_1_1126( CONT_PARAMS );
static RTYPE compiled_block_1_1125( CONT_PARAMS );
static RTYPE compiled_block_1_1124( CONT_PARAMS );
static RTYPE compiled_block_1_1123( CONT_PARAMS );
static RTYPE compiled_block_1_1122( CONT_PARAMS );
static RTYPE compiled_block_1_1121( CONT_PARAMS );
static RTYPE compiled_block_1_1120( CONT_PARAMS );
static RTYPE compiled_start_1_3( CONT_PARAMS );
static RTYPE compiled_start_1_32( CONT_PARAMS );
static RTYPE compiled_block_1_1163( CONT_PARAMS );
static RTYPE compiled_temp_1_34( CONT_PARAMS );
static RTYPE compiled_block_1_1162( CONT_PARAMS );
static RTYPE compiled_start_1_33( CONT_PARAMS );
static RTYPE compiled_block_1_1166( CONT_PARAMS );
static RTYPE compiled_temp_1_36( CONT_PARAMS );
static RTYPE compiled_block_1_1167( CONT_PARAMS );
static RTYPE compiled_block_1_1165( CONT_PARAMS );
static RTYPE compiled_start_1_35( CONT_PARAMS );
static RTYPE compiled_start_1_31( CONT_PARAMS );
static RTYPE compiled_block_1_1153( CONT_PARAMS );
static RTYPE compiled_start_1_37( CONT_PARAMS );
static RTYPE compiled_block_1_1157( CONT_PARAMS );
static RTYPE compiled_temp_1_40( CONT_PARAMS );
static RTYPE compiled_block_1_1155( CONT_PARAMS );
static RTYPE compiled_temp_1_39( CONT_PARAMS );
static RTYPE compiled_start_1_38( CONT_PARAMS );
static RTYPE compiled_block_1_1151( CONT_PARAMS );
static RTYPE compiled_start_1_30( CONT_PARAMS );
static RTYPE compiled_start_1_29( CONT_PARAMS );
static RTYPE compiled_block_1_1148( CONT_PARAMS );
static RTYPE compiled_start_1_28( CONT_PARAMS );
static RTYPE compiled_start_1_27( CONT_PARAMS );
static RTYPE compiled_start_1_26( CONT_PARAMS );
static RTYPE compiled_start_1_25( CONT_PARAMS );
static RTYPE compiled_start_1_24( CONT_PARAMS );
static RTYPE compiled_block_1_1118( CONT_PARAMS );
static RTYPE compiled_temp_1_42( CONT_PARAMS );
static RTYPE compiled_temp_1_41( CONT_PARAMS );
static RTYPE compiled_start_1_23( CONT_PARAMS );
static RTYPE compiled_start_1_22( CONT_PARAMS );
static RTYPE compiled_block_1_1115( CONT_PARAMS );
static RTYPE compiled_start_1_43( CONT_PARAMS );
static RTYPE compiled_start_1_21( CONT_PARAMS );
static RTYPE compiled_block_1_1113( CONT_PARAMS );
static RTYPE compiled_start_1_44( CONT_PARAMS );
static RTYPE compiled_start_1_20( CONT_PARAMS );
static RTYPE compiled_start_1_45( CONT_PARAMS );
static RTYPE compiled_start_1_19( CONT_PARAMS );
static RTYPE compiled_start_1_46( CONT_PARAMS );
static RTYPE compiled_block_1_1104( CONT_PARAMS );
static RTYPE compiled_block_1_1109( CONT_PARAMS );
static RTYPE compiled_block_1_1105( CONT_PARAMS );
static RTYPE compiled_block_1_1107( CONT_PARAMS );
static RTYPE compiled_temp_1_48( CONT_PARAMS );
static RTYPE compiled_temp_1_47( CONT_PARAMS );
static RTYPE compiled_start_1_18( CONT_PARAMS );
static RTYPE compiled_temp_1_52( CONT_PARAMS );
static RTYPE compiled_block_1_1108( CONT_PARAMS );
static RTYPE compiled_temp_1_51( CONT_PARAMS );
static RTYPE compiled_start_1_50( CONT_PARAMS );
static RTYPE compiled_temp_1_55( CONT_PARAMS );
static RTYPE compiled_block_1_1106( CONT_PARAMS );
static RTYPE compiled_temp_1_54( CONT_PARAMS );
static RTYPE compiled_temp_1_53( CONT_PARAMS );
static RTYPE compiled_start_1_49( CONT_PARAMS );
static RTYPE compiled_block_1_1102( CONT_PARAMS );
static RTYPE compiled_start_1_17( CONT_PARAMS );
static RTYPE compiled_temp_1_58( CONT_PARAMS );
static RTYPE compiled_block_1_1101( CONT_PARAMS );
static RTYPE compiled_temp_1_57( CONT_PARAMS );
static RTYPE compiled_start_1_56( CONT_PARAMS );
static RTYPE compiled_start_1_16( CONT_PARAMS );
static RTYPE compiled_start_1_59( CONT_PARAMS );
static RTYPE compiled_start_1_15( CONT_PARAMS );
static RTYPE compiled_start_1_60( CONT_PARAMS );
static RTYPE compiled_block_1_1092( CONT_PARAMS );
static RTYPE compiled_temp_1_66( CONT_PARAMS );
static RTYPE compiled_temp_1_65( CONT_PARAMS );
static RTYPE compiled_block_1_1095( CONT_PARAMS );
static RTYPE compiled_temp_1_63( CONT_PARAMS );
static RTYPE compiled_block_1_1090( CONT_PARAMS );
static RTYPE compiled_block_1_1088( CONT_PARAMS );
static RTYPE compiled_temp_1_62( CONT_PARAMS );
static RTYPE compiled_temp_1_61( CONT_PARAMS );
static RTYPE compiled_block_1_1089( CONT_PARAMS );
static RTYPE compiled_start_1_14( CONT_PARAMS );
static RTYPE compiled_temp_1_68( CONT_PARAMS );
static RTYPE compiled_block_1_1097( CONT_PARAMS );
static RTYPE compiled_block_1_1096( CONT_PARAMS );
static RTYPE compiled_start_1_67( CONT_PARAMS );
static RTYPE compiled_temp_1_70( CONT_PARAMS );
static RTYPE compiled_block_1_1094( CONT_PARAMS );
static RTYPE compiled_temp_1_69( CONT_PARAMS );
static RTYPE compiled_block_1_1093( CONT_PARAMS );
static RTYPE compiled_start_1_64( CONT_PARAMS );
static RTYPE compiled_start_1_13( CONT_PARAMS );
static RTYPE compiled_temp_1_72( CONT_PARAMS );
static RTYPE compiled_block_1_1086( CONT_PARAMS );
static RTYPE compiled_block_1_1085( CONT_PARAMS );
static RTYPE compiled_start_1_71( CONT_PARAMS );
static RTYPE compiled_temp_1_75( CONT_PARAMS );
static RTYPE compiled_temp_1_74( CONT_PARAMS );
static RTYPE compiled_block_1_1074( CONT_PARAMS );
static RTYPE compiled_start_1_12( CONT_PARAMS );
static RTYPE compiled_block_1_1082( CONT_PARAMS );
static RTYPE compiled_temp_1_78( CONT_PARAMS );
static RTYPE compiled_block_1_1081( CONT_PARAMS );
static RTYPE compiled_temp_1_77( CONT_PARAMS );
static RTYPE compiled_start_1_76( CONT_PARAMS );
static RTYPE compiled_block_1_1077( CONT_PARAMS );
static RTYPE compiled_temp_1_81( CONT_PARAMS );
static RTYPE compiled_temp_1_80( CONT_PARAMS );
static RTYPE compiled_block_1_1076( CONT_PARAMS );
static RTYPE compiled_temp_1_79( CONT_PARAMS );
static RTYPE compiled_start_1_73( CONT_PARAMS );
static RTYPE compiled_block_1_1072( CONT_PARAMS );
static RTYPE compiled_temp_1_83( CONT_PARAMS );
static RTYPE compiled_temp_1_82( CONT_PARAMS );
static RTYPE compiled_start_1_11( CONT_PARAMS );
static RTYPE compiled_block_1_1069( CONT_PARAMS );
static RTYPE compiled_start_1_10( CONT_PARAMS );
static RTYPE compiled_block_1_1068( CONT_PARAMS );
static RTYPE compiled_temp_1_85( CONT_PARAMS );
static RTYPE compiled_temp_1_84( CONT_PARAMS );
static RTYPE compiled_start_1_9( CONT_PARAMS );
static RTYPE compiled_block_1_1065( CONT_PARAMS );
static RTYPE compiled_start_1_8( CONT_PARAMS );
static RTYPE compiled_start_1_7( CONT_PARAMS );
static RTYPE compiled_start_1_6( CONT_PARAMS );
static RTYPE compiled_start_1_5( CONT_PARAMS );
static RTYPE compiled_start_1_4( CONT_PARAMS );
static RTYPE compiled_block_1_1059( CONT_PARAMS );
static RTYPE compiled_start_1_2( CONT_PARAMS );
static RTYPE compiled_block_1_1042( CONT_PARAMS );
static RTYPE compiled_block_1_1044( CONT_PARAMS );
static RTYPE compiled_block_1_1051( CONT_PARAMS );
static RTYPE compiled_block_1_1053( CONT_PARAMS );
static RTYPE compiled_block_1_1046( CONT_PARAMS );
static RTYPE compiled_block_1_1047( CONT_PARAMS );
static RTYPE compiled_block_1_1049( CONT_PARAMS );
static RTYPE compiled_block_1_1048( CONT_PARAMS );
static RTYPE compiled_block_1_1045( CONT_PARAMS );
static RTYPE compiled_block_1_1003( CONT_PARAMS );
static RTYPE compiled_block_1_1024( CONT_PARAMS );
static RTYPE compiled_block_1_1026( CONT_PARAMS );
static RTYPE compiled_block_1_1033( CONT_PARAMS );
static RTYPE compiled_block_1_1035( CONT_PARAMS );
static RTYPE compiled_block_1_1028( CONT_PARAMS );
static RTYPE compiled_block_1_1029( CONT_PARAMS );
static RTYPE compiled_block_1_1031( CONT_PARAMS );
static RTYPE compiled_block_1_1030( CONT_PARAMS );
static RTYPE compiled_block_1_1027( CONT_PARAMS );
static RTYPE compiled_block_1_1002( CONT_PARAMS );
static RTYPE compiled_block_1_1006( CONT_PARAMS );
static RTYPE compiled_block_1_1008( CONT_PARAMS );
static RTYPE compiled_block_1_1015( CONT_PARAMS );
static RTYPE compiled_block_1_1017( CONT_PARAMS );
static RTYPE compiled_block_1_1010( CONT_PARAMS );
static RTYPE compiled_block_1_1011( CONT_PARAMS );
static RTYPE compiled_block_1_1013( CONT_PARAMS );
static RTYPE compiled_block_1_1012( CONT_PARAMS );
static RTYPE compiled_block_1_1009( CONT_PARAMS );
static RTYPE compiled_start_1_86( CONT_PARAMS );
static RTYPE compiled_start_1_1( CONT_PARAMS );

static RTYPE compiled_start_1_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 2 ); /*  sint-list->blob~1ayXVW~37587 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 3 ); /*  uint-list->blob~1ayXVW~37586 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 4 ); /*  make-int-list->blob~1ayXVW~37585 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 5 ); /*  blob->sint-list~1ayXVW~37584 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 6 ); /*  blob->uint-list~1ayXVW~37583 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 7 ); /*  make-blob->int-list~1ayXVW~37582 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 8 ); /*  s8-list->blob~1ayXVW~37581 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 9 ); /*  u8-list->blob~1ayXVW~37580 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 10 ); /*  blob->s8-list~1ayXVW~37579 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 11 ); /*  blob->u8-list~1ayXVW~37578 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 12 ); /*  blob=?~1ayXVW~37577 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 13 ); /*  blob-copy~1ayXVW~37576 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 14 ); /*  blob-copy!~1ayXVW~37575 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 15 ); /*  blob-s64-native-set!~1ayXVW~37574 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 16 ); /*  blob-s64-native-ref~1ayXVW~37573 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 17 ); /*  blob-u64-native-set!~1ayXVW~37572 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 18 ); /*  blob-u64-native-ref~1ayXVW~37571 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 19 ); /*  blob-s64-set!~1ayXVW~37570 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 20 ); /*  blob-s64-ref~1ayXVW~37569 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 21 ); /*  blob-u64-set!~1ayXVW~37568 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 22 ); /*  blob-u64-ref~1ayXVW~37567 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 23 ); /*  blob-s32-native-set!~1ayXVW~37566 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 24 ); /*  blob-s32-native-ref~1ayXVW~37565 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 25 ); /*  blob-u32-native-set!~1ayXVW~37564 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 26 ); /*  blob-u32-native-ref~1ayXVW~37563 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 27 ); /*  blob-s32-set!~1ayXVW~37562 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 28 ); /*  blob-s32-ref~1ayXVW~37561 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 29 ); /*  blob-u32-set!~1ayXVW~37560 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 30 ); /*  blob-u32-ref~1ayXVW~37559 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 31 ); /*  blob-s16-native-set!~1ayXVW~37558 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 32 ); /*  blob-s16-native-ref~1ayXVW~37557 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 33 ); /*  blob-u16-native-set!~1ayXVW~37556 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 34 ); /*  blob-u16-native-ref~1ayXVW~37555 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 35 ); /*  blob-s16-set!~1ayXVW~37554 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 36 ); /*  blob-s16-ref~1ayXVW~37553 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 37 ); /*  blob-u16-set!~1ayXVW~37552 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 38 ); /*  blob-u16-ref~1ayXVW~37551 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 39 ); /*  ensure-aligned~1ayXVW~37550 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 40 ); /*  make-set!/native~1ayXVW~37549 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 41 ); /*  make-ref/native~1ayXVW~37548 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 42 ); /*  make-sint-set!~1ayXVW~37547 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 43 ); /*  make-uint-set!~1ayXVW~37546 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 44 ); /*  blob-sint-set!~1ayXVW~37545 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 45 ); /*  blob-uint-set!~1ayXVW~37544 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 46 ); /*  make-sint-ref~1ayXVW~37543 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 47 ); /*  make-uint-ref~1ayXVW~37542 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 48 ); /*  blob-sint-ref~1ayXVW~37541 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 49 ); /*  blob-uint-ref~1ayXVW~37540 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 50 ); /*  index-iterate~1ayXVW~37539 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 51 ); /*  s8->u8~1ayXVW~37538 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 52 ); /*  blob-s8-set!~1ayXVW~37537 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 53 ); /*  u8->s8~1ayXVW~37536 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 54 ); /*  blob-s8-ref~1ayXVW~37535 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 55 ); /*  blob-u8-set!~1ayXVW~37534 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 56 ); /*  blob-u8-ref~1ayXVW~37533 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 57 ); /*  blob-length~1ayXVW~37532 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 58 ); /*  make-blob~1ayXVW~37531 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 59 ); /*  blob?~1ayXVW~37530 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 60 ); /*  *endianness/big*~1ayXVW~37499 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 61 ); /*  *endianness/little*~1ayXVW~37498 */
  twobit_lambda( compiled_start_1_1, 63, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_2, 65, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_3, 67, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 68 );
  twobit_setreg( 1 );
  twobit_const( 69 );
  twobit_setreg( 3 );
  twobit_const( 70 );
  twobit_setreg( 4 );
  twobit_const( 71 );
  twobit_setreg( 5 );
  twobit_const( 72 );
  twobit_setreg( 8 );
  twobit_global( 73 ); /* ex:make-library */
  twobit_setrtn( 1173, compiled_block_1_1173 );
  twobit_invoke( 8 );
  twobit_label( 1173, compiled_block_1_1173 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 74 ); /* ex:register-library! */
  twobit_setrtn( 1174, compiled_block_1_1174 );
  twobit_invoke( 1 );
  twobit_label( 1174, compiled_block_1_1174 );
  twobit_load( 0, 0 );
  twobit_global( 75 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* ex:uncompress */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_86, 2, 0 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1059, compiled_block_1_1059 );
  twobit_invoke( 2 );
  twobit_label( 1059, compiled_block_1_1059 );
  twobit_load( 0, 0 );
  twobit_global( 5 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_86( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1006, compiled_block_1_1006 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1008, compiled_block_1_1008 ); /* internal:branchf-pair? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* ex:identifier? */
  twobit_setrtn( 1009, compiled_block_1_1009 );
  twobit_invoke( 1 );
  twobit_label( 1009, compiled_block_1_1009 );
  twobit_load( 0, 0 );
  twobit_branchf( 1011, compiled_block_1_1011 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1012, compiled_block_1_1012 );
  twobit_invoke( 5 );
  twobit_label( 1012, compiled_block_1_1012 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* ex:free-identifier=? */
  twobit_setrtn( 1013, compiled_block_1_1013 );
  twobit_invoke( 2 );
  twobit_label( 1013, compiled_block_1_1013 );
  twobit_load( 0, 0 );
  twobit_skip( 1010, compiled_block_1_1010 );
  twobit_label( 1011, compiled_block_1_1011 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1010, compiled_block_1_1010 );
  twobit_branchf( 1015, compiled_block_1_1015 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1017, compiled_block_1_1017 ); /* internal:branchf-null? */
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_pop( 3 );
  twobit_invoke( 5 );
  twobit_label( 1017, compiled_block_1_1017 );
  twobit_load( 1, 3 );
  twobit_pop( 3 );
  twobit_branch( 1003, compiled_block_1_1003 );
  twobit_label( 1015, compiled_block_1_1015 );
  twobit_load( 1, 3 );
  twobit_pop( 3 );
  twobit_branch( 1003, compiled_block_1_1003 );
  twobit_label( 1008, compiled_block_1_1008 );
  twobit_branch( 1003, compiled_block_1_1003 );
  twobit_label( 1006, compiled_block_1_1006 );
  twobit_branch( 1003, compiled_block_1_1003 );
  twobit_label( 1002, compiled_block_1_1002 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1024, compiled_block_1_1024 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1026, compiled_block_1_1026 ); /* internal:branchf-pair? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* ex:identifier? */
  twobit_setrtn( 1027, compiled_block_1_1027 );
  twobit_invoke( 1 );
  twobit_label( 1027, compiled_block_1_1027 );
  twobit_load( 0, 0 );
  twobit_branchf( 1029, compiled_block_1_1029 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1030, compiled_block_1_1030 );
  twobit_invoke( 5 );
  twobit_label( 1030, compiled_block_1_1030 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* ex:free-identifier=? */
  twobit_setrtn( 1031, compiled_block_1_1031 );
  twobit_invoke( 2 );
  twobit_label( 1031, compiled_block_1_1031 );
  twobit_load( 0, 0 );
  twobit_skip( 1028, compiled_block_1_1028 );
  twobit_label( 1029, compiled_block_1_1029 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1028, compiled_block_1_1028 );
  twobit_branchf( 1033, compiled_block_1_1033 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1035, compiled_block_1_1035 ); /* internal:branchf-null? */
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_pop( 3 );
  twobit_invoke( 5 );
  twobit_label( 1035, compiled_block_1_1035 );
  twobit_load( 1, 3 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_pop( 3 );
  twobit_invoke( 1 );
  twobit_label( 1033, compiled_block_1_1033 );
  twobit_load( 1, 3 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_pop( 3 );
  twobit_invoke( 1 );
  twobit_label( 1026, compiled_block_1_1026 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1024, compiled_block_1_1024 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1003, compiled_block_1_1003 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1042, compiled_block_1_1042 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1044, compiled_block_1_1044 ); /* internal:branchf-pair? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* ex:identifier? */
  twobit_setrtn( 1045, compiled_block_1_1045 );
  twobit_invoke( 1 );
  twobit_label( 1045, compiled_block_1_1045 );
  twobit_load( 0, 0 );
  twobit_branchf( 1047, compiled_block_1_1047 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 13 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1048, compiled_block_1_1048 );
  twobit_invoke( 5 );
  twobit_label( 1048, compiled_block_1_1048 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* ex:free-identifier=? */
  twobit_setrtn( 1049, compiled_block_1_1049 );
  twobit_invoke( 2 );
  twobit_label( 1049, compiled_block_1_1049 );
  twobit_load( 0, 0 );
  twobit_skip( 1046, compiled_block_1_1046 );
  twobit_label( 1047, compiled_block_1_1047 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1046, compiled_block_1_1046 );
  twobit_branchf( 1051, compiled_block_1_1051 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1053, compiled_block_1_1053 ); /* internal:branchf-null? */
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 13 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_pop( 3 );
  twobit_invoke( 5 );
  twobit_label( 1053, compiled_block_1_1053 );
  twobit_load( 1, 3 );
  twobit_pop( 3 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1051, compiled_block_1_1051 );
  twobit_load( 1, 3 );
  twobit_pop( 3 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1044, compiled_block_1_1044 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1042, compiled_block_1_1042 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 2 ); /*  sint-list->blob~1ayXVW~37587 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 3 ); /*  uint-list->blob~1ayXVW~37586 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 4 ); /*  make-int-list->blob~1ayXVW~37585 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 5 ); /*  blob->sint-list~1ayXVW~37584 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 6 ); /*  blob->uint-list~1ayXVW~37583 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 7 ); /*  make-blob->int-list~1ayXVW~37582 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 8 ); /*  s8-list->blob~1ayXVW~37581 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 9 ); /*  u8-list->blob~1ayXVW~37580 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 10 ); /*  blob->s8-list~1ayXVW~37579 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 11 ); /*  blob->u8-list~1ayXVW~37578 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 12 ); /*  blob=?~1ayXVW~37577 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 13 ); /*  blob-copy~1ayXVW~37576 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 14 ); /*  blob-copy!~1ayXVW~37575 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 15 ); /*  blob-s64-native-set!~1ayXVW~37574 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 16 ); /*  blob-s64-native-ref~1ayXVW~37573 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 17 ); /*  blob-u64-native-set!~1ayXVW~37572 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 18 ); /*  blob-u64-native-ref~1ayXVW~37571 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 19 ); /*  blob-s64-set!~1ayXVW~37570 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 20 ); /*  blob-s64-ref~1ayXVW~37569 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 21 ); /*  blob-u64-set!~1ayXVW~37568 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 22 ); /*  blob-u64-ref~1ayXVW~37567 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 23 ); /*  blob-s32-native-set!~1ayXVW~37566 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 24 ); /*  blob-s32-native-ref~1ayXVW~37565 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 25 ); /*  blob-u32-native-set!~1ayXVW~37564 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 26 ); /*  blob-u32-native-ref~1ayXVW~37563 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 27 ); /*  blob-s32-set!~1ayXVW~37562 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 28 ); /*  blob-s32-ref~1ayXVW~37561 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 29 ); /*  blob-u32-set!~1ayXVW~37560 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 30 ); /*  blob-u32-ref~1ayXVW~37559 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 31 ); /*  blob-s16-native-set!~1ayXVW~37558 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 32 ); /*  blob-s16-native-ref~1ayXVW~37557 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 33 ); /*  blob-u16-native-set!~1ayXVW~37556 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 34 ); /*  blob-u16-native-ref~1ayXVW~37555 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 35 ); /*  blob-s16-set!~1ayXVW~37554 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 36 ); /*  blob-s16-ref~1ayXVW~37553 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 37 ); /*  blob-u16-set!~1ayXVW~37552 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 38 ); /*  blob-u16-ref~1ayXVW~37551 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 39 ); /*  ensure-aligned~1ayXVW~37550 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 40 ); /*  make-set!/native~1ayXVW~37549 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 41 ); /*  make-ref/native~1ayXVW~37548 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 42 ); /*  make-sint-set!~1ayXVW~37547 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 43 ); /*  make-uint-set!~1ayXVW~37546 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 44 ); /*  blob-sint-set!~1ayXVW~37545 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 45 ); /*  blob-uint-set!~1ayXVW~37544 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 46 ); /*  make-sint-ref~1ayXVW~37543 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 47 ); /*  make-uint-ref~1ayXVW~37542 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 48 ); /*  blob-sint-ref~1ayXVW~37541 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 49 ); /*  blob-uint-ref~1ayXVW~37540 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 50 ); /*  index-iterate~1ayXVW~37539 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 51 ); /*  s8->u8~1ayXVW~37538 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 52 ); /*  blob-s8-set!~1ayXVW~37537 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 53 ); /*  u8->s8~1ayXVW~37536 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 54 ); /*  blob-s8-ref~1ayXVW~37535 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 55 ); /*  blob-u8-set!~1ayXVW~37534 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 56 ); /*  blob-u8-ref~1ayXVW~37533 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 57 ); /*  blob-length~1ayXVW~37532 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 58 ); /*  make-blob~1ayXVW~37531 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 59 ); /*  blob?~1ayXVW~37530 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 60 ); /*  *endianness/big*~1ayXVW~37499 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 61 ); /*  *endianness/little*~1ayXVW~37498 */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_const( 62 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setglbl( 63 ); /*  *endianness/little*~1ayXVW~37498 */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_const( 64 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setglbl( 65 ); /*  *endianness/big*~1ayXVW~37499 */
  twobit_global( 66 ); /* u8vector? */
  twobit_setglbl( 67 ); /*  blob?~1ayXVW~37530 */
  twobit_lambda( compiled_start_1_4, 69, 0 );
  twobit_setglbl( 70 ); /*  make-blob~1ayXVW~37531 */
  twobit_lambda( compiled_start_1_5, 72, 0 );
  twobit_setglbl( 73 ); /*  blob-length~1ayXVW~37532 */
  twobit_lambda( compiled_start_1_6, 75, 0 );
  twobit_setglbl( 76 ); /*  blob-u8-ref~1ayXVW~37533 */
  twobit_lambda( compiled_start_1_7, 78, 0 );
  twobit_setglbl( 79 ); /*  blob-u8-set!~1ayXVW~37534 */
  twobit_lambda( compiled_start_1_8, 81, 0 );
  twobit_setglbl( 82 ); /*  blob-s8-ref~1ayXVW~37535 */
  twobit_lambda( compiled_start_1_9, 84, 0 );
  twobit_setglbl( 85 ); /*  u8->s8~1ayXVW~37536 */
  twobit_lambda( compiled_start_1_10, 87, 0 );
  twobit_setglbl( 88 ); /*  blob-s8-set!~1ayXVW~37537 */
  twobit_lambda( compiled_start_1_11, 90, 0 );
  twobit_setglbl( 91 ); /*  s8->u8~1ayXVW~37538 */
  twobit_lambda( compiled_start_1_12, 93, 0 );
  twobit_setglbl( 94 ); /*  index-iterate~1ayXVW~37539 */
  twobit_lambda( compiled_start_1_13, 96, 0 );
  twobit_setglbl( 49 ); /*  blob-uint-ref~1ayXVW~37540 */
  twobit_lambda( compiled_start_1_14, 98, 0 );
  twobit_setglbl( 48 ); /*  blob-sint-ref~1ayXVW~37541 */
  twobit_lambda( compiled_start_1_15, 100, 0 );
  twobit_setglbl( 47 ); /*  make-uint-ref~1ayXVW~37542 */
  twobit_lambda( compiled_start_1_16, 102, 0 );
  twobit_setglbl( 46 ); /*  make-sint-ref~1ayXVW~37543 */
  twobit_lambda( compiled_start_1_17, 104, 0 );
  twobit_setglbl( 45 ); /*  blob-uint-set!~1ayXVW~37544 */
  twobit_lambda( compiled_start_1_18, 106, 0 );
  twobit_setglbl( 44 ); /*  blob-sint-set!~1ayXVW~37545 */
  twobit_lambda( compiled_start_1_19, 108, 0 );
  twobit_setglbl( 43 ); /*  make-uint-set!~1ayXVW~37546 */
  twobit_lambda( compiled_start_1_20, 110, 0 );
  twobit_setglbl( 42 ); /*  make-sint-set!~1ayXVW~37547 */
  twobit_lambda( compiled_start_1_21, 112, 0 );
  twobit_setglbl( 41 ); /*  make-ref/native~1ayXVW~37548 */
  twobit_lambda( compiled_start_1_22, 114, 0 );
  twobit_setglbl( 40 ); /*  make-set!/native~1ayXVW~37549 */
  twobit_lambda( compiled_start_1_23, 116, 0 );
  twobit_setglbl( 39 ); /*  ensure-aligned~1ayXVW~37550 */
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_global( 47 ); /*  make-uint-ref~1ayXVW~37542 */
  twobit_setrtn( 1120, compiled_block_1_1120 );
  twobit_invoke( 1 );
  twobit_label( 1120, compiled_block_1_1120 );
  twobit_load( 0, 0 );
  twobit_setglbl( 38 ); /*  blob-u16-ref~1ayXVW~37551 */
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_global( 43 ); /*  make-uint-set!~1ayXVW~37546 */
  twobit_setrtn( 1121, compiled_block_1_1121 );
  twobit_invoke( 1 );
  twobit_label( 1121, compiled_block_1_1121 );
  twobit_load( 0, 0 );
  twobit_setglbl( 37 ); /*  blob-u16-set!~1ayXVW~37552 */
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_global( 46 ); /*  make-sint-ref~1ayXVW~37543 */
  twobit_setrtn( 1122, compiled_block_1_1122 );
  twobit_invoke( 1 );
  twobit_label( 1122, compiled_block_1_1122 );
  twobit_load( 0, 0 );
  twobit_setglbl( 36 ); /*  blob-s16-ref~1ayXVW~37553 */
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_global( 42 ); /*  make-sint-set!~1ayXVW~37547 */
  twobit_setrtn( 1123, compiled_block_1_1123 );
  twobit_invoke( 1 );
  twobit_label( 1123, compiled_block_1_1123 );
  twobit_load( 0, 0 );
  twobit_setglbl( 35 ); /*  blob-s16-set!~1ayXVW~37554 */
  twobit_global( 38 ); /*  blob-u16-ref~1ayXVW~37551 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_global( 41 ); /*  make-ref/native~1ayXVW~37548 */
  twobit_setrtn( 1124, compiled_block_1_1124 );
  twobit_invoke( 2 );
  twobit_label( 1124, compiled_block_1_1124 );
  twobit_load( 0, 0 );
  twobit_setglbl( 34 ); /*  blob-u16-native-ref~1ayXVW~37555 */
  twobit_global( 37 ); /*  blob-u16-set!~1ayXVW~37552 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_global( 40 ); /*  make-set!/native~1ayXVW~37549 */
  twobit_setrtn( 1125, compiled_block_1_1125 );
  twobit_invoke( 2 );
  twobit_label( 1125, compiled_block_1_1125 );
  twobit_load( 0, 0 );
  twobit_setglbl( 33 ); /*  blob-u16-native-set!~1ayXVW~37556 */
  twobit_global( 36 ); /*  blob-s16-ref~1ayXVW~37553 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_global( 41 ); /*  make-ref/native~1ayXVW~37548 */
  twobit_setrtn( 1126, compiled_block_1_1126 );
  twobit_invoke( 2 );
  twobit_label( 1126, compiled_block_1_1126 );
  twobit_load( 0, 0 );
  twobit_setglbl( 32 ); /*  blob-s16-native-ref~1ayXVW~37557 */
  twobit_global( 35 ); /*  blob-s16-set!~1ayXVW~37554 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_global( 40 ); /*  make-set!/native~1ayXVW~37549 */
  twobit_setrtn( 1127, compiled_block_1_1127 );
  twobit_invoke( 2 );
  twobit_label( 1127, compiled_block_1_1127 );
  twobit_load( 0, 0 );
  twobit_setglbl( 31 ); /*  blob-s16-native-set!~1ayXVW~37558 */
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 1 );
  twobit_global( 47 ); /*  make-uint-ref~1ayXVW~37542 */
  twobit_setrtn( 1128, compiled_block_1_1128 );
  twobit_invoke( 1 );
  twobit_label( 1128, compiled_block_1_1128 );
  twobit_load( 0, 0 );
  twobit_setglbl( 30 ); /*  blob-u32-ref~1ayXVW~37559 */
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 1 );
  twobit_global( 43 ); /*  make-uint-set!~1ayXVW~37546 */
  twobit_setrtn( 1129, compiled_block_1_1129 );
  twobit_invoke( 1 );
  twobit_label( 1129, compiled_block_1_1129 );
  twobit_load( 0, 0 );
  twobit_setglbl( 29 ); /*  blob-u32-set!~1ayXVW~37560 */
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 1 );
  twobit_global( 46 ); /*  make-sint-ref~1ayXVW~37543 */
  twobit_setrtn( 1130, compiled_block_1_1130 );
  twobit_invoke( 1 );
  twobit_label( 1130, compiled_block_1_1130 );
  twobit_load( 0, 0 );
  twobit_setglbl( 28 ); /*  blob-s32-ref~1ayXVW~37561 */
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 1 );
  twobit_global( 42 ); /*  make-sint-set!~1ayXVW~37547 */
  twobit_setrtn( 1131, compiled_block_1_1131 );
  twobit_invoke( 1 );
  twobit_label( 1131, compiled_block_1_1131 );
  twobit_load( 0, 0 );
  twobit_setglbl( 27 ); /*  blob-s32-set!~1ayXVW~37562 */
  twobit_global( 30 ); /*  blob-u32-ref~1ayXVW~37559 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 1 );
  twobit_global( 41 ); /*  make-ref/native~1ayXVW~37548 */
  twobit_setrtn( 1132, compiled_block_1_1132 );
  twobit_invoke( 2 );
  twobit_label( 1132, compiled_block_1_1132 );
  twobit_load( 0, 0 );
  twobit_setglbl( 26 ); /*  blob-u32-native-ref~1ayXVW~37563 */
  twobit_global( 29 ); /*  blob-u32-set!~1ayXVW~37560 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 1 );
  twobit_global( 40 ); /*  make-set!/native~1ayXVW~37549 */
  twobit_setrtn( 1133, compiled_block_1_1133 );
  twobit_invoke( 2 );
  twobit_label( 1133, compiled_block_1_1133 );
  twobit_load( 0, 0 );
  twobit_setglbl( 25 ); /*  blob-u32-native-set!~1ayXVW~37564 */
  twobit_global( 28 ); /*  blob-s32-ref~1ayXVW~37561 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 1 );
  twobit_global( 41 ); /*  make-ref/native~1ayXVW~37548 */
  twobit_setrtn( 1134, compiled_block_1_1134 );
  twobit_invoke( 2 );
  twobit_label( 1134, compiled_block_1_1134 );
  twobit_load( 0, 0 );
  twobit_setglbl( 24 ); /*  blob-s32-native-ref~1ayXVW~37565 */
  twobit_global( 27 ); /*  blob-s32-set!~1ayXVW~37562 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 1 );
  twobit_global( 40 ); /*  make-set!/native~1ayXVW~37549 */
  twobit_setrtn( 1135, compiled_block_1_1135 );
  twobit_invoke( 2 );
  twobit_label( 1135, compiled_block_1_1135 );
  twobit_load( 0, 0 );
  twobit_setglbl( 23 ); /*  blob-s32-native-set!~1ayXVW~37566 */
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 1 );
  twobit_global( 47 ); /*  make-uint-ref~1ayXVW~37542 */
  twobit_setrtn( 1136, compiled_block_1_1136 );
  twobit_invoke( 1 );
  twobit_label( 1136, compiled_block_1_1136 );
  twobit_load( 0, 0 );
  twobit_setglbl( 22 ); /*  blob-u64-ref~1ayXVW~37567 */
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 1 );
  twobit_global( 43 ); /*  make-uint-set!~1ayXVW~37546 */
  twobit_setrtn( 1137, compiled_block_1_1137 );
  twobit_invoke( 1 );
  twobit_label( 1137, compiled_block_1_1137 );
  twobit_load( 0, 0 );
  twobit_setglbl( 21 ); /*  blob-u64-set!~1ayXVW~37568 */
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 1 );
  twobit_global( 46 ); /*  make-sint-ref~1ayXVW~37543 */
  twobit_setrtn( 1138, compiled_block_1_1138 );
  twobit_invoke( 1 );
  twobit_label( 1138, compiled_block_1_1138 );
  twobit_load( 0, 0 );
  twobit_setglbl( 20 ); /*  blob-s64-ref~1ayXVW~37569 */
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 1 );
  twobit_global( 42 ); /*  make-sint-set!~1ayXVW~37547 */
  twobit_setrtn( 1139, compiled_block_1_1139 );
  twobit_invoke( 1 );
  twobit_label( 1139, compiled_block_1_1139 );
  twobit_load( 0, 0 );
  twobit_setglbl( 19 ); /*  blob-s64-set!~1ayXVW~37570 */
  twobit_global( 22 ); /*  blob-u64-ref~1ayXVW~37567 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 1 );
  twobit_global( 41 ); /*  make-ref/native~1ayXVW~37548 */
  twobit_setrtn( 1140, compiled_block_1_1140 );
  twobit_invoke( 2 );
  twobit_label( 1140, compiled_block_1_1140 );
  twobit_load( 0, 0 );
  twobit_setglbl( 18 ); /*  blob-u64-native-ref~1ayXVW~37571 */
  twobit_global( 21 ); /*  blob-u64-set!~1ayXVW~37568 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 1 );
  twobit_global( 40 ); /*  make-set!/native~1ayXVW~37549 */
  twobit_setrtn( 1141, compiled_block_1_1141 );
  twobit_invoke( 2 );
  twobit_label( 1141, compiled_block_1_1141 );
  twobit_load( 0, 0 );
  twobit_setglbl( 17 ); /*  blob-u64-native-set!~1ayXVW~37572 */
  twobit_global( 20 ); /*  blob-s64-ref~1ayXVW~37569 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 1 );
  twobit_global( 41 ); /*  make-ref/native~1ayXVW~37548 */
  twobit_setrtn( 1142, compiled_block_1_1142 );
  twobit_invoke( 2 );
  twobit_label( 1142, compiled_block_1_1142 );
  twobit_load( 0, 0 );
  twobit_setglbl( 16 ); /*  blob-s64-native-ref~1ayXVW~37573 */
  twobit_global( 19 ); /*  blob-s64-set!~1ayXVW~37570 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 1 );
  twobit_global( 40 ); /*  make-set!/native~1ayXVW~37549 */
  twobit_setrtn( 1143, compiled_block_1_1143 );
  twobit_invoke( 2 );
  twobit_label( 1143, compiled_block_1_1143 );
  twobit_load( 0, 0 );
  twobit_setglbl( 15 ); /*  blob-s64-native-set!~1ayXVW~37574 */
  twobit_lambda( compiled_start_1_24, 118, 0 );
  twobit_setglbl( 14 ); /*  blob-copy!~1ayXVW~37575 */
  twobit_lambda( compiled_start_1_25, 120, 0 );
  twobit_setglbl( 13 ); /*  blob-copy~1ayXVW~37576 */
  twobit_lambda( compiled_start_1_26, 122, 0 );
  twobit_setglbl( 12 ); /*  blob=?~1ayXVW~37577 */
  twobit_lambda( compiled_start_1_27, 124, 0 );
  twobit_setglbl( 11 ); /*  blob->u8-list~1ayXVW~37578 */
  twobit_lambda( compiled_start_1_28, 126, 0 );
  twobit_setglbl( 10 ); /*  blob->s8-list~1ayXVW~37579 */
  twobit_lambda( compiled_start_1_29, 128, 0 );
  twobit_setglbl( 9 ); /*  u8-list->blob~1ayXVW~37580 */
  twobit_lambda( compiled_start_1_30, 130, 0 );
  twobit_setglbl( 8 ); /*  s8-list->blob~1ayXVW~37581 */
  twobit_lambda( compiled_start_1_31, 132, 0 );
  twobit_setglbl( 7 ); /*  make-blob->int-list~1ayXVW~37582 */
  twobit_global( 49 ); /*  blob-uint-ref~1ayXVW~37540 */
  twobit_setreg( 1 );
  twobit_global( 7 ); /*  make-blob->int-list~1ayXVW~37582 */
  twobit_setrtn( 1160, compiled_block_1_1160 );
  twobit_invoke( 1 );
  twobit_label( 1160, compiled_block_1_1160 );
  twobit_load( 0, 0 );
  twobit_setglbl( 6 ); /*  blob->uint-list~1ayXVW~37583 */
  twobit_global( 48 ); /*  blob-sint-ref~1ayXVW~37541 */
  twobit_setreg( 1 );
  twobit_global( 7 ); /*  make-blob->int-list~1ayXVW~37582 */
  twobit_setrtn( 1161, compiled_block_1_1161 );
  twobit_invoke( 1 );
  twobit_label( 1161, compiled_block_1_1161 );
  twobit_load( 0, 0 );
  twobit_setglbl( 5 ); /*  blob->sint-list~1ayXVW~37584 */
  twobit_lambda( compiled_start_1_32, 134, 0 );
  twobit_setglbl( 4 ); /*  make-int-list->blob~1ayXVW~37585 */
  twobit_global( 45 ); /*  blob-uint-set!~1ayXVW~37544 */
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  make-int-list->blob~1ayXVW~37585 */
  twobit_setrtn( 1170, compiled_block_1_1170 );
  twobit_invoke( 1 );
  twobit_label( 1170, compiled_block_1_1170 );
  twobit_load( 0, 0 );
  twobit_setglbl( 3 ); /*  uint-list->blob~1ayXVW~37586 */
  twobit_global( 44 ); /*  blob-sint-set!~1ayXVW~37545 */
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  make-int-list->blob~1ayXVW~37585 */
  twobit_setrtn( 1171, compiled_block_1_1171 );
  twobit_invoke( 1 );
  twobit_label( 1171, compiled_block_1_1171 );
  twobit_load( 0, 0 );
  twobit_setglbl( 2 ); /*  sint-list->blob~1ayXVW~37587 */
  twobit_global( 135 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* make-u8vector */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_global( 1 ); /* u8vector-length */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_6( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_global( 1 ); /* u8vector-ref */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_7( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_global( 1 ); /* u8vector-set! */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_8( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* u8vector-ref */
  twobit_setrtn( 1065, compiled_block_1_1065 );
  twobit_invoke( 2 );
  twobit_label( 1065, compiled_block_1_1065 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  u8->s8~1ayXVW~37536 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_9( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_636( fixnum(127), 84, compiled_temp_1_84, 1068, compiled_block_1_1068 ); /* internal:branchf->/imm */
  twobit_reg( 1 );
  twobit_op2imm_131( fixnum(256), 85, compiled_temp_1_85 ); /* - */
  twobit_return();
  twobit_label( 1068, compiled_block_1_1068 );
  twobit_reg( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_10( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /*  s8->u8~1ayXVW~37538 */
  twobit_setrtn( 1069, compiled_block_1_1069 );
  twobit_invoke( 1 );
  twobit_label( 1069, compiled_block_1_1069 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 2 ); /* u8vector-set! */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_11( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(0), 82, compiled_temp_1_82, 1072, compiled_block_1_1072 ); /* internal:branchf-</imm */
  twobit_reg( 1 );
  twobit_op2imm_130( fixnum(256), 83, compiled_temp_1_83 ); /* + */
  twobit_return();
  twobit_label( 1072, compiled_block_1_1072 );
  twobit_reg( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_12( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_reg( 3 );
  twobit_branchf( 1074, compiled_block_1_1074 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 4, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 5, 4 );
  twobit_lambda( compiled_start_1_73, 3, 4 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1074, compiled_block_1_1074 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op2_61( 2, 74, compiled_temp_1_74 ); /* + */
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_store( 2, 1 );
  twobit_reg( 3 );
  twobit_op2imm_131( fixnum(1), 75, compiled_temp_1_75 ); /* - */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 5, 2 );
  twobit_lambda( compiled_start_1_76, 5, 3 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_73( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_621( 4, 79, compiled_temp_1_79, 1076, compiled_block_1_1076 ); /* internal:branchf->= */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1076, compiled_block_1_1076 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op2imm_130( fixnum(1), 80, compiled_temp_1_80 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 1 );
  twobit_op2_61( 1, 81, compiled_temp_1_81 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 0, 4 );
  twobit_setrtn( 1077, compiled_block_1_1077 );
  twobit_invoke( 2 );
  twobit_label( 1077, compiled_block_1_1077 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_76( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 77, compiled_temp_1_77, 1081, compiled_block_1_1081 ); /* internal:branchf-< */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1081, compiled_block_1_1081 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op2imm_131( fixnum(1), 78, compiled_temp_1_78 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1082, compiled_block_1_1082 );
  twobit_invoke( 2 );
  twobit_label( 1082, compiled_block_1_1082 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_13( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 4, 1 );
  twobit_store( 1, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_71, 2, 1 );
  twobit_setreg( 4 );
  twobit_global( 3 ); /*  *endianness/big*~1ayXVW~37499 */
  twobit_op2_56( 2 ); /* eq? */
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 5 );
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_global( 4 ); /*  index-iterate~1ayXVW~37539 */
  twobit_pop( 2 );
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_71( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* u8vector-ref */
  twobit_setrtn( 1085, compiled_block_1_1085 );
  twobit_invoke( 2 );
  twobit_label( 1085, compiled_block_1_1085 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  arithmetic-shift~1ayXVW~28986 */
  twobit_setrtn( 1086, compiled_block_1_1086 );
  twobit_invoke( 2 );
  twobit_label( 1086, compiled_block_1_1086 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_61( 4, 72, compiled_temp_1_72 ); /* + */
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_14( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 3 );
  twobit_store( 3, 2 );
  twobit_store( 4, 1 );
  twobit_global( 1 ); /*  *endianness/big*~1ayXVW~37499 */
  twobit_setreg( 31 );
  twobit_reg( 2 );
  twobit_op2_branchf_624( 31, 1089, compiled_block_1_1089 ); /* internal:branchf-eq? */
  twobit_reg( 4 );
  twobit_skip( 1088, compiled_block_1_1088 );
  twobit_label( 1089, compiled_block_1_1089 );
  twobit_reg( 4 );
  twobit_op2_61( 1, 61, compiled_temp_1_61 ); /* + */
  twobit_op2imm_131( fixnum(1), 62, compiled_temp_1_62 ); /* - */
  twobit_label( 1088, compiled_block_1_1088 );
  twobit_setreg( 2 );
  twobit_movereg( 3, 1 );
  twobit_global( 2 ); /* u8vector-ref */
  twobit_setrtn( 1090, compiled_block_1_1090 );
  twobit_invoke( 2 );
  twobit_label( 1090, compiled_block_1_1090 );
  twobit_load( 0, 0 );
  twobit_op2imm_branchf_636( fixnum(127), 63, compiled_temp_1_63, 1092, compiled_block_1_1092 ); /* internal:branchf->/imm */
  twobit_load( 1, 1 );
  twobit_store( 1, 5 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_64, 4, 1 );
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  *endianness/big*~1ayXVW~37499 */
  twobit_load( 2, 3 );
  twobit_op2_56( 2 ); /* eq? */
  twobit_setreg( 3 );
  twobit_load( 2, 4 );
  twobit_movereg( 4, 5 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_global( 5 ); /*  index-iterate~1ayXVW~37539 */
  twobit_setrtn( 1095, compiled_block_1_1095 );
  twobit_invoke( 5 );
  twobit_label( 1095, compiled_block_1_1095 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 4, 65, compiled_temp_1_65 ); /* + */
  twobit_op1_32( 66, compiled_temp_1_66 ); /* -- */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1092, compiled_block_1_1092 );
  twobit_load( 1, 1 );
  twobit_store( 1, 5 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_67, 7, 1 );
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  *endianness/big*~1ayXVW~37499 */
  twobit_load( 2, 3 );
  twobit_op2_56( 2 ); /* eq? */
  twobit_setreg( 3 );
  twobit_load( 2, 4 );
  twobit_movereg( 4, 5 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_global( 5 ); /*  index-iterate~1ayXVW~37539 */
  twobit_pop( 5 );
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_64( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* u8vector-ref */
  twobit_setrtn( 1093, compiled_block_1_1093 );
  twobit_invoke( 2 );
  twobit_label( 1093, compiled_block_1_1093 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(255) ); /* 255 */
  twobit_op2_62( 4, 69, compiled_temp_1_69 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  arithmetic-shift~1ayXVW~28986 */
  twobit_setrtn( 1094, compiled_block_1_1094 );
  twobit_invoke( 2 );
  twobit_label( 1094, compiled_block_1_1094 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_61( 4, 70, compiled_temp_1_70 ); /* + */
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_67( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* u8vector-ref */
  twobit_setrtn( 1096, compiled_block_1_1096 );
  twobit_invoke( 2 );
  twobit_label( 1096, compiled_block_1_1096 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  arithmetic-shift~1ayXVW~28986 */
  twobit_setrtn( 1097, compiled_block_1_1097 );
  twobit_invoke( 2 );
  twobit_label( 1097, compiled_block_1_1097 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_61( 4, 68, compiled_temp_1_68 ); /* + */
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_15( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_60, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_60( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_load( 4, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  blob-uint-ref~1ayXVW~37540 */
  twobit_pop( 2 );
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_16( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_59, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_59( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_load( 4, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  blob-sint-ref~1ayXVW~37541 */
  twobit_pop( 2 );
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_17( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 4, 1 );
  twobit_movereg( 5, 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 1 );
  twobit_store( 1, 3 );
  twobit_global( 1 ); /*  *endianness/little*~1ayXVW~37498 */
  twobit_op2_56( 2 ); /* eq? */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_56, 3, 1 );
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_movereg( 4, 3 );
  twobit_load( 1, 3 );
  twobit_load( 4, 4 );
  twobit_load( 5, 2 );
  twobit_global( 4 ); /*  index-iterate~1ayXVW~37539 */
  twobit_setrtn( 1102, compiled_block_1_1102 );
  twobit_invoke( 5 );
  twobit_label( 1102, compiled_block_1_1102 );
  twobit_load( 0, 0 );
  twobit_global( 5 ); /* values */
  twobit_pop( 4 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_56( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_imm_const( fixnum(256) ); /* 256 */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_103( 4, 57, compiled_temp_1_57 ); /* remainder */
  twobit_setreg( 3 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* u8vector-set! */
  twobit_setrtn( 1101, compiled_block_1_1101 );
  twobit_invoke( 3 );
  twobit_label( 1101, compiled_block_1_1101 );
  twobit_load( 0, 0 );
  twobit_imm_const( fixnum(256) ); /* 256 */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_65( 4, 58, compiled_temp_1_58 ); /* quotient */
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_18( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 4, 4 );
  twobit_reg( 5 );
  twobit_op2imm_branchf_635( fixnum(0), 47, compiled_temp_1_47, 1105, compiled_block_1_1105 ); /* internal:branchf-</imm */
  twobit_movereg( 4, 1 );
  twobit_store( 1, 2 );
  twobit_global( 1 ); /*  *endianness/little*~1ayXVW~37498 */
  twobit_op2_56( 2 ); /* eq? */
  twobit_setreg( 31 );
  twobit_load( 2, 1 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_62( 5, 48, compiled_temp_1_48 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_49, 3, 1 );
  twobit_setreg( 4 );
  twobit_movereg( 31, 3 );
  twobit_movereg( 4, 5 );
  twobit_load( 1, 2 );
  twobit_load( 4, 3 );
  twobit_global( 4 ); /*  index-iterate~1ayXVW~37539 */
  twobit_setrtn( 1107, compiled_block_1_1107 );
  twobit_invoke( 5 );
  twobit_label( 1107, compiled_block_1_1107 );
  twobit_load( 0, 0 );
  twobit_skip( 1104, compiled_block_1_1104 );
  twobit_label( 1105, compiled_block_1_1105 );
  twobit_movereg( 5, 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 4 );
  twobit_store( 1, 3 );
  twobit_global( 1 ); /*  *endianness/little*~1ayXVW~37498 */
  twobit_op2_56( 2 ); /* eq? */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 2, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_50, 6, 1 );
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_movereg( 4, 5 );
  twobit_load( 1, 3 );
  twobit_load( 4, 5 );
  twobit_global( 4 ); /*  index-iterate~1ayXVW~37539 */
  twobit_setrtn( 1109, compiled_block_1_1109 );
  twobit_invoke( 5 );
  twobit_label( 1109, compiled_block_1_1109 );
  twobit_load( 0, 0 );
  twobit_label( 1104, compiled_block_1_1104 );
  twobit_global( 7 ); /* values */
  twobit_pop( 5 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_49( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_imm_const( fixnum(256) ); /* 256 */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_103( 4, 53, compiled_temp_1_53 ); /* remainder */
  twobit_setreg( 4 );
  twobit_movereg( 1, 2 );
  twobit_imm_const( fixnum(255) ); /* 255 */
  twobit_op2_62( 4, 54, compiled_temp_1_54 ); /* - */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* u8vector-set! */
  twobit_setrtn( 1106, compiled_block_1_1106 );
  twobit_invoke( 3 );
  twobit_label( 1106, compiled_block_1_1106 );
  twobit_load( 0, 0 );
  twobit_imm_const( fixnum(256) ); /* 256 */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_65( 4, 55, compiled_temp_1_55 ); /* quotient */
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_50( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_imm_const( fixnum(256) ); /* 256 */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_103( 4, 51, compiled_temp_1_51 ); /* remainder */
  twobit_setreg( 3 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* u8vector-set! */
  twobit_setrtn( 1108, compiled_block_1_1108 );
  twobit_invoke( 3 );
  twobit_label( 1108, compiled_block_1_1108 );
  twobit_load( 0, 0 );
  twobit_imm_const( fixnum(256) ); /* 256 */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_65( 4, 52, compiled_temp_1_52 ); /* quotient */
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_19( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_46, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_46( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_store( 4, 3 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_load( 4, 2 );
  twobit_stack( 3 );
  twobit_setreg( 1 );
  twobit_movereg( 1, 5 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  blob-uint-set!~1ayXVW~37544 */
  twobit_pop( 3 );
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_20( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_45, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_45( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_store( 4, 3 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_load( 4, 2 );
  twobit_stack( 3 );
  twobit_setreg( 1 );
  twobit_movereg( 1, 5 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  blob-sint-set!~1ayXVW~37545 */
  twobit_pop( 3 );
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_21( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lambda( compiled_start_1_44, 2, 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_44( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  ensure-aligned~1ayXVW~37550 */
  twobit_setrtn( 1113, compiled_block_1_1113 );
  twobit_invoke( 2 );
  twobit_label( 1113, compiled_block_1_1113 );
  twobit_load( 0, 0 );
  twobit_load( 2, 1 );
  twobit_load( 3, 2 );
  twobit_global( 2 ); /*  *endianness/big*~1ayXVW~37499 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_22( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lambda( compiled_start_1_43, 2, 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_43( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_movereg( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  ensure-aligned~1ayXVW~37550 */
  twobit_setrtn( 1115, compiled_block_1_1115 );
  twobit_invoke( 2 );
  twobit_label( 1115, compiled_block_1_1115 );
  twobit_load( 0, 0 );
  twobit_load( 2, 1 );
  twobit_load( 3, 2 );
  twobit_load( 4, 3 );
  twobit_global( 2 ); /*  *endianness/big*~1ayXVW~37499 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_pop( 3 );
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_23( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op2_103( 2, 41, compiled_temp_1_41 ); /* remainder */
  twobit_op1_branchf_612( 42, compiled_temp_1_42, 1118, compiled_block_1_1118 ); /* internal:branchf-zero? */
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1118, compiled_block_1_1118 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_24( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_global( 1 ); /* u8vector-copy! */
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_25( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_global( 1 ); /* u8vector-copy */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_26( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_global( 1 ); /* u8vector=? */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_27( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_global( 1 ); /* u8vector->list */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_28( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* u8vector->list */
  twobit_setrtn( 1148, compiled_block_1_1148 );
  twobit_invoke( 1 );
  twobit_label( 1148, compiled_block_1_1148 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  u8->s8~1ayXVW~37536 */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  map~1ayXVW~1381 */
  twobit_pop( 0 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_29( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_global( 1 ); /* list->u8vector */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_30( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /*  s8->u8~1ayXVW~37538 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  map~1ayXVW~1381 */
  twobit_setrtn( 1151, compiled_block_1_1151 );
  twobit_invoke( 2 );
  twobit_label( 1151, compiled_block_1_1151 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* list->u8vector */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_31( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_37, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_37( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /*  blob-length~1ayXVW~37532 */
  twobit_setrtn( 1153, compiled_block_1_1153 );
  twobit_invoke( 1 );
  twobit_label( 1153, compiled_block_1_1153 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 5, 1 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_38, 4, 5 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_38( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_621( 4, 39, compiled_temp_1_39, 1155, compiled_block_1_1155 ); /* internal:branchf->= */
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1155, compiled_block_1_1155 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_movereg( 1, 4 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op2_61( 3, 40, compiled_temp_1_40 ); /* + */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_setrtn( 1157, compiled_block_1_1157 );
  twobit_invoke( 4 );
  twobit_label( 1157, compiled_block_1_1157 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 3, 2 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_32( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_33, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_33( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 1162, compiled_block_1_1162 );
  twobit_invoke( 1 );
  twobit_label( 1162, compiled_block_1_1162 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_63( 4, 34, compiled_temp_1_34 ); /* * */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  make-blob~1ayXVW~37531 */
  twobit_setrtn( 1163, compiled_block_1_1163 );
  twobit_invoke( 1 );
  twobit_label( 1163, compiled_block_1_1163 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_35, 5, 4 );
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_35( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1165, compiled_block_1_1165 ); /* internal:branchf-null? */
  twobit_lexical( 0, 4 );
  twobit_return();
  twobit_label( 1165, compiled_block_1_1165 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 1, 4 );
  twobit_reg_op1_check_652(reg(2),1166,compiled_block_1_1166); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_movereg( 3, 5 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_setrtn( 1167, compiled_block_1_1167 );
  twobit_invoke( 5 );
  twobit_label( 1167, compiled_block_1_1167 );
  twobit_load( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_61( 4, 36, compiled_temp_1_36 ); /* + */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1166, compiled_block_1_1166 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_26c4d5644ebdb2e64bf6d4b413b13be0_0(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_1_0(CONT_ACTUALS));
}
static RTYPE compiled_block_2_1004( CONT_PARAMS );
static RTYPE compiled_block_2_1003( CONT_PARAMS );
static RTYPE compiled_start_2_0( CONT_PARAMS );
static RTYPE compiled_start_2_3( CONT_PARAMS );
static RTYPE compiled_start_2_2( CONT_PARAMS );
static RTYPE compiled_start_2_1( CONT_PARAMS );

static RTYPE compiled_start_2_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_2_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_2_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1003, compiled_block_2_1003 );
  twobit_invoke( 8 );
  twobit_label( 1003, compiled_block_2_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1004, compiled_block_2_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_2_1004 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_26c4d5644ebdb2e64bf6d4b413b13be0_1(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_2_0(CONT_ACTUALS));
}
codeptr_t CDECL twobit_load_table[] = { 
  twobit_thunk_26c4d5644ebdb2e64bf6d4b413b13be0_0,
  twobit_thunk_26c4d5644ebdb2e64bf6d4b413b13be0_1,
  0  /* The table may be empty; some compilers complain */
};

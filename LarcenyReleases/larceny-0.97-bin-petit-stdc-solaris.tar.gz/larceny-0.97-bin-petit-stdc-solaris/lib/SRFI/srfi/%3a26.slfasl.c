/* Generated from /proj/will/pnkfelix/larcenytest/larceny-petit-Nightly-2009-08-19/larceny_src/lib/SRFI/srfi/%3a26.slfasl */
#include "petit-instr.h"

static RTYPE compiled_block_1_1276( CONT_PARAMS );
static RTYPE compiled_block_1_1275( CONT_PARAMS );
static RTYPE compiled_start_1_0( CONT_PARAMS );
static RTYPE compiled_start_1_3( CONT_PARAMS );
static RTYPE compiled_block_1_1272( CONT_PARAMS );
static RTYPE compiled_block_1_1267( CONT_PARAMS );
static RTYPE compiled_block_1_1262( CONT_PARAMS );
static RTYPE compiled_block_1_1126( CONT_PARAMS );
static RTYPE compiled_start_1_2( CONT_PARAMS );
static RTYPE compiled_block_1_1269( CONT_PARAMS );
static RTYPE compiled_block_1_1270( CONT_PARAMS );
static RTYPE compiled_start_1_7( CONT_PARAMS );
static RTYPE compiled_block_1_1264( CONT_PARAMS );
static RTYPE compiled_block_1_1265( CONT_PARAMS );
static RTYPE compiled_start_1_6( CONT_PARAMS );
static RTYPE compiled_block_1_1219( CONT_PARAMS );
static RTYPE compiled_block_1_1221( CONT_PARAMS );
static RTYPE compiled_block_1_1224( CONT_PARAMS );
static RTYPE compiled_block_1_1226( CONT_PARAMS );
static RTYPE compiled_block_1_1228( CONT_PARAMS );
static RTYPE compiled_block_1_1230( CONT_PARAMS );
static RTYPE compiled_block_1_1233( CONT_PARAMS );
static RTYPE compiled_block_1_1235( CONT_PARAMS );
static RTYPE compiled_block_1_1242( CONT_PARAMS );
static RTYPE compiled_block_1_1244( CONT_PARAMS );
static RTYPE compiled_block_1_1251( CONT_PARAMS );
static RTYPE compiled_block_1_1250( CONT_PARAMS );
static RTYPE compiled_block_1_1249( CONT_PARAMS );
static RTYPE compiled_block_1_1248( CONT_PARAMS );
static RTYPE compiled_block_1_1247( CONT_PARAMS );
static RTYPE compiled_block_1_1246( CONT_PARAMS );
static RTYPE compiled_block_1_1245( CONT_PARAMS );
static RTYPE compiled_block_1_1237( CONT_PARAMS );
static RTYPE compiled_block_1_1238( CONT_PARAMS );
static RTYPE compiled_block_1_1240( CONT_PARAMS );
static RTYPE compiled_block_1_1239( CONT_PARAMS );
static RTYPE compiled_block_1_1236( CONT_PARAMS );
static RTYPE compiled_block_1_1231( CONT_PARAMS );
static RTYPE compiled_block_1_1222( CONT_PARAMS );
static RTYPE compiled_block_1_1129( CONT_PARAMS );
static RTYPE compiled_block_1_1183( CONT_PARAMS );
static RTYPE compiled_block_1_1185( CONT_PARAMS );
static RTYPE compiled_block_1_1188( CONT_PARAMS );
static RTYPE compiled_block_1_1190( CONT_PARAMS );
static RTYPE compiled_block_1_1192( CONT_PARAMS );
static RTYPE compiled_block_1_1195( CONT_PARAMS );
static RTYPE compiled_block_1_1197( CONT_PARAMS );
static RTYPE compiled_block_1_1204( CONT_PARAMS );
static RTYPE compiled_block_1_1209( CONT_PARAMS );
static RTYPE compiled_block_1_1208( CONT_PARAMS );
static RTYPE compiled_block_1_1207( CONT_PARAMS );
static RTYPE compiled_block_1_1206( CONT_PARAMS );
static RTYPE compiled_block_1_1205( CONT_PARAMS );
static RTYPE compiled_block_1_1199( CONT_PARAMS );
static RTYPE compiled_block_1_1200( CONT_PARAMS );
static RTYPE compiled_block_1_1202( CONT_PARAMS );
static RTYPE compiled_block_1_1201( CONT_PARAMS );
static RTYPE compiled_block_1_1198( CONT_PARAMS );
static RTYPE compiled_block_1_1193( CONT_PARAMS );
static RTYPE compiled_block_1_1186( CONT_PARAMS );
static RTYPE compiled_block_1_1128( CONT_PARAMS );
static RTYPE compiled_block_1_1160( CONT_PARAMS );
static RTYPE compiled_block_1_1162( CONT_PARAMS );
static RTYPE compiled_block_1_1164( CONT_PARAMS );
static RTYPE compiled_block_1_1166( CONT_PARAMS );
static RTYPE compiled_block_1_1169( CONT_PARAMS );
static RTYPE compiled_block_1_1171( CONT_PARAMS );
static RTYPE compiled_block_1_1175( CONT_PARAMS );
static RTYPE compiled_block_1_1174( CONT_PARAMS );
static RTYPE compiled_block_1_1173( CONT_PARAMS );
static RTYPE compiled_block_1_1172( CONT_PARAMS );
static RTYPE compiled_block_1_1167( CONT_PARAMS );
static RTYPE compiled_block_1_1127( CONT_PARAMS );
static RTYPE compiled_block_1_1132( CONT_PARAMS );
static RTYPE compiled_block_1_1134( CONT_PARAMS );
static RTYPE compiled_block_1_1137( CONT_PARAMS );
static RTYPE compiled_block_1_1139( CONT_PARAMS );
static RTYPE compiled_block_1_1141( CONT_PARAMS );
static RTYPE compiled_block_1_1143( CONT_PARAMS );
static RTYPE compiled_block_1_1146( CONT_PARAMS );
static RTYPE compiled_block_1_1148( CONT_PARAMS );
static RTYPE compiled_block_1_1150( CONT_PARAMS );
static RTYPE compiled_block_1_1149( CONT_PARAMS );
static RTYPE compiled_block_1_1144( CONT_PARAMS );
static RTYPE compiled_block_1_1135( CONT_PARAMS );
static RTYPE compiled_start_1_5( CONT_PARAMS );
static RTYPE compiled_block_1_1087( CONT_PARAMS );
static RTYPE compiled_block_1_1089( CONT_PARAMS );
static RTYPE compiled_block_1_1092( CONT_PARAMS );
static RTYPE compiled_block_1_1094( CONT_PARAMS );
static RTYPE compiled_block_1_1096( CONT_PARAMS );
static RTYPE compiled_block_1_1099( CONT_PARAMS );
static RTYPE compiled_block_1_1101( CONT_PARAMS );
static RTYPE compiled_block_1_1108( CONT_PARAMS );
static RTYPE compiled_block_1_1110( CONT_PARAMS );
static RTYPE compiled_block_1_1116( CONT_PARAMS );
static RTYPE compiled_block_1_1115( CONT_PARAMS );
static RTYPE compiled_block_1_1114( CONT_PARAMS );
static RTYPE compiled_block_1_1113( CONT_PARAMS );
static RTYPE compiled_block_1_1112( CONT_PARAMS );
static RTYPE compiled_block_1_1111( CONT_PARAMS );
static RTYPE compiled_block_1_1103( CONT_PARAMS );
static RTYPE compiled_block_1_1104( CONT_PARAMS );
static RTYPE compiled_block_1_1106( CONT_PARAMS );
static RTYPE compiled_block_1_1105( CONT_PARAMS );
static RTYPE compiled_block_1_1102( CONT_PARAMS );
static RTYPE compiled_block_1_1097( CONT_PARAMS );
static RTYPE compiled_block_1_1090( CONT_PARAMS );
static RTYPE compiled_block_1_1004( CONT_PARAMS );
static RTYPE compiled_block_1_1054( CONT_PARAMS );
static RTYPE compiled_block_1_1056( CONT_PARAMS );
static RTYPE compiled_block_1_1059( CONT_PARAMS );
static RTYPE compiled_block_1_1061( CONT_PARAMS );
static RTYPE compiled_block_1_1064( CONT_PARAMS );
static RTYPE compiled_block_1_1066( CONT_PARAMS );
static RTYPE compiled_block_1_1073( CONT_PARAMS );
static RTYPE compiled_block_1_1078( CONT_PARAMS );
static RTYPE compiled_block_1_1077( CONT_PARAMS );
static RTYPE compiled_block_1_1076( CONT_PARAMS );
static RTYPE compiled_block_1_1075( CONT_PARAMS );
static RTYPE compiled_block_1_1074( CONT_PARAMS );
static RTYPE compiled_block_1_1068( CONT_PARAMS );
static RTYPE compiled_block_1_1069( CONT_PARAMS );
static RTYPE compiled_block_1_1071( CONT_PARAMS );
static RTYPE compiled_block_1_1070( CONT_PARAMS );
static RTYPE compiled_block_1_1067( CONT_PARAMS );
static RTYPE compiled_block_1_1062( CONT_PARAMS );
static RTYPE compiled_block_1_1057( CONT_PARAMS );
static RTYPE compiled_block_1_1003( CONT_PARAMS );
static RTYPE compiled_block_1_1032( CONT_PARAMS );
static RTYPE compiled_block_1_1034( CONT_PARAMS );
static RTYPE compiled_block_1_1037( CONT_PARAMS );
static RTYPE compiled_block_1_1039( CONT_PARAMS );
static RTYPE compiled_block_1_1042( CONT_PARAMS );
static RTYPE compiled_block_1_1044( CONT_PARAMS );
static RTYPE compiled_block_1_1046( CONT_PARAMS );
static RTYPE compiled_block_1_1045( CONT_PARAMS );
static RTYPE compiled_block_1_1040( CONT_PARAMS );
static RTYPE compiled_block_1_1035( CONT_PARAMS );
static RTYPE compiled_block_1_1002( CONT_PARAMS );
static RTYPE compiled_block_1_1007( CONT_PARAMS );
static RTYPE compiled_block_1_1009( CONT_PARAMS );
static RTYPE compiled_block_1_1012( CONT_PARAMS );
static RTYPE compiled_block_1_1014( CONT_PARAMS );
static RTYPE compiled_block_1_1016( CONT_PARAMS );
static RTYPE compiled_block_1_1019( CONT_PARAMS );
static RTYPE compiled_block_1_1021( CONT_PARAMS );
static RTYPE compiled_block_1_1023( CONT_PARAMS );
static RTYPE compiled_block_1_1022( CONT_PARAMS );
static RTYPE compiled_block_1_1017( CONT_PARAMS );
static RTYPE compiled_block_1_1010( CONT_PARAMS );
static RTYPE compiled_start_1_4( CONT_PARAMS );
static RTYPE compiled_start_1_1( CONT_PARAMS );

static RTYPE compiled_start_1_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1275, compiled_block_1_1275 );
  twobit_invoke( 8 );
  twobit_label( 1275, compiled_block_1_1275 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1276, compiled_block_1_1276 );
  twobit_invoke( 1 );
  twobit_label( 1276, compiled_block_1_1276 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* ex:uncompress */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_4, 2, 0 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1126, compiled_block_1_1126 );
  twobit_invoke( 2 );
  twobit_label( 1126, compiled_block_1_1126 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_5, 6, 0 );
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1262, compiled_block_1_1262 );
  twobit_invoke( 2 );
  twobit_label( 1262, compiled_block_1_1262 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_6, 9, 0 );
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1267, compiled_block_1_1267 );
  twobit_invoke( 2 );
  twobit_label( 1267, compiled_block_1_1267 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_7, 12, 0 );
  twobit_setreg( 2 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1272, compiled_block_1_1272 );
  twobit_invoke( 2 );
  twobit_label( 1272, compiled_block_1_1272 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1007, compiled_block_1_1007 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1009, compiled_block_1_1009 ); /* internal:branchf-pair? */
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 5 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1010, compiled_block_1_1010 );
  twobit_invoke( 1 );
  twobit_label( 1010, compiled_block_1_1010 );
  twobit_load( 0, 0 );
  twobit_branchf( 1012, compiled_block_1_1012 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1014, compiled_block_1_1014 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1016, compiled_block_1_1016 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1017, compiled_block_1_1017 );
  twobit_invoke( 1 );
  twobit_label( 1017, compiled_block_1_1017 );
  twobit_load( 0, 0 );
  twobit_branchf( 1019, compiled_block_1_1019 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1021, compiled_block_1_1021 ); /* internal:branchf-null? */
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1022, compiled_block_1_1022 );
  twobit_invoke( 5 );
  twobit_label( 1022, compiled_block_1_1022 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1023, compiled_block_1_1023 );
  twobit_invoke( 5 );
  twobit_label( 1023, compiled_block_1_1023 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1021, compiled_block_1_1021 );
  twobit_load( 1, 5 );
  twobit_pop( 5 );
  twobit_branch( 1004, compiled_block_1_1004 );
  twobit_label( 1019, compiled_block_1_1019 );
  twobit_load( 1, 5 );
  twobit_pop( 5 );
  twobit_branch( 1004, compiled_block_1_1004 );
  twobit_label( 1016, compiled_block_1_1016 );
  twobit_load( 1, 5 );
  twobit_pop( 5 );
  twobit_branch( 1004, compiled_block_1_1004 );
  twobit_label( 1014, compiled_block_1_1014 );
  twobit_load( 1, 5 );
  twobit_pop( 5 );
  twobit_branch( 1004, compiled_block_1_1004 );
  twobit_label( 1012, compiled_block_1_1012 );
  twobit_load( 1, 5 );
  twobit_pop( 5 );
  twobit_branch( 1004, compiled_block_1_1004 );
  twobit_label( 1009, compiled_block_1_1009 );
  twobit_branch( 1004, compiled_block_1_1004 );
  twobit_label( 1007, compiled_block_1_1007 );
  twobit_branch( 1004, compiled_block_1_1004 );
  twobit_label( 1002, compiled_block_1_1002 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1032, compiled_block_1_1032 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1034, compiled_block_1_1034 ); /* internal:branchf-pair? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1035, compiled_block_1_1035 );
  twobit_invoke( 1 );
  twobit_label( 1035, compiled_block_1_1035 );
  twobit_load( 0, 0 );
  twobit_branchf( 1037, compiled_block_1_1037 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1039, compiled_block_1_1039 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1040, compiled_block_1_1040 );
  twobit_invoke( 1 );
  twobit_label( 1040, compiled_block_1_1040 );
  twobit_load( 0, 0 );
  twobit_branchf( 1042, compiled_block_1_1042 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1044, compiled_block_1_1044 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1045, compiled_block_1_1045 );
  twobit_invoke( 5 );
  twobit_label( 1045, compiled_block_1_1045 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 9 ); /* append */
  twobit_setrtn( 1046, compiled_block_1_1046 );
  twobit_invoke( 2 );
  twobit_label( 1046, compiled_block_1_1046 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1044, compiled_block_1_1044 );
  twobit_load( 1, 6 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_pop( 6 );
  twobit_invoke( 1 );
  twobit_label( 1042, compiled_block_1_1042 );
  twobit_load( 1, 6 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_pop( 6 );
  twobit_invoke( 1 );
  twobit_label( 1039, compiled_block_1_1039 );
  twobit_load( 1, 6 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_pop( 6 );
  twobit_invoke( 1 );
  twobit_label( 1037, compiled_block_1_1037 );
  twobit_load( 1, 6 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_pop( 6 );
  twobit_invoke( 1 );
  twobit_label( 1034, compiled_block_1_1034 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1032, compiled_block_1_1032 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1003, compiled_block_1_1003 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1054, compiled_block_1_1054 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1056, compiled_block_1_1056 ); /* internal:branchf-pair? */
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 5 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1057, compiled_block_1_1057 );
  twobit_invoke( 1 );
  twobit_label( 1057, compiled_block_1_1057 );
  twobit_load( 0, 0 );
  twobit_branchf( 1059, compiled_block_1_1059 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1061, compiled_block_1_1061 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1062, compiled_block_1_1062 );
  twobit_invoke( 1 );
  twobit_label( 1062, compiled_block_1_1062 );
  twobit_load( 0, 0 );
  twobit_branchf( 1064, compiled_block_1_1064 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1066, compiled_block_1_1066 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 3, 1 );
  twobit_global( 11 ); /* ex:identifier? */
  twobit_setrtn( 1067, compiled_block_1_1067 );
  twobit_invoke( 1 );
  twobit_label( 1067, compiled_block_1_1067 );
  twobit_load( 0, 0 );
  twobit_branchf( 1069, compiled_block_1_1069 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 13 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1070, compiled_block_1_1070 );
  twobit_invoke( 5 );
  twobit_label( 1070, compiled_block_1_1070 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 14 ); /* ex:free-identifier=? */
  twobit_setrtn( 1071, compiled_block_1_1071 );
  twobit_invoke( 2 );
  twobit_label( 1071, compiled_block_1_1071 );
  twobit_load( 0, 0 );
  twobit_skip( 1068, compiled_block_1_1068 );
  twobit_label( 1069, compiled_block_1_1069 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1068, compiled_block_1_1068 );
  twobit_branchf( 1073, compiled_block_1_1073 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 13 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1074, compiled_block_1_1074 );
  twobit_invoke( 5 );
  twobit_label( 1074, compiled_block_1_1074 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 13 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1075, compiled_block_1_1075 );
  twobit_invoke( 5 );
  twobit_label( 1075, compiled_block_1_1075 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_global( 9 ); /* append */
  twobit_setrtn( 1076, compiled_block_1_1076 );
  twobit_invoke( 2 );
  twobit_label( 1076, compiled_block_1_1076 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 13 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1077, compiled_block_1_1077 );
  twobit_invoke( 5 );
  twobit_label( 1077, compiled_block_1_1077 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 4 );
  twobit_global( 9 ); /* append */
  twobit_setrtn( 1078, compiled_block_1_1078 );
  twobit_invoke( 2 );
  twobit_label( 1078, compiled_block_1_1078 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1073, compiled_block_1_1073 );
  twobit_load( 1, 5 );
  twobit_pop( 5 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1066, compiled_block_1_1066 );
  twobit_load( 1, 5 );
  twobit_pop( 5 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1064, compiled_block_1_1064 );
  twobit_load( 1, 5 );
  twobit_pop( 5 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1061, compiled_block_1_1061 );
  twobit_load( 1, 5 );
  twobit_pop( 5 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1059, compiled_block_1_1059 );
  twobit_load( 1, 5 );
  twobit_pop( 5 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1056, compiled_block_1_1056 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1054, compiled_block_1_1054 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1004, compiled_block_1_1004 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1087, compiled_block_1_1087 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1089, compiled_block_1_1089 ); /* internal:branchf-pair? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1090, compiled_block_1_1090 );
  twobit_invoke( 1 );
  twobit_label( 1090, compiled_block_1_1090 );
  twobit_load( 0, 0 );
  twobit_branchf( 1092, compiled_block_1_1092 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1094, compiled_block_1_1094 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1096, compiled_block_1_1096 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 5 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1097, compiled_block_1_1097 );
  twobit_invoke( 1 );
  twobit_label( 1097, compiled_block_1_1097 );
  twobit_load( 0, 0 );
  twobit_branchf( 1099, compiled_block_1_1099 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1101, compiled_block_1_1101 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 3, 1 );
  twobit_global( 11 ); /* ex:identifier? */
  twobit_setrtn( 1102, compiled_block_1_1102 );
  twobit_invoke( 1 );
  twobit_label( 1102, compiled_block_1_1102 );
  twobit_load( 0, 0 );
  twobit_branchf( 1104, compiled_block_1_1104 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 17 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1105, compiled_block_1_1105 );
  twobit_invoke( 5 );
  twobit_label( 1105, compiled_block_1_1105 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 14 ); /* ex:free-identifier=? */
  twobit_setrtn( 1106, compiled_block_1_1106 );
  twobit_invoke( 2 );
  twobit_label( 1106, compiled_block_1_1106 );
  twobit_load( 0, 0 );
  twobit_skip( 1103, compiled_block_1_1103 );
  twobit_label( 1104, compiled_block_1_1104 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1103, compiled_block_1_1103 );
  twobit_branchf( 1108, compiled_block_1_1108 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1110, compiled_block_1_1110 ); /* internal:branchf-null? */
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 17 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1111, compiled_block_1_1111 );
  twobit_invoke( 5 );
  twobit_label( 1111, compiled_block_1_1111 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 18 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 17 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1112, compiled_block_1_1112 );
  twobit_invoke( 5 );
  twobit_label( 1112, compiled_block_1_1112 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_global( 9 ); /* append */
  twobit_setrtn( 1113, compiled_block_1_1113 );
  twobit_invoke( 2 );
  twobit_label( 1113, compiled_block_1_1113 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 17 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1114, compiled_block_1_1114 );
  twobit_invoke( 5 );
  twobit_label( 1114, compiled_block_1_1114 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 18 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 17 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1115, compiled_block_1_1115 );
  twobit_invoke( 5 );
  twobit_label( 1115, compiled_block_1_1115 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 4 );
  twobit_global( 9 ); /* append */
  twobit_setrtn( 1116, compiled_block_1_1116 );
  twobit_invoke( 2 );
  twobit_label( 1116, compiled_block_1_1116 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1110, compiled_block_1_1110 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1003, compiled_block_1_1003 );
  twobit_label( 1108, compiled_block_1_1108 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1003, compiled_block_1_1003 );
  twobit_label( 1101, compiled_block_1_1101 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1003, compiled_block_1_1003 );
  twobit_label( 1099, compiled_block_1_1099 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1003, compiled_block_1_1003 );
  twobit_label( 1096, compiled_block_1_1096 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1003, compiled_block_1_1003 );
  twobit_label( 1094, compiled_block_1_1094 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1003, compiled_block_1_1003 );
  twobit_label( 1092, compiled_block_1_1092 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1003, compiled_block_1_1003 );
  twobit_label( 1089, compiled_block_1_1089 );
  twobit_branch( 1003, compiled_block_1_1003 );
  twobit_label( 1087, compiled_block_1_1087 );
  twobit_branch( 1003, compiled_block_1_1003 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1132, compiled_block_1_1132 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1134, compiled_block_1_1134 ); /* internal:branchf-pair? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1135, compiled_block_1_1135 );
  twobit_invoke( 1 );
  twobit_label( 1135, compiled_block_1_1135 );
  twobit_load( 0, 0 );
  twobit_branchf( 1137, compiled_block_1_1137 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1139, compiled_block_1_1139 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1141, compiled_block_1_1141 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1143, compiled_block_1_1143 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 3 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1144, compiled_block_1_1144 );
  twobit_invoke( 1 );
  twobit_label( 1144, compiled_block_1_1144 );
  twobit_load( 0, 0 );
  twobit_branchf( 1146, compiled_block_1_1146 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1148, compiled_block_1_1148 ); /* internal:branchf-null? */
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1149, compiled_block_1_1149 );
  twobit_invoke( 5 );
  twobit_label( 1149, compiled_block_1_1149 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 3, 2 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 2 ); /* () */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1150, compiled_block_1_1150 );
  twobit_invoke( 5 );
  twobit_label( 1150, compiled_block_1_1150 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1148, compiled_block_1_1148 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1129, compiled_block_1_1129 );
  twobit_label( 1146, compiled_block_1_1146 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1129, compiled_block_1_1129 );
  twobit_label( 1143, compiled_block_1_1143 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1129, compiled_block_1_1129 );
  twobit_label( 1141, compiled_block_1_1141 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1129, compiled_block_1_1129 );
  twobit_label( 1139, compiled_block_1_1139 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1129, compiled_block_1_1129 );
  twobit_label( 1137, compiled_block_1_1137 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1129, compiled_block_1_1129 );
  twobit_label( 1134, compiled_block_1_1134 );
  twobit_branch( 1129, compiled_block_1_1129 );
  twobit_label( 1132, compiled_block_1_1132 );
  twobit_branch( 1129, compiled_block_1_1129 );
  twobit_label( 1127, compiled_block_1_1127 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1160, compiled_block_1_1160 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1162, compiled_block_1_1162 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1164, compiled_block_1_1164 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1166, compiled_block_1_1166 ); /* internal:branchf-pair? */
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 8 );
  twobit_store( 2, 2 );
  twobit_store( 3, 6 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 3 );
  twobit_movereg( 31, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1167, compiled_block_1_1167 );
  twobit_invoke( 1 );
  twobit_label( 1167, compiled_block_1_1167 );
  twobit_load( 0, 0 );
  twobit_branchf( 1169, compiled_block_1_1169 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1171, compiled_block_1_1171 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1172, compiled_block_1_1172 );
  twobit_invoke( 5 );
  twobit_label( 1172, compiled_block_1_1172 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1173, compiled_block_1_1173 );
  twobit_invoke( 5 );
  twobit_label( 1173, compiled_block_1_1173 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1174, compiled_block_1_1174 );
  twobit_invoke( 5 );
  twobit_label( 1174, compiled_block_1_1174 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_global( 10 ); /* append */
  twobit_setrtn( 1175, compiled_block_1_1175 );
  twobit_invoke( 2 );
  twobit_label( 1175, compiled_block_1_1175 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 1171, compiled_block_1_1171 );
  twobit_load( 1, 8 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 1169, compiled_block_1_1169 );
  twobit_load( 1, 8 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 1166, compiled_block_1_1166 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1164, compiled_block_1_1164 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1162, compiled_block_1_1162 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1160, compiled_block_1_1160 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1128, compiled_block_1_1128 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1183, compiled_block_1_1183 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1185, compiled_block_1_1185 ); /* internal:branchf-pair? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1186, compiled_block_1_1186 );
  twobit_invoke( 1 );
  twobit_label( 1186, compiled_block_1_1186 );
  twobit_load( 0, 0 );
  twobit_branchf( 1188, compiled_block_1_1188 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1190, compiled_block_1_1190 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1192, compiled_block_1_1192 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 4 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1193, compiled_block_1_1193 );
  twobit_invoke( 1 );
  twobit_label( 1193, compiled_block_1_1193 );
  twobit_load( 0, 0 );
  twobit_branchf( 1195, compiled_block_1_1195 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1197, compiled_block_1_1197 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 3, 1 );
  twobit_global( 12 ); /* ex:identifier? */
  twobit_setrtn( 1198, compiled_block_1_1198 );
  twobit_invoke( 1 );
  twobit_label( 1198, compiled_block_1_1198 );
  twobit_load( 0, 0 );
  twobit_branchf( 1200, compiled_block_1_1200 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1201, compiled_block_1_1201 );
  twobit_invoke( 5 );
  twobit_label( 1201, compiled_block_1_1201 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 15 ); /* ex:free-identifier=? */
  twobit_setrtn( 1202, compiled_block_1_1202 );
  twobit_invoke( 2 );
  twobit_label( 1202, compiled_block_1_1202 );
  twobit_load( 0, 0 );
  twobit_skip( 1199, compiled_block_1_1199 );
  twobit_label( 1200, compiled_block_1_1200 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1199, compiled_block_1_1199 );
  twobit_branchf( 1204, compiled_block_1_1204 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1205, compiled_block_1_1205 );
  twobit_invoke( 5 );
  twobit_label( 1205, compiled_block_1_1205 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1206, compiled_block_1_1206 );
  twobit_invoke( 5 );
  twobit_label( 1206, compiled_block_1_1206 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_global( 10 ); /* append */
  twobit_setrtn( 1207, compiled_block_1_1207 );
  twobit_invoke( 2 );
  twobit_label( 1207, compiled_block_1_1207 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1208, compiled_block_1_1208 );
  twobit_invoke( 5 );
  twobit_label( 1208, compiled_block_1_1208 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 4 );
  twobit_global( 10 ); /* append */
  twobit_setrtn( 1209, compiled_block_1_1209 );
  twobit_invoke( 2 );
  twobit_label( 1209, compiled_block_1_1209 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1204, compiled_block_1_1204 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1127, compiled_block_1_1127 );
  twobit_label( 1197, compiled_block_1_1197 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1127, compiled_block_1_1127 );
  twobit_label( 1195, compiled_block_1_1195 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1127, compiled_block_1_1127 );
  twobit_label( 1192, compiled_block_1_1192 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1127, compiled_block_1_1127 );
  twobit_label( 1190, compiled_block_1_1190 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1127, compiled_block_1_1127 );
  twobit_label( 1188, compiled_block_1_1188 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1127, compiled_block_1_1127 );
  twobit_label( 1185, compiled_block_1_1185 );
  twobit_branch( 1127, compiled_block_1_1127 );
  twobit_label( 1183, compiled_block_1_1183 );
  twobit_branch( 1127, compiled_block_1_1127 );
  twobit_label( 1129, compiled_block_1_1129 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1219, compiled_block_1_1219 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1221, compiled_block_1_1221 ); /* internal:branchf-pair? */
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 8 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1222, compiled_block_1_1222 );
  twobit_invoke( 1 );
  twobit_label( 1222, compiled_block_1_1222 );
  twobit_load( 0, 0 );
  twobit_branchf( 1224, compiled_block_1_1224 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1226, compiled_block_1_1226 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1228, compiled_block_1_1228 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1230, compiled_block_1_1230 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 5 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 4 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1231, compiled_block_1_1231 );
  twobit_invoke( 1 );
  twobit_label( 1231, compiled_block_1_1231 );
  twobit_load( 0, 0 );
  twobit_branchf( 1233, compiled_block_1_1233 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1235, compiled_block_1_1235 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 3, 1 );
  twobit_global( 12 ); /* ex:identifier? */
  twobit_setrtn( 1236, compiled_block_1_1236 );
  twobit_invoke( 1 );
  twobit_label( 1236, compiled_block_1_1236 );
  twobit_load( 0, 0 );
  twobit_branchf( 1238, compiled_block_1_1238 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 17 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1239, compiled_block_1_1239 );
  twobit_invoke( 5 );
  twobit_label( 1239, compiled_block_1_1239 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 15 ); /* ex:free-identifier=? */
  twobit_setrtn( 1240, compiled_block_1_1240 );
  twobit_invoke( 2 );
  twobit_label( 1240, compiled_block_1_1240 );
  twobit_load( 0, 0 );
  twobit_skip( 1237, compiled_block_1_1237 );
  twobit_label( 1238, compiled_block_1_1238 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1237, compiled_block_1_1237 );
  twobit_branchf( 1242, compiled_block_1_1242 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1244, compiled_block_1_1244 ); /* internal:branchf-null? */
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 17 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1245, compiled_block_1_1245 );
  twobit_invoke( 5 );
  twobit_label( 1245, compiled_block_1_1245 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 17 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1246, compiled_block_1_1246 );
  twobit_invoke( 5 );
  twobit_label( 1246, compiled_block_1_1246 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 17 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1247, compiled_block_1_1247 );
  twobit_invoke( 5 );
  twobit_label( 1247, compiled_block_1_1247 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_global( 10 ); /* append */
  twobit_setrtn( 1248, compiled_block_1_1248 );
  twobit_invoke( 2 );
  twobit_label( 1248, compiled_block_1_1248 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 18 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 17 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1249, compiled_block_1_1249 );
  twobit_invoke( 5 );
  twobit_label( 1249, compiled_block_1_1249 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 17 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1250, compiled_block_1_1250 );
  twobit_invoke( 5 );
  twobit_label( 1250, compiled_block_1_1250 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 4 );
  twobit_global( 10 ); /* append */
  twobit_setrtn( 1251, compiled_block_1_1251 );
  twobit_invoke( 2 );
  twobit_label( 1251, compiled_block_1_1251 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 1244, compiled_block_1_1244 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1128, compiled_block_1_1128 );
  twobit_label( 1242, compiled_block_1_1242 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1128, compiled_block_1_1128 );
  twobit_label( 1235, compiled_block_1_1235 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1128, compiled_block_1_1128 );
  twobit_label( 1233, compiled_block_1_1233 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1128, compiled_block_1_1128 );
  twobit_label( 1230, compiled_block_1_1230 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1128, compiled_block_1_1128 );
  twobit_label( 1228, compiled_block_1_1228 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1128, compiled_block_1_1128 );
  twobit_label( 1226, compiled_block_1_1226 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1128, compiled_block_1_1128 );
  twobit_label( 1224, compiled_block_1_1224 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1128, compiled_block_1_1128 );
  twobit_label( 1221, compiled_block_1_1221 );
  twobit_branch( 1128, compiled_block_1_1128 );
  twobit_label( 1219, compiled_block_1_1219 );
  twobit_branch( 1128, compiled_block_1_1128 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_6( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1264, compiled_block_1_1264 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1265, compiled_block_1_1265 );
  twobit_invoke( 5 );
  twobit_label( 1265, compiled_block_1_1265 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1264, compiled_block_1_1264 );
  twobit_global( 5 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_7( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1269, compiled_block_1_1269 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1270, compiled_block_1_1270 );
  twobit_invoke( 5 );
  twobit_label( 1270, compiled_block_1_1270 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1269, compiled_block_1_1269 );
  twobit_global( 5 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_0508ee6e35dc29ece1878ece13398486_0(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_1_0(CONT_ACTUALS));
}
static RTYPE compiled_block_2_1004( CONT_PARAMS );
static RTYPE compiled_block_2_1003( CONT_PARAMS );
static RTYPE compiled_start_2_0( CONT_PARAMS );
static RTYPE compiled_start_2_3( CONT_PARAMS );
static RTYPE compiled_start_2_2( CONT_PARAMS );
static RTYPE compiled_start_2_1( CONT_PARAMS );

static RTYPE compiled_start_2_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_2_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_2_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1003, compiled_block_2_1003 );
  twobit_invoke( 8 );
  twobit_label( 1003, compiled_block_2_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1004, compiled_block_2_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_2_1004 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_0508ee6e35dc29ece1878ece13398486_1(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_2_0(CONT_ACTUALS));
}
codeptr_t CDECL twobit_load_table[] = { 
  twobit_thunk_0508ee6e35dc29ece1878ece13398486_0,
  twobit_thunk_0508ee6e35dc29ece1878ece13398486_1,
  0  /* The table may be empty; some compilers complain */
};

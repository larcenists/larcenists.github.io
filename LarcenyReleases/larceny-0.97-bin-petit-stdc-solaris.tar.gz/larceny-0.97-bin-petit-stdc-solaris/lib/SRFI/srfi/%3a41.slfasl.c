/* Generated from /proj/will/pnkfelix/larcenytest/larceny-petit-Nightly-2009-08-19/larceny_src/lib/SRFI/srfi/%3a41.slfasl */
#include "petit-instr.h"

static RTYPE compiled_block_1_1131( CONT_PARAMS );
static RTYPE compiled_block_1_1130( CONT_PARAMS );
static RTYPE compiled_start_1_0( CONT_PARAMS );
static RTYPE compiled_block_1_1097( CONT_PARAMS );
static RTYPE compiled_block_1_1096( CONT_PARAMS );
static RTYPE compiled_block_1_1095( CONT_PARAMS );
static RTYPE compiled_block_1_1094( CONT_PARAMS );
static RTYPE compiled_block_1_1093( CONT_PARAMS );
static RTYPE compiled_block_1_1092( CONT_PARAMS );
static RTYPE compiled_block_1_1091( CONT_PARAMS );
static RTYPE compiled_block_1_1090( CONT_PARAMS );
static RTYPE compiled_block_1_1089( CONT_PARAMS );
static RTYPE compiled_block_1_1071( CONT_PARAMS );
static RTYPE compiled_block_1_1070( CONT_PARAMS );
static RTYPE compiled_block_1_1069( CONT_PARAMS );
static RTYPE compiled_block_1_1068( CONT_PARAMS );
static RTYPE compiled_block_1_1067( CONT_PARAMS );
static RTYPE compiled_block_1_1066( CONT_PARAMS );
static RTYPE compiled_block_1_1065( CONT_PARAMS );
static RTYPE compiled_block_1_1064( CONT_PARAMS );
static RTYPE compiled_start_1_3( CONT_PARAMS );
static RTYPE compiled_block_1_1121( CONT_PARAMS );
static RTYPE compiled_block_1_1126( CONT_PARAMS );
static RTYPE compiled_block_1_1124( CONT_PARAMS );
static RTYPE compiled_block_1_1122( CONT_PARAMS );
static RTYPE compiled_block_1_1119( CONT_PARAMS );
static RTYPE compiled_start_1_10( CONT_PARAMS );
static RTYPE compiled_block_1_1110( CONT_PARAMS );
static RTYPE compiled_block_1_1116( CONT_PARAMS );
static RTYPE compiled_block_1_1115( CONT_PARAMS );
static RTYPE compiled_block_1_1113( CONT_PARAMS );
static RTYPE compiled_block_1_1111( CONT_PARAMS );
static RTYPE compiled_block_1_1108( CONT_PARAMS );
static RTYPE compiled_start_1_9( CONT_PARAMS );
static RTYPE compiled_block_1_1105( CONT_PARAMS );
static RTYPE compiled_temp_1_11( CONT_PARAMS );
static RTYPE compiled_block_1_1107( CONT_PARAMS );
static RTYPE compiled_block_1_1106( CONT_PARAMS );
static RTYPE compiled_block_1_1103( CONT_PARAMS );
static RTYPE compiled_start_1_8( CONT_PARAMS );
static RTYPE compiled_block_1_1100( CONT_PARAMS );
static RTYPE compiled_block_1_1101( CONT_PARAMS );
static RTYPE compiled_block_1_1098( CONT_PARAMS );
static RTYPE compiled_start_1_7( CONT_PARAMS );
static RTYPE compiled_start_1_6( CONT_PARAMS );
static RTYPE compiled_block_1_1085( CONT_PARAMS );
static RTYPE compiled_block_1_1074( CONT_PARAMS );
static RTYPE compiled_block_1_1078( CONT_PARAMS );
static RTYPE compiled_block_1_1081( CONT_PARAMS );
static RTYPE compiled_block_1_1086( CONT_PARAMS );
static RTYPE compiled_block_1_1084( CONT_PARAMS );
static RTYPE compiled_block_1_1083( CONT_PARAMS );
static RTYPE compiled_block_1_1082( CONT_PARAMS );
static RTYPE compiled_temp_1_12( CONT_PARAMS );
static RTYPE compiled_block_1_1080( CONT_PARAMS );
static RTYPE compiled_block_1_1079( CONT_PARAMS );
static RTYPE compiled_block_1_1076( CONT_PARAMS );
static RTYPE compiled_block_1_1073( CONT_PARAMS );
static RTYPE compiled_start_1_5( CONT_PARAMS );
static RTYPE compiled_start_1_4( CONT_PARAMS );
static RTYPE compiled_block_1_1062( CONT_PARAMS );
static RTYPE compiled_block_1_1045( CONT_PARAMS );
static RTYPE compiled_block_1_1028( CONT_PARAMS );
static RTYPE compiled_block_1_1016( CONT_PARAMS );
static RTYPE compiled_start_1_2( CONT_PARAMS );
static RTYPE compiled_block_1_1047( CONT_PARAMS );
static RTYPE compiled_block_1_1049( CONT_PARAMS );
static RTYPE compiled_block_1_1051( CONT_PARAMS );
static RTYPE compiled_block_1_1054( CONT_PARAMS );
static RTYPE compiled_block_1_1057( CONT_PARAMS );
static RTYPE compiled_block_1_1056( CONT_PARAMS );
static RTYPE compiled_block_1_1055( CONT_PARAMS );
static RTYPE compiled_block_1_1052( CONT_PARAMS );
static RTYPE compiled_start_1_16( CONT_PARAMS );
static RTYPE compiled_block_1_1030( CONT_PARAMS );
static RTYPE compiled_block_1_1032( CONT_PARAMS );
static RTYPE compiled_block_1_1034( CONT_PARAMS );
static RTYPE compiled_block_1_1036( CONT_PARAMS );
static RTYPE compiled_block_1_1040( CONT_PARAMS );
static RTYPE compiled_block_1_1039( CONT_PARAMS );
static RTYPE compiled_block_1_1038( CONT_PARAMS );
static RTYPE compiled_block_1_1037( CONT_PARAMS );
static RTYPE compiled_start_1_15( CONT_PARAMS );
static RTYPE compiled_block_1_1018( CONT_PARAMS );
static RTYPE compiled_block_1_1020( CONT_PARAMS );
static RTYPE compiled_block_1_1022( CONT_PARAMS );
static RTYPE compiled_block_1_1024( CONT_PARAMS );
static RTYPE compiled_block_1_1023( CONT_PARAMS );
static RTYPE compiled_start_1_14( CONT_PARAMS );
static RTYPE compiled_block_1_1003( CONT_PARAMS );
static RTYPE compiled_block_1_1005( CONT_PARAMS );
static RTYPE compiled_block_1_1007( CONT_PARAMS );
static RTYPE compiled_block_1_1012( CONT_PARAMS );
static RTYPE compiled_block_1_1011( CONT_PARAMS );
static RTYPE compiled_block_1_1010( CONT_PARAMS );
static RTYPE compiled_block_1_1009( CONT_PARAMS );
static RTYPE compiled_block_1_1008( CONT_PARAMS );
static RTYPE compiled_start_1_13( CONT_PARAMS );
static RTYPE compiled_start_1_1( CONT_PARAMS );

static RTYPE compiled_start_1_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 2 ); /*  stream-cdr~1ayXVW~19399 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 3 ); /*  stream-car~1ayXVW~19398 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 4 ); /*  stream-null?~1ayXVW~19379 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 5 ); /*  stream-pair?~1ayXVW~19378 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 6 ); /*  stream-kdr~1ayXVW~19375 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 7 ); /*  stream-kar~1ayXVW~19373 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 8 ); /*  stream-pare?~1ayXVW~19371 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 9 ); /*  make-stream-pare~1ayXVW~19369 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 10 ); /*  ignored~1ayXVW~19367 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 11 ); /*  stream-pare-type~1ayXVW~19365 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 12 ); /*  stream-null~1ayXVW~19360 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 13 ); /*  stream-force~1ayXVW~19359 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 14 ); /*  stream-eager~1ayXVW~19343 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 15 ); /*  stream-promise!~1ayXVW~19327 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 16 ); /*  stream-promise~1ayXVW~19325 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 17 ); /*  stream?~1ayXVW~19323 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 18 ); /*  make-stream~1ayXVW~19321 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 19 ); /*  ignored~1ayXVW~19319 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 20 ); /*  stream-type~1ayXVW~19317 */
  twobit_lambda( compiled_start_1_1, 22, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_2, 24, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_3, 26, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 27 );
  twobit_setreg( 1 );
  twobit_const( 28 );
  twobit_setreg( 3 );
  twobit_const( 29 );
  twobit_setreg( 4 );
  twobit_const( 30 );
  twobit_setreg( 5 );
  twobit_const( 31 );
  twobit_setreg( 8 );
  twobit_global( 32 ); /* ex:make-library */
  twobit_setrtn( 1130, compiled_block_1_1130 );
  twobit_invoke( 8 );
  twobit_label( 1130, compiled_block_1_1130 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 33 ); /* ex:register-library! */
  twobit_setrtn( 1131, compiled_block_1_1131 );
  twobit_invoke( 1 );
  twobit_label( 1131, compiled_block_1_1131 );
  twobit_load( 0, 0 );
  twobit_global( 34 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* ex:uncompress */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_13, 2, 0 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1016, compiled_block_1_1016 );
  twobit_invoke( 2 );
  twobit_label( 1016, compiled_block_1_1016 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_14, 6, 0 );
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1028, compiled_block_1_1028 );
  twobit_invoke( 2 );
  twobit_label( 1028, compiled_block_1_1028 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_15, 9, 0 );
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1045, compiled_block_1_1045 );
  twobit_invoke( 2 );
  twobit_label( 1045, compiled_block_1_1045 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_16, 12, 0 );
  twobit_setreg( 2 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1062, compiled_block_1_1062 );
  twobit_invoke( 2 );
  twobit_label( 1062, compiled_block_1_1062 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_13( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1003, compiled_block_1_1003 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1005, compiled_block_1_1005 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1007, compiled_block_1_1007 ); /* internal:branchf-null? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 3, 2 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1008, compiled_block_1_1008 );
  twobit_invoke( 5 );
  twobit_label( 1008, compiled_block_1_1008 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1009, compiled_block_1_1009 );
  twobit_invoke( 5 );
  twobit_label( 1009, compiled_block_1_1009 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1010, compiled_block_1_1010 );
  twobit_invoke( 5 );
  twobit_label( 1010, compiled_block_1_1010 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1011, compiled_block_1_1011 );
  twobit_invoke( 5 );
  twobit_label( 1011, compiled_block_1_1011 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1012, compiled_block_1_1012 );
  twobit_invoke( 5 );
  twobit_label( 1012, compiled_block_1_1012 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1007, compiled_block_1_1007 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1005, compiled_block_1_1005 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1003, compiled_block_1_1003 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_14( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1018, compiled_block_1_1018 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1020, compiled_block_1_1020 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1022, compiled_block_1_1022 ); /* internal:branchf-null? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1023, compiled_block_1_1023 );
  twobit_invoke( 5 );
  twobit_label( 1023, compiled_block_1_1023 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1024, compiled_block_1_1024 );
  twobit_invoke( 5 );
  twobit_label( 1024, compiled_block_1_1024 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1022, compiled_block_1_1022 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1020, compiled_block_1_1020 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1018, compiled_block_1_1018 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_15( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1030, compiled_block_1_1030 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1032, compiled_block_1_1032 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1034, compiled_block_1_1034 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1036, compiled_block_1_1036 ); /* internal:branchf-null? */
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 3, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1037, compiled_block_1_1037 );
  twobit_invoke( 5 );
  twobit_label( 1037, compiled_block_1_1037 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1038, compiled_block_1_1038 );
  twobit_invoke( 5 );
  twobit_label( 1038, compiled_block_1_1038 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1039, compiled_block_1_1039 );
  twobit_invoke( 5 );
  twobit_label( 1039, compiled_block_1_1039 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1040, compiled_block_1_1040 );
  twobit_invoke( 5 );
  twobit_label( 1040, compiled_block_1_1040 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1036, compiled_block_1_1036 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1034, compiled_block_1_1034 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1032, compiled_block_1_1032 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1030, compiled_block_1_1030 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_16( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1047, compiled_block_1_1047 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1049, compiled_block_1_1049 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1051, compiled_block_1_1051 ); /* internal:branchf-pair? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 3, 4 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1052, compiled_block_1_1052 );
  twobit_invoke( 1 );
  twobit_label( 1052, compiled_block_1_1052 );
  twobit_load( 0, 0 );
  twobit_branchf( 1054, compiled_block_1_1054 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1055, compiled_block_1_1055 );
  twobit_invoke( 5 );
  twobit_label( 1055, compiled_block_1_1055 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1056, compiled_block_1_1056 );
  twobit_invoke( 5 );
  twobit_label( 1056, compiled_block_1_1056 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 3, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1057, compiled_block_1_1057 );
  twobit_invoke( 5 );
  twobit_label( 1057, compiled_block_1_1057 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1054, compiled_block_1_1054 );
  twobit_load( 1, 6 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_pop( 6 );
  twobit_invoke( 1 );
  twobit_label( 1051, compiled_block_1_1051 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1049, compiled_block_1_1049 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1047, compiled_block_1_1047 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 2 ); /*  stream-cdr~1ayXVW~19399 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 3 ); /*  stream-car~1ayXVW~19398 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 4 ); /*  stream-null?~1ayXVW~19379 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 5 ); /*  stream-pair?~1ayXVW~19378 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 6 ); /*  stream-kdr~1ayXVW~19375 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 7 ); /*  stream-kar~1ayXVW~19373 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 8 ); /*  stream-pare?~1ayXVW~19371 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 9 ); /*  make-stream-pare~1ayXVW~19369 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 10 ); /*  ignored~1ayXVW~19367 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 11 ); /*  stream-pare-type~1ayXVW~19365 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 12 ); /*  stream-null~1ayXVW~19360 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 13 ); /*  stream-force~1ayXVW~19359 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 14 ); /*  stream-eager~1ayXVW~19343 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 15 ); /*  stream-promise!~1ayXVW~19327 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 16 ); /*  stream-promise~1ayXVW~19325 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 17 ); /*  stream?~1ayXVW~19323 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 18 ); /*  make-stream~1ayXVW~19321 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 19 ); /*  ignored~1ayXVW~19319 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 20 ); /*  stream-type~1ayXVW~19317 */
  twobit_const( 21 );
  twobit_setreg( 1 );
  twobit_const( 22 );
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_global( 23 ); /* make-rtd */
  twobit_setrtn( 1064, compiled_block_1_1064 );
  twobit_invoke( 3 );
  twobit_label( 1064, compiled_block_1_1064 );
  twobit_load( 0, 0 );
  twobit_setglbl( 20 ); /*  stream-type~1ayXVW~19317 */
  twobit_global( 20 ); /*  stream-type~1ayXVW~19317 */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_global( 24 ); /* make-record-constructor-descriptor */
  twobit_setrtn( 1065, compiled_block_1_1065 );
  twobit_invoke( 3 );
  twobit_label( 1065, compiled_block_1_1065 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 20 ); /*  stream-type~1ayXVW~19317 */
  twobit_setreg( 1 );
  twobit_global( 25 ); /*  preferred-cd-set!~1ayXVW~2073 */
  twobit_setrtn( 1066, compiled_block_1_1066 );
  twobit_invoke( 2 );
  twobit_label( 1066, compiled_block_1_1066 );
  twobit_load( 0, 0 );
  twobit_setglbl( 19 ); /*  ignored~1ayXVW~19319 */
  twobit_global( 20 ); /*  stream-type~1ayXVW~19317 */
  twobit_setreg( 1 );
  twobit_global( 26 ); /*  preferred-cd~1ayXVW~2072 */
  twobit_setrtn( 1067, compiled_block_1_1067 );
  twobit_invoke( 1 );
  twobit_label( 1067, compiled_block_1_1067 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 27 ); /* record-constructor */
  twobit_setrtn( 1068, compiled_block_1_1068 );
  twobit_invoke( 1 );
  twobit_label( 1068, compiled_block_1_1068 );
  twobit_load( 0, 0 );
  twobit_setglbl( 18 ); /*  make-stream~1ayXVW~19321 */
  twobit_global( 20 ); /*  stream-type~1ayXVW~19317 */
  twobit_setreg( 1 );
  twobit_global( 28 ); /* rtd-predicate */
  twobit_setrtn( 1069, compiled_block_1_1069 );
  twobit_invoke( 1 );
  twobit_label( 1069, compiled_block_1_1069 );
  twobit_load( 0, 0 );
  twobit_setglbl( 17 ); /*  stream?~1ayXVW~19323 */
  twobit_global( 20 ); /*  stream-type~1ayXVW~19317 */
  twobit_setreg( 1 );
  twobit_const( 29 );
  twobit_setreg( 2 );
  twobit_global( 30 ); /* rtd-accessor */
  twobit_setrtn( 1070, compiled_block_1_1070 );
  twobit_invoke( 2 );
  twobit_label( 1070, compiled_block_1_1070 );
  twobit_load( 0, 0 );
  twobit_setglbl( 16 ); /*  stream-promise~1ayXVW~19325 */
  twobit_global( 20 ); /*  stream-type~1ayXVW~19317 */
  twobit_setreg( 1 );
  twobit_const( 29 );
  twobit_setreg( 2 );
  twobit_global( 31 ); /* rtd-mutator */
  twobit_setrtn( 1071, compiled_block_1_1071 );
  twobit_invoke( 2 );
  twobit_label( 1071, compiled_block_1_1071 );
  twobit_load( 0, 0 );
  twobit_setglbl( 15 ); /*  stream-promise!~1ayXVW~19327 */
  twobit_lambda( compiled_start_1_4, 33, 0 );
  twobit_setglbl( 14 ); /*  stream-eager~1ayXVW~19343 */
  twobit_lambda( compiled_start_1_5, 35, 0 );
  twobit_setglbl( 13 ); /*  stream-force~1ayXVW~19359 */
  twobit_lambda( compiled_start_1_6, 37, 0 );
  twobit_setreg( 4 );
  twobit_const( 38 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 18 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1089, compiled_block_1_1089 );
  twobit_invoke( 1 );
  twobit_label( 1089, compiled_block_1_1089 );
  twobit_load( 0, 0 );
  twobit_setglbl( 12 ); /*  stream-null~1ayXVW~19360 */
  twobit_const( 39 );
  twobit_setreg( 1 );
  twobit_const( 40 );
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_global( 23 ); /* make-rtd */
  twobit_setrtn( 1090, compiled_block_1_1090 );
  twobit_invoke( 3 );
  twobit_label( 1090, compiled_block_1_1090 );
  twobit_load( 0, 0 );
  twobit_setglbl( 11 ); /*  stream-pare-type~1ayXVW~19365 */
  twobit_global( 11 ); /*  stream-pare-type~1ayXVW~19365 */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_global( 24 ); /* make-record-constructor-descriptor */
  twobit_setrtn( 1091, compiled_block_1_1091 );
  twobit_invoke( 3 );
  twobit_label( 1091, compiled_block_1_1091 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 11 ); /*  stream-pare-type~1ayXVW~19365 */
  twobit_setreg( 1 );
  twobit_global( 25 ); /*  preferred-cd-set!~1ayXVW~2073 */
  twobit_setrtn( 1092, compiled_block_1_1092 );
  twobit_invoke( 2 );
  twobit_label( 1092, compiled_block_1_1092 );
  twobit_load( 0, 0 );
  twobit_setglbl( 10 ); /*  ignored~1ayXVW~19367 */
  twobit_global( 11 ); /*  stream-pare-type~1ayXVW~19365 */
  twobit_setreg( 1 );
  twobit_global( 26 ); /*  preferred-cd~1ayXVW~2072 */
  twobit_setrtn( 1093, compiled_block_1_1093 );
  twobit_invoke( 1 );
  twobit_label( 1093, compiled_block_1_1093 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 27 ); /* record-constructor */
  twobit_setrtn( 1094, compiled_block_1_1094 );
  twobit_invoke( 1 );
  twobit_label( 1094, compiled_block_1_1094 );
  twobit_load( 0, 0 );
  twobit_setglbl( 9 ); /*  make-stream-pare~1ayXVW~19369 */
  twobit_global( 11 ); /*  stream-pare-type~1ayXVW~19365 */
  twobit_setreg( 1 );
  twobit_global( 28 ); /* rtd-predicate */
  twobit_setrtn( 1095, compiled_block_1_1095 );
  twobit_invoke( 1 );
  twobit_label( 1095, compiled_block_1_1095 );
  twobit_load( 0, 0 );
  twobit_setglbl( 8 ); /*  stream-pare?~1ayXVW~19371 */
  twobit_global( 11 ); /*  stream-pare-type~1ayXVW~19365 */
  twobit_setreg( 1 );
  twobit_const( 41 );
  twobit_setreg( 2 );
  twobit_global( 30 ); /* rtd-accessor */
  twobit_setrtn( 1096, compiled_block_1_1096 );
  twobit_invoke( 2 );
  twobit_label( 1096, compiled_block_1_1096 );
  twobit_load( 0, 0 );
  twobit_setglbl( 7 ); /*  stream-kar~1ayXVW~19373 */
  twobit_global( 11 ); /*  stream-pare-type~1ayXVW~19365 */
  twobit_setreg( 1 );
  twobit_const( 42 );
  twobit_setreg( 2 );
  twobit_global( 30 ); /* rtd-accessor */
  twobit_setrtn( 1097, compiled_block_1_1097 );
  twobit_invoke( 2 );
  twobit_label( 1097, compiled_block_1_1097 );
  twobit_load( 0, 0 );
  twobit_setglbl( 6 ); /*  stream-kdr~1ayXVW~19375 */
  twobit_lambda( compiled_start_1_7, 44, 0 );
  twobit_setglbl( 5 ); /*  stream-pair?~1ayXVW~19378 */
  twobit_lambda( compiled_start_1_8, 46, 0 );
  twobit_setglbl( 4 ); /*  stream-null?~1ayXVW~19379 */
  twobit_lambda( compiled_start_1_9, 48, 0 );
  twobit_setglbl( 3 ); /*  stream-car~1ayXVW~19398 */
  twobit_lambda( compiled_start_1_10, 50, 0 );
  twobit_setglbl( 2 ); /*  stream-cdr~1ayXVW~19399 */
  twobit_global( 51 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_const( 1 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  make-stream~1ayXVW~19321 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  stream-promise~1ayXVW~19325 */
  twobit_setrtn( 1073, compiled_block_1_1073 );
  twobit_invoke( 1 );
  twobit_label( 1073, compiled_block_1_1073 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1074,compiled_block_1_1074); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2_branchf_624( 2, 1076, compiled_block_1_1076 ); /* internal:branchf-eq? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1076, compiled_block_1_1076 );
  twobit_const( 3 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2_branchf_624( 2, 1078, compiled_block_1_1078 ); /* internal:branchf-eq? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1079, compiled_block_1_1079 );
  twobit_invoke( 0 );
  twobit_label( 1079, compiled_block_1_1079 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 1 ); /*  stream-promise~1ayXVW~19325 */
  twobit_setrtn( 1080, compiled_block_1_1080 );
  twobit_invoke( 1 );
  twobit_label( 1080, compiled_block_1_1080 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg_op1_check_652(reg(4),1074,compiled_block_1_1074); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_const_setreg( 2, 2 );
  twobit_op2_57( 2, 12, compiled_temp_1_12 ); /* eqv? */
  twobit_branchf( 1082, compiled_block_1_1082 );
  twobit_op1_3(); /* unspecified */
  twobit_skip( 1081, compiled_block_1_1081 );
  twobit_label( 1082, compiled_block_1_1082 );
  twobit_load( 1, 2 );
  twobit_global( 1 ); /*  stream-promise~1ayXVW~19325 */
  twobit_setrtn( 1083, compiled_block_1_1083 );
  twobit_invoke( 1 );
  twobit_label( 1083, compiled_block_1_1083 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1074,compiled_block_1_1074); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_59( 4 ); /* set-car! */
  twobit_load( 1, 2 );
  twobit_global( 1 ); /*  stream-promise~1ayXVW~19325 */
  twobit_setrtn( 1084, compiled_block_1_1084 );
  twobit_invoke( 1 );
  twobit_label( 1084, compiled_block_1_1084 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1085,compiled_block_1_1085); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_60( 4 ); /* set-cdr! */
  twobit_load( 1, 2 );
  twobit_load( 2, 3 );
  twobit_global( 4 ); /*  stream-promise!~1ayXVW~19327 */
  twobit_setrtn( 1086, compiled_block_1_1086 );
  twobit_invoke( 2 );
  twobit_label( 1086, compiled_block_1_1086 );
  twobit_load( 0, 0 );
  twobit_label( 1081, compiled_block_1_1081 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /*  stream-force~1ayXVW~19359 */
  twobit_pop( 3 );
  twobit_invoke( 1 );
  twobit_label( 1078, compiled_block_1_1078 );
  twobit_op1_3(); /* unspecified */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1074, compiled_block_1_1074 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 1085, compiled_block_1_1085 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_6( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_const( 1 );
  twobit_setreg( 4 );
  twobit_const( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  stream-eager~1ayXVW~19343 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_7( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  stream?~1ayXVW~19323 */
  twobit_setrtn( 1098, compiled_block_1_1098 );
  twobit_invoke( 1 );
  twobit_label( 1098, compiled_block_1_1098 );
  twobit_load( 0, 0 );
  twobit_branchf( 1100, compiled_block_1_1100 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  stream-force~1ayXVW~19359 */
  twobit_setrtn( 1101, compiled_block_1_1101 );
  twobit_invoke( 1 );
  twobit_label( 1101, compiled_block_1_1101 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  stream-pare?~1ayXVW~19371 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1100, compiled_block_1_1100 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_8( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  stream?~1ayXVW~19323 */
  twobit_setrtn( 1103, compiled_block_1_1103 );
  twobit_invoke( 1 );
  twobit_label( 1103, compiled_block_1_1103 );
  twobit_load( 0, 0 );
  twobit_branchf( 1105, compiled_block_1_1105 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  stream-force~1ayXVW~19359 */
  twobit_setrtn( 1106, compiled_block_1_1106 );
  twobit_invoke( 1 );
  twobit_label( 1106, compiled_block_1_1106 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_global( 3 ); /*  stream-null~1ayXVW~19360 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  stream-force~1ayXVW~19359 */
  twobit_setrtn( 1107, compiled_block_1_1107 );
  twobit_invoke( 1 );
  twobit_label( 1107, compiled_block_1_1107 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_57( 4, 11, compiled_temp_1_11 ); /* eqv? */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1105, compiled_block_1_1105 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_9( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  stream?~1ayXVW~19323 */
  twobit_setrtn( 1108, compiled_block_1_1108 );
  twobit_invoke( 1 );
  twobit_label( 1108, compiled_block_1_1108 );
  twobit_load( 0, 0 );
  twobit_branchf( 1110, compiled_block_1_1110 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  stream-null?~1ayXVW~19379 */
  twobit_setrtn( 1111, compiled_block_1_1111 );
  twobit_invoke( 1 );
  twobit_label( 1111, compiled_block_1_1111 );
  twobit_load( 0, 0 );
  twobit_branchf( 1113, compiled_block_1_1113 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_const( 4 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* error */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1113, compiled_block_1_1113 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /*  stream-force~1ayXVW~19359 */
  twobit_setrtn( 1115, compiled_block_1_1115 );
  twobit_invoke( 1 );
  twobit_label( 1115, compiled_block_1_1115 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /*  stream-kar~1ayXVW~19373 */
  twobit_setrtn( 1116, compiled_block_1_1116 );
  twobit_invoke( 1 );
  twobit_label( 1116, compiled_block_1_1116 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  stream-force~1ayXVW~19359 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1110, compiled_block_1_1110 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* error */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_10( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  stream?~1ayXVW~19323 */
  twobit_setrtn( 1119, compiled_block_1_1119 );
  twobit_invoke( 1 );
  twobit_label( 1119, compiled_block_1_1119 );
  twobit_load( 0, 0 );
  twobit_branchf( 1121, compiled_block_1_1121 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  stream-null?~1ayXVW~19379 */
  twobit_setrtn( 1122, compiled_block_1_1122 );
  twobit_invoke( 1 );
  twobit_label( 1122, compiled_block_1_1122 );
  twobit_load( 0, 0 );
  twobit_branchf( 1124, compiled_block_1_1124 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_const( 4 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* error */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1124, compiled_block_1_1124 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /*  stream-force~1ayXVW~19359 */
  twobit_setrtn( 1126, compiled_block_1_1126 );
  twobit_invoke( 1 );
  twobit_label( 1126, compiled_block_1_1126 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /*  stream-kdr~1ayXVW~19375 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1121, compiled_block_1_1121 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* error */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


RTYPE twobit_thunk_af55553616217b7f1700476cfd289013_0(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_1_0(CONT_ACTUALS));
}
static RTYPE compiled_block_2_2043( CONT_PARAMS );
static RTYPE compiled_block_2_2042( CONT_PARAMS );
static RTYPE compiled_start_2_0( CONT_PARAMS );
static RTYPE compiled_start_2_3( CONT_PARAMS );
static RTYPE compiled_block_2_2018( CONT_PARAMS );
static RTYPE compiled_block_2_2026( CONT_PARAMS );
static RTYPE compiled_block_2_2024( CONT_PARAMS );
static RTYPE compiled_block_2_2021( CONT_PARAMS );
static RTYPE compiled_start_2_27( CONT_PARAMS );
static RTYPE compiled_block_2_2038( CONT_PARAMS );
static RTYPE compiled_block_2_2037( CONT_PARAMS );
static RTYPE compiled_block_2_2034( CONT_PARAMS );
static RTYPE compiled_block_2_2031( CONT_PARAMS );
static RTYPE compiled_block_2_2029( CONT_PARAMS );
static RTYPE compiled_start_2_29( CONT_PARAMS );
static RTYPE compiled_block_2_2035( CONT_PARAMS );
static RTYPE compiled_start_2_31( CONT_PARAMS );
static RTYPE compiled_block_2_2032( CONT_PARAMS );
static RTYPE compiled_start_2_30( CONT_PARAMS );
static RTYPE compiled_block_2_2023( CONT_PARAMS );
static RTYPE compiled_start_2_28( CONT_PARAMS );
static RTYPE compiled_block_2_1973( CONT_PARAMS );
static RTYPE compiled_block_2_1972( CONT_PARAMS );
static RTYPE compiled_block_2_1982( CONT_PARAMS );
static RTYPE compiled_block_2_1971( CONT_PARAMS );
static RTYPE compiled_block_2_1976( CONT_PARAMS );
static RTYPE compiled_block_2_1977( CONT_PARAMS );
static RTYPE compiled_start_2_26( CONT_PARAMS );
static RTYPE compiled_start_2_36( CONT_PARAMS );
static RTYPE compiled_block_2_2014( CONT_PARAMS );
static RTYPE compiled_block_2_2013( CONT_PARAMS );
static RTYPE compiled_block_2_2011( CONT_PARAMS );
static RTYPE compiled_start_2_38( CONT_PARAMS );
static RTYPE compiled_start_2_40( CONT_PARAMS );
static RTYPE compiled_start_2_39( CONT_PARAMS );
static RTYPE compiled_start_2_37( CONT_PARAMS );
static RTYPE compiled_block_2_2006( CONT_PARAMS );
static RTYPE compiled_block_2_2002( CONT_PARAMS );
static RTYPE compiled_block_2_2004( CONT_PARAMS );
static RTYPE compiled_block_2_1992( CONT_PARAMS );
static RTYPE compiled_block_2_1999( CONT_PARAMS );
static RTYPE compiled_block_2_1998( CONT_PARAMS );
static RTYPE compiled_block_2_1995( CONT_PARAMS );
static RTYPE compiled_block_2_1990( CONT_PARAMS );
static RTYPE compiled_block_2_1989( CONT_PARAMS );
static RTYPE compiled_temp_2_41( CONT_PARAMS );
static RTYPE compiled_start_2_35( CONT_PARAMS );
static RTYPE compiled_block_2_1996( CONT_PARAMS );
static RTYPE compiled_start_2_43( CONT_PARAMS );
static RTYPE compiled_block_2_1993( CONT_PARAMS );
static RTYPE compiled_start_2_42( CONT_PARAMS );
static RTYPE compiled_block_2_1986( CONT_PARAMS );
static RTYPE compiled_temp_2_45( CONT_PARAMS );
static RTYPE compiled_block_2_1984( CONT_PARAMS );
static RTYPE compiled_temp_2_44( CONT_PARAMS );
static RTYPE compiled_start_2_34( CONT_PARAMS );
static RTYPE compiled_temp_2_46( CONT_PARAMS );
static RTYPE compiled_block_2_1981( CONT_PARAMS );
static RTYPE compiled_start_2_33( CONT_PARAMS );
static RTYPE compiled_start_2_32( CONT_PARAMS );
static RTYPE compiled_block_2_1947( CONT_PARAMS );
static RTYPE compiled_block_2_1950( CONT_PARAMS );
static RTYPE compiled_block_2_1952( CONT_PARAMS );
static RTYPE compiled_block_2_1954( CONT_PARAMS );
static RTYPE compiled_start_2_25( CONT_PARAMS );
static RTYPE compiled_block_2_1961( CONT_PARAMS );
static RTYPE compiled_block_2_1968( CONT_PARAMS );
static RTYPE compiled_block_2_1967( CONT_PARAMS );
static RTYPE compiled_block_2_1964( CONT_PARAMS );
static RTYPE compiled_block_2_1959( CONT_PARAMS );
static RTYPE compiled_start_2_47( CONT_PARAMS );
static RTYPE compiled_block_2_1965( CONT_PARAMS );
static RTYPE compiled_start_2_49( CONT_PARAMS );
static RTYPE compiled_block_2_1962( CONT_PARAMS );
static RTYPE compiled_start_2_48( CONT_PARAMS );
static RTYPE compiled_block_2_1921( CONT_PARAMS );
static RTYPE compiled_block_2_1925( CONT_PARAMS );
static RTYPE compiled_block_2_1927( CONT_PARAMS );
static RTYPE compiled_block_2_1923( CONT_PARAMS );
static RTYPE compiled_start_2_24( CONT_PARAMS );
static RTYPE compiled_block_2_1937( CONT_PARAMS );
static RTYPE compiled_block_2_1944( CONT_PARAMS );
static RTYPE compiled_block_2_1943( CONT_PARAMS );
static RTYPE compiled_block_2_1940( CONT_PARAMS );
static RTYPE compiled_block_2_1935( CONT_PARAMS );
static RTYPE compiled_block_2_1934( CONT_PARAMS );
static RTYPE compiled_block_2_1933( CONT_PARAMS );
static RTYPE compiled_block_2_1931( CONT_PARAMS );
static RTYPE compiled_start_2_50( CONT_PARAMS );
static RTYPE compiled_block_2_1941( CONT_PARAMS );
static RTYPE compiled_start_2_52( CONT_PARAMS );
static RTYPE compiled_block_2_1938( CONT_PARAMS );
static RTYPE compiled_start_2_51( CONT_PARAMS );
static RTYPE compiled_block_2_1894( CONT_PARAMS );
static RTYPE compiled_block_2_1898( CONT_PARAMS );
static RTYPE compiled_block_2_1900( CONT_PARAMS );
static RTYPE compiled_block_2_1902( CONT_PARAMS );
static RTYPE compiled_temp_2_53( CONT_PARAMS );
static RTYPE compiled_block_2_1896( CONT_PARAMS );
static RTYPE compiled_start_2_23( CONT_PARAMS );
static RTYPE compiled_block_2_1918( CONT_PARAMS );
static RTYPE compiled_block_2_1917( CONT_PARAMS );
static RTYPE compiled_block_2_1914( CONT_PARAMS );
static RTYPE compiled_block_2_1911( CONT_PARAMS );
static RTYPE compiled_block_2_1908( CONT_PARAMS );
static RTYPE compiled_temp_2_55( CONT_PARAMS );
static RTYPE compiled_block_2_1909( CONT_PARAMS );
static RTYPE compiled_block_2_1907( CONT_PARAMS );
static RTYPE compiled_start_2_54( CONT_PARAMS );
static RTYPE compiled_block_2_1915( CONT_PARAMS );
static RTYPE compiled_temp_2_58( CONT_PARAMS );
static RTYPE compiled_start_2_57( CONT_PARAMS );
static RTYPE compiled_block_2_1912( CONT_PARAMS );
static RTYPE compiled_start_2_56( CONT_PARAMS );
static RTYPE compiled_block_2_1866( CONT_PARAMS );
static RTYPE compiled_block_2_1869( CONT_PARAMS );
static RTYPE compiled_block_2_1872( CONT_PARAMS );
static RTYPE compiled_block_2_1870( CONT_PARAMS );
static RTYPE compiled_start_2_22( CONT_PARAMS );
static RTYPE compiled_block_2_1891( CONT_PARAMS );
static RTYPE compiled_block_2_1890( CONT_PARAMS );
static RTYPE compiled_block_2_1885( CONT_PARAMS );
static RTYPE compiled_block_2_1878( CONT_PARAMS );
static RTYPE compiled_block_2_1882( CONT_PARAMS );
static RTYPE compiled_block_2_1881( CONT_PARAMS );
static RTYPE compiled_block_2_1880( CONT_PARAMS );
static RTYPE compiled_block_2_1876( CONT_PARAMS );
static RTYPE compiled_start_2_59( CONT_PARAMS );
static RTYPE compiled_block_2_1888( CONT_PARAMS );
static RTYPE compiled_block_2_1887( CONT_PARAMS );
static RTYPE compiled_block_2_1886( CONT_PARAMS );
static RTYPE compiled_start_2_63( CONT_PARAMS );
static RTYPE compiled_start_2_62( CONT_PARAMS );
static RTYPE compiled_start_2_61( CONT_PARAMS );
static RTYPE compiled_start_2_60( CONT_PARAMS );
static RTYPE compiled_block_2_1847( CONT_PARAMS );
static RTYPE compiled_block_2_1851( CONT_PARAMS );
static RTYPE compiled_block_2_1849( CONT_PARAMS );
static RTYPE compiled_start_2_21( CONT_PARAMS );
static RTYPE compiled_block_2_1863( CONT_PARAMS );
static RTYPE compiled_block_2_1862( CONT_PARAMS );
static RTYPE compiled_block_2_1861( CONT_PARAMS );
static RTYPE compiled_block_2_1860( CONT_PARAMS );
static RTYPE compiled_block_2_1857( CONT_PARAMS );
static RTYPE compiled_block_2_1856( CONT_PARAMS );
static RTYPE compiled_block_2_1854( CONT_PARAMS );
static RTYPE compiled_start_2_64( CONT_PARAMS );
static RTYPE compiled_start_2_66( CONT_PARAMS );
static RTYPE compiled_block_2_1858( CONT_PARAMS );
static RTYPE compiled_start_2_65( CONT_PARAMS );
static RTYPE compiled_block_2_1829( CONT_PARAMS );
static RTYPE compiled_block_2_1831( CONT_PARAMS );
static RTYPE compiled_block_2_1833( CONT_PARAMS );
static RTYPE compiled_temp_2_67( CONT_PARAMS );
static RTYPE compiled_block_2_1827( CONT_PARAMS );
static RTYPE compiled_start_2_20( CONT_PARAMS );
static RTYPE compiled_block_2_1842( CONT_PARAMS );
static RTYPE compiled_temp_2_70( CONT_PARAMS );
static RTYPE compiled_block_2_1840( CONT_PARAMS );
static RTYPE compiled_temp_2_69( CONT_PARAMS );
static RTYPE compiled_block_2_1837( CONT_PARAMS );
static RTYPE compiled_block_2_1835( CONT_PARAMS );
static RTYPE compiled_start_2_68( CONT_PARAMS );
static RTYPE compiled_block_2_1799( CONT_PARAMS );
static RTYPE compiled_block_2_1802( CONT_PARAMS );
static RTYPE compiled_block_2_1804( CONT_PARAMS );
static RTYPE compiled_block_2_1810( CONT_PARAMS );
static RTYPE compiled_block_2_1811( CONT_PARAMS );
static RTYPE compiled_block_2_1812( CONT_PARAMS );
static RTYPE compiled_temp_2_72( CONT_PARAMS );
static RTYPE compiled_block_2_1805( CONT_PARAMS );
static RTYPE compiled_block_2_1808( CONT_PARAMS );
static RTYPE compiled_temp_2_71( CONT_PARAMS );
static RTYPE compiled_block_2_1806( CONT_PARAMS );
static RTYPE compiled_start_2_19( CONT_PARAMS );
static RTYPE compiled_block_2_1819( CONT_PARAMS );
static RTYPE compiled_block_2_1824( CONT_PARAMS );
static RTYPE compiled_block_2_1823( CONT_PARAMS );
static RTYPE compiled_block_2_1821( CONT_PARAMS );
static RTYPE compiled_block_2_1817( CONT_PARAMS );
static RTYPE compiled_start_2_73( CONT_PARAMS );
static RTYPE compiled_temp_2_76( CONT_PARAMS );
static RTYPE compiled_start_2_75( CONT_PARAMS );
static RTYPE compiled_start_2_74( CONT_PARAMS );
static RTYPE compiled_block_2_1772( CONT_PARAMS );
static RTYPE compiled_block_2_1775( CONT_PARAMS );
static RTYPE compiled_block_2_1782( CONT_PARAMS );
static RTYPE compiled_block_2_1780( CONT_PARAMS );
static RTYPE compiled_block_2_1777( CONT_PARAMS );
static RTYPE compiled_start_2_18( CONT_PARAMS );
static RTYPE compiled_block_2_1796( CONT_PARAMS );
static RTYPE compiled_block_2_1795( CONT_PARAMS );
static RTYPE compiled_block_2_1792( CONT_PARAMS );
static RTYPE compiled_block_2_1788( CONT_PARAMS );
static RTYPE compiled_block_2_1786( CONT_PARAMS );
static RTYPE compiled_start_2_78( CONT_PARAMS );
static RTYPE compiled_block_2_1793( CONT_PARAMS );
static RTYPE compiled_start_2_80( CONT_PARAMS );
static RTYPE compiled_block_2_1790( CONT_PARAMS );
static RTYPE compiled_block_2_1789( CONT_PARAMS );
static RTYPE compiled_start_2_79( CONT_PARAMS );
static RTYPE compiled_block_2_1779( CONT_PARAMS );
static RTYPE compiled_start_2_77( CONT_PARAMS );
static RTYPE compiled_block_2_1764( CONT_PARAMS );
static RTYPE compiled_block_2_1762( CONT_PARAMS );
static RTYPE compiled_start_2_17( CONT_PARAMS );
static RTYPE compiled_block_2_1768( CONT_PARAMS );
static RTYPE compiled_temp_2_82( CONT_PARAMS );
static RTYPE compiled_block_2_1767( CONT_PARAMS );
static RTYPE compiled_block_2_1765( CONT_PARAMS );
static RTYPE compiled_start_2_81( CONT_PARAMS );
static RTYPE compiled_block_2_1748( CONT_PARAMS );
static RTYPE compiled_block_2_1751( CONT_PARAMS );
static RTYPE compiled_start_2_16( CONT_PARAMS );
static RTYPE compiled_block_2_1759( CONT_PARAMS );
static RTYPE compiled_block_2_1758( CONT_PARAMS );
static RTYPE compiled_block_2_1755( CONT_PARAMS );
static RTYPE compiled_start_2_83( CONT_PARAMS );
static RTYPE compiled_block_2_1756( CONT_PARAMS );
static RTYPE compiled_start_2_85( CONT_PARAMS );
static RTYPE compiled_start_2_84( CONT_PARAMS );
static RTYPE compiled_block_2_1733( CONT_PARAMS );
static RTYPE compiled_block_2_1729( CONT_PARAMS );
static RTYPE compiled_block_2_1735( CONT_PARAMS );
static RTYPE compiled_block_2_1737( CONT_PARAMS );
static RTYPE compiled_block_2_1731( CONT_PARAMS );
static RTYPE compiled_block_2_1732( CONT_PARAMS );
static RTYPE compiled_start_2_15( CONT_PARAMS );
static RTYPE compiled_block_2_1745( CONT_PARAMS );
static RTYPE compiled_block_2_1744( CONT_PARAMS );
static RTYPE compiled_block_2_1742( CONT_PARAMS );
static RTYPE compiled_start_2_86( CONT_PARAMS );
static RTYPE compiled_temp_2_89( CONT_PARAMS );
static RTYPE compiled_start_2_88( CONT_PARAMS );
static RTYPE compiled_start_2_87( CONT_PARAMS );
static RTYPE compiled_block_2_1727( CONT_PARAMS );
static RTYPE compiled_block_2_1726( CONT_PARAMS );
static RTYPE compiled_block_2_1725( CONT_PARAMS );
static RTYPE compiled_block_2_1724( CONT_PARAMS );
static RTYPE compiled_block_2_1722( CONT_PARAMS );
static RTYPE compiled_block_2_1708( CONT_PARAMS );
static RTYPE compiled_block_2_1711( CONT_PARAMS );
static RTYPE compiled_block_2_1718( CONT_PARAMS );
static RTYPE compiled_block_2_1716( CONT_PARAMS );
static RTYPE compiled_block_2_1713( CONT_PARAMS );
static RTYPE compiled_start_2_14( CONT_PARAMS );
static RTYPE compiled_block_2_1715( CONT_PARAMS );
static RTYPE compiled_start_2_90( CONT_PARAMS );
static RTYPE compiled_block_2_1694( CONT_PARAMS );
static RTYPE compiled_block_2_1697( CONT_PARAMS );
static RTYPE compiled_block_2_1695( CONT_PARAMS );
static RTYPE compiled_start_2_13( CONT_PARAMS );
static RTYPE compiled_block_2_1703( CONT_PARAMS );
static RTYPE compiled_block_2_1702( CONT_PARAMS );
static RTYPE compiled_block_2_1701( CONT_PARAMS );
static RTYPE compiled_block_2_1700( CONT_PARAMS );
static RTYPE compiled_block_2_1698( CONT_PARAMS );
static RTYPE compiled_start_2_91( CONT_PARAMS );
static RTYPE compiled_block_2_1665( CONT_PARAMS );
static RTYPE compiled_block_2_1668( CONT_PARAMS );
static RTYPE compiled_block_2_1671( CONT_PARAMS );
static RTYPE compiled_block_2_1669( CONT_PARAMS );
static RTYPE compiled_start_2_12( CONT_PARAMS );
static RTYPE compiled_block_2_1690( CONT_PARAMS );
static RTYPE compiled_block_2_1681( CONT_PARAMS );
static RTYPE compiled_block_2_1688( CONT_PARAMS );
static RTYPE compiled_block_2_1687( CONT_PARAMS );
static RTYPE compiled_block_2_1684( CONT_PARAMS );
static RTYPE compiled_block_2_1679( CONT_PARAMS );
static RTYPE compiled_block_2_1678( CONT_PARAMS );
static RTYPE compiled_block_2_1677( CONT_PARAMS );
static RTYPE compiled_block_2_1675( CONT_PARAMS );
static RTYPE compiled_start_2_92( CONT_PARAMS );
static RTYPE compiled_block_2_1685( CONT_PARAMS );
static RTYPE compiled_start_2_94( CONT_PARAMS );
static RTYPE compiled_block_2_1682( CONT_PARAMS );
static RTYPE compiled_start_2_93( CONT_PARAMS );
static RTYPE compiled_block_2_1645( CONT_PARAMS );
static RTYPE compiled_block_2_1648( CONT_PARAMS );
static RTYPE compiled_block_2_1651( CONT_PARAMS );
static RTYPE compiled_block_2_1649( CONT_PARAMS );
static RTYPE compiled_start_2_11( CONT_PARAMS );
static RTYPE compiled_block_2_1661( CONT_PARAMS );
static RTYPE compiled_block_2_1662( CONT_PARAMS );
static RTYPE compiled_block_2_1656( CONT_PARAMS );
static RTYPE compiled_block_2_1657( CONT_PARAMS );
static RTYPE compiled_block_2_1659( CONT_PARAMS );
static RTYPE compiled_block_2_1658( CONT_PARAMS );
static RTYPE compiled_block_2_1655( CONT_PARAMS );
static RTYPE compiled_start_2_95( CONT_PARAMS );
static RTYPE compiled_block_2_1624( CONT_PARAMS );
static RTYPE compiled_block_2_1627( CONT_PARAMS );
static RTYPE compiled_block_2_1633( CONT_PARAMS );
static RTYPE compiled_block_2_1631( CONT_PARAMS );
static RTYPE compiled_block_2_1629( CONT_PARAMS );
static RTYPE compiled_temp_2_96( CONT_PARAMS );
static RTYPE compiled_start_2_10( CONT_PARAMS );
static RTYPE compiled_block_2_1642( CONT_PARAMS );
static RTYPE compiled_temp_2_99( CONT_PARAMS );
static RTYPE compiled_block_2_1641( CONT_PARAMS );
static RTYPE compiled_block_2_1637( CONT_PARAMS );
static RTYPE compiled_block_2_1639( CONT_PARAMS );
static RTYPE compiled_block_2_1638( CONT_PARAMS );
static RTYPE compiled_temp_2_98( CONT_PARAMS );
static RTYPE compiled_start_2_97( CONT_PARAMS );
static RTYPE compiled_start_2_9( CONT_PARAMS );
static RTYPE compiled_block_2_1607( CONT_PARAMS );
static RTYPE compiled_block_2_1621( CONT_PARAMS );
static RTYPE compiled_block_2_1620( CONT_PARAMS );
static RTYPE compiled_block_2_1617( CONT_PARAMS );
static RTYPE compiled_block_2_1609( CONT_PARAMS );
static RTYPE compiled_block_2_1614( CONT_PARAMS );
static RTYPE compiled_block_2_1613( CONT_PARAMS );
static RTYPE compiled_block_2_1611( CONT_PARAMS );
static RTYPE compiled_block_2_1606( CONT_PARAMS );
static RTYPE compiled_start_2_100( CONT_PARAMS );
static RTYPE compiled_block_2_1618( CONT_PARAMS );
static RTYPE compiled_start_2_104( CONT_PARAMS );
static RTYPE compiled_start_2_103( CONT_PARAMS );
static RTYPE compiled_start_2_102( CONT_PARAMS );
static RTYPE compiled_start_2_101( CONT_PARAMS );
static RTYPE compiled_block_2_1567( CONT_PARAMS );
static RTYPE compiled_block_2_1571( CONT_PARAMS );
static RTYPE compiled_block_2_1569( CONT_PARAMS );
static RTYPE compiled_start_2_8( CONT_PARAMS );
static RTYPE compiled_block_2_1580( CONT_PARAMS );
static RTYPE compiled_block_2_1601( CONT_PARAMS );
static RTYPE compiled_block_2_1600( CONT_PARAMS );
static RTYPE compiled_block_2_1590( CONT_PARAMS );
static RTYPE compiled_block_2_1584( CONT_PARAMS );
static RTYPE compiled_block_2_1585( CONT_PARAMS );
static RTYPE compiled_block_2_1582( CONT_PARAMS );
static RTYPE compiled_block_2_1581( CONT_PARAMS );
static RTYPE compiled_block_2_1578( CONT_PARAMS );
static RTYPE compiled_block_2_1577( CONT_PARAMS );
static RTYPE compiled_block_2_1576( CONT_PARAMS );
static RTYPE compiled_block_2_1574( CONT_PARAMS );
static RTYPE compiled_start_2_105( CONT_PARAMS );
static RTYPE compiled_block_2_1598( CONT_PARAMS );
static RTYPE compiled_block_2_1597( CONT_PARAMS );
static RTYPE compiled_block_2_1596( CONT_PARAMS );
static RTYPE compiled_block_2_1594( CONT_PARAMS );
static RTYPE compiled_start_2_107( CONT_PARAMS );
static RTYPE compiled_start_2_109( CONT_PARAMS );
static RTYPE compiled_block_2_1592( CONT_PARAMS );
static RTYPE compiled_block_2_1591( CONT_PARAMS );
static RTYPE compiled_start_2_108( CONT_PARAMS );
static RTYPE compiled_block_2_1588( CONT_PARAMS );
static RTYPE compiled_block_2_1587( CONT_PARAMS );
static RTYPE compiled_start_2_106( CONT_PARAMS );
static RTYPE compiled_block_2_1541( CONT_PARAMS );
static RTYPE compiled_block_2_1548( CONT_PARAMS );
static RTYPE compiled_block_2_1546( CONT_PARAMS );
static RTYPE compiled_block_2_1544( CONT_PARAMS );
static RTYPE compiled_start_2_7( CONT_PARAMS );
static RTYPE compiled_block_2_1551( CONT_PARAMS );
static RTYPE compiled_block_2_1564( CONT_PARAMS );
static RTYPE compiled_block_2_1563( CONT_PARAMS );
static RTYPE compiled_block_2_1560( CONT_PARAMS );
static RTYPE compiled_block_2_1556( CONT_PARAMS );
static RTYPE compiled_block_2_1554( CONT_PARAMS );
static RTYPE compiled_block_2_1553( CONT_PARAMS );
static RTYPE compiled_start_2_111( CONT_PARAMS );
static RTYPE compiled_block_2_1561( CONT_PARAMS );
static RTYPE compiled_start_2_113( CONT_PARAMS );
static RTYPE compiled_block_2_1558( CONT_PARAMS );
static RTYPE compiled_start_2_112( CONT_PARAMS );
static RTYPE compiled_block_2_1545( CONT_PARAMS );
static RTYPE compiled_start_2_110( CONT_PARAMS );
static RTYPE compiled_block_2_1510( CONT_PARAMS );
static RTYPE compiled_block_2_1511( CONT_PARAMS );
static RTYPE compiled_block_2_1512( CONT_PARAMS );
static RTYPE compiled_block_2_1518( CONT_PARAMS );
static RTYPE compiled_block_2_1529( CONT_PARAMS );
static RTYPE compiled_block_2_1530( CONT_PARAMS );
static RTYPE compiled_block_2_1527( CONT_PARAMS );
static RTYPE compiled_block_2_1524( CONT_PARAMS );
static RTYPE compiled_block_2_1525( CONT_PARAMS );
static RTYPE compiled_temp_2_116( CONT_PARAMS );
static RTYPE compiled_block_2_1522( CONT_PARAMS );
static RTYPE compiled_block_2_1519( CONT_PARAMS );
static RTYPE compiled_block_2_1520( CONT_PARAMS );
static RTYPE compiled_block_2_1516( CONT_PARAMS );
static RTYPE compiled_block_2_1514( CONT_PARAMS );
static RTYPE compiled_block_2_1515( CONT_PARAMS );
static RTYPE compiled_temp_2_115( CONT_PARAMS );
static RTYPE compiled_block_2_1513( CONT_PARAMS );
static RTYPE compiled_block_2_1508( CONT_PARAMS );
static RTYPE compiled_block_2_1509( CONT_PARAMS );
static RTYPE compiled_temp_2_114( CONT_PARAMS );
static RTYPE compiled_block_2_1507( CONT_PARAMS );
static RTYPE compiled_start_2_6( CONT_PARAMS );
static RTYPE compiled_block_2_1538( CONT_PARAMS );
static RTYPE compiled_block_2_1537( CONT_PARAMS );
static RTYPE compiled_temp_2_119( CONT_PARAMS );
static RTYPE compiled_block_2_1536( CONT_PARAMS );
static RTYPE compiled_block_2_1535( CONT_PARAMS );
static RTYPE compiled_block_2_1531( CONT_PARAMS );
static RTYPE compiled_block_2_1533( CONT_PARAMS );
static RTYPE compiled_block_2_1532( CONT_PARAMS );
static RTYPE compiled_temp_2_118( CONT_PARAMS );
static RTYPE compiled_start_2_117( CONT_PARAMS );
static RTYPE compiled_block_2_1483( CONT_PARAMS );
static RTYPE compiled_block_2_1478( CONT_PARAMS );
static RTYPE compiled_block_2_1486( CONT_PARAMS );
static RTYPE compiled_block_2_1484( CONT_PARAMS );
static RTYPE compiled_block_2_1480( CONT_PARAMS );
static RTYPE compiled_block_2_1481( CONT_PARAMS );
static RTYPE compiled_block_2_1482( CONT_PARAMS );
static RTYPE compiled_start_2_5( CONT_PARAMS );
static RTYPE compiled_block_2_1489( CONT_PARAMS );
static RTYPE compiled_block_2_1492( CONT_PARAMS );
static RTYPE compiled_block_2_1504( CONT_PARAMS );
static RTYPE compiled_block_2_1503( CONT_PARAMS );
static RTYPE compiled_block_2_1501( CONT_PARAMS );
static RTYPE compiled_block_2_1499( CONT_PARAMS );
static RTYPE compiled_block_2_1495( CONT_PARAMS );
static RTYPE compiled_block_2_1497( CONT_PARAMS );
static RTYPE compiled_block_2_1496( CONT_PARAMS );
static RTYPE compiled_block_2_1493( CONT_PARAMS );
static RTYPE compiled_block_2_1494( CONT_PARAMS );
static RTYPE compiled_block_2_1490( CONT_PARAMS );
static RTYPE compiled_block_2_1491( CONT_PARAMS );
static RTYPE compiled_start_2_120( CONT_PARAMS );
static RTYPE compiled_start_2_122( CONT_PARAMS );
static RTYPE compiled_start_2_121( CONT_PARAMS );
static RTYPE compiled_block_2_1460( CONT_PARAMS );
static RTYPE compiled_block_2_1464( CONT_PARAMS );
static RTYPE compiled_block_2_1462( CONT_PARAMS );
static RTYPE compiled_start_2_4( CONT_PARAMS );
static RTYPE compiled_block_2_1475( CONT_PARAMS );
static RTYPE compiled_block_2_1474( CONT_PARAMS );
static RTYPE compiled_block_2_1471( CONT_PARAMS );
static RTYPE compiled_block_2_1468( CONT_PARAMS );
static RTYPE compiled_start_2_123( CONT_PARAMS );
static RTYPE compiled_block_2_1472( CONT_PARAMS );
static RTYPE compiled_start_2_125( CONT_PARAMS );
static RTYPE compiled_block_2_1469( CONT_PARAMS );
static RTYPE compiled_start_2_124( CONT_PARAMS );
static RTYPE compiled_block_2_1458( CONT_PARAMS );
static RTYPE compiled_block_2_1335( CONT_PARAMS );
static RTYPE compiled_block_2_1322( CONT_PARAMS );
static RTYPE compiled_block_2_1165( CONT_PARAMS );
static RTYPE compiled_block_2_1112( CONT_PARAMS );
static RTYPE compiled_block_2_1075( CONT_PARAMS );
static RTYPE compiled_block_2_1042( CONT_PARAMS );
static RTYPE compiled_block_2_1020( CONT_PARAMS );
static RTYPE compiled_start_2_2( CONT_PARAMS );
static RTYPE compiled_block_2_1410( CONT_PARAMS );
static RTYPE compiled_block_2_1412( CONT_PARAMS );
static RTYPE compiled_block_2_1414( CONT_PARAMS );
static RTYPE compiled_block_2_1416( CONT_PARAMS );
static RTYPE compiled_block_2_1418( CONT_PARAMS );
static RTYPE compiled_block_2_1420( CONT_PARAMS );
static RTYPE compiled_block_2_1427( CONT_PARAMS );
static RTYPE compiled_block_2_1429( CONT_PARAMS );
static RTYPE compiled_block_2_1431( CONT_PARAMS );
static RTYPE compiled_block_2_1434( CONT_PARAMS );
static RTYPE compiled_block_2_1447( CONT_PARAMS );
static RTYPE compiled_block_2_1446( CONT_PARAMS );
static RTYPE compiled_block_2_1445( CONT_PARAMS );
static RTYPE compiled_block_2_1444( CONT_PARAMS );
static RTYPE compiled_block_2_1443( CONT_PARAMS );
static RTYPE compiled_block_2_1442( CONT_PARAMS );
static RTYPE compiled_block_2_1441( CONT_PARAMS );
static RTYPE compiled_block_2_1440( CONT_PARAMS );
static RTYPE compiled_block_2_1439( CONT_PARAMS );
static RTYPE compiled_block_2_1438( CONT_PARAMS );
static RTYPE compiled_block_2_1437( CONT_PARAMS );
static RTYPE compiled_block_2_1436( CONT_PARAMS );
static RTYPE compiled_block_2_1435( CONT_PARAMS );
static RTYPE compiled_block_2_1432( CONT_PARAMS );
static RTYPE compiled_block_2_1422( CONT_PARAMS );
static RTYPE compiled_block_2_1423( CONT_PARAMS );
static RTYPE compiled_block_2_1425( CONT_PARAMS );
static RTYPE compiled_block_2_1424( CONT_PARAMS );
static RTYPE compiled_block_2_1421( CONT_PARAMS );
static RTYPE compiled_block_2_1338( CONT_PARAMS );
static RTYPE compiled_block_2_1372( CONT_PARAMS );
static RTYPE compiled_block_2_1374( CONT_PARAMS );
static RTYPE compiled_block_2_1376( CONT_PARAMS );
static RTYPE compiled_block_2_1378( CONT_PARAMS );
static RTYPE compiled_block_2_1380( CONT_PARAMS );
static RTYPE compiled_block_2_1382( CONT_PARAMS );
static RTYPE compiled_block_2_1389( CONT_PARAMS );
static RTYPE compiled_block_2_1391( CONT_PARAMS );
static RTYPE compiled_block_2_1393( CONT_PARAMS );
static RTYPE compiled_block_2_1396( CONT_PARAMS );
static RTYPE compiled_block_2_1398( CONT_PARAMS );
static RTYPE compiled_block_2_1397( CONT_PARAMS );
static RTYPE compiled_block_2_1394( CONT_PARAMS );
static RTYPE compiled_block_2_1384( CONT_PARAMS );
static RTYPE compiled_block_2_1385( CONT_PARAMS );
static RTYPE compiled_block_2_1387( CONT_PARAMS );
static RTYPE compiled_block_2_1386( CONT_PARAMS );
static RTYPE compiled_block_2_1383( CONT_PARAMS );
static RTYPE compiled_block_2_1337( CONT_PARAMS );
static RTYPE compiled_block_2_1354( CONT_PARAMS );
static RTYPE compiled_block_2_1356( CONT_PARAMS );
static RTYPE compiled_block_2_1358( CONT_PARAMS );
static RTYPE compiled_block_2_1360( CONT_PARAMS );
static RTYPE compiled_block_2_1363( CONT_PARAMS );
static RTYPE compiled_block_2_1365( CONT_PARAMS );
static RTYPE compiled_block_2_1364( CONT_PARAMS );
static RTYPE compiled_block_2_1361( CONT_PARAMS );
static RTYPE compiled_block_2_1336( CONT_PARAMS );
static RTYPE compiled_block_2_1341( CONT_PARAMS );
static RTYPE compiled_block_2_1343( CONT_PARAMS );
static RTYPE compiled_block_2_1345( CONT_PARAMS );
static RTYPE compiled_block_2_1347( CONT_PARAMS );
static RTYPE compiled_block_2_1348( CONT_PARAMS );
static RTYPE compiled_start_2_133( CONT_PARAMS );
static RTYPE compiled_block_2_1324( CONT_PARAMS );
static RTYPE compiled_block_2_1326( CONT_PARAMS );
static RTYPE compiled_block_2_1329( CONT_PARAMS );
static RTYPE compiled_block_2_1331( CONT_PARAMS );
static RTYPE compiled_block_2_1330( CONT_PARAMS );
static RTYPE compiled_block_2_1327( CONT_PARAMS );
static RTYPE compiled_start_2_132( CONT_PARAMS );
static RTYPE compiled_block_2_1286( CONT_PARAMS );
static RTYPE compiled_block_2_1288( CONT_PARAMS );
static RTYPE compiled_block_2_1290( CONT_PARAMS );
static RTYPE compiled_block_2_1292( CONT_PARAMS );
static RTYPE compiled_block_2_1294( CONT_PARAMS );
static RTYPE compiled_block_2_1297( CONT_PARAMS );
static RTYPE compiled_block_2_1299( CONT_PARAMS );
static RTYPE compiled_block_2_1301( CONT_PARAMS );
static RTYPE compiled_block_2_1308( CONT_PARAMS );
static RTYPE compiled_block_2_1312( CONT_PARAMS );
static RTYPE compiled_block_2_1311( CONT_PARAMS );
static RTYPE compiled_block_2_1310( CONT_PARAMS );
static RTYPE compiled_block_2_1309( CONT_PARAMS );
static RTYPE compiled_block_2_1303( CONT_PARAMS );
static RTYPE compiled_block_2_1304( CONT_PARAMS );
static RTYPE compiled_block_2_1306( CONT_PARAMS );
static RTYPE compiled_block_2_1305( CONT_PARAMS );
static RTYPE compiled_block_2_1302( CONT_PARAMS );
static RTYPE compiled_block_2_1295( CONT_PARAMS );
static RTYPE compiled_block_2_1169( CONT_PARAMS );
static RTYPE compiled_block_2_1254( CONT_PARAMS );
static RTYPE compiled_block_2_1256( CONT_PARAMS );
static RTYPE compiled_block_2_1258( CONT_PARAMS );
static RTYPE compiled_block_2_1260( CONT_PARAMS );
static RTYPE compiled_block_2_1262( CONT_PARAMS );
static RTYPE compiled_block_2_1265( CONT_PARAMS );
static RTYPE compiled_block_2_1267( CONT_PARAMS );
static RTYPE compiled_block_2_1269( CONT_PARAMS );
static RTYPE compiled_block_2_1276( CONT_PARAMS );
static RTYPE compiled_block_2_1275( CONT_PARAMS );
static RTYPE compiled_block_2_1274( CONT_PARAMS );
static RTYPE compiled_block_2_1273( CONT_PARAMS );
static RTYPE compiled_block_2_1272( CONT_PARAMS );
static RTYPE compiled_block_2_1271( CONT_PARAMS );
static RTYPE compiled_block_2_1270( CONT_PARAMS );
static RTYPE compiled_block_2_1263( CONT_PARAMS );
static RTYPE compiled_block_2_1168( CONT_PARAMS );
static RTYPE compiled_block_2_1223( CONT_PARAMS );
static RTYPE compiled_block_2_1225( CONT_PARAMS );
static RTYPE compiled_block_2_1227( CONT_PARAMS );
static RTYPE compiled_block_2_1229( CONT_PARAMS );
static RTYPE compiled_block_2_1232( CONT_PARAMS );
static RTYPE compiled_block_2_1234( CONT_PARAMS );
static RTYPE compiled_block_2_1236( CONT_PARAMS );
static RTYPE compiled_block_2_1243( CONT_PARAMS );
static RTYPE compiled_block_2_1244( CONT_PARAMS );
static RTYPE compiled_block_2_1238( CONT_PARAMS );
static RTYPE compiled_block_2_1239( CONT_PARAMS );
static RTYPE compiled_block_2_1241( CONT_PARAMS );
static RTYPE compiled_block_2_1240( CONT_PARAMS );
static RTYPE compiled_block_2_1237( CONT_PARAMS );
static RTYPE compiled_block_2_1230( CONT_PARAMS );
static RTYPE compiled_block_2_1167( CONT_PARAMS );
static RTYPE compiled_block_2_1200( CONT_PARAMS );
static RTYPE compiled_block_2_1202( CONT_PARAMS );
static RTYPE compiled_block_2_1204( CONT_PARAMS );
static RTYPE compiled_block_2_1206( CONT_PARAMS );
static RTYPE compiled_block_2_1209( CONT_PARAMS );
static RTYPE compiled_block_2_1211( CONT_PARAMS );
static RTYPE compiled_block_2_1213( CONT_PARAMS );
static RTYPE compiled_block_2_1214( CONT_PARAMS );
static RTYPE compiled_block_2_1207( CONT_PARAMS );
static RTYPE compiled_block_2_1166( CONT_PARAMS );
static RTYPE compiled_block_2_1172( CONT_PARAMS );
static RTYPE compiled_block_2_1174( CONT_PARAMS );
static RTYPE compiled_block_2_1176( CONT_PARAMS );
static RTYPE compiled_block_2_1178( CONT_PARAMS );
static RTYPE compiled_block_2_1180( CONT_PARAMS );
static RTYPE compiled_block_2_1183( CONT_PARAMS );
static RTYPE compiled_block_2_1185( CONT_PARAMS );
static RTYPE compiled_block_2_1187( CONT_PARAMS );
static RTYPE compiled_block_2_1190( CONT_PARAMS );
static RTYPE compiled_block_2_1189( CONT_PARAMS );
static RTYPE compiled_block_2_1188( CONT_PARAMS );
static RTYPE compiled_block_2_1181( CONT_PARAMS );
static RTYPE compiled_start_2_131( CONT_PARAMS );
static RTYPE compiled_block_2_1143( CONT_PARAMS );
static RTYPE compiled_block_2_1145( CONT_PARAMS );
static RTYPE compiled_block_2_1147( CONT_PARAMS );
static RTYPE compiled_block_2_1149( CONT_PARAMS );
static RTYPE compiled_block_2_1151( CONT_PARAMS );
static RTYPE compiled_block_2_1153( CONT_PARAMS );
static RTYPE compiled_block_2_1155( CONT_PARAMS );
static RTYPE compiled_block_2_1157( CONT_PARAMS );
static RTYPE compiled_block_2_1156( CONT_PARAMS );
static RTYPE compiled_block_2_1113( CONT_PARAMS );
static RTYPE compiled_block_2_1116( CONT_PARAMS );
static RTYPE compiled_block_2_1118( CONT_PARAMS );
static RTYPE compiled_block_2_1120( CONT_PARAMS );
static RTYPE compiled_block_2_1122( CONT_PARAMS );
static RTYPE compiled_block_2_1124( CONT_PARAMS );
static RTYPE compiled_block_2_1126( CONT_PARAMS );
static RTYPE compiled_block_2_1128( CONT_PARAMS );
static RTYPE compiled_block_2_1130( CONT_PARAMS );
static RTYPE compiled_block_2_1133( CONT_PARAMS );
static RTYPE compiled_block_2_1132( CONT_PARAMS );
static RTYPE compiled_block_2_1131( CONT_PARAMS );
static RTYPE compiled_start_2_130( CONT_PARAMS );
static RTYPE compiled_block_2_1106( CONT_PARAMS );
static RTYPE compiled_block_2_1110( CONT_PARAMS );
static RTYPE compiled_block_2_1109( CONT_PARAMS );
static RTYPE compiled_block_2_1108( CONT_PARAMS );
static RTYPE compiled_block_2_1107( CONT_PARAMS );
static RTYPE compiled_block_2_1104( CONT_PARAMS );
static RTYPE compiled_block_2_1076( CONT_PARAMS );
static RTYPE compiled_block_2_1079( CONT_PARAMS );
static RTYPE compiled_block_2_1081( CONT_PARAMS );
static RTYPE compiled_block_2_1084( CONT_PARAMS );
static RTYPE compiled_block_2_1099( CONT_PARAMS );
static RTYPE compiled_block_2_1098( CONT_PARAMS );
static RTYPE compiled_block_2_1097( CONT_PARAMS );
static RTYPE compiled_block_2_1096( CONT_PARAMS );
static RTYPE compiled_block_2_1095( CONT_PARAMS );
static RTYPE compiled_block_2_1094( CONT_PARAMS );
static RTYPE compiled_block_2_1093( CONT_PARAMS );
static RTYPE compiled_block_2_1092( CONT_PARAMS );
static RTYPE compiled_block_2_1091( CONT_PARAMS );
static RTYPE compiled_block_2_1090( CONT_PARAMS );
static RTYPE compiled_block_2_1089( CONT_PARAMS );
static RTYPE compiled_block_2_1088( CONT_PARAMS );
static RTYPE compiled_block_2_1087( CONT_PARAMS );
static RTYPE compiled_block_2_1086( CONT_PARAMS );
static RTYPE compiled_block_2_1085( CONT_PARAMS );
static RTYPE compiled_block_2_1082( CONT_PARAMS );
static RTYPE compiled_start_2_129( CONT_PARAMS );
static RTYPE compiled_block_2_1044( CONT_PARAMS );
static RTYPE compiled_block_2_1046( CONT_PARAMS );
static RTYPE compiled_block_2_1048( CONT_PARAMS );
static RTYPE compiled_start_2_128( CONT_PARAMS );
static RTYPE compiled_block_2_1056( CONT_PARAMS );
static RTYPE compiled_block_2_1066( CONT_PARAMS );
static RTYPE compiled_block_2_1068( CONT_PARAMS );
static RTYPE compiled_block_2_1067( CONT_PARAMS );
static RTYPE compiled_start_2_135( CONT_PARAMS );
static RTYPE compiled_block_2_1058( CONT_PARAMS );
static RTYPE compiled_block_2_1061( CONT_PARAMS );
static RTYPE compiled_block_2_1063( CONT_PARAMS );
static RTYPE compiled_block_2_1062( CONT_PARAMS );
static RTYPE compiled_block_2_1059( CONT_PARAMS );
static RTYPE compiled_start_2_136( CONT_PARAMS );
static RTYPE compiled_block_2_1050( CONT_PARAMS );
static RTYPE compiled_block_2_1052( CONT_PARAMS );
static RTYPE compiled_block_2_1054( CONT_PARAMS );
static RTYPE compiled_start_2_134( CONT_PARAMS );
static RTYPE compiled_block_2_1031( CONT_PARAMS );
static RTYPE compiled_block_2_1033( CONT_PARAMS );
static RTYPE compiled_block_2_1036( CONT_PARAMS );
static RTYPE compiled_block_2_1038( CONT_PARAMS );
static RTYPE compiled_block_2_1037( CONT_PARAMS );
static RTYPE compiled_block_2_1034( CONT_PARAMS );
static RTYPE compiled_block_2_1021( CONT_PARAMS );
static RTYPE compiled_block_2_1024( CONT_PARAMS );
static RTYPE compiled_block_2_1026( CONT_PARAMS );
static RTYPE compiled_start_2_127( CONT_PARAMS );
static RTYPE compiled_block_2_1003( CONT_PARAMS );
static RTYPE compiled_block_2_1005( CONT_PARAMS );
static RTYPE compiled_block_2_1007( CONT_PARAMS );
static RTYPE compiled_block_2_1009( CONT_PARAMS );
static RTYPE compiled_block_2_1012( CONT_PARAMS );
static RTYPE compiled_block_2_1014( CONT_PARAMS );
static RTYPE compiled_block_2_1013( CONT_PARAMS );
static RTYPE compiled_block_2_1010( CONT_PARAMS );
static RTYPE compiled_start_2_126( CONT_PARAMS );
static RTYPE compiled_start_2_1( CONT_PARAMS );

static RTYPE compiled_start_2_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 2 ); /*  stream-zip~1ayXVW~19850 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 3 ); /*  stream-unfolds~1ayXVW~19849 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 4 ); /*  stream-unfold~1ayXVW~19848 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 5 ); /*  stream-take-while~1ayXVW~19847 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 6 ); /*  stream-take~1ayXVW~19846 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 7 ); /*  stream-scan~1ayXVW~19845 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 8 ); /*  stream-reverse~1ayXVW~19844 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 9 ); /*  stream-ref~1ayXVW~19843 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 10 ); /*  stream-range~1ayXVW~19842 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 11 ); /*  stream-map~1ayXVW~19577 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 12 ); /*  stream-length~1ayXVW~19547 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 13 ); /*  stream-iterate~1ayXVW~19546 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 14 ); /*  stream-from~1ayXVW~19545 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 15 ); /*  stream-for-each~1ayXVW~19544 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 16 ); /*  stream-fold~1ayXVW~19543 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 17 ); /*  stream-filter~1ayXVW~19542 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 18 ); /*  stream-drop-while~1ayXVW~19541 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 19 ); /*  stream-drop~1ayXVW~19540 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 20 ); /*  stream-constant~1ayXVW~19539 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 21 ); /*  stream-concat~1ayXVW~19538 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 22 ); /*  stream-append~1ayXVW~19537 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 23 ); /*  stream->list~1ayXVW~19536 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 24 ); /*  port->stream~1ayXVW~19513 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 25 ); /*  list->stream~1ayXVW~19512 */
  twobit_lambda( compiled_start_2_1, 27, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_2_2, 29, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_2_3, 31, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 32 );
  twobit_setreg( 1 );
  twobit_const( 33 );
  twobit_setreg( 3 );
  twobit_const( 34 );
  twobit_setreg( 4 );
  twobit_const( 35 );
  twobit_setreg( 5 );
  twobit_const( 36 );
  twobit_setreg( 8 );
  twobit_global( 37 ); /* ex:make-library */
  twobit_setrtn( 2042, compiled_block_2_2042 );
  twobit_invoke( 8 );
  twobit_label( 2042, compiled_block_2_2042 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 38 ); /* ex:register-library! */
  twobit_setrtn( 2043, compiled_block_2_2043 );
  twobit_invoke( 1 );
  twobit_label( 2043, compiled_block_2_2043 );
  twobit_load( 0, 0 );
  twobit_global( 39 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* ex:uncompress */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_126, 2, 0 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1020, compiled_block_2_1020 );
  twobit_invoke( 2 );
  twobit_label( 1020, compiled_block_2_1020 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_2_127, 6, 0 );
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1042, compiled_block_2_1042 );
  twobit_invoke( 2 );
  twobit_label( 1042, compiled_block_2_1042 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_2_128, 9, 0 );
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1075, compiled_block_2_1075 );
  twobit_invoke( 2 );
  twobit_label( 1075, compiled_block_2_1075 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_2_129, 12, 0 );
  twobit_setreg( 2 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1112, compiled_block_2_1112 );
  twobit_invoke( 2 );
  twobit_label( 1112, compiled_block_2_1112 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_2_130, 15, 0 );
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1165, compiled_block_2_1165 );
  twobit_invoke( 2 );
  twobit_label( 1165, compiled_block_2_1165 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_2_131, 18, 0 );
  twobit_setreg( 2 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1322, compiled_block_2_1322 );
  twobit_invoke( 2 );
  twobit_label( 1322, compiled_block_2_1322 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_2_132, 21, 0 );
  twobit_setreg( 2 );
  twobit_const( 22 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1335, compiled_block_2_1335 );
  twobit_invoke( 2 );
  twobit_label( 1335, compiled_block_2_1335 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_2_133, 24, 0 );
  twobit_setreg( 2 );
  twobit_const( 25 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1458, compiled_block_2_1458 );
  twobit_invoke( 2 );
  twobit_label( 1458, compiled_block_2_1458 );
  twobit_load( 0, 0 );
  twobit_global( 26 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_126( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1003, compiled_block_2_1003 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1005, compiled_block_2_1005 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1007, compiled_block_2_1007 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1009, compiled_block_2_1009 ); /* internal:branchf-pair? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 2, 4 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1010, compiled_block_2_1010 );
  twobit_invoke( 1 );
  twobit_label( 1010, compiled_block_2_1010 );
  twobit_load( 0, 0 );
  twobit_branchf( 1012, compiled_block_2_1012 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1013, compiled_block_2_1013 );
  twobit_invoke( 5 );
  twobit_label( 1013, compiled_block_2_1013 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 3, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1014, compiled_block_2_1014 );
  twobit_invoke( 5 );
  twobit_label( 1014, compiled_block_2_1014 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1012, compiled_block_2_1012 );
  twobit_load( 1, 6 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_pop( 6 );
  twobit_invoke( 1 );
  twobit_label( 1009, compiled_block_2_1009 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1007, compiled_block_2_1007 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1005, compiled_block_2_1005 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1003, compiled_block_2_1003 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_127( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1024, compiled_block_2_1024 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1026, compiled_block_2_1026 ); /* internal:branchf-null? */
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_invoke( 5 );
  twobit_label( 1026, compiled_block_2_1026 );
  twobit_branch( 1021, compiled_block_2_1021 );
  twobit_label( 1024, compiled_block_2_1024 );
  twobit_label( 1021, compiled_block_2_1021 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1031, compiled_block_2_1031 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1033, compiled_block_2_1033 ); /* internal:branchf-pair? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* list? */
  twobit_setrtn( 1034, compiled_block_2_1034 );
  twobit_invoke( 1 );
  twobit_label( 1034, compiled_block_2_1034 );
  twobit_load( 0, 0 );
  twobit_branchf( 1036, compiled_block_2_1036 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1037, compiled_block_2_1037 );
  twobit_invoke( 5 );
  twobit_label( 1037, compiled_block_2_1037 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1038, compiled_block_2_1038 );
  twobit_invoke( 5 );
  twobit_label( 1038, compiled_block_2_1038 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1036, compiled_block_2_1036 );
  twobit_load( 1, 4 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 1033, compiled_block_2_1033 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1031, compiled_block_2_1031 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_128( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1044, compiled_block_2_1044 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1046, compiled_block_2_1046 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1048, compiled_block_2_1048 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_lambda( compiled_start_2_134, 2, 0 );
  twobit_setreg( 31 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_2_135, 4, 3 );
  twobit_setreg( 3 );
  twobit_movereg( 31, 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* ex:map-while */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_label( 1048, compiled_block_2_1048 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1046, compiled_block_2_1046 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1044, compiled_block_2_1044 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_134( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1050, compiled_block_2_1050 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1052, compiled_block_2_1052 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1054, compiled_block_2_1054 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_return();
  twobit_label( 1054, compiled_block_2_1054 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1052, compiled_block_2_1052 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1050, compiled_block_2_1050 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_135( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1056, compiled_block_2_1056 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_136, 2, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1067, compiled_block_2_1067 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_skip( 1066, compiled_block_2_1066 );
  twobit_label( 1067, compiled_block_2_1067 );
  twobit_movereg( 1, 3 );
  twobit_global( 4 ); /* map */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* list */
  twobit_setreg( 2 );
  twobit_global( 6 ); /* apply */
  twobit_setrtn( 1068, compiled_block_2_1068 );
  twobit_invoke( 3 );
  twobit_label( 1068, compiled_block_2_1068 );
  twobit_load( 0, 0 );
  twobit_label( 1066, compiled_block_2_1066 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1056, compiled_block_2_1056 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_136( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 1, 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1058, compiled_block_2_1058 ); /* internal:branchf-pair? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 6 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1059, compiled_block_2_1059 );
  twobit_invoke( 1 );
  twobit_label( 1059, compiled_block_2_1059 );
  twobit_load( 0, 0 );
  twobit_branchf( 1061, compiled_block_2_1061 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1062, compiled_block_2_1062 );
  twobit_invoke( 5 );
  twobit_label( 1062, compiled_block_2_1062 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_lexical( 1, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_load( 2, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_stack( 3 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1063, compiled_block_2_1063 );
  twobit_invoke( 5 );
  twobit_label( 1063, compiled_block_2_1063 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_lexical( 1, 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1061, compiled_block_2_1061 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_pop( 6 );
  twobit_invoke( 1 );
  twobit_label( 1058, compiled_block_2_1058 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_129( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1079, compiled_block_2_1079 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1081, compiled_block_2_1081 ); /* internal:branchf-pair? */
  twobit_save( 10 );
  twobit_store( 0, 0 );
  twobit_store( 1, 10 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1082, compiled_block_2_1082 );
  twobit_invoke( 1 );
  twobit_label( 1082, compiled_block_2_1082 );
  twobit_load( 0, 0 );
  twobit_branchf( 1084, compiled_block_2_1084 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1085, compiled_block_2_1085 );
  twobit_invoke( 5 );
  twobit_label( 1085, compiled_block_2_1085 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1086, compiled_block_2_1086 );
  twobit_invoke( 5 );
  twobit_label( 1086, compiled_block_2_1086 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1087, compiled_block_2_1087 );
  twobit_invoke( 5 );
  twobit_label( 1087, compiled_block_2_1087 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1088, compiled_block_2_1088 );
  twobit_invoke( 5 );
  twobit_label( 1088, compiled_block_2_1088 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1089, compiled_block_2_1089 );
  twobit_invoke( 5 );
  twobit_label( 1089, compiled_block_2_1089 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1090, compiled_block_2_1090 );
  twobit_invoke( 5 );
  twobit_label( 1090, compiled_block_2_1090 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1091, compiled_block_2_1091 );
  twobit_invoke( 5 );
  twobit_label( 1091, compiled_block_2_1091 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_const( 11 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1092, compiled_block_2_1092 );
  twobit_invoke( 5 );
  twobit_label( 1092, compiled_block_2_1092 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1093, compiled_block_2_1093 );
  twobit_invoke( 5 );
  twobit_label( 1093, compiled_block_2_1093 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 1, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_setrtn( 1094, compiled_block_2_1094 );
  twobit_branch( 1076, compiled_block_2_1076 );
  twobit_label( 1094, compiled_block_2_1094 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1095, compiled_block_2_1095 );
  twobit_invoke( 5 );
  twobit_label( 1095, compiled_block_2_1095 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1096, compiled_block_2_1096 );
  twobit_invoke( 5 );
  twobit_label( 1096, compiled_block_2_1096 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_const( 15 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1097, compiled_block_2_1097 );
  twobit_invoke( 5 );
  twobit_label( 1097, compiled_block_2_1097 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1098, compiled_block_2_1098 );
  twobit_invoke( 5 );
  twobit_label( 1098, compiled_block_2_1098 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_global( 16 ); /* append */
  twobit_setrtn( 1099, compiled_block_2_1099 );
  twobit_invoke( 2 );
  twobit_label( 1099, compiled_block_2_1099 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 10 );
  twobit_return();
  twobit_label( 1084, compiled_block_2_1084 );
  twobit_load( 1, 10 );
  twobit_global( 17 ); /* ex:invalid-form */
  twobit_pop( 10 );
  twobit_invoke( 1 );
  twobit_label( 1081, compiled_block_2_1081 );
  twobit_global( 17 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1079, compiled_block_2_1079 );
  twobit_global( 17 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1076, compiled_block_2_1076 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1104, compiled_block_2_1104 ); /* internal:branchf-null? */
  twobit_movereg( 2, 1 );
  twobit_global( 18 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1104, compiled_block_2_1104 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 2, 4 );
  twobit_reg_op1_check_652(reg(1),1106,compiled_block_2_1106); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1107, compiled_block_2_1107 );
  twobit_invoke( 5 );
  twobit_label( 1107, compiled_block_2_1107 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1108, compiled_block_2_1108 );
  twobit_invoke( 5 );
  twobit_label( 1108, compiled_block_2_1108 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 20 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1109, compiled_block_2_1109 );
  twobit_invoke( 5 );
  twobit_label( 1109, compiled_block_2_1109 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 21 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1110, compiled_block_2_1110 );
  twobit_invoke( 5 );
  twobit_label( 1110, compiled_block_2_1110 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_pop( 4 );
  twobit_branch( 1076, compiled_block_2_1076 );
  twobit_label( 1106, compiled_block_2_1106 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_130( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1116, compiled_block_2_1116 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1118, compiled_block_2_1118 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1120, compiled_block_2_1120 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1122, compiled_block_2_1122 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1124, compiled_block_2_1124 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1126, compiled_block_2_1126 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 29 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1128, compiled_block_2_1128 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1130, compiled_block_2_1130 ); /* internal:branchf-null? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 3, 5 );
  twobit_store( 29, 1 );
  twobit_store( 30, 2 );
  twobit_store( 31, 4 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1131, compiled_block_2_1131 );
  twobit_invoke( 5 );
  twobit_label( 1131, compiled_block_2_1131 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1132, compiled_block_2_1132 );
  twobit_invoke( 5 );
  twobit_label( 1132, compiled_block_2_1132 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1133, compiled_block_2_1133 );
  twobit_invoke( 5 );
  twobit_label( 1133, compiled_block_2_1133 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1130, compiled_block_2_1130 );
  twobit_branch( 1113, compiled_block_2_1113 );
  twobit_label( 1128, compiled_block_2_1128 );
  twobit_branch( 1113, compiled_block_2_1113 );
  twobit_label( 1126, compiled_block_2_1126 );
  twobit_branch( 1113, compiled_block_2_1113 );
  twobit_label( 1124, compiled_block_2_1124 );
  twobit_branch( 1113, compiled_block_2_1113 );
  twobit_label( 1122, compiled_block_2_1122 );
  twobit_branch( 1113, compiled_block_2_1113 );
  twobit_label( 1120, compiled_block_2_1120 );
  twobit_branch( 1113, compiled_block_2_1113 );
  twobit_label( 1118, compiled_block_2_1118 );
  twobit_branch( 1113, compiled_block_2_1113 );
  twobit_label( 1116, compiled_block_2_1116 );
  twobit_label( 1113, compiled_block_2_1113 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1143, compiled_block_2_1143 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1145, compiled_block_2_1145 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1147, compiled_block_2_1147 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1149, compiled_block_2_1149 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1151, compiled_block_2_1151 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1153, compiled_block_2_1153 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1155, compiled_block_2_1155 ); /* internal:branchf-null? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 3, 3 );
  twobit_store( 30, 1 );
  twobit_store( 31, 2 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1156, compiled_block_2_1156 );
  twobit_invoke( 5 );
  twobit_label( 1156, compiled_block_2_1156 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1157, compiled_block_2_1157 );
  twobit_invoke( 5 );
  twobit_label( 1157, compiled_block_2_1157 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1155, compiled_block_2_1155 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1153, compiled_block_2_1153 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1151, compiled_block_2_1151 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1149, compiled_block_2_1149 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1147, compiled_block_2_1147 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1145, compiled_block_2_1145 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1143, compiled_block_2_1143 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_131( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1172, compiled_block_2_1172 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1174, compiled_block_2_1174 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1176, compiled_block_2_1176 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_op1_branchf_610( 1178, compiled_block_2_1178 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1180, compiled_block_2_1180 ); /* internal:branchf-pair? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 3, 2 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1181, compiled_block_2_1181 );
  twobit_invoke( 1 );
  twobit_label( 1181, compiled_block_2_1181 );
  twobit_load( 0, 0 );
  twobit_branchf( 1183, compiled_block_2_1183 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1185, compiled_block_2_1185 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1187, compiled_block_2_1187 ); /* internal:branchf-null? */
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1188, compiled_block_2_1188 );
  twobit_invoke( 5 );
  twobit_label( 1188, compiled_block_2_1188 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1189, compiled_block_2_1189 );
  twobit_invoke( 5 );
  twobit_label( 1189, compiled_block_2_1189 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1190, compiled_block_2_1190 );
  twobit_invoke( 5 );
  twobit_label( 1190, compiled_block_2_1190 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1187, compiled_block_2_1187 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1169, compiled_block_2_1169 );
  twobit_label( 1185, compiled_block_2_1185 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1169, compiled_block_2_1169 );
  twobit_label( 1183, compiled_block_2_1183 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1169, compiled_block_2_1169 );
  twobit_label( 1180, compiled_block_2_1180 );
  twobit_branch( 1169, compiled_block_2_1169 );
  twobit_label( 1178, compiled_block_2_1178 );
  twobit_branch( 1169, compiled_block_2_1169 );
  twobit_label( 1176, compiled_block_2_1176 );
  twobit_branch( 1169, compiled_block_2_1169 );
  twobit_label( 1174, compiled_block_2_1174 );
  twobit_branch( 1169, compiled_block_2_1169 );
  twobit_label( 1172, compiled_block_2_1172 );
  twobit_branch( 1169, compiled_block_2_1169 );
  twobit_label( 1166, compiled_block_2_1166 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1200, compiled_block_2_1200 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1202, compiled_block_2_1202 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1204, compiled_block_2_1204 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1206, compiled_block_2_1206 ); /* internal:branchf-pair? */
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 5 );
  twobit_store( 2, 3 );
  twobit_store( 3, 2 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 4 );
  twobit_movereg( 31, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1207, compiled_block_2_1207 );
  twobit_invoke( 1 );
  twobit_label( 1207, compiled_block_2_1207 );
  twobit_load( 0, 0 );
  twobit_branchf( 1209, compiled_block_2_1209 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1211, compiled_block_2_1211 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1213, compiled_block_2_1213 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 2, 4 );
  twobit_op2_58( 2 ); /* cons */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1214, compiled_block_2_1214 );
  twobit_invoke( 5 );
  twobit_label( 1214, compiled_block_2_1214 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1213, compiled_block_2_1213 );
  twobit_load( 1, 5 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 1211, compiled_block_2_1211 );
  twobit_load( 1, 5 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 1209, compiled_block_2_1209 );
  twobit_load( 1, 5 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 1206, compiled_block_2_1206 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1204, compiled_block_2_1204 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1202, compiled_block_2_1202 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1200, compiled_block_2_1200 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1167, compiled_block_2_1167 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1223, compiled_block_2_1223 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1225, compiled_block_2_1225 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1227, compiled_block_2_1227 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1229, compiled_block_2_1229 ); /* internal:branchf-pair? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 3, 2 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1230, compiled_block_2_1230 );
  twobit_invoke( 1 );
  twobit_label( 1230, compiled_block_2_1230 );
  twobit_load( 0, 0 );
  twobit_branchf( 1232, compiled_block_2_1232 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1234, compiled_block_2_1234 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1236, compiled_block_2_1236 ); /* internal:branchf-null? */
  twobit_load( 1, 2 );
  twobit_global( 10 ); /* ex:identifier? */
  twobit_setrtn( 1237, compiled_block_2_1237 );
  twobit_invoke( 1 );
  twobit_label( 1237, compiled_block_2_1237 );
  twobit_load( 0, 0 );
  twobit_branchf( 1239, compiled_block_2_1239 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1240, compiled_block_2_1240 );
  twobit_invoke( 5 );
  twobit_label( 1240, compiled_block_2_1240 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 13 ); /* ex:free-identifier=? */
  twobit_setrtn( 1241, compiled_block_2_1241 );
  twobit_invoke( 2 );
  twobit_label( 1241, compiled_block_2_1241 );
  twobit_load( 0, 0 );
  twobit_skip( 1238, compiled_block_2_1238 );
  twobit_label( 1239, compiled_block_2_1239 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1238, compiled_block_2_1238 );
  twobit_branchf( 1243, compiled_block_2_1243 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1244, compiled_block_2_1244 );
  twobit_invoke( 5 );
  twobit_label( 1244, compiled_block_2_1244 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1243, compiled_block_2_1243 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1166, compiled_block_2_1166 );
  twobit_label( 1236, compiled_block_2_1236 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1166, compiled_block_2_1166 );
  twobit_label( 1234, compiled_block_2_1234 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1166, compiled_block_2_1166 );
  twobit_label( 1232, compiled_block_2_1232 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1166, compiled_block_2_1166 );
  twobit_label( 1229, compiled_block_2_1229 );
  twobit_branch( 1166, compiled_block_2_1166 );
  twobit_label( 1227, compiled_block_2_1227 );
  twobit_branch( 1166, compiled_block_2_1166 );
  twobit_label( 1225, compiled_block_2_1225 );
  twobit_branch( 1166, compiled_block_2_1166 );
  twobit_label( 1223, compiled_block_2_1223 );
  twobit_branch( 1166, compiled_block_2_1166 );
  twobit_label( 1168, compiled_block_2_1168 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1254, compiled_block_2_1254 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1256, compiled_block_2_1256 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1258, compiled_block_2_1258 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_branchf_611( 1260, compiled_block_2_1260 ); /* internal:branchf-pair? */
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1262, compiled_block_2_1262 ); /* internal:branchf-pair? */
  twobit_save( 12 );
  twobit_store( 0, 0 );
  twobit_store( 1, 12 );
  twobit_store( 2, 2 );
  twobit_store( 3, 1 );
  twobit_store( 4, 8 );
  twobit_store( 30, 5 );
  twobit_store( 31, 7 );
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 29 );
  twobit_store( 29, 6 );
  twobit_movereg( 29, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1263, compiled_block_2_1263 );
  twobit_invoke( 1 );
  twobit_label( 1263, compiled_block_2_1263 );
  twobit_load( 0, 0 );
  twobit_branchf( 1265, compiled_block_2_1265 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1267, compiled_block_2_1267 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1269, compiled_block_2_1269 ); /* internal:branchf-null? */
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1270, compiled_block_2_1270 );
  twobit_invoke( 5 );
  twobit_label( 1270, compiled_block_2_1270 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1271, compiled_block_2_1271 );
  twobit_invoke( 5 );
  twobit_label( 1271, compiled_block_2_1271 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1272, compiled_block_2_1272 );
  twobit_invoke( 5 );
  twobit_label( 1272, compiled_block_2_1272 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 17 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1273, compiled_block_2_1273 );
  twobit_invoke( 5 );
  twobit_label( 1273, compiled_block_2_1273 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 18 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1274, compiled_block_2_1274 );
  twobit_invoke( 5 );
  twobit_label( 1274, compiled_block_2_1274 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1275, compiled_block_2_1275 );
  twobit_invoke( 5 );
  twobit_label( 1275, compiled_block_2_1275 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_const( 17 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1276, compiled_block_2_1276 );
  twobit_invoke( 5 );
  twobit_label( 1276, compiled_block_2_1276 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 12 );
  twobit_return();
  twobit_label( 1269, compiled_block_2_1269 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1167, compiled_block_2_1167 );
  twobit_label( 1267, compiled_block_2_1267 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1167, compiled_block_2_1167 );
  twobit_label( 1265, compiled_block_2_1265 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1167, compiled_block_2_1167 );
  twobit_label( 1262, compiled_block_2_1262 );
  twobit_branch( 1167, compiled_block_2_1167 );
  twobit_label( 1260, compiled_block_2_1260 );
  twobit_branch( 1167, compiled_block_2_1167 );
  twobit_label( 1258, compiled_block_2_1258 );
  twobit_branch( 1167, compiled_block_2_1167 );
  twobit_label( 1256, compiled_block_2_1256 );
  twobit_branch( 1167, compiled_block_2_1167 );
  twobit_label( 1254, compiled_block_2_1254 );
  twobit_branch( 1167, compiled_block_2_1167 );
  twobit_label( 1169, compiled_block_2_1169 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1286, compiled_block_2_1286 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1288, compiled_block_2_1288 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1290, compiled_block_2_1290 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_branchf_611( 1292, compiled_block_2_1292 ); /* internal:branchf-pair? */
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1294, compiled_block_2_1294 ); /* internal:branchf-pair? */
  twobit_save( 9 );
  twobit_store( 0, 0 );
  twobit_store( 1, 9 );
  twobit_store( 2, 3 );
  twobit_store( 3, 1 );
  twobit_store( 4, 6 );
  twobit_store( 30, 2 );
  twobit_store( 31, 5 );
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 29 );
  twobit_store( 29, 4 );
  twobit_movereg( 29, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1295, compiled_block_2_1295 );
  twobit_invoke( 1 );
  twobit_label( 1295, compiled_block_2_1295 );
  twobit_load( 0, 0 );
  twobit_branchf( 1297, compiled_block_2_1297 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1299, compiled_block_2_1299 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1301, compiled_block_2_1301 ); /* internal:branchf-null? */
  twobit_load( 1, 2 );
  twobit_global( 10 ); /* ex:identifier? */
  twobit_setrtn( 1302, compiled_block_2_1302 );
  twobit_invoke( 1 );
  twobit_label( 1302, compiled_block_2_1302 );
  twobit_load( 0, 0 );
  twobit_branchf( 1304, compiled_block_2_1304 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1305, compiled_block_2_1305 );
  twobit_invoke( 5 );
  twobit_label( 1305, compiled_block_2_1305 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 13 ); /* ex:free-identifier=? */
  twobit_setrtn( 1306, compiled_block_2_1306 );
  twobit_invoke( 2 );
  twobit_label( 1306, compiled_block_2_1306 );
  twobit_load( 0, 0 );
  twobit_skip( 1303, compiled_block_2_1303 );
  twobit_label( 1304, compiled_block_2_1304 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1303, compiled_block_2_1303 );
  twobit_branchf( 1308, compiled_block_2_1308 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 20 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1309, compiled_block_2_1309 );
  twobit_invoke( 5 );
  twobit_label( 1309, compiled_block_2_1309 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 20 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1310, compiled_block_2_1310 );
  twobit_invoke( 5 );
  twobit_label( 1310, compiled_block_2_1310 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 20 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1311, compiled_block_2_1311 );
  twobit_invoke( 5 );
  twobit_label( 1311, compiled_block_2_1311 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 2 ); /* () */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 3 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 6 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 20 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1312, compiled_block_2_1312 );
  twobit_invoke( 5 );
  twobit_label( 1312, compiled_block_2_1312 );
  twobit_load( 0, 0 );
  twobit_load( 3, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 9 );
  twobit_return();
  twobit_label( 1308, compiled_block_2_1308 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1168, compiled_block_2_1168 );
  twobit_label( 1301, compiled_block_2_1301 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1168, compiled_block_2_1168 );
  twobit_label( 1299, compiled_block_2_1299 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1168, compiled_block_2_1168 );
  twobit_label( 1297, compiled_block_2_1297 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1168, compiled_block_2_1168 );
  twobit_label( 1294, compiled_block_2_1294 );
  twobit_branch( 1168, compiled_block_2_1168 );
  twobit_label( 1292, compiled_block_2_1292 );
  twobit_branch( 1168, compiled_block_2_1168 );
  twobit_label( 1290, compiled_block_2_1290 );
  twobit_branch( 1168, compiled_block_2_1168 );
  twobit_label( 1288, compiled_block_2_1288 );
  twobit_branch( 1168, compiled_block_2_1168 );
  twobit_label( 1286, compiled_block_2_1286 );
  twobit_branch( 1168, compiled_block_2_1168 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_132( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1324, compiled_block_2_1324 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1326, compiled_block_2_1326 ); /* internal:branchf-pair? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1327, compiled_block_2_1327 );
  twobit_invoke( 1 );
  twobit_label( 1327, compiled_block_2_1327 );
  twobit_load( 0, 0 );
  twobit_branchf( 1329, compiled_block_2_1329 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1330, compiled_block_2_1330 );
  twobit_invoke( 5 );
  twobit_label( 1330, compiled_block_2_1330 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1331, compiled_block_2_1331 );
  twobit_invoke( 5 );
  twobit_label( 1331, compiled_block_2_1331 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1329, compiled_block_2_1329 );
  twobit_load( 1, 4 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 1326, compiled_block_2_1326 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1324, compiled_block_2_1324 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_133( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1341, compiled_block_2_1341 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1343, compiled_block_2_1343 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1345, compiled_block_2_1345 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1347, compiled_block_2_1347 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1348, compiled_block_2_1348 );
  twobit_invoke( 5 );
  twobit_label( 1348, compiled_block_2_1348 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1347, compiled_block_2_1347 );
  twobit_branch( 1338, compiled_block_2_1338 );
  twobit_label( 1345, compiled_block_2_1345 );
  twobit_branch( 1338, compiled_block_2_1338 );
  twobit_label( 1343, compiled_block_2_1343 );
  twobit_branch( 1338, compiled_block_2_1338 );
  twobit_label( 1341, compiled_block_2_1341 );
  twobit_branch( 1338, compiled_block_2_1338 );
  twobit_label( 1336, compiled_block_2_1336 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1354, compiled_block_2_1354 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1356, compiled_block_2_1356 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1358, compiled_block_2_1358 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1360, compiled_block_2_1360 ); /* internal:branchf-pair? */
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 7 );
  twobit_store( 2, 1 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 5 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* list? */
  twobit_setrtn( 1361, compiled_block_2_1361 );
  twobit_invoke( 1 );
  twobit_label( 1361, compiled_block_2_1361 );
  twobit_load( 0, 0 );
  twobit_branchf( 1363, compiled_block_2_1363 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1364, compiled_block_2_1364 );
  twobit_invoke( 5 );
  twobit_label( 1364, compiled_block_2_1364 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_load( 2, 2 );
  twobit_stack( 1 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_stack( 3 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1365, compiled_block_2_1365 );
  twobit_invoke( 5 );
  twobit_label( 1365, compiled_block_2_1365 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1363, compiled_block_2_1363 );
  twobit_load( 1, 7 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_pop( 7 );
  twobit_invoke( 1 );
  twobit_label( 1360, compiled_block_2_1360 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1358, compiled_block_2_1358 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1356, compiled_block_2_1356 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1354, compiled_block_2_1354 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1337, compiled_block_2_1337 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1372, compiled_block_2_1372 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1374, compiled_block_2_1374 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1376, compiled_block_2_1376 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1378, compiled_block_2_1378 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_branchf_611( 1380, compiled_block_2_1380 ); /* internal:branchf-pair? */
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_branchf_611( 1382, compiled_block_2_1382 ); /* internal:branchf-pair? */
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 7 );
  twobit_store( 2, 5 );
  twobit_store( 3, 6 );
  twobit_store( 4, 3 );
  twobit_store( 30, 4 );
  twobit_store( 31, 2 );
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 29 );
  twobit_store( 29, 1 );
  twobit_movereg( 29, 1 );
  twobit_global( 10 ); /* ex:identifier? */
  twobit_setrtn( 1383, compiled_block_2_1383 );
  twobit_invoke( 1 );
  twobit_label( 1383, compiled_block_2_1383 );
  twobit_load( 0, 0 );
  twobit_branchf( 1385, compiled_block_2_1385 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1386, compiled_block_2_1386 );
  twobit_invoke( 5 );
  twobit_label( 1386, compiled_block_2_1386 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 13 ); /* ex:free-identifier=? */
  twobit_setrtn( 1387, compiled_block_2_1387 );
  twobit_invoke( 2 );
  twobit_label( 1387, compiled_block_2_1387 );
  twobit_load( 0, 0 );
  twobit_skip( 1384, compiled_block_2_1384 );
  twobit_label( 1385, compiled_block_2_1385 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1384, compiled_block_2_1384 );
  twobit_branchf( 1389, compiled_block_2_1389 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1391, compiled_block_2_1391 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1393, compiled_block_2_1393 ); /* internal:branchf-null? */
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* list? */
  twobit_setrtn( 1394, compiled_block_2_1394 );
  twobit_invoke( 1 );
  twobit_label( 1394, compiled_block_2_1394 );
  twobit_load( 0, 0 );
  twobit_branchf( 1396, compiled_block_2_1396 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1397, compiled_block_2_1397 );
  twobit_invoke( 5 );
  twobit_label( 1397, compiled_block_2_1397 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 2 ); /* () */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_load( 2, 3 );
  twobit_stack( 5 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_stack( 6 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 6 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1398, compiled_block_2_1398 );
  twobit_invoke( 5 );
  twobit_label( 1398, compiled_block_2_1398 );
  twobit_load( 0, 0 );
  twobit_load( 3, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1396, compiled_block_2_1396 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1336, compiled_block_2_1336 );
  twobit_label( 1393, compiled_block_2_1393 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1336, compiled_block_2_1336 );
  twobit_label( 1391, compiled_block_2_1391 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1336, compiled_block_2_1336 );
  twobit_label( 1389, compiled_block_2_1389 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1336, compiled_block_2_1336 );
  twobit_label( 1382, compiled_block_2_1382 );
  twobit_branch( 1336, compiled_block_2_1336 );
  twobit_label( 1380, compiled_block_2_1380 );
  twobit_branch( 1336, compiled_block_2_1336 );
  twobit_label( 1378, compiled_block_2_1378 );
  twobit_branch( 1336, compiled_block_2_1336 );
  twobit_label( 1376, compiled_block_2_1376 );
  twobit_branch( 1336, compiled_block_2_1336 );
  twobit_label( 1374, compiled_block_2_1374 );
  twobit_branch( 1336, compiled_block_2_1336 );
  twobit_label( 1372, compiled_block_2_1372 );
  twobit_branch( 1336, compiled_block_2_1336 );
  twobit_label( 1338, compiled_block_2_1338 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1410, compiled_block_2_1410 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1412, compiled_block_2_1412 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1414, compiled_block_2_1414 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1416, compiled_block_2_1416 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_branchf_611( 1418, compiled_block_2_1418 ); /* internal:branchf-pair? */
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_branchf_611( 1420, compiled_block_2_1420 ); /* internal:branchf-pair? */
  twobit_save( 14 );
  twobit_store( 0, 0 );
  twobit_store( 1, 14 );
  twobit_store( 2, 8 );
  twobit_store( 3, 5 );
  twobit_store( 4, 3 );
  twobit_store( 30, 4 );
  twobit_store( 31, 2 );
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 29 );
  twobit_store( 29, 1 );
  twobit_movereg( 29, 1 );
  twobit_global( 10 ); /* ex:identifier? */
  twobit_setrtn( 1421, compiled_block_2_1421 );
  twobit_invoke( 1 );
  twobit_label( 1421, compiled_block_2_1421 );
  twobit_load( 0, 0 );
  twobit_branchf( 1423, compiled_block_2_1423 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1424, compiled_block_2_1424 );
  twobit_invoke( 5 );
  twobit_label( 1424, compiled_block_2_1424 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 13 ); /* ex:free-identifier=? */
  twobit_setrtn( 1425, compiled_block_2_1425 );
  twobit_invoke( 2 );
  twobit_label( 1425, compiled_block_2_1425 );
  twobit_load( 0, 0 );
  twobit_skip( 1422, compiled_block_2_1422 );
  twobit_label( 1423, compiled_block_2_1423 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1422, compiled_block_2_1422 );
  twobit_branchf( 1427, compiled_block_2_1427 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1429, compiled_block_2_1429 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1431, compiled_block_2_1431 ); /* internal:branchf-null? */
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* list? */
  twobit_setrtn( 1432, compiled_block_2_1432 );
  twobit_invoke( 1 );
  twobit_label( 1432, compiled_block_2_1432 );
  twobit_load( 0, 0 );
  twobit_branchf( 1434, compiled_block_2_1434 );
  twobit_const( 17 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1435, compiled_block_2_1435 );
  twobit_invoke( 5 );
  twobit_label( 1435, compiled_block_2_1435 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 13 );
  twobit_const( 18 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1436, compiled_block_2_1436 );
  twobit_invoke( 5 );
  twobit_label( 1436, compiled_block_2_1436 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1437, compiled_block_2_1437 );
  twobit_invoke( 5 );
  twobit_label( 1437, compiled_block_2_1437 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1438, compiled_block_2_1438 );
  twobit_invoke( 5 );
  twobit_label( 1438, compiled_block_2_1438 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_const( 20 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1439, compiled_block_2_1439 );
  twobit_invoke( 5 );
  twobit_label( 1439, compiled_block_2_1439 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1440, compiled_block_2_1440 );
  twobit_invoke( 5 );
  twobit_label( 1440, compiled_block_2_1440 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1441, compiled_block_2_1441 );
  twobit_invoke( 5 );
  twobit_label( 1441, compiled_block_2_1441 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 21 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1442, compiled_block_2_1442 );
  twobit_invoke( 5 );
  twobit_label( 1442, compiled_block_2_1442 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1443, compiled_block_2_1443 );
  twobit_invoke( 5 );
  twobit_label( 1443, compiled_block_2_1443 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1444, compiled_block_2_1444 );
  twobit_invoke( 5 );
  twobit_label( 1444, compiled_block_2_1444 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 18 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1445, compiled_block_2_1445 );
  twobit_invoke( 5 );
  twobit_label( 1445, compiled_block_2_1445 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 22 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1446, compiled_block_2_1446 );
  twobit_invoke( 5 );
  twobit_label( 1446, compiled_block_2_1446 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1447, compiled_block_2_1447 );
  twobit_invoke( 5 );
  twobit_label( 1447, compiled_block_2_1447 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 13 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 14 );
  twobit_return();
  twobit_label( 1434, compiled_block_2_1434 );
  twobit_load( 1, 14 );
  twobit_pop( 14 );
  twobit_branch( 1337, compiled_block_2_1337 );
  twobit_label( 1431, compiled_block_2_1431 );
  twobit_load( 1, 14 );
  twobit_pop( 14 );
  twobit_branch( 1337, compiled_block_2_1337 );
  twobit_label( 1429, compiled_block_2_1429 );
  twobit_load( 1, 14 );
  twobit_pop( 14 );
  twobit_branch( 1337, compiled_block_2_1337 );
  twobit_label( 1427, compiled_block_2_1427 );
  twobit_load( 1, 14 );
  twobit_pop( 14 );
  twobit_branch( 1337, compiled_block_2_1337 );
  twobit_label( 1420, compiled_block_2_1420 );
  twobit_branch( 1337, compiled_block_2_1337 );
  twobit_label( 1418, compiled_block_2_1418 );
  twobit_branch( 1337, compiled_block_2_1337 );
  twobit_label( 1416, compiled_block_2_1416 );
  twobit_branch( 1337, compiled_block_2_1337 );
  twobit_label( 1414, compiled_block_2_1414 );
  twobit_branch( 1337, compiled_block_2_1337 );
  twobit_label( 1412, compiled_block_2_1412 );
  twobit_branch( 1337, compiled_block_2_1337 );
  twobit_label( 1410, compiled_block_2_1410 );
  twobit_branch( 1337, compiled_block_2_1337 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 2 ); /*  stream-zip~1ayXVW~19850 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 3 ); /*  stream-unfolds~1ayXVW~19849 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 4 ); /*  stream-unfold~1ayXVW~19848 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 5 ); /*  stream-take-while~1ayXVW~19847 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 6 ); /*  stream-take~1ayXVW~19846 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 7 ); /*  stream-scan~1ayXVW~19845 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 8 ); /*  stream-reverse~1ayXVW~19844 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 9 ); /*  stream-ref~1ayXVW~19843 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 10 ); /*  stream-range~1ayXVW~19842 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 11 ); /*  stream-map~1ayXVW~19577 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 12 ); /*  stream-length~1ayXVW~19547 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 13 ); /*  stream-iterate~1ayXVW~19546 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 14 ); /*  stream-from~1ayXVW~19545 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 15 ); /*  stream-for-each~1ayXVW~19544 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 16 ); /*  stream-fold~1ayXVW~19543 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 17 ); /*  stream-filter~1ayXVW~19542 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 18 ); /*  stream-drop-while~1ayXVW~19541 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 19 ); /*  stream-drop~1ayXVW~19540 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 20 ); /*  stream-constant~1ayXVW~19539 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 21 ); /*  stream-concat~1ayXVW~19538 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 22 ); /*  stream-append~1ayXVW~19537 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 23 ); /*  stream->list~1ayXVW~19536 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 24 ); /*  port->stream~1ayXVW~19513 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 25 ); /*  list->stream~1ayXVW~19512 */
  twobit_lambda( compiled_start_2_4, 27, 0 );
  twobit_setglbl( 25 ); /*  list->stream~1ayXVW~19512 */
  twobit_lambda( compiled_start_2_5, 29, 0 );
  twobit_setglbl( 24 ); /*  port->stream~1ayXVW~19513 */
  twobit_lambda( compiled_start_2_6, 31, 0 );
  twobit_setglbl( 23 ); /*  stream->list~1ayXVW~19536 */
  twobit_lambda( compiled_start_2_7, 33, 0 );
  twobit_setglbl( 22 ); /*  stream-append~1ayXVW~19537 */
  twobit_lambda( compiled_start_2_8, 35, 0 );
  twobit_setglbl( 21 ); /*  stream-concat~1ayXVW~19538 */
  twobit_lambda( compiled_start_2_9, 37, 0 );
  twobit_setglbl( 20 ); /*  stream-constant~1ayXVW~19539 */
  twobit_lambda( compiled_start_2_10, 39, 0 );
  twobit_setglbl( 19 ); /*  stream-drop~1ayXVW~19540 */
  twobit_lambda( compiled_start_2_11, 41, 0 );
  twobit_setglbl( 18 ); /*  stream-drop-while~1ayXVW~19541 */
  twobit_lambda( compiled_start_2_12, 43, 0 );
  twobit_setglbl( 17 ); /*  stream-filter~1ayXVW~19542 */
  twobit_lambda( compiled_start_2_13, 45, 0 );
  twobit_setglbl( 16 ); /*  stream-fold~1ayXVW~19543 */
  twobit_lambda( compiled_start_2_14, 47, 0 );
  twobit_setglbl( 15 ); /*  stream-for-each~1ayXVW~19544 */
  twobit_lambda( compiled_start_2_15, 49, 0 );
  twobit_setglbl( 14 ); /*  stream-from~1ayXVW~19545 */
  twobit_lambda( compiled_start_2_16, 51, 0 );
  twobit_setglbl( 13 ); /*  stream-iterate~1ayXVW~19546 */
  twobit_lambda( compiled_start_2_17, 53, 0 );
  twobit_setglbl( 12 ); /*  stream-length~1ayXVW~19547 */
  twobit_lambda( compiled_start_2_18, 55, 0 );
  twobit_setglbl( 11 ); /*  stream-map~1ayXVW~19577 */
  twobit_lambda( compiled_start_2_19, 57, 0 );
  twobit_setglbl( 10 ); /*  stream-range~1ayXVW~19842 */
  twobit_lambda( compiled_start_2_20, 59, 0 );
  twobit_setglbl( 9 ); /*  stream-ref~1ayXVW~19843 */
  twobit_lambda( compiled_start_2_21, 61, 0 );
  twobit_setglbl( 8 ); /*  stream-reverse~1ayXVW~19844 */
  twobit_lambda( compiled_start_2_22, 63, 0 );
  twobit_setglbl( 7 ); /*  stream-scan~1ayXVW~19845 */
  twobit_lambda( compiled_start_2_23, 65, 0 );
  twobit_setglbl( 6 ); /*  stream-take~1ayXVW~19846 */
  twobit_lambda( compiled_start_2_24, 67, 0 );
  twobit_setglbl( 5 ); /*  stream-take-while~1ayXVW~19847 */
  twobit_lambda( compiled_start_2_25, 69, 0 );
  twobit_setglbl( 4 ); /*  stream-unfold~1ayXVW~19848 */
  twobit_lambda( compiled_start_2_26, 71, 0 );
  twobit_setglbl( 3 ); /*  stream-unfolds~1ayXVW~19849 */
  twobit_lambda( compiled_start_2_27, 73, 0 );
  twobit_setglbl( 2 ); /*  stream-zip~1ayXVW~19850 */
  twobit_global( 74 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1462, compiled_block_2_1462 );
  twobit_invoke( 1 );
  twobit_label( 1462, compiled_block_2_1462 );
  twobit_load( 0, 0 );
  twobit_branchf( 1464, compiled_block_2_1464 );
  twobit_load( 1, 1 );
  twobit_pop( 1 );
  twobit_branch( 1460, compiled_block_2_1460 );
  twobit_label( 1464, compiled_block_2_1464 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 3 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* error */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1460, compiled_block_2_1460 );
  twobit_lambda( compiled_start_2_123, 6, 1 );
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 8 ); /*  make-stream~1ayXVW~19321 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_123( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_610( 1468, compiled_block_2_1468 ); /* internal:branchf-null? */
  twobit_global( 1 ); /*  stream-null~1ayXVW~19360 */
  twobit_return();
  twobit_label( 1468, compiled_block_2_1468 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_124, 3, 0 );
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1471, compiled_block_2_1471 );
  twobit_invoke( 1 );
  twobit_label( 1471, compiled_block_2_1471 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_2_125, 7, 0 );
  twobit_setreg( 3 );
  twobit_const( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1474, compiled_block_2_1474 );
  twobit_invoke( 1 );
  twobit_label( 1474, compiled_block_2_1474 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 8 ); /*  make-stream-pare~1ayXVW~19369 */
  twobit_setrtn( 1475, compiled_block_2_1475 );
  twobit_invoke( 2 );
  twobit_label( 1475, compiled_block_2_1475 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_124( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 1469, compiled_block_2_1469 );
  twobit_lexical( 1, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-eager~1ayXVW~19343 */
  twobit_invoke( 1 );
  twobit_label( 1469, compiled_block_2_1469 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_125( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 1472, compiled_block_2_1472 );
  twobit_lexical( 1, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_jump( 2, 1460, compiled_block_2_1460 );
  twobit_label( 1472, compiled_block_2_1472 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1481, compiled_block_2_1481 ); /* internal:branchf-null? */
  twobit_global( 1 ); /* current-input-port */
  twobit_setrtn( 1482, compiled_block_2_1482 );
  twobit_invoke( 0 );
  twobit_label( 1482, compiled_block_2_1482 );
  twobit_load( 0, 0 );
  twobit_skip( 1480, compiled_block_2_1480 );
  twobit_label( 1481, compiled_block_2_1481 );
  twobit_reg_op1_check_652(reg(1),1483,compiled_block_2_1483); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_label( 1480, compiled_block_2_1480 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 2 ); /* input-port? */
  twobit_setrtn( 1484, compiled_block_2_1484 );
  twobit_invoke( 1 );
  twobit_label( 1484, compiled_block_2_1484 );
  twobit_load( 0, 0 );
  twobit_branchf( 1486, compiled_block_2_1486 );
  twobit_load( 1, 1 );
  twobit_pop( 1 );
  twobit_branch( 1478, compiled_block_2_1478 );
  twobit_label( 1486, compiled_block_2_1486 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_const( 4 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* error */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1478, compiled_block_2_1478 );
  twobit_lambda( compiled_start_2_120, 7, 1 );
  twobit_setreg( 4 );
  twobit_const( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  make-stream~1ayXVW~19321 */
  twobit_invoke( 1 );
  twobit_label( 1483, compiled_block_2_1483 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_120( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_13(); /* port? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 1489, compiled_block_2_1489 );
  twobit_lexical( 0, 1 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_op2imm_branchf_640( fixnum(3), 1491, compiled_block_2_1491 ); /* internal:branchf-eq?/imm */
  twobit_reg_op1_check_651(reg(4),1492,compiled_block_2_1492); /* internal:check-fixnum? with (4 3 0) */
  twobit_reg( 3 );
  twobit_op1_43(); /* bytevector? */
  twobit_check( 4, 3, 0, 1492, compiled_block_2_1492 );
  twobit_reg( 3 );
  twobit_op1_102(); /* bytevector-like-length */
  twobit_setreg( 2 );
  twobit_reg_op2_check_661(reg(4),reg(2),1492,compiled_block_2_1492); /* internal:check-range with (4 3 0) */
  twobit_reg( 3 );
  twobit_op2_96( 4 ); /* bytevector-like-ref */
  twobit_skip( 1490, compiled_block_2_1490 );
  twobit_label( 1491, compiled_block_2_1491 );
  twobit_imm_const( fixnum(255) ); /* 255 */
  twobit_label( 1490, compiled_block_2_1490 );
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(13) ); /* 13 */
  twobit_op2_407( 2 ); /* <:fix:fix */
  twobit_branchf( 1494, compiled_block_2_1494 );
  twobit_reg( 2 );
  twobit_op2imm_452( fixnum(128) ); /* <:fix:fix */
  twobit_skip( 1493, compiled_block_2_1493 );
  twobit_label( 1494, compiled_block_2_1494 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1493, compiled_block_2_1493 );
  twobit_branchf( 1496, compiled_block_2_1496 );
  twobit_reg( 4 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op3_403( 1, 3 ); /* vector-set!:trusted:nwb */
  twobit_reg( 2 );
  twobit_op1_38(); /* integer->char */
  twobit_skip( 1495, compiled_block_2_1495 );
  twobit_label( 1496, compiled_block_2_1496 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* io/get-char */
  twobit_setrtn( 1497, compiled_block_2_1497 );
  twobit_invoke( 2 );
  twobit_label( 1497, compiled_block_2_1497 );
  twobit_load( 0, 0 );
  twobit_label( 1495, compiled_block_2_1495 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_613( 1499, compiled_block_2_1499 ); /* internal:branchf-eof-object? */
  twobit_global( 2 ); /*  stream-null~1ayXVW~19360 */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1499, compiled_block_2_1499 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_121, 4, 1 );
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1501, compiled_block_2_1501 );
  twobit_invoke( 1 );
  twobit_label( 1501, compiled_block_2_1501 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_2_122, 8, 0 );
  twobit_setreg( 3 );
  twobit_const( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1503, compiled_block_2_1503 );
  twobit_invoke( 1 );
  twobit_label( 1503, compiled_block_2_1503 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 9 ); /*  make-stream-pare~1ayXVW~19369 */
  twobit_setrtn( 1504, compiled_block_2_1504 );
  twobit_invoke( 2 );
  twobit_label( 1504, compiled_block_2_1504 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 10 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1492, compiled_block_2_1492 );
  twobit_trap( 3, 4, 0, 70 );
  twobit_label( 1489, compiled_block_2_1489 );
  twobit_trap( 4, 0, 0, 112 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_121( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-eager~1ayXVW~19343 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_122( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_jump( 2, 1478, compiled_block_2_1478 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_6( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 1507, compiled_block_2_1507 );
  twobit_invoke( 1 );
  twobit_label( 1507, compiled_block_2_1507 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_branchf_623( 4, 114, compiled_temp_2_114, 1509, compiled_block_2_1509 ); /* internal:branchf-= */
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1510, compiled_block_2_1510 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 1508, compiled_block_2_1508 );
  twobit_label( 1509, compiled_block_2_1509 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1511, compiled_block_2_1511 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1512,compiled_block_2_1512); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_label( 1508, compiled_block_2_1508 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 1513, compiled_block_2_1513 );
  twobit_invoke( 1 );
  twobit_label( 1513, compiled_block_2_1513 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_branchf_623( 4, 115, compiled_temp_2_115, 1515, compiled_block_2_1515 ); /* internal:branchf-= */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1514, compiled_block_2_1514 );
  twobit_label( 1515, compiled_block_2_1515 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1510, compiled_block_2_1510 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_label( 1514, compiled_block_2_1514 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 2 );
  twobit_global( 2 ); /*  stream?~1ayXVW~19323 */
  twobit_setrtn( 1516, compiled_block_2_1516 );
  twobit_invoke( 1 );
  twobit_label( 1516, compiled_block_2_1516 );
  twobit_load( 0, 0 );
  twobit_branchf( 1518, compiled_block_2_1518 );
  twobit_stack( 3 );
  twobit_branchf( 1520, compiled_block_2_1520 );
  twobit_stack( 3 );
  twobit_op1_22(); /* integer? */
  twobit_op1_9(); /* not */
  twobit_skip( 1519, compiled_block_2_1519 );
  twobit_label( 1520, compiled_block_2_1520 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1519, compiled_block_2_1519 );
  twobit_branchf( 1522, compiled_block_2_1522 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_const( 4 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* error */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1522, compiled_block_2_1522 );
  twobit_stack( 3 );
  twobit_branchf( 1525, compiled_block_2_1525 );
  twobit_stack( 3 );
  twobit_op2imm_132( fixnum(0), 116, compiled_temp_2_116 ); /* < */
  twobit_skip( 1524, compiled_block_2_1524 );
  twobit_label( 1525, compiled_block_2_1525 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1524, compiled_block_2_1524 );
  twobit_branchf( 1527, compiled_block_2_1527 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_const( 6 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* error */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1527, compiled_block_2_1527 );
  twobit_stack( 3 );
  twobit_branchf( 1530, compiled_block_2_1530 );
  twobit_load( 1, 3 );
  twobit_skip( 1529, compiled_block_2_1529 );
  twobit_label( 1530, compiled_block_2_1530 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_setreg( 1 );
  twobit_label( 1529, compiled_block_2_1529 );
  twobit_store( 1, 1 );
  twobit_global( 7 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_117, 9, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1518, compiled_block_2_1518 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_const( 10 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* error */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1512, compiled_block_2_1512 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 1511, compiled_block_2_1511 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_label( 1510, compiled_block_2_1510 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_117( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_612( 118, compiled_temp_2_118, 1532, compiled_block_2_1532 ); /* internal:branchf-zero? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1531, compiled_block_2_1531 );
  twobit_label( 1532, compiled_block_2_1532 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  stream-null?~1ayXVW~19379 */
  twobit_setrtn( 1533, compiled_block_2_1533 );
  twobit_invoke( 1 );
  twobit_label( 1533, compiled_block_2_1533 );
  twobit_load( 0, 0 );
  twobit_label( 1531, compiled_block_2_1531 );
  twobit_branchf( 1535, compiled_block_2_1535 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1535, compiled_block_2_1535 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  stream-car~1ayXVW~19398 */
  twobit_setrtn( 1536, compiled_block_2_1536 );
  twobit_invoke( 1 );
  twobit_label( 1536, compiled_block_2_1536 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_stack( 2 );
  twobit_op2imm_131( fixnum(1), 119, compiled_temp_2_119 ); /* - */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  stream-cdr~1ayXVW~19399 */
  twobit_setrtn( 1537, compiled_block_2_1537 );
  twobit_invoke( 1 );
  twobit_label( 1537, compiled_block_2_1537 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1538, compiled_block_2_1538 );
  twobit_invoke( 2 );
  twobit_label( 1538, compiled_block_2_1538 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 3 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_7( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1544, compiled_block_2_1544 ); /* internal:branchf-null? */
  twobit_global( 1 ); /*  stream-null~1ayXVW~19360 */
  twobit_return();
  twobit_label( 1544, compiled_block_2_1544 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_lambda( compiled_start_2_110, 3, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* exists */
  twobit_setrtn( 1546, compiled_block_2_1546 );
  twobit_invoke( 2 );
  twobit_label( 1546, compiled_block_2_1546 );
  twobit_load( 0, 0 );
  twobit_branchf( 1548, compiled_block_2_1548 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_const( 6 );
  twobit_setreg( 2 );
  twobit_global( 7 ); /* error */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1548, compiled_block_2_1548 );
  twobit_load( 1, 1 );
  twobit_pop( 1 );
  twobit_label( 1541, compiled_block_2_1541 );
  twobit_lambda( compiled_start_2_111, 9, 1 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 11 ); /*  make-stream~1ayXVW~19321 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_110( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  stream?~1ayXVW~19323 */
  twobit_setrtn( 1545, compiled_block_2_1545 );
  twobit_invoke( 1 );
  twobit_label( 1545, compiled_block_2_1545 );
  twobit_load( 0, 0 );
  twobit_op1_9(); /* not */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_111( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 1551, compiled_block_2_1551 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1553, compiled_block_2_1553 ); /* internal:branchf-null? */
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_return();
  twobit_label( 1553, compiled_block_2_1553 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-null?~1ayXVW~19379 */
  twobit_setrtn( 1554, compiled_block_2_1554 );
  twobit_invoke( 1 );
  twobit_label( 1554, compiled_block_2_1554 );
  twobit_load( 0, 0 );
  twobit_branchf( 1556, compiled_block_2_1556 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_pop( 1 );
  twobit_jump( 1, 1541, compiled_block_2_1541 );
  twobit_label( 1556, compiled_block_2_1556 );
  twobit_lambda( compiled_start_2_112, 3, 0 );
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1560, compiled_block_2_1560 );
  twobit_invoke( 1 );
  twobit_label( 1560, compiled_block_2_1560 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_2_113, 7, 0 );
  twobit_setreg( 3 );
  twobit_const( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1563, compiled_block_2_1563 );
  twobit_invoke( 1 );
  twobit_label( 1563, compiled_block_2_1563 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 8 ); /*  make-stream-pare~1ayXVW~19369 */
  twobit_setrtn( 1564, compiled_block_2_1564 );
  twobit_invoke( 2 );
  twobit_label( 1564, compiled_block_2_1564 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1551, compiled_block_2_1551 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_112( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 1, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-car~1ayXVW~19398 */
  twobit_setrtn( 1558, compiled_block_2_1558 );
  twobit_invoke( 1 );
  twobit_label( 1558, compiled_block_2_1558 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_113( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lexical( 1, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 1, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-cdr~1ayXVW~19399 */
  twobit_setrtn( 1561, compiled_block_2_1561 );
  twobit_invoke( 1 );
  twobit_label( 1561, compiled_block_2_1561 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_pop( 1 );
  twobit_jump( 2, 1541, compiled_block_2_1541 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_8( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  stream?~1ayXVW~19323 */
  twobit_setrtn( 1569, compiled_block_2_1569 );
  twobit_invoke( 1 );
  twobit_label( 1569, compiled_block_2_1569 );
  twobit_load( 0, 0 );
  twobit_branchf( 1571, compiled_block_2_1571 );
  twobit_load( 1, 1 );
  twobit_pop( 1 );
  twobit_branch( 1567, compiled_block_2_1567 );
  twobit_label( 1571, compiled_block_2_1571 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 3 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* error */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1567, compiled_block_2_1567 );
  twobit_lambda( compiled_start_2_105, 6, 1 );
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 8 ); /*  make-stream~1ayXVW~19321 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_105( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-null?~1ayXVW~19379 */
  twobit_setrtn( 1574, compiled_block_2_1574 );
  twobit_invoke( 1 );
  twobit_label( 1574, compiled_block_2_1574 );
  twobit_load( 0, 0 );
  twobit_branchf( 1576, compiled_block_2_1576 );
  twobit_global( 2 ); /*  stream-null~1ayXVW~19360 */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1576, compiled_block_2_1576 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  stream-car~1ayXVW~19398 */
  twobit_setrtn( 1577, compiled_block_2_1577 );
  twobit_invoke( 1 );
  twobit_label( 1577, compiled_block_2_1577 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  stream?~1ayXVW~19323 */
  twobit_setrtn( 1578, compiled_block_2_1578 );
  twobit_invoke( 1 );
  twobit_label( 1578, compiled_block_2_1578 );
  twobit_load( 0, 0 );
  twobit_branchf( 1580, compiled_block_2_1580 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  stream-car~1ayXVW~19398 */
  twobit_setrtn( 1581, compiled_block_2_1581 );
  twobit_invoke( 1 );
  twobit_label( 1581, compiled_block_2_1581 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-null?~1ayXVW~19379 */
  twobit_setrtn( 1582, compiled_block_2_1582 );
  twobit_invoke( 1 );
  twobit_label( 1582, compiled_block_2_1582 );
  twobit_load( 0, 0 );
  twobit_branchf( 1584, compiled_block_2_1584 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  stream-cdr~1ayXVW~19399 */
  twobit_setrtn( 1585, compiled_block_2_1585 );
  twobit_invoke( 1 );
  twobit_label( 1585, compiled_block_2_1585 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_pop( 1 );
  twobit_jump( 1, 1567, compiled_block_2_1567 );
  twobit_label( 1584, compiled_block_2_1584 );
  twobit_lambda( compiled_start_2_106, 7, 0 );
  twobit_setreg( 4 );
  twobit_const( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1590, compiled_block_2_1590 );
  twobit_invoke( 1 );
  twobit_label( 1590, compiled_block_2_1590 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_2_107, 11, 0 );
  twobit_setreg( 3 );
  twobit_const( 8 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1600, compiled_block_2_1600 );
  twobit_invoke( 1 );
  twobit_label( 1600, compiled_block_2_1600 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 12 ); /*  make-stream-pare~1ayXVW~19369 */
  twobit_setrtn( 1601, compiled_block_2_1601 );
  twobit_invoke( 2 );
  twobit_label( 1601, compiled_block_2_1601 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1580, compiled_block_2_1580 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_const( 15 );
  twobit_setreg( 2 );
  twobit_global( 16 ); /* error */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_106( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-car~1ayXVW~19398 */
  twobit_setrtn( 1587, compiled_block_2_1587 );
  twobit_invoke( 1 );
  twobit_label( 1587, compiled_block_2_1587 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-car~1ayXVW~19398 */
  twobit_setrtn( 1588, compiled_block_2_1588 );
  twobit_invoke( 1 );
  twobit_label( 1588, compiled_block_2_1588 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_107( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_108, 2, 0 );
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1594, compiled_block_2_1594 );
  twobit_invoke( 1 );
  twobit_label( 1594, compiled_block_2_1594 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_2_109, 6, 0 );
  twobit_setreg( 3 );
  twobit_const( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1596, compiled_block_2_1596 );
  twobit_invoke( 1 );
  twobit_label( 1596, compiled_block_2_1596 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 7 ); /*  make-stream-pare~1ayXVW~19369 */
  twobit_setrtn( 1597, compiled_block_2_1597 );
  twobit_invoke( 2 );
  twobit_label( 1597, compiled_block_2_1597 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 8 ); /*  stream-eager~1ayXVW~19343 */
  twobit_setrtn( 1598, compiled_block_2_1598 );
  twobit_invoke( 1 );
  twobit_label( 1598, compiled_block_2_1598 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_pop( 1 );
  twobit_jump( 2, 1567, compiled_block_2_1567 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_108( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 2, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-car~1ayXVW~19398 */
  twobit_setrtn( 1591, compiled_block_2_1591 );
  twobit_invoke( 1 );
  twobit_label( 1591, compiled_block_2_1591 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  stream-cdr~1ayXVW~19399 */
  twobit_setrtn( 1592, compiled_block_2_1592 );
  twobit_invoke( 1 );
  twobit_label( 1592, compiled_block_2_1592 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_109( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 2, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-cdr~1ayXVW~19399 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_9( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_lambda( compiled_start_2_100, 2, 1 );
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  make-stream~1ayXVW~19321 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_100( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_610( 1606, compiled_block_2_1606 ); /* internal:branchf-null? */
  twobit_global( 1 ); /*  stream-null~1ayXVW~19360 */
  twobit_return();
  twobit_label( 1606, compiled_block_2_1606 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 1607, compiled_block_2_1607 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1609, compiled_block_2_1609 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_101, 3, 0 );
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1611, compiled_block_2_1611 );
  twobit_invoke( 1 );
  twobit_label( 1611, compiled_block_2_1611 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_2_102, 7, 0 );
  twobit_setreg( 3 );
  twobit_const( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1613, compiled_block_2_1613 );
  twobit_invoke( 1 );
  twobit_label( 1613, compiled_block_2_1613 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 8 ); /*  make-stream-pare~1ayXVW~19369 */
  twobit_setrtn( 1614, compiled_block_2_1614 );
  twobit_invoke( 2 );
  twobit_label( 1614, compiled_block_2_1614 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1609, compiled_block_2_1609 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_103, 11, 0 );
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1617, compiled_block_2_1617 );
  twobit_invoke( 1 );
  twobit_label( 1617, compiled_block_2_1617 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_2_104, 13, 0 );
  twobit_setreg( 3 );
  twobit_const( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1620, compiled_block_2_1620 );
  twobit_invoke( 1 );
  twobit_label( 1620, compiled_block_2_1620 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 8 ); /*  make-stream-pare~1ayXVW~19369 */
  twobit_setrtn( 1621, compiled_block_2_1621 );
  twobit_invoke( 2 );
  twobit_label( 1621, compiled_block_2_1621 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1607, compiled_block_2_1607 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_101( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-eager~1ayXVW~19343 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_102( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-constant~1ayXVW~19539 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_103( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-eager~1ayXVW~19343 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_104( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 1, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* append */
  twobit_setrtn( 1618, compiled_block_2_1618 );
  twobit_invoke( 2 );
  twobit_label( 1618, compiled_block_2_1618 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  stream-constant~1ayXVW~19539 */
  twobit_setreg( 1 );
  twobit_global( 3 ); /* apply */
  twobit_pop( 0 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_10( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1627, compiled_block_2_1627 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(0), 96, compiled_temp_2_96, 1629, compiled_block_2_1629 ); /* internal:branchf-</imm */
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1629, compiled_block_2_1629 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 4 ); /*  stream?~1ayXVW~19323 */
  twobit_setrtn( 1631, compiled_block_2_1631 );
  twobit_invoke( 1 );
  twobit_label( 1631, compiled_block_2_1631 );
  twobit_load( 0, 0 );
  twobit_branchf( 1633, compiled_block_2_1633 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_pop( 2 );
  twobit_branch( 1624, compiled_block_2_1624 );
  twobit_label( 1633, compiled_block_2_1633 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 5 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* error */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1627, compiled_block_2_1627 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 6 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1624, compiled_block_2_1624 );
  twobit_lambda( compiled_start_2_97, 8, 2 );
  twobit_setreg( 4 );
  twobit_const( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 10 ); /*  make-stream~1ayXVW~19321 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_97( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_branchf_612( 98, compiled_temp_2_98, 1638, compiled_block_2_1638 ); /* internal:branchf-zero? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1637, compiled_block_2_1637 );
  twobit_label( 1638, compiled_block_2_1638 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-null?~1ayXVW~19379 */
  twobit_setrtn( 1639, compiled_block_2_1639 );
  twobit_invoke( 1 );
  twobit_label( 1639, compiled_block_2_1639 );
  twobit_load( 0, 0 );
  twobit_label( 1637, compiled_block_2_1637 );
  twobit_branchf( 1641, compiled_block_2_1641 );
  twobit_lexical( 0, 2 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1641, compiled_block_2_1641 );
  twobit_lexical( 0, 1 );
  twobit_op2imm_131( fixnum(1), 99, compiled_temp_2_99 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  stream-cdr~1ayXVW~19399 */
  twobit_setrtn( 1642, compiled_block_2_1642 );
  twobit_invoke( 1 );
  twobit_label( 1642, compiled_block_2_1642 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_pop( 1 );
  twobit_jump( 1, 1624, compiled_block_2_1624 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_11( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1648, compiled_block_2_1648 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  stream?~1ayXVW~19323 */
  twobit_setrtn( 1649, compiled_block_2_1649 );
  twobit_invoke( 1 );
  twobit_label( 1649, compiled_block_2_1649 );
  twobit_load( 0, 0 );
  twobit_branchf( 1651, compiled_block_2_1651 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_pop( 2 );
  twobit_branch( 1645, compiled_block_2_1645 );
  twobit_label( 1651, compiled_block_2_1651 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 3 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* error */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1648, compiled_block_2_1648 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 5 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1645, compiled_block_2_1645 );
  twobit_lambda( compiled_start_2_95, 7, 2 );
  twobit_setreg( 4 );
  twobit_const( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  make-stream~1ayXVW~19321 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_95( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-pair?~1ayXVW~19378 */
  twobit_setrtn( 1655, compiled_block_2_1655 );
  twobit_invoke( 1 );
  twobit_label( 1655, compiled_block_2_1655 );
  twobit_load( 0, 0 );
  twobit_branchf( 1657, compiled_block_2_1657 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  stream-car~1ayXVW~19398 */
  twobit_setrtn( 1658, compiled_block_2_1658 );
  twobit_invoke( 1 );
  twobit_label( 1658, compiled_block_2_1658 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1659, compiled_block_2_1659 );
  twobit_invoke( 1 );
  twobit_label( 1659, compiled_block_2_1659 );
  twobit_load( 0, 0 );
  twobit_skip( 1656, compiled_block_2_1656 );
  twobit_label( 1657, compiled_block_2_1657 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1656, compiled_block_2_1656 );
  twobit_branchf( 1661, compiled_block_2_1661 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  stream-cdr~1ayXVW~19399 */
  twobit_setrtn( 1662, compiled_block_2_1662 );
  twobit_invoke( 1 );
  twobit_label( 1662, compiled_block_2_1662 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_pop( 0 );
  twobit_jump( 1, 1645, compiled_block_2_1645 );
  twobit_label( 1661, compiled_block_2_1661 );
  twobit_lexical( 0, 2 );
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_12( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1668, compiled_block_2_1668 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  stream?~1ayXVW~19323 */
  twobit_setrtn( 1669, compiled_block_2_1669 );
  twobit_invoke( 1 );
  twobit_label( 1669, compiled_block_2_1669 );
  twobit_load( 0, 0 );
  twobit_branchf( 1671, compiled_block_2_1671 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_pop( 2 );
  twobit_branch( 1665, compiled_block_2_1665 );
  twobit_label( 1671, compiled_block_2_1671 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 3 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* error */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1668, compiled_block_2_1668 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 5 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1665, compiled_block_2_1665 );
  twobit_lambda( compiled_start_2_92, 7, 2 );
  twobit_setreg( 4 );
  twobit_const( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  make-stream~1ayXVW~19321 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_92( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-null?~1ayXVW~19379 */
  twobit_setrtn( 1675, compiled_block_2_1675 );
  twobit_invoke( 1 );
  twobit_label( 1675, compiled_block_2_1675 );
  twobit_load( 0, 0 );
  twobit_branchf( 1677, compiled_block_2_1677 );
  twobit_global( 2 ); /*  stream-null~1ayXVW~19360 */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1677, compiled_block_2_1677 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  stream-car~1ayXVW~19398 */
  twobit_setrtn( 1678, compiled_block_2_1678 );
  twobit_invoke( 1 );
  twobit_label( 1678, compiled_block_2_1678 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1679, compiled_block_2_1679 );
  twobit_invoke( 1 );
  twobit_label( 1679, compiled_block_2_1679 );
  twobit_load( 0, 0 );
  twobit_branchf( 1681, compiled_block_2_1681 );
  twobit_lambda( compiled_start_2_93, 5, 0 );
  twobit_setreg( 4 );
  twobit_const( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 7 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1684, compiled_block_2_1684 );
  twobit_invoke( 1 );
  twobit_label( 1684, compiled_block_2_1684 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_2_94, 9, 0 );
  twobit_setreg( 3 );
  twobit_const( 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 7 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1687, compiled_block_2_1687 );
  twobit_invoke( 1 );
  twobit_label( 1687, compiled_block_2_1687 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 10 ); /*  make-stream-pare~1ayXVW~19369 */
  twobit_setrtn( 1688, compiled_block_2_1688 );
  twobit_invoke( 2 );
  twobit_label( 1688, compiled_block_2_1688 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 11 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1681, compiled_block_2_1681 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 12 ); /*  stream-cdr~1ayXVW~19399 */
  twobit_setrtn( 1690, compiled_block_2_1690 );
  twobit_invoke( 1 );
  twobit_label( 1690, compiled_block_2_1690 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_pop( 1 );
  twobit_jump( 1, 1665, compiled_block_2_1665 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_93( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-car~1ayXVW~19398 */
  twobit_setrtn( 1682, compiled_block_2_1682 );
  twobit_invoke( 1 );
  twobit_label( 1682, compiled_block_2_1682 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_94( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-cdr~1ayXVW~19399 */
  twobit_setrtn( 1685, compiled_block_2_1685 );
  twobit_invoke( 1 );
  twobit_label( 1685, compiled_block_2_1685 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_pop( 0 );
  twobit_jump( 2, 1665, compiled_block_2_1665 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_13( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1694, compiled_block_2_1694 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /*  stream?~1ayXVW~19323 */
  twobit_setrtn( 1695, compiled_block_2_1695 );
  twobit_invoke( 1 );
  twobit_label( 1695, compiled_block_2_1695 );
  twobit_load( 0, 0 );
  twobit_branchf( 1697, compiled_block_2_1697 );
  twobit_load( 2, 1 );
  twobit_store( 2, 4 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_91, 4, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 4 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 1697, compiled_block_2_1697 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_const( 6 );
  twobit_setreg( 2 );
  twobit_global( 7 ); /* error */
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 1694, compiled_block_2_1694 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 2 );
  twobit_global( 7 ); /* error */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_91( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  stream-null?~1ayXVW~19379 */
  twobit_setrtn( 1698, compiled_block_2_1698 );
  twobit_invoke( 1 );
  twobit_label( 1698, compiled_block_2_1698 );
  twobit_load( 0, 0 );
  twobit_branchf( 1700, compiled_block_2_1700 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1700, compiled_block_2_1700 );
  twobit_load( 1, 2 );
  twobit_global( 2 ); /*  stream-car~1ayXVW~19398 */
  twobit_setrtn( 1701, compiled_block_2_1701 );
  twobit_invoke( 1 );
  twobit_label( 1701, compiled_block_2_1701 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1702, compiled_block_2_1702 );
  twobit_invoke( 2 );
  twobit_label( 1702, compiled_block_2_1702 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 2 );
  twobit_global( 3 ); /*  stream-cdr~1ayXVW~19399 */
  twobit_setrtn( 1703, compiled_block_2_1703 );
  twobit_invoke( 1 );
  twobit_label( 1703, compiled_block_2_1703 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_14( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_reg( 1 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1711, compiled_block_2_1711 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1713, compiled_block_2_1713 ); /* internal:branchf-null? */
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1713, compiled_block_2_1713 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_lambda( compiled_start_2_90, 5, 0 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /* exists */
  twobit_setrtn( 1716, compiled_block_2_1716 );
  twobit_invoke( 2 );
  twobit_label( 1716, compiled_block_2_1716 );
  twobit_load( 0, 0 );
  twobit_branchf( 1718, compiled_block_2_1718 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 7 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* error */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1718, compiled_block_2_1718 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_pop( 2 );
  twobit_branch( 1708, compiled_block_2_1708 );
  twobit_label( 1711, compiled_block_2_1711 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1708, compiled_block_2_1708 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_global( 9 ); /*  stream-null?~1ayXVW~19379 */
  twobit_setreg( 1 );
  twobit_global( 6 ); /* exists */
  twobit_setrtn( 1722, compiled_block_2_1722 );
  twobit_invoke( 2 );
  twobit_label( 1722, compiled_block_2_1722 );
  twobit_load( 0, 0 );
  twobit_branchf( 1724, compiled_block_2_1724 );
  twobit_op1_3(); /* unspecified */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1724, compiled_block_2_1724 );
  twobit_global( 10 ); /*  stream-car~1ayXVW~19398 */
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 11 ); /*  map~1ayXVW~1381 */
  twobit_setrtn( 1725, compiled_block_2_1725 );
  twobit_invoke( 2 );
  twobit_label( 1725, compiled_block_2_1725 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 12 ); /* apply */
  twobit_setrtn( 1726, compiled_block_2_1726 );
  twobit_invoke( 2 );
  twobit_label( 1726, compiled_block_2_1726 );
  twobit_load( 0, 0 );
  twobit_global( 13 ); /*  stream-cdr~1ayXVW~19399 */
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 11 ); /*  map~1ayXVW~1381 */
  twobit_setrtn( 1727, compiled_block_2_1727 );
  twobit_invoke( 2 );
  twobit_label( 1727, compiled_block_2_1727 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 1708, compiled_block_2_1708 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_90( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  stream?~1ayXVW~19323 */
  twobit_setrtn( 1715, compiled_block_2_1715 );
  twobit_invoke( 1 );
  twobit_label( 1715, compiled_block_2_1715 );
  twobit_load( 0, 0 );
  twobit_op1_9(); /* not */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_15( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1732, compiled_block_2_1732 ); /* internal:branchf-null? */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_skip( 1731, compiled_block_2_1731 );
  twobit_label( 1732, compiled_block_2_1732 );
  twobit_reg_op1_check_652(reg(2),1733,compiled_block_2_1733); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_label( 1731, compiled_block_2_1731 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_18(); /* complex? */
  twobit_branchf( 1735, compiled_block_2_1735 );
  twobit_reg( 4 );
  twobit_op1_18(); /* complex? */
  twobit_branchf( 1737, compiled_block_2_1737 );
  twobit_movereg( 4, 2 );
  twobit_branch( 1729, compiled_block_2_1729 );
  twobit_label( 1737, compiled_block_2_1737 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1735, compiled_block_2_1735 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 4 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1729, compiled_block_2_1729 );
  twobit_lambda( compiled_start_2_86, 6, 2 );
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 8 ); /*  make-stream~1ayXVW~19321 */
  twobit_invoke( 1 );
  twobit_label( 1733, compiled_block_2_1733 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_86( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_87, 2, 0 );
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1742, compiled_block_2_1742 );
  twobit_invoke( 1 );
  twobit_label( 1742, compiled_block_2_1742 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_2_88, 6, 0 );
  twobit_setreg( 3 );
  twobit_const( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1744, compiled_block_2_1744 );
  twobit_invoke( 1 );
  twobit_label( 1744, compiled_block_2_1744 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 7 ); /*  make-stream-pare~1ayXVW~19369 */
  twobit_setrtn( 1745, compiled_block_2_1745 );
  twobit_invoke( 2 );
  twobit_label( 1745, compiled_block_2_1745 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 8 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_87( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-eager~1ayXVW~19343 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_88( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_op2_61( 4, 89, compiled_temp_2_89 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_jump( 2, 1729, compiled_block_2_1729 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_16( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1751, compiled_block_2_1751 );
  twobit_branch( 1748, compiled_block_2_1748 );
  twobit_label( 1751, compiled_block_2_1751 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1748, compiled_block_2_1748 );
  twobit_lambda( compiled_start_2_83, 5, 2 );
  twobit_setreg( 4 );
  twobit_const( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 7 ); /*  make-stream~1ayXVW~19321 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_83( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_84, 2, 0 );
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1755, compiled_block_2_1755 );
  twobit_invoke( 1 );
  twobit_label( 1755, compiled_block_2_1755 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_2_85, 6, 0 );
  twobit_setreg( 3 );
  twobit_const( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1758, compiled_block_2_1758 );
  twobit_invoke( 1 );
  twobit_label( 1758, compiled_block_2_1758 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 7 ); /*  make-stream-pare~1ayXVW~19369 */
  twobit_setrtn( 1759, compiled_block_2_1759 );
  twobit_invoke( 2 );
  twobit_label( 1759, compiled_block_2_1759 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 8 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_84( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-eager~1ayXVW~19343 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_85( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setrtn( 1756, compiled_block_2_1756 );
  twobit_invoke( 1 );
  twobit_label( 1756, compiled_block_2_1756 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_pop( 0 );
  twobit_jump( 2, 1748, compiled_block_2_1748 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_17( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  stream?~1ayXVW~19323 */
  twobit_setrtn( 1762, compiled_block_2_1762 );
  twobit_invoke( 1 );
  twobit_label( 1762, compiled_block_2_1762 );
  twobit_load( 0, 0 );
  twobit_branchf( 1764, compiled_block_2_1764 );
  twobit_load( 2, 1 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_81, 4, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1764, compiled_block_2_1764 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_const( 6 );
  twobit_setreg( 2 );
  twobit_global( 7 ); /* error */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_81( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  stream-null?~1ayXVW~19379 */
  twobit_setrtn( 1765, compiled_block_2_1765 );
  twobit_invoke( 1 );
  twobit_label( 1765, compiled_block_2_1765 );
  twobit_load( 0, 0 );
  twobit_branchf( 1767, compiled_block_2_1767 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1767, compiled_block_2_1767 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 82, compiled_temp_2_82 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 2 );
  twobit_global( 2 ); /*  stream-cdr~1ayXVW~19399 */
  twobit_setrtn( 1768, compiled_block_2_1768 );
  twobit_invoke( 1 );
  twobit_label( 1768, compiled_block_2_1768 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_18( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_reg( 1 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1775, compiled_block_2_1775 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1777, compiled_block_2_1777 ); /* internal:branchf-null? */
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1777, compiled_block_2_1777 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_lambda( compiled_start_2_77, 5, 0 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /* exists */
  twobit_setrtn( 1780, compiled_block_2_1780 );
  twobit_invoke( 2 );
  twobit_label( 1780, compiled_block_2_1780 );
  twobit_load( 0, 0 );
  twobit_branchf( 1782, compiled_block_2_1782 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 7 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* error */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1782, compiled_block_2_1782 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_pop( 2 );
  twobit_branch( 1772, compiled_block_2_1772 );
  twobit_label( 1775, compiled_block_2_1775 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1772, compiled_block_2_1772 );
  twobit_lambda( compiled_start_2_78, 10, 2 );
  twobit_setreg( 4 );
  twobit_const( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 12 ); /*  make-stream~1ayXVW~19321 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_77( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  stream?~1ayXVW~19323 */
  twobit_setrtn( 1779, compiled_block_2_1779 );
  twobit_invoke( 1 );
  twobit_label( 1779, compiled_block_2_1779 );
  twobit_load( 0, 0 );
  twobit_op1_9(); /* not */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_78( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  stream-null?~1ayXVW~19379 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* exists */
  twobit_setrtn( 1786, compiled_block_2_1786 );
  twobit_invoke( 2 );
  twobit_label( 1786, compiled_block_2_1786 );
  twobit_load( 0, 0 );
  twobit_branchf( 1788, compiled_block_2_1788 );
  twobit_global( 3 ); /*  stream-null~1ayXVW~19360 */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1788, compiled_block_2_1788 );
  twobit_lambda( compiled_start_2_79, 5, 0 );
  twobit_setreg( 4 );
  twobit_const( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 7 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1792, compiled_block_2_1792 );
  twobit_invoke( 1 );
  twobit_label( 1792, compiled_block_2_1792 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_2_80, 9, 0 );
  twobit_setreg( 3 );
  twobit_const( 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 7 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1795, compiled_block_2_1795 );
  twobit_invoke( 1 );
  twobit_label( 1795, compiled_block_2_1795 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 10 ); /*  make-stream-pare~1ayXVW~19369 */
  twobit_setrtn( 1796, compiled_block_2_1796 );
  twobit_invoke( 2 );
  twobit_label( 1796, compiled_block_2_1796 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 11 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_79( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  stream-car~1ayXVW~19398 */
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  map~1ayXVW~1381 */
  twobit_setrtn( 1789, compiled_block_2_1789 );
  twobit_invoke( 2 );
  twobit_label( 1789, compiled_block_2_1789 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* apply */
  twobit_setrtn( 1790, compiled_block_2_1790 );
  twobit_invoke( 2 );
  twobit_label( 1790, compiled_block_2_1790 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_80( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  stream-cdr~1ayXVW~19399 */
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  map~1ayXVW~1381 */
  twobit_setrtn( 1793, compiled_block_2_1793 );
  twobit_invoke( 2 );
  twobit_label( 1793, compiled_block_2_1793 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_pop( 0 );
  twobit_jump( 2, 1772, compiled_block_2_1772 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_19( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_reg( 1 );
  twobit_op1_18(); /* complex? */
  twobit_branchf( 1802, compiled_block_2_1802 );
  twobit_reg( 2 );
  twobit_op1_18(); /* complex? */
  twobit_branchf( 1804, compiled_block_2_1804 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1806, compiled_block_2_1806 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 1805, compiled_block_2_1805 );
  twobit_label( 1806, compiled_block_2_1806 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 2, 71, compiled_temp_2_71, 1808, compiled_block_2_1808 ); /* internal:branchf-< */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_skip( 1805, compiled_block_2_1805 );
  twobit_label( 1808, compiled_block_2_1808 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_label( 1805, compiled_block_2_1805 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_18(); /* complex? */
  twobit_branchf( 1810, compiled_block_2_1810 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 4, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_branchf_619( 4, 72, compiled_temp_2_72, 1812, compiled_block_2_1812 ); /* internal:branchf-< */
  twobit_global( 1 ); /* < */
  twobit_skip( 1811, compiled_block_2_1811 );
  twobit_label( 1812, compiled_block_2_1812 );
  twobit_global( 2 ); /* > */
  twobit_label( 1811, compiled_block_2_1811 );
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_pop( 1 );
  twobit_branch( 1799, compiled_block_2_1799 );
  twobit_label( 1810, compiled_block_2_1810 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_const( 4 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1804, compiled_block_2_1804 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_const( 6 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1802, compiled_block_2_1802 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_const( 7 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1799, compiled_block_2_1799 );
  twobit_lambda( compiled_start_2_73, 9, 4 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 11 ); /*  make-stream~1ayXVW~19321 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_73( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 4 );
  twobit_setrtn( 1817, compiled_block_2_1817 );
  twobit_invoke( 2 );
  twobit_label( 1817, compiled_block_2_1817 );
  twobit_load( 0, 0 );
  twobit_branchf( 1819, compiled_block_2_1819 );
  twobit_lambda( compiled_start_2_74, 2, 0 );
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1821, compiled_block_2_1821 );
  twobit_invoke( 1 );
  twobit_label( 1821, compiled_block_2_1821 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_2_75, 6, 0 );
  twobit_setreg( 3 );
  twobit_const( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1823, compiled_block_2_1823 );
  twobit_invoke( 1 );
  twobit_label( 1823, compiled_block_2_1823 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 7 ); /*  make-stream-pare~1ayXVW~19369 */
  twobit_setrtn( 1824, compiled_block_2_1824 );
  twobit_invoke( 2 );
  twobit_label( 1824, compiled_block_2_1824 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 8 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1819, compiled_block_2_1819 );
  twobit_global( 9 ); /*  stream-null~1ayXVW~19360 */
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_74( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-eager~1ayXVW~19343 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_75( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_op2_61( 4, 76, compiled_temp_2_76 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 4 );
  twobit_setreg( 4 );
  twobit_jump( 2, 1799, compiled_block_2_1799 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_20( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  stream?~1ayXVW~19323 */
  twobit_setrtn( 1827, compiled_block_2_1827 );
  twobit_invoke( 1 );
  twobit_label( 1827, compiled_block_2_1827 );
  twobit_load( 0, 0 );
  twobit_branchf( 1829, compiled_block_2_1829 );
  twobit_stack( 1 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1831, compiled_block_2_1831 );
  twobit_stack( 1 );
  twobit_op2imm_branchf_635( fixnum(0), 67, compiled_temp_2_67, 1833, compiled_block_2_1833 ); /* internal:branchf-</imm */
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 3 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* error */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1833, compiled_block_2_1833 );
  twobit_global( 5 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_68, 7, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1831, compiled_block_2_1831 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* error */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1829, compiled_block_2_1829 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 9 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* error */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_68( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  stream-null?~1ayXVW~19379 */
  twobit_setrtn( 1835, compiled_block_2_1835 );
  twobit_invoke( 1 );
  twobit_label( 1835, compiled_block_2_1835 );
  twobit_load( 0, 0 );
  twobit_branchf( 1837, compiled_block_2_1837 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 3 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* error */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1837, compiled_block_2_1837 );
  twobit_stack( 1 );
  twobit_op1_branchf_612( 69, compiled_temp_2_69, 1840, compiled_block_2_1840 ); /* internal:branchf-zero? */
  twobit_load( 1, 2 );
  twobit_global( 5 ); /*  stream-car~1ayXVW~19398 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1840, compiled_block_2_1840 );
  twobit_stack( 1 );
  twobit_op2imm_131( fixnum(1), 70, compiled_temp_2_70 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /*  stream-cdr~1ayXVW~19399 */
  twobit_setrtn( 1842, compiled_block_2_1842 );
  twobit_invoke( 1 );
  twobit_label( 1842, compiled_block_2_1842 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_21( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  stream?~1ayXVW~19323 */
  twobit_setrtn( 1849, compiled_block_2_1849 );
  twobit_invoke( 1 );
  twobit_label( 1849, compiled_block_2_1849 );
  twobit_load( 0, 0 );
  twobit_branchf( 1851, compiled_block_2_1851 );
  twobit_global( 2 ); /*  stream-null~1ayXVW~19360 */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_pop( 1 );
  twobit_branch( 1847, compiled_block_2_1847 );
  twobit_label( 1851, compiled_block_2_1851 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_const( 4 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* error */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1847, compiled_block_2_1847 );
  twobit_lambda( compiled_start_2_64, 7, 2 );
  twobit_setreg( 4 );
  twobit_const( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  make-stream~1ayXVW~19321 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_64( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-null?~1ayXVW~19379 */
  twobit_setrtn( 1854, compiled_block_2_1854 );
  twobit_invoke( 1 );
  twobit_label( 1854, compiled_block_2_1854 );
  twobit_load( 0, 0 );
  twobit_branchf( 1856, compiled_block_2_1856 );
  twobit_lexical( 0, 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1856, compiled_block_2_1856 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  stream-cdr~1ayXVW~19399 */
  twobit_setrtn( 1857, compiled_block_2_1857 );
  twobit_invoke( 1 );
  twobit_label( 1857, compiled_block_2_1857 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_lambda( compiled_start_2_65, 4, 0 );
  twobit_setreg( 3 );
  twobit_const( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1860, compiled_block_2_1860 );
  twobit_invoke( 1 );
  twobit_label( 1860, compiled_block_2_1860 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_2_66, 8, 0 );
  twobit_setreg( 3 );
  twobit_const( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1861, compiled_block_2_1861 );
  twobit_invoke( 1 );
  twobit_label( 1861, compiled_block_2_1861 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 9 ); /*  make-stream-pare~1ayXVW~19369 */
  twobit_setrtn( 1862, compiled_block_2_1862 );
  twobit_invoke( 2 );
  twobit_label( 1862, compiled_block_2_1862 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 10 ); /*  stream-eager~1ayXVW~19343 */
  twobit_setrtn( 1863, compiled_block_2_1863 );
  twobit_invoke( 1 );
  twobit_label( 1863, compiled_block_2_1863 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_jump( 1, 1847, compiled_block_2_1847 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_65( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-car~1ayXVW~19398 */
  twobit_setrtn( 1858, compiled_block_2_1858 );
  twobit_invoke( 1 );
  twobit_label( 1858, compiled_block_2_1858 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_66( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_22( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1869, compiled_block_2_1869 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /*  stream?~1ayXVW~19323 */
  twobit_setrtn( 1870, compiled_block_2_1870 );
  twobit_invoke( 1 );
  twobit_label( 1870, compiled_block_2_1870 );
  twobit_load( 0, 0 );
  twobit_branchf( 1872, compiled_block_2_1872 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_load( 3, 3 );
  twobit_pop( 3 );
  twobit_branch( 1866, compiled_block_2_1866 );
  twobit_label( 1872, compiled_block_2_1872 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 3 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* error */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1869, compiled_block_2_1869 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 5 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1866, compiled_block_2_1866 );
  twobit_lambda( compiled_start_2_59, 7, 3 );
  twobit_setreg( 4 );
  twobit_const( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  make-stream~1ayXVW~19321 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_59( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-null?~1ayXVW~19379 */
  twobit_setrtn( 1876, compiled_block_2_1876 );
  twobit_invoke( 1 );
  twobit_label( 1876, compiled_block_2_1876 );
  twobit_load( 0, 0 );
  twobit_branchf( 1878, compiled_block_2_1878 );
  twobit_lambda( compiled_start_2_60, 3, 0 );
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1880, compiled_block_2_1880 );
  twobit_invoke( 1 );
  twobit_label( 1880, compiled_block_2_1880 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_2_61, 7, 0 );
  twobit_setreg( 3 );
  twobit_const( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1881, compiled_block_2_1881 );
  twobit_invoke( 1 );
  twobit_label( 1881, compiled_block_2_1881 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 8 ); /*  make-stream-pare~1ayXVW~19369 */
  twobit_setrtn( 1882, compiled_block_2_1882 );
  twobit_invoke( 2 );
  twobit_label( 1882, compiled_block_2_1882 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1878, compiled_block_2_1878 );
  twobit_lambda( compiled_start_2_62, 11, 0 );
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1885, compiled_block_2_1885 );
  twobit_invoke( 1 );
  twobit_label( 1885, compiled_block_2_1885 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_2_63, 13, 0 );
  twobit_setreg( 3 );
  twobit_const( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1890, compiled_block_2_1890 );
  twobit_invoke( 1 );
  twobit_label( 1890, compiled_block_2_1890 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 8 ); /*  make-stream-pare~1ayXVW~19369 */
  twobit_setrtn( 1891, compiled_block_2_1891 );
  twobit_invoke( 2 );
  twobit_label( 1891, compiled_block_2_1891 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_60( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-eager~1ayXVW~19343 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_61( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  stream-null~1ayXVW~19360 */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_62( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-eager~1ayXVW~19343 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_63( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-car~1ayXVW~19398 */
  twobit_setrtn( 1886, compiled_block_2_1886 );
  twobit_invoke( 1 );
  twobit_label( 1886, compiled_block_2_1886 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setrtn( 1887, compiled_block_2_1887 );
  twobit_invoke( 2 );
  twobit_label( 1887, compiled_block_2_1887 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  stream-cdr~1ayXVW~19399 */
  twobit_setrtn( 1888, compiled_block_2_1888 );
  twobit_invoke( 1 );
  twobit_label( 1888, compiled_block_2_1888 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_pop( 1 );
  twobit_jump( 2, 1866, compiled_block_2_1866 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_23( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  stream?~1ayXVW~19323 */
  twobit_setrtn( 1896, compiled_block_2_1896 );
  twobit_invoke( 1 );
  twobit_label( 1896, compiled_block_2_1896 );
  twobit_load( 0, 0 );
  twobit_branchf( 1898, compiled_block_2_1898 );
  twobit_stack( 1 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1900, compiled_block_2_1900 );
  twobit_stack( 1 );
  twobit_op2imm_branchf_635( fixnum(0), 53, compiled_temp_2_53, 1902, compiled_block_2_1902 ); /* internal:branchf-</imm */
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 3 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* error */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1902, compiled_block_2_1902 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_pop( 2 );
  twobit_branch( 1894, compiled_block_2_1894 );
  twobit_label( 1900, compiled_block_2_1900 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 5 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* error */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1898, compiled_block_2_1898 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 6 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* error */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1894, compiled_block_2_1894 );
  twobit_lambda( compiled_start_2_54, 8, 2 );
  twobit_setreg( 4 );
  twobit_const( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 10 ); /*  make-stream~1ayXVW~19321 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_54( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-null?~1ayXVW~19379 */
  twobit_setrtn( 1907, compiled_block_2_1907 );
  twobit_invoke( 1 );
  twobit_label( 1907, compiled_block_2_1907 );
  twobit_load( 0, 0 );
  twobit_branchf( 1909, compiled_block_2_1909 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1908, compiled_block_2_1908 );
  twobit_label( 1909, compiled_block_2_1909 );
  twobit_lexical( 0, 1 );
  twobit_op1_31( 55, compiled_temp_2_55 ); /* zero? */
  twobit_label( 1908, compiled_block_2_1908 );
  twobit_branchf( 1911, compiled_block_2_1911 );
  twobit_global( 2 ); /*  stream-null~1ayXVW~19360 */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1911, compiled_block_2_1911 );
  twobit_lambda( compiled_start_2_56, 4, 0 );
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1914, compiled_block_2_1914 );
  twobit_invoke( 1 );
  twobit_label( 1914, compiled_block_2_1914 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_2_57, 8, 0 );
  twobit_setreg( 3 );
  twobit_const( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1917, compiled_block_2_1917 );
  twobit_invoke( 1 );
  twobit_label( 1917, compiled_block_2_1917 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 9 ); /*  make-stream-pare~1ayXVW~19369 */
  twobit_setrtn( 1918, compiled_block_2_1918 );
  twobit_invoke( 2 );
  twobit_label( 1918, compiled_block_2_1918 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 10 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_56( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-car~1ayXVW~19398 */
  twobit_setrtn( 1912, compiled_block_2_1912 );
  twobit_invoke( 1 );
  twobit_label( 1912, compiled_block_2_1912 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_57( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lexical( 1, 1 );
  twobit_op2imm_131( fixnum(1), 58, compiled_temp_2_58 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-cdr~1ayXVW~19399 */
  twobit_setrtn( 1915, compiled_block_2_1915 );
  twobit_invoke( 1 );
  twobit_label( 1915, compiled_block_2_1915 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_pop( 1 );
  twobit_jump( 2, 1894, compiled_block_2_1894 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_24( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  stream?~1ayXVW~19323 */
  twobit_setrtn( 1923, compiled_block_2_1923 );
  twobit_invoke( 1 );
  twobit_label( 1923, compiled_block_2_1923 );
  twobit_load( 0, 0 );
  twobit_branchf( 1925, compiled_block_2_1925 );
  twobit_stack( 1 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1927, compiled_block_2_1927 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_pop( 2 );
  twobit_branch( 1921, compiled_block_2_1921 );
  twobit_label( 1927, compiled_block_2_1927 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 3 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* error */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1925, compiled_block_2_1925 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 5 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* error */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1921, compiled_block_2_1921 );
  twobit_lambda( compiled_start_2_50, 7, 2 );
  twobit_setreg( 4 );
  twobit_const( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  make-stream~1ayXVW~19321 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_50( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-null?~1ayXVW~19379 */
  twobit_setrtn( 1931, compiled_block_2_1931 );
  twobit_invoke( 1 );
  twobit_label( 1931, compiled_block_2_1931 );
  twobit_load( 0, 0 );
  twobit_branchf( 1933, compiled_block_2_1933 );
  twobit_global( 2 ); /*  stream-null~1ayXVW~19360 */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1933, compiled_block_2_1933 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  stream-car~1ayXVW~19398 */
  twobit_setrtn( 1934, compiled_block_2_1934 );
  twobit_invoke( 1 );
  twobit_label( 1934, compiled_block_2_1934 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1935, compiled_block_2_1935 );
  twobit_invoke( 1 );
  twobit_label( 1935, compiled_block_2_1935 );
  twobit_load( 0, 0 );
  twobit_branchf( 1937, compiled_block_2_1937 );
  twobit_lambda( compiled_start_2_51, 5, 0 );
  twobit_setreg( 4 );
  twobit_const( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 7 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1940, compiled_block_2_1940 );
  twobit_invoke( 1 );
  twobit_label( 1940, compiled_block_2_1940 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_2_52, 9, 0 );
  twobit_setreg( 3 );
  twobit_const( 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 7 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1943, compiled_block_2_1943 );
  twobit_invoke( 1 );
  twobit_label( 1943, compiled_block_2_1943 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 10 ); /*  make-stream-pare~1ayXVW~19369 */
  twobit_setrtn( 1944, compiled_block_2_1944 );
  twobit_invoke( 2 );
  twobit_label( 1944, compiled_block_2_1944 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 11 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1937, compiled_block_2_1937 );
  twobit_global( 2 ); /*  stream-null~1ayXVW~19360 */
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_51( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-car~1ayXVW~19398 */
  twobit_setrtn( 1938, compiled_block_2_1938 );
  twobit_invoke( 1 );
  twobit_label( 1938, compiled_block_2_1938 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_52( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-cdr~1ayXVW~19399 */
  twobit_setrtn( 1941, compiled_block_2_1941 );
  twobit_invoke( 1 );
  twobit_label( 1941, compiled_block_2_1941 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_pop( 0 );
  twobit_jump( 2, 1921, compiled_block_2_1921 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_25( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_reg( 1 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1950, compiled_block_2_1950 );
  twobit_reg( 2 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1952, compiled_block_2_1952 );
  twobit_reg( 3 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1954, compiled_block_2_1954 );
  twobit_branch( 1947, compiled_block_2_1947 );
  twobit_label( 1954, compiled_block_2_1954 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1952, compiled_block_2_1952 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 4 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1950, compiled_block_2_1950 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 5 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1947, compiled_block_2_1947 );
  twobit_lambda( compiled_start_2_47, 7, 4 );
  twobit_setreg( 4 );
  twobit_const( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  make-stream~1ayXVW~19321 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_47( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1959, compiled_block_2_1959 );
  twobit_invoke( 1 );
  twobit_label( 1959, compiled_block_2_1959 );
  twobit_load( 0, 0 );
  twobit_branchf( 1961, compiled_block_2_1961 );
  twobit_lambda( compiled_start_2_48, 2, 0 );
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1964, compiled_block_2_1964 );
  twobit_invoke( 1 );
  twobit_label( 1964, compiled_block_2_1964 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_2_49, 6, 0 );
  twobit_setreg( 3 );
  twobit_const( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1967, compiled_block_2_1967 );
  twobit_invoke( 1 );
  twobit_label( 1967, compiled_block_2_1967 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 7 ); /*  make-stream-pare~1ayXVW~19369 */
  twobit_setrtn( 1968, compiled_block_2_1968 );
  twobit_invoke( 2 );
  twobit_label( 1968, compiled_block_2_1968 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 8 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1961, compiled_block_2_1961 );
  twobit_global( 9 ); /*  stream-null~1ayXVW~19360 */
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_48( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 1, 4 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setrtn( 1962, compiled_block_2_1962 );
  twobit_invoke( 1 );
  twobit_label( 1962, compiled_block_2_1962 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_49( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 1, 4 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 3 );
  twobit_setrtn( 1965, compiled_block_2_1965 );
  twobit_invoke( 1 );
  twobit_label( 1965, compiled_block_2_1965 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 3 );
  twobit_pop( 0 );
  twobit_jump( 2, 1947, compiled_block_2_1947 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_26( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1976, compiled_block_2_1976 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_setrtn( 1977, compiled_block_2_1977 );
  twobit_branch( 1973, compiled_block_2_1973 );
  twobit_label( 1977, compiled_block_2_1977 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_pop( 2 );
  twobit_branch( 1971, compiled_block_2_1971 );
  twobit_label( 1976, compiled_block_2_1976 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1971, compiled_block_2_1971 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_movereg( 1, 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_32, 5, 2 );
  twobit_setreg( 1 );
  twobit_lambda( compiled_start_2_33, 7, 0 );
  twobit_setreg( 2 );
  twobit_global( 8 ); /* call-with-values */
  twobit_setrtn( 1982, compiled_block_2_1982 );
  twobit_invoke( 2 );
  twobit_label( 1982, compiled_block_2_1982 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_global( 9 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_34, 11, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1972, compiled_block_2_1972 );
  twobit_lambda( compiled_start_2_35, 13, 2 );
  twobit_setreg( 4 );
  twobit_const( 14 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 15 ); /*  make-stream~1ayXVW~19321 */
  twobit_invoke( 1 );
  twobit_label( 1973, compiled_block_2_1973 );
  twobit_lambda( compiled_start_2_36, 17, 2 );
  twobit_setreg( 4 );
  twobit_const( 14 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 15 ); /*  make-stream~1ayXVW~19321 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_32( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_33( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 1981, compiled_block_2_1981 );
  twobit_invoke( 1 );
  twobit_label( 1981, compiled_block_2_1981 );
  twobit_load( 0, 0 );
  twobit_op2imm_131( fixnum(1), 46, compiled_temp_2_46 ); /* - */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_34( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_612( 44, compiled_temp_2_44, 1984, compiled_block_2_1984 ); /* internal:branchf-zero? */
  twobit_global( 1 ); /* values */
  twobit_setreg( 1 );
  twobit_global( 2 ); /* apply */
  twobit_invoke( 2 );
  twobit_label( 1984, compiled_block_2_1984 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_movereg( 1, 2 );
  twobit_reg( 1 );
  twobit_op2imm_131( fixnum(1), 45, compiled_temp_2_45 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_setrtn( 1986, compiled_block_2_1986 );
  twobit_jump( 1, 1972, compiled_block_2_1972 );
  twobit_label( 1986, compiled_block_2_1986 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 3, 2 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_35( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 2 );
  twobit_op2imm_131( fixnum(1), 41, compiled_temp_2_41 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-car~1ayXVW~19398 */
  twobit_setrtn( 1989, compiled_block_2_1989 );
  twobit_invoke( 1 );
  twobit_label( 1989, compiled_block_2_1989 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 2 ); /* list-ref */
  twobit_setrtn( 1990, compiled_block_2_1990 );
  twobit_invoke( 2 );
  twobit_label( 1990, compiled_block_2_1990 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_branchf( 1992, compiled_block_2_1992 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_42, 4, 2 );
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1995, compiled_block_2_1995 );
  twobit_invoke( 1 );
  twobit_label( 1995, compiled_block_2_1995 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_2_43, 8, 0 );
  twobit_setreg( 3 );
  twobit_const( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 1998, compiled_block_2_1998 );
  twobit_invoke( 1 );
  twobit_label( 1998, compiled_block_2_1998 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 9 ); /*  make-stream-pare~1ayXVW~19369 */
  twobit_setrtn( 1999, compiled_block_2_1999 );
  twobit_invoke( 2 );
  twobit_label( 1999, compiled_block_2_1999 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 10 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1992, compiled_block_2_1992 );
  twobit_reg( 4 );
  twobit_branchf( 2002, compiled_block_2_2002 );
  twobit_reg( 4 );
  twobit_op1_branchf_610( 2004, compiled_block_2_2004 ); /* internal:branchf-null? */
  twobit_global( 11 ); /*  stream-null~1ayXVW~19360 */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2004, compiled_block_2_2004 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_const( 13 );
  twobit_setreg( 2 );
  twobit_global( 14 ); /* error */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2002, compiled_block_2_2002 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 15 ); /*  stream-cdr~1ayXVW~19399 */
  twobit_setrtn( 2006, compiled_block_2_2006 );
  twobit_invoke( 1 );
  twobit_label( 2006, compiled_block_2_2006 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_pop( 1 );
  twobit_jump( 1, 1972, compiled_block_2_1972 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_42( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 1993, compiled_block_2_1993 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-eager~1ayXVW~19343 */
  twobit_invoke( 1 );
  twobit_label( 1993, compiled_block_2_1993 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_43( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-cdr~1ayXVW~19399 */
  twobit_setrtn( 1996, compiled_block_2_1996 );
  twobit_invoke( 1 );
  twobit_label( 1996, compiled_block_2_1996 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_pop( 0 );
  twobit_jump( 2, 1972, compiled_block_2_1972 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_36( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lambda( compiled_start_2_37, 2, 0 );
  twobit_setreg( 1 );
  twobit_lambda( compiled_start_2_38, 4, 0 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_37( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_38( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_2_39, 2, 1 );
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 2011, compiled_block_2_2011 );
  twobit_invoke( 1 );
  twobit_label( 2011, compiled_block_2_2011 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_2_40, 6, 1 );
  twobit_setreg( 3 );
  twobit_const( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 2013, compiled_block_2_2013 );
  twobit_invoke( 1 );
  twobit_label( 2013, compiled_block_2_2013 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 7 ); /*  make-stream-pare~1ayXVW~19369 */
  twobit_setrtn( 2014, compiled_block_2_2014 );
  twobit_invoke( 2 );
  twobit_label( 2014, compiled_block_2_2014 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 8 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_39( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  stream-eager~1ayXVW~19343 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_40( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 2, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_jump( 3, 1973, compiled_block_2_1973 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_27( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 2021, compiled_block_2_2021 ); /* internal:branchf-null? */
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 2021, compiled_block_2_2021 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_lambda( compiled_start_2_28, 5, 0 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /* exists */
  twobit_setrtn( 2024, compiled_block_2_2024 );
  twobit_invoke( 2 );
  twobit_label( 2024, compiled_block_2_2024 );
  twobit_load( 0, 0 );
  twobit_branchf( 2026, compiled_block_2_2026 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 7 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* error */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2026, compiled_block_2_2026 );
  twobit_load( 1, 1 );
  twobit_pop( 1 );
  twobit_label( 2018, compiled_block_2_2018 );
  twobit_lambda( compiled_start_2_29, 9, 1 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 11 ); /*  make-stream~1ayXVW~19321 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_28( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  stream?~1ayXVW~19323 */
  twobit_setrtn( 2023, compiled_block_2_2023 );
  twobit_invoke( 1 );
  twobit_label( 2023, compiled_block_2_2023 );
  twobit_load( 0, 0 );
  twobit_op1_9(); /* not */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_29( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  stream-null?~1ayXVW~19379 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* exists */
  twobit_setrtn( 2029, compiled_block_2_2029 );
  twobit_invoke( 2 );
  twobit_label( 2029, compiled_block_2_2029 );
  twobit_load( 0, 0 );
  twobit_branchf( 2031, compiled_block_2_2031 );
  twobit_global( 3 ); /*  stream-null~1ayXVW~19360 */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2031, compiled_block_2_2031 );
  twobit_lambda( compiled_start_2_30, 5, 0 );
  twobit_setreg( 4 );
  twobit_const( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 7 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 2034, compiled_block_2_2034 );
  twobit_invoke( 1 );
  twobit_label( 2034, compiled_block_2_2034 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_2_31, 9, 0 );
  twobit_setreg( 3 );
  twobit_const( 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 7 ); /*  make-stream~1ayXVW~19321 */
  twobit_setrtn( 2037, compiled_block_2_2037 );
  twobit_invoke( 1 );
  twobit_label( 2037, compiled_block_2_2037 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 10 ); /*  make-stream-pare~1ayXVW~19369 */
  twobit_setrtn( 2038, compiled_block_2_2038 );
  twobit_invoke( 2 );
  twobit_label( 2038, compiled_block_2_2038 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 11 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_30( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  stream-car~1ayXVW~19398 */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  map~1ayXVW~1381 */
  twobit_setrtn( 2032, compiled_block_2_2032 );
  twobit_invoke( 2 );
  twobit_label( 2032, compiled_block_2_2032 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  stream-eager~1ayXVW~19343 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_31( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  stream-cdr~1ayXVW~19399 */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  map~1ayXVW~1381 */
  twobit_setrtn( 2035, compiled_block_2_2035 );
  twobit_invoke( 2 );
  twobit_label( 2035, compiled_block_2_2035 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_pop( 0 );
  twobit_jump( 2, 2018, compiled_block_2_2018 );
  twobit_epilogue();
}


RTYPE twobit_thunk_af55553616217b7f1700476cfd289013_1(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_2_0(CONT_ACTUALS));
}
static RTYPE compiled_block_3_1004( CONT_PARAMS );
static RTYPE compiled_block_3_1003( CONT_PARAMS );
static RTYPE compiled_start_3_0( CONT_PARAMS );
static RTYPE compiled_start_3_3( CONT_PARAMS );
static RTYPE compiled_start_3_2( CONT_PARAMS );
static RTYPE compiled_start_3_1( CONT_PARAMS );

static RTYPE compiled_start_3_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_3_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_3_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_3_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1003, compiled_block_3_1003 );
  twobit_invoke( 8 );
  twobit_label( 1003, compiled_block_3_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1004, compiled_block_3_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_3_1004 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_3_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_3_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_3_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_af55553616217b7f1700476cfd289013_2(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_3_0(CONT_ACTUALS));
}
static RTYPE compiled_block_4_1004( CONT_PARAMS );
static RTYPE compiled_block_4_1003( CONT_PARAMS );
static RTYPE compiled_start_4_0( CONT_PARAMS );
static RTYPE compiled_start_4_3( CONT_PARAMS );
static RTYPE compiled_start_4_2( CONT_PARAMS );
static RTYPE compiled_start_4_1( CONT_PARAMS );

static RTYPE compiled_start_4_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_4_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_4_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_4_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1003, compiled_block_4_1003 );
  twobit_invoke( 8 );
  twobit_label( 1003, compiled_block_4_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1004, compiled_block_4_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_4_1004 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_4_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_4_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_4_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_af55553616217b7f1700476cfd289013_3(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_4_0(CONT_ACTUALS));
}
codeptr_t CDECL twobit_load_table[] = { 
  twobit_thunk_af55553616217b7f1700476cfd289013_0,
  twobit_thunk_af55553616217b7f1700476cfd289013_1,
  twobit_thunk_af55553616217b7f1700476cfd289013_2,
  twobit_thunk_af55553616217b7f1700476cfd289013_3,
  0  /* The table may be empty; some compilers complain */
};

/* Generated from /proj/will/pnkfelix/larcenytest/larceny-petit-Nightly-2009-08-19/larceny_src/lib/SRFI/srfi/%3a27.slfasl */
#include "petit-instr.h"

static RTYPE compiled_block_1_1277( CONT_PARAMS );
static RTYPE compiled_block_1_1276( CONT_PARAMS );
static RTYPE compiled_start_1_0( CONT_PARAMS );
static RTYPE compiled_block_1_1274( CONT_PARAMS );
static RTYPE compiled_block_1_1273( CONT_PARAMS );
static RTYPE compiled_block_1_1272( CONT_PARAMS );
static RTYPE compiled_block_1_1201( CONT_PARAMS );
static RTYPE compiled_block_1_1011( CONT_PARAMS );
static RTYPE compiled_block_1_1010( CONT_PARAMS );
static RTYPE compiled_block_1_1009( CONT_PARAMS );
static RTYPE compiled_block_1_1008( CONT_PARAMS );
static RTYPE compiled_block_1_1007( CONT_PARAMS );
static RTYPE compiled_block_1_1006( CONT_PARAMS );
static RTYPE compiled_block_1_1005( CONT_PARAMS );
static RTYPE compiled_block_1_1004( CONT_PARAMS );
static RTYPE compiled_block_1_1003( CONT_PARAMS );
static RTYPE compiled_block_1_1002( CONT_PARAMS );
static RTYPE compiled_start_1_3( CONT_PARAMS );
static RTYPE compiled_block_1_1270( CONT_PARAMS );
static RTYPE compiled_start_1_24( CONT_PARAMS );
static RTYPE compiled_block_1_1268( CONT_PARAMS );
static RTYPE compiled_start_1_23( CONT_PARAMS );
static RTYPE compiled_block_1_1266( CONT_PARAMS );
static RTYPE compiled_start_1_22( CONT_PARAMS );
static RTYPE compiled_block_1_1264( CONT_PARAMS );
static RTYPE compiled_start_1_21( CONT_PARAMS );
static RTYPE compiled_block_1_1262( CONT_PARAMS );
static RTYPE compiled_start_1_20( CONT_PARAMS );
static RTYPE compiled_block_1_1260( CONT_PARAMS );
static RTYPE compiled_start_1_19( CONT_PARAMS );
static RTYPE compiled_block_1_1225( CONT_PARAMS );
static RTYPE compiled_block_1_1224( CONT_PARAMS );
static RTYPE compiled_block_1_1223( CONT_PARAMS );
static RTYPE compiled_start_1_18( CONT_PARAMS );
static RTYPE compiled_block_1_1244( CONT_PARAMS );
static RTYPE compiled_block_1_1246( CONT_PARAMS );
static RTYPE compiled_block_1_1252( CONT_PARAMS );
static RTYPE compiled_block_1_1254( CONT_PARAMS );
static RTYPE compiled_temp_1_36( CONT_PARAMS );
static RTYPE compiled_temp_1_35( CONT_PARAMS );
static RTYPE compiled_temp_1_34( CONT_PARAMS );
static RTYPE compiled_block_1_1247( CONT_PARAMS );
static RTYPE compiled_block_1_1248( CONT_PARAMS );
static RTYPE compiled_block_1_1250( CONT_PARAMS );
static RTYPE compiled_temp_1_33( CONT_PARAMS );
static RTYPE compiled_temp_1_32( CONT_PARAMS );
static RTYPE compiled_block_1_1242( CONT_PARAMS );
static RTYPE compiled_start_1_30( CONT_PARAMS );
static RTYPE compiled_start_1_38( CONT_PARAMS );
static RTYPE compiled_start_1_37( CONT_PARAMS );
static RTYPE compiled_start_1_31( CONT_PARAMS );
static RTYPE compiled_start_1_29( CONT_PARAMS );
static RTYPE compiled_block_1_1235( CONT_PARAMS );
static RTYPE compiled_block_1_1237( CONT_PARAMS );
static RTYPE compiled_temp_1_41( CONT_PARAMS );
static RTYPE compiled_block_1_1230( CONT_PARAMS );
static RTYPE compiled_block_1_1231( CONT_PARAMS );
static RTYPE compiled_block_1_1233( CONT_PARAMS );
static RTYPE compiled_temp_1_40( CONT_PARAMS );
static RTYPE compiled_start_1_39( CONT_PARAMS );
static RTYPE compiled_block_1_1229( CONT_PARAMS );
static RTYPE compiled_start_1_28( CONT_PARAMS );
static RTYPE compiled_block_1_1228( CONT_PARAMS );
static RTYPE compiled_start_1_27( CONT_PARAMS );
static RTYPE compiled_block_1_1227( CONT_PARAMS );
static RTYPE compiled_start_1_26( CONT_PARAMS );
static RTYPE compiled_start_1_25( CONT_PARAMS );
static RTYPE compiled_temp_1_43( CONT_PARAMS );
static RTYPE compiled_temp_1_42( CONT_PARAMS );
static RTYPE compiled_start_1_17( CONT_PARAMS );
static RTYPE compiled_temp_1_52( CONT_PARAMS );
static RTYPE compiled_temp_1_51( CONT_PARAMS );
static RTYPE compiled_block_1_1218( CONT_PARAMS );
static RTYPE compiled_temp_1_50( CONT_PARAMS );
static RTYPE compiled_temp_1_49( CONT_PARAMS );
static RTYPE compiled_temp_1_48( CONT_PARAMS );
static RTYPE compiled_block_1_1220( CONT_PARAMS );
static RTYPE compiled_temp_1_47( CONT_PARAMS );
static RTYPE compiled_temp_1_46( CONT_PARAMS );
static RTYPE compiled_block_1_1219( CONT_PARAMS );
static RTYPE compiled_temp_1_45( CONT_PARAMS );
static RTYPE compiled_start_1_44( CONT_PARAMS );
static RTYPE compiled_temp_1_53( CONT_PARAMS );
static RTYPE compiled_start_1_16( CONT_PARAMS );
static RTYPE compiled_temp_1_60( CONT_PARAMS );
static RTYPE compiled_temp_1_59( CONT_PARAMS );
static RTYPE compiled_block_1_1208( CONT_PARAMS );
static RTYPE compiled_block_1_1209( CONT_PARAMS );
static RTYPE compiled_temp_1_57( CONT_PARAMS );
static RTYPE compiled_temp_1_56( CONT_PARAMS );
static RTYPE compiled_temp_1_55( CONT_PARAMS );
static RTYPE compiled_start_1_54( CONT_PARAMS );
static RTYPE compiled_block_1_1212( CONT_PARAMS );
static RTYPE compiled_block_1_1211( CONT_PARAMS );
static RTYPE compiled_temp_1_62( CONT_PARAMS );
static RTYPE compiled_temp_1_61( CONT_PARAMS );
static RTYPE compiled_start_1_58( CONT_PARAMS );
static RTYPE compiled_temp_1_66( CONT_PARAMS );
static RTYPE compiled_block_1_1206( CONT_PARAMS );
static RTYPE compiled_temp_1_65( CONT_PARAMS );
static RTYPE compiled_block_1_1205( CONT_PARAMS );
static RTYPE compiled_temp_1_64( CONT_PARAMS );
static RTYPE compiled_block_1_1203( CONT_PARAMS );
static RTYPE compiled_temp_1_63( CONT_PARAMS );
static RTYPE compiled_start_1_15( CONT_PARAMS );
static RTYPE compiled_block_1_1181( CONT_PARAMS );
static RTYPE compiled_block_1_1190( CONT_PARAMS );
static RTYPE compiled_block_1_1178( CONT_PARAMS );
static RTYPE compiled_block_1_1184( CONT_PARAMS );
static RTYPE compiled_block_1_1193( CONT_PARAMS );
static RTYPE compiled_block_1_1187( CONT_PARAMS );
static RTYPE compiled_temp_1_84( CONT_PARAMS );
static RTYPE compiled_temp_1_83( CONT_PARAMS );
static RTYPE compiled_temp_1_82( CONT_PARAMS );
static RTYPE compiled_block_1_1200( CONT_PARAMS );
static RTYPE compiled_block_1_1173( CONT_PARAMS );
static RTYPE compiled_temp_1_81( CONT_PARAMS );
static RTYPE compiled_block_1_1198( CONT_PARAMS );
static RTYPE compiled_temp_1_80( CONT_PARAMS );
static RTYPE compiled_temp_1_79( CONT_PARAMS );
static RTYPE compiled_temp_1_78( CONT_PARAMS );
static RTYPE compiled_temp_1_77( CONT_PARAMS );
static RTYPE compiled_block_1_1197( CONT_PARAMS );
static RTYPE compiled_block_1_1172( CONT_PARAMS );
static RTYPE compiled_temp_1_76( CONT_PARAMS );
static RTYPE compiled_block_1_1195( CONT_PARAMS );
static RTYPE compiled_temp_1_75( CONT_PARAMS );
static RTYPE compiled_block_1_1194( CONT_PARAMS );
static RTYPE compiled_temp_1_74( CONT_PARAMS );
static RTYPE compiled_block_1_1192( CONT_PARAMS );
static RTYPE compiled_temp_1_73( CONT_PARAMS );
static RTYPE compiled_block_1_1191( CONT_PARAMS );
static RTYPE compiled_block_1_1189( CONT_PARAMS );
static RTYPE compiled_temp_1_72( CONT_PARAMS );
static RTYPE compiled_block_1_1188( CONT_PARAMS );
static RTYPE compiled_temp_1_71( CONT_PARAMS );
static RTYPE compiled_block_1_1186( CONT_PARAMS );
static RTYPE compiled_temp_1_70( CONT_PARAMS );
static RTYPE compiled_block_1_1185( CONT_PARAMS );
static RTYPE compiled_temp_1_69( CONT_PARAMS );
static RTYPE compiled_block_1_1183( CONT_PARAMS );
static RTYPE compiled_temp_1_68( CONT_PARAMS );
static RTYPE compiled_block_1_1182( CONT_PARAMS );
static RTYPE compiled_block_1_1180( CONT_PARAMS );
static RTYPE compiled_temp_1_67( CONT_PARAMS );
static RTYPE compiled_block_1_1179( CONT_PARAMS );
static RTYPE compiled_block_1_1177( CONT_PARAMS );
static RTYPE compiled_block_1_1176( CONT_PARAMS );
static RTYPE compiled_block_1_1175( CONT_PARAMS );
static RTYPE compiled_start_1_14( CONT_PARAMS );
static RTYPE compiled_block_1_1122( CONT_PARAMS );
static RTYPE compiled_block_1_1123( CONT_PARAMS );
static RTYPE compiled_block_1_1124( CONT_PARAMS );
static RTYPE compiled_block_1_1119( CONT_PARAMS );
static RTYPE compiled_block_1_1120( CONT_PARAMS );
static RTYPE compiled_block_1_1121( CONT_PARAMS );
static RTYPE compiled_block_1_1171( CONT_PARAMS );
static RTYPE compiled_block_1_1170( CONT_PARAMS );
static RTYPE compiled_block_1_1169( CONT_PARAMS );
static RTYPE compiled_block_1_1168( CONT_PARAMS );
static RTYPE compiled_block_1_1167( CONT_PARAMS );
static RTYPE compiled_block_1_1166( CONT_PARAMS );
static RTYPE compiled_block_1_1165( CONT_PARAMS );
static RTYPE compiled_block_1_1164( CONT_PARAMS );
static RTYPE compiled_block_1_1163( CONT_PARAMS );
static RTYPE compiled_block_1_1162( CONT_PARAMS );
static RTYPE compiled_block_1_1161( CONT_PARAMS );
static RTYPE compiled_block_1_1160( CONT_PARAMS );
static RTYPE compiled_block_1_1159( CONT_PARAMS );
static RTYPE compiled_block_1_1158( CONT_PARAMS );
static RTYPE compiled_block_1_1157( CONT_PARAMS );
static RTYPE compiled_block_1_1156( CONT_PARAMS );
static RTYPE compiled_block_1_1155( CONT_PARAMS );
static RTYPE compiled_block_1_1154( CONT_PARAMS );
static RTYPE compiled_block_1_1090( CONT_PARAMS );
static RTYPE compiled_block_1_1139( CONT_PARAMS );
static RTYPE compiled_temp_1_90( CONT_PARAMS );
static RTYPE compiled_block_1_1136( CONT_PARAMS );
static RTYPE compiled_block_1_1137( CONT_PARAMS );
static RTYPE compiled_temp_1_89( CONT_PARAMS );
static RTYPE compiled_block_1_1134( CONT_PARAMS );
static RTYPE compiled_block_1_1133( CONT_PARAMS );
static RTYPE compiled_temp_1_88( CONT_PARAMS );
static RTYPE compiled_block_1_1131( CONT_PARAMS );
static RTYPE compiled_temp_1_87( CONT_PARAMS );
static RTYPE compiled_block_1_1089( CONT_PARAMS );
static RTYPE compiled_block_1_1128( CONT_PARAMS );
static RTYPE compiled_temp_1_86( CONT_PARAMS );
static RTYPE compiled_block_1_1127( CONT_PARAMS );
static RTYPE compiled_temp_1_85( CONT_PARAMS );
static RTYPE compiled_block_1_1088( CONT_PARAMS );
static RTYPE compiled_block_1_1118( CONT_PARAMS );
static RTYPE compiled_block_1_1117( CONT_PARAMS );
static RTYPE compiled_block_1_1116( CONT_PARAMS );
static RTYPE compiled_block_1_1115( CONT_PARAMS );
static RTYPE compiled_block_1_1114( CONT_PARAMS );
static RTYPE compiled_block_1_1113( CONT_PARAMS );
static RTYPE compiled_block_1_1112( CONT_PARAMS );
static RTYPE compiled_block_1_1111( CONT_PARAMS );
static RTYPE compiled_block_1_1110( CONT_PARAMS );
static RTYPE compiled_block_1_1109( CONT_PARAMS );
static RTYPE compiled_block_1_1108( CONT_PARAMS );
static RTYPE compiled_block_1_1101( CONT_PARAMS );
static RTYPE compiled_block_1_1107( CONT_PARAMS );
static RTYPE compiled_block_1_1106( CONT_PARAMS );
static RTYPE compiled_block_1_1105( CONT_PARAMS );
static RTYPE compiled_block_1_1104( CONT_PARAMS );
static RTYPE compiled_block_1_1103( CONT_PARAMS );
static RTYPE compiled_block_1_1102( CONT_PARAMS );
static RTYPE compiled_block_1_1098( CONT_PARAMS );
static RTYPE compiled_block_1_1100( CONT_PARAMS );
static RTYPE compiled_block_1_1099( CONT_PARAMS );
static RTYPE compiled_block_1_1092( CONT_PARAMS );
static RTYPE compiled_block_1_1093( CONT_PARAMS );
static RTYPE compiled_block_1_1095( CONT_PARAMS );
static RTYPE compiled_block_1_1097( CONT_PARAMS );
static RTYPE compiled_start_1_13( CONT_PARAMS );
static RTYPE compiled_block_1_1144( CONT_PARAMS );
static RTYPE compiled_block_1_1148( CONT_PARAMS );
static RTYPE compiled_block_1_1141( CONT_PARAMS );
static RTYPE compiled_block_1_1142( CONT_PARAMS );
static RTYPE compiled_block_1_1149( CONT_PARAMS );
static RTYPE compiled_block_1_1145( CONT_PARAMS );
static RTYPE compiled_temp_1_122( CONT_PARAMS );
static RTYPE compiled_temp_1_121( CONT_PARAMS );
static RTYPE compiled_temp_1_120( CONT_PARAMS );
static RTYPE compiled_temp_1_119( CONT_PARAMS );
static RTYPE compiled_temp_1_118( CONT_PARAMS );
static RTYPE compiled_temp_1_117( CONT_PARAMS );
static RTYPE compiled_temp_1_116( CONT_PARAMS );
static RTYPE compiled_temp_1_115( CONT_PARAMS );
static RTYPE compiled_temp_1_114( CONT_PARAMS );
static RTYPE compiled_temp_1_113( CONT_PARAMS );
static RTYPE compiled_temp_1_112( CONT_PARAMS );
static RTYPE compiled_temp_1_111( CONT_PARAMS );
static RTYPE compiled_temp_1_110( CONT_PARAMS );
static RTYPE compiled_temp_1_109( CONT_PARAMS );
static RTYPE compiled_temp_1_108( CONT_PARAMS );
static RTYPE compiled_temp_1_107( CONT_PARAMS );
static RTYPE compiled_temp_1_106( CONT_PARAMS );
static RTYPE compiled_temp_1_105( CONT_PARAMS );
static RTYPE compiled_temp_1_104( CONT_PARAMS );
static RTYPE compiled_temp_1_103( CONT_PARAMS );
static RTYPE compiled_temp_1_102( CONT_PARAMS );
static RTYPE compiled_temp_1_101( CONT_PARAMS );
static RTYPE compiled_temp_1_100( CONT_PARAMS );
static RTYPE compiled_temp_1_99( CONT_PARAMS );
static RTYPE compiled_temp_1_98( CONT_PARAMS );
static RTYPE compiled_temp_1_97( CONT_PARAMS );
static RTYPE compiled_temp_1_96( CONT_PARAMS );
static RTYPE compiled_temp_1_95( CONT_PARAMS );
static RTYPE compiled_temp_1_94( CONT_PARAMS );
static RTYPE compiled_temp_1_93( CONT_PARAMS );
static RTYPE compiled_temp_1_92( CONT_PARAMS );
static RTYPE compiled_block_1_1152( CONT_PARAMS );
static RTYPE compiled_block_1_1151( CONT_PARAMS );
static RTYPE compiled_block_1_1150( CONT_PARAMS );
static RTYPE compiled_block_1_1147( CONT_PARAMS );
static RTYPE compiled_block_1_1146( CONT_PARAMS );
static RTYPE compiled_block_1_1143( CONT_PARAMS );
static RTYPE compiled_start_1_91( CONT_PARAMS );
static RTYPE compiled_block_1_1049( CONT_PARAMS );
static RTYPE compiled_block_1_1052( CONT_PARAMS );
static RTYPE compiled_block_1_1086( CONT_PARAMS );
static RTYPE compiled_block_1_1079( CONT_PARAMS );
static RTYPE compiled_block_1_1080( CONT_PARAMS );
static RTYPE compiled_block_1_1082( CONT_PARAMS );
static RTYPE compiled_block_1_1084( CONT_PARAMS );
static RTYPE compiled_temp_1_132( CONT_PARAMS );
static RTYPE compiled_temp_1_131( CONT_PARAMS );
static RTYPE compiled_temp_1_130( CONT_PARAMS );
static RTYPE compiled_block_1_1041( CONT_PARAMS );
static RTYPE compiled_block_1_1051( CONT_PARAMS );
static RTYPE compiled_block_1_1076( CONT_PARAMS );
static RTYPE compiled_block_1_1073( CONT_PARAMS );
static RTYPE compiled_block_1_1074( CONT_PARAMS );
static RTYPE compiled_block_1_1075( CONT_PARAMS );
static RTYPE compiled_block_1_1068( CONT_PARAMS );
static RTYPE compiled_temp_1_129( CONT_PARAMS );
static RTYPE compiled_temp_1_128( CONT_PARAMS );
static RTYPE compiled_temp_1_127( CONT_PARAMS );
static RTYPE compiled_block_1_1072( CONT_PARAMS );
static RTYPE compiled_block_1_1071( CONT_PARAMS );
static RTYPE compiled_block_1_1070( CONT_PARAMS );
static RTYPE compiled_block_1_1069( CONT_PARAMS );
static RTYPE compiled_temp_1_126( CONT_PARAMS );
static RTYPE compiled_temp_1_125( CONT_PARAMS );
static RTYPE compiled_temp_1_124( CONT_PARAMS );
static RTYPE compiled_block_1_1067( CONT_PARAMS );
static RTYPE compiled_block_1_1066( CONT_PARAMS );
static RTYPE compiled_block_1_1065( CONT_PARAMS );
static RTYPE compiled_block_1_1064( CONT_PARAMS );
static RTYPE compiled_block_1_1063( CONT_PARAMS );
static RTYPE compiled_block_1_1062( CONT_PARAMS );
static RTYPE compiled_block_1_1061( CONT_PARAMS );
static RTYPE compiled_block_1_1060( CONT_PARAMS );
static RTYPE compiled_block_1_1059( CONT_PARAMS );
static RTYPE compiled_block_1_1058( CONT_PARAMS );
static RTYPE compiled_block_1_1057( CONT_PARAMS );
static RTYPE compiled_block_1_1056( CONT_PARAMS );
static RTYPE compiled_block_1_1055( CONT_PARAMS );
static RTYPE compiled_block_1_1054( CONT_PARAMS );
static RTYPE compiled_block_1_1053( CONT_PARAMS );
static RTYPE compiled_block_1_1044( CONT_PARAMS );
static RTYPE compiled_block_1_1045( CONT_PARAMS );
static RTYPE compiled_block_1_1048( CONT_PARAMS );
static RTYPE compiled_temp_1_123( CONT_PARAMS );
static RTYPE compiled_block_1_1046( CONT_PARAMS );
static RTYPE compiled_block_1_1043( CONT_PARAMS );
static RTYPE compiled_start_1_12( CONT_PARAMS );
static RTYPE compiled_block_1_1040( CONT_PARAMS );
static RTYPE compiled_block_1_1039( CONT_PARAMS );
static RTYPE compiled_start_1_11( CONT_PARAMS );
static RTYPE compiled_temp_1_134( CONT_PARAMS );
static RTYPE compiled_temp_1_133( CONT_PARAMS );
static RTYPE compiled_block_1_1038( CONT_PARAMS );
static RTYPE compiled_start_1_10( CONT_PARAMS );
static RTYPE compiled_block_1_1031( CONT_PARAMS );
static RTYPE compiled_temp_1_137( CONT_PARAMS );
static RTYPE compiled_block_1_1030( CONT_PARAMS );
static RTYPE compiled_temp_1_136( CONT_PARAMS );
static RTYPE compiled_temp_1_135( CONT_PARAMS );
static RTYPE compiled_start_1_9( CONT_PARAMS );
static RTYPE compiled_block_1_1035( CONT_PARAMS );
static RTYPE compiled_block_1_1033( CONT_PARAMS );
static RTYPE compiled_temp_1_141( CONT_PARAMS );
static RTYPE compiled_block_1_1034( CONT_PARAMS );
static RTYPE compiled_temp_1_140( CONT_PARAMS );
static RTYPE compiled_temp_1_139( CONT_PARAMS );
static RTYPE compiled_start_1_138( CONT_PARAMS );
static RTYPE compiled_start_1_8( CONT_PARAMS );
static RTYPE compiled_block_1_1027( CONT_PARAMS );
static RTYPE compiled_block_1_1026( CONT_PARAMS );
static RTYPE compiled_start_1_7( CONT_PARAMS );
static RTYPE compiled_block_1_1024( CONT_PARAMS );
static RTYPE compiled_block_1_1023( CONT_PARAMS );
static RTYPE compiled_start_1_6( CONT_PARAMS );
static RTYPE compiled_block_1_1022( CONT_PARAMS );
static RTYPE compiled_block_1_1021( CONT_PARAMS );
static RTYPE compiled_block_1_1015( CONT_PARAMS );
static RTYPE compiled_block_1_1018( CONT_PARAMS );
static RTYPE compiled_block_1_1017( CONT_PARAMS );
static RTYPE compiled_block_1_1014( CONT_PARAMS );
static RTYPE compiled_temp_1_157( CONT_PARAMS );
static RTYPE compiled_temp_1_156( CONT_PARAMS );
static RTYPE compiled_block_1_1020( CONT_PARAMS );
static RTYPE compiled_temp_1_155( CONT_PARAMS );
static RTYPE compiled_temp_1_154( CONT_PARAMS );
static RTYPE compiled_temp_1_153( CONT_PARAMS );
static RTYPE compiled_temp_1_152( CONT_PARAMS );
static RTYPE compiled_block_1_1019( CONT_PARAMS );
static RTYPE compiled_temp_1_151( CONT_PARAMS );
static RTYPE compiled_temp_1_150( CONT_PARAMS );
static RTYPE compiled_temp_1_149( CONT_PARAMS );
static RTYPE compiled_temp_1_148( CONT_PARAMS );
static RTYPE compiled_temp_1_147( CONT_PARAMS );
static RTYPE compiled_temp_1_146( CONT_PARAMS );
static RTYPE compiled_block_1_1016( CONT_PARAMS );
static RTYPE compiled_temp_1_145( CONT_PARAMS );
static RTYPE compiled_temp_1_144( CONT_PARAMS );
static RTYPE compiled_temp_1_143( CONT_PARAMS );
static RTYPE compiled_temp_1_142( CONT_PARAMS );
static RTYPE compiled_start_1_5( CONT_PARAMS );
static RTYPE compiled_start_1_4( CONT_PARAMS );
static RTYPE compiled_temp_1_160( CONT_PARAMS );
static RTYPE compiled_start_1_159( CONT_PARAMS );
static RTYPE compiled_start_1_158( CONT_PARAMS );
static RTYPE compiled_start_1_2( CONT_PARAMS );
static RTYPE compiled_start_1_1( CONT_PARAMS );

static RTYPE compiled_start_1_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 2 ); /*  random-real~1ayXVW~13283 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 3 ); /*  random-integer~1ayXVW~13282 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 4 ); /*  default-random-source~1ayXVW~13281 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 5 ); /*  random-source-make-reals~1ayXVW~13280 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 6 ); /*  random-source-make-integers~1ayXVW~13279 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 7 ); /*  random-source-pseudo-randomize!~1ayXVW~13278 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 8 ); /*  random-source-randomize!~1ayXVW~13277 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 9 ); /*  random-source-state-set!~1ayXVW~13276 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 10 ); /*  random-source-state-ref~1ayXVW~13275 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 11 ); /*  random-source?~1ayXVW~13274 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 12 ); /*  make-random-source~1ayXVW~13273 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 13 ); /*  mrg32k3a-random-real-mp~1ayXVW~13272 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 14 ); /*  mrg32k3a-random-large~1ayXVW~13271 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 15 ); /*  mrg32k3a-random-power~1ayXVW~13270 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 16 ); /*  mrg32k3a-m-max~1ayXVW~13269 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 17 ); /*  mrg32k3a-randomize-state~1ayXVW~13268 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 18 ); /*  mrg32k3a-pseudo-randomize-state~1ayXVW~13267 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 19 ); /*  mrg32k3a-generators~1ayXVW~13266 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 20 ); /*  mrg32k3a-initial-state~1ayXVW~13265 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 21 ); /*  mrg32k3a-m2~1ayXVW~13264 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 22 ); /*  mrg32k3a-m1~1ayXVW~13263 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 23 ); /*  mrg32k3a-state-set~1ayXVW~13262 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 24 ); /*  mrg32k3a-state-ref~1ayXVW~13261 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 25 ); /*  mrg32k3a-random-real~1ayXVW~13260 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 26 ); /*  mrg32k3a-random-integer~1ayXVW~13259 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 27 ); /*  mrg32k3a-random-range~1ayXVW~13258 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 28 ); /*  mrg32k3a-unpack-state~1ayXVW~13257 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 29 ); /*  mrg32k3a-pack-state~1ayXVW~13256 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 30 ); /*  mrg32k3a-random-m1~1ayXVW~13255 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 31 ); /*  :random-source-current-time~1ayXVW~13254 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 32 ); /*  :random-source-make-reals~1ayXVW~13253 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 33 ); /*  :random-source-make-integers~1ayXVW~13252 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 34 ); /*  :random-source-pseudo-randomize!~1ayXVW~13251 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 35 ); /*  :random-source-randomize!~1ayXVW~13250 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 36 ); /*  :random-source-state-set!~1ayXVW~13249 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 37 ); /*  :random-source-state-ref~1ayXVW~13248 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 38 ); /*  :random-source?~1ayXVW~13247 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 39 ); /*  :random-source-make~1ayXVW~13246 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 40 ); /*  :random-source~1ayXVW~13245 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 41 ); /*  most-positive-fixnum~1ayXVW~13241 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 42 ); /*  ignored~1ayXVW~13240 */
  twobit_lambda( compiled_start_1_1, 44, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_2, 46, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_3, 48, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 49 );
  twobit_setreg( 1 );
  twobit_const( 50 );
  twobit_setreg( 3 );
  twobit_const( 51 );
  twobit_setreg( 4 );
  twobit_const( 52 );
  twobit_setreg( 5 );
  twobit_const( 53 );
  twobit_setreg( 8 );
  twobit_global( 54 ); /* ex:make-library */
  twobit_setrtn( 1276, compiled_block_1_1276 );
  twobit_invoke( 8 );
  twobit_label( 1276, compiled_block_1_1276 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 55 ); /* ex:register-library! */
  twobit_setrtn( 1277, compiled_block_1_1277 );
  twobit_invoke( 1 );
  twobit_label( 1277, compiled_block_1_1277 );
  twobit_load( 0, 0 );
  twobit_global( 56 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 2 ); /*  random-real~1ayXVW~13283 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 3 ); /*  random-integer~1ayXVW~13282 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 4 ); /*  default-random-source~1ayXVW~13281 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 5 ); /*  random-source-make-reals~1ayXVW~13280 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 6 ); /*  random-source-make-integers~1ayXVW~13279 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 7 ); /*  random-source-pseudo-randomize!~1ayXVW~13278 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 8 ); /*  random-source-randomize!~1ayXVW~13277 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 9 ); /*  random-source-state-set!~1ayXVW~13276 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 10 ); /*  random-source-state-ref~1ayXVW~13275 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 11 ); /*  random-source?~1ayXVW~13274 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 12 ); /*  make-random-source~1ayXVW~13273 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 13 ); /*  mrg32k3a-random-real-mp~1ayXVW~13272 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 14 ); /*  mrg32k3a-random-large~1ayXVW~13271 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 15 ); /*  mrg32k3a-random-power~1ayXVW~13270 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 16 ); /*  mrg32k3a-m-max~1ayXVW~13269 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 17 ); /*  mrg32k3a-randomize-state~1ayXVW~13268 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 18 ); /*  mrg32k3a-pseudo-randomize-state~1ayXVW~13267 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 19 ); /*  mrg32k3a-generators~1ayXVW~13266 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 20 ); /*  mrg32k3a-initial-state~1ayXVW~13265 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 21 ); /*  mrg32k3a-m2~1ayXVW~13264 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 22 ); /*  mrg32k3a-m1~1ayXVW~13263 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 23 ); /*  mrg32k3a-state-set~1ayXVW~13262 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 24 ); /*  mrg32k3a-state-ref~1ayXVW~13261 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 25 ); /*  mrg32k3a-random-real~1ayXVW~13260 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 26 ); /*  mrg32k3a-random-integer~1ayXVW~13259 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 27 ); /*  mrg32k3a-random-range~1ayXVW~13258 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 28 ); /*  mrg32k3a-unpack-state~1ayXVW~13257 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 29 ); /*  mrg32k3a-pack-state~1ayXVW~13256 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 30 ); /*  mrg32k3a-random-m1~1ayXVW~13255 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 31 ); /*  :random-source-current-time~1ayXVW~13254 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 32 ); /*  :random-source-make-reals~1ayXVW~13253 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 33 ); /*  :random-source-make-integers~1ayXVW~13252 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 34 ); /*  :random-source-pseudo-randomize!~1ayXVW~13251 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 35 ); /*  :random-source-randomize!~1ayXVW~13250 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 36 ); /*  :random-source-state-set!~1ayXVW~13249 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 37 ); /*  :random-source-state-ref~1ayXVW~13248 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 38 ); /*  :random-source?~1ayXVW~13247 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 39 ); /*  :random-source-make~1ayXVW~13246 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 40 ); /*  :random-source~1ayXVW~13245 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 41 ); /*  most-positive-fixnum~1ayXVW~13241 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 42 ); /*  ignored~1ayXVW~13240 */
  twobit_const( 43 );
  twobit_setreg( 1 );
  twobit_global( 44 ); /* r5rs:require */
  twobit_setrtn( 1002, compiled_block_1_1002 );
  twobit_invoke( 1 );
  twobit_label( 1002, compiled_block_1_1002 );
  twobit_load( 0, 0 );
  twobit_setglbl( 42 ); /*  ignored~1ayXVW~13240 */
  twobit_global( 45 ); /* greatest-fixnum */
  twobit_setglbl( 41 ); /*  most-positive-fixnum~1ayXVW~13241 */
  twobit_const( 46 );
  twobit_setreg( 1 );
  twobit_const( 47 );
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_global( 48 ); /* make-rtd */
  twobit_setrtn( 1003, compiled_block_1_1003 );
  twobit_invoke( 3 );
  twobit_label( 1003, compiled_block_1_1003 );
  twobit_load( 0, 0 );
  twobit_setglbl( 40 ); /*  :random-source~1ayXVW~13245 */
  twobit_global( 40 ); /*  :random-source~1ayXVW~13245 */
  twobit_setreg( 1 );
  twobit_const( 47 );
  twobit_setreg( 2 );
  twobit_global( 49 ); /* rtd-constructor */
  twobit_setrtn( 1004, compiled_block_1_1004 );
  twobit_invoke( 2 );
  twobit_label( 1004, compiled_block_1_1004 );
  twobit_load( 0, 0 );
  twobit_setglbl( 39 ); /*  :random-source-make~1ayXVW~13246 */
  twobit_global( 40 ); /*  :random-source~1ayXVW~13245 */
  twobit_setreg( 1 );
  twobit_global( 50 ); /* rtd-predicate */
  twobit_setrtn( 1005, compiled_block_1_1005 );
  twobit_invoke( 1 );
  twobit_label( 1005, compiled_block_1_1005 );
  twobit_load( 0, 0 );
  twobit_setglbl( 38 ); /*  :random-source?~1ayXVW~13247 */
  twobit_global( 40 ); /*  :random-source~1ayXVW~13245 */
  twobit_setreg( 1 );
  twobit_const( 51 );
  twobit_setreg( 2 );
  twobit_global( 52 ); /* rtd-accessor */
  twobit_setrtn( 1006, compiled_block_1_1006 );
  twobit_invoke( 2 );
  twobit_label( 1006, compiled_block_1_1006 );
  twobit_load( 0, 0 );
  twobit_setglbl( 37 ); /*  :random-source-state-ref~1ayXVW~13248 */
  twobit_global( 40 ); /*  :random-source~1ayXVW~13245 */
  twobit_setreg( 1 );
  twobit_const( 53 );
  twobit_setreg( 2 );
  twobit_global( 54 ); /* rtd-accessor */
  twobit_setrtn( 1007, compiled_block_1_1007 );
  twobit_invoke( 2 );
  twobit_label( 1007, compiled_block_1_1007 );
  twobit_load( 0, 0 );
  twobit_setglbl( 36 ); /*  :random-source-state-set!~1ayXVW~13249 */
  twobit_global( 40 ); /*  :random-source~1ayXVW~13245 */
  twobit_setreg( 1 );
  twobit_const( 55 );
  twobit_setreg( 2 );
  twobit_global( 56 ); /* rtd-accessor */
  twobit_setrtn( 1008, compiled_block_1_1008 );
  twobit_invoke( 2 );
  twobit_label( 1008, compiled_block_1_1008 );
  twobit_load( 0, 0 );
  twobit_setglbl( 35 ); /*  :random-source-randomize!~1ayXVW~13250 */
  twobit_global( 40 ); /*  :random-source~1ayXVW~13245 */
  twobit_setreg( 1 );
  twobit_const( 57 );
  twobit_setreg( 2 );
  twobit_global( 58 ); /* rtd-accessor */
  twobit_setrtn( 1009, compiled_block_1_1009 );
  twobit_invoke( 2 );
  twobit_label( 1009, compiled_block_1_1009 );
  twobit_load( 0, 0 );
  twobit_setglbl( 34 ); /*  :random-source-pseudo-randomize!~1ayXVW~13251 */
  twobit_global( 40 ); /*  :random-source~1ayXVW~13245 */
  twobit_setreg( 1 );
  twobit_const( 59 );
  twobit_setreg( 2 );
  twobit_global( 60 ); /* rtd-accessor */
  twobit_setrtn( 1010, compiled_block_1_1010 );
  twobit_invoke( 2 );
  twobit_label( 1010, compiled_block_1_1010 );
  twobit_load( 0, 0 );
  twobit_setglbl( 33 ); /*  :random-source-make-integers~1ayXVW~13252 */
  twobit_global( 40 ); /*  :random-source~1ayXVW~13245 */
  twobit_setreg( 1 );
  twobit_const( 61 );
  twobit_setreg( 2 );
  twobit_global( 62 ); /* rtd-accessor */
  twobit_setrtn( 1011, compiled_block_1_1011 );
  twobit_invoke( 2 );
  twobit_label( 1011, compiled_block_1_1011 );
  twobit_load( 0, 0 );
  twobit_setglbl( 32 ); /*  :random-source-make-reals~1ayXVW~13253 */
  twobit_lambda( compiled_start_1_4, 64, 0 );
  twobit_setglbl( 31 ); /*  :random-source-current-time~1ayXVW~13254 */
  twobit_lambda( compiled_start_1_5, 66, 0 );
  twobit_setglbl( 30 ); /*  mrg32k3a-random-m1~1ayXVW~13255 */
  twobit_lambda( compiled_start_1_6, 68, 0 );
  twobit_setglbl( 29 ); /*  mrg32k3a-pack-state~1ayXVW~13256 */
  twobit_lambda( compiled_start_1_7, 70, 0 );
  twobit_setglbl( 28 ); /*  mrg32k3a-unpack-state~1ayXVW~13257 */
  twobit_lambda( compiled_start_1_8, 72, 0 );
  twobit_setglbl( 27 ); /*  mrg32k3a-random-range~1ayXVW~13258 */
  twobit_lambda( compiled_start_1_9, 74, 0 );
  twobit_setglbl( 26 ); /*  mrg32k3a-random-integer~1ayXVW~13259 */
  twobit_lambda( compiled_start_1_10, 76, 0 );
  twobit_setglbl( 25 ); /*  mrg32k3a-random-real~1ayXVW~13260 */
  twobit_lambda( compiled_start_1_11, 78, 0 );
  twobit_setglbl( 24 ); /*  mrg32k3a-state-ref~1ayXVW~13261 */
  twobit_lambda( compiled_start_1_12, 80, 0 );
  twobit_setglbl( 23 ); /*  mrg32k3a-state-set~1ayXVW~13262 */
  twobit_const( 81 );
  twobit_setglbl( 22 ); /*  mrg32k3a-m1~1ayXVW~13263 */
  twobit_const( 82 );
  twobit_setglbl( 21 ); /*  mrg32k3a-m2~1ayXVW~13264 */
  twobit_const( 83 );
  twobit_setglbl( 20 ); /*  mrg32k3a-initial-state~1ayXVW~13265 */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setglbl( 19 ); /*  mrg32k3a-generators~1ayXVW~13266 */
  twobit_lambda( compiled_start_1_13, 85, 0 );
  twobit_setglbl( 18 ); /*  mrg32k3a-pseudo-randomize-state~1ayXVW~13267 */
  twobit_lambda( compiled_start_1_14, 87, 0 );
  twobit_setglbl( 17 ); /*  mrg32k3a-randomize-state~1ayXVW~13268 */
  twobit_global( 27 ); /*  mrg32k3a-random-range~1ayXVW~13258 */
  twobit_setrtn( 1201, compiled_block_1_1201 );
  twobit_invoke( 0 );
  twobit_label( 1201, compiled_block_1_1201 );
  twobit_load( 0, 0 );
  twobit_setglbl( 16 ); /*  mrg32k3a-m-max~1ayXVW~13269 */
  twobit_lambda( compiled_start_1_15, 89, 0 );
  twobit_setglbl( 15 ); /*  mrg32k3a-random-power~1ayXVW~13270 */
  twobit_lambda( compiled_start_1_16, 91, 0 );
  twobit_setglbl( 14 ); /*  mrg32k3a-random-large~1ayXVW~13271 */
  twobit_lambda( compiled_start_1_17, 93, 0 );
  twobit_setglbl( 13 ); /*  mrg32k3a-random-real-mp~1ayXVW~13272 */
  twobit_lambda( compiled_start_1_18, 95, 0 );
  twobit_setglbl( 12 ); /*  make-random-source~1ayXVW~13273 */
  twobit_global( 38 ); /*  :random-source?~1ayXVW~13247 */
  twobit_setglbl( 11 ); /*  random-source?~1ayXVW~13274 */
  twobit_lambda( compiled_start_1_19, 97, 0 );
  twobit_setglbl( 10 ); /*  random-source-state-ref~1ayXVW~13275 */
  twobit_lambda( compiled_start_1_20, 99, 0 );
  twobit_setglbl( 9 ); /*  random-source-state-set!~1ayXVW~13276 */
  twobit_lambda( compiled_start_1_21, 101, 0 );
  twobit_setglbl( 8 ); /*  random-source-randomize!~1ayXVW~13277 */
  twobit_lambda( compiled_start_1_22, 103, 0 );
  twobit_setglbl( 7 ); /*  random-source-pseudo-randomize!~1ayXVW~13278 */
  twobit_lambda( compiled_start_1_23, 105, 0 );
  twobit_setglbl( 6 ); /*  random-source-make-integers~1ayXVW~13279 */
  twobit_lambda( compiled_start_1_24, 107, 0 );
  twobit_setglbl( 5 ); /*  random-source-make-reals~1ayXVW~13280 */
  twobit_global( 12 ); /*  make-random-source~1ayXVW~13273 */
  twobit_setrtn( 1272, compiled_block_1_1272 );
  twobit_invoke( 0 );
  twobit_label( 1272, compiled_block_1_1272 );
  twobit_load( 0, 0 );
  twobit_setglbl( 4 ); /*  default-random-source~1ayXVW~13281 */
  twobit_global( 4 ); /*  default-random-source~1ayXVW~13281 */
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  random-source-make-integers~1ayXVW~13279 */
  twobit_setrtn( 1273, compiled_block_1_1273 );
  twobit_invoke( 1 );
  twobit_label( 1273, compiled_block_1_1273 );
  twobit_load( 0, 0 );
  twobit_setglbl( 3 ); /*  random-integer~1ayXVW~13282 */
  twobit_global( 4 ); /*  default-random-source~1ayXVW~13281 */
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  random-source-make-reals~1ayXVW~13280 */
  twobit_setrtn( 1274, compiled_block_1_1274 );
  twobit_invoke( 1 );
  twobit_label( 1274, compiled_block_1_1274 );
  twobit_load( 0, 0 );
  twobit_setglbl( 2 ); /*  random-real~1ayXVW~13283 */
  twobit_global( 108 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lambda( compiled_start_1_158, 2, 0 );
  twobit_setreg( 1 );
  twobit_lambda( compiled_start_1_159, 4, 0 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_158( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* current-utc-time */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_159( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op2_61( 2, 160, compiled_temp_1_160 ); /* + */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_reg_op2_check_662(reg(1),reg(4),1014,compiled_block_1_1014); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_store( 4, 2 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(4),1014,compiled_block_1_1014); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_const( 1 );
  twobit_op2_63( 3, 142, compiled_temp_1_142 ); /* * */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(4),1015,compiled_block_1_1015); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_op2_63( 2, 143, compiled_temp_1_143 ); /* * */
  twobit_op2_62( 3, 144, compiled_temp_1_144 ); /* - */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_const( 3 );
  twobit_setreg( 31 );
  twobit_reg( 2 );
  twobit_op2_64( 31, 145, compiled_temp_1_145 ); /* / */
  twobit_setreg( 1 );
  twobit_global( 4 ); /* floor */
  twobit_setrtn( 1016, compiled_block_1_1016 );
  twobit_invoke( 1 );
  twobit_label( 1016, compiled_block_1_1016 );
  twobit_load( 0, 0 );
  twobit_const_setreg( 3, 3 );
  twobit_op2_63( 3, 146, compiled_temp_1_146 ); /* * */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_62( 4, 147, compiled_temp_1_147 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 3, 2 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 3 );
  twobit_check( 0, 1, 0, 1017, compiled_block_1_1017 );
  twobit_stack( 3 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_const( 5 );
  twobit_op2_63( 2, 148, compiled_temp_1_148 ); /* * */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 3 );
  twobit_check( 0, 3, 0, 1018, compiled_block_1_1018 );
  twobit_stack( 3 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_const( 6 );
  twobit_op2_63( 3, 149, compiled_temp_1_149 ); /* * */
  twobit_op2_62( 2, 150, compiled_temp_1_150 ); /* - */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_op2_64( 1, 151, compiled_temp_1_151 ); /* / */
  twobit_setreg( 1 );
  twobit_global( 4 ); /* floor */
  twobit_setrtn( 1019, compiled_block_1_1019 );
  twobit_invoke( 1 );
  twobit_label( 1019, compiled_block_1_1019 );
  twobit_load( 0, 0 );
  twobit_const_setreg( 7, 3 );
  twobit_op2_63( 3, 152, compiled_temp_1_152 ); /* * */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_62( 4, 153, compiled_temp_1_153 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_stack( 4 );
  twobit_op2_62( 4, 154, compiled_temp_1_154 ); /* - */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 3 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2_64( 2, 155, compiled_temp_1_155 ); /* / */
  twobit_setreg( 1 );
  twobit_global( 4 ); /* floor */
  twobit_setrtn( 1020, compiled_block_1_1020 );
  twobit_invoke( 1 );
  twobit_label( 1020, compiled_block_1_1020 );
  twobit_load( 0, 0 );
  twobit_const_setreg( 3, 3 );
  twobit_op2_63( 3, 156, compiled_temp_1_156 ); /* * */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_62( 4, 157, compiled_temp_1_157 ); /* - */
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 3 );
  twobit_check( 0, 1, 0, 1021, compiled_block_1_1021 );
  twobit_stack( 3 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 1 );
  twobit_stack( 3 );
  twobit_op3_403( 1, 2 ); /* vector-set!:trusted */
  twobit_stack( 3 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 1 );
  twobit_stack( 3 );
  twobit_op3_403( 1, 2 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_load( 1, 5 );
  twobit_stack( 3 );
  twobit_op3_403( 2, 1 ); /* vector-set!:trusted */
  twobit_stack( 3 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_stack( 3 );
  twobit_op3_403( 1, 2 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 3 );
  twobit_check( 0, 2, 0, 1022, compiled_block_1_1022 );
  twobit_stack( 3 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_stack( 3 );
  twobit_op3_403( 2, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_load( 2, 4 );
  twobit_stack( 3 );
  twobit_op3_403( 3, 2 ); /* vector-set!:trusted */
  twobit_reg( 4 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1014, compiled_block_1_1014 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1017, compiled_block_1_1017 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1018, compiled_block_1_1018 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 1 );
  twobit_trap( 3, 1, 0, 160 );
  twobit_label( 1015, compiled_block_1_1015 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1021, compiled_block_1_1021 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1022, compiled_block_1_1022 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_6( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* vector->list */
  twobit_setrtn( 1023, compiled_block_1_1023 );
  twobit_invoke( 1 );
  twobit_label( 1023, compiled_block_1_1023 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* exact->inexact */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  map~1ayXVW~1381 */
  twobit_setrtn( 1024, compiled_block_1_1024 );
  twobit_invoke( 2 );
  twobit_label( 1024, compiled_block_1_1024 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* list->vector */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_7( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* vector->list */
  twobit_setrtn( 1026, compiled_block_1_1026 );
  twobit_invoke( 1 );
  twobit_label( 1026, compiled_block_1_1026 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* inexact->exact */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  map~1ayXVW~1381 */
  twobit_setrtn( 1027, compiled_block_1_1027 );
  twobit_invoke( 2 );
  twobit_label( 1027, compiled_block_1_1027 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* list->vector */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_8( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  most-positive-fixnum~1ayXVW~13241 */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_9( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_reg( 2 );
  twobit_op1_27( 135, compiled_temp_1_135 ); /* exact->inexact */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 1 );
  twobit_op2_64( 4, 136, compiled_temp_1_136 ); /* / */
  twobit_setreg( 1 );
  twobit_global( 2 ); /* floor */
  twobit_setrtn( 1030, compiled_block_1_1030 );
  twobit_invoke( 1 );
  twobit_label( 1030, compiled_block_1_1030 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 3, 1 );
  twobit_reg( 4 );
  twobit_op2_63( 3, 137, compiled_temp_1_137 ); /* * */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_load( 1, 2 );
  twobit_global( 3 ); /*  mrg32k3a-random-m1~1ayXVW~13255 */
  twobit_setrtn( 1031, compiled_block_1_1031 );
  twobit_invoke( 1 );
  twobit_label( 1031, compiled_block_1_1031 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_global( 4 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 4, 1 );
  twobit_load( 2, 3 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_138, 6, 4 );
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_138( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 139, compiled_temp_1_139, 1033, compiled_block_1_1033 ); /* internal:branchf-< */
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_64( 4, 140, compiled_temp_1_140 ); /* / */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* floor */
  twobit_setrtn( 1034, compiled_block_1_1034 );
  twobit_invoke( 1 );
  twobit_label( 1034, compiled_block_1_1034 );
  twobit_load( 0, 0 );
  twobit_op1_28( 141, compiled_temp_1_141 ); /* inexact->exact */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1033, compiled_block_1_1033 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  mrg32k3a-random-m1~1ayXVW~13255 */
  twobit_setrtn( 1035, compiled_block_1_1035 );
  twobit_invoke( 1 );
  twobit_label( 1035, compiled_block_1_1035 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_10( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  mrg32k3a-random-m1~1ayXVW~13255 */
  twobit_setrtn( 1038, compiled_block_1_1038 );
  twobit_invoke( 1 );
  twobit_label( 1038, compiled_block_1_1038 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_const( 2 );
  twobit_op2_61( 4, 133, compiled_temp_1_133 ); /* + */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_op2_63( 4, 134, compiled_temp_1_134 ); /* * */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_11( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  mrg32k3a-unpack-state~1ayXVW~13257 */
  twobit_setrtn( 1039, compiled_block_1_1039 );
  twobit_invoke( 1 );
  twobit_label( 1039, compiled_block_1_1039 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* vector->list */
  twobit_setrtn( 1040, compiled_block_1_1040 );
  twobit_invoke( 1 );
  twobit_label( 1040, compiled_block_1_1040 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_12( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1043, compiled_block_1_1043 );
  twobit_invoke( 1 );
  twobit_label( 1043, compiled_block_1_1043 );
  twobit_load( 0, 0 );
  twobit_branchf( 1045, compiled_block_1_1045 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* length */
  twobit_setrtn( 1046, compiled_block_1_1046 );
  twobit_invoke( 1 );
  twobit_label( 1046, compiled_block_1_1046 );
  twobit_load( 0, 0 );
  twobit_op2imm_branchf_639( fixnum(7), 123, compiled_temp_1_123, 1048, compiled_block_1_1048 ); /* internal:branchf-=/imm */
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1049, compiled_block_1_1049 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_const_setreg( 3, 3 );
  twobit_op2_56( 3 ); /* eq? */
  twobit_skip( 1044, compiled_block_1_1044 );
  twobit_label( 1048, compiled_block_1_1048 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1044, compiled_block_1_1044 );
  twobit_label( 1045, compiled_block_1_1045 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1044, compiled_block_1_1044 );
  twobit_branchf( 1051, compiled_block_1_1051 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1052, compiled_block_1_1052 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 4 ); /* list-ref */
  twobit_setrtn( 1053, compiled_block_1_1053 );
  twobit_invoke( 2 );
  twobit_label( 1053, compiled_block_1_1053 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  mrg32k3a-m1~1ayXVW~13263 */
  twobit_setreg( 2 );
  twobit_setrtn( 1054, compiled_block_1_1054 );
  twobit_branch( 1041, compiled_block_1_1041 );
  twobit_label( 1054, compiled_block_1_1054 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 4 ); /* list-ref */
  twobit_setrtn( 1055, compiled_block_1_1055 );
  twobit_invoke( 2 );
  twobit_label( 1055, compiled_block_1_1055 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  mrg32k3a-m1~1ayXVW~13263 */
  twobit_setreg( 2 );
  twobit_setrtn( 1056, compiled_block_1_1056 );
  twobit_branch( 1041, compiled_block_1_1041 );
  twobit_label( 1056, compiled_block_1_1056 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 4 ); /* list-ref */
  twobit_setrtn( 1057, compiled_block_1_1057 );
  twobit_invoke( 2 );
  twobit_label( 1057, compiled_block_1_1057 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  mrg32k3a-m1~1ayXVW~13263 */
  twobit_setreg( 2 );
  twobit_setrtn( 1058, compiled_block_1_1058 );
  twobit_branch( 1041, compiled_block_1_1041 );
  twobit_label( 1058, compiled_block_1_1058 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_global( 4 ); /* list-ref */
  twobit_setrtn( 1059, compiled_block_1_1059 );
  twobit_invoke( 2 );
  twobit_label( 1059, compiled_block_1_1059 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  mrg32k3a-m2~1ayXVW~13264 */
  twobit_setreg( 2 );
  twobit_setrtn( 1060, compiled_block_1_1060 );
  twobit_branch( 1041, compiled_block_1_1041 );
  twobit_label( 1060, compiled_block_1_1060 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_global( 4 ); /* list-ref */
  twobit_setrtn( 1061, compiled_block_1_1061 );
  twobit_invoke( 2 );
  twobit_label( 1061, compiled_block_1_1061 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  mrg32k3a-m2~1ayXVW~13264 */
  twobit_setreg( 2 );
  twobit_setrtn( 1062, compiled_block_1_1062 );
  twobit_branch( 1041, compiled_block_1_1041 );
  twobit_label( 1062, compiled_block_1_1062 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_global( 4 ); /* list-ref */
  twobit_setrtn( 1063, compiled_block_1_1063 );
  twobit_invoke( 2 );
  twobit_label( 1063, compiled_block_1_1063 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  mrg32k3a-m2~1ayXVW~13264 */
  twobit_setreg( 2 );
  twobit_setrtn( 1064, compiled_block_1_1064 );
  twobit_branch( 1041, compiled_block_1_1041 );
  twobit_label( 1064, compiled_block_1_1064 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 4 ); /* list-ref */
  twobit_setrtn( 1065, compiled_block_1_1065 );
  twobit_invoke( 2 );
  twobit_label( 1065, compiled_block_1_1065 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 4 ); /* list-ref */
  twobit_setrtn( 1066, compiled_block_1_1066 );
  twobit_invoke( 2 );
  twobit_label( 1066, compiled_block_1_1066 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 4 ); /* list-ref */
  twobit_setrtn( 1067, compiled_block_1_1067 );
  twobit_invoke( 2 );
  twobit_label( 1067, compiled_block_1_1067 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_61( 4, 124, compiled_temp_1_124 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_61( 4, 125, compiled_temp_1_125 ); /* + */
  twobit_op1_branchf_612( 126, compiled_temp_1_126, 1069, compiled_block_1_1069 ); /* internal:branchf-zero? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1068, compiled_block_1_1068 );
  twobit_label( 1069, compiled_block_1_1069 );
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_global( 4 ); /* list-ref */
  twobit_setrtn( 1070, compiled_block_1_1070 );
  twobit_invoke( 2 );
  twobit_label( 1070, compiled_block_1_1070 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_global( 4 ); /* list-ref */
  twobit_setrtn( 1071, compiled_block_1_1071 );
  twobit_invoke( 2 );
  twobit_label( 1071, compiled_block_1_1071 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_global( 4 ); /* list-ref */
  twobit_setrtn( 1072, compiled_block_1_1072 );
  twobit_invoke( 2 );
  twobit_label( 1072, compiled_block_1_1072 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_61( 4, 127, compiled_temp_1_127 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_61( 4, 128, compiled_temp_1_128 ); /* + */
  twobit_op1_31( 129, compiled_temp_1_129 ); /* zero? */
  twobit_label( 1068, compiled_block_1_1068 );
  twobit_branchf( 1074, compiled_block_1_1074 );
  twobit_load( 2, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_global( 8 ); /* error */
  twobit_setrtn( 1075, compiled_block_1_1075 );
  twobit_invoke( 2 );
  twobit_label( 1075, compiled_block_1_1075 );
  twobit_load( 0, 0 );
  twobit_skip( 1073, compiled_block_1_1073 );
  twobit_label( 1074, compiled_block_1_1074 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 1073, compiled_block_1_1073 );
  twobit_load( 1, 2 );
  twobit_global( 9 ); /* list->vector */
  twobit_setrtn( 1076, compiled_block_1_1076 );
  twobit_invoke( 1 );
  twobit_label( 1076, compiled_block_1_1076 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 10 ); /*  mrg32k3a-pack-state~1ayXVW~13256 */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 1051, compiled_block_1_1051 );
  twobit_load( 2, 1 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_global( 8 ); /* error */
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 1041, compiled_block_1_1041 );
  twobit_reg( 1 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1080, compiled_block_1_1080 );
  twobit_reg( 1 );
  twobit_op1_25(); /* exact? */
  twobit_branchf( 1082, compiled_block_1_1082 );
  twobit_reg( 2 );
  twobit_op2imm_131( fixnum(1), 130, compiled_temp_1_130 ); /* - */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_67( 4, 131, compiled_temp_1_131 ); /* <= */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_branchf_622( 1, 132, compiled_temp_1_132, 1084, compiled_block_1_1084 ); /* internal:branchf-<= */
  twobit_reg( 4 );
  twobit_skip( 1079, compiled_block_1_1079 );
  twobit_label( 1084, compiled_block_1_1084 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1079, compiled_block_1_1079 );
  twobit_label( 1082, compiled_block_1_1082 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1079, compiled_block_1_1079 );
  twobit_label( 1080, compiled_block_1_1080 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1079, compiled_block_1_1079 );
  twobit_branchf( 1086, compiled_block_1_1086 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_return();
  twobit_label( 1086, compiled_block_1_1086 );
  twobit_movereg( 1, 2 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_global( 8 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1052, compiled_block_1_1052 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_label( 1049, compiled_block_1_1049 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_13( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 1 );
  twobit_reg( 1 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1093, compiled_block_1_1093 );
  twobit_reg( 1 );
  twobit_op1_25(); /* exact? */
  twobit_branchf( 1095, compiled_block_1_1095 );
  twobit_reg( 2 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1097, compiled_block_1_1097 );
  twobit_reg( 2 );
  twobit_op1_25(); /* exact? */
  twobit_skip( 1092, compiled_block_1_1092 );
  twobit_label( 1097, compiled_block_1_1097 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1092, compiled_block_1_1092 );
  twobit_label( 1095, compiled_block_1_1095 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1092, compiled_block_1_1092 );
  twobit_label( 1093, compiled_block_1_1093 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1092, compiled_block_1_1092 );
  twobit_branchf( 1099, compiled_block_1_1099 );
  twobit_op1_3(); /* unspecified */
  twobit_skip( 1098, compiled_block_1_1098 );
  twobit_label( 1099, compiled_block_1_1099 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* error */
  twobit_setrtn( 1100, compiled_block_1_1100 );
  twobit_invoke( 3 );
  twobit_label( 1100, compiled_block_1_1100 );
  twobit_load( 0, 0 );
  twobit_label( 1098, compiled_block_1_1098 );
  twobit_global( 3 ); /*  mrg32k3a-generators~1ayXVW~13266 */
  twobit_branchf( 1102, compiled_block_1_1102 );
  twobit_op1_3(); /* unspecified */
  twobit_skip( 1101, compiled_block_1_1101 );
  twobit_label( 1102, compiled_block_1_1102 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_const( 4 );
  twobit_setreg( 2 );
  twobit_setrtn( 1103, compiled_block_1_1103 );
  twobit_branch( 1090, compiled_block_1_1090 );
  twobit_label( 1103, compiled_block_1_1103 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(126) ); /* 126 */
  twobit_setreg( 2 );
  twobit_setrtn( 1104, compiled_block_1_1104 );
  twobit_branch( 1088, compiled_block_1_1088 );
  twobit_label( 1104, compiled_block_1_1104 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_const( 4 );
  twobit_setreg( 2 );
  twobit_setrtn( 1105, compiled_block_1_1105 );
  twobit_branch( 1090, compiled_block_1_1090 );
  twobit_label( 1105, compiled_block_1_1105 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(75) ); /* 75 */
  twobit_setreg( 2 );
  twobit_setrtn( 1106, compiled_block_1_1106 );
  twobit_branch( 1088, compiled_block_1_1088 );
  twobit_label( 1106, compiled_block_1_1106 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(16) ); /* 16 */
  twobit_setreg( 2 );
  twobit_setrtn( 1107, compiled_block_1_1107 );
  twobit_branch( 1089, compiled_block_1_1089 );
  twobit_label( 1107, compiled_block_1_1107 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setglbl( 3 ); /*  mrg32k3a-generators~1ayXVW~13266 */
  twobit_label( 1101, compiled_block_1_1101 );
  twobit_global( 3 ); /*  mrg32k3a-generators~1ayXVW~13266 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 5 ); /* list-ref */
  twobit_setrtn( 1108, compiled_block_1_1108 );
  twobit_invoke( 2 );
  twobit_label( 1108, compiled_block_1_1108 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_global( 3 ); /*  mrg32k3a-generators~1ayXVW~13266 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 5 ); /* list-ref */
  twobit_setrtn( 1109, compiled_block_1_1109 );
  twobit_invoke( 2 );
  twobit_label( 1109, compiled_block_1_1109 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(28) ); /* 28 */
  twobit_setreg( 2 );
  twobit_global( 6 ); /* expt */
  twobit_setrtn( 1110, compiled_block_1_1110 );
  twobit_invoke( 2 );
  twobit_label( 1110, compiled_block_1_1110 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 4 );
  twobit_global( 7 ); /* modulo */
  twobit_setrtn( 1111, compiled_block_1_1111 );
  twobit_invoke( 2 );
  twobit_label( 1111, compiled_block_1_1111 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 5 );
  twobit_setrtn( 1112, compiled_block_1_1112 );
  twobit_branch( 1089, compiled_block_1_1089 );
  twobit_label( 1112, compiled_block_1_1112 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_global( 3 ); /*  mrg32k3a-generators~1ayXVW~13266 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 5 ); /* list-ref */
  twobit_setrtn( 1113, compiled_block_1_1113 );
  twobit_invoke( 2 );
  twobit_label( 1113, compiled_block_1_1113 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(28) ); /* 28 */
  twobit_setreg( 2 );
  twobit_global( 6 ); /* expt */
  twobit_setrtn( 1114, compiled_block_1_1114 );
  twobit_invoke( 2 );
  twobit_label( 1114, compiled_block_1_1114 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 7 ); /* modulo */
  twobit_setrtn( 1115, compiled_block_1_1115 );
  twobit_invoke( 2 );
  twobit_label( 1115, compiled_block_1_1115 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 5 );
  twobit_setrtn( 1116, compiled_block_1_1116 );
  twobit_branch( 1089, compiled_block_1_1089 );
  twobit_label( 1116, compiled_block_1_1116 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 4 );
  twobit_setrtn( 1117, compiled_block_1_1117 );
  twobit_branch( 1090, compiled_block_1_1090 );
  twobit_label( 1117, compiled_block_1_1117 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 6 );
  twobit_setrtn( 1118, compiled_block_1_1118 );
  twobit_branch( 1090, compiled_block_1_1090 );
  twobit_label( 1118, compiled_block_1_1118 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_reg( 4 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(15) ); /* 15 */
  twobit_reg_op2_check_655(RESULT,reg(3),1119,compiled_block_1_1119); /* internal:check-<:fix:fix with (0 4 0) */
  twobit_reg( 4 );
  twobit_op2imm_450( fixnum(15) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(12) ); /* 12 */
  twobit_reg_op2_check_655(RESULT,reg(3),1120,compiled_block_1_1120); /* internal:check-<:fix:fix with (0 4 0) */
  twobit_reg( 4 );
  twobit_op2imm_450( fixnum(12) ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_reg_op2_check_655(RESULT,reg(3),1121,compiled_block_1_1121); /* internal:check-<:fix:fix with (0 4 0) */
  twobit_reg( 4 );
  twobit_op2imm_450( fixnum(9) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 4, 6 );
  twobit_check( 0, 4, 0, 1122, compiled_block_1_1122 );
  twobit_stack( 6 );
  twobit_op2imm_450( fixnum(6) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 4, 6 );
  twobit_check( 0, 4, 0, 1123, compiled_block_1_1123 );
  twobit_stack( 6 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 6 );
  twobit_check( 0, 3, 0, 1124, compiled_block_1_1124 );
  twobit_stack( 6 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_op2_606( 2 ); /* make-vector:6 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op3_403( 4, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_reg( 2 );
  twobit_op3_403( 4, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 4 );
  twobit_load( 1, 5 );
  twobit_reg( 2 );
  twobit_op3_403( 4, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 2 );
  twobit_op3_403( 4, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_movereg( 2, 1 );
  twobit_global( 8 ); /*  mrg32k3a-pack-state~1ayXVW~13256 */
  twobit_pop( 6 );
  twobit_invoke( 1 );
  twobit_label( 1088, compiled_block_1_1088 );
  twobit_reg( 2 );
  twobit_op1_branchf_612( 85, compiled_temp_1_85, 1127, compiled_block_1_1127 ); /* internal:branchf-zero? */
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1127, compiled_block_1_1127 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 2 );
  twobit_op2imm_131( fixnum(1), 86, compiled_temp_1_86 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 1, 2 );
  twobit_setrtn( 1128, compiled_block_1_1128 );
  twobit_branch( 1090, compiled_block_1_1090 );
  twobit_label( 1128, compiled_block_1_1128 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_pop( 1 );
  twobit_branch( 1088, compiled_block_1_1088 );
  twobit_label( 1089, compiled_block_1_1089 );
  twobit_reg( 2 );
  twobit_op1_branchf_612( 87, compiled_temp_1_87, 1131, compiled_block_1_1131 ); /* internal:branchf-zero? */
  twobit_const( 9 );
  twobit_return();
  twobit_label( 1131, compiled_block_1_1131 );
  twobit_reg( 2 );
  twobit_op2imm_branchf_639( fixnum(1), 88, compiled_temp_1_88, 1133, compiled_block_1_1133 ); /* internal:branchf-=/imm */
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1133, compiled_block_1_1133 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 10 ); /* even? */
  twobit_setrtn( 1134, compiled_block_1_1134 );
  twobit_invoke( 1 );
  twobit_label( 1134, compiled_block_1_1134 );
  twobit_load( 0, 0 );
  twobit_branchf( 1136, compiled_block_1_1136 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_65( 4, 89, compiled_temp_1_89 ); /* quotient */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 2, 2 );
  twobit_load( 1, 2 );
  twobit_setrtn( 1137, compiled_block_1_1137 );
  twobit_branch( 1090, compiled_block_1_1090 );
  twobit_label( 1137, compiled_block_1_1137 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_pop( 2 );
  twobit_branch( 1089, compiled_block_1_1089 );
  twobit_label( 1136, compiled_block_1_1136 );
  twobit_stack( 1 );
  twobit_op2imm_131( fixnum(1), 90, compiled_temp_1_90 ); /* - */
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_setrtn( 1139, compiled_block_1_1139 );
  twobit_branch( 1089, compiled_block_1_1089 );
  twobit_label( 1139, compiled_block_1_1139 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_pop( 2 );
  twobit_label( 1090, compiled_block_1_1090 );
  twobit_save( 18 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_91, 12, 2 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_global( 13 ); /*  mrg32k3a-m2~1ayXVW~13264 */
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 9 );
  twobit_imm_const( fixnum(15) ); /* 15 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(16) ); /* 16 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(17) ); /* 17 */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(11) ); /* 11 */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(14) ); /* 14 */
  twobit_setreg( 5 );
  twobit_imm_const( fixnum(17) ); /* 17 */
  twobit_setreg( 6 );
  twobit_imm_const( fixnum(22853) ); /* 22853 */
  twobit_setreg( 8 );
  twobit_reg( 9 );
  twobit_setrtn( 1154, compiled_block_1_1154 );
  twobit_invoke( 8 );
  twobit_label( 1154, compiled_block_1_1154 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_global( 13 ); /*  mrg32k3a-m2~1ayXVW~13264 */
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_imm_const( fixnum(15) ); /* 15 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(16) ); /* 16 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(17) ); /* 17 */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(10) ); /* 10 */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(13) ); /* 13 */
  twobit_setreg( 5 );
  twobit_imm_const( fixnum(16) ); /* 16 */
  twobit_setreg( 6 );
  twobit_imm_const( fixnum(22853) ); /* 22853 */
  twobit_setreg( 8 );
  twobit_stack( 1 );
  twobit_setrtn( 1155, compiled_block_1_1155 );
  twobit_invoke( 8 );
  twobit_label( 1155, compiled_block_1_1155 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_global( 13 ); /*  mrg32k3a-m2~1ayXVW~13264 */
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_imm_const( fixnum(15) ); /* 15 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(16) ); /* 16 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(17) ); /* 17 */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(12) ); /* 12 */
  twobit_setreg( 5 );
  twobit_imm_const( fixnum(15) ); /* 15 */
  twobit_setreg( 6 );
  twobit_imm_const( fixnum(22853) ); /* 22853 */
  twobit_setreg( 8 );
  twobit_stack( 1 );
  twobit_setrtn( 1156, compiled_block_1_1156 );
  twobit_invoke( 8 );
  twobit_label( 1156, compiled_block_1_1156 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_global( 13 ); /*  mrg32k3a-m2~1ayXVW~13264 */
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_imm_const( fixnum(12) ); /* 12 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(13) ); /* 13 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(14) ); /* 14 */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(11) ); /* 11 */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(14) ); /* 14 */
  twobit_setreg( 5 );
  twobit_imm_const( fixnum(17) ); /* 17 */
  twobit_setreg( 6 );
  twobit_imm_const( fixnum(22853) ); /* 22853 */
  twobit_setreg( 8 );
  twobit_stack( 1 );
  twobit_setrtn( 1157, compiled_block_1_1157 );
  twobit_invoke( 8 );
  twobit_label( 1157, compiled_block_1_1157 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_global( 13 ); /*  mrg32k3a-m2~1ayXVW~13264 */
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_imm_const( fixnum(12) ); /* 12 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(13) ); /* 13 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(14) ); /* 14 */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(10) ); /* 10 */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(13) ); /* 13 */
  twobit_setreg( 5 );
  twobit_imm_const( fixnum(16) ); /* 16 */
  twobit_setreg( 6 );
  twobit_imm_const( fixnum(22853) ); /* 22853 */
  twobit_setreg( 8 );
  twobit_stack( 1 );
  twobit_setrtn( 1158, compiled_block_1_1158 );
  twobit_invoke( 8 );
  twobit_label( 1158, compiled_block_1_1158 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_global( 13 ); /*  mrg32k3a-m2~1ayXVW~13264 */
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_imm_const( fixnum(12) ); /* 12 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(13) ); /* 13 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(14) ); /* 14 */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(12) ); /* 12 */
  twobit_setreg( 5 );
  twobit_imm_const( fixnum(15) ); /* 15 */
  twobit_setreg( 6 );
  twobit_imm_const( fixnum(22853) ); /* 22853 */
  twobit_setreg( 8 );
  twobit_stack( 1 );
  twobit_setrtn( 1159, compiled_block_1_1159 );
  twobit_invoke( 8 );
  twobit_label( 1159, compiled_block_1_1159 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_global( 13 ); /*  mrg32k3a-m2~1ayXVW~13264 */
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(10) ); /* 10 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(11) ); /* 11 */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(11) ); /* 11 */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(14) ); /* 14 */
  twobit_setreg( 5 );
  twobit_imm_const( fixnum(17) ); /* 17 */
  twobit_setreg( 6 );
  twobit_imm_const( fixnum(22853) ); /* 22853 */
  twobit_setreg( 8 );
  twobit_stack( 1 );
  twobit_setrtn( 1160, compiled_block_1_1160 );
  twobit_invoke( 8 );
  twobit_label( 1160, compiled_block_1_1160 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_global( 13 ); /*  mrg32k3a-m2~1ayXVW~13264 */
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(10) ); /* 10 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(11) ); /* 11 */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(10) ); /* 10 */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(13) ); /* 13 */
  twobit_setreg( 5 );
  twobit_imm_const( fixnum(16) ); /* 16 */
  twobit_setreg( 6 );
  twobit_imm_const( fixnum(22853) ); /* 22853 */
  twobit_setreg( 8 );
  twobit_stack( 1 );
  twobit_setrtn( 1161, compiled_block_1_1161 );
  twobit_invoke( 8 );
  twobit_label( 1161, compiled_block_1_1161 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_global( 13 ); /*  mrg32k3a-m2~1ayXVW~13264 */
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(10) ); /* 10 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(11) ); /* 11 */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(12) ); /* 12 */
  twobit_setreg( 5 );
  twobit_imm_const( fixnum(15) ); /* 15 */
  twobit_setreg( 6 );
  twobit_imm_const( fixnum(22853) ); /* 22853 */
  twobit_setreg( 8 );
  twobit_stack( 1 );
  twobit_setrtn( 1162, compiled_block_1_1162 );
  twobit_invoke( 8 );
  twobit_label( 1162, compiled_block_1_1162 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_global( 14 ); /*  mrg32k3a-m1~1ayXVW~13263 */
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 5 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 6 );
  twobit_imm_const( fixnum(209) ); /* 209 */
  twobit_setreg( 8 );
  twobit_stack( 1 );
  twobit_setrtn( 1163, compiled_block_1_1163 );
  twobit_invoke( 8 );
  twobit_label( 1163, compiled_block_1_1163 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_global( 14 ); /*  mrg32k3a-m1~1ayXVW~13263 */
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 5 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 6 );
  twobit_imm_const( fixnum(209) ); /* 209 */
  twobit_setreg( 8 );
  twobit_stack( 1 );
  twobit_setrtn( 1164, compiled_block_1_1164 );
  twobit_invoke( 8 );
  twobit_label( 1164, compiled_block_1_1164 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_global( 14 ); /*  mrg32k3a-m1~1ayXVW~13263 */
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 5 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 6 );
  twobit_imm_const( fixnum(209) ); /* 209 */
  twobit_setreg( 8 );
  twobit_stack( 1 );
  twobit_setrtn( 1165, compiled_block_1_1165 );
  twobit_invoke( 8 );
  twobit_label( 1165, compiled_block_1_1165 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 13 );
  twobit_global( 14 ); /*  mrg32k3a-m1~1ayXVW~13263 */
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 5 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 6 );
  twobit_imm_const( fixnum(209) ); /* 209 */
  twobit_setreg( 8 );
  twobit_stack( 1 );
  twobit_setrtn( 1166, compiled_block_1_1166 );
  twobit_invoke( 8 );
  twobit_label( 1166, compiled_block_1_1166 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 14 );
  twobit_global( 14 ); /*  mrg32k3a-m1~1ayXVW~13263 */
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 5 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 6 );
  twobit_imm_const( fixnum(209) ); /* 209 */
  twobit_setreg( 8 );
  twobit_stack( 1 );
  twobit_setrtn( 1167, compiled_block_1_1167 );
  twobit_invoke( 8 );
  twobit_label( 1167, compiled_block_1_1167 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 15 );
  twobit_global( 14 ); /*  mrg32k3a-m1~1ayXVW~13263 */
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 5 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 6 );
  twobit_imm_const( fixnum(209) ); /* 209 */
  twobit_setreg( 8 );
  twobit_stack( 1 );
  twobit_setrtn( 1168, compiled_block_1_1168 );
  twobit_invoke( 8 );
  twobit_label( 1168, compiled_block_1_1168 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 16 );
  twobit_global( 14 ); /*  mrg32k3a-m1~1ayXVW~13263 */
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 5 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 6 );
  twobit_imm_const( fixnum(209) ); /* 209 */
  twobit_setreg( 8 );
  twobit_stack( 1 );
  twobit_setrtn( 1169, compiled_block_1_1169 );
  twobit_invoke( 8 );
  twobit_label( 1169, compiled_block_1_1169 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 17 );
  twobit_global( 14 ); /*  mrg32k3a-m1~1ayXVW~13263 */
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 5 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 6 );
  twobit_imm_const( fixnum(209) ); /* 209 */
  twobit_setreg( 8 );
  twobit_stack( 1 );
  twobit_setrtn( 1170, compiled_block_1_1170 );
  twobit_invoke( 8 );
  twobit_label( 1170, compiled_block_1_1170 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 18 );
  twobit_global( 14 ); /*  mrg32k3a-m1~1ayXVW~13263 */
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 5 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 6 );
  twobit_imm_const( fixnum(209) ); /* 209 */
  twobit_setreg( 8 );
  twobit_stack( 1 );
  twobit_setrtn( 1171, compiled_block_1_1171 );
  twobit_invoke( 8 );
  twobit_label( 1171, compiled_block_1_1171 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_imm_const( fixnum(18) ); /* 18 */
  twobit_op2_80( 3 ); /* make-vector */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(16) ); /* 16 */
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_reg( 3 );
  twobit_op3_403( 2, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(15) ); /* 15 */
  twobit_setreg( 2 );
  twobit_load( 1, 4 );
  twobit_reg( 3 );
  twobit_op3_403( 2, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(14) ); /* 14 */
  twobit_setreg( 2 );
  twobit_load( 1, 5 );
  twobit_reg( 3 );
  twobit_op3_403( 2, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(13) ); /* 13 */
  twobit_setreg( 2 );
  twobit_load( 1, 6 );
  twobit_reg( 3 );
  twobit_op3_403( 2, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(12) ); /* 12 */
  twobit_setreg( 2 );
  twobit_load( 1, 7 );
  twobit_reg( 3 );
  twobit_op3_403( 2, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(11) ); /* 11 */
  twobit_setreg( 2 );
  twobit_load( 1, 8 );
  twobit_reg( 3 );
  twobit_op3_403( 2, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(10) ); /* 10 */
  twobit_setreg( 2 );
  twobit_load( 1, 9 );
  twobit_reg( 3 );
  twobit_op3_403( 2, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_setreg( 2 );
  twobit_load( 1, 10 );
  twobit_reg( 3 );
  twobit_op3_403( 2, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 2 );
  twobit_load( 1, 11 );
  twobit_reg( 3 );
  twobit_op3_403( 2, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 2 );
  twobit_load( 1, 12 );
  twobit_reg( 3 );
  twobit_op3_403( 2, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 2 );
  twobit_load( 1, 13 );
  twobit_reg( 3 );
  twobit_op3_403( 2, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_load( 1, 14 );
  twobit_reg( 3 );
  twobit_op3_403( 2, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_load( 1, 15 );
  twobit_reg( 3 );
  twobit_op3_403( 2, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_load( 1, 16 );
  twobit_reg( 3 );
  twobit_op3_403( 2, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_load( 1, 17 );
  twobit_reg( 3 );
  twobit_op3_403( 2, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_load( 1, 18 );
  twobit_reg( 3 );
  twobit_op3_403( 2, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op3_403( 2, 4 ); /* vector-set!:trusted */
  twobit_reg( 3 );
  twobit_pop( 18 );
  twobit_return();
  twobit_label( 1121, compiled_block_1_1121 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_setreg( 1 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_label( 1120, compiled_block_1_1120 );
  twobit_imm_const( fixnum(12) ); /* 12 */
  twobit_setreg( 1 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_label( 1119, compiled_block_1_1119 );
  twobit_imm_const( fixnum(15) ); /* 15 */
  twobit_setreg( 1 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_label( 1124, compiled_block_1_1124 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 3, 1, 0, 160 );
  twobit_label( 1123, compiled_block_1_1123 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 1 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_label( 1122, compiled_block_1_1122 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 1 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_91( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 8 );
  twobit_save( 14 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 2, 5 );
  twobit_store( 3, 4 );
  twobit_store( 4, 3 );
  twobit_store( 5, 1 );
  twobit_store( 6, 7 );
  twobit_store( 7, 8 );
  twobit_store( 8, 9 );
  twobit_reg( 6 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 31 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 6, 30, 0, 1141, compiled_block_1_1141 );
  twobit_lexical( 0, 2 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 31 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 6, 30, 0, 1141, compiled_block_1_1141 );
  twobit_lexical( 0, 2 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 31 );
  twobit_store( 31, 2 );
  twobit_reg( 6 );
  twobit_op2_407( 31 ); /* <:fix:fix */
  twobit_setreg( 30 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 29 );
  twobit_reg( 30 );
  twobit_check( 6, 29, 0, 1142, compiled_block_1_1142 );
  twobit_reg( 6 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 30 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 29 );
  twobit_reg( 30 );
  twobit_check( 6, 29, 0, 1142, compiled_block_1_1142 );
  twobit_lexical( 0, 2 );
  twobit_op2_402( 6 ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(65536) ); /* 65536 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* modulo */
  twobit_setrtn( 1143, compiled_block_1_1143 );
  twobit_invoke( 2 );
  twobit_label( 1143, compiled_block_1_1143 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 14 );
  twobit_stack( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_load( 3, 1 );
  twobit_reg( 1 );
  twobit_check( 3, 2, 0, 1144, compiled_block_1_1144 );
  twobit_load( 3, 2 );
  twobit_stack( 1 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_reg( 3 );
  twobit_check( 2, 1, 0, 1145, compiled_block_1_1145 );
  twobit_stack( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_load( 3, 1 );
  twobit_reg( 1 );
  twobit_check( 3, 2, 0, 1144, compiled_block_1_1144 );
  twobit_lexical( 0, 2 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(65536) ); /* 65536 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* modulo */
  twobit_setrtn( 1146, compiled_block_1_1146 );
  twobit_invoke( 2 );
  twobit_label( 1146, compiled_block_1_1146 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_stack( 3 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_load( 3, 3 );
  twobit_reg( 1 );
  twobit_check( 3, 2, 0, 1144, compiled_block_1_1144 );
  twobit_load( 3, 2 );
  twobit_stack( 3 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_load( 3, 3 );
  twobit_reg( 1 );
  twobit_check( 3, 2, 0, 1144, compiled_block_1_1144 );
  twobit_stack( 3 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 3, 2, 0, 1144, compiled_block_1_1144 );
  twobit_lexical( 0, 2 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(65536) ); /* 65536 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* modulo */
  twobit_setrtn( 1147, compiled_block_1_1147 );
  twobit_invoke( 2 );
  twobit_label( 1147, compiled_block_1_1147 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_stack( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_load( 3, 4 );
  twobit_reg( 1 );
  twobit_check( 3, 2, 0, 1144, compiled_block_1_1144 );
  twobit_lexical( 0, 1 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 3, 2, 0, 1144, compiled_block_1_1144 );
  twobit_lexical( 0, 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_stack( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_load( 4, 4 );
  twobit_reg( 2 );
  twobit_check( 4, 1, 0, 1148, compiled_block_1_1148 );
  twobit_stack( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 2, 0, 1149, compiled_block_1_1149 );
  twobit_lexical( 0, 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(65536) ); /* 65536 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* modulo */
  twobit_setrtn( 1150, compiled_block_1_1150 );
  twobit_invoke( 2 );
  twobit_label( 1150, compiled_block_1_1150 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 13 );
  twobit_stack( 5 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_load( 3, 5 );
  twobit_reg( 1 );
  twobit_check( 3, 2, 0, 1144, compiled_block_1_1144 );
  twobit_load( 3, 2 );
  twobit_stack( 5 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_load( 2, 5 );
  twobit_reg( 3 );
  twobit_check( 2, 1, 0, 1145, compiled_block_1_1145 );
  twobit_stack( 5 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_load( 3, 5 );
  twobit_reg( 1 );
  twobit_check( 3, 2, 0, 1144, compiled_block_1_1144 );
  twobit_lexical( 0, 1 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(65536) ); /* 65536 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* modulo */
  twobit_setrtn( 1151, compiled_block_1_1151 );
  twobit_invoke( 2 );
  twobit_label( 1151, compiled_block_1_1151 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_stack( 6 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_load( 3, 6 );
  twobit_reg( 1 );
  twobit_check( 3, 2, 0, 1144, compiled_block_1_1144 );
  twobit_load( 3, 2 );
  twobit_stack( 6 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_load( 3, 6 );
  twobit_reg( 1 );
  twobit_check( 3, 2, 0, 1144, compiled_block_1_1144 );
  twobit_stack( 6 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 3, 2, 0, 1144, compiled_block_1_1144 );
  twobit_lexical( 0, 1 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(65536) ); /* 65536 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* modulo */
  twobit_setrtn( 1152, compiled_block_1_1152 );
  twobit_invoke( 2 );
  twobit_label( 1152, compiled_block_1_1152 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 3, 7 );
  twobit_lexical( 0, 2 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_imm_const_setreg( fixnum(65536), 2 ); /* 65536 */
  twobit_op2_65( 2, 92, compiled_temp_1_92 ); /* quotient */
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 2 );
  twobit_op2_402( 2 ); /* vector-ref:trusted */
  twobit_imm_const_setreg( fixnum(65536), 1 ); /* 65536 */
  twobit_op2_65( 1, 93, compiled_temp_1_93 ); /* quotient */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_load( 1, 3 );
  twobit_lexical( 0, 2 );
  twobit_op2_402( 1 ); /* vector-ref:trusted */
  twobit_imm_const_setreg( fixnum(65536), 1 ); /* 65536 */
  twobit_op2_65( 1, 94, compiled_temp_1_94 ); /* quotient */
  twobit_setreg( 1 );
  twobit_load( 4, 4 );
  twobit_lexical( 0, 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_imm_const_setreg( fixnum(65536), 4 ); /* 65536 */
  twobit_op2_65( 4, 95, compiled_temp_1_95 ); /* quotient */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 4, 5 );
  twobit_lexical( 0, 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 2, 8 );
  twobit_imm_const( fixnum(65536) ); /* 65536 */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_65( 4, 96, compiled_temp_1_96 ); /* quotient */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 4, 6 );
  twobit_lexical( 0, 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_imm_const_setreg( fixnum(65536), 4 ); /* 65536 */
  twobit_op2_65( 4, 97, compiled_temp_1_97 ); /* quotient */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_op2_63( 1, 98, compiled_temp_1_98 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_stack( 4 );
  twobit_op2_63( 3, 99, compiled_temp_1_99 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 4, 1 );
  twobit_stack( 5 );
  twobit_op2_63( 4, 100, compiled_temp_1_100 ); /* * */
  twobit_load( 4, 6 );
  twobit_op2_61( 4, 101, compiled_temp_1_101 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_61( 4, 102, compiled_temp_1_102 ); /* + */
  twobit_load( 4, 9 );
  twobit_op2_63( 4, 103, compiled_temp_1_103 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 4, 10 );
  twobit_stack( 3 );
  twobit_op2_63( 4, 104, compiled_temp_1_104 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_stack( 2 );
  twobit_op2_63( 1, 105, compiled_temp_1_105 ); /* * */
  twobit_setreg( 1 );
  twobit_load( 4, 11 );
  twobit_stack( 5 );
  twobit_op2_63( 4, 106, compiled_temp_1_106 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 4, 1 );
  twobit_stack( 12 );
  twobit_op2_63( 4, 107, compiled_temp_1_107 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_stack( 13 );
  twobit_op2_63( 3, 108, compiled_temp_1_108 ); /* * */
  twobit_setreg( 3 );
  twobit_load( 4, 14 );
  twobit_stack( 4 );
  twobit_op2_63( 4, 109, compiled_temp_1_109 ); /* * */
  twobit_op2_61( 3, 110, compiled_temp_1_110 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_61( 4, 111, compiled_temp_1_111 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_61( 4, 112, compiled_temp_1_112 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_61( 4, 113, compiled_temp_1_113 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_61( 4, 114, compiled_temp_1_114 ); /* + */
  twobit_imm_const_setreg( fixnum(65536), 3 ); /* 65536 */
  twobit_op2_63( 3, 115, compiled_temp_1_115 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 3, 10 );
  twobit_stack( 2 );
  twobit_op2_63( 3, 116, compiled_temp_1_116 ); /* * */
  twobit_setreg( 3 );
  twobit_load( 1, 14 );
  twobit_stack( 13 );
  twobit_op2_63( 1, 117, compiled_temp_1_117 ); /* * */
  twobit_setreg( 1 );
  twobit_load( 4, 11 );
  twobit_stack( 12 );
  twobit_op2_63( 4, 118, compiled_temp_1_118 ); /* * */
  twobit_op2_61( 1, 119, compiled_temp_1_119 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_61( 4, 120, compiled_temp_1_120 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_61( 4, 121, compiled_temp_1_121 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_61( 4, 122, compiled_temp_1_122 ); /* + */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* modulo */
  twobit_pop( 14 );
  twobit_invoke( 2 );
  twobit_label( 1145, compiled_block_1_1145 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1149, compiled_block_1_1149 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1142, compiled_block_1_1142 );
  twobit_trap( 29, 6, 0, 160 );
  twobit_label( 1141, compiled_block_1_1141 );
  twobit_trap( 30, 6, 0, 160 );
  twobit_label( 1148, compiled_block_1_1148 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_label( 1144, compiled_block_1_1144 );
  twobit_trap( 2, 3, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_14( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 9 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  :random-source-current-time~1ayXVW~13254 */
  twobit_setrtn( 1175, compiled_block_1_1175 );
  twobit_invoke( 0 );
  twobit_label( 1175, compiled_block_1_1175 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(65536) ); /* 65536 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* modulo */
  twobit_setrtn( 1176, compiled_block_1_1176 );
  twobit_invoke( 2 );
  twobit_label( 1176, compiled_block_1_1176 );
  twobit_load( 0, 0 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_global( 3 ); /*  mrg32k3a-m2~1ayXVW~13264 */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_global( 4 ); /*  mrg32k3a-m1~1ayXVW~13263 */
  twobit_setreg( 2 );
  twobit_store( 2, 6 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /*  mrg32k3a-unpack-state~1ayXVW~13257 */
  twobit_setrtn( 1177, compiled_block_1_1177 );
  twobit_invoke( 1 );
  twobit_label( 1177, compiled_block_1_1177 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_reg_op2_check_662(reg(4),reg(3),1178,compiled_block_1_1178); /* internal:check-vector?/vector-length:vec with (0 4 0) */
  twobit_store( 3, 4 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_reg_op2_check_655(RESULT,reg(3),1178,compiled_block_1_1178); /* internal:check-<:fix:fix with (0 4 0) */
  twobit_reg( 4 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_setrtn( 1179, compiled_block_1_1179 );
  twobit_branch( 1172, compiled_block_1_1172 );
  twobit_label( 1179, compiled_block_1_1179 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_61( 4, 67, compiled_temp_1_67 ); /* + */
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 2 ); /* modulo */
  twobit_setrtn( 1180, compiled_block_1_1180 );
  twobit_invoke( 2 );
  twobit_label( 1180, compiled_block_1_1180 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 3, 4 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 5 );
  twobit_check( 0, 1, 0, 1181, compiled_block_1_1181 );
  twobit_stack( 5 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_load( 1, 3 );
  twobit_load( 2, 2 );
  twobit_setrtn( 1182, compiled_block_1_1182 );
  twobit_branch( 1172, compiled_block_1_1172 );
  twobit_label( 1182, compiled_block_1_1182 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_61( 4, 68, compiled_temp_1_68 ); /* + */
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 2 ); /* modulo */
  twobit_setrtn( 1183, compiled_block_1_1183 );
  twobit_invoke( 2 );
  twobit_label( 1183, compiled_block_1_1183 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_stack( 2 );
  twobit_op2imm_131( fixnum(1), 69, compiled_temp_1_69 ); /* - */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 3, 2 );
  twobit_load( 1, 4 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_op2_407( 1 ); /* <:fix:fix */
  twobit_load( 1, 5 );
  twobit_check( 0, 1, 0, 1184, compiled_block_1_1184 );
  twobit_stack( 5 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_load( 1, 3 );
  twobit_setrtn( 1185, compiled_block_1_1185 );
  twobit_branch( 1172, compiled_block_1_1172 );
  twobit_label( 1185, compiled_block_1_1185 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_61( 4, 70, compiled_temp_1_70 ); /* + */
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 2 ); /* modulo */
  twobit_setrtn( 1186, compiled_block_1_1186 );
  twobit_invoke( 2 );
  twobit_label( 1186, compiled_block_1_1186 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 6 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 4, 71, compiled_temp_1_71 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 3, 4 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 5 );
  twobit_check( 0, 3, 0, 1187, compiled_block_1_1187 );
  twobit_stack( 5 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_load( 1, 3 );
  twobit_setrtn( 1188, compiled_block_1_1188 );
  twobit_branch( 1172, compiled_block_1_1172 );
  twobit_label( 1188, compiled_block_1_1188 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_61( 4, 72, compiled_temp_1_72 ); /* + */
  twobit_setreg( 1 );
  twobit_load( 2, 6 );
  twobit_global( 2 ); /* modulo */
  twobit_setrtn( 1189, compiled_block_1_1189 );
  twobit_invoke( 2 );
  twobit_label( 1189, compiled_block_1_1189 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_load( 3, 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 5 );
  twobit_check( 0, 1, 0, 1190, compiled_block_1_1190 );
  twobit_stack( 5 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_load( 1, 3 );
  twobit_load( 2, 6 );
  twobit_setrtn( 1191, compiled_block_1_1191 );
  twobit_branch( 1172, compiled_block_1_1172 );
  twobit_label( 1191, compiled_block_1_1191 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_61( 4, 73, compiled_temp_1_73 ); /* + */
  twobit_setreg( 1 );
  twobit_load( 2, 6 );
  twobit_global( 2 ); /* modulo */
  twobit_setrtn( 1192, compiled_block_1_1192 );
  twobit_invoke( 2 );
  twobit_label( 1192, compiled_block_1_1192 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_stack( 6 );
  twobit_op2imm_131( fixnum(1), 74, compiled_temp_1_74 ); /* - */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_movereg( 3, 2 );
  twobit_load( 1, 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_407( 1 ); /* <:fix:fix */
  twobit_load( 1, 5 );
  twobit_check( 0, 1, 0, 1193, compiled_block_1_1193 );
  twobit_stack( 5 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_store( 1, 5 );
  twobit_load( 1, 3 );
  twobit_setrtn( 1194, compiled_block_1_1194 );
  twobit_branch( 1172, compiled_block_1_1172 );
  twobit_label( 1194, compiled_block_1_1194 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_61( 4, 75, compiled_temp_1_75 ); /* + */
  twobit_setreg( 1 );
  twobit_load( 2, 6 );
  twobit_global( 2 ); /* modulo */
  twobit_setrtn( 1195, compiled_block_1_1195 );
  twobit_invoke( 2 );
  twobit_label( 1195, compiled_block_1_1195 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 4, 76, compiled_temp_1_76 ); /* + */
  twobit_setreg( 4 );
  twobit_load( 3, 7 );
  twobit_op2_606( 3 ); /* make-vector:6 */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_load( 1, 8 );
  twobit_reg( 3 );
  twobit_op3_403( 2, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_reg( 3 );
  twobit_op3_403( 2, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_load( 1, 9 );
  twobit_reg( 3 );
  twobit_op3_403( 2, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_reg( 3 );
  twobit_op3_403( 2, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op3_403( 2, 4 ); /* vector-set!:trusted */
  twobit_movereg( 3, 1 );
  twobit_global( 6 ); /*  mrg32k3a-pack-state~1ayXVW~13256 */
  twobit_pop( 9 );
  twobit_invoke( 1 );
  twobit_label( 1172, compiled_block_1_1172 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 3 );
  twobit_reg( 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(65536) ); /* 65536 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* modulo */
  twobit_setrtn( 1197, compiled_block_1_1197 );
  twobit_invoke( 2 );
  twobit_label( 1197, compiled_block_1_1197 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_imm_const_setreg( fixnum(65536), 2 ); /* 65536 */
  twobit_op2_65( 2, 77, compiled_temp_1_77 ); /* quotient */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(30903) ); /* 30903 */
  twobit_op2_63( 4, 78, compiled_temp_1_78 ); /* * */
  twobit_op2_61( 3, 79, compiled_temp_1_79 ); /* + */
  twobit_setreg( 2 );
  twobit_stack( 1 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_imm_const( fixnum(65536) ); /* 65536 */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_63( 3, 80, compiled_temp_1_80 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_setrtn( 1198, compiled_block_1_1198 );
  twobit_branch( 1173, compiled_block_1_1173 );
  twobit_label( 1198, compiled_block_1_1198 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_61( 4, 81, compiled_temp_1_81 ); /* + */
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_global( 2 ); /* modulo */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1173, compiled_block_1_1173 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(65536) ); /* 65536 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* modulo */
  twobit_setrtn( 1200, compiled_block_1_1200 );
  twobit_invoke( 2 );
  twobit_label( 1200, compiled_block_1_1200 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_imm_const_setreg( fixnum(65536), 2 ); /* 65536 */
  twobit_op2_65( 2, 82, compiled_temp_1_82 ); /* quotient */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(30903) ); /* 30903 */
  twobit_op2_63( 4, 83, compiled_temp_1_83 ); /* * */
  twobit_op2_61( 3, 84, compiled_temp_1_84 ); /* + */
  twobit_setreg( 2 );
  twobit_stack( 1 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1187, compiled_block_1_1187 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_trap( 3, 1, 0, 160 );
  twobit_label( 1193, compiled_block_1_1193 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1184, compiled_block_1_1184 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1178, compiled_block_1_1178 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 1 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_label( 1190, compiled_block_1_1190 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1181, compiled_block_1_1181 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_15( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op2imm_branchf_639( fixnum(1), 63, compiled_temp_1_63, 1203, compiled_block_1_1203 ); /* internal:branchf-=/imm */
  twobit_global( 1 ); /*  mrg32k3a-m-max~1ayXVW~13269 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  mrg32k3a-random-integer~1ayXVW~13259 */
  twobit_invoke( 2 );
  twobit_label( 1203, compiled_block_1_1203 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 2 );
  twobit_op2imm_131( fixnum(1), 64, compiled_temp_1_64 ); /* - */
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  mrg32k3a-random-power~1ayXVW~13270 */
  twobit_setrtn( 1205, compiled_block_1_1205 );
  twobit_invoke( 2 );
  twobit_label( 1205, compiled_block_1_1205 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  mrg32k3a-m-max~1ayXVW~13269 */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_63( 3, 65, compiled_temp_1_65 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_movereg( 3, 2 );
  twobit_global( 2 ); /*  mrg32k3a-random-integer~1ayXVW~13259 */
  twobit_setrtn( 1206, compiled_block_1_1206 );
  twobit_invoke( 2 );
  twobit_label( 1206, compiled_block_1_1206 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_61( 4, 66, compiled_temp_1_66 ); /* + */
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_16( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  mrg32k3a-m-max~1ayXVW~13269 */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2_63( 4, 53, compiled_temp_1_53 ); /* * */
  twobit_setreg( 4 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_lambda( compiled_start_1_54, 4, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 4, 2 );
  twobit_load( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_54( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_branchf_621( 4, 55, compiled_temp_1_55, 1208, compiled_block_1_1208 ); /* internal:branchf->= */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_65( 4, 56, compiled_temp_1_56 ); /* quotient */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_63( 3, 57, compiled_temp_1_57 ); /* * */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  mrg32k3a-random-power~1ayXVW~13270 */
  twobit_setrtn( 1209, compiled_block_1_1209 );
  twobit_invoke( 2 );
  twobit_label( 1209, compiled_block_1_1209 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 4, 1 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_58, 4, 4 );
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 1208, compiled_block_1_1208 );
  twobit_reg( 1 );
  twobit_op2imm_130( fixnum(1), 59, compiled_temp_1_59 ); /* + */
  twobit_setreg( 1 );
  twobit_global( 5 ); /*  mrg32k3a-m-max~1ayXVW~13269 */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_63( 4, 60, compiled_temp_1_60 ); /* * */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_58( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 61, compiled_temp_1_61, 1211, compiled_block_1_1211 ); /* internal:branchf-< */
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_65( 4, 62, compiled_temp_1_62 ); /* quotient */
  twobit_return();
  twobit_label( 1211, compiled_block_1_1211 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  mrg32k3a-random-power~1ayXVW~13270 */
  twobit_setrtn( 1212, compiled_block_1_1212 );
  twobit_invoke( 2 );
  twobit_label( 1212, compiled_block_1_1212 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_17( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_64( 2, 42, compiled_temp_1_42 ); /* / */
  twobit_op2imm_131( fixnum(1), 43, compiled_temp_1_43 ); /* - */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_44, 3, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_44( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op2imm_branchf_638( fixnum(1), 45, compiled_temp_1_45, 1218, compiled_block_1_1218 ); /* internal:branchf-<=/imm */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  mrg32k3a-random-power~1ayXVW~13270 */
  twobit_setrtn( 1219, compiled_block_1_1219 );
  twobit_invoke( 2 );
  twobit_label( 1219, compiled_block_1_1219 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_op2imm_130( fixnum(1), 46, compiled_temp_1_46 ); /* + */
  twobit_op1_27( 47, compiled_temp_1_47 ); /* exact->inexact */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_global( 2 ); /*  mrg32k3a-m-max~1ayXVW~13269 */
  twobit_setreg( 1 );
  twobit_global( 3 ); /* expt */
  twobit_setrtn( 1220, compiled_block_1_1220 );
  twobit_invoke( 2 );
  twobit_label( 1220, compiled_block_1_1220 );
  twobit_load( 0, 0 );
  twobit_op2imm_130( fixnum(1), 48, compiled_temp_1_48 ); /* + */
  twobit_op1_27( 49, compiled_temp_1_49 ); /* exact->inexact */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_64( 4, 50, compiled_temp_1_50 ); /* / */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1218, compiled_block_1_1218 );
  twobit_reg( 1 );
  twobit_op2imm_130( fixnum(1), 51, compiled_temp_1_51 ); /* + */
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  mrg32k3a-m1~1ayXVW~13263 */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_64( 4, 52, compiled_temp_1_52 ); /* / */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_18( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  mrg32k3a-initial-state~1ayXVW~13265 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /* vector->list */
  twobit_setrtn( 1223, compiled_block_1_1223 );
  twobit_invoke( 1 );
  twobit_label( 1223, compiled_block_1_1223 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* list->vector */
  twobit_setrtn( 1224, compiled_block_1_1224 );
  twobit_invoke( 1 );
  twobit_label( 1224, compiled_block_1_1224 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  mrg32k3a-pack-state~1ayXVW~13256 */
  twobit_setrtn( 1225, compiled_block_1_1225 );
  twobit_invoke( 1 );
  twobit_label( 1225, compiled_block_1_1225 );
  twobit_load( 0, 0 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_25, 6, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_26, 8, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_27, 10, 1 );
  twobit_setreg( 3 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_28, 12, 1 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_lambda( compiled_start_1_29, 14, 1 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_30, 16, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 1, 6 );
  twobit_movereg( 4, 5 );
  twobit_load( 1, 1 );
  twobit_load( 4, 2 );
  twobit_global( 17 ); /*  :random-source-make~1ayXVW~13246 */
  twobit_pop( 2 );
  twobit_invoke( 6 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_25( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  mrg32k3a-state-ref~1ayXVW~13261 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_26( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  mrg32k3a-state-set~1ayXVW~13262 */
  twobit_setrtn( 1227, compiled_block_1_1227 );
  twobit_invoke( 1 );
  twobit_label( 1227, compiled_block_1_1227 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_27( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  mrg32k3a-randomize-state~1ayXVW~13268 */
  twobit_setrtn( 1228, compiled_block_1_1228 );
  twobit_invoke( 1 );
  twobit_label( 1228, compiled_block_1_1228 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_28( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  mrg32k3a-pseudo-randomize-state~1ayXVW~13267 */
  twobit_setrtn( 1229, compiled_block_1_1229 );
  twobit_invoke( 2 );
  twobit_label( 1229, compiled_block_1_1229 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_29( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lambda( compiled_start_1_39, 2, 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_39( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1231, compiled_block_1_1231 );
  twobit_reg( 1 );
  twobit_op1_25(); /* exact? */
  twobit_branchf( 1233, compiled_block_1_1233 );
  twobit_reg( 1 );
  twobit_op2imm_135( fixnum(0), 40, compiled_temp_1_40 ); /* > */
  twobit_skip( 1230, compiled_block_1_1230 );
  twobit_label( 1233, compiled_block_1_1233 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1230, compiled_block_1_1230 );
  twobit_label( 1231, compiled_block_1_1231 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1230, compiled_block_1_1230 );
  twobit_branchf( 1235, compiled_block_1_1235 );
  twobit_global( 1 ); /*  mrg32k3a-m-max~1ayXVW~13269 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_622( 4, 41, compiled_temp_1_41, 1237, compiled_block_1_1237 ); /* internal:branchf-<= */
  twobit_movereg( 1, 2 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  mrg32k3a-random-integer~1ayXVW~13259 */
  twobit_invoke( 2 );
  twobit_label( 1237, compiled_block_1_1237 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  mrg32k3a-random-large~1ayXVW~13271 */
  twobit_invoke( 2 );
  twobit_label( 1235, compiled_block_1_1235 );
  twobit_movereg( 1, 2 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /* error */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_30( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1242, compiled_block_1_1242 ); /* internal:branchf-null? */
  twobit_lambda( compiled_start_1_31, 2, 0 );
  twobit_return();
  twobit_label( 1242, compiled_block_1_1242 );
  twobit_reg_op1_check_652(reg(1),1244,compiled_block_1_1244); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1246, compiled_block_1_1246 ); /* internal:branchf-null? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_20(); /* rational? */
  twobit_branchf( 1248, compiled_block_1_1248 );
  twobit_reg( 4 );
  twobit_op2imm_132( fixnum(1), 32, compiled_temp_1_32 ); /* < */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_branchf_619( 4, 33, compiled_temp_1_33, 1250, compiled_block_1_1250 ); /* internal:branchf-< */
  twobit_reg( 3 );
  twobit_skip( 1247, compiled_block_1_1247 );
  twobit_label( 1250, compiled_block_1_1250 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1247, compiled_block_1_1247 );
  twobit_label( 1248, compiled_block_1_1248 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1247, compiled_block_1_1247 );
  twobit_branchf( 1252, compiled_block_1_1252 );
  twobit_global( 3 ); /*  mrg32k3a-m1~1ayXVW~13263 */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_64( 4, 34, compiled_temp_1_34 ); /* / */
  twobit_op2imm_131( fixnum(1), 35, compiled_temp_1_35 ); /* - */
  twobit_op2_branchf_622( 3, 36, compiled_temp_1_36, 1254, compiled_block_1_1254 ); /* internal:branchf-<= */
  twobit_lambda( compiled_start_1_37, 5, 0 );
  twobit_return();
  twobit_label( 1254, compiled_block_1_1254 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_38, 7, 1 );
  twobit_return();
  twobit_label( 1252, compiled_block_1_1252 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 9 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1246, compiled_block_1_1246 );
  twobit_movereg( 1, 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_global( 9 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1244, compiled_block_1_1244 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_31( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  mrg32k3a-random-real~1ayXVW~13260 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_37( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  mrg32k3a-random-real~1ayXVW~13260 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_38( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  mrg32k3a-random-real-mp~1ayXVW~13272 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_19( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  :random-source-state-ref~1ayXVW~13248 */
  twobit_setrtn( 1260, compiled_block_1_1260 );
  twobit_invoke( 1 );
  twobit_label( 1260, compiled_block_1_1260 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_20( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  :random-source-state-set!~1ayXVW~13249 */
  twobit_setrtn( 1262, compiled_block_1_1262 );
  twobit_invoke( 1 );
  twobit_label( 1262, compiled_block_1_1262 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_21( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  :random-source-randomize!~1ayXVW~13250 */
  twobit_setrtn( 1264, compiled_block_1_1264 );
  twobit_invoke( 1 );
  twobit_label( 1264, compiled_block_1_1264 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_22( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  :random-source-pseudo-randomize!~1ayXVW~13251 */
  twobit_setrtn( 1266, compiled_block_1_1266 );
  twobit_invoke( 1 );
  twobit_label( 1266, compiled_block_1_1266 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_23( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  :random-source-make-integers~1ayXVW~13252 */
  twobit_setrtn( 1268, compiled_block_1_1268 );
  twobit_invoke( 1 );
  twobit_label( 1268, compiled_block_1_1268 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_24( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  :random-source-make-reals~1ayXVW~13253 */
  twobit_setrtn( 1270, compiled_block_1_1270 );
  twobit_invoke( 1 );
  twobit_label( 1270, compiled_block_1_1270 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 2 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


RTYPE twobit_thunk_f01efd60cdcce99f32903d7fa7361323_0(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_1_0(CONT_ACTUALS));
}
static RTYPE compiled_block_2_1004( CONT_PARAMS );
static RTYPE compiled_block_2_1003( CONT_PARAMS );
static RTYPE compiled_start_2_0( CONT_PARAMS );
static RTYPE compiled_start_2_3( CONT_PARAMS );
static RTYPE compiled_start_2_2( CONT_PARAMS );
static RTYPE compiled_start_2_1( CONT_PARAMS );

static RTYPE compiled_start_2_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_2_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_2_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1003, compiled_block_2_1003 );
  twobit_invoke( 8 );
  twobit_label( 1003, compiled_block_2_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1004, compiled_block_2_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_2_1004 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_f01efd60cdcce99f32903d7fa7361323_1(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_2_0(CONT_ACTUALS));
}
codeptr_t CDECL twobit_load_table[] = { 
  twobit_thunk_f01efd60cdcce99f32903d7fa7361323_0,
  twobit_thunk_f01efd60cdcce99f32903d7fa7361323_1,
  0  /* The table may be empty; some compilers complain */
};

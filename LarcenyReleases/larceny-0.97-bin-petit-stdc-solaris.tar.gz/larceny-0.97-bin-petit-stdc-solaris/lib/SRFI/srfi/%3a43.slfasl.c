/* Generated from /proj/will/pnkfelix/larcenytest/larceny-petit-Nightly-2009-08-19/larceny_src/lib/SRFI/srfi/%3a43.slfasl */
#include "petit-instr.h"

static RTYPE compiled_block_1_1004( CONT_PARAMS );
static RTYPE compiled_block_1_1003( CONT_PARAMS );
static RTYPE compiled_start_1_0( CONT_PARAMS );
static RTYPE compiled_start_1_3( CONT_PARAMS );
static RTYPE compiled_start_1_2( CONT_PARAMS );
static RTYPE compiled_start_1_1( CONT_PARAMS );

static RTYPE compiled_start_1_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1003, compiled_block_1_1003 );
  twobit_invoke( 8 );
  twobit_label( 1003, compiled_block_1_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1004, compiled_block_1_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_1_1004 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_84467001c87d88ff37d722b999e52a0f_0(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_1_0(CONT_ACTUALS));
}
static RTYPE compiled_block_2_1926( CONT_PARAMS );
static RTYPE compiled_block_2_1925( CONT_PARAMS );
static RTYPE compiled_start_2_0( CONT_PARAMS );
static RTYPE compiled_start_2_3( CONT_PARAMS );
static RTYPE compiled_block_2_1893( CONT_PARAMS );
static RTYPE compiled_block_2_1908( CONT_PARAMS );
static RTYPE compiled_block_2_1922( CONT_PARAMS );
static RTYPE compiled_block_2_1910( CONT_PARAMS );
static RTYPE compiled_block_2_1920( CONT_PARAMS );
static RTYPE compiled_temp_2_88( CONT_PARAMS );
static RTYPE compiled_block_2_1912( CONT_PARAMS );
static RTYPE compiled_block_2_1911( CONT_PARAMS );
static RTYPE compiled_block_2_1895( CONT_PARAMS );
static RTYPE compiled_block_2_1906( CONT_PARAMS );
static RTYPE compiled_temp_2_86( CONT_PARAMS );
static RTYPE compiled_block_2_1898( CONT_PARAMS );
static RTYPE compiled_block_2_1897( CONT_PARAMS );
static RTYPE compiled_block_2_1896( CONT_PARAMS );
static RTYPE compiled_block_2_1880( CONT_PARAMS );
static RTYPE compiled_block_2_1891( CONT_PARAMS );
static RTYPE compiled_temp_2_84( CONT_PARAMS );
static RTYPE compiled_block_2_1883( CONT_PARAMS );
static RTYPE compiled_block_2_1882( CONT_PARAMS );
static RTYPE compiled_block_2_1881( CONT_PARAMS );
static RTYPE compiled_start_2_82( CONT_PARAMS );
static RTYPE compiled_block_2_1917( CONT_PARAMS );
static RTYPE compiled_block_2_1914( CONT_PARAMS );
static RTYPE compiled_start_2_87( CONT_PARAMS );
static RTYPE compiled_block_2_1903( CONT_PARAMS );
static RTYPE compiled_block_2_1900( CONT_PARAMS );
static RTYPE compiled_start_2_85( CONT_PARAMS );
static RTYPE compiled_block_2_1888( CONT_PARAMS );
static RTYPE compiled_block_2_1885( CONT_PARAMS );
static RTYPE compiled_start_2_83( CONT_PARAMS );
static RTYPE compiled_block_2_1848( CONT_PARAMS );
static RTYPE compiled_block_2_1863( CONT_PARAMS );
static RTYPE compiled_block_2_1877( CONT_PARAMS );
static RTYPE compiled_block_2_1865( CONT_PARAMS );
static RTYPE compiled_block_2_1875( CONT_PARAMS );
static RTYPE compiled_temp_2_92( CONT_PARAMS );
static RTYPE compiled_block_2_1867( CONT_PARAMS );
static RTYPE compiled_block_2_1866( CONT_PARAMS );
static RTYPE compiled_block_2_1850( CONT_PARAMS );
static RTYPE compiled_block_2_1861( CONT_PARAMS );
static RTYPE compiled_temp_2_90( CONT_PARAMS );
static RTYPE compiled_block_2_1853( CONT_PARAMS );
static RTYPE compiled_block_2_1852( CONT_PARAMS );
static RTYPE compiled_block_2_1851( CONT_PARAMS );
static RTYPE compiled_block_2_1846( CONT_PARAMS );
static RTYPE compiled_start_2_81( CONT_PARAMS );
static RTYPE compiled_block_2_1872( CONT_PARAMS );
static RTYPE compiled_block_2_1869( CONT_PARAMS );
static RTYPE compiled_start_2_91( CONT_PARAMS );
static RTYPE compiled_block_2_1858( CONT_PARAMS );
static RTYPE compiled_block_2_1855( CONT_PARAMS );
static RTYPE compiled_start_2_89( CONT_PARAMS );
static RTYPE compiled_block_2_1837( CONT_PARAMS );
static RTYPE compiled_start_2_80( CONT_PARAMS );
static RTYPE compiled_start_2_94( CONT_PARAMS );
static RTYPE compiled_block_2_1841( CONT_PARAMS );
static RTYPE compiled_block_2_1840( CONT_PARAMS );
static RTYPE compiled_temp_2_96( CONT_PARAMS );
static RTYPE compiled_start_2_95( CONT_PARAMS );
static RTYPE compiled_start_2_93( CONT_PARAMS );
static RTYPE compiled_block_2_1829( CONT_PARAMS );
static RTYPE compiled_block_2_1827( CONT_PARAMS );
static RTYPE compiled_start_2_79( CONT_PARAMS );
static RTYPE compiled_temp_2_99( CONT_PARAMS );
static RTYPE compiled_start_2_98( CONT_PARAMS );
static RTYPE compiled_block_2_1833( CONT_PARAMS );
static RTYPE compiled_block_2_1832( CONT_PARAMS );
static RTYPE compiled_temp_2_101( CONT_PARAMS );
static RTYPE compiled_start_2_100( CONT_PARAMS );
static RTYPE compiled_start_2_97( CONT_PARAMS );
static RTYPE compiled_block_2_1822( CONT_PARAMS );
static RTYPE compiled_start_2_78( CONT_PARAMS );
static RTYPE compiled_start_2_103( CONT_PARAMS );
static RTYPE compiled_start_2_102( CONT_PARAMS );
static RTYPE compiled_block_2_1816( CONT_PARAMS );
static RTYPE compiled_block_2_1785( CONT_PARAMS );
static RTYPE compiled_block_2_1789( CONT_PARAMS );
static RTYPE compiled_block_2_1793( CONT_PARAMS );
static RTYPE compiled_block_2_1820( CONT_PARAMS );
static RTYPE compiled_block_2_1818( CONT_PARAMS );
static RTYPE compiled_block_2_1814( CONT_PARAMS );
static RTYPE compiled_block_2_1815( CONT_PARAMS );
static RTYPE compiled_temp_2_111( CONT_PARAMS );
static RTYPE compiled_temp_2_110( CONT_PARAMS );
static RTYPE compiled_temp_2_109( CONT_PARAMS );
static RTYPE compiled_block_2_1812( CONT_PARAMS );
static RTYPE compiled_block_2_1813( CONT_PARAMS );
static RTYPE compiled_temp_2_108( CONT_PARAMS );
static RTYPE compiled_block_2_1810( CONT_PARAMS );
static RTYPE compiled_block_2_1811( CONT_PARAMS );
static RTYPE compiled_temp_2_107( CONT_PARAMS );
static RTYPE compiled_temp_2_106( CONT_PARAMS );
static RTYPE compiled_block_2_1808( CONT_PARAMS );
static RTYPE compiled_block_2_1801( CONT_PARAMS );
static RTYPE compiled_block_2_1802( CONT_PARAMS );
static RTYPE compiled_block_2_1806( CONT_PARAMS );
static RTYPE compiled_temp_2_105( CONT_PARAMS );
static RTYPE compiled_temp_2_104( CONT_PARAMS );
static RTYPE compiled_block_2_1805( CONT_PARAMS );
static RTYPE compiled_block_2_1803( CONT_PARAMS );
static RTYPE compiled_block_2_1800( CONT_PARAMS );
static RTYPE compiled_block_2_1799( CONT_PARAMS );
static RTYPE compiled_block_2_1798( CONT_PARAMS );
static RTYPE compiled_block_2_1783( CONT_PARAMS );
static RTYPE compiled_block_2_1795( CONT_PARAMS );
static RTYPE compiled_block_2_1791( CONT_PARAMS );
static RTYPE compiled_block_2_1787( CONT_PARAMS );
static RTYPE compiled_start_2_77( CONT_PARAMS );
static RTYPE compiled_block_2_1781( CONT_PARAMS );
static RTYPE compiled_block_2_1755( CONT_PARAMS );
static RTYPE compiled_block_2_1759( CONT_PARAMS );
static RTYPE compiled_block_2_1763( CONT_PARAMS );
static RTYPE compiled_block_2_1777( CONT_PARAMS );
static RTYPE compiled_block_2_1779( CONT_PARAMS );
static RTYPE compiled_block_2_1775( CONT_PARAMS );
static RTYPE compiled_block_2_1776( CONT_PARAMS );
static RTYPE compiled_temp_2_117( CONT_PARAMS );
static RTYPE compiled_temp_2_116( CONT_PARAMS );
static RTYPE compiled_temp_2_115( CONT_PARAMS );
static RTYPE compiled_block_2_1773( CONT_PARAMS );
static RTYPE compiled_block_2_1774( CONT_PARAMS );
static RTYPE compiled_temp_2_114( CONT_PARAMS );
static RTYPE compiled_block_2_1771( CONT_PARAMS );
static RTYPE compiled_block_2_1772( CONT_PARAMS );
static RTYPE compiled_temp_2_113( CONT_PARAMS );
static RTYPE compiled_temp_2_112( CONT_PARAMS );
static RTYPE compiled_block_2_1770( CONT_PARAMS );
static RTYPE compiled_block_2_1769( CONT_PARAMS );
static RTYPE compiled_block_2_1768( CONT_PARAMS );
static RTYPE compiled_block_2_1753( CONT_PARAMS );
static RTYPE compiled_block_2_1765( CONT_PARAMS );
static RTYPE compiled_block_2_1761( CONT_PARAMS );
static RTYPE compiled_block_2_1757( CONT_PARAMS );
static RTYPE compiled_start_2_76( CONT_PARAMS );
static RTYPE compiled_block_2_1745( CONT_PARAMS );
static RTYPE compiled_block_2_1743( CONT_PARAMS );
static RTYPE compiled_start_2_75( CONT_PARAMS );
static RTYPE compiled_start_2_119( CONT_PARAMS );
static RTYPE compiled_block_2_1749( CONT_PARAMS );
static RTYPE compiled_block_2_1748( CONT_PARAMS );
static RTYPE compiled_temp_2_121( CONT_PARAMS );
static RTYPE compiled_start_2_120( CONT_PARAMS );
static RTYPE compiled_start_2_118( CONT_PARAMS );
static RTYPE compiled_block_2_1739( CONT_PARAMS );
static RTYPE compiled_block_2_1741( CONT_PARAMS );
static RTYPE compiled_block_2_1740( CONT_PARAMS );
static RTYPE compiled_block_2_1738( CONT_PARAMS );
static RTYPE compiled_block_2_1737( CONT_PARAMS );
static RTYPE compiled_block_2_1736( CONT_PARAMS );
static RTYPE compiled_start_2_74( CONT_PARAMS );
static RTYPE compiled_block_2_1731( CONT_PARAMS );
static RTYPE compiled_block_2_1733( CONT_PARAMS );
static RTYPE compiled_temp_2_122( CONT_PARAMS );
static RTYPE compiled_block_2_1734( CONT_PARAMS );
static RTYPE compiled_block_2_1730( CONT_PARAMS );
static RTYPE compiled_block_2_1728( CONT_PARAMS );
static RTYPE compiled_block_2_1727( CONT_PARAMS );
static RTYPE compiled_start_2_73( CONT_PARAMS );
static RTYPE compiled_block_2_1721( CONT_PARAMS );
static RTYPE compiled_block_2_1725( CONT_PARAMS );
static RTYPE compiled_block_2_1723( CONT_PARAMS );
static RTYPE compiled_block_2_1720( CONT_PARAMS );
static RTYPE compiled_temp_2_124( CONT_PARAMS );
static RTYPE compiled_block_2_1718( CONT_PARAMS );
static RTYPE compiled_temp_2_123( CONT_PARAMS );
static RTYPE compiled_start_2_72( CONT_PARAMS );
static RTYPE compiled_block_2_1715( CONT_PARAMS );
static RTYPE compiled_temp_2_127( CONT_PARAMS );
static RTYPE compiled_block_2_1713( CONT_PARAMS );
static RTYPE compiled_block_2_1712( CONT_PARAMS );
static RTYPE compiled_block_2_1709( CONT_PARAMS );
static RTYPE compiled_block_2_1710( CONT_PARAMS );
static RTYPE compiled_temp_2_126( CONT_PARAMS );
static RTYPE compiled_block_2_1707( CONT_PARAMS );
static RTYPE compiled_temp_2_125( CONT_PARAMS );
static RTYPE compiled_start_2_71( CONT_PARAMS );
static RTYPE compiled_block_2_1701( CONT_PARAMS );
static RTYPE compiled_block_2_1703( CONT_PARAMS );
static RTYPE compiled_temp_2_128( CONT_PARAMS );
static RTYPE compiled_block_2_1704( CONT_PARAMS );
static RTYPE compiled_block_2_1700( CONT_PARAMS );
static RTYPE compiled_block_2_1698( CONT_PARAMS );
static RTYPE compiled_block_2_1697( CONT_PARAMS );
static RTYPE compiled_start_2_70( CONT_PARAMS );
static RTYPE compiled_block_2_1691( CONT_PARAMS );
static RTYPE compiled_block_2_1695( CONT_PARAMS );
static RTYPE compiled_block_2_1693( CONT_PARAMS );
static RTYPE compiled_block_2_1690( CONT_PARAMS );
static RTYPE compiled_temp_2_130( CONT_PARAMS );
static RTYPE compiled_block_2_1688( CONT_PARAMS );
static RTYPE compiled_temp_2_129( CONT_PARAMS );
static RTYPE compiled_start_2_69( CONT_PARAMS );
static RTYPE compiled_temp_2_133( CONT_PARAMS );
static RTYPE compiled_block_2_1685( CONT_PARAMS );
static RTYPE compiled_block_2_1683( CONT_PARAMS );
static RTYPE compiled_block_2_1682( CONT_PARAMS );
static RTYPE compiled_block_2_1679( CONT_PARAMS );
static RTYPE compiled_block_2_1680( CONT_PARAMS );
static RTYPE compiled_temp_2_132( CONT_PARAMS );
static RTYPE compiled_block_2_1677( CONT_PARAMS );
static RTYPE compiled_temp_2_131( CONT_PARAMS );
static RTYPE compiled_start_2_68( CONT_PARAMS );
static RTYPE compiled_block_2_1657( CONT_PARAMS );
static RTYPE compiled_block_2_1656( CONT_PARAMS );
static RTYPE compiled_start_2_67( CONT_PARAMS );
static RTYPE compiled_start_2_135( CONT_PARAMS );
static RTYPE compiled_block_2_1665( CONT_PARAMS );
static RTYPE compiled_block_2_1671( CONT_PARAMS );
static RTYPE compiled_temp_2_142( CONT_PARAMS );
static RTYPE compiled_block_2_1669( CONT_PARAMS );
static RTYPE compiled_temp_2_141( CONT_PARAMS );
static RTYPE compiled_block_2_1667( CONT_PARAMS );
static RTYPE compiled_block_2_1666( CONT_PARAMS );
static RTYPE compiled_block_2_1664( CONT_PARAMS );
static RTYPE compiled_block_2_1659( CONT_PARAMS );
static RTYPE compiled_block_2_1662( CONT_PARAMS );
static RTYPE compiled_temp_2_140( CONT_PARAMS );
static RTYPE compiled_block_2_1660( CONT_PARAMS );
static RTYPE compiled_temp_2_139( CONT_PARAMS );
static RTYPE compiled_temp_2_138( CONT_PARAMS );
static RTYPE compiled_temp_2_137( CONT_PARAMS );
static RTYPE compiled_start_2_136( CONT_PARAMS );
static RTYPE compiled_start_2_134( CONT_PARAMS );
static RTYPE compiled_block_2_1651( CONT_PARAMS );
static RTYPE compiled_block_2_1653( CONT_PARAMS );
static RTYPE compiled_temp_2_143( CONT_PARAMS );
static RTYPE compiled_block_2_1654( CONT_PARAMS );
static RTYPE compiled_block_2_1650( CONT_PARAMS );
static RTYPE compiled_block_2_1648( CONT_PARAMS );
static RTYPE compiled_block_2_1647( CONT_PARAMS );
static RTYPE compiled_start_2_66( CONT_PARAMS );
static RTYPE compiled_block_2_1642( CONT_PARAMS );
static RTYPE compiled_block_2_1645( CONT_PARAMS );
static RTYPE compiled_block_2_1643( CONT_PARAMS );
static RTYPE compiled_block_2_1641( CONT_PARAMS );
static RTYPE compiled_temp_2_144( CONT_PARAMS );
static RTYPE compiled_start_2_65( CONT_PARAMS );
static RTYPE compiled_temp_2_146( CONT_PARAMS );
static RTYPE compiled_block_2_1638( CONT_PARAMS );
static RTYPE compiled_block_2_1636( CONT_PARAMS );
static RTYPE compiled_block_2_1635( CONT_PARAMS );
static RTYPE compiled_block_2_1634( CONT_PARAMS );
static RTYPE compiled_temp_2_145( CONT_PARAMS );
static RTYPE compiled_start_2_64( CONT_PARAMS );
static RTYPE compiled_start_2_63( CONT_PARAMS );
static RTYPE compiled_block_2_1631( CONT_PARAMS );
static RTYPE compiled_start_2_147( CONT_PARAMS );
static RTYPE compiled_start_2_62( CONT_PARAMS );
static RTYPE compiled_block_2_1625( CONT_PARAMS );
static RTYPE compiled_block_2_1627( CONT_PARAMS );
static RTYPE compiled_block_2_1628( CONT_PARAMS );
static RTYPE compiled_block_2_1624( CONT_PARAMS );
static RTYPE compiled_block_2_1622( CONT_PARAMS );
static RTYPE compiled_block_2_1621( CONT_PARAMS );
static RTYPE compiled_start_2_61( CONT_PARAMS );
static RTYPE compiled_block_2_1616( CONT_PARAMS );
static RTYPE compiled_block_2_1619( CONT_PARAMS );
static RTYPE compiled_block_2_1617( CONT_PARAMS );
static RTYPE compiled_block_2_1615( CONT_PARAMS );
static RTYPE compiled_temp_2_148( CONT_PARAMS );
static RTYPE compiled_start_2_60( CONT_PARAMS );
static RTYPE compiled_temp_2_150( CONT_PARAMS );
static RTYPE compiled_block_2_1612( CONT_PARAMS );
static RTYPE compiled_block_2_1610( CONT_PARAMS );
static RTYPE compiled_block_2_1609( CONT_PARAMS );
static RTYPE compiled_block_2_1608( CONT_PARAMS );
static RTYPE compiled_temp_2_149( CONT_PARAMS );
static RTYPE compiled_start_2_59( CONT_PARAMS );
static RTYPE compiled_start_2_58( CONT_PARAMS );
static RTYPE compiled_block_2_1605( CONT_PARAMS );
static RTYPE compiled_start_2_151( CONT_PARAMS );
static RTYPE compiled_start_2_57( CONT_PARAMS );
static RTYPE compiled_block_2_1601( CONT_PARAMS );
static RTYPE compiled_block_2_1596( CONT_PARAMS );
static RTYPE compiled_block_2_1602( CONT_PARAMS );
static RTYPE compiled_block_2_1592( CONT_PARAMS );
static RTYPE compiled_block_2_1590( CONT_PARAMS );
static RTYPE compiled_block_2_1589( CONT_PARAMS );
static RTYPE compiled_start_2_56( CONT_PARAMS );
static RTYPE compiled_block_2_1600( CONT_PARAMS );
static RTYPE compiled_temp_2_154( CONT_PARAMS );
static RTYPE compiled_block_2_1598( CONT_PARAMS );
static RTYPE compiled_start_2_153( CONT_PARAMS );
static RTYPE compiled_block_2_1595( CONT_PARAMS );
static RTYPE compiled_temp_2_155( CONT_PARAMS );
static RTYPE compiled_block_2_1593( CONT_PARAMS );
static RTYPE compiled_start_2_152( CONT_PARAMS );
static RTYPE compiled_block_2_1584( CONT_PARAMS );
static RTYPE compiled_block_2_1586( CONT_PARAMS );
static RTYPE compiled_block_2_1587( CONT_PARAMS );
static RTYPE compiled_block_2_1583( CONT_PARAMS );
static RTYPE compiled_block_2_1581( CONT_PARAMS );
static RTYPE compiled_block_2_1580( CONT_PARAMS );
static RTYPE compiled_start_2_55( CONT_PARAMS );
static RTYPE compiled_block_2_1577( CONT_PARAMS );
static RTYPE compiled_block_2_1576( CONT_PARAMS );
static RTYPE compiled_block_2_1578( CONT_PARAMS );
static RTYPE compiled_temp_2_156( CONT_PARAMS );
static RTYPE compiled_start_2_54( CONT_PARAMS );
static RTYPE compiled_block_2_1571( CONT_PARAMS );
static RTYPE compiled_temp_2_158( CONT_PARAMS );
static RTYPE compiled_block_2_1573( CONT_PARAMS );
static RTYPE compiled_block_2_1572( CONT_PARAMS );
static RTYPE compiled_temp_2_157( CONT_PARAMS );
static RTYPE compiled_start_2_53( CONT_PARAMS );
static RTYPE compiled_block_2_1566( CONT_PARAMS );
static RTYPE compiled_block_2_1564( CONT_PARAMS );
static RTYPE compiled_block_2_1562( CONT_PARAMS );
static RTYPE compiled_block_2_1568( CONT_PARAMS );
static RTYPE compiled_block_2_1567( CONT_PARAMS );
static RTYPE compiled_block_2_1563( CONT_PARAMS );
static RTYPE compiled_block_2_1565( CONT_PARAMS );
static RTYPE compiled_block_2_1561( CONT_PARAMS );
static RTYPE compiled_block_2_1560( CONT_PARAMS );
static RTYPE compiled_start_2_52( CONT_PARAMS );
static RTYPE compiled_block_2_1555( CONT_PARAMS );
static RTYPE compiled_block_2_1557( CONT_PARAMS );
static RTYPE compiled_block_2_1558( CONT_PARAMS );
static RTYPE compiled_block_2_1554( CONT_PARAMS );
static RTYPE compiled_block_2_1552( CONT_PARAMS );
static RTYPE compiled_block_2_1551( CONT_PARAMS );
static RTYPE compiled_start_2_51( CONT_PARAMS );
static RTYPE compiled_block_2_1546( CONT_PARAMS );
static RTYPE compiled_block_2_1548( CONT_PARAMS );
static RTYPE compiled_temp_2_159( CONT_PARAMS );
static RTYPE compiled_block_2_1549( CONT_PARAMS );
static RTYPE compiled_block_2_1545( CONT_PARAMS );
static RTYPE compiled_block_2_1543( CONT_PARAMS );
static RTYPE compiled_block_2_1542( CONT_PARAMS );
static RTYPE compiled_start_2_50( CONT_PARAMS );
static RTYPE compiled_block_2_1539( CONT_PARAMS );
static RTYPE compiled_block_2_1540( CONT_PARAMS );
static RTYPE compiled_temp_2_161( CONT_PARAMS );
static RTYPE compiled_block_2_1538( CONT_PARAMS );
static RTYPE compiled_temp_2_160( CONT_PARAMS );
static RTYPE compiled_start_2_49( CONT_PARAMS );
static RTYPE compiled_block_2_1535( CONT_PARAMS );
static RTYPE compiled_block_2_1534( CONT_PARAMS );
static RTYPE compiled_temp_2_163( CONT_PARAMS );
static RTYPE compiled_block_2_1533( CONT_PARAMS );
static RTYPE compiled_temp_2_162( CONT_PARAMS );
static RTYPE compiled_start_2_48( CONT_PARAMS );
static RTYPE compiled_block_2_1527( CONT_PARAMS );
static RTYPE compiled_block_2_1529( CONT_PARAMS );
static RTYPE compiled_block_2_1530( CONT_PARAMS );
static RTYPE compiled_block_2_1526( CONT_PARAMS );
static RTYPE compiled_block_2_1524( CONT_PARAMS );
static RTYPE compiled_block_2_1523( CONT_PARAMS );
static RTYPE compiled_start_2_47( CONT_PARAMS );
static RTYPE compiled_block_2_1505( CONT_PARAMS );
static RTYPE compiled_block_2_1506( CONT_PARAMS );
static RTYPE compiled_block_2_1521( CONT_PARAMS );
static RTYPE compiled_block_2_1504( CONT_PARAMS );
static RTYPE compiled_start_2_46( CONT_PARAMS );
static RTYPE compiled_block_2_1518( CONT_PARAMS );
static RTYPE compiled_block_2_1517( CONT_PARAMS );
static RTYPE compiled_block_2_1516( CONT_PARAMS );
static RTYPE compiled_temp_2_167( CONT_PARAMS );
static RTYPE compiled_block_2_1514( CONT_PARAMS );
static RTYPE compiled_temp_2_166( CONT_PARAMS );
static RTYPE compiled_start_2_165( CONT_PARAMS );
static RTYPE compiled_block_2_1511( CONT_PARAMS );
static RTYPE compiled_temp_2_168( CONT_PARAMS );
static RTYPE compiled_block_2_1507( CONT_PARAMS );
static RTYPE compiled_block_2_1509( CONT_PARAMS );
static RTYPE compiled_block_2_1508( CONT_PARAMS );
static RTYPE compiled_start_2_164( CONT_PARAMS );
static RTYPE compiled_block_2_1489( CONT_PARAMS );
static RTYPE compiled_block_2_1491( CONT_PARAMS );
static RTYPE compiled_block_2_1492( CONT_PARAMS );
static RTYPE compiled_block_2_1488( CONT_PARAMS );
static RTYPE compiled_block_2_1486( CONT_PARAMS );
static RTYPE compiled_start_2_45( CONT_PARAMS );
static RTYPE compiled_block_2_1493( CONT_PARAMS );
static RTYPE compiled_block_2_1497( CONT_PARAMS );
static RTYPE compiled_block_2_1500( CONT_PARAMS );
static RTYPE compiled_block_2_1498( CONT_PARAMS );
static RTYPE compiled_block_2_1496( CONT_PARAMS );
static RTYPE compiled_block_2_1494( CONT_PARAMS );
static RTYPE compiled_start_2_169( CONT_PARAMS );
static RTYPE compiled_block_2_1485( CONT_PARAMS );
static RTYPE compiled_temp_2_170( CONT_PARAMS );
static RTYPE compiled_block_2_1484( CONT_PARAMS );
static RTYPE compiled_start_2_44( CONT_PARAMS );
static RTYPE compiled_block_2_1480( CONT_PARAMS );
static RTYPE compiled_block_2_1476( CONT_PARAMS );
static RTYPE compiled_block_2_1483( CONT_PARAMS );
static RTYPE compiled_block_2_1482( CONT_PARAMS );
static RTYPE compiled_block_2_1478( CONT_PARAMS );
static RTYPE compiled_block_2_1481( CONT_PARAMS );
static RTYPE compiled_block_2_1479( CONT_PARAMS );
static RTYPE compiled_block_2_1475( CONT_PARAMS );
static RTYPE compiled_start_2_43( CONT_PARAMS );
static RTYPE compiled_block_2_1472( CONT_PARAMS );
static RTYPE compiled_block_2_1470( CONT_PARAMS );
static RTYPE compiled_temp_2_171( CONT_PARAMS );
static RTYPE compiled_block_2_1471( CONT_PARAMS );
static RTYPE compiled_block_2_1469( CONT_PARAMS );
static RTYPE compiled_start_2_42( CONT_PARAMS );
static RTYPE compiled_block_2_1465( CONT_PARAMS );
static RTYPE compiled_block_2_1464( CONT_PARAMS );
static RTYPE compiled_temp_2_172( CONT_PARAMS );
static RTYPE compiled_block_2_1466( CONT_PARAMS );
static RTYPE compiled_block_2_1463( CONT_PARAMS );
static RTYPE compiled_start_2_41( CONT_PARAMS );
static RTYPE compiled_start_2_40( CONT_PARAMS );
static RTYPE compiled_start_2_39( CONT_PARAMS );
static RTYPE compiled_block_2_1456( CONT_PARAMS );
static RTYPE compiled_start_2_38( CONT_PARAMS );
static RTYPE compiled_block_2_1458( CONT_PARAMS );
static RTYPE compiled_temp_2_175( CONT_PARAMS );
static RTYPE compiled_start_2_174( CONT_PARAMS );
static RTYPE compiled_start_2_173( CONT_PARAMS );
static RTYPE compiled_block_2_1441( CONT_PARAMS );
static RTYPE compiled_block_2_1426( CONT_PARAMS );
static RTYPE compiled_block_2_1431( CONT_PARAMS );
static RTYPE compiled_block_2_1436( CONT_PARAMS );
static RTYPE compiled_block_2_1453( CONT_PARAMS );
static RTYPE compiled_block_2_1450( CONT_PARAMS );
static RTYPE compiled_block_2_1451( CONT_PARAMS );
static RTYPE compiled_temp_2_178( CONT_PARAMS );
static RTYPE compiled_block_2_1448( CONT_PARAMS );
static RTYPE compiled_block_2_1449( CONT_PARAMS );
static RTYPE compiled_temp_2_177( CONT_PARAMS );
static RTYPE compiled_temp_2_176( CONT_PARAMS );
static RTYPE compiled_block_2_1447( CONT_PARAMS );
static RTYPE compiled_block_2_1446( CONT_PARAMS );
static RTYPE compiled_block_2_1424( CONT_PARAMS );
static RTYPE compiled_block_2_1443( CONT_PARAMS );
static RTYPE compiled_block_2_1438( CONT_PARAMS );
static RTYPE compiled_block_2_1439( CONT_PARAMS );
static RTYPE compiled_block_2_1433( CONT_PARAMS );
static RTYPE compiled_block_2_1434( CONT_PARAMS );
static RTYPE compiled_block_2_1428( CONT_PARAMS );
static RTYPE compiled_block_2_1429( CONT_PARAMS );
static RTYPE compiled_start_2_37( CONT_PARAMS );
static RTYPE compiled_block_2_1417( CONT_PARAMS );
static RTYPE compiled_start_2_36( CONT_PARAMS );
static RTYPE compiled_block_2_1419( CONT_PARAMS );
static RTYPE compiled_block_2_1422( CONT_PARAMS );
static RTYPE compiled_block_2_1420( CONT_PARAMS );
static RTYPE compiled_block_2_1421( CONT_PARAMS );
static RTYPE compiled_temp_2_182( CONT_PARAMS );
static RTYPE compiled_temp_2_181( CONT_PARAMS );
static RTYPE compiled_start_2_180( CONT_PARAMS );
static RTYPE compiled_start_2_179( CONT_PARAMS );
static RTYPE compiled_block_2_1412( CONT_PARAMS );
static RTYPE compiled_block_2_1409( CONT_PARAMS );
static RTYPE compiled_block_2_1416( CONT_PARAMS );
static RTYPE compiled_block_2_1414( CONT_PARAMS );
static RTYPE compiled_block_2_1415( CONT_PARAMS );
static RTYPE compiled_block_2_1410( CONT_PARAMS );
static RTYPE compiled_block_2_1411( CONT_PARAMS );
static RTYPE compiled_temp_2_183( CONT_PARAMS );
static RTYPE compiled_block_2_1408( CONT_PARAMS );
static RTYPE compiled_block_2_1407( CONT_PARAMS );
static RTYPE compiled_start_2_35( CONT_PARAMS );
static RTYPE compiled_block_2_1405( CONT_PARAMS );
static RTYPE compiled_block_2_1403( CONT_PARAMS );
static RTYPE compiled_block_2_1404( CONT_PARAMS );
static RTYPE compiled_temp_2_184( CONT_PARAMS );
static RTYPE compiled_start_2_34( CONT_PARAMS );
static RTYPE compiled_block_2_1397( CONT_PARAMS );
static RTYPE compiled_temp_2_185( CONT_PARAMS );
static RTYPE compiled_start_2_33( CONT_PARAMS );
static RTYPE compiled_start_2_187( CONT_PARAMS );
static RTYPE compiled_block_2_1398( CONT_PARAMS );
static RTYPE compiled_start_2_186( CONT_PARAMS );
static RTYPE compiled_block_2_1391( CONT_PARAMS );
static RTYPE compiled_temp_2_188( CONT_PARAMS );
static RTYPE compiled_start_2_32( CONT_PARAMS );
static RTYPE compiled_start_2_190( CONT_PARAMS );
static RTYPE compiled_block_2_1392( CONT_PARAMS );
static RTYPE compiled_start_2_189( CONT_PARAMS );
static RTYPE compiled_block_2_1385( CONT_PARAMS );
static RTYPE compiled_block_2_1382( CONT_PARAMS );
static RTYPE compiled_block_2_1389( CONT_PARAMS );
static RTYPE compiled_block_2_1387( CONT_PARAMS );
static RTYPE compiled_block_2_1388( CONT_PARAMS );
static RTYPE compiled_block_2_1383( CONT_PARAMS );
static RTYPE compiled_block_2_1384( CONT_PARAMS );
static RTYPE compiled_block_2_1381( CONT_PARAMS );
static RTYPE compiled_block_2_1380( CONT_PARAMS );
static RTYPE compiled_start_2_31( CONT_PARAMS );
static RTYPE compiled_block_2_1378( CONT_PARAMS );
static RTYPE compiled_block_2_1376( CONT_PARAMS );
static RTYPE compiled_block_2_1377( CONT_PARAMS );
static RTYPE compiled_temp_2_191( CONT_PARAMS );
static RTYPE compiled_start_2_30( CONT_PARAMS );
static RTYPE compiled_block_2_1370( CONT_PARAMS );
static RTYPE compiled_temp_2_192( CONT_PARAMS );
static RTYPE compiled_start_2_29( CONT_PARAMS );
static RTYPE compiled_start_2_194( CONT_PARAMS );
static RTYPE compiled_block_2_1371( CONT_PARAMS );
static RTYPE compiled_start_2_193( CONT_PARAMS );
static RTYPE compiled_block_2_1364( CONT_PARAMS );
static RTYPE compiled_temp_2_195( CONT_PARAMS );
static RTYPE compiled_start_2_28( CONT_PARAMS );
static RTYPE compiled_start_2_197( CONT_PARAMS );
static RTYPE compiled_block_2_1365( CONT_PARAMS );
static RTYPE compiled_start_2_196( CONT_PARAMS );
static RTYPE compiled_start_2_27( CONT_PARAMS );
static RTYPE compiled_block_2_1360( CONT_PARAMS );
static RTYPE compiled_block_2_1359( CONT_PARAMS );
static RTYPE compiled_block_2_1358( CONT_PARAMS );
static RTYPE compiled_temp_2_199( CONT_PARAMS );
static RTYPE compiled_block_2_1357( CONT_PARAMS );
static RTYPE compiled_temp_2_198( CONT_PARAMS );
static RTYPE compiled_start_2_26( CONT_PARAMS );
static RTYPE compiled_start_2_25( CONT_PARAMS );
static RTYPE compiled_block_2_1351( CONT_PARAMS );
static RTYPE compiled_block_2_1353( CONT_PARAMS );
static RTYPE compiled_block_2_1352( CONT_PARAMS );
static RTYPE compiled_temp_2_201( CONT_PARAMS );
static RTYPE compiled_block_2_1350( CONT_PARAMS );
static RTYPE compiled_temp_2_200( CONT_PARAMS );
static RTYPE compiled_start_2_24( CONT_PARAMS );
static RTYPE compiled_start_2_23( CONT_PARAMS );
static RTYPE compiled_block_2_1346( CONT_PARAMS );
static RTYPE compiled_block_2_1345( CONT_PARAMS );
static RTYPE compiled_temp_2_203( CONT_PARAMS );
static RTYPE compiled_block_2_1344( CONT_PARAMS );
static RTYPE compiled_temp_2_202( CONT_PARAMS );
static RTYPE compiled_start_2_22( CONT_PARAMS );
static RTYPE compiled_start_2_21( CONT_PARAMS );
static RTYPE compiled_block_2_1339( CONT_PARAMS );
static RTYPE compiled_block_2_1340( CONT_PARAMS );
static RTYPE compiled_temp_2_205( CONT_PARAMS );
static RTYPE compiled_block_2_1338( CONT_PARAMS );
static RTYPE compiled_temp_2_204( CONT_PARAMS );
static RTYPE compiled_start_2_20( CONT_PARAMS );
static RTYPE compiled_temp_2_206( CONT_PARAMS );
static RTYPE compiled_start_2_19( CONT_PARAMS );
static RTYPE compiled_block_2_1334( CONT_PARAMS );
static RTYPE compiled_block_2_1333( CONT_PARAMS );
static RTYPE compiled_block_2_1332( CONT_PARAMS );
static RTYPE compiled_temp_2_207( CONT_PARAMS );
static RTYPE compiled_start_2_18( CONT_PARAMS );
static RTYPE compiled_temp_2_208( CONT_PARAMS );
static RTYPE compiled_start_2_17( CONT_PARAMS );
static RTYPE compiled_block_2_1328( CONT_PARAMS );
static RTYPE compiled_block_2_1327( CONT_PARAMS );
static RTYPE compiled_block_2_1326( CONT_PARAMS );
static RTYPE compiled_temp_2_209( CONT_PARAMS );
static RTYPE compiled_start_2_16( CONT_PARAMS );
static RTYPE compiled_temp_2_215( CONT_PARAMS );
static RTYPE compiled_temp_2_214( CONT_PARAMS );
static RTYPE compiled_temp_2_213( CONT_PARAMS );
static RTYPE compiled_temp_2_212( CONT_PARAMS );
static RTYPE compiled_temp_2_211( CONT_PARAMS );
static RTYPE compiled_block_2_1322( CONT_PARAMS );
static RTYPE compiled_temp_2_210( CONT_PARAMS );
static RTYPE compiled_start_2_15( CONT_PARAMS );
static RTYPE compiled_block_2_1319( CONT_PARAMS );
static RTYPE compiled_block_2_1318( CONT_PARAMS );
static RTYPE compiled_block_2_1317( CONT_PARAMS );
static RTYPE compiled_temp_2_216( CONT_PARAMS );
static RTYPE compiled_start_2_14( CONT_PARAMS );
static RTYPE compiled_block_2_1314( CONT_PARAMS );
static RTYPE compiled_block_2_1313( CONT_PARAMS );
static RTYPE compiled_block_2_1312( CONT_PARAMS );
static RTYPE compiled_temp_2_217( CONT_PARAMS );
static RTYPE compiled_start_2_13( CONT_PARAMS );
static RTYPE compiled_block_2_1305( CONT_PARAMS );
static RTYPE compiled_block_2_1303( CONT_PARAMS );
static RTYPE compiled_block_2_1308( CONT_PARAMS );
static RTYPE compiled_block_2_1309( CONT_PARAMS );
static RTYPE compiled_temp_2_219( CONT_PARAMS );
static RTYPE compiled_block_2_1306( CONT_PARAMS );
static RTYPE compiled_block_2_1307( CONT_PARAMS );
static RTYPE compiled_temp_2_218( CONT_PARAMS );
static RTYPE compiled_block_2_1304( CONT_PARAMS );
static RTYPE compiled_block_2_1302( CONT_PARAMS );
static RTYPE compiled_start_2_12( CONT_PARAMS );
static RTYPE compiled_block_2_1288( CONT_PARAMS );
static RTYPE compiled_block_2_1292( CONT_PARAMS );
static RTYPE compiled_block_2_1296( CONT_PARAMS );
static RTYPE compiled_block_2_1298( CONT_PARAMS );
static RTYPE compiled_block_2_1294( CONT_PARAMS );
static RTYPE compiled_block_2_1290( CONT_PARAMS );
static RTYPE compiled_start_2_11( CONT_PARAMS );
static RTYPE compiled_block_2_1274( CONT_PARAMS );
static RTYPE compiled_block_2_1286( CONT_PARAMS );
static RTYPE compiled_block_2_1262( CONT_PARAMS );
static RTYPE compiled_block_2_1281( CONT_PARAMS );
static RTYPE compiled_block_2_1283( CONT_PARAMS );
static RTYPE compiled_block_2_1282( CONT_PARAMS );
static RTYPE compiled_temp_2_225( CONT_PARAMS );
static RTYPE compiled_block_2_1276( CONT_PARAMS );
static RTYPE compiled_block_2_1278( CONT_PARAMS );
static RTYPE compiled_block_2_1277( CONT_PARAMS );
static RTYPE compiled_temp_2_224( CONT_PARAMS );
static RTYPE compiled_block_2_1271( CONT_PARAMS );
static RTYPE compiled_block_2_1272( CONT_PARAMS );
static RTYPE compiled_temp_2_223( CONT_PARAMS );
static RTYPE compiled_block_2_1266( CONT_PARAMS );
static RTYPE compiled_temp_2_220( CONT_PARAMS );
static RTYPE compiled_block_2_1264( CONT_PARAMS );
static RTYPE compiled_block_2_1263( CONT_PARAMS );
static RTYPE compiled_start_2_10( CONT_PARAMS );
static RTYPE compiled_start_2_222( CONT_PARAMS );
static RTYPE compiled_start_2_221( CONT_PARAMS );
static RTYPE compiled_block_2_1256( CONT_PARAMS );
static RTYPE compiled_block_2_1258( CONT_PARAMS );
static RTYPE compiled_block_2_1259( CONT_PARAMS );
static RTYPE compiled_temp_2_227( CONT_PARAMS );
static RTYPE compiled_block_2_1253( CONT_PARAMS );
static RTYPE compiled_block_2_1254( CONT_PARAMS );
static RTYPE compiled_temp_2_226( CONT_PARAMS );
static RTYPE compiled_block_2_1251( CONT_PARAMS );
static RTYPE compiled_start_2_9( CONT_PARAMS );
static RTYPE compiled_block_2_1249( CONT_PARAMS );
static RTYPE compiled_block_2_1248( CONT_PARAMS );
static RTYPE compiled_block_2_1246( CONT_PARAMS );
static RTYPE compiled_start_2_8( CONT_PARAMS );
static RTYPE compiled_start_2_7( CONT_PARAMS );
static RTYPE compiled_block_2_1244( CONT_PARAMS );
static RTYPE compiled_start_2_228( CONT_PARAMS );
static RTYPE compiled_start_2_6( CONT_PARAMS );
static RTYPE compiled_block_2_1243( CONT_PARAMS );
static RTYPE compiled_temp_2_230( CONT_PARAMS );
static RTYPE compiled_temp_2_229( CONT_PARAMS );
static RTYPE compiled_start_2_5( CONT_PARAMS );
static RTYPE compiled_block_2_1241( CONT_PARAMS );
static RTYPE compiled_temp_2_231( CONT_PARAMS );
static RTYPE compiled_start_2_4( CONT_PARAMS );
static RTYPE compiled_block_2_1238( CONT_PARAMS );
static RTYPE compiled_block_2_1199( CONT_PARAMS );
static RTYPE compiled_block_2_1125( CONT_PARAMS );
static RTYPE compiled_block_2_1021( CONT_PARAMS );
static RTYPE compiled_start_2_2( CONT_PARAMS );
static RTYPE compiled_block_2_1201( CONT_PARAMS );
static RTYPE compiled_block_2_1203( CONT_PARAMS );
static RTYPE compiled_block_2_1205( CONT_PARAMS );
static RTYPE compiled_block_2_1207( CONT_PARAMS );
static RTYPE compiled_block_2_1209( CONT_PARAMS );
static RTYPE compiled_block_2_1211( CONT_PARAMS );
static RTYPE compiled_block_2_1213( CONT_PARAMS );
static RTYPE compiled_block_2_1215( CONT_PARAMS );
static RTYPE compiled_block_2_1217( CONT_PARAMS );
static RTYPE compiled_block_2_1220( CONT_PARAMS );
static RTYPE compiled_block_2_1227( CONT_PARAMS );
static RTYPE compiled_block_2_1226( CONT_PARAMS );
static RTYPE compiled_block_2_1225( CONT_PARAMS );
static RTYPE compiled_block_2_1224( CONT_PARAMS );
static RTYPE compiled_block_2_1223( CONT_PARAMS );
static RTYPE compiled_block_2_1222( CONT_PARAMS );
static RTYPE compiled_block_2_1221( CONT_PARAMS );
static RTYPE compiled_block_2_1218( CONT_PARAMS );
static RTYPE compiled_start_2_235( CONT_PARAMS );
static RTYPE compiled_block_2_1156( CONT_PARAMS );
static RTYPE compiled_block_2_1158( CONT_PARAMS );
static RTYPE compiled_block_2_1160( CONT_PARAMS );
static RTYPE compiled_block_2_1162( CONT_PARAMS );
static RTYPE compiled_block_2_1164( CONT_PARAMS );
static RTYPE compiled_block_2_1166( CONT_PARAMS );
static RTYPE compiled_block_2_1168( CONT_PARAMS );
static RTYPE compiled_block_2_1170( CONT_PARAMS );
static RTYPE compiled_block_2_1173( CONT_PARAMS );
static RTYPE compiled_block_2_1175( CONT_PARAMS );
static RTYPE compiled_block_2_1178( CONT_PARAMS );
static RTYPE compiled_block_2_1187( CONT_PARAMS );
static RTYPE compiled_block_2_1186( CONT_PARAMS );
static RTYPE compiled_block_2_1185( CONT_PARAMS );
static RTYPE compiled_block_2_1184( CONT_PARAMS );
static RTYPE compiled_block_2_1183( CONT_PARAMS );
static RTYPE compiled_block_2_1182( CONT_PARAMS );
static RTYPE compiled_block_2_1181( CONT_PARAMS );
static RTYPE compiled_block_2_1180( CONT_PARAMS );
static RTYPE compiled_block_2_1179( CONT_PARAMS );
static RTYPE compiled_block_2_1176( CONT_PARAMS );
static RTYPE compiled_block_2_1171( CONT_PARAMS );
static RTYPE compiled_block_2_1126( CONT_PARAMS );
static RTYPE compiled_block_2_1129( CONT_PARAMS );
static RTYPE compiled_block_2_1131( CONT_PARAMS );
static RTYPE compiled_block_2_1133( CONT_PARAMS );
static RTYPE compiled_block_2_1135( CONT_PARAMS );
static RTYPE compiled_block_2_1137( CONT_PARAMS );
static RTYPE compiled_block_2_1139( CONT_PARAMS );
static RTYPE compiled_block_2_1142( CONT_PARAMS );
static RTYPE compiled_block_2_1147( CONT_PARAMS );
static RTYPE compiled_block_2_1146( CONT_PARAMS );
static RTYPE compiled_block_2_1145( CONT_PARAMS );
static RTYPE compiled_block_2_1144( CONT_PARAMS );
static RTYPE compiled_block_2_1143( CONT_PARAMS );
static RTYPE compiled_block_2_1140( CONT_PARAMS );
static RTYPE compiled_start_2_234( CONT_PARAMS );
static RTYPE compiled_block_2_1079( CONT_PARAMS );
static RTYPE compiled_block_2_1081( CONT_PARAMS );
static RTYPE compiled_block_2_1083( CONT_PARAMS );
static RTYPE compiled_block_2_1022( CONT_PARAMS );
static RTYPE compiled_block_2_1025( CONT_PARAMS );
static RTYPE compiled_block_2_1027( CONT_PARAMS );
static RTYPE compiled_block_2_1030( CONT_PARAMS );
static RTYPE compiled_block_2_1032( CONT_PARAMS );
static RTYPE compiled_block_2_1028( CONT_PARAMS );
static RTYPE compiled_start_2_233( CONT_PARAMS );
static RTYPE compiled_block_2_1116( CONT_PARAMS );
static RTYPE compiled_block_2_1118( CONT_PARAMS );
static RTYPE compiled_block_2_1120( CONT_PARAMS );
static RTYPE compiled_start_2_239( CONT_PARAMS );
static RTYPE compiled_block_2_1085( CONT_PARAMS );
static RTYPE compiled_block_2_1110( CONT_PARAMS );
static RTYPE compiled_block_2_1112( CONT_PARAMS );
static RTYPE compiled_block_2_1111( CONT_PARAMS );
static RTYPE compiled_start_2_238( CONT_PARAMS );
static RTYPE compiled_block_2_1108( CONT_PARAMS );
static RTYPE compiled_block_2_1107( CONT_PARAMS );
static RTYPE compiled_block_2_1105( CONT_PARAMS );
static RTYPE compiled_block_2_1102( CONT_PARAMS );
static RTYPE compiled_block_2_1103( CONT_PARAMS );
static RTYPE compiled_block_2_1086( CONT_PARAMS );
static RTYPE compiled_block_2_1089( CONT_PARAMS );
static RTYPE compiled_block_2_1092( CONT_PARAMS );
static RTYPE compiled_block_2_1096( CONT_PARAMS );
static RTYPE compiled_block_2_1099( CONT_PARAMS );
static RTYPE compiled_block_2_1097( CONT_PARAMS );
static RTYPE compiled_block_2_1098( CONT_PARAMS );
static RTYPE compiled_temp_2_241( CONT_PARAMS );
static RTYPE compiled_block_2_1095( CONT_PARAMS );
static RTYPE compiled_block_2_1094( CONT_PARAMS );
static RTYPE compiled_block_2_1093( CONT_PARAMS );
static RTYPE compiled_block_2_1090( CONT_PARAMS );
static RTYPE compiled_start_2_240( CONT_PARAMS );
static RTYPE compiled_block_2_1040( CONT_PARAMS );
static RTYPE compiled_block_2_1068( CONT_PARAMS );
static RTYPE compiled_block_2_1070( CONT_PARAMS );
static RTYPE compiled_block_2_1069( CONT_PARAMS );
static RTYPE compiled_start_2_237( CONT_PARAMS );
static RTYPE compiled_block_2_1066( CONT_PARAMS );
static RTYPE compiled_block_2_1065( CONT_PARAMS );
static RTYPE compiled_block_2_1063( CONT_PARAMS );
static RTYPE compiled_block_2_1060( CONT_PARAMS );
static RTYPE compiled_block_2_1061( CONT_PARAMS );
static RTYPE compiled_block_2_1041( CONT_PARAMS );
static RTYPE compiled_block_2_1044( CONT_PARAMS );
static RTYPE compiled_block_2_1047( CONT_PARAMS );
static RTYPE compiled_block_2_1054( CONT_PARAMS );
static RTYPE compiled_block_2_1057( CONT_PARAMS );
static RTYPE compiled_block_2_1055( CONT_PARAMS );
static RTYPE compiled_block_2_1056( CONT_PARAMS );
static RTYPE compiled_temp_2_243( CONT_PARAMS );
static RTYPE compiled_block_2_1053( CONT_PARAMS );
static RTYPE compiled_block_2_1052( CONT_PARAMS );
static RTYPE compiled_block_2_1051( CONT_PARAMS );
static RTYPE compiled_block_2_1050( CONT_PARAMS );
static RTYPE compiled_block_2_1049( CONT_PARAMS );
static RTYPE compiled_block_2_1048( CONT_PARAMS );
static RTYPE compiled_block_2_1045( CONT_PARAMS );
static RTYPE compiled_start_2_242( CONT_PARAMS );
static RTYPE compiled_block_2_1034( CONT_PARAMS );
static RTYPE compiled_block_2_1036( CONT_PARAMS );
static RTYPE compiled_block_2_1038( CONT_PARAMS );
static RTYPE compiled_start_2_236( CONT_PARAMS );
static RTYPE compiled_block_2_1003( CONT_PARAMS );
static RTYPE compiled_block_2_1005( CONT_PARAMS );
static RTYPE compiled_block_2_1007( CONT_PARAMS );
static RTYPE compiled_block_2_1009( CONT_PARAMS );
static RTYPE compiled_block_2_1012( CONT_PARAMS );
static RTYPE compiled_block_2_1015( CONT_PARAMS );
static RTYPE compiled_block_2_1014( CONT_PARAMS );
static RTYPE compiled_block_2_1013( CONT_PARAMS );
static RTYPE compiled_block_2_1010( CONT_PARAMS );
static RTYPE compiled_start_2_232( CONT_PARAMS );
static RTYPE compiled_start_2_1( CONT_PARAMS );

static RTYPE compiled_start_2_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 2 ); /*  reverse-list->vector~1ayXVW~24406 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 3 ); /*  list->vector~1ayXVW~24405 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 4 ); /*  reverse-vector->list~1ayXVW~24404 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 5 ); /*  vector->list~1ayXVW~24403 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 6 ); /*  vector-reverse!~1ayXVW~24402 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 7 ); /*  vector-reverse-copy!~1ayXVW~24401 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 8 ); /*  vector-copy!~1ayXVW~24400 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 9 ); /*  vector-fill!~1ayXVW~24399 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 10 ); /*  vector-swap!~1ayXVW~24398 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 11 ); /*  vector-every~1ayXVW~24397 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 12 ); /*  vector-any~1ayXVW~24396 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 13 ); /*  vector-binary-search~1ayXVW~24395 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 14 ); /*  vector-index/skip-right~1ayXVW~24394 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 15 ); /*  vector-skip-right~1ayXVW~24393 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 16 ); /*  vector-index-right~1ayXVW~24392 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 17 ); /*  vector-index/skip~1ayXVW~24391 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 18 ); /*  vector-skip~1ayXVW~24390 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 19 ); /*  vector-index~1ayXVW~24389 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 20 ); /*  vector-count~1ayXVW~24388 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 21 ); /*  vector-for-each~1ayXVW~24387 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 22 ); /*  vector-map!~1ayXVW~24386 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 23 ); /*  vector-map~1ayXVW~24385 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 24 ); /*  vector-fold-right~1ayXVW~24384 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 25 ); /*  vector-fold~1ayXVW~24383 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 26 ); /*  binary-vector=~1ayXVW~24382 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 27 ); /*  vector=~1ayXVW~24381 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 28 ); /*  vector-empty?~1ayXVW~24380 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 29 ); /*  vector-concatenate:aux~1ayXVW~24379 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 30 ); /*  vector-concatenate~1ayXVW~24378 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 31 ); /*  vector-append~1ayXVW~24377 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 32 ); /*  vector-reverse-copy~1ayXVW~24376 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 33 ); /*  vector-copy:parse-args~1ayXVW~24375 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 34 ); /*  vector-copy~1ayXVW~24374 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 35 ); /*  vector-unfold-right~1ayXVW~24373 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 36 ); /*  vector-unfold~1ayXVW~24372 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 37 ); /*  %vector-map2+!~1ayXVW~24371 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 38 ); /*  %vector-map1!~1ayXVW~24370 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 39 ); /*  %vector-fold2+~1ayXVW~24369 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 40 ); /*  %vector-fold1~1ayXVW~24368 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 41 ); /*  %vector-reverse!~1ayXVW~24367 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 42 ); /*  %vector-reverse-copy!~1ayXVW~24366 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 43 ); /*  %vector-copy!~1ayXVW~24365 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 44 ); /*  %smallest-length~1ayXVW~24364 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 45 ); /*  vector-parse-start+end~1ayXVW~24330 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 46 ); /*  check-indices~1ayXVW~24329 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 47 ); /*  check-index~1ayXVW~24328 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 48 ); /*  check-type~1ayXVW~24327 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 49 ); /*  vectors-ref~1ayXVW~24326 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 50 ); /*  unspecified-value~1ayXVW~24325 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 51 ); /*  between?~1ayXVW~24324 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 52 ); /*  nonneg-int?~1ayXVW~24323 */
  twobit_lambda( compiled_start_2_1, 54, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_2_2, 56, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_2_3, 58, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 59 );
  twobit_setreg( 1 );
  twobit_const( 60 );
  twobit_setreg( 3 );
  twobit_const( 61 );
  twobit_setreg( 4 );
  twobit_const( 62 );
  twobit_setreg( 5 );
  twobit_const( 63 );
  twobit_setreg( 8 );
  twobit_global( 64 ); /* ex:make-library */
  twobit_setrtn( 1925, compiled_block_2_1925 );
  twobit_invoke( 8 );
  twobit_label( 1925, compiled_block_2_1925 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 65 ); /* ex:register-library! */
  twobit_setrtn( 1926, compiled_block_2_1926 );
  twobit_invoke( 1 );
  twobit_label( 1926, compiled_block_2_1926 );
  twobit_load( 0, 0 );
  twobit_global( 66 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* ex:uncompress */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_232, 2, 0 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1021, compiled_block_2_1021 );
  twobit_invoke( 2 );
  twobit_label( 1021, compiled_block_2_1021 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_2_233, 6, 0 );
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1125, compiled_block_2_1125 );
  twobit_invoke( 2 );
  twobit_label( 1125, compiled_block_2_1125 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_2_234, 9, 0 );
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1199, compiled_block_2_1199 );
  twobit_invoke( 2 );
  twobit_label( 1199, compiled_block_2_1199 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_2_235, 12, 0 );
  twobit_setreg( 2 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1238, compiled_block_2_1238 );
  twobit_invoke( 2 );
  twobit_label( 1238, compiled_block_2_1238 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_232( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1003, compiled_block_2_1003 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1005, compiled_block_2_1005 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1007, compiled_block_2_1007 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1009, compiled_block_2_1009 ); /* internal:branchf-pair? */
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 7 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1010, compiled_block_2_1010 );
  twobit_invoke( 1 );
  twobit_label( 1010, compiled_block_2_1010 );
  twobit_load( 0, 0 );
  twobit_branchf( 1012, compiled_block_2_1012 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1013, compiled_block_2_1013 );
  twobit_invoke( 5 );
  twobit_label( 1013, compiled_block_2_1013 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1014, compiled_block_2_1014 );
  twobit_invoke( 5 );
  twobit_label( 1014, compiled_block_2_1014 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 3, 2 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1015, compiled_block_2_1015 );
  twobit_invoke( 5 );
  twobit_label( 1015, compiled_block_2_1015 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1012, compiled_block_2_1012 );
  twobit_load( 1, 7 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_pop( 7 );
  twobit_invoke( 1 );
  twobit_label( 1009, compiled_block_2_1009 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1007, compiled_block_2_1007 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1005, compiled_block_2_1005 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1003, compiled_block_2_1003 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_233( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1025, compiled_block_2_1025 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1027, compiled_block_2_1027 ); /* internal:branchf-pair? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1028, compiled_block_2_1028 );
  twobit_invoke( 1 );
  twobit_label( 1028, compiled_block_2_1028 );
  twobit_load( 0, 0 );
  twobit_branchf( 1030, compiled_block_2_1030 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1032, compiled_block_2_1032 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 4 );
  twobit_lambda( compiled_start_2_236, 3, 0 );
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 4, 3 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_2_237, 5, 3 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_load( 2, 4 );
  twobit_global( 6 ); /* ex:map-while */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 1032, compiled_block_2_1032 );
  twobit_load( 1, 3 );
  twobit_pop( 4 );
  twobit_branch( 1022, compiled_block_2_1022 );
  twobit_label( 1030, compiled_block_2_1030 );
  twobit_load( 1, 3 );
  twobit_pop( 4 );
  twobit_branch( 1022, compiled_block_2_1022 );
  twobit_label( 1027, compiled_block_2_1027 );
  twobit_branch( 1022, compiled_block_2_1022 );
  twobit_label( 1025, compiled_block_2_1025 );
  twobit_label( 1022, compiled_block_2_1022 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1079, compiled_block_2_1079 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1081, compiled_block_2_1081 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1083, compiled_block_2_1083 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_2_238, 8, 3 );
  twobit_setreg( 3 );
  twobit_lambda( compiled_start_2_239, 10, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 6 ); /* ex:map-while */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_label( 1083, compiled_block_2_1083 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1081, compiled_block_2_1081 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1079, compiled_block_2_1079 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_236( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1034, compiled_block_2_1034 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1036, compiled_block_2_1036 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1038, compiled_block_2_1038 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_return();
  twobit_label( 1038, compiled_block_2_1038 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1036, compiled_block_2_1036 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1034, compiled_block_2_1034 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_237( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1040, compiled_block_2_1040 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_242, 2, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1069, compiled_block_2_1069 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_skip( 1068, compiled_block_2_1068 );
  twobit_label( 1069, compiled_block_2_1069 );
  twobit_movereg( 1, 3 );
  twobit_global( 4 ); /* map */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* list */
  twobit_setreg( 2 );
  twobit_global( 6 ); /* apply */
  twobit_setrtn( 1070, compiled_block_2_1070 );
  twobit_invoke( 3 );
  twobit_label( 1070, compiled_block_2_1070 );
  twobit_load( 0, 0 );
  twobit_label( 1068, compiled_block_2_1068 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1040, compiled_block_2_1040 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_jump( 1, 1022, compiled_block_2_1022 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_242( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 1, 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1044, compiled_block_2_1044 ); /* internal:branchf-pair? */
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 5 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1045, compiled_block_2_1045 );
  twobit_invoke( 1 );
  twobit_label( 1045, compiled_block_2_1045 );
  twobit_load( 0, 0 );
  twobit_branchf( 1047, compiled_block_2_1047 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1048, compiled_block_2_1048 );
  twobit_invoke( 5 );
  twobit_label( 1048, compiled_block_2_1048 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1049, compiled_block_2_1049 );
  twobit_invoke( 5 );
  twobit_label( 1049, compiled_block_2_1049 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1050, compiled_block_2_1050 );
  twobit_invoke( 5 );
  twobit_label( 1050, compiled_block_2_1050 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1051, compiled_block_2_1051 );
  twobit_invoke( 5 );
  twobit_label( 1051, compiled_block_2_1051 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 3, 2 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_load( 1, 4 );
  twobit_global( 8 ); /* length */
  twobit_setrtn( 1052, compiled_block_2_1052 );
  twobit_invoke( 1 );
  twobit_label( 1052, compiled_block_2_1052 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 5 );
  twobit_global( 8 ); /* length */
  twobit_setrtn( 1053, compiled_block_2_1053 );
  twobit_invoke( 1 );
  twobit_label( 1053, compiled_block_2_1053 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_branchf_623( 4, 243, compiled_temp_2_243, 1055, compiled_block_2_1055 ); /* internal:branchf-= */
  twobit_load( 1, 4 );
  twobit_load( 2, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_setrtn( 1056, compiled_block_2_1056 );
  twobit_branch( 1041, compiled_block_2_1041 );
  twobit_label( 1056, compiled_block_2_1056 );
  twobit_load( 0, 0 );
  twobit_skip( 1054, compiled_block_2_1054 );
  twobit_label( 1055, compiled_block_2_1055 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_const( 10 );
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_global( 12 ); /* ex:syntax-violation */
  twobit_setrtn( 1057, compiled_block_2_1057 );
  twobit_invoke( 4 );
  twobit_label( 1057, compiled_block_2_1057 );
  twobit_load( 0, 0 );
  twobit_label( 1054, compiled_block_2_1054 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 1047, compiled_block_2_1047 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_pop( 8 );
  twobit_jump( 2, 1022, compiled_block_2_1022 );
  twobit_label( 1044, compiled_block_2_1044 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_jump( 2, 1022, compiled_block_2_1022 );
  twobit_label( 1041, compiled_block_2_1041 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1061, compiled_block_2_1061 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1060, compiled_block_2_1060 );
  twobit_label( 1061, compiled_block_2_1061 );
  twobit_reg( 2 );
  twobit_op1_10(); /* null? */
  twobit_label( 1060, compiled_block_2_1060 );
  twobit_branchf( 1063, compiled_block_2_1063 );
  twobit_movereg( 3, 1 );
  twobit_global( 13 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1063, compiled_block_2_1063 );
  twobit_reg_op1_check_652(reg(2),1065,compiled_block_2_1065); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(1),1066,compiled_block_2_1066); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op2_58( 30 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 31 );
  twobit_op2_58( 4 ); /* cons */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_branch( 1041, compiled_block_2_1041 );
  twobit_label( 1065, compiled_block_2_1065 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 1066, compiled_block_2_1066 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_238( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1085, compiled_block_2_1085 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_240, 2, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1111, compiled_block_2_1111 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_skip( 1110, compiled_block_2_1110 );
  twobit_label( 1111, compiled_block_2_1111 );
  twobit_movereg( 1, 3 );
  twobit_global( 4 ); /* map */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* list */
  twobit_setreg( 2 );
  twobit_global( 6 ); /* apply */
  twobit_setrtn( 1112, compiled_block_2_1112 );
  twobit_invoke( 3 );
  twobit_label( 1112, compiled_block_2_1112 );
  twobit_load( 0, 0 );
  twobit_label( 1110, compiled_block_2_1110 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1085, compiled_block_2_1085 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_240( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 1, 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1089, compiled_block_2_1089 ); /* internal:branchf-pair? */
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 4 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1090, compiled_block_2_1090 );
  twobit_invoke( 1 );
  twobit_label( 1090, compiled_block_2_1090 );
  twobit_load( 0, 0 );
  twobit_branchf( 1092, compiled_block_2_1092 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1093, compiled_block_2_1093 );
  twobit_invoke( 5 );
  twobit_label( 1093, compiled_block_2_1093 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 3, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_load( 1, 3 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1094, compiled_block_2_1094 );
  twobit_invoke( 1 );
  twobit_label( 1094, compiled_block_2_1094 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 4 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1095, compiled_block_2_1095 );
  twobit_invoke( 1 );
  twobit_label( 1095, compiled_block_2_1095 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_branchf_623( 4, 241, compiled_temp_2_241, 1097, compiled_block_2_1097 ); /* internal:branchf-= */
  twobit_load( 1, 3 );
  twobit_load( 2, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_setrtn( 1098, compiled_block_2_1098 );
  twobit_branch( 1086, compiled_block_2_1086 );
  twobit_label( 1098, compiled_block_2_1098 );
  twobit_load( 0, 0 );
  twobit_skip( 1096, compiled_block_2_1096 );
  twobit_label( 1097, compiled_block_2_1097 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_global( 10 ); /* ex:syntax-violation */
  twobit_setrtn( 1099, compiled_block_2_1099 );
  twobit_invoke( 4 );
  twobit_label( 1099, compiled_block_2_1099 );
  twobit_load( 0, 0 );
  twobit_label( 1096, compiled_block_2_1096 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_lexical( 1, 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_lexical( 1, 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1092, compiled_block_2_1092 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 1089, compiled_block_2_1089 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1086, compiled_block_2_1086 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1103, compiled_block_2_1103 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1102, compiled_block_2_1102 );
  twobit_label( 1103, compiled_block_2_1103 );
  twobit_reg( 2 );
  twobit_op1_10(); /* null? */
  twobit_label( 1102, compiled_block_2_1102 );
  twobit_branchf( 1105, compiled_block_2_1105 );
  twobit_movereg( 3, 1 );
  twobit_global( 12 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1105, compiled_block_2_1105 );
  twobit_reg_op1_check_652(reg(2),1107,compiled_block_2_1107); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(1),1108,compiled_block_2_1108); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op2_58( 30 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 31 );
  twobit_op2_58( 4 ); /* cons */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_branch( 1086, compiled_block_2_1086 );
  twobit_label( 1107, compiled_block_2_1107 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 1108, compiled_block_2_1108 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_239( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1116, compiled_block_2_1116 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1118, compiled_block_2_1118 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1120, compiled_block_2_1120 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_return();
  twobit_label( 1120, compiled_block_2_1120 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1118, compiled_block_2_1118 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1116, compiled_block_2_1116 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_234( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1129, compiled_block_2_1129 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1131, compiled_block_2_1131 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1133, compiled_block_2_1133 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1135, compiled_block_2_1135 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_op1_branchf_610( 1137, compiled_block_2_1137 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1139, compiled_block_2_1139 ); /* internal:branchf-pair? */
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 7 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1140, compiled_block_2_1140 );
  twobit_invoke( 1 );
  twobit_label( 1140, compiled_block_2_1140 );
  twobit_load( 0, 0 );
  twobit_branchf( 1142, compiled_block_2_1142 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1143, compiled_block_2_1143 );
  twobit_invoke( 5 );
  twobit_label( 1143, compiled_block_2_1143 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1144, compiled_block_2_1144 );
  twobit_invoke( 5 );
  twobit_label( 1144, compiled_block_2_1144 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 3, 2 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1145, compiled_block_2_1145 );
  twobit_invoke( 5 );
  twobit_label( 1145, compiled_block_2_1145 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1146, compiled_block_2_1146 );
  twobit_invoke( 5 );
  twobit_label( 1146, compiled_block_2_1146 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 4 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 4 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1147, compiled_block_2_1147 );
  twobit_invoke( 5 );
  twobit_label( 1147, compiled_block_2_1147 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1142, compiled_block_2_1142 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1126, compiled_block_2_1126 );
  twobit_label( 1139, compiled_block_2_1139 );
  twobit_branch( 1126, compiled_block_2_1126 );
  twobit_label( 1137, compiled_block_2_1137 );
  twobit_branch( 1126, compiled_block_2_1126 );
  twobit_label( 1135, compiled_block_2_1135 );
  twobit_branch( 1126, compiled_block_2_1126 );
  twobit_label( 1133, compiled_block_2_1133 );
  twobit_branch( 1126, compiled_block_2_1126 );
  twobit_label( 1131, compiled_block_2_1131 );
  twobit_branch( 1126, compiled_block_2_1126 );
  twobit_label( 1129, compiled_block_2_1129 );
  twobit_label( 1126, compiled_block_2_1126 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1156, compiled_block_2_1156 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1158, compiled_block_2_1158 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1160, compiled_block_2_1160 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1162, compiled_block_2_1162 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_branchf_611( 1164, compiled_block_2_1164 ); /* internal:branchf-pair? */
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 30 );
  twobit_op1_branchf_611( 1166, compiled_block_2_1166 ); /* internal:branchf-pair? */
  twobit_reg( 30 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 29 );
  twobit_reg( 30 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 30 );
  twobit_reg( 30 );
  twobit_op1_branchf_611( 1168, compiled_block_2_1168 ); /* internal:branchf-pair? */
  twobit_reg( 30 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 28 );
  twobit_reg( 30 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1170, compiled_block_2_1170 ); /* internal:branchf-null? */
  twobit_save( 12 );
  twobit_store( 0, 0 );
  twobit_store( 1, 12 );
  twobit_store( 2, 2 );
  twobit_store( 3, 8 );
  twobit_store( 4, 1 );
  twobit_store( 28, 5 );
  twobit_store( 29, 6 );
  twobit_reg( 31 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 7 );
  twobit_movereg( 31, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1171, compiled_block_2_1171 );
  twobit_invoke( 1 );
  twobit_label( 1171, compiled_block_2_1171 );
  twobit_load( 0, 0 );
  twobit_branchf( 1173, compiled_block_2_1173 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1175, compiled_block_2_1175 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1176, compiled_block_2_1176 );
  twobit_invoke( 1 );
  twobit_label( 1176, compiled_block_2_1176 );
  twobit_load( 0, 0 );
  twobit_branchf( 1178, compiled_block_2_1178 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1179, compiled_block_2_1179 );
  twobit_invoke( 5 );
  twobit_label( 1179, compiled_block_2_1179 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1180, compiled_block_2_1180 );
  twobit_invoke( 5 );
  twobit_label( 1180, compiled_block_2_1180 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_load( 3, 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_stack( 5 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_stack( 6 );
  twobit_op2_58( 1 ); /* cons */
  twobit_load( 3, 7 );
  twobit_op2_58( 3 ); /* cons */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1181, compiled_block_2_1181 );
  twobit_invoke( 5 );
  twobit_label( 1181, compiled_block_2_1181 );
  twobit_load( 0, 0 );
  twobit_load( 3, 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1182, compiled_block_2_1182 );
  twobit_invoke( 5 );
  twobit_label( 1182, compiled_block_2_1182 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1183, compiled_block_2_1183 );
  twobit_invoke( 5 );
  twobit_label( 1183, compiled_block_2_1183 );
  twobit_load( 0, 0 );
  twobit_load( 3, 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1184, compiled_block_2_1184 );
  twobit_invoke( 5 );
  twobit_label( 1184, compiled_block_2_1184 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1185, compiled_block_2_1185 );
  twobit_invoke( 5 );
  twobit_label( 1185, compiled_block_2_1185 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1186, compiled_block_2_1186 );
  twobit_invoke( 5 );
  twobit_label( 1186, compiled_block_2_1186 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 3, 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 7 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 7 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1187, compiled_block_2_1187 );
  twobit_invoke( 5 );
  twobit_label( 1187, compiled_block_2_1187 );
  twobit_load( 0, 0 );
  twobit_load( 3, 7 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 12 );
  twobit_return();
  twobit_label( 1178, compiled_block_2_1178 );
  twobit_load( 1, 12 );
  twobit_global( 17 ); /* ex:invalid-form */
  twobit_pop( 12 );
  twobit_invoke( 1 );
  twobit_label( 1175, compiled_block_2_1175 );
  twobit_load( 1, 12 );
  twobit_global( 17 ); /* ex:invalid-form */
  twobit_pop( 12 );
  twobit_invoke( 1 );
  twobit_label( 1173, compiled_block_2_1173 );
  twobit_load( 1, 12 );
  twobit_global( 17 ); /* ex:invalid-form */
  twobit_pop( 12 );
  twobit_invoke( 1 );
  twobit_label( 1170, compiled_block_2_1170 );
  twobit_global( 17 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1168, compiled_block_2_1168 );
  twobit_global( 17 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1166, compiled_block_2_1166 );
  twobit_global( 17 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1164, compiled_block_2_1164 );
  twobit_global( 17 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1162, compiled_block_2_1162 );
  twobit_global( 17 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1160, compiled_block_2_1160 );
  twobit_global( 17 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1158, compiled_block_2_1158 );
  twobit_global( 17 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1156, compiled_block_2_1156 );
  twobit_global( 17 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_235( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1201, compiled_block_2_1201 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1203, compiled_block_2_1203 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1205, compiled_block_2_1205 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1207, compiled_block_2_1207 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1209, compiled_block_2_1209 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 30 );
  twobit_op1_branchf_611( 1211, compiled_block_2_1211 ); /* internal:branchf-pair? */
  twobit_reg( 30 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 29 );
  twobit_reg( 30 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 30 );
  twobit_reg( 30 );
  twobit_op1_branchf_611( 1213, compiled_block_2_1213 ); /* internal:branchf-pair? */
  twobit_reg( 30 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 28 );
  twobit_reg( 30 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1215, compiled_block_2_1215 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1217, compiled_block_2_1217 ); /* internal:branchf-pair? */
  twobit_save( 13 );
  twobit_store( 0, 0 );
  twobit_store( 1, 13 );
  twobit_store( 2, 2 );
  twobit_store( 3, 1 );
  twobit_store( 28, 5 );
  twobit_store( 29, 6 );
  twobit_store( 31, 9 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_store( 30, 8 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1218, compiled_block_2_1218 );
  twobit_invoke( 1 );
  twobit_label( 1218, compiled_block_2_1218 );
  twobit_load( 0, 0 );
  twobit_branchf( 1220, compiled_block_2_1220 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1221, compiled_block_2_1221 );
  twobit_invoke( 5 );
  twobit_label( 1221, compiled_block_2_1221 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1222, compiled_block_2_1222 );
  twobit_invoke( 5 );
  twobit_label( 1222, compiled_block_2_1222 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1223, compiled_block_2_1223 );
  twobit_invoke( 5 );
  twobit_label( 1223, compiled_block_2_1223 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1224, compiled_block_2_1224 );
  twobit_invoke( 5 );
  twobit_label( 1224, compiled_block_2_1224 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_load( 2, 7 );
  twobit_stack( 8 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1225, compiled_block_2_1225 );
  twobit_invoke( 5 );
  twobit_label( 1225, compiled_block_2_1225 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1226, compiled_block_2_1226 );
  twobit_invoke( 5 );
  twobit_label( 1226, compiled_block_2_1226 );
  twobit_load( 0, 0 );
  twobit_load( 3, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 5 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 5 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1227, compiled_block_2_1227 );
  twobit_invoke( 5 );
  twobit_label( 1227, compiled_block_2_1227 );
  twobit_load( 0, 0 );
  twobit_load( 3, 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 13 );
  twobit_return();
  twobit_label( 1220, compiled_block_2_1220 );
  twobit_load( 1, 13 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_pop( 13 );
  twobit_invoke( 1 );
  twobit_label( 1217, compiled_block_2_1217 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1215, compiled_block_2_1215 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1213, compiled_block_2_1213 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1211, compiled_block_2_1211 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1209, compiled_block_2_1209 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1207, compiled_block_2_1207 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1205, compiled_block_2_1205 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1203, compiled_block_2_1203 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1201, compiled_block_2_1201 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 2 ); /*  reverse-list->vector~1ayXVW~24406 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 3 ); /*  list->vector~1ayXVW~24405 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 4 ); /*  reverse-vector->list~1ayXVW~24404 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 5 ); /*  vector->list~1ayXVW~24403 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 6 ); /*  vector-reverse!~1ayXVW~24402 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 7 ); /*  vector-reverse-copy!~1ayXVW~24401 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 8 ); /*  vector-copy!~1ayXVW~24400 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 9 ); /*  vector-fill!~1ayXVW~24399 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 10 ); /*  vector-swap!~1ayXVW~24398 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 11 ); /*  vector-every~1ayXVW~24397 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 12 ); /*  vector-any~1ayXVW~24396 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 13 ); /*  vector-binary-search~1ayXVW~24395 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 14 ); /*  vector-index/skip-right~1ayXVW~24394 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 15 ); /*  vector-skip-right~1ayXVW~24393 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 16 ); /*  vector-index-right~1ayXVW~24392 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 17 ); /*  vector-index/skip~1ayXVW~24391 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 18 ); /*  vector-skip~1ayXVW~24390 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 19 ); /*  vector-index~1ayXVW~24389 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 20 ); /*  vector-count~1ayXVW~24388 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 21 ); /*  vector-for-each~1ayXVW~24387 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 22 ); /*  vector-map!~1ayXVW~24386 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 23 ); /*  vector-map~1ayXVW~24385 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 24 ); /*  vector-fold-right~1ayXVW~24384 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 25 ); /*  vector-fold~1ayXVW~24383 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 26 ); /*  binary-vector=~1ayXVW~24382 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 27 ); /*  vector=~1ayXVW~24381 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 28 ); /*  vector-empty?~1ayXVW~24380 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 29 ); /*  vector-concatenate:aux~1ayXVW~24379 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 30 ); /*  vector-concatenate~1ayXVW~24378 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 31 ); /*  vector-append~1ayXVW~24377 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 32 ); /*  vector-reverse-copy~1ayXVW~24376 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 33 ); /*  vector-copy:parse-args~1ayXVW~24375 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 34 ); /*  vector-copy~1ayXVW~24374 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 35 ); /*  vector-unfold-right~1ayXVW~24373 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 36 ); /*  vector-unfold~1ayXVW~24372 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 37 ); /*  %vector-map2+!~1ayXVW~24371 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 38 ); /*  %vector-map1!~1ayXVW~24370 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 39 ); /*  %vector-fold2+~1ayXVW~24369 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 40 ); /*  %vector-fold1~1ayXVW~24368 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 41 ); /*  %vector-reverse!~1ayXVW~24367 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 42 ); /*  %vector-reverse-copy!~1ayXVW~24366 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 43 ); /*  %vector-copy!~1ayXVW~24365 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 44 ); /*  %smallest-length~1ayXVW~24364 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 45 ); /*  vector-parse-start+end~1ayXVW~24330 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 46 ); /*  check-indices~1ayXVW~24329 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 47 ); /*  check-index~1ayXVW~24328 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 48 ); /*  check-type~1ayXVW~24327 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 49 ); /*  vectors-ref~1ayXVW~24326 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 50 ); /*  unspecified-value~1ayXVW~24325 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 51 ); /*  between?~1ayXVW~24324 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 52 ); /*  nonneg-int?~1ayXVW~24323 */
  twobit_lambda( compiled_start_2_4, 54, 0 );
  twobit_setglbl( 55 ); /*  nonneg-int?~1ayXVW~24323 */
  twobit_lambda( compiled_start_2_5, 57, 0 );
  twobit_setglbl( 58 ); /*  between?~1ayXVW~24324 */
  twobit_lambda( compiled_start_2_6, 60, 0 );
  twobit_setglbl( 61 ); /*  unspecified-value~1ayXVW~24325 */
  twobit_lambda( compiled_start_2_7, 63, 0 );
  twobit_setglbl( 49 ); /*  vectors-ref~1ayXVW~24326 */
  twobit_lambda( compiled_start_2_8, 65, 0 );
  twobit_setglbl( 48 ); /*  check-type~1ayXVW~24327 */
  twobit_lambda( compiled_start_2_9, 67, 0 );
  twobit_setglbl( 47 ); /*  check-index~1ayXVW~24328 */
  twobit_lambda( compiled_start_2_10, 69, 0 );
  twobit_setglbl( 46 ); /*  check-indices~1ayXVW~24329 */
  twobit_lambda( compiled_start_2_11, 71, 0 );
  twobit_setglbl( 45 ); /*  vector-parse-start+end~1ayXVW~24330 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_12, 73, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setglbl( 44 ); /*  %smallest-length~1ayXVW~24364 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_13, 75, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_2_14, 77, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op2_84( 31 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_movereg( 3, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_15, 79, 2 );
  twobit_setglbl( 43 ); /*  %vector-copy!~1ayXVW~24365 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_16, 81, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_17, 83, 1 );
  twobit_setglbl( 42 ); /*  %vector-reverse-copy!~1ayXVW~24366 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_18, 85, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_19, 87, 1 );
  twobit_setglbl( 41 ); /*  %vector-reverse!~1ayXVW~24367 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_20, 89, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_21, 91, 1 );
  twobit_setglbl( 40 ); /*  %vector-fold1~1ayXVW~24368 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_22, 93, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_23, 95, 1 );
  twobit_setglbl( 39 ); /*  %vector-fold2+~1ayXVW~24369 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_24, 97, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_25, 99, 1 );
  twobit_setglbl( 38 ); /*  %vector-map1!~1ayXVW~24370 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_26, 101, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_27, 103, 1 );
  twobit_setglbl( 37 ); /*  %vector-map2+!~1ayXVW~24371 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_28, 105, 1 );
  twobit_setreg( 31 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_2_29, 107, 1 );
  twobit_setreg( 30 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_2_30, 109, 1 );
  twobit_setreg( 29 );
  twobit_reg( 3 );
  twobit_op2_84( 29 ); /* cell-set! */
  twobit_reg( 2 );
  twobit_op2_84( 30 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op2_84( 31 ); /* cell-set! */
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_31, 111, 3 );
  twobit_setglbl( 36 ); /*  vector-unfold~1ayXVW~24372 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_32, 113, 1 );
  twobit_setreg( 31 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_2_33, 115, 1 );
  twobit_setreg( 30 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_2_34, 117, 1 );
  twobit_setreg( 29 );
  twobit_reg( 3 );
  twobit_op2_84( 29 ); /* cell-set! */
  twobit_reg( 2 );
  twobit_op2_84( 30 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op2_84( 31 ); /* cell-set! */
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_35, 119, 3 );
  twobit_setglbl( 35 ); /*  vector-unfold-right~1ayXVW~24373 */
  twobit_lambda( compiled_start_2_36, 121, 0 );
  twobit_setglbl( 34 ); /*  vector-copy~1ayXVW~24374 */
  twobit_lambda( compiled_start_2_37, 123, 0 );
  twobit_setglbl( 33 ); /*  vector-copy:parse-args~1ayXVW~24375 */
  twobit_lambda( compiled_start_2_38, 125, 0 );
  twobit_setglbl( 32 ); /*  vector-reverse-copy~1ayXVW~24376 */
  twobit_lambda( compiled_start_2_39, 127, 0 );
  twobit_setglbl( 31 ); /*  vector-append~1ayXVW~24377 */
  twobit_lambda( compiled_start_2_40, 129, 0 );
  twobit_setglbl( 30 ); /*  vector-concatenate~1ayXVW~24378 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_41, 131, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_2_42, 133, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op2_84( 31 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_movereg( 3, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_43, 135, 2 );
  twobit_setglbl( 29 ); /*  vector-concatenate:aux~1ayXVW~24379 */
  twobit_lambda( compiled_start_2_44, 137, 0 );
  twobit_setglbl( 28 ); /*  vector-empty?~1ayXVW~24380 */
  twobit_lambda( compiled_start_2_45, 139, 0 );
  twobit_setglbl( 27 ); /*  vector=~1ayXVW~24381 */
  twobit_lambda( compiled_start_2_46, 141, 0 );
  twobit_setglbl( 26 ); /*  binary-vector=~1ayXVW~24382 */
  twobit_lambda( compiled_start_2_47, 143, 0 );
  twobit_setglbl( 25 ); /*  vector-fold~1ayXVW~24383 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_2_48, 145, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_49, 147, 1 );
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op2_84( 31 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_2_50, 149, 2 );
  twobit_setglbl( 24 ); /*  vector-fold-right~1ayXVW~24384 */
  twobit_lambda( compiled_start_2_51, 151, 0 );
  twobit_setglbl( 23 ); /*  vector-map~1ayXVW~24385 */
  twobit_lambda( compiled_start_2_52, 153, 0 );
  twobit_setglbl( 22 ); /*  vector-map!~1ayXVW~24386 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_2_53, 155, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_54, 157, 1 );
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op2_84( 31 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_2_55, 159, 2 );
  twobit_setglbl( 21 ); /*  vector-for-each~1ayXVW~24387 */
  twobit_lambda( compiled_start_2_56, 161, 0 );
  twobit_setglbl( 20 ); /*  vector-count~1ayXVW~24388 */
  twobit_lambda( compiled_start_2_57, 163, 0 );
  twobit_setglbl( 19 ); /*  vector-index~1ayXVW~24389 */
  twobit_lambda( compiled_start_2_58, 165, 0 );
  twobit_setglbl( 18 ); /*  vector-skip~1ayXVW~24390 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_2_59, 167, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_60, 169, 1 );
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op2_84( 31 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_2_61, 171, 2 );
  twobit_setglbl( 17 ); /*  vector-index/skip~1ayXVW~24391 */
  twobit_lambda( compiled_start_2_62, 173, 0 );
  twobit_setglbl( 16 ); /*  vector-index-right~1ayXVW~24392 */
  twobit_lambda( compiled_start_2_63, 175, 0 );
  twobit_setglbl( 15 ); /*  vector-skip-right~1ayXVW~24393 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_2_64, 177, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_65, 179, 1 );
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op2_84( 31 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_2_66, 181, 2 );
  twobit_setglbl( 14 ); /*  vector-index/skip-right~1ayXVW~24394 */
  twobit_lambda( compiled_start_2_67, 183, 0 );
  twobit_setglbl( 13 ); /*  vector-binary-search~1ayXVW~24395 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_2_68, 185, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_69, 187, 1 );
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op2_84( 31 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_2_70, 189, 2 );
  twobit_setglbl( 12 ); /*  vector-any~1ayXVW~24396 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_2_71, 191, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_72, 193, 1 );
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op2_84( 31 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_2_73, 195, 2 );
  twobit_setglbl( 11 ); /*  vector-every~1ayXVW~24397 */
  twobit_lambda( compiled_start_2_74, 197, 0 );
  twobit_setglbl( 10 ); /*  vector-swap!~1ayXVW~24398 */
  twobit_lambda( compiled_start_2_75, 199, 0 );
  twobit_setglbl( 9 ); /*  vector-fill!~1ayXVW~24399 */
  twobit_lambda( compiled_start_2_76, 201, 0 );
  twobit_setglbl( 8 ); /*  vector-copy!~1ayXVW~24400 */
  twobit_lambda( compiled_start_2_77, 203, 0 );
  twobit_setglbl( 7 ); /*  vector-reverse-copy!~1ayXVW~24401 */
  twobit_lambda( compiled_start_2_78, 205, 0 );
  twobit_setglbl( 6 ); /*  vector-reverse!~1ayXVW~24402 */
  twobit_lambda( compiled_start_2_79, 207, 0 );
  twobit_setglbl( 5 ); /*  vector->list~1ayXVW~24403 */
  twobit_lambda( compiled_start_2_80, 209, 0 );
  twobit_setglbl( 4 ); /*  reverse-vector->list~1ayXVW~24404 */
  twobit_lambda( compiled_start_2_81, 211, 0 );
  twobit_setglbl( 3 ); /*  list->vector~1ayXVW~24405 */
  twobit_lambda( compiled_start_2_82, 213, 0 );
  twobit_setglbl( 2 ); /*  reverse-list->vector~1ayXVW~24406 */
  twobit_global( 214 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1241, compiled_block_2_1241 );
  twobit_reg( 1 );
  twobit_op2imm_132( fixnum(0), 231, compiled_temp_2_231 ); /* < */
  twobit_op1_9(); /* not */
  twobit_return();
  twobit_label( 1241, compiled_block_2_1241 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 2, 229, compiled_temp_2_229, 1243, compiled_block_2_1243 ); /* internal:branchf-< */
  twobit_reg( 2 );
  twobit_op2_67( 3, 230, compiled_temp_2_230 ); /* <= */
  twobit_return();
  twobit_label( 1243, compiled_block_2_1243 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_6( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_7( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_2_228, 2, 1 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 3 ); /*  map~1ayXVW~1381 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_228( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 3, 1, 0, 1244, compiled_block_2_1244 );
  twobit_reg( 1 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 3, 1, 0, 1244, compiled_block_2_1244 );
  twobit_reg( 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 3, 1, 0, 1244, compiled_block_2_1244 );
  twobit_lexical( 0, 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 3, 1, 0, 1244, compiled_block_2_1244 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1244, compiled_block_2_1244 );
  twobit_trap( 1, 3, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_8( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_store( 3, 3 );
  twobit_movereg( 1, 4 );
  twobit_movereg( 2, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1246, compiled_block_2_1246 );
  twobit_invoke( 1 );
  twobit_label( 1246, compiled_block_2_1246 );
  twobit_load( 0, 0 );
  twobit_branchf( 1248, compiled_block_2_1248 );
  twobit_stack( 1 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1248, compiled_block_2_1248 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 1249, compiled_block_2_1249 );
  twobit_invoke( 3 );
  twobit_label( 1249, compiled_block_2_1249 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_load( 3, 3 );
  twobit_global( 5 ); /*  check-type~1ayXVW~24327 */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_9( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /* integer? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1251, compiled_block_2_1251 );
  twobit_invoke( 3 );
  twobit_label( 1251, compiled_block_2_1251 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_635( fixnum(0), 226, compiled_temp_2_226, 1253, compiled_block_2_1253 ); /* internal:branchf-</imm */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_global( 8 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 1254, compiled_block_2_1254 );
  twobit_invoke( 4 );
  twobit_label( 1254, compiled_block_2_1254 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_load( 3, 1 );
  twobit_global( 9 ); /*  check-index~1ayXVW~24328 */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1253, compiled_block_2_1253 );
  twobit_stack( 2 );
  twobit_op1_41(); /* vector? */
  twobit_load( 2, 2 );
  twobit_check( 2, 0, 0, 1256, compiled_block_2_1256 );
  twobit_stack( 2 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_621( 3, 227, compiled_temp_2_227, 1258, compiled_block_2_1258 ); /* internal:branchf->= */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_global( 8 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 1259, compiled_block_2_1259 );
  twobit_invoke( 4 );
  twobit_label( 1259, compiled_block_2_1259 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_load( 3, 1 );
  twobit_global( 9 ); /*  check-index~1ayXVW~24328 */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1258, compiled_block_2_1258 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1256, compiled_block_2_1256 );
  twobit_trap( 2, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_10( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 6 );
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 7 );
  twobit_store( 2, 3 );
  twobit_store( 3, 6 );
  twobit_store( 5, 5 );
  twobit_store( 6, 2 );
  twobit_lexes( 6 );
  twobit_setreg( 0 );
  twobit_store( 0, 1 );
  twobit_movereg( 6, 3 );
  twobit_movereg( 4, 2 );
  twobit_global( 1 ); /* integer? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1263, compiled_block_2_1263 );
  twobit_invoke( 3 );
  twobit_label( 1263, compiled_block_2_1263 );
  twobit_load( 0, 1 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 3, 2 );
  twobit_global( 1 ); /* integer? */
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_global( 2 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1264, compiled_block_2_1264 );
  twobit_invoke( 3 );
  twobit_label( 1264, compiled_block_2_1264 );
  twobit_load( 0, 1 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_load( 3, 4 );
  twobit_reg( 4 );
  twobit_op2_branchf_620( 3, 220, compiled_temp_2_220, 1266, compiled_block_2_1266 ); /* internal:branchf-> */
  twobit_load( 4, 2 );
  twobit_load( 3, 5 );
  twobit_load( 2, 6 );
  twobit_load( 1, 7 );
  twobit_lambda( compiled_start_2_221, 4, 4 );
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_load( 2, 6 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_2_222, 6, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_global( 7 ); /* call-with-values */
  twobit_pop( 8 );
  twobit_invoke( 2 );
  twobit_label( 1266, compiled_block_2_1266 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_635( fixnum(0), 223, compiled_temp_2_223, 1271, compiled_block_2_1271 ); /* internal:branchf-</imm */
  twobit_const( 8 );
  twobit_setreg( 2 );
  twobit_stack( 6 );
  twobit_op2_58( 2 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 2 ); /* () */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 1 );
  twobit_setrtn( 1272, compiled_block_2_1272 );
  twobit_branch( 1262, compiled_block_2_1262 );
  twobit_label( 1272, compiled_block_2_1272 );
  twobit_load( 0, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 7 );
  twobit_load( 3, 6 );
  twobit_load( 4, 4 );
  twobit_load( 5, 5 );
  twobit_load( 6, 2 );
  twobit_global( 9 ); /*  check-indices~1ayXVW~24329 */
  twobit_pop( 8 );
  twobit_invoke( 6 );
  twobit_label( 1271, compiled_block_2_1271 );
  twobit_stack( 7 );
  twobit_op1_41(); /* vector? */
  twobit_load( 1, 7 );
  twobit_check( 1, 0, 0, 1274, compiled_block_2_1274 );
  twobit_stack( 7 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_branchf_621( 2, 224, compiled_temp_2_224, 1276, compiled_block_2_1276 ); /* internal:branchf->= */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 13 ); /* .list */
  twobit_setrtn( 1277, compiled_block_2_1277 );
  twobit_invoke( 2 );
  twobit_label( 1277, compiled_block_2_1277 );
  twobit_load( 0, 1 );
  twobit_setreg( 1 );
  twobit_setrtn( 1278, compiled_block_2_1278 );
  twobit_branch( 1262, compiled_block_2_1262 );
  twobit_label( 1278, compiled_block_2_1278 );
  twobit_load( 0, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 7 );
  twobit_load( 3, 6 );
  twobit_load( 4, 4 );
  twobit_load( 5, 5 );
  twobit_load( 6, 2 );
  twobit_global( 9 ); /*  check-indices~1ayXVW~24329 */
  twobit_pop( 8 );
  twobit_invoke( 6 );
  twobit_label( 1276, compiled_block_2_1276 );
  twobit_reg( 3 );
  twobit_op2_branchf_620( 2, 225, compiled_temp_2_225, 1281, compiled_block_2_1281 ); /* internal:branchf-> */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 10 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 11 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_stack( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 13 ); /* .list */
  twobit_setrtn( 1282, compiled_block_2_1282 );
  twobit_invoke( 2 );
  twobit_label( 1282, compiled_block_2_1282 );
  twobit_load( 0, 1 );
  twobit_setreg( 1 );
  twobit_setrtn( 1283, compiled_block_2_1283 );
  twobit_branch( 1262, compiled_block_2_1262 );
  twobit_label( 1283, compiled_block_2_1283 );
  twobit_load( 0, 1 );
  twobit_setreg( 4 );
  twobit_load( 1, 7 );
  twobit_load( 2, 8 );
  twobit_load( 3, 6 );
  twobit_load( 5, 5 );
  twobit_load( 6, 2 );
  twobit_global( 9 ); /*  check-indices~1ayXVW~24329 */
  twobit_pop( 8 );
  twobit_invoke( 6 );
  twobit_label( 1281, compiled_block_2_1281 );
  twobit_movereg( 4, 1 );
  twobit_movereg( 3, 2 );
  twobit_global( 14 ); /* values */
  twobit_pop( 8 );
  twobit_invoke( 2 );
  twobit_label( 1262, compiled_block_2_1262 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 15 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_lexical( 0, 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_lexical( 0, 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 31 );
  twobit_lexical( 0, 6 );
  twobit_op2_58( 31 ); /* cons */
  twobit_setreg( 31 );
  twobit_const( 16 );
  twobit_op2_58( 31 ); /* cons */
  twobit_setreg( 31 );
  twobit_const( 17 );
  twobit_op2_58( 31 ); /* cons */
  twobit_setreg( 31 );
  twobit_movereg( 31, 5 );
  twobit_global( 18 ); /* append */
  twobit_setrtn( 1286, compiled_block_2_1286 );
  twobit_invoke( 5 );
  twobit_label( 1286, compiled_block_2_1286 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_global( 19 ); /*  error~1ayXVW~11537 */
  twobit_setreg( 1 );
  twobit_const( 20 );
  twobit_setreg( 2 );
  twobit_global( 21 ); /* apply */
  twobit_pop( 0 );
  twobit_invoke( 3 );
  twobit_label( 1274, compiled_block_2_1274 );
  twobit_trap( 1, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_221( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 4, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 5 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 6 );
  twobit_global( 1 ); /*  check-indices~1ayXVW~24329 */
  twobit_pop( 1 );
  twobit_invoke( 6 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_222( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_jump( 1, 1262, compiled_block_2_1262 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_11( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_reg_op2_check_662(reg(1),reg(31),1288,compiled_block_2_1288); /* internal:check-vector?/vector-length:vec with (1 0 0) */
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1290, compiled_block_2_1290 ); /* internal:branchf-null? */
  twobit_movereg( 31, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1290, compiled_block_2_1290 );
  twobit_reg_op1_check_652(reg(2),1292,compiled_block_2_1292); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 30 );
  twobit_reg( 30 );
  twobit_op1_branchf_610( 1294, compiled_block_2_1294 ); /* internal:branchf-null? */
  twobit_movereg( 5, 30 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_movereg( 4, 5 );
  twobit_movereg( 31, 4 );
  twobit_movereg( 30, 6 );
  twobit_global( 2 ); /*  check-indices~1ayXVW~24329 */
  twobit_invoke( 6 );
  twobit_label( 1294, compiled_block_2_1294 );
  twobit_reg_op1_check_652(reg(30),1296,compiled_block_2_1296); /* internal:check-pair? with (30 0 0) */
  twobit_reg( 30 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_branchf_610( 1298, compiled_block_2_1298 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 4, 1 );
  twobit_movereg( 5, 31 );
  twobit_reg( 30 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_load( 5, 1 );
  twobit_movereg( 31, 6 );
  twobit_global( 2 ); /*  check-indices~1ayXVW~24329 */
  twobit_pop( 1 );
  twobit_invoke( 6 );
  twobit_label( 1298, compiled_block_2_1298 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 29 );
  twobit_reg( 31 );
  twobit_op2_58( 29 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_reg( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  error~1ayXVW~11537 */
  twobit_invoke( 3 );
  twobit_label( 1296, compiled_block_2_1296 );
  twobit_trap( 30, 0, 0, 1 );
  twobit_label( 1292, compiled_block_2_1292 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_label( 1288, compiled_block_2_1288 );
  twobit_trap( 1, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_12( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1302, compiled_block_2_1302 ); /* internal:branchf-null? */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1302, compiled_block_2_1302 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 3 );
  twobit_reg_op1_check_652(reg(1),1303,compiled_block_2_1303); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* vector? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1304, compiled_block_2_1304 );
  twobit_invoke( 3 );
  twobit_label( 1304, compiled_block_2_1304 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op2_check_662(reg(4),reg(4),1305,compiled_block_2_1305); /* internal:check-vector?/vector-length:vec with (4 0 0) */
  twobit_load( 3, 1 );
  twobit_reg( 4 );
  twobit_op2_branchf_622( 3, 218, compiled_temp_2_218, 1307, compiled_block_2_1307 ); /* internal:branchf-<= */
  twobit_reg( 4 );
  twobit_skip( 1306, compiled_block_2_1306 );
  twobit_label( 1307, compiled_block_2_1307 );
  twobit_reg( 3 );
  twobit_label( 1306, compiled_block_2_1306 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_26(); /* inexact? */
  twobit_branchf( 1309, compiled_block_2_1309 );
  twobit_const( 3 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_61( 4, 219, compiled_temp_2_219 ); /* + */
  twobit_skip( 1308, compiled_block_2_1308 );
  twobit_label( 1309, compiled_block_2_1309 );
  twobit_reg( 2 );
  twobit_label( 1308, compiled_block_2_1308 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1303, compiled_block_2_1303 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_label( 1305, compiled_block_2_1305 );
  twobit_trap( 4, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_13( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_reg( 4 );
  twobit_op2_branchf_621( 3, 217, compiled_temp_2_217, 1312, compiled_block_2_1312 ); /* internal:branchf->= */
  twobit_reg_op1_check_651(reg(4),1313,compiled_block_2_1313); /* internal:check-fixnum? with (4 2 0) */
  twobit_reg_op2_check_662(reg(2),reg(31),1313,compiled_block_2_1313); /* internal:check-vector?/vector-length:vec with (4 2 0) */
  twobit_reg_op2_check_661(reg(4),reg(31),1313,compiled_block_2_1313); /* internal:check-range with (4 2 0) */
  twobit_reg( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 31 );
  twobit_reg_op1_check_651(reg(5),1314,compiled_block_2_1314); /* internal:check-fixnum? with (31 5 1) */
  twobit_reg_op2_check_662(reg(1),reg(30),1314,compiled_block_2_1314); /* internal:check-vector?/vector-length:vec with (31 5 1) */
  twobit_reg_op2_check_661(reg(5),reg(30),1314,compiled_block_2_1314); /* internal:check-range with (31 5 1) */
  twobit_reg( 1 );
  twobit_op3_403( 5, 31 ); /* vector-set!:trusted */
  twobit_reg( 4 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 4 );
  twobit_reg( 5 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 31 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 30 );
  twobit_movereg( 31, 5 );
  twobit_reg( 30 );
  twobit_invoke( 5 );
  twobit_label( 1312, compiled_block_2_1312 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1313, compiled_block_2_1313 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1314, compiled_block_2_1314 );
  twobit_trap( 1, 5, 31, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_14( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_reg( 4 );
  twobit_op2_branchf_619( 3, 216, compiled_temp_2_216, 1317, compiled_block_2_1317 ); /* internal:branchf-< */
  twobit_reg_op1_check_651(reg(4),1318,compiled_block_2_1318); /* internal:check-fixnum? with (4 2 0) */
  twobit_reg_op2_check_662(reg(2),reg(31),1318,compiled_block_2_1318); /* internal:check-vector?/vector-length:vec with (4 2 0) */
  twobit_reg_op2_check_661(reg(4),reg(31),1318,compiled_block_2_1318); /* internal:check-range with (4 2 0) */
  twobit_reg( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 31 );
  twobit_reg_op1_check_651(reg(5),1319,compiled_block_2_1319); /* internal:check-fixnum? with (31 5 1) */
  twobit_reg_op2_check_662(reg(1),reg(30),1319,compiled_block_2_1319); /* internal:check-vector?/vector-length:vec with (31 5 1) */
  twobit_reg_op2_check_661(reg(5),reg(30),1319,compiled_block_2_1319); /* internal:check-range with (31 5 1) */
  twobit_reg( 1 );
  twobit_op3_403( 5, 31 ); /* vector-set!:trusted */
  twobit_reg( 4 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 4 );
  twobit_reg( 5 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 31 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 30 );
  twobit_movereg( 31, 5 );
  twobit_reg( 30 );
  twobit_invoke( 5 );
  twobit_label( 1317, compiled_block_2_1317 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1318, compiled_block_2_1318 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1319, compiled_block_2_1319 );
  twobit_trap( 1, 5, 31, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_15( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_reg( 4 );
  twobit_op2_branchf_620( 2, 210, compiled_temp_2_210, 1322, compiled_block_2_1322 ); /* internal:branchf-> */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_store( 4, 2 );
  twobit_store( 2, 3 );
  twobit_movereg( 5, 3 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 6 );
  twobit_load( 4, 2 );
  twobit_load( 5, 3 );
  twobit_reg( 6 );
  twobit_pop( 3 );
  twobit_invoke( 5 );
  twobit_label( 1322, compiled_block_2_1322 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 3, 2 );
  twobit_movereg( 4, 3 );
  twobit_reg( 5 );
  twobit_op2imm_131( fixnum(1), 211, compiled_temp_2_211 ); /* - */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_32( 212, compiled_temp_2_212 ); /* -- */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 31, 4 );
  twobit_store( 4, 3 );
  twobit_load( 4, 1 );
  twobit_reg( 5 );
  twobit_op2_61( 4, 213, compiled_temp_2_213 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_61( 4, 214, compiled_temp_2_214 ); /* + */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 4, 215, compiled_temp_2_215 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 6 );
  twobit_load( 4, 3 );
  twobit_load( 5, 2 );
  twobit_reg( 6 );
  twobit_pop( 3 );
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_16( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_reg( 4 );
  twobit_op2_branchf_621( 3, 209, compiled_temp_2_209, 1326, compiled_block_2_1326 ); /* internal:branchf->= */
  twobit_reg_op1_check_651(reg(4),1327,compiled_block_2_1327); /* internal:check-fixnum? with (4 2 0) */
  twobit_reg_op2_check_662(reg(2),reg(31),1327,compiled_block_2_1327); /* internal:check-vector?/vector-length:vec with (4 2 0) */
  twobit_reg_op2_check_661(reg(4),reg(31),1327,compiled_block_2_1327); /* internal:check-range with (4 2 0) */
  twobit_reg( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 31 );
  twobit_reg_op1_check_651(reg(5),1328,compiled_block_2_1328); /* internal:check-fixnum? with (31 5 1) */
  twobit_reg_op2_check_662(reg(1),reg(30),1328,compiled_block_2_1328); /* internal:check-vector?/vector-length:vec with (31 5 1) */
  twobit_reg_op2_check_661(reg(5),reg(30),1328,compiled_block_2_1328); /* internal:check-range with (31 5 1) */
  twobit_reg( 1 );
  twobit_op3_403( 5, 31 ); /* vector-set!:trusted */
  twobit_reg( 4 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 4 );
  twobit_reg( 5 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 31 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 30 );
  twobit_movereg( 31, 5 );
  twobit_reg( 30 );
  twobit_invoke( 5 );
  twobit_label( 1326, compiled_block_2_1326 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1327, compiled_block_2_1327 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1328, compiled_block_2_1328 );
  twobit_trap( 1, 5, 31, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_17( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 4, 3 );
  twobit_reg( 5 );
  twobit_op2imm_131( fixnum(1), 208, compiled_temp_2_208 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 1 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 6 );
  twobit_load( 4, 2 );
  twobit_load( 5, 1 );
  twobit_reg( 6 );
  twobit_pop( 2 );
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_18( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 2 );
  twobit_op2_branchf_622( 3, 207, compiled_temp_2_207, 1332, compiled_block_2_1332 ); /* internal:branchf-<= */
  twobit_reg_op1_check_651(reg(2),1333,compiled_block_2_1333); /* internal:check-fixnum? with (2 1 0) */
  twobit_reg_op2_check_662(reg(1),reg(4),1333,compiled_block_2_1333); /* internal:check-vector?/vector-length:vec with (2 1 0) */
  twobit_reg_op2_check_661(reg(2),reg(4),1333,compiled_block_2_1333); /* internal:check-range with (2 1 0) */
  twobit_reg( 1 );
  twobit_op2_402( 2 ); /* vector-ref:trusted */
  twobit_setreg( 31 );
  twobit_reg_op1_check_651(reg(3),1334,compiled_block_2_1334); /* internal:check-fixnum? with (3 1 0) */
  twobit_reg_op2_check_661(reg(3),reg(4),1334,compiled_block_2_1334); /* internal:check-range with (3 1 0) */
  twobit_reg( 1 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 2, 4 ); /* vector-set!:trusted */
  twobit_reg( 1 );
  twobit_op3_403( 3, 31 ); /* vector-set!:trusted */
  twobit_reg( 2 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 3 );
  twobit_label( 1332, compiled_block_2_1332 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1333, compiled_block_2_1333 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1334, compiled_block_2_1334 );
  twobit_trap( 1, 3, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_19( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 3 );
  twobit_op2imm_131( fixnum(1), 206, compiled_temp_2_206 ); /* - */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_20( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_reg( 5 );
  twobit_op2_branchf_623( 3, 204, compiled_temp_2_204, 1338, compiled_block_2_1338 ); /* internal:branchf-= */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1338, compiled_block_2_1338 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 3, 3 );
  twobit_store( 4, 4 );
  twobit_reg( 5 );
  twobit_op2imm_130( fixnum(1), 205, compiled_temp_2_205 ); /* + */
  twobit_setreg( 31 );
  twobit_store( 31, 1 );
  twobit_movereg( 1, 30 );
  twobit_movereg( 5, 1 );
  twobit_reg_op1_check_651(reg(5),1339,compiled_block_2_1339); /* internal:check-fixnum? with (5 4 0) */
  twobit_reg_op2_check_662(reg(4),reg(29),1339,compiled_block_2_1339); /* internal:check-vector?/vector-length:vec with (5 4 0) */
  twobit_reg_op2_check_661(reg(5),reg(29),1339,compiled_block_2_1339); /* internal:check-range with (5 4 0) */
  twobit_reg( 4 );
  twobit_op2_402( 5 ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_reg( 30 );
  twobit_setrtn( 1340, compiled_block_2_1340 );
  twobit_invoke( 3 );
  twobit_label( 1340, compiled_block_2_1340 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_stack( 1 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_movereg( 3, 6 );
  twobit_movereg( 4, 5 );
  twobit_load( 1, 2 );
  twobit_load( 3, 3 );
  twobit_load( 4, 4 );
  twobit_reg( 6 );
  twobit_pop( 4 );
  twobit_invoke( 5 );
  twobit_label( 1339, compiled_block_2_1339 );
  twobit_trap( 4, 5, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_21( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 31 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 5 );
  twobit_reg( 31 );
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_22( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_reg( 5 );
  twobit_op2_branchf_623( 3, 202, compiled_temp_2_202, 1344, compiled_block_2_1344 ); /* internal:branchf-= */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1344, compiled_block_2_1344 );
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 5 );
  twobit_store( 4, 6 );
  twobit_store( 5, 2 );
  twobit_movereg( 5, 2 );
  twobit_movereg( 4, 1 );
  twobit_reg( 5 );
  twobit_op2imm_130( fixnum(1), 203, compiled_temp_2_203 ); /* + */
  twobit_setreg( 31 );
  twobit_store( 31, 4 );
  twobit_global( 1 ); /*  vectors-ref~1ayXVW~24326 */
  twobit_setrtn( 1345, compiled_block_2_1345 );
  twobit_invoke( 2 );
  twobit_label( 1345, compiled_block_2_1345 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_global( 2 ); /* apply */
  twobit_setrtn( 1346, compiled_block_2_1346 );
  twobit_invoke( 4 );
  twobit_label( 1346, compiled_block_2_1346 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_stack( 4 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_movereg( 3, 6 );
  twobit_movereg( 4, 5 );
  twobit_load( 1, 3 );
  twobit_load( 3, 5 );
  twobit_load( 4, 6 );
  twobit_reg( 6 );
  twobit_pop( 6 );
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_23( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 31 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 5 );
  twobit_reg( 31 );
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_24( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_612( 200, compiled_temp_2_200, 1350, compiled_block_2_1350 ); /* internal:branchf-zero? */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1350, compiled_block_2_1350 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_reg( 4 );
  twobit_op2imm_131( fixnum(1), 201, compiled_temp_2_201 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 1, 31 );
  twobit_reg_op1_check_651(reg(4),1351,compiled_block_2_1351); /* internal:check-fixnum? with (4 3 0) */
  twobit_reg_op2_check_662(reg(3),reg(30),1351,compiled_block_2_1351); /* internal:check-vector?/vector-length:vec with (4 3 0) */
  twobit_reg_op2_check_661(reg(4),reg(30),1351,compiled_block_2_1351); /* internal:check-range with (4 3 0) */
  twobit_reg( 3 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 1352, compiled_block_2_1352 );
  twobit_invoke( 2 );
  twobit_label( 1352, compiled_block_2_1352 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_41(); /* vector? */
  twobit_load( 3, 1 );
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 3, 1353, compiled_block_2_1353 );
  twobit_stack( 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 2, 3, 1353, compiled_block_2_1353 );
  twobit_load( 3, 2 );
  twobit_stack( 1 );
  twobit_op3_403( 3, 4 ); /* vector-set!:trusted */
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 5 );
  twobit_movereg( 3, 4 );
  twobit_load( 1, 3 );
  twobit_load( 2, 1 );
  twobit_load( 3, 4 );
  twobit_reg( 5 );
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 1353, compiled_block_2_1353 );
  twobit_trap( 3, 2, 4, 161 );
  twobit_label( 1351, compiled_block_2_1351 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_25( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_26( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_612( 198, compiled_temp_2_198, 1357, compiled_block_2_1357 ); /* internal:branchf-zero? */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1357, compiled_block_2_1357 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 3 );
  twobit_store( 3, 4 );
  twobit_movereg( 3, 1 );
  twobit_reg( 4 );
  twobit_op2imm_131( fixnum(1), 199, compiled_temp_2_199 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 2 );
  twobit_global( 1 ); /*  vectors-ref~1ayXVW~24326 */
  twobit_setrtn( 1358, compiled_block_2_1358 );
  twobit_invoke( 2 );
  twobit_label( 1358, compiled_block_2_1358 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 2 ); /* apply */
  twobit_setrtn( 1359, compiled_block_2_1359 );
  twobit_invoke( 3 );
  twobit_label( 1359, compiled_block_2_1359 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 3 );
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 3, 1360, compiled_block_2_1360 );
  twobit_stack( 3 );
  twobit_reg_op1_check_653(RESULT,1360,compiled_block_2_1360); /* internal:check-vector? with (4 2 3) */
  twobit_stack( 3 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 3 );
  twobit_check( 4, 2, 3, 1360, compiled_block_2_1360 );
  twobit_stack( 2 );
  twobit_reg_op2imm_check_660(RESULT,fixnum(0),1360,compiled_block_2_1360); /* internal:check->=:fix:fix/imm with (4 2 3) */
  twobit_load( 3, 2 );
  twobit_stack( 3 );
  twobit_op3_403( 3, 4 ); /* vector-set!:trusted */
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 5 );
  twobit_movereg( 3, 4 );
  twobit_load( 1, 1 );
  twobit_load( 2, 3 );
  twobit_load( 3, 4 );
  twobit_reg( 5 );
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 1360, compiled_block_2_1360 );
  twobit_trap( 3, 2, 4, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_27( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_28( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_reg( 3 );
  twobit_op2_branchf_619( 4, 195, compiled_temp_2_195, 1364, compiled_block_2_1364 ); /* internal:branchf-< */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_196, 2, 4 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 5, 2 );
  twobit_lambda( compiled_start_2_197, 4, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1364, compiled_block_2_1364 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_196( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_movereg( 2, 4 );
  twobit_lexical( 0, 3 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 2, 1365, compiled_block_2_1365 );
  twobit_lexical( 0, 2 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 2, 1365, compiled_block_2_1365 );
  twobit_lexical( 0, 2 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 2, 1365, compiled_block_2_1365 );
  twobit_lexical( 0, 3 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 2, 1365, compiled_block_2_1365 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_op3_403( 3, 1 ); /* vector-set!:trusted */
  twobit_lexical( 0, 3 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_movereg( 2, 6 );
  twobit_movereg( 4, 5 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_reg( 6 );
  twobit_invoke( 5 );
  twobit_label( 1365, compiled_block_2_1365 );
  twobit_trap( 2, 31, 1, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_197( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /* apply */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_29( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_reg( 3 );
  twobit_op2_branchf_619( 4, 192, compiled_temp_2_192, 1370, compiled_block_2_1370 ); /* internal:branchf-< */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_193, 2, 4 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 5, 2 );
  twobit_lambda( compiled_start_2_194, 4, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1370, compiled_block_2_1370 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_193( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 2, 4 );
  twobit_lexical( 0, 3 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 2, 1371, compiled_block_2_1371 );
  twobit_lexical( 0, 2 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 2, 1371, compiled_block_2_1371 );
  twobit_lexical( 0, 2 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 2, 1371, compiled_block_2_1371 );
  twobit_lexical( 0, 3 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 2, 1371, compiled_block_2_1371 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_op3_403( 3, 1 ); /* vector-set!:trusted */
  twobit_lexical( 0, 3 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_movereg( 2, 6 );
  twobit_movereg( 4, 5 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_reg( 6 );
  twobit_invoke( 5 );
  twobit_label( 1371, compiled_block_2_1371 );
  twobit_trap( 2, 31, 1, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_194( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_30( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_reg( 3 );
  twobit_op2_branchf_619( 4, 191, compiled_temp_2_191, 1376, compiled_block_2_1376 ); /* internal:branchf-< */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 2 );
  twobit_store( 3, 1 );
  twobit_store( 4, 4 );
  twobit_movereg( 1, 31 );
  twobit_movereg( 3, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 1377, compiled_block_2_1377 );
  twobit_invoke( 1 );
  twobit_label( 1377, compiled_block_2_1377 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_load( 2, 1 );
  twobit_check( 4, 2, 3, 1378, compiled_block_2_1378 );
  twobit_stack( 2 );
  twobit_reg_op1_check_653(RESULT,1378,compiled_block_2_1378); /* internal:check-vector? with (4 2 3) */
  twobit_stack( 2 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 2 );
  twobit_check( 4, 2, 3, 1378, compiled_block_2_1378 );
  twobit_stack( 1 );
  twobit_reg_op2imm_check_660(RESULT,fixnum(0),1378,compiled_block_2_1378); /* internal:check->=:fix:fix/imm with (4 2 3) */
  twobit_load( 3, 1 );
  twobit_stack( 2 );
  twobit_op3_403( 3, 4 ); /* vector-set!:trusted */
  twobit_reg( 3 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 5 );
  twobit_load( 1, 3 );
  twobit_load( 2, 2 );
  twobit_load( 4, 4 );
  twobit_reg( 5 );
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 1376, compiled_block_2_1376 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1378, compiled_block_2_1378 );
  twobit_trap( 3, 2, 4, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_31( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 3, 3 );
  twobit_global( 1 ); /*  nonneg-int?~1ayXVW~24323 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-unfold~1ayXVW~24372 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1380, compiled_block_2_1380 );
  twobit_invoke( 3 );
  twobit_label( 1380, compiled_block_2_1380 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /* procedure? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-unfold~1ayXVW~24372 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1381, compiled_block_2_1381 );
  twobit_invoke( 3 );
  twobit_label( 1381, compiled_block_2_1381 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_80( 3 ); /* make-vector */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_stack( 3 );
  twobit_op1_branchf_610( 1383, compiled_block_2_1383 ); /* internal:branchf-null? */
  twobit_movereg( 3, 2 );
  twobit_movereg( 4, 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 5 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_load( 4, 2 );
  twobit_reg( 5 );
  twobit_setrtn( 1384, compiled_block_2_1384 );
  twobit_invoke( 4 );
  twobit_label( 1384, compiled_block_2_1384 );
  twobit_load( 0, 0 );
  twobit_skip( 1382, compiled_block_2_1382 );
  twobit_label( 1383, compiled_block_2_1383 );
  twobit_stack( 3 );
  twobit_op1_11(); /* pair? */
  twobit_load( 1, 3 );
  twobit_check( 1, 0, 0, 1385, compiled_block_2_1385 );
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1387, compiled_block_2_1387 ); /* internal:branchf-null? */
  twobit_stack( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_movereg( 1, 6 );
  twobit_movereg( 2, 5 );
  twobit_movereg( 4, 1 );
  twobit_movereg( 3, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_load( 4, 2 );
  twobit_reg( 6 );
  twobit_setrtn( 1388, compiled_block_2_1388 );
  twobit_invoke( 5 );
  twobit_label( 1388, compiled_block_2_1388 );
  twobit_load( 0, 0 );
  twobit_skip( 1382, compiled_block_2_1382 );
  twobit_label( 1387, compiled_block_2_1387 );
  twobit_stack( 3 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_movereg( 1, 6 );
  twobit_movereg( 2, 5 );
  twobit_movereg( 4, 1 );
  twobit_movereg( 3, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_load( 4, 2 );
  twobit_reg( 6 );
  twobit_setrtn( 1389, compiled_block_2_1389 );
  twobit_invoke( 5 );
  twobit_label( 1389, compiled_block_2_1389 );
  twobit_load( 0, 0 );
  twobit_label( 1382, compiled_block_2_1382 );
  twobit_stack( 1 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1385, compiled_block_2_1385 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_32( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_reg( 3 );
  twobit_op2imm_branchf_637( fixnum(0), 188, compiled_temp_2_188, 1391, compiled_block_2_1391 ); /* internal:branchf->=/imm */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_189, 2, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_2_190, 4, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1391, compiled_block_2_1391 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_189( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_movereg( 2, 4 );
  twobit_lexical( 0, 3 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 2, 1392, compiled_block_2_1392 );
  twobit_lexical( 0, 2 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 2, 1392, compiled_block_2_1392 );
  twobit_lexical( 0, 2 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 2, 1392, compiled_block_2_1392 );
  twobit_lexical( 0, 3 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 2, 1392, compiled_block_2_1392 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_op3_403( 3, 1 ); /* vector-set!:trusted */
  twobit_lexical( 0, 3 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_movereg( 2, 5 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_reg( 5 );
  twobit_invoke( 4 );
  twobit_label( 1392, compiled_block_2_1392 );
  twobit_trap( 2, 31, 1, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_190( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /* apply */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_33( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_reg( 3 );
  twobit_op2imm_branchf_637( fixnum(0), 185, compiled_temp_2_185, 1397, compiled_block_2_1397 ); /* internal:branchf->=/imm */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_186, 2, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_2_187, 4, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1397, compiled_block_2_1397 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_186( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 2, 4 );
  twobit_lexical( 0, 3 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 2, 1398, compiled_block_2_1398 );
  twobit_lexical( 0, 2 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 2, 1398, compiled_block_2_1398 );
  twobit_lexical( 0, 2 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 2, 1398, compiled_block_2_1398 );
  twobit_lexical( 0, 3 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 2, 1398, compiled_block_2_1398 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_op3_403( 3, 1 ); /* vector-set!:trusted */
  twobit_lexical( 0, 3 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_movereg( 2, 5 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_reg( 5 );
  twobit_invoke( 4 );
  twobit_label( 1398, compiled_block_2_1398 );
  twobit_trap( 2, 31, 1, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_187( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_34( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 3 );
  twobit_op2imm_branchf_637( fixnum(0), 184, compiled_temp_2_184, 1403, compiled_block_2_1403 ); /* internal:branchf->=/imm */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 2 );
  twobit_store( 3, 1 );
  twobit_movereg( 1, 4 );
  twobit_movereg( 3, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1404, compiled_block_2_1404 );
  twobit_invoke( 1 );
  twobit_label( 1404, compiled_block_2_1404 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_load( 2, 1 );
  twobit_check( 4, 2, 3, 1405, compiled_block_2_1405 );
  twobit_stack( 2 );
  twobit_reg_op1_check_653(RESULT,1405,compiled_block_2_1405); /* internal:check-vector? with (4 2 3) */
  twobit_stack( 2 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 2 );
  twobit_check( 4, 2, 3, 1405, compiled_block_2_1405 );
  twobit_stack( 1 );
  twobit_reg_op2imm_check_660(RESULT,fixnum(0),1405,compiled_block_2_1405); /* internal:check->=:fix:fix/imm with (4 2 3) */
  twobit_load( 3, 1 );
  twobit_stack( 2 );
  twobit_op3_403( 3, 4 ); /* vector-set!:trusted */
  twobit_reg( 3 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1403, compiled_block_2_1403 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1405, compiled_block_2_1405 );
  twobit_trap( 3, 2, 4, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_35( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 3, 3 );
  twobit_global( 1 ); /*  nonneg-int?~1ayXVW~24323 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-unfold-right~1ayXVW~24373 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1407, compiled_block_2_1407 );
  twobit_invoke( 3 );
  twobit_label( 1407, compiled_block_2_1407 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /* procedure? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-unfold-right~1ayXVW~24373 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1408, compiled_block_2_1408 );
  twobit_invoke( 3 );
  twobit_label( 1408, compiled_block_2_1408 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_stack( 2 );
  twobit_op2imm_131( fixnum(1), 183, compiled_temp_2_183 ); /* - */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 2 );
  twobit_op2_80( 2 ); /* make-vector */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_stack( 3 );
  twobit_op1_branchf_610( 1410, compiled_block_2_1410 ); /* internal:branchf-null? */
  twobit_movereg( 4, 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1411, compiled_block_2_1411 );
  twobit_invoke( 3 );
  twobit_label( 1411, compiled_block_2_1411 );
  twobit_load( 0, 0 );
  twobit_skip( 1409, compiled_block_2_1409 );
  twobit_label( 1410, compiled_block_2_1410 );
  twobit_stack( 3 );
  twobit_op1_11(); /* pair? */
  twobit_load( 1, 3 );
  twobit_check( 1, 0, 0, 1412, compiled_block_2_1412 );
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1414, compiled_block_2_1414 ); /* internal:branchf-null? */
  twobit_stack( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_movereg( 1, 5 );
  twobit_load( 1, 1 );
  twobit_reg( 5 );
  twobit_setrtn( 1415, compiled_block_2_1415 );
  twobit_invoke( 4 );
  twobit_label( 1415, compiled_block_2_1415 );
  twobit_load( 0, 0 );
  twobit_skip( 1409, compiled_block_2_1409 );
  twobit_label( 1414, compiled_block_2_1414 );
  twobit_load( 4, 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_movereg( 1, 5 );
  twobit_load( 1, 1 );
  twobit_reg( 5 );
  twobit_setrtn( 1416, compiled_block_2_1416 );
  twobit_invoke( 4 );
  twobit_label( 1416, compiled_block_2_1416 );
  twobit_load( 0, 0 );
  twobit_label( 1409, compiled_block_2_1409 );
  twobit_stack( 2 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1412, compiled_block_2_1412 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_36( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /* vector? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-copy~1ayXVW~24374 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1417, compiled_block_2_1417 );
  twobit_invoke( 3 );
  twobit_label( 1417, compiled_block_2_1417 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_179, 5, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_180, 7, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 8 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_179( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  vector-copy:parse-args~1ayXVW~24375 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_180( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 2 );
  twobit_op2_62( 1, 181, compiled_temp_2_181 ); /* - */
  twobit_op2_80( 3 ); /* make-vector */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 31, 0, 0, 1419, compiled_block_2_1419 );
  twobit_lexical( 0, 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_branchf_620( 3, 182, compiled_temp_2_182, 1421, compiled_block_2_1421 ); /* internal:branchf-> */
  twobit_reg( 3 );
  twobit_skip( 1420, compiled_block_2_1420 );
  twobit_label( 1421, compiled_block_2_1421 );
  twobit_reg( 2 );
  twobit_label( 1420, compiled_block_2_1420 );
  twobit_setreg( 31 );
  twobit_movereg( 1, 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_movereg( 31, 5 );
  twobit_global( 1 ); /*  %vector-copy!~1ayXVW~24365 */
  twobit_setrtn( 1422, compiled_block_2_1422 );
  twobit_invoke( 5 );
  twobit_label( 1422, compiled_block_2_1422 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1419, compiled_block_2_1419 );
  twobit_trap( 31, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_37( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1426,compiled_block_2_1426); /* internal:check-vector?/vector-length:vec with (1 0 0) */
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1428, compiled_block_2_1428 ); /* internal:branchf-null? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 4, 1 );
  twobit_global( 1 ); /*  unspecified-value~1ayXVW~24325 */
  twobit_setrtn( 1429, compiled_block_2_1429 );
  twobit_invoke( 0 );
  twobit_label( 1429, compiled_block_2_1429 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 5 );
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_load( 4, 1 );
  twobit_pop( 2 );
  twobit_branch( 1424, compiled_block_2_1424 );
  twobit_label( 1428, compiled_block_2_1428 );
  twobit_reg_op1_check_652(reg(2),1431,compiled_block_2_1431); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_610( 1433, compiled_block_2_1433 ); /* internal:branchf-null? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 4, 3 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  unspecified-value~1ayXVW~24325 */
  twobit_setrtn( 1434, compiled_block_2_1434 );
  twobit_invoke( 0 );
  twobit_label( 1434, compiled_block_2_1434 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 5 );
  twobit_load( 1, 2 );
  twobit_load( 3, 3 );
  twobit_load( 4, 3 );
  twobit_pop( 3 );
  twobit_branch( 1424, compiled_block_2_1424 );
  twobit_label( 1433, compiled_block_2_1433 );
  twobit_reg_op1_check_652(reg(3),1436,compiled_block_2_1436); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_branchf_610( 1438, compiled_block_2_1438 ); /* internal:branchf-null? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 4, 4 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  unspecified-value~1ayXVW~24325 */
  twobit_setrtn( 1439, compiled_block_2_1439 );
  twobit_invoke( 0 );
  twobit_label( 1439, compiled_block_2_1439 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_load( 2, 2 );
  twobit_movereg( 4, 5 );
  twobit_load( 1, 3 );
  twobit_load( 4, 4 );
  twobit_pop( 4 );
  twobit_branch( 1424, compiled_block_2_1424 );
  twobit_label( 1438, compiled_block_2_1438 );
  twobit_reg_op1_check_652(reg(31),1441,compiled_block_2_1441); /* internal:check-pair? with (31 0 0) */
  twobit_reg( 31 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 30 );
  twobit_reg( 30 );
  twobit_op1_branchf_610( 1443, compiled_block_2_1443 ); /* internal:branchf-null? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_movereg( 31, 5 );
  twobit_branch( 1424, compiled_block_2_1424 );
  twobit_label( 1443, compiled_block_2_1443 );
  twobit_global( 2 ); /*  vector-copy~1ayXVW~24374 */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_movereg( 30, 3 );
  twobit_global( 4 ); /*  error~1ayXVW~11537 */
  twobit_invoke( 3 );
  twobit_label( 1424, compiled_block_2_1424 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 5 );
  twobit_store( 2, 1 );
  twobit_store( 4, 3 );
  twobit_store( 5, 4 );
  twobit_movereg( 3, 2 );
  twobit_global( 5 ); /*  nonneg-int?~1ayXVW~24323 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-copy~1ayXVW~24374 */
  twobit_setreg( 3 );
  twobit_global( 6 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1446, compiled_block_2_1446 );
  twobit_invoke( 3 );
  twobit_label( 1446, compiled_block_2_1446 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_global( 5 ); /*  nonneg-int?~1ayXVW~24323 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-copy~1ayXVW~24374 */
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_global( 6 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1447, compiled_block_2_1447 );
  twobit_invoke( 3 );
  twobit_label( 1447, compiled_block_2_1447 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_reg( 4 );
  twobit_op2_67( 3, 176, compiled_temp_2_176 ); /* <= */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_branchf_622( 4, 177, compiled_temp_2_177, 1449, compiled_block_2_1449 ); /* internal:branchf-<= */
  twobit_reg( 2 );
  twobit_skip( 1448, compiled_block_2_1448 );
  twobit_label( 1449, compiled_block_2_1449 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1448, compiled_block_2_1448 );
  twobit_branchf( 1451, compiled_block_2_1451 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_op2_67( 1, 178, compiled_temp_2_178 ); /* <= */
  twobit_skip( 1450, compiled_block_2_1450 );
  twobit_label( 1451, compiled_block_2_1451 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1450, compiled_block_2_1450 );
  twobit_branchf( 1453, compiled_block_2_1453 );
  twobit_load( 3, 4 );
  twobit_movereg( 4, 1 );
  twobit_load( 2, 2 );
  twobit_global( 7 ); /* values */
  twobit_pop( 5 );
  twobit_invoke( 3 );
  twobit_label( 1453, compiled_block_2_1453 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 5 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 4 );
  twobit_global( 2 ); /*  vector-copy~1ayXVW~24374 */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 10 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 11 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 12 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 13 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_load( 5, 4 );
  twobit_global( 4 ); /*  error~1ayXVW~11537 */
  twobit_pop( 5 );
  twobit_invoke( 5 );
  twobit_label( 1436, compiled_block_2_1436 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_label( 1431, compiled_block_2_1431 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_label( 1426, compiled_block_2_1426 );
  twobit_trap( 1, 0, 0, 162 );
  twobit_label( 1441, compiled_block_2_1441 );
  twobit_trap( 31, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_38( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /* vector? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-reverse-copy~1ayXVW~24376 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1456, compiled_block_2_1456 );
  twobit_invoke( 3 );
  twobit_label( 1456, compiled_block_2_1456 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_173, 5, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_174, 7, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 8 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_173( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  vector-reverse-copy~1ayXVW~24376 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 5 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_const( 3 );
  twobit_setreg( 4 );
  twobit_global( 4 ); /*  vector-parse-start+end~1ayXVW~24330 */
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_174( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 4 );
  twobit_movereg( 2, 3 );
  twobit_reg( 2 );
  twobit_op2_62( 1, 175, compiled_temp_2_175 ); /* - */
  twobit_imm_const_setreg( NIL_CONST, 1 ); /* () */
  twobit_op2_80( 1 ); /* make-vector */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_movereg( 3, 5 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  %vector-reverse-copy!~1ayXVW~24366 */
  twobit_setrtn( 1458, compiled_block_2_1458 );
  twobit_invoke( 5 );
  twobit_label( 1458, compiled_block_2_1458 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_39( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_global( 1 ); /*  vector-append~1ayXVW~24377 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  vector-concatenate:aux~1ayXVW~24379 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_40( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_global( 1 ); /*  vector-concatenate~1ayXVW~24378 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  vector-concatenate:aux~1ayXVW~24379 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_41( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1463, compiled_block_2_1463 ); /* internal:branchf-null? */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1463, compiled_block_2_1463 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 5 );
  twobit_movereg( 3, 2 );
  twobit_reg_op1_check_652(reg(1),1464,compiled_block_2_1464); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_reg_op2_check_662(reg(4),reg(4),1465,compiled_block_2_1465); /* internal:check-vector?/vector-length:vec with (4 0 0) */
  twobit_store( 4, 4 );
  twobit_movereg( 4, 5 );
  twobit_load( 3, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  %vector-copy!~1ayXVW~24365 */
  twobit_setrtn( 1466, compiled_block_2_1466 );
  twobit_invoke( 5 );
  twobit_label( 1466, compiled_block_2_1466 );
  twobit_load( 0, 0 );
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_load( 4, 4 );
  twobit_stack( 5 );
  twobit_op2_61( 4, 172, compiled_temp_2_172 ); /* + */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_pop( 5 );
  twobit_invoke( 3 );
  twobit_label( 1464, compiled_block_2_1464 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_label( 1465, compiled_block_2_1465 );
  twobit_trap( 4, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_42( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1469, compiled_block_2_1469 ); /* internal:branchf-null? */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1469, compiled_block_2_1469 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_reg_op1_check_652(reg(1),1470,compiled_block_2_1470); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* vector? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1471, compiled_block_2_1471 );
  twobit_invoke( 3 );
  twobit_label( 1471, compiled_block_2_1471 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg_op1_check_653(reg(4),1472,compiled_block_2_1472); /* internal:check-vector? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_load( 3, 2 );
  twobit_op2_61( 3, 171, compiled_temp_2_171 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1470, compiled_block_2_1470 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_label( 1472, compiled_block_2_1472 );
  twobit_trap( 4, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_43( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1475, compiled_block_2_1475 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_op2_600( 4 ); /* make-vector:0 */
  twobit_return();
  twobit_label( 1475, compiled_block_2_1475 );
  twobit_reg_op1_check_652(reg(1),1476,compiled_block_2_1476); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1478, compiled_block_2_1478 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_movereg( 2, 3 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* vector? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1479, compiled_block_2_1479 );
  twobit_invoke( 3 );
  twobit_label( 1479, compiled_block_2_1479 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op2_check_662(reg(4),reg(3),1480,compiled_block_2_1480); /* internal:check-vector?/vector-length:vec with (4 0 0) */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2_80( 2 ); /* make-vector */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_movereg( 3, 5 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_movereg( 4, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_global( 3 ); /*  %vector-copy!~1ayXVW~24365 */
  twobit_setrtn( 1481, compiled_block_2_1481 );
  twobit_invoke( 5 );
  twobit_label( 1481, compiled_block_2_1481 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1478, compiled_block_2_1478 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 3 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_setrtn( 1482, compiled_block_2_1482 );
  twobit_invoke( 3 );
  twobit_label( 1482, compiled_block_2_1482 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_80( 3 ); /* make-vector */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_movereg( 3, 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_setrtn( 1483, compiled_block_2_1483 );
  twobit_invoke( 3 );
  twobit_label( 1483, compiled_block_2_1483 );
  twobit_load( 0, 0 );
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1476, compiled_block_2_1476 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_label( 1480, compiled_block_2_1480 );
  twobit_trap( 4, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_44( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /* vector? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-empty?~1ayXVW~24380 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1484, compiled_block_2_1484 );
  twobit_invoke( 3 );
  twobit_label( 1484, compiled_block_2_1484 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_653(reg(4),1485,compiled_block_2_1485); /* internal:check-vector? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_op1_31( 170, compiled_temp_2_170 ); /* zero? */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1485, compiled_block_2_1485 );
  twobit_trap( 4, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_45( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /* procedure? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector=~1ayXVW~24381 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1486, compiled_block_2_1486 );
  twobit_invoke( 3 );
  twobit_label( 1486, compiled_block_2_1486 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_branchf_610( 1488, compiled_block_2_1488 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1488, compiled_block_2_1488 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 2, 1 );
  twobit_check( 2, 0, 0, 1489, compiled_block_2_1489 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1491, compiled_block_2_1491 ); /* internal:branchf-null? */
  twobit_global( 4 ); /* vector? */
  twobit_setreg( 1 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  vector=~1ayXVW~24381 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1492, compiled_block_2_1492 );
  twobit_invoke( 3 );
  twobit_label( 1492, compiled_block_2_1492 );
  twobit_load( 0, 0 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1491, compiled_block_2_1491 );
  twobit_load( 1, 1 );
  twobit_store( 1, 2 );
  twobit_global( 5 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_2_169, 7, 2 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1489, compiled_block_2_1489 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_169( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg_op1_check_652(reg(1),1493,compiled_block_2_1493); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* vector? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector=~1ayXVW~24381 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1494, compiled_block_2_1494 );
  twobit_invoke( 3 );
  twobit_label( 1494, compiled_block_2_1494 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 3 );
  twobit_op1_10(); /* null? */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_branchf( 1496, compiled_block_2_1496 );
  twobit_reg( 2 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1496, compiled_block_2_1496 );
  twobit_movereg( 4, 2 );
  twobit_reg_op1_check_652(reg(3),1497,compiled_block_2_1497); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  binary-vector=~1ayXVW~24382 */
  twobit_setrtn( 1498, compiled_block_2_1498 );
  twobit_invoke( 3 );
  twobit_label( 1498, compiled_block_2_1498 );
  twobit_load( 0, 0 );
  twobit_branchf( 1500, compiled_block_2_1500 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1500, compiled_block_2_1500 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1497, compiled_block_2_1497 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_label( 1493, compiled_block_2_1493 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_46( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 2 );
  twobit_op2_56( 3 ); /* eq? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1504, compiled_block_2_1504 );
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1504, compiled_block_2_1504 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_reg_op2_check_662(reg(3),reg(4),1505,compiled_block_2_1505); /* internal:check-vector?/vector-length:vec with (3 0 0) */
  twobit_reg_op2_check_662(reg(2),reg(31),1506,compiled_block_2_1506); /* internal:check-vector?/vector-length:vec with (2 0 0) */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setreg( 30 );
  twobit_reg( 30 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 29 );
  twobit_reg( 30 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 30 );
  twobit_movereg( 29, 2 );
  twobit_lambda( compiled_start_2_164, 3, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_movereg( 30, 5 );
  twobit_load( 2, 1 );
  twobit_movereg( 31, 1 );
  twobit_lambda( compiled_start_2_165, 5, 5 );
  twobit_setreg( 3 );
  twobit_reg( 29 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_load( 3, 2 );
  twobit_reg( 30 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 31 );
  twobit_op2_406( 4 ); /* =:fix:fix */
  twobit_branchf( 1521, compiled_block_2_1521 );
  twobit_reg( 29 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1521, compiled_block_2_1521 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1506, compiled_block_2_1506 );
  twobit_trap( 2, 0, 0, 162 );
  twobit_label( 1505, compiled_block_2_1505 );
  twobit_trap( 3, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_164( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 2, 1508, compiled_block_2_1508 ); /* internal:branchf-eq? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1507, compiled_block_2_1507 );
  twobit_label( 1508, compiled_block_2_1508 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1509, compiled_block_2_1509 );
  twobit_invoke( 2 );
  twobit_label( 1509, compiled_block_2_1509 );
  twobit_load( 0, 0 );
  twobit_label( 1507, compiled_block_2_1507 );
  twobit_branchf( 1511, compiled_block_2_1511 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 168, compiled_temp_2_168 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1511, compiled_block_2_1511 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_165( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_68( 4, 166, compiled_temp_2_166 ); /* = */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1514, compiled_block_2_1514 );
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1514, compiled_block_2_1514 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 3, 167, compiled_temp_2_167, 1516, compiled_block_2_1516 ); /* internal:branchf-< */
  twobit_movereg( 1, 3 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_check( 1, 2, 0, 1517, compiled_block_2_1517 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_check( 1, 2, 0, 1517, compiled_block_2_1517 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_check( 1, 2, 0, 1517, compiled_block_2_1517 );
  twobit_lexical( 0, 3 );
  twobit_op2_402( 1 ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_check( 1, 31, 0, 1518, compiled_block_2_1518 );
  twobit_lexical( 0, 2 );
  twobit_op2_402( 1 ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_lexical( 0, 5 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 3 );
  twobit_label( 1516, compiled_block_2_1516 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1517, compiled_block_2_1517 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1518, compiled_block_2_1518 );
  twobit_trap( 31, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_47( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 3 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_global( 1 ); /* vector? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-fold~1ayXVW~24383 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1523, compiled_block_2_1523 );
  twobit_invoke( 3 );
  twobit_label( 1523, compiled_block_2_1523 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /* procedure? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-fold~1ayXVW~24383 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1524, compiled_block_2_1524 );
  twobit_invoke( 3 );
  twobit_label( 1524, compiled_block_2_1524 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_stack( 2 );
  twobit_op1_branchf_610( 1526, compiled_block_2_1526 ); /* internal:branchf-null? */
  twobit_movereg( 4, 1 );
  twobit_stack( 3 );
  twobit_op1_41(); /* vector? */
  twobit_load( 3, 3 );
  twobit_check( 3, 0, 0, 1527, compiled_block_2_1527 );
  twobit_stack( 3 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_load( 2, 4 );
  twobit_load( 4, 3 );
  twobit_global( 5 ); /*  %vector-fold1~1ayXVW~24368 */
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 1526, compiled_block_2_1526 );
  twobit_load( 1, 2 );
  twobit_load( 3, 2 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_stack( 3 );
  twobit_op1_41(); /* vector? */
  twobit_load( 2, 3 );
  twobit_check( 2, 0, 0, 1529, compiled_block_2_1529 );
  twobit_stack( 3 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  vector-fold~1ayXVW~24383 */
  twobit_setreg( 3 );
  twobit_global( 6 ); /*  %smallest-length~1ayXVW~24364 */
  twobit_setrtn( 1530, compiled_block_2_1530 );
  twobit_invoke( 3 );
  twobit_label( 1530, compiled_block_2_1530 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 4, 2 );
  twobit_load( 1, 1 );
  twobit_load( 2, 4 );
  twobit_global( 7 ); /*  %vector-fold2+~1ayXVW~24369 */
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 1529, compiled_block_2_1529 );
  twobit_trap( 2, 0, 0, 162 );
  twobit_label( 1527, compiled_block_2_1527 );
  twobit_trap( 3, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_48( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_635( fixnum(0), 162, compiled_temp_2_162, 1533, compiled_block_2_1533 ); /* internal:branchf-</imm */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1533, compiled_block_2_1533 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 5 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_reg( 4 );
  twobit_op2imm_131( fixnum(1), 163, compiled_temp_2_163 ); /* - */
  twobit_setreg( 31 );
  twobit_store( 31, 4 );
  twobit_global( 1 ); /*  vectors-ref~1ayXVW~24326 */
  twobit_setrtn( 1534, compiled_block_2_1534 );
  twobit_invoke( 2 );
  twobit_label( 1534, compiled_block_2_1534 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_global( 2 ); /* apply */
  twobit_setrtn( 1535, compiled_block_2_1535 );
  twobit_invoke( 4 );
  twobit_label( 1535, compiled_block_2_1535 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 4, 4 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_movereg( 3, 5 );
  twobit_load( 1, 3 );
  twobit_load( 3, 5 );
  twobit_reg( 5 );
  twobit_pop( 5 );
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_49( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_635( fixnum(0), 160, compiled_temp_2_160, 1538, compiled_block_2_1538 ); /* internal:branchf-</imm */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1538, compiled_block_2_1538 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op2imm_131( fixnum(1), 161, compiled_temp_2_161 ); /* - */
  twobit_setreg( 31 );
  twobit_store( 31, 1 );
  twobit_movereg( 1, 30 );
  twobit_movereg( 4, 1 );
  twobit_reg_op1_check_651(reg(4),1539,compiled_block_2_1539); /* internal:check-fixnum? with (4 3 0) */
  twobit_reg_op2_check_662(reg(3),reg(29),1539,compiled_block_2_1539); /* internal:check-vector?/vector-length:vec with (4 3 0) */
  twobit_reg_op2_check_661(reg(4),reg(29),1539,compiled_block_2_1539); /* internal:check-range with (4 3 0) */
  twobit_reg( 3 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_reg( 30 );
  twobit_setrtn( 1540, compiled_block_2_1540 );
  twobit_invoke( 3 );
  twobit_label( 1540, compiled_block_2_1540 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 4, 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_movereg( 3, 5 );
  twobit_load( 1, 2 );
  twobit_load( 3, 3 );
  twobit_reg( 5 );
  twobit_pop( 3 );
  twobit_invoke( 4 );
  twobit_label( 1539, compiled_block_2_1539 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_50( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 3 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_global( 1 ); /* vector? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-fold-right~1ayXVW~24384 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1542, compiled_block_2_1542 );
  twobit_invoke( 3 );
  twobit_label( 1542, compiled_block_2_1542 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /* procedure? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-fold-right~1ayXVW~24384 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1543, compiled_block_2_1543 );
  twobit_invoke( 3 );
  twobit_label( 1543, compiled_block_2_1543 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_stack( 2 );
  twobit_op1_branchf_610( 1545, compiled_block_2_1545 ); /* internal:branchf-null? */
  twobit_movereg( 4, 1 );
  twobit_stack( 3 );
  twobit_op1_41(); /* vector? */
  twobit_load( 3, 3 );
  twobit_check( 3, 0, 0, 1546, compiled_block_2_1546 );
  twobit_stack( 3 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_movereg( 3, 5 );
  twobit_load( 2, 4 );
  twobit_load( 3, 3 );
  twobit_reg( 5 );
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 1545, compiled_block_2_1545 );
  twobit_load( 1, 2 );
  twobit_load( 3, 2 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_stack( 3 );
  twobit_op1_41(); /* vector? */
  twobit_load( 2, 3 );
  twobit_check( 2, 0, 0, 1548, compiled_block_2_1548 );
  twobit_stack( 3 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  vector-fold-right~1ayXVW~24384 */
  twobit_setreg( 3 );
  twobit_global( 5 ); /*  %smallest-length~1ayXVW~24364 */
  twobit_setrtn( 1549, compiled_block_2_1549 );
  twobit_invoke( 3 );
  twobit_label( 1549, compiled_block_2_1549 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_reg( 4 );
  twobit_op2imm_131( fixnum(1), 159, compiled_temp_2_159 ); /* - */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_movereg( 2, 5 );
  twobit_load( 1, 1 );
  twobit_load( 2, 4 );
  twobit_reg( 5 );
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 1548, compiled_block_2_1548 );
  twobit_trap( 2, 0, 0, 162 );
  twobit_label( 1546, compiled_block_2_1546 );
  twobit_trap( 3, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_51( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 3, 2 );
  twobit_global( 1 ); /* vector? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-map~1ayXVW~24385 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1551, compiled_block_2_1551 );
  twobit_invoke( 3 );
  twobit_label( 1551, compiled_block_2_1551 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /* procedure? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-map~1ayXVW~24385 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1552, compiled_block_2_1552 );
  twobit_invoke( 3 );
  twobit_label( 1552, compiled_block_2_1552 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_stack( 2 );
  twobit_op1_branchf_610( 1554, compiled_block_2_1554 ); /* internal:branchf-null? */
  twobit_movereg( 4, 1 );
  twobit_stack( 3 );
  twobit_op1_41(); /* vector? */
  twobit_load( 3, 3 );
  twobit_check( 3, 0, 0, 1555, compiled_block_2_1555 );
  twobit_stack( 3 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_80( 3 ); /* make-vector */
  twobit_setreg( 2 );
  twobit_load( 3, 3 );
  twobit_global( 5 ); /*  %vector-map1!~1ayXVW~24370 */
  twobit_pop( 3 );
  twobit_invoke( 4 );
  twobit_label( 1554, compiled_block_2_1554 );
  twobit_load( 1, 2 );
  twobit_stack( 3 );
  twobit_op1_41(); /* vector? */
  twobit_load( 2, 3 );
  twobit_check( 2, 0, 0, 1557, compiled_block_2_1557 );
  twobit_stack( 3 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  vector-map~1ayXVW~24385 */
  twobit_setreg( 3 );
  twobit_global( 6 ); /*  %smallest-length~1ayXVW~24364 */
  twobit_setrtn( 1558, compiled_block_2_1558 );
  twobit_invoke( 3 );
  twobit_label( 1558, compiled_block_2_1558 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_80( 3 ); /* make-vector */
  twobit_setreg( 2 );
  twobit_load( 3, 2 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_global( 7 ); /*  %vector-map2+!~1ayXVW~24371 */
  twobit_pop( 3 );
  twobit_invoke( 4 );
  twobit_label( 1557, compiled_block_2_1557 );
  twobit_trap( 2, 0, 0, 162 );
  twobit_label( 1555, compiled_block_2_1555 );
  twobit_trap( 3, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_52( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 3, 2 );
  twobit_global( 1 ); /* vector? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-map!~1ayXVW~24386 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1560, compiled_block_2_1560 );
  twobit_invoke( 3 );
  twobit_label( 1560, compiled_block_2_1560 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /* procedure? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-map!~1ayXVW~24386 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1561, compiled_block_2_1561 );
  twobit_invoke( 3 );
  twobit_label( 1561, compiled_block_2_1561 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_stack( 2 );
  twobit_op1_branchf_610( 1563, compiled_block_2_1563 ); /* internal:branchf-null? */
  twobit_movereg( 4, 1 );
  twobit_stack( 3 );
  twobit_op1_41(); /* vector? */
  twobit_load( 2, 3 );
  twobit_check( 2, 0, 0, 1564, compiled_block_2_1564 );
  twobit_stack( 3 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_load( 3, 3 );
  twobit_global( 5 ); /*  %vector-map1!~1ayXVW~24370 */
  twobit_setrtn( 1565, compiled_block_2_1565 );
  twobit_invoke( 4 );
  twobit_label( 1565, compiled_block_2_1565 );
  twobit_load( 0, 0 );
  twobit_skip( 1562, compiled_block_2_1562 );
  twobit_label( 1563, compiled_block_2_1563 );
  twobit_load( 1, 2 );
  twobit_load( 3, 2 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_stack( 3 );
  twobit_op1_41(); /* vector? */
  twobit_load( 3, 3 );
  twobit_check( 3, 0, 0, 1566, compiled_block_2_1566 );
  twobit_stack( 3 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  vector-map!~1ayXVW~24386 */
  twobit_setreg( 3 );
  twobit_global( 6 ); /*  %smallest-length~1ayXVW~24364 */
  twobit_setrtn( 1567, compiled_block_2_1567 );
  twobit_invoke( 3 );
  twobit_label( 1567, compiled_block_2_1567 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_load( 1, 4 );
  twobit_load( 2, 3 );
  twobit_global( 7 ); /*  %vector-map2+!~1ayXVW~24371 */
  twobit_setrtn( 1568, compiled_block_2_1568 );
  twobit_invoke( 4 );
  twobit_label( 1568, compiled_block_2_1568 );
  twobit_load( 0, 0 );
  twobit_label( 1562, compiled_block_2_1562 );
  twobit_global( 8 ); /*  unspecified-value~1ayXVW~24325 */
  twobit_pop( 4 );
  twobit_invoke( 0 );
  twobit_label( 1564, compiled_block_2_1564 );
  twobit_trap( 2, 0, 0, 162 );
  twobit_label( 1566, compiled_block_2_1566 );
  twobit_trap( 3, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_53( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_reg( 3 );
  twobit_op2_branchf_619( 4, 157, compiled_temp_2_157, 1571, compiled_block_2_1571 ); /* internal:branchf-< */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 3 );
  twobit_store( 3, 1 );
  twobit_store( 4, 4 );
  twobit_movereg( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_global( 1 ); /*  vectors-ref~1ayXVW~24326 */
  twobit_setrtn( 1572, compiled_block_2_1572 );
  twobit_invoke( 2 );
  twobit_label( 1572, compiled_block_2_1572 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_load( 1, 2 );
  twobit_global( 2 ); /* apply */
  twobit_setrtn( 1573, compiled_block_2_1573 );
  twobit_invoke( 3 );
  twobit_label( 1573, compiled_block_2_1573 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 158, compiled_temp_2_158 ); /* + */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 5 );
  twobit_load( 1, 2 );
  twobit_load( 2, 3 );
  twobit_load( 4, 4 );
  twobit_reg( 5 );
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 1571, compiled_block_2_1571 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_54( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_reg( 3 );
  twobit_op2_branchf_619( 4, 156, compiled_temp_2_156, 1576, compiled_block_2_1576 ); /* internal:branchf-< */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 3 );
  twobit_store( 3, 1 );
  twobit_store( 4, 4 );
  twobit_movereg( 1, 31 );
  twobit_movereg( 3, 1 );
  twobit_reg_op1_check_651(reg(3),1577,compiled_block_2_1577); /* internal:check-fixnum? with (3 2 0) */
  twobit_reg_op2_check_662(reg(2),reg(30),1577,compiled_block_2_1577); /* internal:check-vector?/vector-length:vec with (3 2 0) */
  twobit_reg_op2_check_661(reg(3),reg(30),1577,compiled_block_2_1577); /* internal:check-range with (3 2 0) */
  twobit_reg( 2 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_reg( 31 );
  twobit_setrtn( 1578, compiled_block_2_1578 );
  twobit_invoke( 2 );
  twobit_label( 1578, compiled_block_2_1578 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 5 );
  twobit_load( 1, 2 );
  twobit_load( 2, 3 );
  twobit_load( 4, 4 );
  twobit_reg( 5 );
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 1576, compiled_block_2_1576 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1577, compiled_block_2_1577 );
  twobit_trap( 2, 3, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_55( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 3, 2 );
  twobit_global( 1 ); /* vector? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-for-each~1ayXVW~24387 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1580, compiled_block_2_1580 );
  twobit_invoke( 3 );
  twobit_label( 1580, compiled_block_2_1580 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /* procedure? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-for-each~1ayXVW~24387 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1581, compiled_block_2_1581 );
  twobit_invoke( 3 );
  twobit_label( 1581, compiled_block_2_1581 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_stack( 2 );
  twobit_op1_branchf_610( 1583, compiled_block_2_1583 ); /* internal:branchf-null? */
  twobit_movereg( 4, 1 );
  twobit_stack( 3 );
  twobit_op1_41(); /* vector? */
  twobit_load( 3, 3 );
  twobit_check( 3, 0, 0, 1584, compiled_block_2_1584 );
  twobit_stack( 3 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_movereg( 3, 5 );
  twobit_load( 2, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_reg( 5 );
  twobit_pop( 3 );
  twobit_invoke( 4 );
  twobit_label( 1583, compiled_block_2_1583 );
  twobit_load( 1, 2 );
  twobit_load( 3, 2 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_stack( 3 );
  twobit_op1_41(); /* vector? */
  twobit_load( 2, 3 );
  twobit_check( 2, 0, 0, 1586, compiled_block_2_1586 );
  twobit_stack( 3 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  vector-for-each~1ayXVW~24387 */
  twobit_setreg( 3 );
  twobit_global( 5 ); /*  %smallest-length~1ayXVW~24364 */
  twobit_setrtn( 1587, compiled_block_2_1587 );
  twobit_invoke( 3 );
  twobit_label( 1587, compiled_block_2_1587 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_movereg( 3, 5 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_reg( 5 );
  twobit_pop( 3 );
  twobit_invoke( 4 );
  twobit_label( 1586, compiled_block_2_1586 );
  twobit_trap( 2, 0, 0, 162 );
  twobit_label( 1584, compiled_block_2_1584 );
  twobit_trap( 3, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_56( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 3, 2 );
  twobit_global( 1 ); /* vector? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-count~1ayXVW~24388 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1589, compiled_block_2_1589 );
  twobit_invoke( 3 );
  twobit_label( 1589, compiled_block_2_1589 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /* procedure? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-count~1ayXVW~24388 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1590, compiled_block_2_1590 );
  twobit_invoke( 3 );
  twobit_label( 1590, compiled_block_2_1590 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op1_branchf_610( 1592, compiled_block_2_1592 ); /* internal:branchf-null? */
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_152, 6, 1 );
  twobit_setreg( 1 );
  twobit_stack( 3 );
  twobit_op1_41(); /* vector? */
  twobit_load( 3, 3 );
  twobit_check( 3, 0, 0, 1596, compiled_block_2_1596 );
  twobit_stack( 3 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_load( 4, 3 );
  twobit_global( 7 ); /*  %vector-fold1~1ayXVW~24368 */
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 1592, compiled_block_2_1592 );
  twobit_load( 1, 2 );
  twobit_store( 1, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_153, 9, 1 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 3, 2 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_stack( 3 );
  twobit_op1_41(); /* vector? */
  twobit_load( 1, 3 );
  twobit_check( 1, 0, 0, 1601, compiled_block_2_1601 );
  twobit_stack( 3 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  vector-count~1ayXVW~24388 */
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_global( 10 ); /*  %smallest-length~1ayXVW~24364 */
  twobit_setrtn( 1602, compiled_block_2_1602 );
  twobit_invoke( 3 );
  twobit_label( 1602, compiled_block_2_1602 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 4, 2 );
  twobit_load( 1, 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 11 ); /*  %vector-fold2+~1ayXVW~24369 */
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 1596, compiled_block_2_1596 );
  twobit_trap( 3, 0, 0, 162 );
  twobit_label( 1601, compiled_block_2_1601 );
  twobit_trap( 1, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_152( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1593, compiled_block_2_1593 );
  twobit_invoke( 2 );
  twobit_label( 1593, compiled_block_2_1593 );
  twobit_load( 0, 0 );
  twobit_branchf( 1595, compiled_block_2_1595 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 155, compiled_temp_2_155 ); /* + */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1595, compiled_block_2_1595 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_153( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* apply */
  twobit_setrtn( 1598, compiled_block_2_1598 );
  twobit_invoke( 3 );
  twobit_label( 1598, compiled_block_2_1598 );
  twobit_load( 0, 0 );
  twobit_branchf( 1600, compiled_block_2_1600 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 154, compiled_temp_2_154 ); /* + */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1600, compiled_block_2_1600 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_57( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_global( 1 ); /*  vector-index~1ayXVW~24389 */
  twobit_setreg( 4 );
  twobit_global( 2 ); /*  vector-index/skip~1ayXVW~24391 */
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_58( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_lambda( compiled_start_2_151, 2, 1 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  vector-skip~1ayXVW~24390 */
  twobit_setreg( 4 );
  twobit_global( 4 ); /*  vector-index/skip~1ayXVW~24391 */
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_151( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* apply */
  twobit_setrtn( 1605, compiled_block_2_1605 );
  twobit_invoke( 2 );
  twobit_label( 1605, compiled_block_2_1605 );
  twobit_load( 0, 0 );
  twobit_op1_9(); /* not */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_59( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_reg( 4 );
  twobit_op2_branchf_623( 3, 149, compiled_temp_2_149, 1608, compiled_block_2_1608 ); /* internal:branchf-= */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1608, compiled_block_2_1608 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 3 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 2, 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 1 ); /*  vectors-ref~1ayXVW~24326 */
  twobit_setrtn( 1609, compiled_block_2_1609 );
  twobit_invoke( 2 );
  twobit_label( 1609, compiled_block_2_1609 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* apply */
  twobit_setrtn( 1610, compiled_block_2_1610 );
  twobit_invoke( 2 );
  twobit_label( 1610, compiled_block_2_1610 );
  twobit_load( 0, 0 );
  twobit_branchf( 1612, compiled_block_2_1612 );
  twobit_stack( 2 );
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1612, compiled_block_2_1612 );
  twobit_stack( 2 );
  twobit_op2imm_130( fixnum(1), 150, compiled_temp_2_150 ); /* + */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_movereg( 3, 5 );
  twobit_load( 1, 1 );
  twobit_load( 2, 3 );
  twobit_load( 3, 4 );
  twobit_reg( 5 );
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_60( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_reg( 4 );
  twobit_op2_branchf_623( 3, 148, compiled_temp_2_148, 1615, compiled_block_2_1615 ); /* internal:branchf-= */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1615, compiled_block_2_1615 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 3 );
  twobit_store( 3, 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 1, 31 );
  twobit_reg_op1_check_651(reg(4),1616,compiled_block_2_1616); /* internal:check-fixnum? with (4 2 0) */
  twobit_reg_op2_check_662(reg(2),reg(30),1616,compiled_block_2_1616); /* internal:check-vector?/vector-length:vec with (4 2 0) */
  twobit_reg_op2_check_661(reg(4),reg(30),1616,compiled_block_2_1616); /* internal:check-range with (4 2 0) */
  twobit_reg( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_reg( 31 );
  twobit_setrtn( 1617, compiled_block_2_1617 );
  twobit_invoke( 1 );
  twobit_label( 1617, compiled_block_2_1617 );
  twobit_load( 0, 0 );
  twobit_branchf( 1619, compiled_block_2_1619 );
  twobit_stack( 1 );
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1619, compiled_block_2_1619 );
  twobit_stack( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_movereg( 3, 5 );
  twobit_load( 1, 2 );
  twobit_load( 2, 3 );
  twobit_load( 3, 4 );
  twobit_reg( 5 );
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 1616, compiled_block_2_1616 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_61( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 3, 3 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 3 );
  twobit_global( 1 ); /* vector? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1621, compiled_block_2_1621 );
  twobit_invoke( 3 );
  twobit_label( 1621, compiled_block_2_1621 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 3, 1 );
  twobit_load( 2, 2 );
  twobit_global( 3 ); /* procedure? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1622, compiled_block_2_1622 );
  twobit_invoke( 3 );
  twobit_label( 1622, compiled_block_2_1622 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 3 );
  twobit_op1_branchf_610( 1624, compiled_block_2_1624 ); /* internal:branchf-null? */
  twobit_movereg( 4, 1 );
  twobit_stack( 4 );
  twobit_op1_41(); /* vector? */
  twobit_load( 3, 4 );
  twobit_check( 3, 0, 0, 1625, compiled_block_2_1625 );
  twobit_stack( 4 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 5 );
  twobit_load( 2, 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_reg( 5 );
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 1624, compiled_block_2_1624 );
  twobit_load( 1, 3 );
  twobit_load( 3, 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_load( 3, 1 );
  twobit_stack( 4 );
  twobit_op1_41(); /* vector? */
  twobit_load( 2, 4 );
  twobit_check( 2, 0, 0, 1627, compiled_block_2_1627 );
  twobit_stack( 4 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 2 );
  twobit_global( 4 ); /*  %smallest-length~1ayXVW~24364 */
  twobit_setrtn( 1628, compiled_block_2_1628 );
  twobit_invoke( 3 );
  twobit_label( 1628, compiled_block_2_1628 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 5 );
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_reg( 5 );
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 1627, compiled_block_2_1627 );
  twobit_trap( 2, 0, 0, 162 );
  twobit_label( 1625, compiled_block_2_1625 );
  twobit_trap( 3, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_62( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_global( 1 ); /*  vector-index-right~1ayXVW~24392 */
  twobit_setreg( 4 );
  twobit_global( 2 ); /*  vector-index/skip-right~1ayXVW~24394 */
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_63( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_lambda( compiled_start_2_147, 2, 1 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  vector-index-right~1ayXVW~24392 */
  twobit_setreg( 4 );
  twobit_global( 4 ); /*  vector-index/skip-right~1ayXVW~24394 */
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_147( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* apply */
  twobit_setrtn( 1631, compiled_block_2_1631 );
  twobit_invoke( 2 );
  twobit_label( 1631, compiled_block_2_1631 );
  twobit_load( 0, 0 );
  twobit_op1_9(); /* not */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_64( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 3 );
  twobit_op2imm_branchf_635( fixnum(0), 145, compiled_temp_2_145, 1634, compiled_block_2_1634 ); /* internal:branchf-</imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1634, compiled_block_2_1634 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 3 );
  twobit_store( 3, 2 );
  twobit_movereg( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_global( 1 ); /*  vectors-ref~1ayXVW~24326 */
  twobit_setrtn( 1635, compiled_block_2_1635 );
  twobit_invoke( 2 );
  twobit_label( 1635, compiled_block_2_1635 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* apply */
  twobit_setrtn( 1636, compiled_block_2_1636 );
  twobit_invoke( 2 );
  twobit_label( 1636, compiled_block_2_1636 );
  twobit_load( 0, 0 );
  twobit_branchf( 1638, compiled_block_2_1638 );
  twobit_stack( 2 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1638, compiled_block_2_1638 );
  twobit_stack( 2 );
  twobit_op2imm_131( fixnum(1), 146, compiled_temp_2_146 ); /* - */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 2, 3 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_65( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 3 );
  twobit_op2imm_branchf_635( fixnum(0), 144, compiled_temp_2_144, 1641, compiled_block_2_1641 ); /* internal:branchf-</imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1641, compiled_block_2_1641 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 1, 4 );
  twobit_reg_op1_check_651(reg(3),1642,compiled_block_2_1642); /* internal:check-fixnum? with (3 2 0) */
  twobit_reg_op2_check_662(reg(2),reg(31),1642,compiled_block_2_1642); /* internal:check-vector?/vector-length:vec with (3 2 0) */
  twobit_reg_op2_check_661(reg(3),reg(31),1642,compiled_block_2_1642); /* internal:check-range with (3 2 0) */
  twobit_reg( 2 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1643, compiled_block_2_1643 );
  twobit_invoke( 1 );
  twobit_label( 1643, compiled_block_2_1643 );
  twobit_load( 0, 0 );
  twobit_branchf( 1645, compiled_block_2_1645 );
  twobit_stack( 1 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1645, compiled_block_2_1645 );
  twobit_stack( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_load( 2, 3 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1642, compiled_block_2_1642 );
  twobit_trap( 2, 3, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_66( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 3, 3 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 3 );
  twobit_global( 1 ); /* vector? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1647, compiled_block_2_1647 );
  twobit_invoke( 3 );
  twobit_label( 1647, compiled_block_2_1647 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 3, 1 );
  twobit_load( 2, 2 );
  twobit_global( 3 ); /* procedure? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1648, compiled_block_2_1648 );
  twobit_invoke( 3 );
  twobit_label( 1648, compiled_block_2_1648 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 3 );
  twobit_op1_branchf_610( 1650, compiled_block_2_1650 ); /* internal:branchf-null? */
  twobit_movereg( 4, 1 );
  twobit_stack( 4 );
  twobit_op1_41(); /* vector? */
  twobit_load( 3, 4 );
  twobit_check( 3, 0, 0, 1651, compiled_block_2_1651 );
  twobit_stack( 4 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 4 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 1650, compiled_block_2_1650 );
  twobit_load( 1, 3 );
  twobit_load( 3, 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_load( 3, 1 );
  twobit_stack( 4 );
  twobit_op1_41(); /* vector? */
  twobit_load( 2, 4 );
  twobit_check( 2, 0, 0, 1653, compiled_block_2_1653 );
  twobit_stack( 4 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 2 );
  twobit_global( 4 ); /*  %smallest-length~1ayXVW~24364 */
  twobit_setrtn( 1654, compiled_block_2_1654 );
  twobit_invoke( 3 );
  twobit_label( 1654, compiled_block_2_1654 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_reg( 4 );
  twobit_op2imm_131( fixnum(1), 143, compiled_temp_2_143 ); /* - */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 1653, compiled_block_2_1653 );
  twobit_trap( 2, 0, 0, 162 );
  twobit_label( 1651, compiled_block_2_1651 );
  twobit_trap( 3, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_67( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 3 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 3 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_global( 1 ); /* procedure? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-binary-search~1ayXVW~24395 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1656, compiled_block_2_1656 );
  twobit_invoke( 3 );
  twobit_label( 1656, compiled_block_2_1656 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /* vector? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-binary-search~1ayXVW~24395 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1657, compiled_block_2_1657 );
  twobit_invoke( 3 );
  twobit_label( 1657, compiled_block_2_1657 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_134, 6, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_load( 3, 3 );
  twobit_load( 2, 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_135, 8, 3 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 9 ); /* call-with-values */
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_134( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  vector-binary-search~1ayXVW~24395 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 5 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_const( 3 );
  twobit_setreg( 4 );
  twobit_global( 4 ); /*  vector-parse-start+end~1ayXVW~24330 */
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_135( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_136, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_136( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op2_61( 2, 137, compiled_temp_2_137 ); /* + */
  twobit_imm_const_setreg( fixnum(2), 4 ); /* 2 */
  twobit_op2_65( 4, 138, compiled_temp_2_138 ); /* quotient */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_623( 2, 139, compiled_temp_2_139, 1660, compiled_block_2_1660 ); /* internal:branchf-= */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1659, compiled_block_2_1659 );
  twobit_label( 1660, compiled_block_2_1660 );
  twobit_reg( 3 );
  twobit_branchf( 1662, compiled_block_2_1662 );
  twobit_reg( 4 );
  twobit_op2_68( 3, 140, compiled_temp_2_140 ); /* = */
  twobit_skip( 1659, compiled_block_2_1659 );
  twobit_label( 1662, compiled_block_2_1662 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1659, compiled_block_2_1659 );
  twobit_branchf( 1664, compiled_block_2_1664 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1664, compiled_block_2_1664 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 4 );
  twobit_store( 4, 2 );
  twobit_global( 1 ); /*  vector-binary-search~1ayXVW~24395 */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 31 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 4, 30, 0, 1665, compiled_block_2_1665 );
  twobit_lexical( 1, 1 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 31 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 4, 30, 0, 1665, compiled_block_2_1665 );
  twobit_lexical( 1, 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op2_407( 31 ); /* <:fix:fix */
  twobit_setreg( 31 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 4, 30, 0, 1665, compiled_block_2_1665 );
  twobit_reg( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 31 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 4, 30, 0, 1665, compiled_block_2_1665 );
  twobit_lexical( 1, 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_setrtn( 1666, compiled_block_2_1666 );
  twobit_invoke( 2 );
  twobit_label( 1666, compiled_block_2_1666 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 3, 1 );
  twobit_global( 3 ); /* integer? */
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1667, compiled_block_2_1667 );
  twobit_invoke( 3 );
  twobit_label( 1667, compiled_block_2_1667 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_612( 141, compiled_temp_2_141, 1669, compiled_block_2_1669 ); /* internal:branchf-zero? */
  twobit_stack( 2 );
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1669, compiled_block_2_1669 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_636( fixnum(0), 142, compiled_temp_2_142, 1671, compiled_block_2_1671 ); /* internal:branchf->/imm */
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_load( 2, 2 );
  twobit_load( 3, 2 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 1671, compiled_block_2_1671 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_load( 2, 4 );
  twobit_load( 3, 2 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 1665, compiled_block_2_1665 );
  twobit_trap( 30, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_68( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_reg( 3 );
  twobit_op2_branchf_623( 4, 131, compiled_temp_2_131, 1677, compiled_block_2_1677 ); /* internal:branchf-= */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1677, compiled_block_2_1677 );
  twobit_reg( 3 );
  twobit_op2_branchf_623( 5, 132, compiled_temp_2_132, 1679, compiled_block_2_1679 ); /* internal:branchf-= */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_global( 1 ); /*  vectors-ref~1ayXVW~24326 */
  twobit_setrtn( 1680, compiled_block_2_1680 );
  twobit_invoke( 2 );
  twobit_label( 1680, compiled_block_2_1680 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1679, compiled_block_2_1679 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 3 );
  twobit_store( 3, 2 );
  twobit_store( 4, 4 );
  twobit_store( 5, 5 );
  twobit_movereg( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_global( 1 ); /*  vectors-ref~1ayXVW~24326 */
  twobit_setrtn( 1682, compiled_block_2_1682 );
  twobit_invoke( 2 );
  twobit_label( 1682, compiled_block_2_1682 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* apply */
  twobit_setrtn( 1683, compiled_block_2_1683 );
  twobit_invoke( 2 );
  twobit_label( 1683, compiled_block_2_1683 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1685, compiled_block_2_1685 );
  twobit_reg( 4 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1685, compiled_block_2_1685 );
  twobit_stack( 2 );
  twobit_op2imm_130( fixnum(1), 133, compiled_temp_2_133 ); /* + */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 6 );
  twobit_load( 1, 1 );
  twobit_load( 2, 3 );
  twobit_load( 4, 4 );
  twobit_load( 5, 5 );
  twobit_reg( 6 );
  twobit_pop( 5 );
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_69( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_reg( 3 );
  twobit_op2_branchf_623( 4, 129, compiled_temp_2_129, 1688, compiled_block_2_1688 ); /* internal:branchf-= */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1688, compiled_block_2_1688 );
  twobit_reg( 3 );
  twobit_op2_branchf_623( 5, 130, compiled_temp_2_130, 1690, compiled_block_2_1690 ); /* internal:branchf-= */
  twobit_movereg( 1, 4 );
  twobit_reg_op1_check_651(reg(3),1691,compiled_block_2_1691); /* internal:check-fixnum? with (3 2 0) */
  twobit_reg_op2_check_662(reg(2),reg(1),1691,compiled_block_2_1691); /* internal:check-vector?/vector-length:vec with (3 2 0) */
  twobit_reg_op2_check_661(reg(3),reg(1),1691,compiled_block_2_1691); /* internal:check-range with (3 2 0) */
  twobit_reg( 2 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 1690, compiled_block_2_1690 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 3 );
  twobit_store( 3, 1 );
  twobit_store( 4, 4 );
  twobit_store( 5, 5 );
  twobit_movereg( 1, 31 );
  twobit_reg_op1_check_651(reg(3),1691,compiled_block_2_1691); /* internal:check-fixnum? with (3 2 0) */
  twobit_reg_op2_check_662(reg(2),reg(30),1691,compiled_block_2_1691); /* internal:check-vector?/vector-length:vec with (3 2 0) */
  twobit_reg_op2_check_661(reg(3),reg(30),1691,compiled_block_2_1691); /* internal:check-range with (3 2 0) */
  twobit_reg( 2 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_reg( 31 );
  twobit_setrtn( 1693, compiled_block_2_1693 );
  twobit_invoke( 1 );
  twobit_label( 1693, compiled_block_2_1693 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1695, compiled_block_2_1695 );
  twobit_reg( 4 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1695, compiled_block_2_1695 );
  twobit_stack( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 6 );
  twobit_load( 1, 2 );
  twobit_load( 2, 3 );
  twobit_load( 4, 4 );
  twobit_load( 5, 5 );
  twobit_reg( 6 );
  twobit_pop( 5 );
  twobit_invoke( 5 );
  twobit_label( 1691, compiled_block_2_1691 );
  twobit_trap( 2, 3, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_70( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 3, 2 );
  twobit_global( 1 ); /* vector? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-any~1ayXVW~24396 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1697, compiled_block_2_1697 );
  twobit_invoke( 3 );
  twobit_label( 1697, compiled_block_2_1697 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /* procedure? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-any~1ayXVW~24396 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1698, compiled_block_2_1698 );
  twobit_invoke( 3 );
  twobit_label( 1698, compiled_block_2_1698 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_stack( 2 );
  twobit_op1_branchf_610( 1700, compiled_block_2_1700 ); /* internal:branchf-null? */
  twobit_movereg( 4, 1 );
  twobit_stack( 3 );
  twobit_op1_41(); /* vector? */
  twobit_load( 3, 3 );
  twobit_check( 3, 0, 0, 1701, compiled_block_2_1701 );
  twobit_stack( 3 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_movereg( 2, 6 );
  twobit_movereg( 3, 5 );
  twobit_load( 2, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_reg( 6 );
  twobit_pop( 3 );
  twobit_invoke( 5 );
  twobit_label( 1700, compiled_block_2_1700 );
  twobit_load( 1, 2 );
  twobit_stack( 3 );
  twobit_op1_41(); /* vector? */
  twobit_load( 2, 3 );
  twobit_check( 2, 0, 0, 1703, compiled_block_2_1703 );
  twobit_stack( 3 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  vector-any~1ayXVW~24396 */
  twobit_setreg( 3 );
  twobit_global( 5 ); /*  %smallest-length~1ayXVW~24364 */
  twobit_setrtn( 1704, compiled_block_2_1704 );
  twobit_invoke( 3 );
  twobit_label( 1704, compiled_block_2_1704 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2imm_131( fixnum(1), 128, compiled_temp_2_128 ); /* - */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_movereg( 1, 6 );
  twobit_movereg( 3, 5 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_reg( 6 );
  twobit_pop( 3 );
  twobit_invoke( 5 );
  twobit_label( 1703, compiled_block_2_1703 );
  twobit_trap( 2, 0, 0, 162 );
  twobit_label( 1701, compiled_block_2_1701 );
  twobit_trap( 3, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_71( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_reg( 3 );
  twobit_op2_68( 4, 125, compiled_temp_2_125 ); /* = */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_branchf( 1707, compiled_block_2_1707 );
  twobit_reg( 31 );
  twobit_return();
  twobit_label( 1707, compiled_block_2_1707 );
  twobit_reg( 3 );
  twobit_op2_branchf_623( 5, 126, compiled_temp_2_126, 1709, compiled_block_2_1709 ); /* internal:branchf-= */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_global( 1 ); /*  vectors-ref~1ayXVW~24326 */
  twobit_setrtn( 1710, compiled_block_2_1710 );
  twobit_invoke( 2 );
  twobit_label( 1710, compiled_block_2_1710 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1709, compiled_block_2_1709 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 3 );
  twobit_store( 3, 2 );
  twobit_store( 4, 4 );
  twobit_store( 5, 5 );
  twobit_movereg( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_global( 1 ); /*  vectors-ref~1ayXVW~24326 */
  twobit_setrtn( 1712, compiled_block_2_1712 );
  twobit_invoke( 2 );
  twobit_label( 1712, compiled_block_2_1712 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* apply */
  twobit_setrtn( 1713, compiled_block_2_1713 );
  twobit_invoke( 2 );
  twobit_label( 1713, compiled_block_2_1713 );
  twobit_load( 0, 0 );
  twobit_branchf( 1715, compiled_block_2_1715 );
  twobit_stack( 2 );
  twobit_op2imm_130( fixnum(1), 127, compiled_temp_2_127 ); /* + */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 6 );
  twobit_load( 1, 1 );
  twobit_load( 2, 3 );
  twobit_load( 4, 4 );
  twobit_load( 5, 5 );
  twobit_reg( 6 );
  twobit_pop( 5 );
  twobit_invoke( 5 );
  twobit_label( 1715, compiled_block_2_1715 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 5 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_72( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_reg( 3 );
  twobit_op2_68( 4, 123, compiled_temp_2_123 ); /* = */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_branchf( 1718, compiled_block_2_1718 );
  twobit_reg( 31 );
  twobit_return();
  twobit_label( 1718, compiled_block_2_1718 );
  twobit_reg( 3 );
  twobit_op2_branchf_623( 5, 124, compiled_temp_2_124, 1720, compiled_block_2_1720 ); /* internal:branchf-= */
  twobit_movereg( 1, 4 );
  twobit_reg_op1_check_651(reg(3),1721,compiled_block_2_1721); /* internal:check-fixnum? with (3 2 0) */
  twobit_reg_op2_check_662(reg(2),reg(1),1721,compiled_block_2_1721); /* internal:check-vector?/vector-length:vec with (3 2 0) */
  twobit_reg_op2_check_661(reg(3),reg(1),1721,compiled_block_2_1721); /* internal:check-range with (3 2 0) */
  twobit_reg( 2 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 1720, compiled_block_2_1720 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 3 );
  twobit_store( 3, 1 );
  twobit_store( 4, 4 );
  twobit_store( 5, 5 );
  twobit_movereg( 1, 31 );
  twobit_reg_op1_check_651(reg(3),1721,compiled_block_2_1721); /* internal:check-fixnum? with (3 2 0) */
  twobit_reg_op2_check_662(reg(2),reg(30),1721,compiled_block_2_1721); /* internal:check-vector?/vector-length:vec with (3 2 0) */
  twobit_reg_op2_check_661(reg(3),reg(30),1721,compiled_block_2_1721); /* internal:check-range with (3 2 0) */
  twobit_reg( 2 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_reg( 31 );
  twobit_setrtn( 1723, compiled_block_2_1723 );
  twobit_invoke( 1 );
  twobit_label( 1723, compiled_block_2_1723 );
  twobit_load( 0, 0 );
  twobit_branchf( 1725, compiled_block_2_1725 );
  twobit_stack( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 6 );
  twobit_load( 1, 2 );
  twobit_load( 2, 3 );
  twobit_load( 4, 4 );
  twobit_load( 5, 5 );
  twobit_reg( 6 );
  twobit_pop( 5 );
  twobit_invoke( 5 );
  twobit_label( 1725, compiled_block_2_1725 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1721, compiled_block_2_1721 );
  twobit_trap( 2, 3, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_73( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 3, 2 );
  twobit_global( 1 ); /* vector? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-every~1ayXVW~24397 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1727, compiled_block_2_1727 );
  twobit_invoke( 3 );
  twobit_label( 1727, compiled_block_2_1727 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /* procedure? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-every~1ayXVW~24397 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1728, compiled_block_2_1728 );
  twobit_invoke( 3 );
  twobit_label( 1728, compiled_block_2_1728 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_stack( 2 );
  twobit_op1_branchf_610( 1730, compiled_block_2_1730 ); /* internal:branchf-null? */
  twobit_movereg( 4, 1 );
  twobit_stack( 3 );
  twobit_op1_41(); /* vector? */
  twobit_load( 3, 3 );
  twobit_check( 3, 0, 0, 1731, compiled_block_2_1731 );
  twobit_stack( 3 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_movereg( 2, 6 );
  twobit_movereg( 3, 5 );
  twobit_load( 2, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_reg( 6 );
  twobit_pop( 3 );
  twobit_invoke( 5 );
  twobit_label( 1730, compiled_block_2_1730 );
  twobit_load( 1, 2 );
  twobit_stack( 3 );
  twobit_op1_41(); /* vector? */
  twobit_load( 2, 3 );
  twobit_check( 2, 0, 0, 1733, compiled_block_2_1733 );
  twobit_stack( 3 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  vector-every~1ayXVW~24397 */
  twobit_setreg( 3 );
  twobit_global( 5 ); /*  %smallest-length~1ayXVW~24364 */
  twobit_setrtn( 1734, compiled_block_2_1734 );
  twobit_invoke( 3 );
  twobit_label( 1734, compiled_block_2_1734 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2imm_131( fixnum(1), 122, compiled_temp_2_122 ); /* - */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_movereg( 1, 6 );
  twobit_movereg( 3, 5 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_reg( 6 );
  twobit_pop( 3 );
  twobit_invoke( 5 );
  twobit_label( 1733, compiled_block_2_1733 );
  twobit_trap( 2, 0, 0, 162 );
  twobit_label( 1731, compiled_block_2_1731 );
  twobit_trap( 3, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_74( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 2, 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /* vector? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-swap!~1ayXVW~24398 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1736, compiled_block_2_1736 );
  twobit_invoke( 3 );
  twobit_label( 1736, compiled_block_2_1736 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 2 ); /*  vector-swap!~1ayXVW~24398 */
  twobit_setreg( 3 );
  twobit_global( 4 ); /*  check-index~1ayXVW~24328 */
  twobit_setrtn( 1737, compiled_block_2_1737 );
  twobit_invoke( 3 );
  twobit_label( 1737, compiled_block_2_1737 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_global( 2 ); /*  vector-swap!~1ayXVW~24398 */
  twobit_setreg( 3 );
  twobit_load( 1, 2 );
  twobit_load( 2, 3 );
  twobit_global( 4 ); /*  check-index~1ayXVW~24328 */
  twobit_setrtn( 1738, compiled_block_2_1738 );
  twobit_invoke( 3 );
  twobit_label( 1738, compiled_block_2_1738 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 2 );
  twobit_check( 4, 1, 0, 1739, compiled_block_2_1739 );
  twobit_stack( 2 );
  twobit_reg_op1_check_653(RESULT,1739,compiled_block_2_1739); /* internal:check-vector? with (4 1 0) */
  twobit_stack( 2 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1740, compiled_block_2_1740 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1740,compiled_block_2_1740); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_stack( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 4, 1 );
  twobit_check( 4, 1, 0, 1739, compiled_block_2_1739 );
  twobit_stack( 1 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 3, 1, 0, 1741, compiled_block_2_1741 );
  twobit_stack( 1 );
  twobit_reg_op2imm_check_660(RESULT,fixnum(0),1741,compiled_block_2_1741); /* internal:check->=:fix:fix/imm with (3 1 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_load( 1, 3 );
  twobit_stack( 2 );
  twobit_op3_403( 1, 3 ); /* vector-set!:trusted */
  twobit_stack( 2 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1740, compiled_block_2_1740 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1741, compiled_block_2_1741 );
  twobit_trap( 1, 3, 0, 160 );
  twobit_label( 1739, compiled_block_2_1739 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_75( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_reg( 3 );
  twobit_op1_branchf_610( 1743, compiled_block_2_1743 ); /* internal:branchf-null? */
  twobit_global( 1 ); /* vector-fill! */
  twobit_invoke( 2 );
  twobit_label( 1743, compiled_block_2_1743 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 3, 1 );
  twobit_movereg( 1, 2 );
  twobit_global( 2 ); /* vector? */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  vector-fill!~1ayXVW~24399 */
  twobit_setreg( 3 );
  twobit_global( 4 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1745, compiled_block_2_1745 );
  twobit_invoke( 3 );
  twobit_label( 1745, compiled_block_2_1745 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_118, 6, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 3 );
  twobit_load( 2, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_119, 8, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_global( 9 ); /* call-with-values */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_118( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  vector-fill!~1ayXVW~24399 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 5 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_const( 3 );
  twobit_setreg( 4 );
  twobit_global( 4 ); /*  vector-parse-start+end~1ayXVW~24330 */
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_119( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_120, 3, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_120( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_623( 4, 121, compiled_temp_2_121, 1748, compiled_block_2_1748 ); /* internal:branchf-= */
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1748, compiled_block_2_1748 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_check( 2, 1, 3, 1749, compiled_block_2_1749 );
  twobit_lexical( 1, 1 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_check( 2, 1, 3, 1749, compiled_block_2_1749 );
  twobit_lexical( 1, 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_check( 2, 1, 3, 1749, compiled_block_2_1749 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_check( 2, 1, 3, 1749, compiled_block_2_1749 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_op3_403( 1, 3 ); /* vector-set!:trusted */
  twobit_reg( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 1749, compiled_block_2_1749 );
  twobit_trap( 3, 1, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_76( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 3 );
  twobit_reg_op2_check_662(reg(3),reg(31),1755,compiled_block_2_1755); /* internal:check-vector?/vector-length:vec with (3 0 0) */
  twobit_reg( 4 );
  twobit_op1_branchf_610( 1757, compiled_block_2_1757 ); /* internal:branchf-null? */
  twobit_movereg( 31, 4 );
  twobit_movereg( 4, 5 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_movereg( 31, 6 );
  twobit_branch( 1753, compiled_block_2_1753 );
  twobit_label( 1757, compiled_block_2_1757 );
  twobit_reg_op1_check_652(reg(4),1759,compiled_block_2_1759); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 30 );
  twobit_reg( 30 );
  twobit_op1_branchf_610( 1761, compiled_block_2_1761 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_movereg( 31, 5 );
  twobit_movereg( 31, 6 );
  twobit_branch( 1753, compiled_block_2_1753 );
  twobit_label( 1761, compiled_block_2_1761 );
  twobit_reg_op1_check_652(reg(30),1763,compiled_block_2_1763); /* internal:check-pair? with (30 0 0) */
  twobit_reg( 30 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 29 );
  twobit_reg( 29 );
  twobit_op1_branchf_610( 1765, compiled_block_2_1765 ); /* internal:branchf-null? */
  twobit_reg( 30 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_movereg( 30, 5 );
  twobit_movereg( 31, 6 );
  twobit_branch( 1753, compiled_block_2_1753 );
  twobit_label( 1765, compiled_block_2_1765 );
  twobit_global( 1 ); /*  vector-copy!~1ayXVW~24400 */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_movereg( 29, 3 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_invoke( 3 );
  twobit_label( 1753, compiled_block_2_1753 );
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 5 );
  twobit_store( 2, 2 );
  twobit_store( 3, 6 );
  twobit_store( 4, 1 );
  twobit_store( 6, 3 );
  twobit_movereg( 5, 2 );
  twobit_global( 4 ); /*  nonneg-int?~1ayXVW~24323 */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  vector-copy!~1ayXVW~24400 */
  twobit_setreg( 3 );
  twobit_global( 5 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1768, compiled_block_2_1768 );
  twobit_invoke( 3 );
  twobit_label( 1768, compiled_block_2_1768 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /*  nonneg-int?~1ayXVW~24323 */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  vector-copy!~1ayXVW~24400 */
  twobit_setreg( 3 );
  twobit_global( 5 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1769, compiled_block_2_1769 );
  twobit_invoke( 3 );
  twobit_label( 1769, compiled_block_2_1769 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_global( 4 ); /*  nonneg-int?~1ayXVW~24323 */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  vector-copy!~1ayXVW~24400 */
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_global( 5 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1770, compiled_block_2_1770 );
  twobit_invoke( 3 );
  twobit_label( 1770, compiled_block_2_1770 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 3, 3 );
  twobit_stack( 4 );
  twobit_op2_67( 3, 112, compiled_temp_2_112 ); /* <= */
  twobit_setreg( 2 );
  twobit_load( 1, 4 );
  twobit_stack( 1 );
  twobit_op2_branchf_622( 1, 113, compiled_temp_2_113, 1772, compiled_block_2_1772 ); /* internal:branchf-<= */
  twobit_reg( 2 );
  twobit_skip( 1771, compiled_block_2_1771 );
  twobit_label( 1772, compiled_block_2_1772 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1771, compiled_block_2_1771 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_branchf_622( 1, 114, compiled_temp_2_114, 1774, compiled_block_2_1774 ); /* internal:branchf-<= */
  twobit_reg( 3 );
  twobit_skip( 1773, compiled_block_2_1773 );
  twobit_label( 1774, compiled_block_2_1774 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1773, compiled_block_2_1773 );
  twobit_branchf( 1776, compiled_block_2_1776 );
  twobit_stack( 5 );
  twobit_op1_41(); /* vector? */
  twobit_load( 2, 5 );
  twobit_check( 2, 0, 0, 1777, compiled_block_2_1777 );
  twobit_stack( 5 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_62( 1, 115, compiled_temp_2_115 ); /* - */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_61( 2, 116, compiled_temp_2_116 ); /* + */
  twobit_op2_67( 3, 117, compiled_temp_2_117 ); /* <= */
  twobit_skip( 1775, compiled_block_2_1775 );
  twobit_label( 1776, compiled_block_2_1776 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1775, compiled_block_2_1775 );
  twobit_branchf( 1779, compiled_block_2_1779 );
  twobit_movereg( 4, 2 );
  twobit_movereg( 1, 4 );
  twobit_load( 1, 5 );
  twobit_load( 3, 6 );
  twobit_load( 5, 4 );
  twobit_global( 6 ); /*  %vector-copy!~1ayXVW~24365 */
  twobit_pop( 7 );
  twobit_invoke( 5 );
  twobit_label( 1779, compiled_block_2_1779 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 7 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 8 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 7 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 6 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_stack( 5 );
  twobit_op1_41(); /* vector? */
  twobit_load( 1, 5 );
  twobit_check( 1, 0, 0, 1781, compiled_block_2_1781 );
  twobit_stack( 5 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_imm_const_setreg( NIL_CONST, 1 ); /* () */
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_const( 7 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_const( 10 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_stack( 5 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_const( 7 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_const( 11 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  vector-copy!~1ayXVW~24400 */
  twobit_imm_const_setreg( NIL_CONST, 1 ); /* () */
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_const( 12 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_const( 13 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_const( 7 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_const( 14 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 15 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 16 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_movereg( 1, 5 );
  twobit_movereg( 4, 9 );
  twobit_const( 17 );
  twobit_setreg( 1 );
  twobit_load( 4, 6 );
  twobit_load( 6, 3 );
  twobit_load( 7, 7 );
  twobit_load( 8, 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 7 );
  twobit_invoke( 9 );
  twobit_label( 1777, compiled_block_2_1777 );
  twobit_trap( 2, 0, 0, 162 );
  twobit_label( 1763, compiled_block_2_1763 );
  twobit_trap( 30, 0, 0, 1 );
  twobit_label( 1759, compiled_block_2_1759 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_label( 1755, compiled_block_2_1755 );
  twobit_trap( 3, 0, 0, 162 );
  twobit_label( 1781, compiled_block_2_1781 );
  twobit_trap( 1, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_77( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 3 );
  twobit_reg_op2_check_662(reg(3),reg(31),1785,compiled_block_2_1785); /* internal:check-vector?/vector-length:vec with (3 0 0) */
  twobit_reg( 4 );
  twobit_op1_branchf_610( 1787, compiled_block_2_1787 ); /* internal:branchf-null? */
  twobit_movereg( 31, 4 );
  twobit_movereg( 4, 5 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_movereg( 31, 6 );
  twobit_branch( 1783, compiled_block_2_1783 );
  twobit_label( 1787, compiled_block_2_1787 );
  twobit_reg_op1_check_652(reg(4),1789,compiled_block_2_1789); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 30 );
  twobit_reg( 30 );
  twobit_op1_branchf_610( 1791, compiled_block_2_1791 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_movereg( 31, 5 );
  twobit_movereg( 31, 6 );
  twobit_branch( 1783, compiled_block_2_1783 );
  twobit_label( 1791, compiled_block_2_1791 );
  twobit_reg_op1_check_652(reg(30),1793,compiled_block_2_1793); /* internal:check-pair? with (30 0 0) */
  twobit_reg( 30 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 29 );
  twobit_reg( 29 );
  twobit_op1_branchf_610( 1795, compiled_block_2_1795 ); /* internal:branchf-null? */
  twobit_reg( 30 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_movereg( 30, 5 );
  twobit_movereg( 31, 6 );
  twobit_branch( 1783, compiled_block_2_1783 );
  twobit_label( 1795, compiled_block_2_1795 );
  twobit_global( 1 ); /*  vector-reverse-copy!~1ayXVW~24401 */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_movereg( 29, 3 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_invoke( 3 );
  twobit_label( 1783, compiled_block_2_1783 );
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_store( 4, 1 );
  twobit_store( 6, 6 );
  twobit_movereg( 5, 2 );
  twobit_global( 4 ); /*  nonneg-int?~1ayXVW~24323 */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  vector-reverse-copy!~1ayXVW~24401 */
  twobit_setreg( 3 );
  twobit_global( 5 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1798, compiled_block_2_1798 );
  twobit_invoke( 3 );
  twobit_label( 1798, compiled_block_2_1798 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /*  nonneg-int?~1ayXVW~24323 */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  vector-reverse-copy!~1ayXVW~24401 */
  twobit_setreg( 3 );
  twobit_global( 5 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1799, compiled_block_2_1799 );
  twobit_invoke( 3 );
  twobit_label( 1799, compiled_block_2_1799 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_global( 4 ); /*  nonneg-int?~1ayXVW~24323 */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  vector-reverse-copy!~1ayXVW~24401 */
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_global( 5 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1800, compiled_block_2_1800 );
  twobit_invoke( 3 );
  twobit_label( 1800, compiled_block_2_1800 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 3, 3 );
  twobit_stack( 4 );
  twobit_op2_branchf_624( 3, 1802, compiled_block_2_1802 ); /* internal:branchf-eq? */
  twobit_load( 1, 1 );
  twobit_movereg( 4, 2 );
  twobit_load( 3, 5 );
  twobit_global( 6 ); /*  between?~1ayXVW~24324 */
  twobit_setrtn( 1803, compiled_block_2_1803 );
  twobit_invoke( 3 );
  twobit_label( 1803, compiled_block_2_1803 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1805, compiled_block_2_1805 );
  twobit_reg( 4 );
  twobit_skip( 1801, compiled_block_2_1801 );
  twobit_label( 1805, compiled_block_2_1805 );
  twobit_load( 3, 1 );
  twobit_stack( 5 );
  twobit_op2_62( 3, 104, compiled_temp_2_104 ); /* - */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_61( 4, 105, compiled_temp_2_105 ); /* + */
  twobit_setreg( 3 );
  twobit_load( 1, 2 );
  twobit_load( 2, 1 );
  twobit_global( 6 ); /*  between?~1ayXVW~24324 */
  twobit_setrtn( 1806, compiled_block_2_1806 );
  twobit_invoke( 3 );
  twobit_label( 1806, compiled_block_2_1806 );
  twobit_load( 0, 0 );
  twobit_skip( 1801, compiled_block_2_1801 );
  twobit_label( 1802, compiled_block_2_1802 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1801, compiled_block_2_1801 );
  twobit_branchf( 1808, compiled_block_2_1808 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  vector-reverse-copy!~1ayXVW~24401 */
  twobit_setreg( 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_stack( 1 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_const( 7 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_const( 10 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_movereg( 4, 6 );
  twobit_movereg( 1, 5 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_load( 4, 2 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 6 );
  twobit_invoke( 6 );
  twobit_label( 1808, compiled_block_2_1808 );
  twobit_load( 4, 6 );
  twobit_stack( 5 );
  twobit_op2_67( 4, 106, compiled_temp_2_106 ); /* <= */
  twobit_setreg( 3 );
  twobit_load( 2, 5 );
  twobit_stack( 1 );
  twobit_op2_branchf_622( 2, 107, compiled_temp_2_107, 1811, compiled_block_2_1811 ); /* internal:branchf-<= */
  twobit_reg( 3 );
  twobit_skip( 1810, compiled_block_2_1810 );
  twobit_label( 1811, compiled_block_2_1811 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1810, compiled_block_2_1810 );
  twobit_setreg( 1 );
  twobit_load( 4, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_branchf_622( 4, 108, compiled_temp_2_108, 1813, compiled_block_2_1813 ); /* internal:branchf-<= */
  twobit_reg( 1 );
  twobit_skip( 1812, compiled_block_2_1812 );
  twobit_label( 1813, compiled_block_2_1813 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1812, compiled_block_2_1812 );
  twobit_branchf( 1815, compiled_block_2_1815 );
  twobit_stack( 4 );
  twobit_op1_41(); /* vector? */
  twobit_load( 1, 4 );
  twobit_check( 1, 0, 0, 1816, compiled_block_2_1816 );
  twobit_stack( 4 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_62( 4, 109, compiled_temp_2_109 ); /* - */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op2_61( 1, 110, compiled_temp_2_110 ); /* + */
  twobit_op2_67( 3, 111, compiled_temp_2_111 ); /* <= */
  twobit_skip( 1814, compiled_block_2_1814 );
  twobit_label( 1815, compiled_block_2_1815 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1814, compiled_block_2_1814 );
  twobit_branchf( 1818, compiled_block_2_1818 );
  twobit_movereg( 2, 5 );
  twobit_load( 1, 4 );
  twobit_load( 2, 2 );
  twobit_load( 3, 3 );
  twobit_global( 13 ); /*  %vector-reverse-copy!~1ayXVW~24366 */
  twobit_pop( 6 );
  twobit_invoke( 5 );
  twobit_label( 1818, compiled_block_2_1818 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 7 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 14 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_stack( 3 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_const( 7 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_const( 15 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_stack( 4 );
  twobit_op1_41(); /* vector? */
  twobit_load( 2, 4 );
  twobit_check( 2, 0, 0, 1820, compiled_block_2_1820 );
  twobit_stack( 4 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_imm_const_setreg( NIL_CONST, 4 ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 16 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 4 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_const( 17 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  vector-reverse-copy!~1ayXVW~24401 */
  twobit_imm_const_setreg( NIL_CONST, 2 ); /* () */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_const( 18 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_const( 19 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_movereg( 1, 6 );
  twobit_movereg( 4, 9 );
  twobit_const( 20 );
  twobit_setreg( 1 );
  twobit_load( 4, 3 );
  twobit_load( 5, 2 );
  twobit_load( 7, 6 );
  twobit_load( 8, 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 6 );
  twobit_invoke( 9 );
  twobit_label( 1820, compiled_block_2_1820 );
  twobit_trap( 2, 0, 0, 162 );
  twobit_label( 1793, compiled_block_2_1793 );
  twobit_trap( 30, 0, 0, 1 );
  twobit_label( 1789, compiled_block_2_1789 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_label( 1785, compiled_block_2_1785 );
  twobit_trap( 3, 0, 0, 162 );
  twobit_label( 1816, compiled_block_2_1816 );
  twobit_trap( 1, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_78( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /* vector? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  vector-reverse!~1ayXVW~24402 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1822, compiled_block_2_1822 );
  twobit_invoke( 3 );
  twobit_label( 1822, compiled_block_2_1822 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_102, 5, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_103, 7, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 8 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_102( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  vector-reverse!~1ayXVW~24402 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 5 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_const( 3 );
  twobit_setreg( 4 );
  twobit_global( 4 ); /*  vector-parse-start+end~1ayXVW~24330 */
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_103( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %vector-reverse!~1ayXVW~24367 */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_79( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1827, compiled_block_2_1827 ); /* internal:branchf-null? */
  twobit_global( 1 ); /* vector->list */
  twobit_invoke( 1 );
  twobit_label( 1827, compiled_block_2_1827 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_global( 2 ); /* vector? */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  vector->list~1ayXVW~24403 */
  twobit_setreg( 3 );
  twobit_global( 4 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1829, compiled_block_2_1829 );
  twobit_invoke( 3 );
  twobit_label( 1829, compiled_block_2_1829 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_97, 6, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_98, 8, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 9 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_97( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  vector->list~1ayXVW~24403 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 5 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_const( 3 );
  twobit_setreg( 4 );
  twobit_global( 4 ); /*  vector-parse-start+end~1ayXVW~24330 */
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_98( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 2 );
  twobit_op2imm_131( fixnum(1), 99, compiled_temp_2_99 ); /* - */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_2_100, 3, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 4, 1 );
  twobit_load( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_100( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 101, compiled_temp_2_101, 1832, compiled_block_2_1832 ); /* internal:branchf-< */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1832, compiled_block_2_1832 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1833, compiled_block_2_1833 );
  twobit_lexical( 1, 1 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1833, compiled_block_2_1833 );
  twobit_lexical( 1, 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1833, compiled_block_2_1833 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1833, compiled_block_2_1833 );
  twobit_lexical( 1, 1 );
  twobit_op2_402( 1 ); /* vector-ref:trusted */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 1833, compiled_block_2_1833 );
  twobit_trap( 3, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_80( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /* vector? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  reverse-vector->list~1ayXVW~24404 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1837, compiled_block_2_1837 );
  twobit_invoke( 3 );
  twobit_label( 1837, compiled_block_2_1837 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_93, 5, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_94, 7, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 8 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_93( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  reverse-vector->list~1ayXVW~24404 */
  twobit_setreg( 4 );
  twobit_movereg( 4, 5 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_const( 3 );
  twobit_setreg( 4 );
  twobit_global( 4 ); /*  vector-parse-start+end~1ayXVW~24330 */
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_94( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_95, 3, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_95( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_623( 4, 96, compiled_temp_2_96, 1840, compiled_block_2_1840 ); /* internal:branchf-= */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1840, compiled_block_2_1840 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1841, compiled_block_2_1841 );
  twobit_lexical( 1, 1 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1841, compiled_block_2_1841 );
  twobit_lexical( 1, 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1841, compiled_block_2_1841 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1841, compiled_block_2_1841 );
  twobit_lexical( 1, 1 );
  twobit_op2_402( 1 ); /* vector-ref:trusted */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 1841, compiled_block_2_1841 );
  twobit_trap( 3, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_81( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1846, compiled_block_2_1846 ); /* internal:branchf-null? */
  twobit_global( 1 ); /* list->vector */
  twobit_invoke( 1 );
  twobit_label( 1846, compiled_block_2_1846 );
  twobit_reg_op1_check_652(reg(2),1848,compiled_block_2_1848); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_610( 1850, compiled_block_2_1850 ); /* internal:branchf-null? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 3, 1 );
  twobit_global( 2 ); /* length */
  twobit_setrtn( 1851, compiled_block_2_1851 );
  twobit_invoke( 1 );
  twobit_label( 1851, compiled_block_2_1851 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  nonneg-int?~1ayXVW~24323 */
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  list->vector~1ayXVW~24405 */
  twobit_setreg( 3 );
  twobit_global( 5 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1852, compiled_block_2_1852 );
  twobit_invoke( 3 );
  twobit_label( 1852, compiled_block_2_1852 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 2, 1 );
  twobit_global( 3 ); /*  nonneg-int?~1ayXVW~24323 */
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  list->vector~1ayXVW~24405 */
  twobit_setreg( 3 );
  twobit_global( 5 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1853, compiled_block_2_1853 );
  twobit_invoke( 3 );
  twobit_label( 1853, compiled_block_2_1853 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_2_89, 7, 2 );
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 2 );
  twobit_op2_62( 4, 90, compiled_temp_2_90 ); /* - */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_movereg( 4, 2 );
  twobit_global( 8 ); /* list-tail */
  twobit_setrtn( 1861, compiled_block_2_1861 );
  twobit_invoke( 2 );
  twobit_label( 1861, compiled_block_2_1861 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_load( 1, 1 );
  twobit_global( 9 ); /*  vector-unfold~1ayXVW~24372 */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1850, compiled_block_2_1850 );
  twobit_reg_op1_check_652(reg(4),1863,compiled_block_2_1863); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 31 );
  twobit_op1_branchf_610( 1865, compiled_block_2_1865 ); /* internal:branchf-null? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 3 ); /*  nonneg-int?~1ayXVW~24323 */
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  list->vector~1ayXVW~24405 */
  twobit_setreg( 3 );
  twobit_global( 5 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1866, compiled_block_2_1866 );
  twobit_invoke( 3 );
  twobit_label( 1866, compiled_block_2_1866 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_global( 3 ); /*  nonneg-int?~1ayXVW~24323 */
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /*  list->vector~1ayXVW~24405 */
  twobit_setreg( 3 );
  twobit_global( 5 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1867, compiled_block_2_1867 );
  twobit_invoke( 3 );
  twobit_label( 1867, compiled_block_2_1867 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_2_91, 11, 2 );
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 2 );
  twobit_op2_62( 4, 92, compiled_temp_2_92 ); /* - */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_movereg( 4, 2 );
  twobit_global( 8 ); /* list-tail */
  twobit_setrtn( 1875, compiled_block_2_1875 );
  twobit_invoke( 2 );
  twobit_label( 1875, compiled_block_2_1875 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_load( 1, 1 );
  twobit_global( 9 ); /*  vector-unfold~1ayXVW~24372 */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1865, compiled_block_2_1865 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 2 ); /* length */
  twobit_setrtn( 1877, compiled_block_2_1877 );
  twobit_invoke( 1 );
  twobit_label( 1877, compiled_block_2_1877 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 3, 1 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_label( 1863, compiled_block_2_1863 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_label( 1848, compiled_block_2_1848 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_89( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1855, compiled_block_2_1855 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_global( 5 ); /*  list->vector~1ayXVW~24405 */
  twobit_imm_const_setreg( NIL_CONST, 1 ); /* () */
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  error~1ayXVW~11537 */
  twobit_invoke( 4 );
  twobit_label( 1855, compiled_block_2_1855 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1858, compiled_block_2_1858 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_global( 10 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1858, compiled_block_2_1858 );
  twobit_global( 11 ); /* list? */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_global( 5 ); /*  list->vector~1ayXVW~24405 */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  error~1ayXVW~11537 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_91( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1869, compiled_block_2_1869 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_global( 5 ); /*  list->vector~1ayXVW~24405 */
  twobit_imm_const_setreg( NIL_CONST, 1 ); /* () */
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  error~1ayXVW~11537 */
  twobit_invoke( 4 );
  twobit_label( 1869, compiled_block_2_1869 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1872, compiled_block_2_1872 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_global( 10 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1872, compiled_block_2_1872 );
  twobit_global( 11 ); /* list? */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_global( 5 ); /*  list->vector~1ayXVW~24405 */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  error~1ayXVW~11537 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_82( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1880, compiled_block_2_1880 ); /* internal:branchf-null? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 1881, compiled_block_2_1881 );
  twobit_invoke( 1 );
  twobit_label( 1881, compiled_block_2_1881 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  nonneg-int?~1ayXVW~24323 */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  reverse-list->vector~1ayXVW~24406 */
  twobit_setreg( 3 );
  twobit_global( 4 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1882, compiled_block_2_1882 );
  twobit_invoke( 3 );
  twobit_label( 1882, compiled_block_2_1882 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_global( 2 ); /*  nonneg-int?~1ayXVW~24323 */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  reverse-list->vector~1ayXVW~24406 */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 4 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1883, compiled_block_2_1883 );
  twobit_invoke( 3 );
  twobit_label( 1883, compiled_block_2_1883 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_2_83, 6, 2 );
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 2 );
  twobit_op2_62( 4, 84, compiled_temp_2_84 ); /* - */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 7 ); /* list-tail */
  twobit_setrtn( 1891, compiled_block_2_1891 );
  twobit_invoke( 2 );
  twobit_label( 1891, compiled_block_2_1891 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_load( 1, 3 );
  twobit_global( 8 ); /*  vector-unfold-right~1ayXVW~24373 */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1880, compiled_block_2_1880 );
  twobit_reg_op1_check_652(reg(2),1893,compiled_block_2_1893); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_610( 1895, compiled_block_2_1895 ); /* internal:branchf-null? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 1896, compiled_block_2_1896 );
  twobit_invoke( 1 );
  twobit_label( 1896, compiled_block_2_1896 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  nonneg-int?~1ayXVW~24323 */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  reverse-list->vector~1ayXVW~24406 */
  twobit_setreg( 3 );
  twobit_global( 4 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1897, compiled_block_2_1897 );
  twobit_invoke( 3 );
  twobit_label( 1897, compiled_block_2_1897 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 2, 1 );
  twobit_global( 2 ); /*  nonneg-int?~1ayXVW~24323 */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  reverse-list->vector~1ayXVW~24406 */
  twobit_setreg( 3 );
  twobit_global( 4 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1898, compiled_block_2_1898 );
  twobit_invoke( 3 );
  twobit_label( 1898, compiled_block_2_1898 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_2_85, 10, 2 );
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 2 );
  twobit_op2_62( 4, 86, compiled_temp_2_86 ); /* - */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_movereg( 4, 2 );
  twobit_global( 7 ); /* list-tail */
  twobit_setrtn( 1906, compiled_block_2_1906 );
  twobit_invoke( 2 );
  twobit_label( 1906, compiled_block_2_1906 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_load( 1, 1 );
  twobit_global( 8 ); /*  vector-unfold-right~1ayXVW~24373 */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1895, compiled_block_2_1895 );
  twobit_reg_op1_check_652(reg(4),1908,compiled_block_2_1908); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 31 );
  twobit_op1_branchf_610( 1910, compiled_block_2_1910 ); /* internal:branchf-null? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 2 ); /*  nonneg-int?~1ayXVW~24323 */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  reverse-list->vector~1ayXVW~24406 */
  twobit_setreg( 3 );
  twobit_global( 4 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1911, compiled_block_2_1911 );
  twobit_invoke( 3 );
  twobit_label( 1911, compiled_block_2_1911 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_global( 2 ); /*  nonneg-int?~1ayXVW~24323 */
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 3 ); /*  reverse-list->vector~1ayXVW~24406 */
  twobit_setreg( 3 );
  twobit_global( 4 ); /*  check-type~1ayXVW~24327 */
  twobit_setrtn( 1912, compiled_block_2_1912 );
  twobit_invoke( 3 );
  twobit_label( 1912, compiled_block_2_1912 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_2_87, 12, 2 );
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 2 );
  twobit_op2_62( 4, 88, compiled_temp_2_88 ); /* - */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_movereg( 4, 2 );
  twobit_global( 7 ); /* list-tail */
  twobit_setrtn( 1920, compiled_block_2_1920 );
  twobit_invoke( 2 );
  twobit_label( 1920, compiled_block_2_1920 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_load( 1, 1 );
  twobit_global( 8 ); /*  vector-unfold-right~1ayXVW~24373 */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1910, compiled_block_2_1910 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 1922, compiled_block_2_1922 );
  twobit_invoke( 1 );
  twobit_label( 1922, compiled_block_2_1922 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 3, 1 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_global( 14 ); /*  error~1ayXVW~11537 */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_label( 1908, compiled_block_2_1908 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_label( 1893, compiled_block_2_1893 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_83( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1885, compiled_block_2_1885 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_global( 5 ); /*  reverse-list->vector~1ayXVW~24406 */
  twobit_imm_const_setreg( NIL_CONST, 1 ); /* () */
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  error~1ayXVW~11537 */
  twobit_invoke( 4 );
  twobit_label( 1885, compiled_block_2_1885 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1888, compiled_block_2_1888 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_global( 10 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1888, compiled_block_2_1888 );
  twobit_global( 11 ); /* list? */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_global( 5 ); /*  reverse-list->vector~1ayXVW~24406 */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  error~1ayXVW~11537 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_85( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1900, compiled_block_2_1900 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_global( 5 ); /*  reverse-list->vector~1ayXVW~24406 */
  twobit_imm_const_setreg( NIL_CONST, 1 ); /* () */
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  error~1ayXVW~11537 */
  twobit_invoke( 4 );
  twobit_label( 1900, compiled_block_2_1900 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1903, compiled_block_2_1903 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_global( 10 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1903, compiled_block_2_1903 );
  twobit_global( 11 ); /* list? */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_global( 5 ); /*  reverse-list->vector~1ayXVW~24406 */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  error~1ayXVW~11537 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_87( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1914, compiled_block_2_1914 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_global( 5 ); /*  reverse-list->vector~1ayXVW~24406 */
  twobit_imm_const_setreg( NIL_CONST, 1 ); /* () */
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  error~1ayXVW~11537 */
  twobit_invoke( 4 );
  twobit_label( 1914, compiled_block_2_1914 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1917, compiled_block_2_1917 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_global( 10 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1917, compiled_block_2_1917 );
  twobit_global( 11 ); /* list? */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_global( 5 ); /*  reverse-list->vector~1ayXVW~24406 */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  error~1ayXVW~11537 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


RTYPE twobit_thunk_84467001c87d88ff37d722b999e52a0f_1(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_2_0(CONT_ACTUALS));
}
static RTYPE compiled_block_3_1004( CONT_PARAMS );
static RTYPE compiled_block_3_1003( CONT_PARAMS );
static RTYPE compiled_start_3_0( CONT_PARAMS );
static RTYPE compiled_start_3_3( CONT_PARAMS );
static RTYPE compiled_start_3_2( CONT_PARAMS );
static RTYPE compiled_start_3_1( CONT_PARAMS );

static RTYPE compiled_start_3_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_3_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_3_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_3_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1003, compiled_block_3_1003 );
  twobit_invoke( 8 );
  twobit_label( 1003, compiled_block_3_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1004, compiled_block_3_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_3_1004 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_3_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_3_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_3_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_84467001c87d88ff37d722b999e52a0f_2(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_3_0(CONT_ACTUALS));
}
codeptr_t CDECL twobit_load_table[] = { 
  twobit_thunk_84467001c87d88ff37d722b999e52a0f_0,
  twobit_thunk_84467001c87d88ff37d722b999e52a0f_1,
  twobit_thunk_84467001c87d88ff37d722b999e52a0f_2,
  0  /* The table may be empty; some compilers complain */
};

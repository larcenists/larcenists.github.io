/* Generated from /proj/will/pnkfelix/larcenytest/larceny-petit-Nightly-2009-08-19/larceny_src/lib/SRFI/srfi/%3a60.slfasl */
#include "petit-instr.h"

static RTYPE compiled_block_1_1122( CONT_PARAMS );
static RTYPE compiled_block_1_1121( CONT_PARAMS );
static RTYPE compiled_start_1_0( CONT_PARAMS );
static RTYPE compiled_start_1_3( CONT_PARAMS );
static RTYPE compiled_start_1_21( CONT_PARAMS );
static RTYPE compiled_start_1_20( CONT_PARAMS );
static RTYPE compiled_block_1_1114( CONT_PARAMS );
static RTYPE compiled_temp_1_24( CONT_PARAMS );
static RTYPE compiled_temp_1_23( CONT_PARAMS );
static RTYPE compiled_block_1_1115( CONT_PARAMS );
static RTYPE compiled_block_1_1116( CONT_PARAMS );
static RTYPE compiled_block_1_1113( CONT_PARAMS );
static RTYPE compiled_start_1_22( CONT_PARAMS );
static RTYPE compiled_block_1_1105( CONT_PARAMS );
static RTYPE compiled_temp_1_26( CONT_PARAMS );
static RTYPE compiled_block_1_1098( CONT_PARAMS );
static RTYPE compiled_start_1_19( CONT_PARAMS );
static RTYPE compiled_block_1_1109( CONT_PARAMS );
static RTYPE compiled_block_1_1108( CONT_PARAMS );
static RTYPE compiled_temp_1_29( CONT_PARAMS );
static RTYPE compiled_block_1_1107( CONT_PARAMS );
static RTYPE compiled_temp_1_28( CONT_PARAMS );
static RTYPE compiled_start_1_27( CONT_PARAMS );
static RTYPE compiled_block_1_1102( CONT_PARAMS );
static RTYPE compiled_block_1_1101( CONT_PARAMS );
static RTYPE compiled_block_1_1100( CONT_PARAMS );
static RTYPE compiled_temp_1_30( CONT_PARAMS );
static RTYPE compiled_start_1_25( CONT_PARAMS );
static RTYPE compiled_block_1_1095( CONT_PARAMS );
static RTYPE compiled_block_1_1094( CONT_PARAMS );
static RTYPE compiled_block_1_1093( CONT_PARAMS );
static RTYPE compiled_block_1_1092( CONT_PARAMS );
static RTYPE compiled_block_1_1091( CONT_PARAMS );
static RTYPE compiled_block_1_1090( CONT_PARAMS );
static RTYPE compiled_block_1_1089( CONT_PARAMS );
static RTYPE compiled_temp_1_32( CONT_PARAMS );
static RTYPE compiled_block_1_1088( CONT_PARAMS );
static RTYPE compiled_block_1_1087( CONT_PARAMS );
static RTYPE compiled_temp_1_31( CONT_PARAMS );
static RTYPE compiled_start_1_18( CONT_PARAMS );
static RTYPE compiled_block_1_1073( CONT_PARAMS );
static RTYPE compiled_block_1_1074( CONT_PARAMS );
static RTYPE compiled_block_1_1075( CONT_PARAMS );
static RTYPE compiled_temp_1_34( CONT_PARAMS );
static RTYPE compiled_temp_1_33( CONT_PARAMS );
static RTYPE compiled_start_1_17( CONT_PARAMS );
static RTYPE compiled_block_1_1084( CONT_PARAMS );
static RTYPE compiled_block_1_1083( CONT_PARAMS );
static RTYPE compiled_block_1_1082( CONT_PARAMS );
static RTYPE compiled_block_1_1081( CONT_PARAMS );
static RTYPE compiled_temp_1_37( CONT_PARAMS );
static RTYPE compiled_block_1_1077( CONT_PARAMS );
static RTYPE compiled_block_1_1079( CONT_PARAMS );
static RTYPE compiled_temp_1_36( CONT_PARAMS );
static RTYPE compiled_start_1_35( CONT_PARAMS );
static RTYPE compiled_temp_1_39( CONT_PARAMS );
static RTYPE compiled_block_1_1072( CONT_PARAMS );
static RTYPE compiled_block_1_1071( CONT_PARAMS );
static RTYPE compiled_temp_1_38( CONT_PARAMS );
static RTYPE compiled_start_1_16( CONT_PARAMS );
static RTYPE compiled_block_1_1069( CONT_PARAMS );
static RTYPE compiled_temp_1_41( CONT_PARAMS );
static RTYPE compiled_block_1_1065( CONT_PARAMS );
static RTYPE compiled_block_1_1066( CONT_PARAMS );
static RTYPE compiled_temp_1_40( CONT_PARAMS );
static RTYPE compiled_start_1_15( CONT_PARAMS );
static RTYPE compiled_block_1_1062( CONT_PARAMS );
static RTYPE compiled_temp_1_44( CONT_PARAMS );
static RTYPE compiled_block_1_1061( CONT_PARAMS );
static RTYPE compiled_temp_1_43( CONT_PARAMS );
static RTYPE compiled_block_1_1060( CONT_PARAMS );
static RTYPE compiled_temp_1_42( CONT_PARAMS );
static RTYPE compiled_start_1_14( CONT_PARAMS );
static RTYPE compiled_start_1_13( CONT_PARAMS );
static RTYPE compiled_temp_1_49( CONT_PARAMS );
static RTYPE compiled_block_1_1057( CONT_PARAMS );
static RTYPE compiled_temp_1_48( CONT_PARAMS );
static RTYPE compiled_block_1_1055( CONT_PARAMS );
static RTYPE compiled_temp_1_47( CONT_PARAMS );
static RTYPE compiled_block_1_1049( CONT_PARAMS );
static RTYPE compiled_temp_1_46( CONT_PARAMS );
static RTYPE compiled_block_1_1051( CONT_PARAMS );
static RTYPE compiled_block_1_1052( CONT_PARAMS );
static RTYPE compiled_temp_1_45( CONT_PARAMS );
static RTYPE compiled_block_1_1042( CONT_PARAMS );
static RTYPE compiled_block_1_1043( CONT_PARAMS );
static RTYPE compiled_block_1_1047( CONT_PARAMS );
static RTYPE compiled_block_1_1045( CONT_PARAMS );
static RTYPE compiled_start_1_12( CONT_PARAMS );
static RTYPE compiled_temp_1_57( CONT_PARAMS );
static RTYPE compiled_block_1_1041( CONT_PARAMS );
static RTYPE compiled_block_1_1037( CONT_PARAMS );
static RTYPE compiled_temp_1_56( CONT_PARAMS );
static RTYPE compiled_block_1_1040( CONT_PARAMS );
static RTYPE compiled_temp_1_55( CONT_PARAMS );
static RTYPE compiled_temp_1_54( CONT_PARAMS );
static RTYPE compiled_temp_1_53( CONT_PARAMS );
static RTYPE compiled_temp_1_52( CONT_PARAMS );
static RTYPE compiled_block_1_1038( CONT_PARAMS );
static RTYPE compiled_temp_1_51( CONT_PARAMS );
static RTYPE compiled_temp_1_50( CONT_PARAMS );
static RTYPE compiled_start_1_11( CONT_PARAMS );
static RTYPE compiled_block_1_1034( CONT_PARAMS );
static RTYPE compiled_block_1_1033( CONT_PARAMS );
static RTYPE compiled_block_1_1032( CONT_PARAMS );
static RTYPE compiled_block_1_1031( CONT_PARAMS );
static RTYPE compiled_block_1_1030( CONT_PARAMS );
static RTYPE compiled_block_1_1029( CONT_PARAMS );
static RTYPE compiled_temp_1_60( CONT_PARAMS );
static RTYPE compiled_block_1_1028( CONT_PARAMS );
static RTYPE compiled_block_1_1027( CONT_PARAMS );
static RTYPE compiled_block_1_1026( CONT_PARAMS );
static RTYPE compiled_block_1_1025( CONT_PARAMS );
static RTYPE compiled_temp_1_59( CONT_PARAMS );
static RTYPE compiled_block_1_1024( CONT_PARAMS );
static RTYPE compiled_block_1_1023( CONT_PARAMS );
static RTYPE compiled_block_1_1022( CONT_PARAMS );
static RTYPE compiled_temp_1_58( CONT_PARAMS );
static RTYPE compiled_start_1_10( CONT_PARAMS );
static RTYPE compiled_block_1_1020( CONT_PARAMS );
static RTYPE compiled_block_1_1019( CONT_PARAMS );
static RTYPE compiled_block_1_1018( CONT_PARAMS );
static RTYPE compiled_block_1_1017( CONT_PARAMS );
static RTYPE compiled_temp_1_61( CONT_PARAMS );
static RTYPE compiled_start_1_9( CONT_PARAMS );
static RTYPE compiled_block_1_1015( CONT_PARAMS );
static RTYPE compiled_temp_1_63( CONT_PARAMS );
static RTYPE compiled_block_1_1014( CONT_PARAMS );
static RTYPE compiled_block_1_1013( CONT_PARAMS );
static RTYPE compiled_temp_1_62( CONT_PARAMS );
static RTYPE compiled_start_1_8( CONT_PARAMS );
static RTYPE compiled_block_1_1011( CONT_PARAMS );
static RTYPE compiled_block_1_1010( CONT_PARAMS );
static RTYPE compiled_block_1_1007( CONT_PARAMS );
static RTYPE compiled_block_1_1008( CONT_PARAMS );
static RTYPE compiled_start_1_7( CONT_PARAMS );
static RTYPE compiled_block_1_1004( CONT_PARAMS );
static RTYPE compiled_start_1_6( CONT_PARAMS );
static RTYPE compiled_temp_1_64( CONT_PARAMS );
static RTYPE compiled_block_1_1003( CONT_PARAMS );
static RTYPE compiled_start_1_5( CONT_PARAMS );
static RTYPE compiled_start_1_4( CONT_PARAMS );
static RTYPE compiled_start_1_2( CONT_PARAMS );
static RTYPE compiled_start_1_1( CONT_PARAMS );

static RTYPE compiled_start_1_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 2 ); /*  bitwise-merge~1ayXVW~29000 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 3 ); /*  first-set-bit~1ayXVW~28999 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 4 ); /*  any-bits-set?~1ayXVW~28998 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 5 ); /*  bit-set?~1ayXVW~28997 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 6 ); /*  bit-count~1ayXVW~28996 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 7 ); /*  ash~1ayXVW~28995 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 8 ); /*  booleans->integer~1ayXVW~28994 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 9 ); /*  list->integer~1ayXVW~28993 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 10 ); /*  integer->list~1ayXVW~28992 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 11 ); /*  reverse-bit-field~1ayXVW~28991 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 12 ); /*  bit-reverse~1ayXVW~28990 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 13 ); /*  log2-binary-factors~1ayXVW~28989 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 14 ); /*  logcount~1ayXVW~28988 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 15 ); /*  integer-length~1ayXVW~28987 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 16 ); /*  arithmetic-shift~1ayXVW~28986 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 17 ); /*  rotate-bit-field~1ayXVW~28985 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 18 ); /*  copy-bit-field~1ayXVW~28984 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 19 ); /*  bit-field~1ayXVW~28983 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 20 ); /*  copy-bit~1ayXVW~28982 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 21 ); /*  logbit?~1ayXVW~28981 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 22 ); /*  logtest~1ayXVW~28980 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 23 ); /*  lognot~1ayXVW~28979 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 24 ); /*  logxor~1ayXVW~28978 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 25 ); /*  logior~1ayXVW~28977 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 26 ); /*  logand~1ayXVW~28976 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 27 ); /*  logical:ash-4~1ayXVW~28975 */
  twobit_lambda( compiled_start_1_1, 29, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_2, 31, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_3, 33, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 34 );
  twobit_setreg( 1 );
  twobit_const( 35 );
  twobit_setreg( 3 );
  twobit_const( 36 );
  twobit_setreg( 4 );
  twobit_const( 37 );
  twobit_setreg( 5 );
  twobit_const( 38 );
  twobit_setreg( 8 );
  twobit_global( 39 ); /* ex:make-library */
  twobit_setrtn( 1121, compiled_block_1_1121 );
  twobit_invoke( 8 );
  twobit_label( 1121, compiled_block_1_1121 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 40 ); /* ex:register-library! */
  twobit_setrtn( 1122, compiled_block_1_1122 );
  twobit_invoke( 1 );
  twobit_label( 1122, compiled_block_1_1122 );
  twobit_load( 0, 0 );
  twobit_global( 41 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 2 ); /*  bitwise-merge~1ayXVW~29000 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 3 ); /*  first-set-bit~1ayXVW~28999 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 4 ); /*  any-bits-set?~1ayXVW~28998 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 5 ); /*  bit-set?~1ayXVW~28997 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 6 ); /*  bit-count~1ayXVW~28996 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 7 ); /*  ash~1ayXVW~28995 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 8 ); /*  booleans->integer~1ayXVW~28994 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 9 ); /*  list->integer~1ayXVW~28993 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 10 ); /*  integer->list~1ayXVW~28992 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 11 ); /*  reverse-bit-field~1ayXVW~28991 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 12 ); /*  bit-reverse~1ayXVW~28990 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 13 ); /*  log2-binary-factors~1ayXVW~28989 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 14 ); /*  logcount~1ayXVW~28988 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 15 ); /*  integer-length~1ayXVW~28987 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 16 ); /*  arithmetic-shift~1ayXVW~28986 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 17 ); /*  rotate-bit-field~1ayXVW~28985 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 18 ); /*  copy-bit-field~1ayXVW~28984 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 19 ); /*  bit-field~1ayXVW~28983 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 20 ); /*  copy-bit~1ayXVW~28982 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 21 ); /*  logbit?~1ayXVW~28981 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 22 ); /*  logtest~1ayXVW~28980 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 23 ); /*  lognot~1ayXVW~28979 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 24 ); /*  logxor~1ayXVW~28978 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 25 ); /*  logior~1ayXVW~28977 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 26 ); /*  logand~1ayXVW~28976 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 27 ); /*  logical:ash-4~1ayXVW~28975 */
  twobit_lambda( compiled_start_1_4, 29, 0 );
  twobit_setglbl( 27 ); /*  logical:ash-4~1ayXVW~28975 */
  twobit_global( 30 ); /* bitwise-and */
  twobit_setglbl( 26 ); /*  logand~1ayXVW~28976 */
  twobit_global( 31 ); /* bitwise-ior */
  twobit_setglbl( 25 ); /*  logior~1ayXVW~28977 */
  twobit_global( 32 ); /* bitwise-xor */
  twobit_setglbl( 24 ); /*  logxor~1ayXVW~28978 */
  twobit_global( 33 ); /* bitwise-not */
  twobit_setglbl( 23 ); /*  lognot~1ayXVW~28979 */
  twobit_lambda( compiled_start_1_5, 35, 0 );
  twobit_setglbl( 22 ); /*  logtest~1ayXVW~28980 */
  twobit_lambda( compiled_start_1_6, 37, 0 );
  twobit_setglbl( 21 ); /*  logbit?~1ayXVW~28981 */
  twobit_lambda( compiled_start_1_7, 39, 0 );
  twobit_setglbl( 20 ); /*  copy-bit~1ayXVW~28982 */
  twobit_lambda( compiled_start_1_8, 41, 0 );
  twobit_setglbl( 19 ); /*  bit-field~1ayXVW~28983 */
  twobit_lambda( compiled_start_1_9, 43, 0 );
  twobit_setglbl( 18 ); /*  copy-bit-field~1ayXVW~28984 */
  twobit_lambda( compiled_start_1_10, 45, 0 );
  twobit_setglbl( 17 ); /*  rotate-bit-field~1ayXVW~28985 */
  twobit_lambda( compiled_start_1_11, 47, 0 );
  twobit_setglbl( 16 ); /*  arithmetic-shift~1ayXVW~28986 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_12, 49, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_13, 51, 1 );
  twobit_setglbl( 15 ); /*  integer-length~1ayXVW~28987 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_14, 53, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_15, 55, 1 );
  twobit_setglbl( 14 ); /*  logcount~1ayXVW~28988 */
  twobit_lambda( compiled_start_1_16, 57, 0 );
  twobit_setglbl( 13 ); /*  log2-binary-factors~1ayXVW~28989 */
  twobit_lambda( compiled_start_1_17, 59, 0 );
  twobit_setglbl( 12 ); /*  bit-reverse~1ayXVW~28990 */
  twobit_lambda( compiled_start_1_18, 61, 0 );
  twobit_setglbl( 11 ); /*  reverse-bit-field~1ayXVW~28991 */
  twobit_lambda( compiled_start_1_19, 63, 0 );
  twobit_setglbl( 10 ); /*  integer->list~1ayXVW~28992 */
  twobit_lambda( compiled_start_1_20, 65, 0 );
  twobit_setglbl( 9 ); /*  list->integer~1ayXVW~28993 */
  twobit_lambda( compiled_start_1_21, 67, 0 );
  twobit_setglbl( 8 ); /*  booleans->integer~1ayXVW~28994 */
  twobit_global( 16 ); /*  arithmetic-shift~1ayXVW~28986 */
  twobit_setglbl( 7 ); /*  ash~1ayXVW~28995 */
  twobit_global( 14 ); /*  logcount~1ayXVW~28988 */
  twobit_setglbl( 6 ); /*  bit-count~1ayXVW~28996 */
  twobit_global( 21 ); /*  logbit?~1ayXVW~28981 */
  twobit_setglbl( 5 ); /*  bit-set?~1ayXVW~28997 */
  twobit_global( 22 ); /*  logtest~1ayXVW~28980 */
  twobit_setglbl( 4 ); /*  any-bits-set?~1ayXVW~28998 */
  twobit_global( 13 ); /*  log2-binary-factors~1ayXVW~28989 */
  twobit_setglbl( 3 ); /*  first-set-bit~1ayXVW~28999 */
  twobit_global( 68 ); /* bitwise-if */
  twobit_setglbl( 2 ); /*  bitwise-merge~1ayXVW~29000 */
  twobit_global( 69 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* bitwise-arithmetic-shift-right */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  logand~1ayXVW~28976 */
  twobit_setrtn( 1003, compiled_block_1_1003 );
  twobit_invoke( 2 );
  twobit_label( 1003, compiled_block_1_1003 );
  twobit_load( 0, 0 );
  twobit_op1_31( 64, compiled_temp_1_64 ); /* zero? */
  twobit_op1_9(); /* not */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_6( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* expt */
  twobit_setrtn( 1004, compiled_block_1_1004 );
  twobit_invoke( 2 );
  twobit_label( 1004, compiled_block_1_1004 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 2 ); /*  logtest~1ayXVW~28980 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_7( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 3 );
  twobit_branchf( 1007, compiled_block_1_1007 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  arithmetic-shift~1ayXVW~28986 */
  twobit_setrtn( 1008, compiled_block_1_1008 );
  twobit_invoke( 2 );
  twobit_label( 1008, compiled_block_1_1008 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  logior~1ayXVW~28977 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1007, compiled_block_1_1007 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  arithmetic-shift~1ayXVW~28986 */
  twobit_setrtn( 1010, compiled_block_1_1010 );
  twobit_invoke( 2 );
  twobit_label( 1010, compiled_block_1_1010 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  lognot~1ayXVW~28979 */
  twobit_setrtn( 1011, compiled_block_1_1011 );
  twobit_invoke( 1 );
  twobit_label( 1011, compiled_block_1_1011 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 4 ); /*  logand~1ayXVW~28976 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_8( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_reg( 3 );
  twobit_op2_62( 2, 62, compiled_temp_1_62 ); /* - */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  ash~1ayXVW~28995 */
  twobit_setrtn( 1013, compiled_block_1_1013 );
  twobit_invoke( 2 );
  twobit_label( 1013, compiled_block_1_1013 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  lognot~1ayXVW~28979 */
  twobit_setrtn( 1014, compiled_block_1_1014 );
  twobit_invoke( 1 );
  twobit_label( 1014, compiled_block_1_1014 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_stack( 1 );
  twobit_op1_32( 63, compiled_temp_1_63 ); /* -- */
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 3 ); /*  arithmetic-shift~1ayXVW~28986 */
  twobit_setrtn( 1015, compiled_block_1_1015 );
  twobit_invoke( 2 );
  twobit_label( 1015, compiled_block_1_1015 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_global( 4 ); /*  logand~1ayXVW~28976 */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_9( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 2 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op2_62( 3, 61, compiled_temp_1_61 ); /* - */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  ash~1ayXVW~28995 */
  twobit_setrtn( 1017, compiled_block_1_1017 );
  twobit_invoke( 2 );
  twobit_label( 1017, compiled_block_1_1017 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  lognot~1ayXVW~28979 */
  twobit_setrtn( 1018, compiled_block_1_1018 );
  twobit_invoke( 1 );
  twobit_label( 1018, compiled_block_1_1018 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 3 ); /*  arithmetic-shift~1ayXVW~28986 */
  twobit_setrtn( 1019, compiled_block_1_1019 );
  twobit_invoke( 2 );
  twobit_label( 1019, compiled_block_1_1019 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 2, 1 );
  twobit_load( 1, 2 );
  twobit_global( 3 ); /*  arithmetic-shift~1ayXVW~28986 */
  twobit_setrtn( 1020, compiled_block_1_1020 );
  twobit_invoke( 2 );
  twobit_label( 1020, compiled_block_1_1020 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 3, 3 );
  twobit_load( 1, 4 );
  twobit_global( 4 ); /* bitwise-if */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_10( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 3, 3 );
  twobit_reg( 2 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_reg( 4 );
  twobit_op2_62( 3, 58, compiled_temp_1_58 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 2 );
  twobit_stack( 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* modulo */
  twobit_setrtn( 1022, compiled_block_1_1022 );
  twobit_invoke( 2 );
  twobit_label( 1022, compiled_block_1_1022 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 2 ); /*  ash~1ayXVW~28995 */
  twobit_setrtn( 1023, compiled_block_1_1023 );
  twobit_invoke( 2 );
  twobit_label( 1023, compiled_block_1_1023 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  lognot~1ayXVW~28979 */
  twobit_setrtn( 1024, compiled_block_1_1024 );
  twobit_invoke( 1 );
  twobit_label( 1024, compiled_block_1_1024 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_stack( 3 );
  twobit_op1_32( 59, compiled_temp_1_59 ); /* -- */
  twobit_setreg( 2 );
  twobit_load( 1, 4 );
  twobit_global( 4 ); /*  arithmetic-shift~1ayXVW~28986 */
  twobit_setrtn( 1025, compiled_block_1_1025 );
  twobit_invoke( 2 );
  twobit_label( 1025, compiled_block_1_1025 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 5 );
  twobit_global( 5 ); /*  logand~1ayXVW~28976 */
  twobit_setrtn( 1026, compiled_block_1_1026 );
  twobit_invoke( 2 );
  twobit_label( 1026, compiled_block_1_1026 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_movereg( 4, 1 );
  twobit_stack( 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_global( 4 ); /*  arithmetic-shift~1ayXVW~28986 */
  twobit_setrtn( 1027, compiled_block_1_1027 );
  twobit_invoke( 2 );
  twobit_label( 1027, compiled_block_1_1027 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 5 );
  twobit_global( 5 ); /*  logand~1ayXVW~28976 */
  twobit_setrtn( 1028, compiled_block_1_1028 );
  twobit_invoke( 2 );
  twobit_label( 1028, compiled_block_1_1028 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_stack( 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_load( 2, 2 );
  twobit_op2_62( 2, 60, compiled_temp_1_60 ); /* - */
  twobit_setreg( 2 );
  twobit_load( 1, 6 );
  twobit_global( 4 ); /*  arithmetic-shift~1ayXVW~28986 */
  twobit_setrtn( 1029, compiled_block_1_1029 );
  twobit_invoke( 2 );
  twobit_label( 1029, compiled_block_1_1029 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 7 );
  twobit_global( 6 ); /*  logior~1ayXVW~28977 */
  twobit_setrtn( 1030, compiled_block_1_1030 );
  twobit_invoke( 2 );
  twobit_label( 1030, compiled_block_1_1030 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_global( 4 ); /*  arithmetic-shift~1ayXVW~28986 */
  twobit_setrtn( 1031, compiled_block_1_1031 );
  twobit_invoke( 2 );
  twobit_label( 1031, compiled_block_1_1031 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 2, 3 );
  twobit_load( 1, 5 );
  twobit_global( 2 ); /*  ash~1ayXVW~28995 */
  twobit_setrtn( 1032, compiled_block_1_1032 );
  twobit_invoke( 2 );
  twobit_label( 1032, compiled_block_1_1032 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  lognot~1ayXVW~28979 */
  twobit_setrtn( 1033, compiled_block_1_1033 );
  twobit_invoke( 1 );
  twobit_label( 1033, compiled_block_1_1033 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 4 );
  twobit_global( 5 ); /*  logand~1ayXVW~28976 */
  twobit_setrtn( 1034, compiled_block_1_1034 );
  twobit_invoke( 2 );
  twobit_label( 1034, compiled_block_1_1034 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 7 );
  twobit_global( 6 ); /*  logior~1ayXVW~28977 */
  twobit_pop( 7 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_11( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op2imm_branchf_635( fixnum(0), 50, compiled_temp_1_50, 1037, compiled_block_1_1037 ); /* internal:branchf-</imm */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 2 );
  twobit_op1_32( 51, compiled_temp_1_51 ); /* -- */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* expt */
  twobit_setrtn( 1038, compiled_block_1_1038 );
  twobit_invoke( 2 );
  twobit_label( 1038, compiled_block_1_1038 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2imm_branchf_635( fixnum(0), 52, compiled_temp_1_52, 1040, compiled_block_1_1040 ); /* internal:branchf-</imm */
  twobit_load( 3, 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 3, 53, compiled_temp_1_53 ); /* + */
  twobit_op2_65( 4, 54, compiled_temp_1_54 ); /* quotient */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 3, 55, compiled_temp_1_55 ); /* + */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1040, compiled_block_1_1040 );
  twobit_stack( 1 );
  twobit_op2_65( 4, 56, compiled_temp_1_56 ); /* quotient */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1037, compiled_block_1_1037 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* expt */
  twobit_setrtn( 1041, compiled_block_1_1041 );
  twobit_invoke( 2 );
  twobit_label( 1041, compiled_block_1_1041 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_63( 3, 57, compiled_temp_1_57 ); /* * */
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_12( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_614( 1043, compiled_block_1_1043 ); /* internal:branchf-fixnum? */
  twobit_reg( 1 );
  twobit_op2imm_452( fixnum(-8) ); /* <:fix:fix */
  twobit_branchf( 1045, compiled_block_1_1045 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_skip( 1042, compiled_block_1_1042 );
  twobit_label( 1045, compiled_block_1_1045 );
  twobit_reg( 1 );
  twobit_op2imm_452( fixnum(8) ); /* <:fix:fix */
  twobit_branchf( 1047, compiled_block_1_1047 );
  twobit_reg( 1 );
  twobit_op2imm_522( fixnum(-8) ); /* -:idx:idx */
  twobit_setreg( 4 );
  twobit_const( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_skip( 1042, compiled_block_1_1042 );
  twobit_label( 1047, compiled_block_1_1047 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_skip( 1042, compiled_block_1_1042 );
  twobit_label( 1043, compiled_block_1_1043 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_label( 1042, compiled_block_1_1042 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_452( fixnum(2) ); /* <:fix:fix */
  twobit_branchf( 1049, compiled_block_1_1049 );
  twobit_reg( 4 );
  twobit_op2imm_452( fixnum(1) ); /* <:fix:fix */
  twobit_branchf( 1051, compiled_block_1_1051 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_op2_61( 2, 45, compiled_temp_1_45 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_global( 2 ); /*  logical:ash-4~1ayXVW~28975 */
  twobit_setrtn( 1052, compiled_block_1_1052 );
  twobit_invoke( 1 );
  twobit_label( 1052, compiled_block_1_1052 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1051, compiled_block_1_1051 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_61( 2, 46, compiled_temp_1_46 ); /* + */
  twobit_return();
  twobit_label( 1049, compiled_block_1_1049 );
  twobit_reg( 4 );
  twobit_op2imm_452( fixnum(3) ); /* <:fix:fix */
  twobit_branchf( 1055, compiled_block_1_1055 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 2, 47, compiled_temp_1_47 ); /* + */
  twobit_return();
  twobit_label( 1055, compiled_block_1_1055 );
  twobit_reg( 4 );
  twobit_op2imm_452( fixnum(4) ); /* <:fix:fix */
  twobit_branchf( 1057, compiled_block_1_1057 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_op2_61( 2, 48, compiled_temp_1_48 ); /* + */
  twobit_return();
  twobit_label( 1057, compiled_block_1_1057 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_op2_61( 2, 49, compiled_temp_1_49 ); /* + */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_13( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_14( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_612( 42, compiled_temp_1_42, 1060, compiled_block_1_1060 ); /* internal:branchf-zero? */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1060, compiled_block_1_1060 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_imm_const( fixnum(16) ); /* 16 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_65( 4, 43, compiled_temp_1_43 ); /* quotient */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( fixnum(16) ); /* 16 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* modulo */
  twobit_setrtn( 1061, compiled_block_1_1061 );
  twobit_invoke( 2 );
  twobit_label( 1061, compiled_block_1_1061 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg_op1_check_651(reg(4),1062,compiled_block_1_1062); /* internal:check-fixnum? with (4 0 0) */
  twobit_const( 2 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_reg_op2_check_661(reg(4),reg(3),1062,compiled_block_1_1062); /* internal:check-range with (4 0 0) */
  twobit_const( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_load( 3, 2 );
  twobit_op2_61( 3, 44, compiled_temp_1_44 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1062, compiled_block_1_1062 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_15( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(0), 40, compiled_temp_1_40, 1065, compiled_block_1_1065 ); /* internal:branchf-</imm */
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  lognot~1ayXVW~28979 */
  twobit_setrtn( 1066, compiled_block_1_1066 );
  twobit_invoke( 1 );
  twobit_label( 1066, compiled_block_1_1066 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 0 );
  twobit_invoke( 2 );
  twobit_label( 1065, compiled_block_1_1065 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_636( fixnum(0), 41, compiled_temp_1_41, 1069, compiled_block_1_1069 ); /* internal:branchf->/imm */
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 1069, compiled_block_1_1069 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_16( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op1_32( 38, compiled_temp_1_38 ); /* -- */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  logand~1ayXVW~28976 */
  twobit_setrtn( 1071, compiled_block_1_1071 );
  twobit_invoke( 2 );
  twobit_label( 1071, compiled_block_1_1071 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  integer-length~1ayXVW~28987 */
  twobit_setrtn( 1072, compiled_block_1_1072 );
  twobit_invoke( 1 );
  twobit_label( 1072, compiled_block_1_1072 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 4, 39, compiled_temp_1_39 ); /* + */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_17( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 1, 33, compiled_temp_1_33 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 2 );
  twobit_op2imm_132( fixnum(0), 34, compiled_temp_1_34 ); /* < */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 3 );
  twobit_branchf( 1074, compiled_block_1_1074 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  lognot~1ayXVW~28979 */
  twobit_setrtn( 1075, compiled_block_1_1075 );
  twobit_invoke( 1 );
  twobit_label( 1075, compiled_block_1_1075 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_skip( 1073, compiled_block_1_1073 );
  twobit_label( 1074, compiled_block_1_1074 );
  twobit_movereg( 2, 1 );
  twobit_label( 1073, compiled_block_1_1073 );
  twobit_store( 1, 3 );
  twobit_load( 2, 1 );
  twobit_store( 2, 4 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_35, 4, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_load( 2, 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_35( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 2 );
  twobit_op2imm_branchf_635( fixnum(0), 36, compiled_temp_1_36, 1077, compiled_block_1_1077 ); /* internal:branchf-</imm */
  twobit_lexical( 0, 2 );
  twobit_branchf( 1079, compiled_block_1_1079 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /*  lognot~1ayXVW~28979 */
  twobit_invoke( 1 );
  twobit_label( 1079, compiled_block_1_1079 );
  twobit_reg( 3 );
  twobit_return();
  twobit_label( 1077, compiled_block_1_1077 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 3, 1 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 2, 37, compiled_temp_1_37 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  arithmetic-shift~1ayXVW~28986 */
  twobit_setrtn( 1081, compiled_block_1_1081 );
  twobit_invoke( 2 );
  twobit_label( 1081, compiled_block_1_1081 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  arithmetic-shift~1ayXVW~28986 */
  twobit_setrtn( 1082, compiled_block_1_1082 );
  twobit_invoke( 2 );
  twobit_label( 1082, compiled_block_1_1082 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 2, 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  logand~1ayXVW~28976 */
  twobit_setrtn( 1083, compiled_block_1_1083 );
  twobit_invoke( 2 );
  twobit_label( 1083, compiled_block_1_1083 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 4 ); /*  logior~1ayXVW~28977 */
  twobit_setrtn( 1084, compiled_block_1_1084 );
  twobit_invoke( 2 );
  twobit_label( 1084, compiled_block_1_1084 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 1, 3 );
  twobit_load( 2, 4 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_18( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_reg( 3 );
  twobit_op2_62( 2, 31, compiled_temp_1_31 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_movereg( 4, 2 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  ash~1ayXVW~28995 */
  twobit_setrtn( 1087, compiled_block_1_1087 );
  twobit_invoke( 2 );
  twobit_label( 1087, compiled_block_1_1087 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  lognot~1ayXVW~28979 */
  twobit_setrtn( 1088, compiled_block_1_1088 );
  twobit_invoke( 1 );
  twobit_label( 1088, compiled_block_1_1088 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_stack( 1 );
  twobit_op1_32( 32, compiled_temp_1_32 ); /* -- */
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 3 ); /*  arithmetic-shift~1ayXVW~28986 */
  twobit_setrtn( 1089, compiled_block_1_1089 );
  twobit_invoke( 2 );
  twobit_label( 1089, compiled_block_1_1089 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_global( 4 ); /*  logand~1ayXVW~28976 */
  twobit_setrtn( 1090, compiled_block_1_1090 );
  twobit_invoke( 2 );
  twobit_label( 1090, compiled_block_1_1090 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 4 );
  twobit_global( 5 ); /*  bit-reverse~1ayXVW~28990 */
  twobit_setrtn( 1091, compiled_block_1_1091 );
  twobit_invoke( 2 );
  twobit_label( 1091, compiled_block_1_1091 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 3 ); /*  arithmetic-shift~1ayXVW~28986 */
  twobit_setrtn( 1092, compiled_block_1_1092 );
  twobit_invoke( 2 );
  twobit_label( 1092, compiled_block_1_1092 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 3 );
  twobit_load( 2, 1 );
  twobit_global( 1 ); /*  ash~1ayXVW~28995 */
  twobit_setrtn( 1093, compiled_block_1_1093 );
  twobit_invoke( 2 );
  twobit_label( 1093, compiled_block_1_1093 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  lognot~1ayXVW~28979 */
  twobit_setrtn( 1094, compiled_block_1_1094 );
  twobit_invoke( 1 );
  twobit_label( 1094, compiled_block_1_1094 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 4 ); /*  logand~1ayXVW~28976 */
  twobit_setrtn( 1095, compiled_block_1_1095 );
  twobit_invoke( 2 );
  twobit_label( 1095, compiled_block_1_1095 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 4 );
  twobit_global( 6 ); /*  logior~1ayXVW~28977 */
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_19( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1098, compiled_block_1_1098 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_25, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1098, compiled_block_1_1098 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg_op1_check_652(reg(2),1105,compiled_block_1_1105); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_movereg( 1, 2 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 4, 26, compiled_temp_1_26 ); /* + */
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_27, 5, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_label( 1105, compiled_block_1_1105 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_25( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_638( fixnum(0), 30, compiled_temp_1_30, 1100, compiled_block_1_1100 ); /* internal:branchf-<=/imm */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1100, compiled_block_1_1100 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 3 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  arithmetic-shift~1ayXVW~28986 */
  twobit_setrtn( 1101, compiled_block_1_1101 );
  twobit_invoke( 2 );
  twobit_label( 1101, compiled_block_1_1101 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* odd? */
  twobit_setrtn( 1102, compiled_block_1_1102 );
  twobit_invoke( 1 );
  twobit_label( 1102, compiled_block_1_1102 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_27( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(0), 28, compiled_temp_1_28, 1107, compiled_block_1_1107 ); /* internal:branchf-</imm */
  twobit_reg( 3 );
  twobit_return();
  twobit_label( 1107, compiled_block_1_1107 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 1, 29, compiled_temp_1_29 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  arithmetic-shift~1ayXVW~28986 */
  twobit_setrtn( 1108, compiled_block_1_1108 );
  twobit_invoke( 2 );
  twobit_label( 1108, compiled_block_1_1108 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* odd? */
  twobit_setrtn( 1109, compiled_block_1_1109 );
  twobit_invoke( 1 );
  twobit_label( 1109, compiled_block_1_1109 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_load( 3, 4 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_20( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_22, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_22( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1113, compiled_block_1_1113 ); /* internal:branchf-null? */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1113, compiled_block_1_1113 );
  twobit_reg_op1_check_652(reg(1),1114,compiled_block_1_1114); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_branchf( 1116, compiled_block_1_1116 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_skip( 1115, compiled_block_1_1115 );
  twobit_label( 1116, compiled_block_1_1116 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_label( 1115, compiled_block_1_1115 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_61( 4, 23, compiled_temp_1_23 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_61( 4, 24, compiled_temp_1_24 ); /* + */
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 1114, compiled_block_1_1114 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_21( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_global( 1 ); /*  list->integer~1ayXVW~28993 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


RTYPE twobit_thunk_cc3fbc44f7f83063ed8a2ec05da28047_0(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_1_0(CONT_ACTUALS));
}
static RTYPE compiled_block_2_1004( CONT_PARAMS );
static RTYPE compiled_block_2_1003( CONT_PARAMS );
static RTYPE compiled_start_2_0( CONT_PARAMS );
static RTYPE compiled_start_2_3( CONT_PARAMS );
static RTYPE compiled_start_2_2( CONT_PARAMS );
static RTYPE compiled_start_2_1( CONT_PARAMS );

static RTYPE compiled_start_2_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_2_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_2_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1003, compiled_block_2_1003 );
  twobit_invoke( 8 );
  twobit_label( 1003, compiled_block_2_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1004, compiled_block_2_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_2_1004 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_cc3fbc44f7f83063ed8a2ec05da28047_1(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_2_0(CONT_ACTUALS));
}
codeptr_t CDECL twobit_load_table[] = { 
  twobit_thunk_cc3fbc44f7f83063ed8a2ec05da28047_0,
  twobit_thunk_cc3fbc44f7f83063ed8a2ec05da28047_1,
  0  /* The table may be empty; some compilers complain */
};

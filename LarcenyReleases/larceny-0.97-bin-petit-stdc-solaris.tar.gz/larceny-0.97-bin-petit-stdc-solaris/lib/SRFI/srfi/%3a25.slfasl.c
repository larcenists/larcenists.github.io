/* Generated from /proj/will/pnkfelix/larcenytest/larceny-petit-Nightly-2009-08-19/larceny_src/lib/SRFI/srfi/%3a25.slfasl */
#include "petit-instr.h"

static RTYPE compiled_block_1_2282( CONT_PARAMS );
static RTYPE compiled_block_1_2281( CONT_PARAMS );
static RTYPE compiled_start_1_0( CONT_PARAMS );
static RTYPE compiled_block_1_1733( CONT_PARAMS );
static RTYPE compiled_block_1_1627( CONT_PARAMS );
static RTYPE compiled_block_1_1550( CONT_PARAMS );
static RTYPE compiled_block_1_1473( CONT_PARAMS );
static RTYPE compiled_block_1_1311( CONT_PARAMS );
static RTYPE compiled_block_1_1018( CONT_PARAMS );
static RTYPE compiled_block_1_1017( CONT_PARAMS );
static RTYPE compiled_block_1_1016( CONT_PARAMS );
static RTYPE compiled_block_1_1015( CONT_PARAMS );
static RTYPE compiled_block_1_1014( CONT_PARAMS );
static RTYPE compiled_block_1_1013( CONT_PARAMS );
static RTYPE compiled_start_1_3( CONT_PARAMS );
static RTYPE compiled_block_1_2279( CONT_PARAMS );
static RTYPE compiled_block_1_2265( CONT_PARAMS );
static RTYPE compiled_block_1_2259( CONT_PARAMS );
static RTYPE compiled_block_1_2258( CONT_PARAMS );
static RTYPE compiled_temp_1_117( CONT_PARAMS );
static RTYPE compiled_block_1_2257( CONT_PARAMS );
static RTYPE compiled_block_1_2256( CONT_PARAMS );
static RTYPE compiled_block_1_2255( CONT_PARAMS );
static RTYPE compiled_block_1_2250( CONT_PARAMS );
static RTYPE compiled_start_1_115( CONT_PARAMS );
static RTYPE compiled_temp_1_122( CONT_PARAMS );
static RTYPE compiled_block_1_2277( CONT_PARAMS );
static RTYPE compiled_block_1_2270( CONT_PARAMS );
static RTYPE compiled_block_1_2269( CONT_PARAMS );
static RTYPE compiled_block_1_2268( CONT_PARAMS );
static RTYPE compiled_block_1_2267( CONT_PARAMS );
static RTYPE compiled_temp_1_120( CONT_PARAMS );
static RTYPE compiled_start_1_119( CONT_PARAMS );
static RTYPE compiled_temp_1_126( CONT_PARAMS );
static RTYPE compiled_block_1_2275( CONT_PARAMS );
static RTYPE compiled_temp_1_125( CONT_PARAMS );
static RTYPE compiled_block_1_2274( CONT_PARAMS );
static RTYPE compiled_block_1_2273( CONT_PARAMS );
static RTYPE compiled_temp_1_124( CONT_PARAMS );
static RTYPE compiled_block_1_2272( CONT_PARAMS );
static RTYPE compiled_temp_1_123( CONT_PARAMS );
static RTYPE compiled_start_1_121( CONT_PARAMS );
static RTYPE compiled_temp_1_128( CONT_PARAMS );
static RTYPE compiled_block_1_2263( CONT_PARAMS );
static RTYPE compiled_block_1_2262( CONT_PARAMS );
static RTYPE compiled_block_1_2261( CONT_PARAMS );
static RTYPE compiled_temp_1_127( CONT_PARAMS );
static RTYPE compiled_start_1_118( CONT_PARAMS );
static RTYPE compiled_temp_1_130( CONT_PARAMS );
static RTYPE compiled_block_1_2253( CONT_PARAMS );
static RTYPE compiled_block_1_2252( CONT_PARAMS );
static RTYPE compiled_temp_1_129( CONT_PARAMS );
static RTYPE compiled_start_1_116( CONT_PARAMS );
static RTYPE compiled_start_1_114( CONT_PARAMS );
static RTYPE compiled_start_1_131( CONT_PARAMS );
static RTYPE compiled_start_1_132( CONT_PARAMS );
static RTYPE compiled_block_1_2217( CONT_PARAMS );
static RTYPE compiled_block_1_2218( CONT_PARAMS );
static RTYPE compiled_block_1_2219( CONT_PARAMS );
static RTYPE compiled_block_1_2221( CONT_PARAMS );
static RTYPE compiled_block_1_2220( CONT_PARAMS );
static RTYPE compiled_temp_1_133( CONT_PARAMS );
static RTYPE compiled_block_1_2216( CONT_PARAMS );
static RTYPE compiled_block_1_2215( CONT_PARAMS );
static RTYPE compiled_block_1_2214( CONT_PARAMS );
static RTYPE compiled_start_1_113( CONT_PARAMS );
static RTYPE compiled_block_1_2225( CONT_PARAMS );
static RTYPE compiled_block_1_2245( CONT_PARAMS );
static RTYPE compiled_block_1_2243( CONT_PARAMS );
static RTYPE compiled_block_1_2223( CONT_PARAMS );
static RTYPE compiled_block_1_2241( CONT_PARAMS );
static RTYPE compiled_temp_1_141( CONT_PARAMS );
static RTYPE compiled_block_1_2239( CONT_PARAMS );
static RTYPE compiled_temp_1_140( CONT_PARAMS );
static RTYPE compiled_block_1_2237( CONT_PARAMS );
static RTYPE compiled_block_1_2236( CONT_PARAMS );
static RTYPE compiled_block_1_2235( CONT_PARAMS );
static RTYPE compiled_block_1_2229( CONT_PARAMS );
static RTYPE compiled_block_1_2234( CONT_PARAMS );
static RTYPE compiled_block_1_2233( CONT_PARAMS );
static RTYPE compiled_block_1_2232( CONT_PARAMS );
static RTYPE compiled_temp_1_139( CONT_PARAMS );
static RTYPE compiled_block_1_2230( CONT_PARAMS );
static RTYPE compiled_temp_1_138( CONT_PARAMS );
static RTYPE compiled_block_1_2227( CONT_PARAMS );
static RTYPE compiled_temp_1_137( CONT_PARAMS );
static RTYPE compiled_temp_1_136( CONT_PARAMS );
static RTYPE compiled_block_1_2224( CONT_PARAMS );
static RTYPE compiled_temp_1_135( CONT_PARAMS );
static RTYPE compiled_start_1_134( CONT_PARAMS );
static RTYPE compiled_block_1_2200( CONT_PARAMS );
static RTYPE compiled_block_1_2199( CONT_PARAMS );
static RTYPE compiled_block_1_2198( CONT_PARAMS );
static RTYPE compiled_start_1_112( CONT_PARAMS );
static RTYPE compiled_block_1_2211( CONT_PARAMS );
static RTYPE compiled_block_1_2210( CONT_PARAMS );
static RTYPE compiled_temp_1_145( CONT_PARAMS );
static RTYPE compiled_block_1_2202( CONT_PARAMS );
static RTYPE compiled_temp_1_143( CONT_PARAMS );
static RTYPE compiled_start_1_142( CONT_PARAMS );
static RTYPE compiled_block_1_2207( CONT_PARAMS );
static RTYPE compiled_block_1_2206( CONT_PARAMS );
static RTYPE compiled_temp_1_147( CONT_PARAMS );
static RTYPE compiled_block_1_2204( CONT_PARAMS );
static RTYPE compiled_temp_1_146( CONT_PARAMS );
static RTYPE compiled_start_1_144( CONT_PARAMS );
static RTYPE compiled_block_1_2197( CONT_PARAMS );
static RTYPE compiled_block_1_2196( CONT_PARAMS );
static RTYPE compiled_block_1_2195( CONT_PARAMS );
static RTYPE compiled_start_1_111( CONT_PARAMS );
static RTYPE compiled_block_1_2193( CONT_PARAMS );
static RTYPE compiled_block_1_2189( CONT_PARAMS );
static RTYPE compiled_block_1_2192( CONT_PARAMS );
static RTYPE compiled_block_1_2191( CONT_PARAMS );
static RTYPE compiled_block_1_2190( CONT_PARAMS );
static RTYPE compiled_block_1_2188( CONT_PARAMS );
static RTYPE compiled_start_1_110( CONT_PARAMS );
static RTYPE compiled_block_1_2186( CONT_PARAMS );
static RTYPE compiled_block_1_2182( CONT_PARAMS );
static RTYPE compiled_block_1_2185( CONT_PARAMS );
static RTYPE compiled_block_1_2184( CONT_PARAMS );
static RTYPE compiled_block_1_2183( CONT_PARAMS );
static RTYPE compiled_block_1_2181( CONT_PARAMS );
static RTYPE compiled_start_1_109( CONT_PARAMS );
static RTYPE compiled_block_1_2179( CONT_PARAMS );
static RTYPE compiled_block_1_2177( CONT_PARAMS );
static RTYPE compiled_block_1_2175( CONT_PARAMS );
static RTYPE compiled_temp_1_148( CONT_PARAMS );
static RTYPE compiled_block_1_2173( CONT_PARAMS );
static RTYPE compiled_block_1_2169( CONT_PARAMS );
static RTYPE compiled_block_1_2170( CONT_PARAMS );
static RTYPE compiled_block_1_2167( CONT_PARAMS );
static RTYPE compiled_block_1_2165( CONT_PARAMS );
static RTYPE compiled_block_1_2164( CONT_PARAMS );
static RTYPE compiled_block_1_2159( CONT_PARAMS );
static RTYPE compiled_block_1_2161( CONT_PARAMS );
static RTYPE compiled_block_1_2160( CONT_PARAMS );
static RTYPE compiled_block_1_2157( CONT_PARAMS );
static RTYPE compiled_block_1_2156( CONT_PARAMS );
static RTYPE compiled_block_1_2154( CONT_PARAMS );
static RTYPE compiled_block_1_2150( CONT_PARAMS );
static RTYPE compiled_block_1_2151( CONT_PARAMS );
static RTYPE compiled_block_1_2147( CONT_PARAMS );
static RTYPE compiled_start_1_108( CONT_PARAMS );
static RTYPE compiled_start_1_107( CONT_PARAMS );
static RTYPE compiled_block_1_2136( CONT_PARAMS );
static RTYPE compiled_block_1_2141( CONT_PARAMS );
static RTYPE compiled_block_1_2139( CONT_PARAMS );
static RTYPE compiled_block_1_2143( CONT_PARAMS );
static RTYPE compiled_block_1_2142( CONT_PARAMS );
static RTYPE compiled_block_1_2140( CONT_PARAMS );
static RTYPE compiled_temp_1_151( CONT_PARAMS );
static RTYPE compiled_block_1_2138( CONT_PARAMS );
static RTYPE compiled_temp_1_150( CONT_PARAMS );
static RTYPE compiled_start_1_149( CONT_PARAMS );
static RTYPE compiled_start_1_106( CONT_PARAMS );
static RTYPE compiled_block_1_2131( CONT_PARAMS );
static RTYPE compiled_block_1_2133( CONT_PARAMS );
static RTYPE compiled_block_1_2132( CONT_PARAMS );
static RTYPE compiled_block_1_2130( CONT_PARAMS );
static RTYPE compiled_start_1_152( CONT_PARAMS );
static RTYPE compiled_block_1_2127( CONT_PARAMS );
static RTYPE compiled_block_1_2126( CONT_PARAMS );
static RTYPE compiled_block_1_2125( CONT_PARAMS );
static RTYPE compiled_start_1_105( CONT_PARAMS );
static RTYPE compiled_block_1_2122( CONT_PARAMS );
static RTYPE compiled_block_1_2119( CONT_PARAMS );
static RTYPE compiled_block_1_2121( CONT_PARAMS );
static RTYPE compiled_block_1_2124( CONT_PARAMS );
static RTYPE compiled_temp_1_154( CONT_PARAMS );
static RTYPE compiled_temp_1_153( CONT_PARAMS );
static RTYPE compiled_start_1_104( CONT_PARAMS );
static RTYPE compiled_block_1_2106( CONT_PARAMS );
static RTYPE compiled_block_1_2108( CONT_PARAMS );
static RTYPE compiled_temp_1_156( CONT_PARAMS );
static RTYPE compiled_temp_1_155( CONT_PARAMS );
static RTYPE compiled_start_1_103( CONT_PARAMS );
static RTYPE compiled_block_1_2114( CONT_PARAMS );
static RTYPE compiled_block_1_2111( CONT_PARAMS );
static RTYPE compiled_block_1_2112( CONT_PARAMS );
static RTYPE compiled_block_1_2115( CONT_PARAMS );
static RTYPE compiled_block_1_2113( CONT_PARAMS );
static RTYPE compiled_temp_1_160( CONT_PARAMS );
static RTYPE compiled_temp_1_159( CONT_PARAMS );
static RTYPE compiled_block_1_2110( CONT_PARAMS );
static RTYPE compiled_temp_1_158( CONT_PARAMS );
static RTYPE compiled_start_1_157( CONT_PARAMS );
static RTYPE compiled_block_1_2095( CONT_PARAMS );
static RTYPE compiled_block_1_2094( CONT_PARAMS );
static RTYPE compiled_block_1_2097( CONT_PARAMS );
static RTYPE compiled_temp_1_162( CONT_PARAMS );
static RTYPE compiled_temp_1_161( CONT_PARAMS );
static RTYPE compiled_start_1_102( CONT_PARAMS );
static RTYPE compiled_block_1_2102( CONT_PARAMS );
static RTYPE compiled_block_1_2100( CONT_PARAMS );
static RTYPE compiled_block_1_2101( CONT_PARAMS );
static RTYPE compiled_block_1_2103( CONT_PARAMS );
static RTYPE compiled_temp_1_166( CONT_PARAMS );
static RTYPE compiled_temp_1_165( CONT_PARAMS );
static RTYPE compiled_block_1_2099( CONT_PARAMS );
static RTYPE compiled_temp_1_164( CONT_PARAMS );
static RTYPE compiled_start_1_163( CONT_PARAMS );
static RTYPE compiled_block_1_2078( CONT_PARAMS );
static RTYPE compiled_start_1_101( CONT_PARAMS );
static RTYPE compiled_block_1_2087( CONT_PARAMS );
static RTYPE compiled_block_1_2088( CONT_PARAMS );
static RTYPE compiled_block_1_2090( CONT_PARAMS );
static RTYPE compiled_block_1_2091( CONT_PARAMS );
static RTYPE compiled_temp_1_169( CONT_PARAMS );
static RTYPE compiled_block_1_2085( CONT_PARAMS );
static RTYPE compiled_block_1_2086( CONT_PARAMS );
static RTYPE compiled_block_1_2080( CONT_PARAMS );
static RTYPE compiled_block_1_2082( CONT_PARAMS );
static RTYPE compiled_block_1_2084( CONT_PARAMS );
static RTYPE compiled_temp_1_168( CONT_PARAMS );
static RTYPE compiled_start_1_167( CONT_PARAMS );
static RTYPE compiled_block_1_2064( CONT_PARAMS );
static RTYPE compiled_start_1_100( CONT_PARAMS );
static RTYPE compiled_block_1_2071( CONT_PARAMS );
static RTYPE compiled_block_1_2072( CONT_PARAMS );
static RTYPE compiled_block_1_2074( CONT_PARAMS );
static RTYPE compiled_block_1_2075( CONT_PARAMS );
static RTYPE compiled_temp_1_172( CONT_PARAMS );
static RTYPE compiled_block_1_2069( CONT_PARAMS );
static RTYPE compiled_block_1_2070( CONT_PARAMS );
static RTYPE compiled_block_1_2066( CONT_PARAMS );
static RTYPE compiled_block_1_2068( CONT_PARAMS );
static RTYPE compiled_temp_1_171( CONT_PARAMS );
static RTYPE compiled_start_1_170( CONT_PARAMS );
static RTYPE compiled_block_1_2042( CONT_PARAMS );
static RTYPE compiled_block_1_2045( CONT_PARAMS );
static RTYPE compiled_block_1_2049( CONT_PARAMS );
static RTYPE compiled_block_1_2062( CONT_PARAMS );
static RTYPE compiled_block_1_2054( CONT_PARAMS );
static RTYPE compiled_block_1_2052( CONT_PARAMS );
static RTYPE compiled_block_1_2051( CONT_PARAMS );
static RTYPE compiled_block_1_2050( CONT_PARAMS );
static RTYPE compiled_block_1_2046( CONT_PARAMS );
static RTYPE compiled_block_1_2048( CONT_PARAMS );
static RTYPE compiled_block_1_2047( CONT_PARAMS );
static RTYPE compiled_block_1_2043( CONT_PARAMS );
static RTYPE compiled_block_1_2044( CONT_PARAMS );
static RTYPE compiled_temp_1_173( CONT_PARAMS );
static RTYPE compiled_block_1_2041( CONT_PARAMS );
static RTYPE compiled_start_1_99( CONT_PARAMS );
static RTYPE compiled_block_1_2060( CONT_PARAMS );
static RTYPE compiled_block_1_2059( CONT_PARAMS );
static RTYPE compiled_block_1_2058( CONT_PARAMS );
static RTYPE compiled_block_1_2057( CONT_PARAMS );
static RTYPE compiled_temp_1_176( CONT_PARAMS );
static RTYPE compiled_block_1_2056( CONT_PARAMS );
static RTYPE compiled_temp_1_175( CONT_PARAMS );
static RTYPE compiled_start_1_174( CONT_PARAMS );
static RTYPE compiled_block_1_2039( CONT_PARAMS );
static RTYPE compiled_block_1_2038( CONT_PARAMS );
static RTYPE compiled_block_1_2037( CONT_PARAMS );
static RTYPE compiled_block_1_2035( CONT_PARAMS );
static RTYPE compiled_start_1_98( CONT_PARAMS );
static RTYPE compiled_block_1_2031( CONT_PARAMS );
static RTYPE compiled_block_1_2033( CONT_PARAMS );
static RTYPE compiled_block_1_2032( CONT_PARAMS );
static RTYPE compiled_block_1_2030( CONT_PARAMS );
static RTYPE compiled_block_1_2029( CONT_PARAMS );
static RTYPE compiled_block_1_2027( CONT_PARAMS );
static RTYPE compiled_start_1_97( CONT_PARAMS );
static RTYPE compiled_block_1_2025( CONT_PARAMS );
static RTYPE compiled_block_1_2024( CONT_PARAMS );
static RTYPE compiled_block_1_2022( CONT_PARAMS );
static RTYPE compiled_start_1_96( CONT_PARAMS );
static RTYPE compiled_block_1_2019( CONT_PARAMS );
static RTYPE compiled_block_1_2021( CONT_PARAMS );
static RTYPE compiled_block_1_2020( CONT_PARAMS );
static RTYPE compiled_temp_1_177( CONT_PARAMS );
static RTYPE compiled_start_1_95( CONT_PARAMS );
static RTYPE compiled_block_1_2013( CONT_PARAMS );
static RTYPE compiled_block_1_2016( CONT_PARAMS );
static RTYPE compiled_block_1_2014( CONT_PARAMS );
static RTYPE compiled_block_1_2012( CONT_PARAMS );
static RTYPE compiled_block_1_1999( CONT_PARAMS );
static RTYPE compiled_block_1_1998( CONT_PARAMS );
static RTYPE compiled_block_1_1997( CONT_PARAMS );
static RTYPE compiled_temp_1_178( CONT_PARAMS );
static RTYPE compiled_start_1_94( CONT_PARAMS );
static RTYPE compiled_block_1_2006( CONT_PARAMS );
static RTYPE compiled_block_1_2009( CONT_PARAMS );
static RTYPE compiled_temp_1_184( CONT_PARAMS );
static RTYPE compiled_block_1_2010( CONT_PARAMS );
static RTYPE compiled_block_1_2007( CONT_PARAMS );
static RTYPE compiled_block_1_2005( CONT_PARAMS );
static RTYPE compiled_temp_1_183( CONT_PARAMS );
static RTYPE compiled_block_1_2001( CONT_PARAMS );
static RTYPE compiled_temp_1_180( CONT_PARAMS );
static RTYPE compiled_start_1_179( CONT_PARAMS );
static RTYPE compiled_start_1_182( CONT_PARAMS );
static RTYPE compiled_start_1_181( CONT_PARAMS );
static RTYPE compiled_block_1_1965( CONT_PARAMS );
static RTYPE compiled_block_1_1974( CONT_PARAMS );
static RTYPE compiled_block_1_1968( CONT_PARAMS );
static RTYPE compiled_block_1_1971( CONT_PARAMS );
static RTYPE compiled_block_1_1975( CONT_PARAMS );
static RTYPE compiled_block_1_1961( CONT_PARAMS );
static RTYPE compiled_block_1_1966( CONT_PARAMS );
static RTYPE compiled_block_1_1967( CONT_PARAMS );
static RTYPE compiled_block_1_1970( CONT_PARAMS );
static RTYPE compiled_block_1_1973( CONT_PARAMS );
static RTYPE compiled_temp_1_187( CONT_PARAMS );
static RTYPE compiled_temp_1_186( CONT_PARAMS );
static RTYPE compiled_temp_1_185( CONT_PARAMS );
static RTYPE compiled_block_1_1964( CONT_PARAMS );
static RTYPE compiled_block_1_1963( CONT_PARAMS );
static RTYPE compiled_block_1_1962( CONT_PARAMS );
static RTYPE compiled_block_1_1959( CONT_PARAMS );
static RTYPE compiled_start_1_93( CONT_PARAMS );
static RTYPE compiled_block_1_1979( CONT_PARAMS );
static RTYPE compiled_block_1_1980( CONT_PARAMS );
static RTYPE compiled_block_1_1981( CONT_PARAMS );
static RTYPE compiled_block_1_1983( CONT_PARAMS );
static RTYPE compiled_block_1_1984( CONT_PARAMS );
static RTYPE compiled_block_1_1985( CONT_PARAMS );
static RTYPE compiled_block_1_1987( CONT_PARAMS );
static RTYPE compiled_block_1_1989( CONT_PARAMS );
static RTYPE compiled_block_1_1991( CONT_PARAMS );
static RTYPE compiled_block_1_1993( CONT_PARAMS );
static RTYPE compiled_temp_1_191( CONT_PARAMS );
static RTYPE compiled_block_1_1982( CONT_PARAMS );
static RTYPE compiled_block_1_1978( CONT_PARAMS );
static RTYPE compiled_temp_1_190( CONT_PARAMS );
static RTYPE compiled_block_1_1977( CONT_PARAMS );
static RTYPE compiled_temp_1_189( CONT_PARAMS );
static RTYPE compiled_start_1_188( CONT_PARAMS );
static RTYPE compiled_block_1_1945( CONT_PARAMS );
static RTYPE compiled_block_1_1947( CONT_PARAMS );
static RTYPE compiled_block_1_1946( CONT_PARAMS );
static RTYPE compiled_block_1_1944( CONT_PARAMS );
static RTYPE compiled_start_1_92( CONT_PARAMS );
static RTYPE compiled_block_1_1955( CONT_PARAMS );
static RTYPE compiled_block_1_1954( CONT_PARAMS );
static RTYPE compiled_temp_1_198( CONT_PARAMS );
static RTYPE compiled_temp_1_197( CONT_PARAMS );
static RTYPE compiled_block_1_1956( CONT_PARAMS );
static RTYPE compiled_block_1_1953( CONT_PARAMS );
static RTYPE compiled_temp_1_196( CONT_PARAMS );
static RTYPE compiled_block_1_1949( CONT_PARAMS );
static RTYPE compiled_temp_1_194( CONT_PARAMS );
static RTYPE compiled_start_1_193( CONT_PARAMS );
static RTYPE compiled_block_1_1951( CONT_PARAMS );
static RTYPE compiled_temp_1_202( CONT_PARAMS );
static RTYPE compiled_block_1_1952( CONT_PARAMS );
static RTYPE compiled_temp_1_201( CONT_PARAMS );
static RTYPE compiled_temp_1_200( CONT_PARAMS );
static RTYPE compiled_block_1_1950( CONT_PARAMS );
static RTYPE compiled_temp_1_199( CONT_PARAMS );
static RTYPE compiled_start_1_195( CONT_PARAMS );
static RTYPE compiled_start_1_192( CONT_PARAMS );
static RTYPE compiled_block_1_1931( CONT_PARAMS );
static RTYPE compiled_block_1_1933( CONT_PARAMS );
static RTYPE compiled_block_1_1932( CONT_PARAMS );
static RTYPE compiled_block_1_1930( CONT_PARAMS );
static RTYPE compiled_start_1_91( CONT_PARAMS );
static RTYPE compiled_block_1_1937( CONT_PARAMS );
static RTYPE compiled_block_1_1938( CONT_PARAMS );
static RTYPE compiled_block_1_1939( CONT_PARAMS );
static RTYPE compiled_block_1_1941( CONT_PARAMS );
static RTYPE compiled_temp_1_207( CONT_PARAMS );
static RTYPE compiled_temp_1_206( CONT_PARAMS );
static RTYPE compiled_block_1_1940( CONT_PARAMS );
static RTYPE compiled_block_1_1936( CONT_PARAMS );
static RTYPE compiled_temp_1_205( CONT_PARAMS );
static RTYPE compiled_block_1_1935( CONT_PARAMS );
static RTYPE compiled_temp_1_204( CONT_PARAMS );
static RTYPE compiled_start_1_203( CONT_PARAMS );
static RTYPE compiled_block_1_1912( CONT_PARAMS );
static RTYPE compiled_temp_1_208( CONT_PARAMS );
static RTYPE compiled_block_1_1914( CONT_PARAMS );
static RTYPE compiled_block_1_1913( CONT_PARAMS );
static RTYPE compiled_block_1_1911( CONT_PARAMS );
static RTYPE compiled_start_1_90( CONT_PARAMS );
static RTYPE compiled_block_1_1918( CONT_PARAMS );
static RTYPE compiled_block_1_1919( CONT_PARAMS );
static RTYPE compiled_block_1_1920( CONT_PARAMS );
static RTYPE compiled_block_1_1921( CONT_PARAMS );
static RTYPE compiled_block_1_1922( CONT_PARAMS );
static RTYPE compiled_block_1_1925( CONT_PARAMS );
static RTYPE compiled_block_1_1926( CONT_PARAMS );
static RTYPE compiled_block_1_1923( CONT_PARAMS );
static RTYPE compiled_block_1_1927( CONT_PARAMS );
static RTYPE compiled_temp_1_213( CONT_PARAMS );
static RTYPE compiled_temp_1_212( CONT_PARAMS );
static RTYPE compiled_block_1_1924( CONT_PARAMS );
static RTYPE compiled_temp_1_211( CONT_PARAMS );
static RTYPE compiled_block_1_1917( CONT_PARAMS );
static RTYPE compiled_block_1_1916( CONT_PARAMS );
static RTYPE compiled_temp_1_210( CONT_PARAMS );
static RTYPE compiled_start_1_209( CONT_PARAMS );
static RTYPE compiled_block_1_1900( CONT_PARAMS );
static RTYPE compiled_block_1_1909( CONT_PARAMS );
static RTYPE compiled_block_1_1908( CONT_PARAMS );
static RTYPE compiled_block_1_1899( CONT_PARAMS );
static RTYPE compiled_block_1_1898( CONT_PARAMS );
static RTYPE compiled_temp_1_215( CONT_PARAMS );
static RTYPE compiled_block_1_1897( CONT_PARAMS );
static RTYPE compiled_block_1_1891( CONT_PARAMS );
static RTYPE compiled_block_1_1890( CONT_PARAMS );
static RTYPE compiled_block_1_1889( CONT_PARAMS );
static RTYPE compiled_start_1_89( CONT_PARAMS );
static RTYPE compiled_block_1_1904( CONT_PARAMS );
static RTYPE compiled_block_1_1906( CONT_PARAMS );
static RTYPE compiled_block_1_1902( CONT_PARAMS );
static RTYPE compiled_temp_1_219( CONT_PARAMS );
static RTYPE compiled_block_1_1905( CONT_PARAMS );
static RTYPE compiled_temp_1_218( CONT_PARAMS );
static RTYPE compiled_block_1_1903( CONT_PARAMS );
static RTYPE compiled_temp_1_217( CONT_PARAMS );
static RTYPE compiled_start_1_216( CONT_PARAMS );
static RTYPE compiled_block_1_1895( CONT_PARAMS );
static RTYPE compiled_temp_1_221( CONT_PARAMS );
static RTYPE compiled_block_1_1894( CONT_PARAMS );
static RTYPE compiled_block_1_1893( CONT_PARAMS );
static RTYPE compiled_temp_1_220( CONT_PARAMS );
static RTYPE compiled_start_1_214( CONT_PARAMS );
static RTYPE compiled_block_1_1871( CONT_PARAMS );
static RTYPE compiled_block_1_1879( CONT_PARAMS );
static RTYPE compiled_block_1_1887( CONT_PARAMS );
static RTYPE compiled_block_1_1886( CONT_PARAMS );
static RTYPE compiled_block_1_1878( CONT_PARAMS );
static RTYPE compiled_block_1_1877( CONT_PARAMS );
static RTYPE compiled_block_1_1876( CONT_PARAMS );
static RTYPE compiled_start_1_88( CONT_PARAMS );
static RTYPE compiled_block_1_1882( CONT_PARAMS );
static RTYPE compiled_block_1_1884( CONT_PARAMS );
static RTYPE compiled_block_1_1881( CONT_PARAMS );
static RTYPE compiled_temp_1_226( CONT_PARAMS );
static RTYPE compiled_block_1_1883( CONT_PARAMS );
static RTYPE compiled_temp_1_225( CONT_PARAMS );
static RTYPE compiled_temp_1_224( CONT_PARAMS );
static RTYPE compiled_start_1_223( CONT_PARAMS );
static RTYPE compiled_block_1_1874( CONT_PARAMS );
static RTYPE compiled_block_1_1873( CONT_PARAMS );
static RTYPE compiled_temp_1_227( CONT_PARAMS );
static RTYPE compiled_start_1_222( CONT_PARAMS );
static RTYPE compiled_block_1_1852( CONT_PARAMS );
static RTYPE compiled_block_1_1869( CONT_PARAMS );
static RTYPE compiled_block_1_1849( CONT_PARAMS );
static RTYPE compiled_block_1_1868( CONT_PARAMS );
static RTYPE compiled_block_1_1866( CONT_PARAMS );
static RTYPE compiled_block_1_1867( CONT_PARAMS );
static RTYPE compiled_block_1_1850( CONT_PARAMS );
static RTYPE compiled_block_1_1853( CONT_PARAMS );
static RTYPE compiled_temp_1_229( CONT_PARAMS );
static RTYPE compiled_block_1_1851( CONT_PARAMS );
static RTYPE compiled_temp_1_228( CONT_PARAMS );
static RTYPE compiled_block_1_1848( CONT_PARAMS );
static RTYPE compiled_block_1_1847( CONT_PARAMS );
static RTYPE compiled_start_1_87( CONT_PARAMS );
static RTYPE compiled_block_1_1858( CONT_PARAMS );
static RTYPE compiled_block_1_1864( CONT_PARAMS );
static RTYPE compiled_block_1_1863( CONT_PARAMS );
static RTYPE compiled_block_1_1862( CONT_PARAMS );
static RTYPE compiled_temp_1_232( CONT_PARAMS );
static RTYPE compiled_block_1_1861( CONT_PARAMS );
static RTYPE compiled_block_1_1856( CONT_PARAMS );
static RTYPE compiled_block_1_1859( CONT_PARAMS );
static RTYPE compiled_temp_1_231( CONT_PARAMS );
static RTYPE compiled_block_1_1857( CONT_PARAMS );
static RTYPE compiled_block_1_1854( CONT_PARAMS );
static RTYPE compiled_start_1_230( CONT_PARAMS );
static RTYPE compiled_block_1_1830( CONT_PARAMS );
static RTYPE compiled_block_1_1845( CONT_PARAMS );
static RTYPE compiled_block_1_1836( CONT_PARAMS );
static RTYPE compiled_block_1_1844( CONT_PARAMS );
static RTYPE compiled_block_1_1843( CONT_PARAMS );
static RTYPE compiled_block_1_1837( CONT_PARAMS );
static RTYPE compiled_block_1_1839( CONT_PARAMS );
static RTYPE compiled_block_1_1838( CONT_PARAMS );
static RTYPE compiled_temp_1_233( CONT_PARAMS );
static RTYPE compiled_block_1_1835( CONT_PARAMS );
static RTYPE compiled_block_1_1834( CONT_PARAMS );
static RTYPE compiled_block_1_1823( CONT_PARAMS );
static RTYPE compiled_block_1_1833( CONT_PARAMS );
static RTYPE compiled_block_1_1832( CONT_PARAMS );
static RTYPE compiled_block_1_1831( CONT_PARAMS );
static RTYPE compiled_block_1_1829( CONT_PARAMS );
static RTYPE compiled_block_1_1828( CONT_PARAMS );
static RTYPE compiled_block_1_1827( CONT_PARAMS );
static RTYPE compiled_block_1_1826( CONT_PARAMS );
static RTYPE compiled_block_1_1825( CONT_PARAMS );
static RTYPE compiled_block_1_1824( CONT_PARAMS );
static RTYPE compiled_block_1_1822( CONT_PARAMS );
static RTYPE compiled_block_1_1821( CONT_PARAMS );
static RTYPE compiled_block_1_1820( CONT_PARAMS );
static RTYPE compiled_block_1_1815( CONT_PARAMS );
static RTYPE compiled_block_1_1819( CONT_PARAMS );
static RTYPE compiled_block_1_1818( CONT_PARAMS );
static RTYPE compiled_block_1_1817( CONT_PARAMS );
static RTYPE compiled_block_1_1816( CONT_PARAMS );
static RTYPE compiled_block_1_1814( CONT_PARAMS );
static RTYPE compiled_start_1_86( CONT_PARAMS );
static RTYPE compiled_start_1_234( CONT_PARAMS );
static RTYPE compiled_start_1_236( CONT_PARAMS );
static RTYPE compiled_start_1_235( CONT_PARAMS );
static RTYPE compiled_block_1_1813( CONT_PARAMS );
static RTYPE compiled_temp_1_238( CONT_PARAMS );
static RTYPE compiled_temp_1_237( CONT_PARAMS );
static RTYPE compiled_block_1_1812( CONT_PARAMS );
static RTYPE compiled_start_1_85( CONT_PARAMS );
static RTYPE compiled_block_1_1811( CONT_PARAMS );
static RTYPE compiled_temp_1_239( CONT_PARAMS );
static RTYPE compiled_block_1_1810( CONT_PARAMS );
static RTYPE compiled_start_1_84( CONT_PARAMS );
static RTYPE compiled_block_1_1809( CONT_PARAMS );
static RTYPE compiled_temp_1_240( CONT_PARAMS );
static RTYPE compiled_block_1_1808( CONT_PARAMS );
static RTYPE compiled_start_1_83( CONT_PARAMS );
static RTYPE compiled_block_1_1788( CONT_PARAMS );
static RTYPE compiled_block_1_1801( CONT_PARAMS );
static RTYPE compiled_block_1_1806( CONT_PARAMS );
static RTYPE compiled_block_1_1798( CONT_PARAMS );
static RTYPE compiled_block_1_1805( CONT_PARAMS );
static RTYPE compiled_block_1_1804( CONT_PARAMS );
static RTYPE compiled_block_1_1803( CONT_PARAMS );
static RTYPE compiled_block_1_1799( CONT_PARAMS );
static RTYPE compiled_block_1_1802( CONT_PARAMS );
static RTYPE compiled_block_1_1800( CONT_PARAMS );
static RTYPE compiled_temp_1_242( CONT_PARAMS );
static RTYPE compiled_block_1_1789( CONT_PARAMS );
static RTYPE compiled_block_1_1797( CONT_PARAMS );
static RTYPE compiled_block_1_1796( CONT_PARAMS );
static RTYPE compiled_block_1_1795( CONT_PARAMS );
static RTYPE compiled_block_1_1794( CONT_PARAMS );
static RTYPE compiled_block_1_1793( CONT_PARAMS );
static RTYPE compiled_block_1_1792( CONT_PARAMS );
static RTYPE compiled_block_1_1791( CONT_PARAMS );
static RTYPE compiled_block_1_1790( CONT_PARAMS );
static RTYPE compiled_temp_1_241( CONT_PARAMS );
static RTYPE compiled_block_1_1787( CONT_PARAMS );
static RTYPE compiled_block_1_1786( CONT_PARAMS );
static RTYPE compiled_block_1_1781( CONT_PARAMS );
static RTYPE compiled_block_1_1785( CONT_PARAMS );
static RTYPE compiled_block_1_1784( CONT_PARAMS );
static RTYPE compiled_block_1_1783( CONT_PARAMS );
static RTYPE compiled_block_1_1782( CONT_PARAMS );
static RTYPE compiled_block_1_1780( CONT_PARAMS );
static RTYPE compiled_start_1_82( CONT_PARAMS );
static RTYPE compiled_block_1_1762( CONT_PARAMS );
static RTYPE compiled_block_1_1775( CONT_PARAMS );
static RTYPE compiled_block_1_1779( CONT_PARAMS );
static RTYPE compiled_block_1_1778( CONT_PARAMS );
static RTYPE compiled_block_1_1777( CONT_PARAMS );
static RTYPE compiled_block_1_1776( CONT_PARAMS );
static RTYPE compiled_block_1_1774( CONT_PARAMS );
static RTYPE compiled_block_1_1773( CONT_PARAMS );
static RTYPE compiled_block_1_1769( CONT_PARAMS );
static RTYPE compiled_block_1_1772( CONT_PARAMS );
static RTYPE compiled_block_1_1770( CONT_PARAMS );
static RTYPE compiled_block_1_1771( CONT_PARAMS );
static RTYPE compiled_temp_1_243( CONT_PARAMS );
static RTYPE compiled_block_1_1764( CONT_PARAMS );
static RTYPE compiled_block_1_1768( CONT_PARAMS );
static RTYPE compiled_block_1_1767( CONT_PARAMS );
static RTYPE compiled_block_1_1766( CONT_PARAMS );
static RTYPE compiled_block_1_1765( CONT_PARAMS );
static RTYPE compiled_block_1_1763( CONT_PARAMS );
static RTYPE compiled_block_1_1761( CONT_PARAMS );
static RTYPE compiled_start_1_81( CONT_PARAMS );
static RTYPE compiled_block_1_1754( CONT_PARAMS );
static RTYPE compiled_block_1_1759( CONT_PARAMS );
static RTYPE compiled_block_1_1751( CONT_PARAMS );
static RTYPE compiled_block_1_1758( CONT_PARAMS );
static RTYPE compiled_block_1_1757( CONT_PARAMS );
static RTYPE compiled_block_1_1756( CONT_PARAMS );
static RTYPE compiled_block_1_1752( CONT_PARAMS );
static RTYPE compiled_block_1_1755( CONT_PARAMS );
static RTYPE compiled_block_1_1753( CONT_PARAMS );
static RTYPE compiled_temp_1_245( CONT_PARAMS );
static RTYPE compiled_block_1_1748( CONT_PARAMS );
static RTYPE compiled_block_1_1749( CONT_PARAMS );
static RTYPE compiled_block_1_1750( CONT_PARAMS );
static RTYPE compiled_block_1_1747( CONT_PARAMS );
static RTYPE compiled_start_1_80( CONT_PARAMS );
static RTYPE compiled_start_1_244( CONT_PARAMS );
static RTYPE compiled_block_1_1743( CONT_PARAMS );
static RTYPE compiled_block_1_1745( CONT_PARAMS );
static RTYPE compiled_block_1_1744( CONT_PARAMS );
static RTYPE compiled_block_1_1742( CONT_PARAMS );
static RTYPE compiled_start_1_79( CONT_PARAMS );
static RTYPE compiled_block_1_1740( CONT_PARAMS );
static RTYPE compiled_start_1_78( CONT_PARAMS );
static RTYPE compiled_block_1_1738( CONT_PARAMS );
static RTYPE compiled_start_1_77( CONT_PARAMS );
static RTYPE compiled_block_1_1736( CONT_PARAMS );
static RTYPE compiled_start_1_76( CONT_PARAMS );
static RTYPE compiled_block_1_1734( CONT_PARAMS );
static RTYPE compiled_start_1_75( CONT_PARAMS );
static RTYPE compiled_start_1_74( CONT_PARAMS );
static RTYPE compiled_block_1_1711( CONT_PARAMS );
static RTYPE compiled_block_1_1708( CONT_PARAMS );
static RTYPE compiled_block_1_1710( CONT_PARAMS );
static RTYPE compiled_temp_1_247( CONT_PARAMS );
static RTYPE compiled_start_1_246( CONT_PARAMS );
static RTYPE compiled_block_1_1725( CONT_PARAMS );
static RTYPE compiled_block_1_1714( CONT_PARAMS );
static RTYPE compiled_block_1_1715( CONT_PARAMS );
static RTYPE compiled_block_1_1731( CONT_PARAMS );
static RTYPE compiled_block_1_1724( CONT_PARAMS );
static RTYPE compiled_block_1_1723( CONT_PARAMS );
static RTYPE compiled_block_1_1722( CONT_PARAMS );
static RTYPE compiled_block_1_1721( CONT_PARAMS );
static RTYPE compiled_block_1_1720( CONT_PARAMS );
static RTYPE compiled_block_1_1719( CONT_PARAMS );
static RTYPE compiled_block_1_1718( CONT_PARAMS );
static RTYPE compiled_block_1_1717( CONT_PARAMS );
static RTYPE compiled_block_1_1716( CONT_PARAMS );
static RTYPE compiled_block_1_1713( CONT_PARAMS );
static RTYPE compiled_start_1_248( CONT_PARAMS );
static RTYPE compiled_block_1_1729( CONT_PARAMS );
static RTYPE compiled_block_1_1728( CONT_PARAMS );
static RTYPE compiled_temp_1_251( CONT_PARAMS );
static RTYPE compiled_block_1_1727( CONT_PARAMS );
static RTYPE compiled_temp_1_250( CONT_PARAMS );
static RTYPE compiled_start_1_249( CONT_PARAMS );
static RTYPE compiled_start_1_73( CONT_PARAMS );
static RTYPE compiled_block_1_1705( CONT_PARAMS );
static RTYPE compiled_block_1_1704( CONT_PARAMS );
static RTYPE compiled_start_1_72( CONT_PARAMS );
static RTYPE compiled_block_1_1702( CONT_PARAMS );
static RTYPE compiled_block_1_1699( CONT_PARAMS );
static RTYPE compiled_block_1_1700( CONT_PARAMS );
static RTYPE compiled_block_1_1701( CONT_PARAMS );
static RTYPE compiled_block_1_1698( CONT_PARAMS );
static RTYPE compiled_start_1_71( CONT_PARAMS );
static RTYPE compiled_block_1_1693( CONT_PARAMS );
static RTYPE compiled_block_1_1694( CONT_PARAMS );
static RTYPE compiled_block_1_1696( CONT_PARAMS );
static RTYPE compiled_block_1_1695( CONT_PARAMS );
static RTYPE compiled_block_1_1692( CONT_PARAMS );
static RTYPE compiled_start_1_70( CONT_PARAMS );
static RTYPE compiled_block_1_1686( CONT_PARAMS );
static RTYPE compiled_block_1_1687( CONT_PARAMS );
static RTYPE compiled_block_1_1690( CONT_PARAMS );
static RTYPE compiled_block_1_1689( CONT_PARAMS );
static RTYPE compiled_block_1_1688( CONT_PARAMS );
static RTYPE compiled_block_1_1685( CONT_PARAMS );
static RTYPE compiled_start_1_69( CONT_PARAMS );
static RTYPE compiled_block_1_1677( CONT_PARAMS );
static RTYPE compiled_block_1_1683( CONT_PARAMS );
static RTYPE compiled_block_1_1678( CONT_PARAMS );
static RTYPE compiled_block_1_1682( CONT_PARAMS );
static RTYPE compiled_block_1_1681( CONT_PARAMS );
static RTYPE compiled_block_1_1680( CONT_PARAMS );
static RTYPE compiled_block_1_1679( CONT_PARAMS );
static RTYPE compiled_block_1_1676( CONT_PARAMS );
static RTYPE compiled_start_1_68( CONT_PARAMS );
static RTYPE compiled_block_1_1673( CONT_PARAMS );
static RTYPE compiled_block_1_1674( CONT_PARAMS );
static RTYPE compiled_block_1_1666( CONT_PARAMS );
static RTYPE compiled_block_1_1667( CONT_PARAMS );
static RTYPE compiled_block_1_1672( CONT_PARAMS );
static RTYPE compiled_block_1_1671( CONT_PARAMS );
static RTYPE compiled_block_1_1670( CONT_PARAMS );
static RTYPE compiled_block_1_1669( CONT_PARAMS );
static RTYPE compiled_block_1_1668( CONT_PARAMS );
static RTYPE compiled_block_1_1665( CONT_PARAMS );
static RTYPE compiled_start_1_67( CONT_PARAMS );
static RTYPE compiled_block_1_1662( CONT_PARAMS );
static RTYPE compiled_block_1_1663( CONT_PARAMS );
static RTYPE compiled_block_1_1654( CONT_PARAMS );
static RTYPE compiled_block_1_1655( CONT_PARAMS );
static RTYPE compiled_block_1_1661( CONT_PARAMS );
static RTYPE compiled_block_1_1660( CONT_PARAMS );
static RTYPE compiled_block_1_1659( CONT_PARAMS );
static RTYPE compiled_block_1_1658( CONT_PARAMS );
static RTYPE compiled_block_1_1657( CONT_PARAMS );
static RTYPE compiled_block_1_1656( CONT_PARAMS );
static RTYPE compiled_block_1_1653( CONT_PARAMS );
static RTYPE compiled_start_1_66( CONT_PARAMS );
static RTYPE compiled_block_1_1642( CONT_PARAMS );
static RTYPE compiled_block_1_1651( CONT_PARAMS );
static RTYPE compiled_block_1_1643( CONT_PARAMS );
static RTYPE compiled_block_1_1650( CONT_PARAMS );
static RTYPE compiled_block_1_1649( CONT_PARAMS );
static RTYPE compiled_block_1_1648( CONT_PARAMS );
static RTYPE compiled_block_1_1647( CONT_PARAMS );
static RTYPE compiled_block_1_1646( CONT_PARAMS );
static RTYPE compiled_block_1_1645( CONT_PARAMS );
static RTYPE compiled_block_1_1644( CONT_PARAMS );
static RTYPE compiled_block_1_1641( CONT_PARAMS );
static RTYPE compiled_start_1_65( CONT_PARAMS );
static RTYPE compiled_block_1_1629( CONT_PARAMS );
static RTYPE compiled_block_1_1639( CONT_PARAMS );
static RTYPE compiled_block_1_1630( CONT_PARAMS );
static RTYPE compiled_block_1_1638( CONT_PARAMS );
static RTYPE compiled_block_1_1637( CONT_PARAMS );
static RTYPE compiled_block_1_1636( CONT_PARAMS );
static RTYPE compiled_block_1_1635( CONT_PARAMS );
static RTYPE compiled_block_1_1634( CONT_PARAMS );
static RTYPE compiled_block_1_1633( CONT_PARAMS );
static RTYPE compiled_block_1_1632( CONT_PARAMS );
static RTYPE compiled_block_1_1631( CONT_PARAMS );
static RTYPE compiled_block_1_1628( CONT_PARAMS );
static RTYPE compiled_start_1_64( CONT_PARAMS );
static RTYPE compiled_start_1_63( CONT_PARAMS );
static RTYPE compiled_block_1_1609( CONT_PARAMS );
static RTYPE compiled_block_1_1606( CONT_PARAMS );
static RTYPE compiled_block_1_1608( CONT_PARAMS );
static RTYPE compiled_temp_1_253( CONT_PARAMS );
static RTYPE compiled_start_1_252( CONT_PARAMS );
static RTYPE compiled_block_1_1625( CONT_PARAMS );
static RTYPE compiled_block_1_1620( CONT_PARAMS );
static RTYPE compiled_block_1_1619( CONT_PARAMS );
static RTYPE compiled_block_1_1618( CONT_PARAMS );
static RTYPE compiled_block_1_1617( CONT_PARAMS );
static RTYPE compiled_block_1_1616( CONT_PARAMS );
static RTYPE compiled_block_1_1615( CONT_PARAMS );
static RTYPE compiled_block_1_1614( CONT_PARAMS );
static RTYPE compiled_block_1_1613( CONT_PARAMS );
static RTYPE compiled_block_1_1612( CONT_PARAMS );
static RTYPE compiled_block_1_1611( CONT_PARAMS );
static RTYPE compiled_start_1_254( CONT_PARAMS );
static RTYPE compiled_block_1_1623( CONT_PARAMS );
static RTYPE compiled_temp_1_257( CONT_PARAMS );
static RTYPE compiled_block_1_1622( CONT_PARAMS );
static RTYPE compiled_temp_1_256( CONT_PARAMS );
static RTYPE compiled_start_1_255( CONT_PARAMS );
static RTYPE compiled_start_1_62( CONT_PARAMS );
static RTYPE compiled_block_1_1603( CONT_PARAMS );
static RTYPE compiled_start_1_61( CONT_PARAMS );
static RTYPE compiled_block_1_1601( CONT_PARAMS );
static RTYPE compiled_block_1_1600( CONT_PARAMS );
static RTYPE compiled_start_1_60( CONT_PARAMS );
static RTYPE compiled_block_1_1598( CONT_PARAMS );
static RTYPE compiled_block_1_1597( CONT_PARAMS );
static RTYPE compiled_block_1_1596( CONT_PARAMS );
static RTYPE compiled_start_1_59( CONT_PARAMS );
static RTYPE compiled_block_1_1594( CONT_PARAMS );
static RTYPE compiled_block_1_1593( CONT_PARAMS );
static RTYPE compiled_block_1_1592( CONT_PARAMS );
static RTYPE compiled_block_1_1591( CONT_PARAMS );
static RTYPE compiled_start_1_58( CONT_PARAMS );
static RTYPE compiled_block_1_1589( CONT_PARAMS );
static RTYPE compiled_block_1_1588( CONT_PARAMS );
static RTYPE compiled_block_1_1587( CONT_PARAMS );
static RTYPE compiled_block_1_1586( CONT_PARAMS );
static RTYPE compiled_block_1_1585( CONT_PARAMS );
static RTYPE compiled_start_1_57( CONT_PARAMS );
static RTYPE compiled_block_1_1583( CONT_PARAMS );
static RTYPE compiled_block_1_1582( CONT_PARAMS );
static RTYPE compiled_block_1_1581( CONT_PARAMS );
static RTYPE compiled_block_1_1580( CONT_PARAMS );
static RTYPE compiled_block_1_1579( CONT_PARAMS );
static RTYPE compiled_block_1_1578( CONT_PARAMS );
static RTYPE compiled_start_1_56( CONT_PARAMS );
static RTYPE compiled_block_1_1576( CONT_PARAMS );
static RTYPE compiled_block_1_1575( CONT_PARAMS );
static RTYPE compiled_block_1_1574( CONT_PARAMS );
static RTYPE compiled_block_1_1573( CONT_PARAMS );
static RTYPE compiled_block_1_1572( CONT_PARAMS );
static RTYPE compiled_block_1_1571( CONT_PARAMS );
static RTYPE compiled_block_1_1570( CONT_PARAMS );
static RTYPE compiled_start_1_55( CONT_PARAMS );
static RTYPE compiled_block_1_1568( CONT_PARAMS );
static RTYPE compiled_block_1_1567( CONT_PARAMS );
static RTYPE compiled_block_1_1566( CONT_PARAMS );
static RTYPE compiled_block_1_1565( CONT_PARAMS );
static RTYPE compiled_block_1_1564( CONT_PARAMS );
static RTYPE compiled_block_1_1563( CONT_PARAMS );
static RTYPE compiled_block_1_1562( CONT_PARAMS );
static RTYPE compiled_block_1_1561( CONT_PARAMS );
static RTYPE compiled_start_1_54( CONT_PARAMS );
static RTYPE compiled_block_1_1559( CONT_PARAMS );
static RTYPE compiled_block_1_1558( CONT_PARAMS );
static RTYPE compiled_block_1_1557( CONT_PARAMS );
static RTYPE compiled_block_1_1556( CONT_PARAMS );
static RTYPE compiled_block_1_1555( CONT_PARAMS );
static RTYPE compiled_block_1_1554( CONT_PARAMS );
static RTYPE compiled_block_1_1553( CONT_PARAMS );
static RTYPE compiled_block_1_1552( CONT_PARAMS );
static RTYPE compiled_block_1_1551( CONT_PARAMS );
static RTYPE compiled_start_1_53( CONT_PARAMS );
static RTYPE compiled_start_1_52( CONT_PARAMS );
static RTYPE compiled_block_1_1532( CONT_PARAMS );
static RTYPE compiled_block_1_1529( CONT_PARAMS );
static RTYPE compiled_block_1_1531( CONT_PARAMS );
static RTYPE compiled_temp_1_259( CONT_PARAMS );
static RTYPE compiled_start_1_258( CONT_PARAMS );
static RTYPE compiled_block_1_1534( CONT_PARAMS );
static RTYPE compiled_block_1_1542( CONT_PARAMS );
static RTYPE compiled_block_1_1539( CONT_PARAMS );
static RTYPE compiled_block_1_1536( CONT_PARAMS );
static RTYPE compiled_block_1_1541( CONT_PARAMS );
static RTYPE compiled_block_1_1538( CONT_PARAMS );
static RTYPE compiled_block_1_1535( CONT_PARAMS );
static RTYPE compiled_block_1_1543( CONT_PARAMS );
static RTYPE compiled_block_1_1540( CONT_PARAMS );
static RTYPE compiled_block_1_1537( CONT_PARAMS );
static RTYPE compiled_block_1_1548( CONT_PARAMS );
static RTYPE compiled_start_1_260( CONT_PARAMS );
static RTYPE compiled_block_1_1546( CONT_PARAMS );
static RTYPE compiled_temp_1_263( CONT_PARAMS );
static RTYPE compiled_block_1_1545( CONT_PARAMS );
static RTYPE compiled_temp_1_262( CONT_PARAMS );
static RTYPE compiled_start_1_261( CONT_PARAMS );
static RTYPE compiled_start_1_51( CONT_PARAMS );
static RTYPE compiled_block_1_1526( CONT_PARAMS );
static RTYPE compiled_start_1_50( CONT_PARAMS );
static RTYPE compiled_block_1_1523( CONT_PARAMS );
static RTYPE compiled_block_1_1524( CONT_PARAMS );
static RTYPE compiled_start_1_49( CONT_PARAMS );
static RTYPE compiled_block_1_1520( CONT_PARAMS );
static RTYPE compiled_block_1_1519( CONT_PARAMS );
static RTYPE compiled_block_1_1521( CONT_PARAMS );
static RTYPE compiled_start_1_48( CONT_PARAMS );
static RTYPE compiled_block_1_1516( CONT_PARAMS );
static RTYPE compiled_block_1_1515( CONT_PARAMS );
static RTYPE compiled_block_1_1517( CONT_PARAMS );
static RTYPE compiled_block_1_1514( CONT_PARAMS );
static RTYPE compiled_start_1_47( CONT_PARAMS );
static RTYPE compiled_block_1_1511( CONT_PARAMS );
static RTYPE compiled_block_1_1510( CONT_PARAMS );
static RTYPE compiled_block_1_1508( CONT_PARAMS );
static RTYPE compiled_block_1_1512( CONT_PARAMS );
static RTYPE compiled_block_1_1509( CONT_PARAMS );
static RTYPE compiled_start_1_46( CONT_PARAMS );
static RTYPE compiled_block_1_1505( CONT_PARAMS );
static RTYPE compiled_block_1_1501( CONT_PARAMS );
static RTYPE compiled_block_1_1504( CONT_PARAMS );
static RTYPE compiled_block_1_1502( CONT_PARAMS );
static RTYPE compiled_block_1_1506( CONT_PARAMS );
static RTYPE compiled_block_1_1503( CONT_PARAMS );
static RTYPE compiled_start_1_45( CONT_PARAMS );
static RTYPE compiled_block_1_1498( CONT_PARAMS );
static RTYPE compiled_block_1_1494( CONT_PARAMS );
static RTYPE compiled_block_1_1497( CONT_PARAMS );
static RTYPE compiled_block_1_1495( CONT_PARAMS );
static RTYPE compiled_block_1_1499( CONT_PARAMS );
static RTYPE compiled_block_1_1493( CONT_PARAMS );
static RTYPE compiled_block_1_1496( CONT_PARAMS );
static RTYPE compiled_start_1_44( CONT_PARAMS );
static RTYPE compiled_block_1_1490( CONT_PARAMS );
static RTYPE compiled_block_1_1486( CONT_PARAMS );
static RTYPE compiled_block_1_1489( CONT_PARAMS );
static RTYPE compiled_block_1_1484( CONT_PARAMS );
static RTYPE compiled_block_1_1487( CONT_PARAMS );
static RTYPE compiled_block_1_1491( CONT_PARAMS );
static RTYPE compiled_block_1_1485( CONT_PARAMS );
static RTYPE compiled_block_1_1488( CONT_PARAMS );
static RTYPE compiled_start_1_43( CONT_PARAMS );
static RTYPE compiled_block_1_1481( CONT_PARAMS );
static RTYPE compiled_block_1_1474( CONT_PARAMS );
static RTYPE compiled_block_1_1477( CONT_PARAMS );
static RTYPE compiled_block_1_1480( CONT_PARAMS );
static RTYPE compiled_block_1_1475( CONT_PARAMS );
static RTYPE compiled_block_1_1478( CONT_PARAMS );
static RTYPE compiled_block_1_1482( CONT_PARAMS );
static RTYPE compiled_block_1_1476( CONT_PARAMS );
static RTYPE compiled_block_1_1479( CONT_PARAMS );
static RTYPE compiled_start_1_42( CONT_PARAMS );
static RTYPE compiled_start_1_41( CONT_PARAMS );
static RTYPE compiled_block_1_1439( CONT_PARAMS );
static RTYPE compiled_block_1_1436( CONT_PARAMS );
static RTYPE compiled_block_1_1438( CONT_PARAMS );
static RTYPE compiled_temp_1_265( CONT_PARAMS );
static RTYPE compiled_start_1_264( CONT_PARAMS );
static RTYPE compiled_block_1_1458( CONT_PARAMS );
static RTYPE compiled_block_1_1443( CONT_PARAMS );
static RTYPE compiled_block_1_1452( CONT_PARAMS );
static RTYPE compiled_block_1_1465( CONT_PARAMS );
static RTYPE compiled_block_1_1447( CONT_PARAMS );
static RTYPE compiled_block_1_1462( CONT_PARAMS );
static RTYPE compiled_block_1_1456( CONT_PARAMS );
static RTYPE compiled_block_1_1450( CONT_PARAMS );
static RTYPE compiled_block_1_1441( CONT_PARAMS );
static RTYPE compiled_block_1_1464( CONT_PARAMS );
static RTYPE compiled_block_1_1444( CONT_PARAMS );
static RTYPE compiled_block_1_1445( CONT_PARAMS );
static RTYPE compiled_block_1_1460( CONT_PARAMS );
static RTYPE compiled_block_1_1454( CONT_PARAMS );
static RTYPE compiled_block_1_1448( CONT_PARAMS );
static RTYPE compiled_temp_1_288( CONT_PARAMS );
static RTYPE compiled_temp_1_287( CONT_PARAMS );
static RTYPE compiled_temp_1_286( CONT_PARAMS );
static RTYPE compiled_temp_1_285( CONT_PARAMS );
static RTYPE compiled_temp_1_284( CONT_PARAMS );
static RTYPE compiled_temp_1_283( CONT_PARAMS );
static RTYPE compiled_temp_1_282( CONT_PARAMS );
static RTYPE compiled_temp_1_281( CONT_PARAMS );
static RTYPE compiled_temp_1_280( CONT_PARAMS );
static RTYPE compiled_temp_1_279( CONT_PARAMS );
static RTYPE compiled_temp_1_278( CONT_PARAMS );
static RTYPE compiled_block_1_1472( CONT_PARAMS );
static RTYPE compiled_temp_1_276( CONT_PARAMS );
static RTYPE compiled_block_1_1463( CONT_PARAMS );
static RTYPE compiled_temp_1_275( CONT_PARAMS );
static RTYPE compiled_block_1_1461( CONT_PARAMS );
static RTYPE compiled_temp_1_274( CONT_PARAMS );
static RTYPE compiled_block_1_1459( CONT_PARAMS );
static RTYPE compiled_temp_1_273( CONT_PARAMS );
static RTYPE compiled_block_1_1457( CONT_PARAMS );
static RTYPE compiled_temp_1_272( CONT_PARAMS );
static RTYPE compiled_block_1_1455( CONT_PARAMS );
static RTYPE compiled_temp_1_271( CONT_PARAMS );
static RTYPE compiled_block_1_1453( CONT_PARAMS );
static RTYPE compiled_temp_1_270( CONT_PARAMS );
static RTYPE compiled_block_1_1451( CONT_PARAMS );
static RTYPE compiled_temp_1_269( CONT_PARAMS );
static RTYPE compiled_block_1_1449( CONT_PARAMS );
static RTYPE compiled_temp_1_268( CONT_PARAMS );
static RTYPE compiled_block_1_1446( CONT_PARAMS );
static RTYPE compiled_temp_1_267( CONT_PARAMS );
static RTYPE compiled_block_1_1442( CONT_PARAMS );
static RTYPE compiled_start_1_266( CONT_PARAMS );
static RTYPE compiled_block_1_1470( CONT_PARAMS );
static RTYPE compiled_block_1_1468( CONT_PARAMS );
static RTYPE compiled_temp_1_292( CONT_PARAMS );
static RTYPE compiled_temp_1_291( CONT_PARAMS );
static RTYPE compiled_block_1_1469( CONT_PARAMS );
static RTYPE compiled_temp_1_290( CONT_PARAMS );
static RTYPE compiled_block_1_1467( CONT_PARAMS );
static RTYPE compiled_temp_1_289( CONT_PARAMS );
static RTYPE compiled_start_1_277( CONT_PARAMS );
static RTYPE compiled_block_1_1435( CONT_PARAMS );
static RTYPE compiled_temp_1_293( CONT_PARAMS );
static RTYPE compiled_start_1_40( CONT_PARAMS );
static RTYPE compiled_block_1_1434( CONT_PARAMS );
static RTYPE compiled_block_1_1431( CONT_PARAMS );
static RTYPE compiled_block_1_1432( CONT_PARAMS );
static RTYPE compiled_temp_1_295( CONT_PARAMS );
static RTYPE compiled_temp_1_294( CONT_PARAMS );
static RTYPE compiled_block_1_1433( CONT_PARAMS );
static RTYPE compiled_start_1_39( CONT_PARAMS );
static RTYPE compiled_block_1_1426( CONT_PARAMS );
static RTYPE compiled_block_1_1429( CONT_PARAMS );
static RTYPE compiled_block_1_1428( CONT_PARAMS );
static RTYPE compiled_block_1_1424( CONT_PARAMS );
static RTYPE compiled_block_1_1427( CONT_PARAMS );
static RTYPE compiled_temp_1_299( CONT_PARAMS );
static RTYPE compiled_temp_1_298( CONT_PARAMS );
static RTYPE compiled_temp_1_297( CONT_PARAMS );
static RTYPE compiled_block_1_1430( CONT_PARAMS );
static RTYPE compiled_temp_1_296( CONT_PARAMS );
static RTYPE compiled_block_1_1425( CONT_PARAMS );
static RTYPE compiled_start_1_38( CONT_PARAMS );
static RTYPE compiled_block_1_1416( CONT_PARAMS );
static RTYPE compiled_block_1_1420( CONT_PARAMS );
static RTYPE compiled_block_1_1421( CONT_PARAMS );
static RTYPE compiled_block_1_1414( CONT_PARAMS );
static RTYPE compiled_block_1_1417( CONT_PARAMS );
static RTYPE compiled_block_1_1418( CONT_PARAMS );
static RTYPE compiled_block_1_1422( CONT_PARAMS );
static RTYPE compiled_temp_1_305( CONT_PARAMS );
static RTYPE compiled_temp_1_304( CONT_PARAMS );
static RTYPE compiled_temp_1_303( CONT_PARAMS );
static RTYPE compiled_temp_1_302( CONT_PARAMS );
static RTYPE compiled_block_1_1423( CONT_PARAMS );
static RTYPE compiled_temp_1_301( CONT_PARAMS );
static RTYPE compiled_block_1_1419( CONT_PARAMS );
static RTYPE compiled_temp_1_300( CONT_PARAMS );
static RTYPE compiled_block_1_1415( CONT_PARAMS );
static RTYPE compiled_start_1_37( CONT_PARAMS );
static RTYPE compiled_block_1_1404( CONT_PARAMS );
static RTYPE compiled_block_1_1411( CONT_PARAMS );
static RTYPE compiled_block_1_1408( CONT_PARAMS );
static RTYPE compiled_block_1_1412( CONT_PARAMS );
static RTYPE compiled_block_1_1402( CONT_PARAMS );
static RTYPE compiled_block_1_1405( CONT_PARAMS );
static RTYPE compiled_block_1_1406( CONT_PARAMS );
static RTYPE compiled_block_1_1409( CONT_PARAMS );
static RTYPE compiled_temp_1_313( CONT_PARAMS );
static RTYPE compiled_temp_1_312( CONT_PARAMS );
static RTYPE compiled_temp_1_311( CONT_PARAMS );
static RTYPE compiled_temp_1_310( CONT_PARAMS );
static RTYPE compiled_temp_1_309( CONT_PARAMS );
static RTYPE compiled_block_1_1413( CONT_PARAMS );
static RTYPE compiled_temp_1_308( CONT_PARAMS );
static RTYPE compiled_block_1_1410( CONT_PARAMS );
static RTYPE compiled_temp_1_307( CONT_PARAMS );
static RTYPE compiled_block_1_1407( CONT_PARAMS );
static RTYPE compiled_temp_1_306( CONT_PARAMS );
static RTYPE compiled_block_1_1403( CONT_PARAMS );
static RTYPE compiled_start_1_36( CONT_PARAMS );
static RTYPE compiled_block_1_1390( CONT_PARAMS );
static RTYPE compiled_block_1_1400( CONT_PARAMS );
static RTYPE compiled_block_1_1394( CONT_PARAMS );
static RTYPE compiled_block_1_1397( CONT_PARAMS );
static RTYPE compiled_block_1_1388( CONT_PARAMS );
static RTYPE compiled_block_1_1391( CONT_PARAMS );
static RTYPE compiled_block_1_1392( CONT_PARAMS );
static RTYPE compiled_block_1_1399( CONT_PARAMS );
static RTYPE compiled_block_1_1395( CONT_PARAMS );
static RTYPE compiled_temp_1_323( CONT_PARAMS );
static RTYPE compiled_temp_1_322( CONT_PARAMS );
static RTYPE compiled_temp_1_321( CONT_PARAMS );
static RTYPE compiled_temp_1_320( CONT_PARAMS );
static RTYPE compiled_temp_1_319( CONT_PARAMS );
static RTYPE compiled_temp_1_318( CONT_PARAMS );
static RTYPE compiled_block_1_1401( CONT_PARAMS );
static RTYPE compiled_temp_1_317( CONT_PARAMS );
static RTYPE compiled_block_1_1398( CONT_PARAMS );
static RTYPE compiled_temp_1_316( CONT_PARAMS );
static RTYPE compiled_block_1_1396( CONT_PARAMS );
static RTYPE compiled_temp_1_315( CONT_PARAMS );
static RTYPE compiled_block_1_1393( CONT_PARAMS );
static RTYPE compiled_temp_1_314( CONT_PARAMS );
static RTYPE compiled_block_1_1389( CONT_PARAMS );
static RTYPE compiled_start_1_35( CONT_PARAMS );
static RTYPE compiled_block_1_1374( CONT_PARAMS );
static RTYPE compiled_block_1_1383( CONT_PARAMS );
static RTYPE compiled_block_1_1378( CONT_PARAMS );
static RTYPE compiled_block_1_1385( CONT_PARAMS );
static RTYPE compiled_block_1_1381( CONT_PARAMS );
static RTYPE compiled_block_1_1372( CONT_PARAMS );
static RTYPE compiled_block_1_1375( CONT_PARAMS );
static RTYPE compiled_block_1_1376( CONT_PARAMS );
static RTYPE compiled_block_1_1386( CONT_PARAMS );
static RTYPE compiled_block_1_1379( CONT_PARAMS );
static RTYPE compiled_temp_1_335( CONT_PARAMS );
static RTYPE compiled_temp_1_334( CONT_PARAMS );
static RTYPE compiled_temp_1_333( CONT_PARAMS );
static RTYPE compiled_temp_1_332( CONT_PARAMS );
static RTYPE compiled_temp_1_331( CONT_PARAMS );
static RTYPE compiled_temp_1_330( CONT_PARAMS );
static RTYPE compiled_temp_1_329( CONT_PARAMS );
static RTYPE compiled_block_1_1387( CONT_PARAMS );
static RTYPE compiled_temp_1_328( CONT_PARAMS );
static RTYPE compiled_block_1_1384( CONT_PARAMS );
static RTYPE compiled_temp_1_327( CONT_PARAMS );
static RTYPE compiled_block_1_1382( CONT_PARAMS );
static RTYPE compiled_temp_1_326( CONT_PARAMS );
static RTYPE compiled_block_1_1380( CONT_PARAMS );
static RTYPE compiled_temp_1_325( CONT_PARAMS );
static RTYPE compiled_block_1_1377( CONT_PARAMS );
static RTYPE compiled_temp_1_324( CONT_PARAMS );
static RTYPE compiled_block_1_1373( CONT_PARAMS );
static RTYPE compiled_start_1_34( CONT_PARAMS );
static RTYPE compiled_block_1_1369( CONT_PARAMS );
static RTYPE compiled_block_1_1356( CONT_PARAMS );
static RTYPE compiled_block_1_1365( CONT_PARAMS );
static RTYPE compiled_block_1_1360( CONT_PARAMS );
static RTYPE compiled_block_1_1370( CONT_PARAMS );
static RTYPE compiled_block_1_1363( CONT_PARAMS );
static RTYPE compiled_block_1_1354( CONT_PARAMS );
static RTYPE compiled_block_1_1357( CONT_PARAMS );
static RTYPE compiled_block_1_1358( CONT_PARAMS );
static RTYPE compiled_block_1_1367( CONT_PARAMS );
static RTYPE compiled_block_1_1361( CONT_PARAMS );
static RTYPE compiled_temp_1_349( CONT_PARAMS );
static RTYPE compiled_temp_1_348( CONT_PARAMS );
static RTYPE compiled_temp_1_347( CONT_PARAMS );
static RTYPE compiled_temp_1_346( CONT_PARAMS );
static RTYPE compiled_temp_1_345( CONT_PARAMS );
static RTYPE compiled_temp_1_344( CONT_PARAMS );
static RTYPE compiled_temp_1_343( CONT_PARAMS );
static RTYPE compiled_temp_1_342( CONT_PARAMS );
static RTYPE compiled_block_1_1371( CONT_PARAMS );
static RTYPE compiled_temp_1_341( CONT_PARAMS );
static RTYPE compiled_block_1_1368( CONT_PARAMS );
static RTYPE compiled_temp_1_340( CONT_PARAMS );
static RTYPE compiled_block_1_1366( CONT_PARAMS );
static RTYPE compiled_temp_1_339( CONT_PARAMS );
static RTYPE compiled_block_1_1364( CONT_PARAMS );
static RTYPE compiled_temp_1_338( CONT_PARAMS );
static RTYPE compiled_block_1_1362( CONT_PARAMS );
static RTYPE compiled_temp_1_337( CONT_PARAMS );
static RTYPE compiled_block_1_1359( CONT_PARAMS );
static RTYPE compiled_temp_1_336( CONT_PARAMS );
static RTYPE compiled_block_1_1355( CONT_PARAMS );
static RTYPE compiled_start_1_33( CONT_PARAMS );
static RTYPE compiled_block_1_1352( CONT_PARAMS );
static RTYPE compiled_block_1_1336( CONT_PARAMS );
static RTYPE compiled_block_1_1345( CONT_PARAMS );
static RTYPE compiled_block_1_1340( CONT_PARAMS );
static RTYPE compiled_block_1_1349( CONT_PARAMS );
static RTYPE compiled_block_1_1343( CONT_PARAMS );
static RTYPE compiled_block_1_1334( CONT_PARAMS );
static RTYPE compiled_block_1_1337( CONT_PARAMS );
static RTYPE compiled_block_1_1338( CONT_PARAMS );
static RTYPE compiled_block_1_1351( CONT_PARAMS );
static RTYPE compiled_block_1_1347( CONT_PARAMS );
static RTYPE compiled_block_1_1341( CONT_PARAMS );
static RTYPE compiled_temp_1_365( CONT_PARAMS );
static RTYPE compiled_temp_1_364( CONT_PARAMS );
static RTYPE compiled_temp_1_363( CONT_PARAMS );
static RTYPE compiled_temp_1_362( CONT_PARAMS );
static RTYPE compiled_temp_1_361( CONT_PARAMS );
static RTYPE compiled_temp_1_360( CONT_PARAMS );
static RTYPE compiled_temp_1_359( CONT_PARAMS );
static RTYPE compiled_temp_1_358( CONT_PARAMS );
static RTYPE compiled_temp_1_357( CONT_PARAMS );
static RTYPE compiled_block_1_1353( CONT_PARAMS );
static RTYPE compiled_temp_1_356( CONT_PARAMS );
static RTYPE compiled_block_1_1350( CONT_PARAMS );
static RTYPE compiled_temp_1_355( CONT_PARAMS );
static RTYPE compiled_block_1_1348( CONT_PARAMS );
static RTYPE compiled_temp_1_354( CONT_PARAMS );
static RTYPE compiled_block_1_1346( CONT_PARAMS );
static RTYPE compiled_temp_1_353( CONT_PARAMS );
static RTYPE compiled_block_1_1344( CONT_PARAMS );
static RTYPE compiled_temp_1_352( CONT_PARAMS );
static RTYPE compiled_block_1_1342( CONT_PARAMS );
static RTYPE compiled_temp_1_351( CONT_PARAMS );
static RTYPE compiled_block_1_1339( CONT_PARAMS );
static RTYPE compiled_temp_1_350( CONT_PARAMS );
static RTYPE compiled_block_1_1335( CONT_PARAMS );
static RTYPE compiled_start_1_32( CONT_PARAMS );
static RTYPE compiled_block_1_1329( CONT_PARAMS );
static RTYPE compiled_block_1_1314( CONT_PARAMS );
static RTYPE compiled_block_1_1323( CONT_PARAMS );
static RTYPE compiled_block_1_1318( CONT_PARAMS );
static RTYPE compiled_block_1_1331( CONT_PARAMS );
static RTYPE compiled_block_1_1327( CONT_PARAMS );
static RTYPE compiled_block_1_1321( CONT_PARAMS );
static RTYPE compiled_block_1_1312( CONT_PARAMS );
static RTYPE compiled_block_1_1315( CONT_PARAMS );
static RTYPE compiled_block_1_1316( CONT_PARAMS );
static RTYPE compiled_block_1_1332( CONT_PARAMS );
static RTYPE compiled_block_1_1325( CONT_PARAMS );
static RTYPE compiled_block_1_1319( CONT_PARAMS );
static RTYPE compiled_temp_1_383( CONT_PARAMS );
static RTYPE compiled_temp_1_382( CONT_PARAMS );
static RTYPE compiled_temp_1_381( CONT_PARAMS );
static RTYPE compiled_temp_1_380( CONT_PARAMS );
static RTYPE compiled_temp_1_379( CONT_PARAMS );
static RTYPE compiled_temp_1_378( CONT_PARAMS );
static RTYPE compiled_temp_1_377( CONT_PARAMS );
static RTYPE compiled_temp_1_376( CONT_PARAMS );
static RTYPE compiled_temp_1_375( CONT_PARAMS );
static RTYPE compiled_temp_1_374( CONT_PARAMS );
static RTYPE compiled_block_1_1333( CONT_PARAMS );
static RTYPE compiled_temp_1_373( CONT_PARAMS );
static RTYPE compiled_block_1_1330( CONT_PARAMS );
static RTYPE compiled_temp_1_372( CONT_PARAMS );
static RTYPE compiled_block_1_1328( CONT_PARAMS );
static RTYPE compiled_temp_1_371( CONT_PARAMS );
static RTYPE compiled_block_1_1326( CONT_PARAMS );
static RTYPE compiled_temp_1_370( CONT_PARAMS );
static RTYPE compiled_block_1_1324( CONT_PARAMS );
static RTYPE compiled_temp_1_369( CONT_PARAMS );
static RTYPE compiled_block_1_1322( CONT_PARAMS );
static RTYPE compiled_temp_1_368( CONT_PARAMS );
static RTYPE compiled_block_1_1320( CONT_PARAMS );
static RTYPE compiled_temp_1_367( CONT_PARAMS );
static RTYPE compiled_block_1_1317( CONT_PARAMS );
static RTYPE compiled_temp_1_366( CONT_PARAMS );
static RTYPE compiled_block_1_1313( CONT_PARAMS );
static RTYPE compiled_start_1_31( CONT_PARAMS );
static RTYPE compiled_start_1_30( CONT_PARAMS );
static RTYPE compiled_block_1_1282( CONT_PARAMS );
static RTYPE compiled_block_1_1279( CONT_PARAMS );
static RTYPE compiled_block_1_1281( CONT_PARAMS );
static RTYPE compiled_temp_1_385( CONT_PARAMS );
static RTYPE compiled_start_1_384( CONT_PARAMS );
static RTYPE compiled_block_1_1301( CONT_PARAMS );
static RTYPE compiled_block_1_1290( CONT_PARAMS );
static RTYPE compiled_block_1_1287( CONT_PARAMS );
static RTYPE compiled_block_1_1294( CONT_PARAMS );
static RTYPE compiled_block_1_1291( CONT_PARAMS );
static RTYPE compiled_block_1_1298( CONT_PARAMS );
static RTYPE compiled_block_1_1295( CONT_PARAMS );
static RTYPE compiled_block_1_1284( CONT_PARAMS );
static RTYPE compiled_block_1_1302( CONT_PARAMS );
static RTYPE compiled_block_1_1299( CONT_PARAMS );
static RTYPE compiled_block_1_1288( CONT_PARAMS );
static RTYPE compiled_block_1_1285( CONT_PARAMS );
static RTYPE compiled_block_1_1303( CONT_PARAMS );
static RTYPE compiled_block_1_1292( CONT_PARAMS );
static RTYPE compiled_block_1_1289( CONT_PARAMS );
static RTYPE compiled_block_1_1296( CONT_PARAMS );
static RTYPE compiled_block_1_1293( CONT_PARAMS );
static RTYPE compiled_block_1_1300( CONT_PARAMS );
static RTYPE compiled_block_1_1297( CONT_PARAMS );
static RTYPE compiled_block_1_1286( CONT_PARAMS );
static RTYPE compiled_block_1_1304( CONT_PARAMS );
static RTYPE compiled_temp_1_408( CONT_PARAMS );
static RTYPE compiled_temp_1_407( CONT_PARAMS );
static RTYPE compiled_temp_1_406( CONT_PARAMS );
static RTYPE compiled_temp_1_405( CONT_PARAMS );
static RTYPE compiled_temp_1_404( CONT_PARAMS );
static RTYPE compiled_temp_1_403( CONT_PARAMS );
static RTYPE compiled_temp_1_402( CONT_PARAMS );
static RTYPE compiled_temp_1_401( CONT_PARAMS );
static RTYPE compiled_temp_1_400( CONT_PARAMS );
static RTYPE compiled_temp_1_399( CONT_PARAMS );
static RTYPE compiled_temp_1_398( CONT_PARAMS );
static RTYPE compiled_block_1_1310( CONT_PARAMS );
static RTYPE compiled_temp_1_396( CONT_PARAMS );
static RTYPE compiled_temp_1_395( CONT_PARAMS );
static RTYPE compiled_temp_1_394( CONT_PARAMS );
static RTYPE compiled_temp_1_393( CONT_PARAMS );
static RTYPE compiled_temp_1_392( CONT_PARAMS );
static RTYPE compiled_temp_1_391( CONT_PARAMS );
static RTYPE compiled_temp_1_390( CONT_PARAMS );
static RTYPE compiled_temp_1_389( CONT_PARAMS );
static RTYPE compiled_temp_1_388( CONT_PARAMS );
static RTYPE compiled_temp_1_387( CONT_PARAMS );
static RTYPE compiled_start_1_386( CONT_PARAMS );
static RTYPE compiled_block_1_1307( CONT_PARAMS );
static RTYPE compiled_block_1_1308( CONT_PARAMS );
static RTYPE compiled_temp_1_411( CONT_PARAMS );
static RTYPE compiled_temp_1_410( CONT_PARAMS );
static RTYPE compiled_block_1_1306( CONT_PARAMS );
static RTYPE compiled_temp_1_409( CONT_PARAMS );
static RTYPE compiled_start_1_397( CONT_PARAMS );
static RTYPE compiled_block_1_1278( CONT_PARAMS );
static RTYPE compiled_temp_1_412( CONT_PARAMS );
static RTYPE compiled_start_1_29( CONT_PARAMS );
static RTYPE compiled_block_1_1276( CONT_PARAMS );
static RTYPE compiled_block_1_1275( CONT_PARAMS );
static RTYPE compiled_block_1_1277( CONT_PARAMS );
static RTYPE compiled_temp_1_414( CONT_PARAMS );
static RTYPE compiled_temp_1_413( CONT_PARAMS );
static RTYPE compiled_start_1_28( CONT_PARAMS );
static RTYPE compiled_block_1_1270( CONT_PARAMS );
static RTYPE compiled_block_1_1274( CONT_PARAMS );
static RTYPE compiled_block_1_1271( CONT_PARAMS );
static RTYPE compiled_block_1_1273( CONT_PARAMS );
static RTYPE compiled_block_1_1272( CONT_PARAMS );
static RTYPE compiled_temp_1_418( CONT_PARAMS );
static RTYPE compiled_temp_1_417( CONT_PARAMS );
static RTYPE compiled_temp_1_416( CONT_PARAMS );
static RTYPE compiled_temp_1_415( CONT_PARAMS );
static RTYPE compiled_start_1_27( CONT_PARAMS );
static RTYPE compiled_block_1_1263( CONT_PARAMS );
static RTYPE compiled_block_1_1266( CONT_PARAMS );
static RTYPE compiled_block_1_1268( CONT_PARAMS );
static RTYPE compiled_block_1_1267( CONT_PARAMS );
static RTYPE compiled_block_1_1264( CONT_PARAMS );
static RTYPE compiled_block_1_1265( CONT_PARAMS );
static RTYPE compiled_block_1_1269( CONT_PARAMS );
static RTYPE compiled_temp_1_424( CONT_PARAMS );
static RTYPE compiled_temp_1_423( CONT_PARAMS );
static RTYPE compiled_temp_1_422( CONT_PARAMS );
static RTYPE compiled_temp_1_421( CONT_PARAMS );
static RTYPE compiled_temp_1_420( CONT_PARAMS );
static RTYPE compiled_temp_1_419( CONT_PARAMS );
static RTYPE compiled_start_1_26( CONT_PARAMS );
static RTYPE compiled_block_1_1254( CONT_PARAMS );
static RTYPE compiled_block_1_1260( CONT_PARAMS );
static RTYPE compiled_block_1_1257( CONT_PARAMS );
static RTYPE compiled_block_1_1258( CONT_PARAMS );
static RTYPE compiled_block_1_1262( CONT_PARAMS );
static RTYPE compiled_block_1_1255( CONT_PARAMS );
static RTYPE compiled_block_1_1256( CONT_PARAMS );
static RTYPE compiled_block_1_1259( CONT_PARAMS );
static RTYPE compiled_block_1_1261( CONT_PARAMS );
static RTYPE compiled_temp_1_432( CONT_PARAMS );
static RTYPE compiled_temp_1_431( CONT_PARAMS );
static RTYPE compiled_temp_1_430( CONT_PARAMS );
static RTYPE compiled_temp_1_429( CONT_PARAMS );
static RTYPE compiled_temp_1_428( CONT_PARAMS );
static RTYPE compiled_temp_1_427( CONT_PARAMS );
static RTYPE compiled_temp_1_426( CONT_PARAMS );
static RTYPE compiled_temp_1_425( CONT_PARAMS );
static RTYPE compiled_start_1_25( CONT_PARAMS );
static RTYPE compiled_block_1_1243( CONT_PARAMS );
static RTYPE compiled_block_1_1253( CONT_PARAMS );
static RTYPE compiled_block_1_1246( CONT_PARAMS );
static RTYPE compiled_block_1_1247( CONT_PARAMS );
static RTYPE compiled_block_1_1250( CONT_PARAMS );
static RTYPE compiled_block_1_1244( CONT_PARAMS );
static RTYPE compiled_block_1_1252( CONT_PARAMS );
static RTYPE compiled_block_1_1245( CONT_PARAMS );
static RTYPE compiled_block_1_1251( CONT_PARAMS );
static RTYPE compiled_block_1_1248( CONT_PARAMS );
static RTYPE compiled_block_1_1249( CONT_PARAMS );
static RTYPE compiled_temp_1_442( CONT_PARAMS );
static RTYPE compiled_temp_1_441( CONT_PARAMS );
static RTYPE compiled_temp_1_440( CONT_PARAMS );
static RTYPE compiled_temp_1_439( CONT_PARAMS );
static RTYPE compiled_temp_1_438( CONT_PARAMS );
static RTYPE compiled_temp_1_437( CONT_PARAMS );
static RTYPE compiled_temp_1_436( CONT_PARAMS );
static RTYPE compiled_temp_1_435( CONT_PARAMS );
static RTYPE compiled_temp_1_434( CONT_PARAMS );
static RTYPE compiled_temp_1_433( CONT_PARAMS );
static RTYPE compiled_start_1_24( CONT_PARAMS );
static RTYPE compiled_block_1_1230( CONT_PARAMS );
static RTYPE compiled_block_1_1239( CONT_PARAMS );
static RTYPE compiled_block_1_1233( CONT_PARAMS );
static RTYPE compiled_block_1_1241( CONT_PARAMS );
static RTYPE compiled_block_1_1234( CONT_PARAMS );
static RTYPE compiled_block_1_1240( CONT_PARAMS );
static RTYPE compiled_block_1_1237( CONT_PARAMS );
static RTYPE compiled_block_1_1231( CONT_PARAMS );
static RTYPE compiled_block_1_1238( CONT_PARAMS );
static RTYPE compiled_block_1_1232( CONT_PARAMS );
static RTYPE compiled_block_1_1242( CONT_PARAMS );
static RTYPE compiled_block_1_1235( CONT_PARAMS );
static RTYPE compiled_block_1_1236( CONT_PARAMS );
static RTYPE compiled_temp_1_454( CONT_PARAMS );
static RTYPE compiled_temp_1_453( CONT_PARAMS );
static RTYPE compiled_temp_1_452( CONT_PARAMS );
static RTYPE compiled_temp_1_451( CONT_PARAMS );
static RTYPE compiled_temp_1_450( CONT_PARAMS );
static RTYPE compiled_temp_1_449( CONT_PARAMS );
static RTYPE compiled_temp_1_448( CONT_PARAMS );
static RTYPE compiled_temp_1_447( CONT_PARAMS );
static RTYPE compiled_temp_1_446( CONT_PARAMS );
static RTYPE compiled_temp_1_445( CONT_PARAMS );
static RTYPE compiled_temp_1_444( CONT_PARAMS );
static RTYPE compiled_temp_1_443( CONT_PARAMS );
static RTYPE compiled_start_1_23( CONT_PARAMS );
static RTYPE compiled_block_1_1215( CONT_PARAMS );
static RTYPE compiled_block_1_1227( CONT_PARAMS );
static RTYPE compiled_block_1_1224( CONT_PARAMS );
static RTYPE compiled_block_1_1218( CONT_PARAMS );
static RTYPE compiled_block_1_1225( CONT_PARAMS );
static RTYPE compiled_block_1_1219( CONT_PARAMS );
static RTYPE compiled_block_1_1229( CONT_PARAMS );
static RTYPE compiled_block_1_1222( CONT_PARAMS );
static RTYPE compiled_block_1_1216( CONT_PARAMS );
static RTYPE compiled_block_1_1223( CONT_PARAMS );
static RTYPE compiled_block_1_1217( CONT_PARAMS );
static RTYPE compiled_block_1_1226( CONT_PARAMS );
static RTYPE compiled_block_1_1220( CONT_PARAMS );
static RTYPE compiled_block_1_1228( CONT_PARAMS );
static RTYPE compiled_block_1_1221( CONT_PARAMS );
static RTYPE compiled_temp_1_468( CONT_PARAMS );
static RTYPE compiled_temp_1_467( CONT_PARAMS );
static RTYPE compiled_temp_1_466( CONT_PARAMS );
static RTYPE compiled_temp_1_465( CONT_PARAMS );
static RTYPE compiled_temp_1_464( CONT_PARAMS );
static RTYPE compiled_temp_1_463( CONT_PARAMS );
static RTYPE compiled_temp_1_462( CONT_PARAMS );
static RTYPE compiled_temp_1_461( CONT_PARAMS );
static RTYPE compiled_temp_1_460( CONT_PARAMS );
static RTYPE compiled_temp_1_459( CONT_PARAMS );
static RTYPE compiled_temp_1_458( CONT_PARAMS );
static RTYPE compiled_temp_1_457( CONT_PARAMS );
static RTYPE compiled_temp_1_456( CONT_PARAMS );
static RTYPE compiled_temp_1_455( CONT_PARAMS );
static RTYPE compiled_start_1_22( CONT_PARAMS );
static RTYPE compiled_block_1_1198( CONT_PARAMS );
static RTYPE compiled_block_1_1214( CONT_PARAMS );
static RTYPE compiled_block_1_1207( CONT_PARAMS );
static RTYPE compiled_block_1_1201( CONT_PARAMS );
static RTYPE compiled_block_1_1208( CONT_PARAMS );
static RTYPE compiled_block_1_1202( CONT_PARAMS );
static RTYPE compiled_block_1_1211( CONT_PARAMS );
static RTYPE compiled_block_1_1205( CONT_PARAMS );
static RTYPE compiled_block_1_1199( CONT_PARAMS );
static RTYPE compiled_block_1_1213( CONT_PARAMS );
static RTYPE compiled_block_1_1206( CONT_PARAMS );
static RTYPE compiled_block_1_1200( CONT_PARAMS );
static RTYPE compiled_block_1_1212( CONT_PARAMS );
static RTYPE compiled_block_1_1209( CONT_PARAMS );
static RTYPE compiled_block_1_1203( CONT_PARAMS );
static RTYPE compiled_block_1_1210( CONT_PARAMS );
static RTYPE compiled_block_1_1204( CONT_PARAMS );
static RTYPE compiled_temp_1_484( CONT_PARAMS );
static RTYPE compiled_temp_1_483( CONT_PARAMS );
static RTYPE compiled_temp_1_482( CONT_PARAMS );
static RTYPE compiled_temp_1_481( CONT_PARAMS );
static RTYPE compiled_temp_1_480( CONT_PARAMS );
static RTYPE compiled_temp_1_479( CONT_PARAMS );
static RTYPE compiled_temp_1_478( CONT_PARAMS );
static RTYPE compiled_temp_1_477( CONT_PARAMS );
static RTYPE compiled_temp_1_476( CONT_PARAMS );
static RTYPE compiled_temp_1_475( CONT_PARAMS );
static RTYPE compiled_temp_1_474( CONT_PARAMS );
static RTYPE compiled_temp_1_473( CONT_PARAMS );
static RTYPE compiled_temp_1_472( CONT_PARAMS );
static RTYPE compiled_temp_1_471( CONT_PARAMS );
static RTYPE compiled_temp_1_470( CONT_PARAMS );
static RTYPE compiled_temp_1_469( CONT_PARAMS );
static RTYPE compiled_start_1_21( CONT_PARAMS );
static RTYPE compiled_block_1_1179( CONT_PARAMS );
static RTYPE compiled_block_1_1194( CONT_PARAMS );
static RTYPE compiled_block_1_1188( CONT_PARAMS );
static RTYPE compiled_block_1_1182( CONT_PARAMS );
static RTYPE compiled_block_1_1196( CONT_PARAMS );
static RTYPE compiled_block_1_1189( CONT_PARAMS );
static RTYPE compiled_block_1_1183( CONT_PARAMS );
static RTYPE compiled_block_1_1195( CONT_PARAMS );
static RTYPE compiled_block_1_1192( CONT_PARAMS );
static RTYPE compiled_block_1_1186( CONT_PARAMS );
static RTYPE compiled_block_1_1180( CONT_PARAMS );
static RTYPE compiled_block_1_1193( CONT_PARAMS );
static RTYPE compiled_block_1_1187( CONT_PARAMS );
static RTYPE compiled_block_1_1181( CONT_PARAMS );
static RTYPE compiled_block_1_1197( CONT_PARAMS );
static RTYPE compiled_block_1_1190( CONT_PARAMS );
static RTYPE compiled_block_1_1184( CONT_PARAMS );
static RTYPE compiled_block_1_1191( CONT_PARAMS );
static RTYPE compiled_block_1_1185( CONT_PARAMS );
static RTYPE compiled_temp_1_502( CONT_PARAMS );
static RTYPE compiled_temp_1_501( CONT_PARAMS );
static RTYPE compiled_temp_1_500( CONT_PARAMS );
static RTYPE compiled_temp_1_499( CONT_PARAMS );
static RTYPE compiled_temp_1_498( CONT_PARAMS );
static RTYPE compiled_temp_1_497( CONT_PARAMS );
static RTYPE compiled_temp_1_496( CONT_PARAMS );
static RTYPE compiled_temp_1_495( CONT_PARAMS );
static RTYPE compiled_temp_1_494( CONT_PARAMS );
static RTYPE compiled_temp_1_493( CONT_PARAMS );
static RTYPE compiled_temp_1_492( CONT_PARAMS );
static RTYPE compiled_temp_1_491( CONT_PARAMS );
static RTYPE compiled_temp_1_490( CONT_PARAMS );
static RTYPE compiled_temp_1_489( CONT_PARAMS );
static RTYPE compiled_temp_1_488( CONT_PARAMS );
static RTYPE compiled_temp_1_487( CONT_PARAMS );
static RTYPE compiled_temp_1_486( CONT_PARAMS );
static RTYPE compiled_temp_1_485( CONT_PARAMS );
static RTYPE compiled_start_1_20( CONT_PARAMS );
static RTYPE compiled_block_1_1178( CONT_PARAMS );
static RTYPE compiled_block_1_1176( CONT_PARAMS );
static RTYPE compiled_block_1_1174( CONT_PARAMS );
static RTYPE compiled_block_1_1172( CONT_PARAMS );
static RTYPE compiled_start_1_19( CONT_PARAMS );
static RTYPE compiled_block_1_1169( CONT_PARAMS );
static RTYPE compiled_start_1_18( CONT_PARAMS );
static RTYPE compiled_start_1_17( CONT_PARAMS );
static RTYPE compiled_start_1_16( CONT_PARAMS );
static RTYPE compiled_start_1_15( CONT_PARAMS );
static RTYPE compiled_start_1_14( CONT_PARAMS );
static RTYPE compiled_block_1_1167( CONT_PARAMS );
static RTYPE compiled_block_1_1168( CONT_PARAMS );
static RTYPE compiled_temp_1_504( CONT_PARAMS );
static RTYPE compiled_temp_1_503( CONT_PARAMS );
static RTYPE compiled_start_1_13( CONT_PARAMS );
static RTYPE compiled_block_1_1166( CONT_PARAMS );
static RTYPE compiled_block_1_1164( CONT_PARAMS );
static RTYPE compiled_block_1_1165( CONT_PARAMS );
static RTYPE compiled_temp_1_508( CONT_PARAMS );
static RTYPE compiled_temp_1_507( CONT_PARAMS );
static RTYPE compiled_temp_1_506( CONT_PARAMS );
static RTYPE compiled_temp_1_505( CONT_PARAMS );
static RTYPE compiled_start_1_12( CONT_PARAMS );
static RTYPE compiled_start_1_11( CONT_PARAMS );
static RTYPE compiled_start_1_10( CONT_PARAMS );
static RTYPE compiled_start_1_9( CONT_PARAMS );
static RTYPE compiled_block_1_1159( CONT_PARAMS );
static RTYPE compiled_block_1_1161( CONT_PARAMS );
static RTYPE compiled_block_1_1160( CONT_PARAMS );
static RTYPE compiled_temp_1_512( CONT_PARAMS );
static RTYPE compiled_temp_1_511( CONT_PARAMS );
static RTYPE compiled_block_1_1158( CONT_PARAMS );
static RTYPE compiled_temp_1_510( CONT_PARAMS );
static RTYPE compiled_start_1_509( CONT_PARAMS );
static RTYPE compiled_block_1_1155( CONT_PARAMS );
static RTYPE compiled_block_1_1156( CONT_PARAMS );
static RTYPE compiled_temp_1_514( CONT_PARAMS );
static RTYPE compiled_block_1_1154( CONT_PARAMS );
static RTYPE compiled_block_1_1153( CONT_PARAMS );
static RTYPE compiled_temp_1_513( CONT_PARAMS );
static RTYPE compiled_start_1_8( CONT_PARAMS );
static RTYPE compiled_block_1_1151( CONT_PARAMS );
static RTYPE compiled_temp_1_515( CONT_PARAMS );
static RTYPE compiled_start_1_7( CONT_PARAMS );
static RTYPE compiled_block_1_1149( CONT_PARAMS );
static RTYPE compiled_block_1_1148( CONT_PARAMS );
static RTYPE compiled_block_1_1147( CONT_PARAMS );
static RTYPE compiled_block_1_1138( CONT_PARAMS );
static RTYPE compiled_temp_1_521( CONT_PARAMS );
static RTYPE compiled_block_1_1142( CONT_PARAMS );
static RTYPE compiled_temp_1_520( CONT_PARAMS );
static RTYPE compiled_block_1_1141( CONT_PARAMS );
static RTYPE compiled_temp_1_519( CONT_PARAMS );
static RTYPE compiled_block_1_1140( CONT_PARAMS );
static RTYPE compiled_block_1_1139( CONT_PARAMS );
static RTYPE compiled_block_1_1132( CONT_PARAMS );
static RTYPE compiled_temp_1_518( CONT_PARAMS );
static RTYPE compiled_block_1_1135( CONT_PARAMS );
static RTYPE compiled_temp_1_517( CONT_PARAMS );
static RTYPE compiled_block_1_1134( CONT_PARAMS );
static RTYPE compiled_block_1_1133( CONT_PARAMS );
static RTYPE compiled_block_1_1127( CONT_PARAMS );
static RTYPE compiled_temp_1_516( CONT_PARAMS );
static RTYPE compiled_block_1_1129( CONT_PARAMS );
static RTYPE compiled_block_1_1128( CONT_PARAMS );
static RTYPE compiled_block_1_1123( CONT_PARAMS );
static RTYPE compiled_block_1_1124( CONT_PARAMS );
static RTYPE compiled_start_1_6( CONT_PARAMS );
static RTYPE compiled_temp_1_524( CONT_PARAMS );
static RTYPE compiled_block_1_1145( CONT_PARAMS );
static RTYPE compiled_temp_1_523( CONT_PARAMS );
static RTYPE compiled_start_1_522( CONT_PARAMS );
static RTYPE compiled_block_1_1086( CONT_PARAMS );
static RTYPE compiled_block_1_1091( CONT_PARAMS );
static RTYPE compiled_block_1_1102( CONT_PARAMS );
static RTYPE compiled_block_1_1088( CONT_PARAMS );
static RTYPE compiled_block_1_1096( CONT_PARAMS );
static RTYPE compiled_block_1_1095( CONT_PARAMS );
static RTYPE compiled_block_1_1101( CONT_PARAMS );
static RTYPE compiled_block_1_1120( CONT_PARAMS );
static RTYPE compiled_block_1_1119( CONT_PARAMS );
static RTYPE compiled_block_1_1113( CONT_PARAMS );
static RTYPE compiled_block_1_1118( CONT_PARAMS );
static RTYPE compiled_block_1_1117( CONT_PARAMS );
static RTYPE compiled_block_1_1116( CONT_PARAMS );
static RTYPE compiled_block_1_1115( CONT_PARAMS );
static RTYPE compiled_block_1_1114( CONT_PARAMS );
static RTYPE compiled_temp_1_529( CONT_PARAMS );
static RTYPE compiled_block_1_1111( CONT_PARAMS );
static RTYPE compiled_block_1_1098( CONT_PARAMS );
static RTYPE compiled_temp_1_527( CONT_PARAMS );
static RTYPE compiled_temp_1_526( CONT_PARAMS );
static RTYPE compiled_block_1_1100( CONT_PARAMS );
static RTYPE compiled_block_1_1099( CONT_PARAMS );
static RTYPE compiled_block_1_1090( CONT_PARAMS );
static RTYPE compiled_block_1_1094( CONT_PARAMS );
static RTYPE compiled_block_1_1093( CONT_PARAMS );
static RTYPE compiled_block_1_1092( CONT_PARAMS );
static RTYPE compiled_temp_1_525( CONT_PARAMS );
static RTYPE compiled_block_1_1084( CONT_PARAMS );
static RTYPE compiled_block_1_1087( CONT_PARAMS );
static RTYPE compiled_block_1_1085( CONT_PARAMS );
static RTYPE compiled_block_1_1069( CONT_PARAMS );
static RTYPE compiled_block_1_1082( CONT_PARAMS );
static RTYPE compiled_block_1_1080( CONT_PARAMS );
static RTYPE compiled_block_1_1081( CONT_PARAMS );
static RTYPE compiled_block_1_1078( CONT_PARAMS );
static RTYPE compiled_block_1_1076( CONT_PARAMS );
static RTYPE compiled_block_1_1077( CONT_PARAMS );
static RTYPE compiled_block_1_1073( CONT_PARAMS );
static RTYPE compiled_block_1_1074( CONT_PARAMS );
static RTYPE compiled_block_1_1070( CONT_PARAMS );
static RTYPE compiled_block_1_1071( CONT_PARAMS );
static RTYPE compiled_block_1_1068( CONT_PARAMS );
static RTYPE compiled_block_1_1065( CONT_PARAMS );
static RTYPE compiled_block_1_1067( CONT_PARAMS );
static RTYPE compiled_block_1_1066( CONT_PARAMS );
static RTYPE compiled_block_1_1064( CONT_PARAMS );
static RTYPE compiled_start_1_5( CONT_PARAMS );
static RTYPE compiled_block_1_1106( CONT_PARAMS );
static RTYPE compiled_block_1_1107( CONT_PARAMS );
static RTYPE compiled_block_1_1108( CONT_PARAMS );
static RTYPE compiled_block_1_1105( CONT_PARAMS );
static RTYPE compiled_temp_1_533( CONT_PARAMS );
static RTYPE compiled_temp_1_532( CONT_PARAMS );
static RTYPE compiled_block_1_1104( CONT_PARAMS );
static RTYPE compiled_temp_1_531( CONT_PARAMS );
static RTYPE compiled_temp_1_530( CONT_PARAMS );
static RTYPE compiled_start_1_528( CONT_PARAMS );
static RTYPE compiled_block_1_1063( CONT_PARAMS );
static RTYPE compiled_block_1_1042( CONT_PARAMS );
static RTYPE compiled_block_1_1027( CONT_PARAMS );
static RTYPE compiled_block_1_1043( CONT_PARAMS );
static RTYPE compiled_block_1_1056( CONT_PARAMS );
static RTYPE compiled_block_1_1046( CONT_PARAMS );
static RTYPE compiled_block_1_1062( CONT_PARAMS );
static RTYPE compiled_block_1_1039( CONT_PARAMS );
static RTYPE compiled_block_1_1061( CONT_PARAMS );
static RTYPE compiled_block_1_1055( CONT_PARAMS );
static RTYPE compiled_block_1_1060( CONT_PARAMS );
static RTYPE compiled_block_1_1059( CONT_PARAMS );
static RTYPE compiled_block_1_1058( CONT_PARAMS );
static RTYPE compiled_block_1_1057( CONT_PARAMS );
static RTYPE compiled_temp_1_535( CONT_PARAMS );
static RTYPE compiled_block_1_1053( CONT_PARAMS );
static RTYPE compiled_block_1_1050( CONT_PARAMS );
static RTYPE compiled_block_1_1052( CONT_PARAMS );
static RTYPE compiled_block_1_1051( CONT_PARAMS );
static RTYPE compiled_block_1_1045( CONT_PARAMS );
static RTYPE compiled_block_1_1048( CONT_PARAMS );
static RTYPE compiled_block_1_1047( CONT_PARAMS );
static RTYPE compiled_temp_1_534( CONT_PARAMS );
static RTYPE compiled_block_1_1040( CONT_PARAMS );
static RTYPE compiled_block_1_1041( CONT_PARAMS );
static RTYPE compiled_block_1_1024( CONT_PARAMS );
static RTYPE compiled_block_1_1038( CONT_PARAMS );
static RTYPE compiled_block_1_1036( CONT_PARAMS );
static RTYPE compiled_block_1_1037( CONT_PARAMS );
static RTYPE compiled_block_1_1034( CONT_PARAMS );
static RTYPE compiled_block_1_1032( CONT_PARAMS );
static RTYPE compiled_block_1_1033( CONT_PARAMS );
static RTYPE compiled_block_1_1029( CONT_PARAMS );
static RTYPE compiled_block_1_1030( CONT_PARAMS );
static RTYPE compiled_block_1_1025( CONT_PARAMS );
static RTYPE compiled_block_1_1026( CONT_PARAMS );
static RTYPE compiled_block_1_1023( CONT_PARAMS );
static RTYPE compiled_block_1_1020( CONT_PARAMS );
static RTYPE compiled_block_1_1022( CONT_PARAMS );
static RTYPE compiled_block_1_1021( CONT_PARAMS );
static RTYPE compiled_block_1_1019( CONT_PARAMS );
static RTYPE compiled_start_1_4( CONT_PARAMS );
static RTYPE compiled_block_1_1011( CONT_PARAMS );
static RTYPE compiled_start_1_2( CONT_PARAMS );
static RTYPE compiled_block_1_1003( CONT_PARAMS );
static RTYPE compiled_block_1_1006( CONT_PARAMS );
static RTYPE compiled_block_1_1008( CONT_PARAMS );
static RTYPE compiled_block_1_1007( CONT_PARAMS );
static RTYPE compiled_block_1_1004( CONT_PARAMS );
static RTYPE compiled_start_1_536( CONT_PARAMS );
static RTYPE compiled_start_1_1( CONT_PARAMS );

static RTYPE compiled_start_1_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 2 ); /*  array:grok/index!~1ayXVW~11639 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 3 ); /*  array:grok/arguments~1ayXVW~11638 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 4 ); /*  array:map-column->string~1ayXVW~11637 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 5 ); /*  array:map->string~1ayXVW~11636 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 6 ); /*  array:index-length~1ayXVW~11635 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 7 ); /*  array:index-set!~1ayXVW~11634 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 8 ); /*  array:index-ref~1ayXVW~11633 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 9 ); /*  array:thing->string~1ayXVW~11632 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 10 ); /*  array:shape-vector->string~1ayXVW~11631 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 11 ); /*  array:list->string~1ayXVW~11630 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 12 ); /*  array:not-in~1ayXVW~11629 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 13 ); /*  array:good-index?~1ayXVW~11628 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 14 ); /*  array:good-index-actor?~1ayXVW~11627 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 15 ); /*  array:good-index-vector?~1ayXVW~11626 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 16 ); /*  array:good-indices.o?~1ayXVW~11625 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 17 ); /*  array:good-indices?~1ayXVW~11624 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 18 ); /*  array:check-index-actor~1ayXVW~11623 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 19 ); /*  array:check-index-vector~1ayXVW~11622 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 20 ); /*  array:check-indices.o~1ayXVW~11621 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 21 ); /*  array:check-indices~1ayXVW~11620 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 22 ); /*  array:unchecked-share-depth?~1ayXVW~11619 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 23 ); /*  array:good-share?~1ayXVW~11618 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 24 ); /*  array:good-shape?~1ayXVW~11617 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 25 ); /*  array:make-index~1ayXVW~11616 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 26 ); /*  array:size~1ayXVW~11615 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 27 ); /*  array:shape->vector~1ayXVW~11614 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 28 ); /*  array:optimize/actor~1ayXVW~11613 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 29 ); /*  array:optimize/vector~1ayXVW~11612 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 30 ); /*  array:share/index!~1ayXVW~11611 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 31 ); /*  share-array~1ayXVW~11610 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 32 ); /*  array-end~1ayXVW~11609 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 33 ); /*  array-start~1ayXVW~11608 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 34 ); /*  array-rank~1ayXVW~11607 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 35 ); /*  array~1ayXVW~11606 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 36 ); /*  shape~1ayXVW~11605 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 37 ); /*  array:make-array~1ayXVW~11604 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 38 ); /*  make-array~1ayXVW~11603 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 39 ); /*  array?~1ayXVW~11602 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 40 ); /*  array:apply-to-actor~1ayXVW~11601 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 41 ); /*  array:apply-to-vector~1ayXVW~11600 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 42 ); /*  array:index/array~1ayXVW~11599 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 43 ); /*  array:index/vector~1ayXVW~11598 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 44 ); /*  array:applier-to-backing-vector~1ayXVW~11597 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 45 ); /*  array:applier-to-actor~1ayXVW~11596 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 46 ); /*  array:applier-to-vector~1ayXVW~11595 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 47 ); /*  array:indexer/array~1ayXVW~11594 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 48 ); /*  array:indexer/vector~1ayXVW~11593 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 49 ); /*  array:maker~1ayXVW~11592 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 50 ); /*  array:n~1ayXVW~11591 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 51 ); /*  array:3~1ayXVW~11590 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 52 ); /*  array:2~1ayXVW~11589 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 53 ); /*  array:1~1ayXVW~11588 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 54 ); /*  array:0~1ayXVW~11587 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 55 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 56 ); /*  array:shape-vector-index~1ayXVW~11585 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 57 ); /*  array:empty-shape-index~1ayXVW~11584 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 58 ); /*  array:shape-index~1ayXVW~11583 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 59 ); /*  array:vector-index~1ayXVW~11582 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 60 ); /*  array:coefficients~1ayXVW~11581 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 61 ); /*  array:optimize-empty~1ayXVW~11580 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 62 ); /*  array:optimize~1ayXVW~11579 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 63 ); /*  array:opt-args~1ayXVW~11578 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 64 ); /*  array-set!~1ayXVW~11577 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 65 ); /*  array-ref~1ayXVW~11576 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 66 ); /*  array:shape~1ayXVW~11575 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 67 ); /*  array:index~1ayXVW~11574 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 68 ); /*  array:vector~1ayXVW~11573 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 69 ); /*  array:array?~1ayXVW~11572 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 70 ); /*  array:make~1ayXVW~11571 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 71 ); /*  array-rtd~1ayXVW~11570 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 72 ); /*  ignored~1ayXVW~11566 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 73 ); /*  ignored~1ayXVW~11564 */
  twobit_lambda( compiled_start_1_1, 75, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_2, 77, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_3, 79, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 80 );
  twobit_setreg( 1 );
  twobit_const( 81 );
  twobit_setreg( 3 );
  twobit_const( 82 );
  twobit_setreg( 4 );
  twobit_const( 83 );
  twobit_setreg( 5 );
  twobit_const( 84 );
  twobit_setreg( 8 );
  twobit_global( 85 ); /* ex:make-library */
  twobit_setrtn( 2281, compiled_block_1_2281 );
  twobit_invoke( 8 );
  twobit_label( 2281, compiled_block_1_2281 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 86 ); /* ex:register-library! */
  twobit_setrtn( 2282, compiled_block_1_2282 );
  twobit_invoke( 1 );
  twobit_label( 2282, compiled_block_1_2282 );
  twobit_load( 0, 0 );
  twobit_global( 87 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* ex:uncompress */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_536, 2, 0 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1011, compiled_block_1_1011 );
  twobit_invoke( 2 );
  twobit_label( 1011, compiled_block_1_1011 );
  twobit_load( 0, 0 );
  twobit_global( 5 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_536( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1003, compiled_block_1_1003 ); /* internal:branchf-pair? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1004, compiled_block_1_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_1_1004 );
  twobit_load( 0, 0 );
  twobit_branchf( 1006, compiled_block_1_1006 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1007, compiled_block_1_1007 );
  twobit_invoke( 5 );
  twobit_label( 1007, compiled_block_1_1007 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1008, compiled_block_1_1008 );
  twobit_invoke( 5 );
  twobit_label( 1008, compiled_block_1_1008 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1006, compiled_block_1_1006 );
  twobit_load( 1, 3 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_pop( 3 );
  twobit_invoke( 1 );
  twobit_label( 1003, compiled_block_1_1003 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 2 ); /*  array:grok/index!~1ayXVW~11639 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 3 ); /*  array:grok/arguments~1ayXVW~11638 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 4 ); /*  array:map-column->string~1ayXVW~11637 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 5 ); /*  array:map->string~1ayXVW~11636 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 6 ); /*  array:index-length~1ayXVW~11635 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 7 ); /*  array:index-set!~1ayXVW~11634 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 8 ); /*  array:index-ref~1ayXVW~11633 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 9 ); /*  array:thing->string~1ayXVW~11632 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 10 ); /*  array:shape-vector->string~1ayXVW~11631 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 11 ); /*  array:list->string~1ayXVW~11630 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 12 ); /*  array:not-in~1ayXVW~11629 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 13 ); /*  array:good-index?~1ayXVW~11628 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 14 ); /*  array:good-index-actor?~1ayXVW~11627 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 15 ); /*  array:good-index-vector?~1ayXVW~11626 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 16 ); /*  array:good-indices.o?~1ayXVW~11625 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 17 ); /*  array:good-indices?~1ayXVW~11624 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 18 ); /*  array:check-index-actor~1ayXVW~11623 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 19 ); /*  array:check-index-vector~1ayXVW~11622 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 20 ); /*  array:check-indices.o~1ayXVW~11621 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 21 ); /*  array:check-indices~1ayXVW~11620 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 22 ); /*  array:unchecked-share-depth?~1ayXVW~11619 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 23 ); /*  array:good-share?~1ayXVW~11618 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 24 ); /*  array:good-shape?~1ayXVW~11617 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 25 ); /*  array:make-index~1ayXVW~11616 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 26 ); /*  array:size~1ayXVW~11615 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 27 ); /*  array:shape->vector~1ayXVW~11614 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 28 ); /*  array:optimize/actor~1ayXVW~11613 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 29 ); /*  array:optimize/vector~1ayXVW~11612 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 30 ); /*  array:share/index!~1ayXVW~11611 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 31 ); /*  share-array~1ayXVW~11610 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 32 ); /*  array-end~1ayXVW~11609 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 33 ); /*  array-start~1ayXVW~11608 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 34 ); /*  array-rank~1ayXVW~11607 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 35 ); /*  array~1ayXVW~11606 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 36 ); /*  shape~1ayXVW~11605 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 37 ); /*  array:make-array~1ayXVW~11604 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 38 ); /*  make-array~1ayXVW~11603 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 39 ); /*  array?~1ayXVW~11602 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 40 ); /*  array:apply-to-actor~1ayXVW~11601 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 41 ); /*  array:apply-to-vector~1ayXVW~11600 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 42 ); /*  array:index/array~1ayXVW~11599 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 43 ); /*  array:index/vector~1ayXVW~11598 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 44 ); /*  array:applier-to-backing-vector~1ayXVW~11597 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 45 ); /*  array:applier-to-actor~1ayXVW~11596 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 46 ); /*  array:applier-to-vector~1ayXVW~11595 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 47 ); /*  array:indexer/array~1ayXVW~11594 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 48 ); /*  array:indexer/vector~1ayXVW~11593 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 49 ); /*  array:maker~1ayXVW~11592 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 50 ); /*  array:n~1ayXVW~11591 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 51 ); /*  array:3~1ayXVW~11590 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 52 ); /*  array:2~1ayXVW~11589 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 53 ); /*  array:1~1ayXVW~11588 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 54 ); /*  array:0~1ayXVW~11587 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 55 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 56 ); /*  array:shape-vector-index~1ayXVW~11585 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 57 ); /*  array:empty-shape-index~1ayXVW~11584 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 58 ); /*  array:shape-index~1ayXVW~11583 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 59 ); /*  array:vector-index~1ayXVW~11582 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 60 ); /*  array:coefficients~1ayXVW~11581 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 61 ); /*  array:optimize-empty~1ayXVW~11580 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 62 ); /*  array:optimize~1ayXVW~11579 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 63 ); /*  array:opt-args~1ayXVW~11578 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 64 ); /*  array-set!~1ayXVW~11577 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 65 ); /*  array-ref~1ayXVW~11576 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 66 ); /*  array:shape~1ayXVW~11575 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 67 ); /*  array:index~1ayXVW~11574 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 68 ); /*  array:vector~1ayXVW~11573 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 69 ); /*  array:array?~1ayXVW~11572 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 70 ); /*  array:make~1ayXVW~11571 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 71 ); /*  array-rtd~1ayXVW~11570 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 72 ); /*  ignored~1ayXVW~11566 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 73 ); /*  ignored~1ayXVW~11564 */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setglbl( 74 ); /*  ignored~1ayXVW~11564 */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setglbl( 75 ); /*  ignored~1ayXVW~11566 */
  twobit_const( 76 );
  twobit_setreg( 1 );
  twobit_const( 77 );
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_global( 78 ); /* make-rtd */
  twobit_setrtn( 1013, compiled_block_1_1013 );
  twobit_invoke( 3 );
  twobit_label( 1013, compiled_block_1_1013 );
  twobit_load( 0, 0 );
  twobit_setglbl( 79 ); /*  array-rtd~1ayXVW~11570 */
  twobit_global( 80 ); /*  array-rtd~1ayXVW~11570 */
  twobit_setreg( 1 );
  twobit_const( 81 );
  twobit_setreg( 2 );
  twobit_global( 82 ); /* rtd-constructor */
  twobit_setrtn( 1014, compiled_block_1_1014 );
  twobit_invoke( 2 );
  twobit_label( 1014, compiled_block_1_1014 );
  twobit_load( 0, 0 );
  twobit_setglbl( 83 ); /*  array:make~1ayXVW~11571 */
  twobit_global( 84 ); /*  array-rtd~1ayXVW~11570 */
  twobit_setreg( 1 );
  twobit_global( 85 ); /* rtd-predicate */
  twobit_setrtn( 1015, compiled_block_1_1015 );
  twobit_invoke( 1 );
  twobit_label( 1015, compiled_block_1_1015 );
  twobit_load( 0, 0 );
  twobit_setglbl( 86 ); /*  array:array?~1ayXVW~11572 */
  twobit_global( 87 ); /*  array-rtd~1ayXVW~11570 */
  twobit_setreg( 1 );
  twobit_const( 88 );
  twobit_setreg( 2 );
  twobit_global( 89 ); /* rtd-accessor */
  twobit_setrtn( 1016, compiled_block_1_1016 );
  twobit_invoke( 2 );
  twobit_label( 1016, compiled_block_1_1016 );
  twobit_load( 0, 0 );
  twobit_setglbl( 90 ); /*  array:vector~1ayXVW~11573 */
  twobit_global( 91 ); /*  array-rtd~1ayXVW~11570 */
  twobit_setreg( 1 );
  twobit_const( 92 );
  twobit_setreg( 2 );
  twobit_global( 93 ); /* rtd-accessor */
  twobit_setrtn( 1017, compiled_block_1_1017 );
  twobit_invoke( 2 );
  twobit_label( 1017, compiled_block_1_1017 );
  twobit_load( 0, 0 );
  twobit_setglbl( 94 ); /*  array:index~1ayXVW~11574 */
  twobit_global( 95 ); /*  array-rtd~1ayXVW~11570 */
  twobit_setreg( 1 );
  twobit_const( 96 );
  twobit_setreg( 2 );
  twobit_global( 97 ); /* rtd-accessor */
  twobit_setrtn( 1018, compiled_block_1_1018 );
  twobit_invoke( 2 );
  twobit_label( 1018, compiled_block_1_1018 );
  twobit_load( 0, 0 );
  twobit_setglbl( 98 ); /*  array:shape~1ayXVW~11575 */
  twobit_lambda( compiled_start_1_4, 100, 0 );
  twobit_setglbl( 101 ); /*  array-ref~1ayXVW~11576 */
  twobit_lambda( compiled_start_1_5, 103, 0 );
  twobit_setglbl( 104 ); /*  array-set!~1ayXVW~11577 */
  twobit_const( 105 );
  twobit_setglbl( 106 ); /*  array:opt-args~1ayXVW~11578 */
  twobit_lambda( compiled_start_1_6, 108, 0 );
  twobit_setglbl( 109 ); /*  array:optimize~1ayXVW~11579 */
  twobit_lambda( compiled_start_1_7, 111, 0 );
  twobit_setglbl( 112 ); /*  array:optimize-empty~1ayXVW~11580 */
  twobit_lambda( compiled_start_1_8, 114, 0 );
  twobit_setglbl( 115 ); /*  array:coefficients~1ayXVW~11581 */
  twobit_lambda( compiled_start_1_9, 117, 0 );
  twobit_setglbl( 118 ); /*  array:vector-index~1ayXVW~11582 */
  twobit_lambda( compiled_start_1_10, 120, 0 );
  twobit_setglbl( 121 ); /*  array:shape-index~1ayXVW~11583 */
  twobit_lambda( compiled_start_1_11, 123, 0 );
  twobit_setglbl( 124 ); /*  array:empty-shape-index~1ayXVW~11584 */
  twobit_lambda( compiled_start_1_12, 126, 0 );
  twobit_setglbl( 127 ); /*  array:shape-vector-index~1ayXVW~11585 */
  twobit_lambda( compiled_start_1_13, 129, 0 );
  twobit_setglbl( 130 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_lambda( compiled_start_1_14, 132, 0 );
  twobit_setglbl( 133 ); /*  array:0~1ayXVW~11587 */
  twobit_lambda( compiled_start_1_15, 135, 0 );
  twobit_setglbl( 136 ); /*  array:1~1ayXVW~11588 */
  twobit_lambda( compiled_start_1_16, 138, 0 );
  twobit_setglbl( 139 ); /*  array:2~1ayXVW~11589 */
  twobit_lambda( compiled_start_1_17, 141, 0 );
  twobit_setglbl( 142 ); /*  array:3~1ayXVW~11590 */
  twobit_lambda( compiled_start_1_18, 144, 0 );
  twobit_setglbl( 145 ); /*  array:n~1ayXVW~11591 */
  twobit_lambda( compiled_start_1_19, 147, 0 );
  twobit_setglbl( 49 ); /*  array:maker~1ayXVW~11592 */
  twobit_lambda( compiled_start_1_20, 149, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_1_21, 151, 0 );
  twobit_setreg( 3 );
  twobit_lambda( compiled_start_1_22, 153, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_23, 155, 0 );
  twobit_setreg( 1 );
  twobit_lambda( compiled_start_1_24, 157, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_lambda( compiled_start_1_25, 159, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_lambda( compiled_start_1_26, 161, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_lambda( compiled_start_1_27, 163, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_lambda( compiled_start_1_28, 165, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_lambda( compiled_start_1_29, 167, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 4, 1 );
  twobit_imm_const( fixnum(10) ); /* 10 */
  twobit_op2_80( 4 ); /* make-vector */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 4 );
  twobit_load( 3, 3 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 4 );
  twobit_load( 3, 4 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 4 );
  twobit_load( 3, 5 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 4 );
  twobit_load( 3, 6 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_load( 3, 7 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_30, 169, 1 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1311, compiled_block_1_1311 );
  twobit_invoke( 0 );
  twobit_label( 1311, compiled_block_1_1311 );
  twobit_load( 0, 0 );
  twobit_setglbl( 48 ); /*  array:indexer/vector~1ayXVW~11593 */
  twobit_lambda( compiled_start_1_31, 171, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_1_32, 173, 0 );
  twobit_setreg( 3 );
  twobit_lambda( compiled_start_1_33, 175, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_34, 177, 0 );
  twobit_setreg( 1 );
  twobit_lambda( compiled_start_1_35, 179, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_lambda( compiled_start_1_36, 181, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_lambda( compiled_start_1_37, 183, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_lambda( compiled_start_1_38, 185, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_lambda( compiled_start_1_39, 187, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_lambda( compiled_start_1_40, 189, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 4, 1 );
  twobit_imm_const( fixnum(10) ); /* 10 */
  twobit_op2_80( 4 ); /* make-vector */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 4 );
  twobit_load( 3, 7 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 4 );
  twobit_load( 3, 6 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 4 );
  twobit_load( 3, 5 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 4 );
  twobit_load( 3, 4 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 4 );
  twobit_load( 3, 3 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_41, 191, 1 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1473, compiled_block_1_1473 );
  twobit_invoke( 0 );
  twobit_label( 1473, compiled_block_1_1473 );
  twobit_load( 0, 0 );
  twobit_setglbl( 47 ); /*  array:indexer/array~1ayXVW~11594 */
  twobit_lambda( compiled_start_1_42, 193, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_1_43, 195, 0 );
  twobit_setreg( 3 );
  twobit_lambda( compiled_start_1_44, 197, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_45, 199, 0 );
  twobit_setreg( 1 );
  twobit_lambda( compiled_start_1_46, 201, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_lambda( compiled_start_1_47, 203, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_lambda( compiled_start_1_48, 205, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_lambda( compiled_start_1_49, 207, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_lambda( compiled_start_1_50, 209, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_lambda( compiled_start_1_51, 211, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 4, 1 );
  twobit_imm_const( fixnum(10) ); /* 10 */
  twobit_op2_80( 4 ); /* make-vector */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 4 );
  twobit_load( 3, 3 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 4 );
  twobit_load( 3, 4 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 4 );
  twobit_load( 3, 5 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 4 );
  twobit_load( 3, 6 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_load( 3, 7 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_52, 213, 1 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1550, compiled_block_1_1550 );
  twobit_invoke( 0 );
  twobit_label( 1550, compiled_block_1_1550 );
  twobit_load( 0, 0 );
  twobit_setglbl( 46 ); /*  array:applier-to-vector~1ayXVW~11595 */
  twobit_lambda( compiled_start_1_53, 215, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_1_54, 217, 0 );
  twobit_setreg( 3 );
  twobit_lambda( compiled_start_1_55, 219, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_56, 221, 0 );
  twobit_setreg( 1 );
  twobit_lambda( compiled_start_1_57, 223, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_lambda( compiled_start_1_58, 225, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_lambda( compiled_start_1_59, 227, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_lambda( compiled_start_1_60, 229, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_lambda( compiled_start_1_61, 231, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_lambda( compiled_start_1_62, 233, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 4, 1 );
  twobit_imm_const( fixnum(10) ); /* 10 */
  twobit_op2_80( 4 ); /* make-vector */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 4 );
  twobit_load( 3, 7 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 4 );
  twobit_load( 3, 6 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 4 );
  twobit_load( 3, 5 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 4 );
  twobit_load( 3, 4 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 4 );
  twobit_load( 3, 3 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_63, 235, 1 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1627, compiled_block_1_1627 );
  twobit_invoke( 0 );
  twobit_label( 1627, compiled_block_1_1627 );
  twobit_load( 0, 0 );
  twobit_setglbl( 45 ); /*  array:applier-to-actor~1ayXVW~11596 */
  twobit_lambda( compiled_start_1_64, 237, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lambda( compiled_start_1_65, 239, 0 );
  twobit_setreg( 3 );
  twobit_lambda( compiled_start_1_66, 241, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_67, 243, 0 );
  twobit_setreg( 1 );
  twobit_lambda( compiled_start_1_68, 245, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_lambda( compiled_start_1_69, 247, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_lambda( compiled_start_1_70, 249, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_lambda( compiled_start_1_71, 251, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_lambda( compiled_start_1_72, 253, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_lambda( compiled_start_1_73, 255, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 4, 1 );
  twobit_imm_const( fixnum(10) ); /* 10 */
  twobit_op2_80( 4 ); /* make-vector */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 4 );
  twobit_load( 3, 3 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 4 );
  twobit_load( 3, 4 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 4 );
  twobit_load( 3, 5 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 4 );
  twobit_load( 3, 6 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_load( 3, 7 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_74, 257, 1 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1733, compiled_block_1_1733 );
  twobit_invoke( 0 );
  twobit_label( 1733, compiled_block_1_1733 );
  twobit_load( 0, 0 );
  twobit_setglbl( 44 ); /*  array:applier-to-backing-vector~1ayXVW~11597 */
  twobit_lambda( compiled_start_1_75, 259, 0 );
  twobit_setglbl( 43 ); /*  array:index/vector~1ayXVW~11598 */
  twobit_lambda( compiled_start_1_76, 261, 0 );
  twobit_setglbl( 42 ); /*  array:index/array~1ayXVW~11599 */
  twobit_lambda( compiled_start_1_77, 263, 0 );
  twobit_setglbl( 41 ); /*  array:apply-to-vector~1ayXVW~11600 */
  twobit_lambda( compiled_start_1_78, 265, 0 );
  twobit_setglbl( 40 ); /*  array:apply-to-actor~1ayXVW~11601 */
  twobit_global( 266 ); /*  array:array?~1ayXVW~11572 */
  twobit_setglbl( 39 ); /*  array?~1ayXVW~11602 */
  twobit_lambda( compiled_start_1_79, 268, 0 );
  twobit_setglbl( 38 ); /*  make-array~1ayXVW~11603 */
  twobit_lambda( compiled_start_1_80, 270, 0 );
  twobit_setglbl( 37 ); /*  array:make-array~1ayXVW~11604 */
  twobit_lambda( compiled_start_1_81, 272, 0 );
  twobit_setglbl( 36 ); /*  shape~1ayXVW~11605 */
  twobit_lambda( compiled_start_1_82, 274, 0 );
  twobit_setglbl( 35 ); /*  array~1ayXVW~11606 */
  twobit_lambda( compiled_start_1_83, 276, 0 );
  twobit_setglbl( 34 ); /*  array-rank~1ayXVW~11607 */
  twobit_lambda( compiled_start_1_84, 278, 0 );
  twobit_setglbl( 33 ); /*  array-start~1ayXVW~11608 */
  twobit_lambda( compiled_start_1_85, 280, 0 );
  twobit_setglbl( 32 ); /*  array-end~1ayXVW~11609 */
  twobit_lambda( compiled_start_1_86, 282, 0 );
  twobit_setglbl( 31 ); /*  share-array~1ayXVW~11610 */
  twobit_lambda( compiled_start_1_87, 284, 0 );
  twobit_setglbl( 30 ); /*  array:share/index!~1ayXVW~11611 */
  twobit_lambda( compiled_start_1_88, 286, 0 );
  twobit_setglbl( 29 ); /*  array:optimize/vector~1ayXVW~11612 */
  twobit_lambda( compiled_start_1_89, 288, 0 );
  twobit_setglbl( 28 ); /*  array:optimize/actor~1ayXVW~11613 */
  twobit_lambda( compiled_start_1_90, 290, 0 );
  twobit_setglbl( 27 ); /*  array:shape->vector~1ayXVW~11614 */
  twobit_lambda( compiled_start_1_91, 292, 0 );
  twobit_setglbl( 26 ); /*  array:size~1ayXVW~11615 */
  twobit_lambda( compiled_start_1_92, 294, 0 );
  twobit_setglbl( 25 ); /*  array:make-index~1ayXVW~11616 */
  twobit_lambda( compiled_start_1_93, 296, 0 );
  twobit_setglbl( 24 ); /*  array:good-shape?~1ayXVW~11617 */
  twobit_lambda( compiled_start_1_94, 298, 0 );
  twobit_setglbl( 23 ); /*  array:good-share?~1ayXVW~11618 */
  twobit_lambda( compiled_start_1_95, 300, 0 );
  twobit_setglbl( 22 ); /*  array:unchecked-share-depth?~1ayXVW~11619 */
  twobit_lambda( compiled_start_1_96, 302, 0 );
  twobit_setglbl( 21 ); /*  array:check-indices~1ayXVW~11620 */
  twobit_lambda( compiled_start_1_97, 304, 0 );
  twobit_setglbl( 20 ); /*  array:check-indices.o~1ayXVW~11621 */
  twobit_lambda( compiled_start_1_98, 306, 0 );
  twobit_setglbl( 19 ); /*  array:check-index-vector~1ayXVW~11622 */
  twobit_lambda( compiled_start_1_99, 308, 0 );
  twobit_setglbl( 18 ); /*  array:check-index-actor~1ayXVW~11623 */
  twobit_lambda( compiled_start_1_100, 310, 0 );
  twobit_setglbl( 17 ); /*  array:good-indices?~1ayXVW~11624 */
  twobit_lambda( compiled_start_1_101, 312, 0 );
  twobit_setglbl( 16 ); /*  array:good-indices.o?~1ayXVW~11625 */
  twobit_lambda( compiled_start_1_102, 314, 0 );
  twobit_setglbl( 15 ); /*  array:good-index-vector?~1ayXVW~11626 */
  twobit_lambda( compiled_start_1_103, 316, 0 );
  twobit_setglbl( 14 ); /*  array:good-index-actor?~1ayXVW~11627 */
  twobit_lambda( compiled_start_1_104, 318, 0 );
  twobit_setglbl( 13 ); /*  array:good-index?~1ayXVW~11628 */
  twobit_lambda( compiled_start_1_105, 320, 0 );
  twobit_setglbl( 12 ); /*  array:not-in~1ayXVW~11629 */
  twobit_lambda( compiled_start_1_106, 322, 0 );
  twobit_setglbl( 11 ); /*  array:list->string~1ayXVW~11630 */
  twobit_lambda( compiled_start_1_107, 324, 0 );
  twobit_setglbl( 10 ); /*  array:shape-vector->string~1ayXVW~11631 */
  twobit_lambda( compiled_start_1_108, 326, 0 );
  twobit_setglbl( 9 ); /*  array:thing->string~1ayXVW~11632 */
  twobit_lambda( compiled_start_1_109, 328, 0 );
  twobit_setglbl( 8 ); /*  array:index-ref~1ayXVW~11633 */
  twobit_lambda( compiled_start_1_110, 330, 0 );
  twobit_setglbl( 7 ); /*  array:index-set!~1ayXVW~11634 */
  twobit_lambda( compiled_start_1_111, 332, 0 );
  twobit_setglbl( 6 ); /*  array:index-length~1ayXVW~11635 */
  twobit_lambda( compiled_start_1_112, 334, 0 );
  twobit_setglbl( 5 ); /*  array:map->string~1ayXVW~11636 */
  twobit_lambda( compiled_start_1_113, 336, 0 );
  twobit_setglbl( 4 ); /*  array:map-column->string~1ayXVW~11637 */
  twobit_lambda( compiled_start_1_114, 338, 0 );
  twobit_setglbl( 3 ); /*  array:grok/arguments~1ayXVW~11638 */
  twobit_lambda( compiled_start_1_115, 340, 0 );
  twobit_setglbl( 2 ); /*  array:grok/index!~1ayXVW~11639 */
  twobit_global( 341 ); /* values */
  twobit_pop( 7 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_global( 1 ); /*  array:array?~1ayXVW~11572 */
  twobit_setrtn( 1019, compiled_block_1_1019 );
  twobit_invoke( 1 );
  twobit_label( 1019, compiled_block_1_1019 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1021, compiled_block_1_1021 );
  twobit_skip( 1020, compiled_block_1_1020 );
  twobit_label( 1021, compiled_block_1_1021 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 1022, compiled_block_1_1022 );
  twobit_invoke( 1 );
  twobit_label( 1022, compiled_block_1_1022 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_label( 1020, compiled_block_1_1020 );
  twobit_reg( 4 );
  twobit_load( 1, 1 );
  twobit_global( 4 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 1023, compiled_block_1_1023 );
  twobit_invoke( 1 );
  twobit_label( 1023, compiled_block_1_1023 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_stack( 2 );
  twobit_op1_10(); /* null? */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_reg( 3 );
  twobit_branchf( 1025, compiled_block_1_1025 );
  twobit_movereg( 4, 3 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 6 ); /*  array:check-indices~1ayXVW~11620 */
  twobit_setrtn( 1026, compiled_block_1_1026 );
  twobit_invoke( 3 );
  twobit_label( 1026, compiled_block_1_1026 );
  twobit_load( 0, 0 );
  twobit_skip( 1024, compiled_block_1_1024 );
  twobit_label( 1025, compiled_block_1_1025 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 1, 2 );
  twobit_check( 1, 0, 0, 1027, compiled_block_1_1027 );
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_reg( 2 );
  twobit_op1_41(); /* vector? */
  twobit_branchf( 1029, compiled_block_1_1029 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 3 );
  twobit_global( 7 ); /*  array:check-index-vector~1ayXVW~11622 */
  twobit_setrtn( 1030, compiled_block_1_1030 );
  twobit_invoke( 3 );
  twobit_label( 1030, compiled_block_1_1030 );
  twobit_load( 0, 0 );
  twobit_skip( 1024, compiled_block_1_1024 );
  twobit_label( 1029, compiled_block_1_1029 );
  twobit_reg( 2 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1032, compiled_block_1_1032 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_movereg( 4, 3 );
  twobit_global( 6 ); /*  array:check-indices~1ayXVW~11620 */
  twobit_setrtn( 1033, compiled_block_1_1033 );
  twobit_invoke( 3 );
  twobit_label( 1033, compiled_block_1_1033 );
  twobit_load( 0, 0 );
  twobit_skip( 1024, compiled_block_1_1024 );
  twobit_label( 1032, compiled_block_1_1032 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  array:array?~1ayXVW~11572 */
  twobit_setrtn( 1034, compiled_block_1_1034 );
  twobit_invoke( 1 );
  twobit_label( 1034, compiled_block_1_1034 );
  twobit_load( 0, 0 );
  twobit_branchf( 1036, compiled_block_1_1036 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_load( 3, 4 );
  twobit_global( 8 ); /*  array:check-index-actor~1ayXVW~11623 */
  twobit_setrtn( 1037, compiled_block_1_1037 );
  twobit_invoke( 3 );
  twobit_label( 1037, compiled_block_1_1037 );
  twobit_load( 0, 0 );
  twobit_skip( 1024, compiled_block_1_1024 );
  twobit_label( 1036, compiled_block_1_1036 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 1038, compiled_block_1_1038 );
  twobit_invoke( 1 );
  twobit_label( 1038, compiled_block_1_1038 );
  twobit_load( 0, 0 );
  twobit_label( 1024, compiled_block_1_1024 );
  twobit_stack( 5 );
  twobit_branchf( 1040, compiled_block_1_1040 );
  twobit_load( 1, 1 );
  twobit_global( 10 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 1041, compiled_block_1_1041 );
  twobit_invoke( 1 );
  twobit_label( 1041, compiled_block_1_1041 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op2_check_662(reg(4),reg(3),1042,compiled_block_1_1042); /* internal:check-vector?/vector-length:vec with (0 4 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(3),1042,compiled_block_1_1042); /* internal:check-<:fix:fix with (0 4 0) */
  twobit_reg( 4 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_skip( 1039, compiled_block_1_1039 );
  twobit_label( 1040, compiled_block_1_1040 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 2 );
  twobit_check( 3, 0, 0, 1043, compiled_block_1_1043 );
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_reg( 4 );
  twobit_op1_41(); /* vector? */
  twobit_branchf( 1045, compiled_block_1_1045 );
  twobit_stack( 4 );
  twobit_op1_41(); /* vector? */
  twobit_load( 2, 4 );
  twobit_check( 2, 0, 0, 1046, compiled_block_1_1046 );
  twobit_stack( 4 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_imm_const_setreg( fixnum(2), 2 ); /* 2 */
  twobit_op2_65( 2, 534, compiled_temp_1_534 ); /* quotient */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_load( 1, 1 );
  twobit_global( 10 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 1047, compiled_block_1_1047 );
  twobit_invoke( 1 );
  twobit_label( 1047, compiled_block_1_1047 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 4 );
  twobit_load( 3, 5 );
  twobit_global( 11 ); /*  array:index/vector~1ayXVW~11598 */
  twobit_setrtn( 1048, compiled_block_1_1048 );
  twobit_invoke( 3 );
  twobit_label( 1048, compiled_block_1_1048 );
  twobit_load( 0, 0 );
  twobit_skip( 1039, compiled_block_1_1039 );
  twobit_label( 1045, compiled_block_1_1045 );
  twobit_reg( 4 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1050, compiled_block_1_1050 );
  twobit_load( 1, 1 );
  twobit_global( 10 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 1051, compiled_block_1_1051 );
  twobit_invoke( 1 );
  twobit_label( 1051, compiled_block_1_1051 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 12 ); /*  array:vector-index~1ayXVW~11582 */
  twobit_setrtn( 1052, compiled_block_1_1052 );
  twobit_invoke( 2 );
  twobit_label( 1052, compiled_block_1_1052 );
  twobit_load( 0, 0 );
  twobit_skip( 1039, compiled_block_1_1039 );
  twobit_label( 1050, compiled_block_1_1050 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /*  array:array?~1ayXVW~11572 */
  twobit_setrtn( 1053, compiled_block_1_1053 );
  twobit_invoke( 1 );
  twobit_label( 1053, compiled_block_1_1053 );
  twobit_load( 0, 0 );
  twobit_branchf( 1055, compiled_block_1_1055 );
  twobit_stack( 4 );
  twobit_op1_41(); /* vector? */
  twobit_load( 3, 4 );
  twobit_check( 3, 0, 0, 1056, compiled_block_1_1056 );
  twobit_stack( 4 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_imm_const_setreg( fixnum(2), 3 ); /* 2 */
  twobit_op2_65( 3, 535, compiled_temp_1_535 ); /* quotient */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_global( 10 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 1057, compiled_block_1_1057 );
  twobit_invoke( 1 );
  twobit_label( 1057, compiled_block_1_1057 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 5 );
  twobit_global( 13 ); /*  array:vector~1ayXVW~11573 */
  twobit_setrtn( 1058, compiled_block_1_1058 );
  twobit_invoke( 1 );
  twobit_label( 1058, compiled_block_1_1058 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 5 );
  twobit_global( 10 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 1059, compiled_block_1_1059 );
  twobit_invoke( 1 );
  twobit_label( 1059, compiled_block_1_1059 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 4 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_global( 14 ); /*  array:index/array~1ayXVW~11599 */
  twobit_setrtn( 1060, compiled_block_1_1060 );
  twobit_invoke( 4 );
  twobit_label( 1060, compiled_block_1_1060 );
  twobit_load( 0, 0 );
  twobit_skip( 1039, compiled_block_1_1039 );
  twobit_label( 1055, compiled_block_1_1055 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 1061, compiled_block_1_1061 );
  twobit_invoke( 1 );
  twobit_label( 1061, compiled_block_1_1061 );
  twobit_load( 0, 0 );
  twobit_label( 1039, compiled_block_1_1039 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 1 );
  twobit_global( 13 ); /*  array:vector~1ayXVW~11573 */
  twobit_setrtn( 1062, compiled_block_1_1062 );
  twobit_invoke( 1 );
  twobit_label( 1062, compiled_block_1_1062 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 5 );
  twobit_check( 1, 4, 0, 1063, compiled_block_1_1063 );
  twobit_reg_op2_check_662(reg(4),reg(3),1063,compiled_block_1_1063); /* internal:check-vector?/vector-length:vec with (1 4 0) */
  twobit_stack( 5 );
  twobit_reg_op2_check_655(RESULT,reg(3),1063,compiled_block_1_1063); /* internal:check-<:fix:fix with (1 4 0) */
  twobit_stack( 5 );
  twobit_reg_op2imm_check_660(RESULT,fixnum(0),1063,compiled_block_1_1063); /* internal:check->=:fix:fix/imm with (1 4 0) */
  twobit_load( 3, 5 );
  twobit_reg( 4 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1046, compiled_block_1_1046 );
  twobit_trap( 2, 0, 0, 162 );
  twobit_label( 1056, compiled_block_1_1056 );
  twobit_trap( 3, 0, 0, 162 );
  twobit_label( 1043, compiled_block_1_1043 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_label( 1027, compiled_block_1_1027 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_label( 1042, compiled_block_1_1042 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_label( 1063, compiled_block_1_1063 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 3 );
  twobit_store( 3, 2 );
  twobit_global( 1 ); /*  array:array?~1ayXVW~11572 */
  twobit_setrtn( 1064, compiled_block_1_1064 );
  twobit_invoke( 1 );
  twobit_label( 1064, compiled_block_1_1064 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1066, compiled_block_1_1066 );
  twobit_skip( 1065, compiled_block_1_1065 );
  twobit_label( 1066, compiled_block_1_1066 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 1067, compiled_block_1_1067 );
  twobit_invoke( 1 );
  twobit_label( 1067, compiled_block_1_1067 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_label( 1065, compiled_block_1_1065 );
  twobit_reg( 4 );
  twobit_load( 1, 1 );
  twobit_global( 4 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 1068, compiled_block_1_1068 );
  twobit_invoke( 1 );
  twobit_label( 1068, compiled_block_1_1068 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_stack( 2 );
  twobit_op1_10(); /* null? */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_reg( 3 );
  twobit_branchf( 1070, compiled_block_1_1070 );
  twobit_movereg( 4, 3 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 6 ); /*  array:check-indices~1ayXVW~11620 */
  twobit_setrtn( 1071, compiled_block_1_1071 );
  twobit_invoke( 3 );
  twobit_label( 1071, compiled_block_1_1071 );
  twobit_load( 0, 0 );
  twobit_skip( 1069, compiled_block_1_1069 );
  twobit_label( 1070, compiled_block_1_1070 );
  twobit_stack( 3 );
  twobit_op1_41(); /* vector? */
  twobit_branchf( 1073, compiled_block_1_1073 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_movereg( 4, 3 );
  twobit_global( 7 ); /*  array:check-index-vector~1ayXVW~11622 */
  twobit_setrtn( 1074, compiled_block_1_1074 );
  twobit_invoke( 3 );
  twobit_label( 1074, compiled_block_1_1074 );
  twobit_load( 0, 0 );
  twobit_skip( 1069, compiled_block_1_1069 );
  twobit_label( 1073, compiled_block_1_1073 );
  twobit_stack( 3 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1076, compiled_block_1_1076 );
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 3 );
  twobit_global( 8 ); /*  array:check-indices.o~1ayXVW~11621 */
  twobit_setrtn( 1077, compiled_block_1_1077 );
  twobit_invoke( 3 );
  twobit_label( 1077, compiled_block_1_1077 );
  twobit_load( 0, 0 );
  twobit_skip( 1069, compiled_block_1_1069 );
  twobit_label( 1076, compiled_block_1_1076 );
  twobit_load( 1, 3 );
  twobit_global( 1 ); /*  array:array?~1ayXVW~11572 */
  twobit_setrtn( 1078, compiled_block_1_1078 );
  twobit_invoke( 1 );
  twobit_label( 1078, compiled_block_1_1078 );
  twobit_load( 0, 0 );
  twobit_branchf( 1080, compiled_block_1_1080 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_load( 3, 4 );
  twobit_global( 9 ); /*  array:check-index-actor~1ayXVW~11623 */
  twobit_setrtn( 1081, compiled_block_1_1081 );
  twobit_invoke( 3 );
  twobit_label( 1081, compiled_block_1_1081 );
  twobit_load( 0, 0 );
  twobit_skip( 1069, compiled_block_1_1069 );
  twobit_label( 1080, compiled_block_1_1080 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 1082, compiled_block_1_1082 );
  twobit_invoke( 1 );
  twobit_label( 1082, compiled_block_1_1082 );
  twobit_load( 0, 0 );
  twobit_label( 1069, compiled_block_1_1069 );
  twobit_stack( 5 );
  twobit_branchf( 1084, compiled_block_1_1084 );
  twobit_load( 1, 1 );
  twobit_global( 11 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 1085, compiled_block_1_1085 );
  twobit_invoke( 1 );
  twobit_label( 1085, compiled_block_1_1085 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op2_check_662(reg(4),reg(3),1086,compiled_block_1_1086); /* internal:check-vector?/vector-length:vec with (0 4 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(3),1086,compiled_block_1_1086); /* internal:check-<:fix:fix with (0 4 0) */
  twobit_reg( 4 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 1 );
  twobit_global( 12 ); /*  array:vector~1ayXVW~11573 */
  twobit_setrtn( 1087, compiled_block_1_1087 );
  twobit_invoke( 1 );
  twobit_label( 1087, compiled_block_1_1087 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 5 );
  twobit_load( 2, 3 );
  twobit_check( 2, 3, 4, 1088, compiled_block_1_1088 );
  twobit_reg_op2_check_662(reg(4),reg(3),1088,compiled_block_1_1088); /* internal:check-vector?/vector-length:vec with (2 3 4) */
  twobit_stack( 5 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 5 );
  twobit_check( 2, 3, 4, 1088, compiled_block_1_1088 );
  twobit_stack( 5 );
  twobit_reg_op2imm_check_660(RESULT,fixnum(0),1088,compiled_block_1_1088); /* internal:check->=:fix:fix/imm with (2 3 4) */
  twobit_reg( 4 );
  twobit_op3_403( 3, 2 ); /* vector-set!:trusted */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1084, compiled_block_1_1084 );
  twobit_stack( 3 );
  twobit_op1_41(); /* vector? */
  twobit_branchf( 1090, compiled_block_1_1090 );
  twobit_stack( 4 );
  twobit_op1_41(); /* vector? */
  twobit_load( 3, 4 );
  twobit_check( 3, 0, 0, 1091, compiled_block_1_1091 );
  twobit_stack( 4 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_imm_const_setreg( fixnum(2), 3 ); /* 2 */
  twobit_op2_65( 3, 525, compiled_temp_1_525 ); /* quotient */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 1 );
  twobit_global( 11 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 1092, compiled_block_1_1092 );
  twobit_invoke( 1 );
  twobit_label( 1092, compiled_block_1_1092 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 3, 3 );
  twobit_load( 1, 4 );
  twobit_global( 13 ); /*  array:index/vector~1ayXVW~11598 */
  twobit_setrtn( 1093, compiled_block_1_1093 );
  twobit_invoke( 3 );
  twobit_label( 1093, compiled_block_1_1093 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 1 );
  twobit_global( 12 ); /*  array:vector~1ayXVW~11573 */
  twobit_setrtn( 1094, compiled_block_1_1094 );
  twobit_invoke( 1 );
  twobit_label( 1094, compiled_block_1_1094 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 2, 2 );
  twobit_check( 2, 0, 0, 1095, compiled_block_1_1095 );
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 2, 4 );
  twobit_check( 3, 2, 4, 1096, compiled_block_1_1096 );
  twobit_reg_op2_check_662(reg(4),reg(2),1096,compiled_block_1_1096); /* internal:check-vector?/vector-length:vec with (3 2 4) */
  twobit_stack( 4 );
  twobit_op2_407( 2 ); /* <:fix:fix */
  twobit_load( 2, 4 );
  twobit_check( 3, 2, 4, 1096, compiled_block_1_1096 );
  twobit_stack( 4 );
  twobit_reg_op2imm_check_660(RESULT,fixnum(0),1096,compiled_block_1_1096); /* internal:check->=:fix:fix/imm with (3 2 4) */
  twobit_reg( 4 );
  twobit_op3_403( 2, 3 ); /* vector-set!:trusted */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1090, compiled_block_1_1090 );
  twobit_stack( 3 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1098, compiled_block_1_1098 );
  twobit_load( 1, 1 );
  twobit_global( 11 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 1099, compiled_block_1_1099 );
  twobit_invoke( 1 );
  twobit_label( 1099, compiled_block_1_1099 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 1 );
  twobit_global( 12 ); /*  array:vector~1ayXVW~11573 */
  twobit_setrtn( 1100, compiled_block_1_1100 );
  twobit_invoke( 1 );
  twobit_label( 1100, compiled_block_1_1100 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_stack( 4 );
  twobit_op1_41(); /* vector? */
  twobit_load( 2, 4 );
  twobit_check( 2, 0, 0, 1101, compiled_block_1_1101 );
  twobit_stack( 4 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_imm_const_setreg( fixnum(2), 2 ); /* 2 */
  twobit_op2_65( 2, 526, compiled_temp_1_526 ); /* quotient */
  twobit_setreg( 3 );
  twobit_stack( 5 );
  twobit_op1_41(); /* vector? */
  twobit_load( 1, 5 );
  twobit_check( 0, 1, 0, 1102, compiled_block_1_1102 );
  twobit_stack( 5 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 2 );
  twobit_store( 2, 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(2),1102,compiled_block_1_1102); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_stack( 5 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_load( 1, 3 );
  twobit_op2_63( 1, 527, compiled_temp_1_527 ); /* * */
  twobit_setreg( 1 );
  twobit_store( 1, 6 );
  twobit_load( 2, 2 );
  twobit_store( 2, 7 );
  twobit_global( 14 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 5, 1 );
  twobit_load( 2, 4 );
  twobit_load( 1, 5 );
  twobit_lambda( compiled_start_1_528, 16, 5 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 6 );
  twobit_load( 2, 7 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_pop( 7 );
  twobit_invoke( 3 );
  twobit_label( 1098, compiled_block_1_1098 );
  twobit_load( 1, 3 );
  twobit_global( 1 ); /*  array:array?~1ayXVW~11572 */
  twobit_setrtn( 1111, compiled_block_1_1111 );
  twobit_invoke( 1 );
  twobit_label( 1111, compiled_block_1_1111 );
  twobit_load( 0, 0 );
  twobit_branchf( 1113, compiled_block_1_1113 );
  twobit_stack( 4 );
  twobit_op1_41(); /* vector? */
  twobit_load( 3, 4 );
  twobit_check( 3, 0, 0, 1091, compiled_block_1_1091 );
  twobit_stack( 4 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_imm_const_setreg( fixnum(2), 3 ); /* 2 */
  twobit_op2_65( 3, 529, compiled_temp_1_529 ); /* quotient */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 1, 1 );
  twobit_global( 11 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 1114, compiled_block_1_1114 );
  twobit_invoke( 1 );
  twobit_label( 1114, compiled_block_1_1114 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 3 );
  twobit_global( 12 ); /*  array:vector~1ayXVW~11573 */
  twobit_setrtn( 1115, compiled_block_1_1115 );
  twobit_invoke( 1 );
  twobit_label( 1115, compiled_block_1_1115 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 3 );
  twobit_global( 11 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 1116, compiled_block_1_1116 );
  twobit_invoke( 1 );
  twobit_label( 1116, compiled_block_1_1116 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 4 );
  twobit_load( 2, 5 );
  twobit_load( 1, 6 );
  twobit_global( 17 ); /*  array:index/array~1ayXVW~11599 */
  twobit_setrtn( 1117, compiled_block_1_1117 );
  twobit_invoke( 4 );
  twobit_label( 1117, compiled_block_1_1117 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 1, 1 );
  twobit_global( 12 ); /*  array:vector~1ayXVW~11573 */
  twobit_setrtn( 1118, compiled_block_1_1118 );
  twobit_invoke( 1 );
  twobit_label( 1118, compiled_block_1_1118 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 2, 2 );
  twobit_check( 2, 0, 0, 1095, compiled_block_1_1095 );
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_stack( 6 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 2, 6 );
  twobit_check( 3, 2, 4, 1096, compiled_block_1_1096 );
  twobit_reg_op2_check_662(reg(4),reg(2),1096,compiled_block_1_1096); /* internal:check-vector?/vector-length:vec with (3 2 4) */
  twobit_stack( 6 );
  twobit_op2_407( 2 ); /* <:fix:fix */
  twobit_load( 2, 6 );
  twobit_check( 3, 2, 4, 1096, compiled_block_1_1096 );
  twobit_stack( 6 );
  twobit_reg_op2imm_check_660(RESULT,fixnum(0),1096,compiled_block_1_1096); /* internal:check->=:fix:fix/imm with (3 2 4) */
  twobit_reg( 4 );
  twobit_op3_403( 2, 3 ); /* vector-set!:trusted */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1113, compiled_block_1_1113 );
  twobit_load( 1, 3 );
  twobit_global( 18 ); /*  array:thing->string~1ayXVW~11632 */
  twobit_setrtn( 1119, compiled_block_1_1119 );
  twobit_invoke( 1 );
  twobit_label( 1119, compiled_block_1_1119 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_global( 20 ); /* string-append */
  twobit_setrtn( 1120, compiled_block_1_1120 );
  twobit_invoke( 2 );
  twobit_label( 1120, compiled_block_1_1120 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 7 );
  twobit_invoke( 1 );
  twobit_label( 1101, compiled_block_1_1101 );
  twobit_trap( 2, 0, 0, 162 );
  twobit_label( 1095, compiled_block_1_1095 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 1096, compiled_block_1_1096 );
  twobit_trap( 4, 2, 3, 161 );
  twobit_label( 1088, compiled_block_1_1088 );
  twobit_trap( 4, 3, 2, 161 );
  twobit_label( 1102, compiled_block_1_1102 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1091, compiled_block_1_1091 );
  twobit_trap( 3, 0, 0, 162 );
  twobit_label( 1086, compiled_block_1_1086 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_528( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_branchf_623( 4, 530, compiled_temp_1_530, 1104, compiled_block_1_1104 ); /* internal:branchf-= */
  twobit_reg_op1_check_652(reg(2),1105,compiled_block_1_1105); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 2 );
  twobit_check( 3, 31, 0, 1106, compiled_block_1_1106 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2_407( 2 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 2 );
  twobit_check( 3, 31, 0, 1106, compiled_block_1_1106 );
  twobit_reg( 3 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 2 );
  twobit_check( 3, 31, 0, 1106, compiled_block_1_1106 );
  twobit_lexical( 0, 1 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op2_61( 3, 531, compiled_temp_1_531 ); /* + */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_check( 4, 3, 1, 1107, compiled_block_1_1107 );
  twobit_lexical( 0, 5 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_check( 4, 3, 1, 1107, compiled_block_1_1107 );
  twobit_lexical( 0, 5 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2_407( 2 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_check( 4, 3, 1, 1107, compiled_block_1_1107 );
  twobit_reg( 3 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_check( 4, 3, 1, 1107, compiled_block_1_1107 );
  twobit_lexical( 0, 5 );
  twobit_op3_403( 3, 4 ); /* vector-set!:trusted */
  twobit_return();
  twobit_label( 1104, compiled_block_1_1104 );
  twobit_reg_op1_check_652(reg(2),1105,compiled_block_1_1105); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 31 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 3, 30, 0, 1108, compiled_block_1_1108 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op2_407( 31 ); /* <:fix:fix */
  twobit_setreg( 31 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 3, 30, 0, 1108, compiled_block_1_1108 );
  twobit_reg( 3 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 31 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 3, 30, 0, 1108, compiled_block_1_1108 );
  twobit_lexical( 0, 1 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_op2_63( 4, 532, compiled_temp_1_532 ); /* * */
  twobit_setreg( 31 );
  twobit_reg( 1 );
  twobit_op2_61( 31, 533, compiled_temp_1_533 ); /* + */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 3 );
  twobit_lexical( 0, 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 3 );
  twobit_label( 1105, compiled_block_1_1105 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 1108, compiled_block_1_1108 );
  twobit_trap( 30, 3, 0, 160 );
  twobit_label( 1107, compiled_block_1_1107 );
  twobit_trap( 1, 3, 4, 161 );
  twobit_label( 1106, compiled_block_1_1106 );
  twobit_trap( 31, 3, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_6( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op2imm_branchf_640( fixnum(0), 1123, compiled_block_1_1123 ); /* internal:branchf-eq?/imm */
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1124, compiled_block_1_1124 );
  twobit_invoke( 0 );
  twobit_label( 1124, compiled_block_1_1124 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  array:0~1ayXVW~11587 */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_label( 1123, compiled_block_1_1123 );
  twobit_reg( 2 );
  twobit_op2imm_branchf_640( fixnum(1), 1127, compiled_block_1_1127 ); /* internal:branchf-eq?/imm */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1128, compiled_block_1_1128 );
  twobit_invoke( 1 );
  twobit_label( 1128, compiled_block_1_1128 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 1 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_setrtn( 1129, compiled_block_1_1129 );
  twobit_invoke( 1 );
  twobit_label( 1129, compiled_block_1_1129 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_62( 3, 516, compiled_temp_1_516 ); /* - */
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 2 ); /*  array:1~1ayXVW~11588 */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1127, compiled_block_1_1127 );
  twobit_reg( 2 );
  twobit_op2imm_branchf_640( fixnum(2), 1132, compiled_block_1_1132 ); /* internal:branchf-eq?/imm */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_setrtn( 1133, compiled_block_1_1133 );
  twobit_invoke( 2 );
  twobit_label( 1133, compiled_block_1_1133 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 1 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_setrtn( 1134, compiled_block_1_1134 );
  twobit_invoke( 2 );
  twobit_label( 1134, compiled_block_1_1134 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_62( 3, 517, compiled_temp_1_517 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_stack( 1 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_setrtn( 1135, compiled_block_1_1135 );
  twobit_invoke( 2 );
  twobit_label( 1135, compiled_block_1_1135 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_load( 3, 2 );
  twobit_reg( 4 );
  twobit_op2_62( 3, 518, compiled_temp_1_518 ); /* - */
  twobit_setreg( 3 );
  twobit_load( 1, 2 );
  twobit_global( 3 ); /*  array:2~1ayXVW~11589 */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1132, compiled_block_1_1132 );
  twobit_reg( 2 );
  twobit_op2imm_branchf_640( fixnum(3), 1138, compiled_block_1_1138 ); /* internal:branchf-eq?/imm */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_setrtn( 1139, compiled_block_1_1139 );
  twobit_invoke( 3 );
  twobit_label( 1139, compiled_block_1_1139 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 1 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_setrtn( 1140, compiled_block_1_1140 );
  twobit_invoke( 3 );
  twobit_label( 1140, compiled_block_1_1140 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_62( 3, 519, compiled_temp_1_519 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_stack( 1 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_setrtn( 1141, compiled_block_1_1141 );
  twobit_invoke( 3 );
  twobit_label( 1141, compiled_block_1_1141 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_62( 3, 520, compiled_temp_1_520 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_stack( 1 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_setrtn( 1142, compiled_block_1_1142 );
  twobit_invoke( 3 );
  twobit_label( 1142, compiled_block_1_1142 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_load( 3, 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_op2_62( 1, 521, compiled_temp_1_521 ); /* - */
  twobit_setreg( 4 );
  twobit_global( 4 ); /*  array:3~1ayXVW~11590 */
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 1138, compiled_block_1_1138 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 5 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_522, 7, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_setrtn( 1147, compiled_block_1_1147 );
  twobit_invoke( 2 );
  twobit_label( 1147, compiled_block_1_1147 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 8 ); /* apply */
  twobit_setrtn( 1148, compiled_block_1_1148 );
  twobit_invoke( 2 );
  twobit_label( 1148, compiled_block_1_1148 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 1 );
  twobit_load( 3, 2 );
  twobit_load( 4, 2 );
  twobit_global( 9 ); /*  array:coefficients~1ayXVW~11581 */
  twobit_setrtn( 1149, compiled_block_1_1149 );
  twobit_invoke( 4 );
  twobit_label( 1149, compiled_block_1_1149 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_global( 10 ); /*  array:n~1ayXVW~11591 */
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_global( 8 ); /* apply */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_522( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_623( 4, 523, compiled_temp_1_523, 1145, compiled_block_1_1145 ); /* internal:branchf-= */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1145, compiled_block_1_1145 );
  twobit_reg( 1 );
  twobit_op2imm_130( fixnum(1), 524, compiled_temp_1_524 ); /* + */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_7( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_130( fixnum(1), 515, compiled_temp_1_515 ); /* + */
  twobit_imm_const_setreg( fixnum(0), 3 ); /* 0 */
  twobit_op2_80( 3 ); /* make-vector */
  twobit_setreg( 4 );
  twobit_reg_op1_check_651(reg(1),1151,compiled_block_1_1151); /* internal:check-fixnum? with (0 1 4) */
  twobit_reg( 4 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_reg_op2_check_661(reg(1),reg(3),1151,compiled_block_1_1151); /* internal:check-range with (0 1 4) */
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op3_403( 1, 2 ); /* vector-set!:trusted */
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1151, compiled_block_1_1151 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_setreg( 2 );
  twobit_trap( 4, 1, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_8( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op2_57( 31, 513, compiled_temp_1_513 ); /* eqv? */
  twobit_branchf( 1153, compiled_block_1_1153 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_label( 1153, compiled_block_1_1153 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op2_59( 31 ); /* set-car! */
  twobit_global( 1 ); /* apply */
  twobit_setrtn( 1154, compiled_block_1_1154 );
  twobit_invoke( 2 );
  twobit_label( 1154, compiled_block_1_1154 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_62( 3, 514, compiled_temp_1_514 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_59( 3 ); /* set-car! */
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 2, 2 );
  twobit_check( 2, 0, 0, 1155, compiled_block_1_1155 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_load( 2, 1 );
  twobit_load( 3, 4 );
  twobit_global( 2 ); /*  array:coefficients~1ayXVW~11581 */
  twobit_setrtn( 1156, compiled_block_1_1156 );
  twobit_invoke( 4 );
  twobit_label( 1156, compiled_block_1_1156 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1155, compiled_block_1_1155 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_9( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_509, 3, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_509( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1158, compiled_block_1_1158 ); /* internal:branchf-null? */
  twobit_reg( 3 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_check( 3, 2, 0, 1159, compiled_block_1_1159 );
  twobit_lexical( 0, 1 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_check( 3, 2, 0, 1159, compiled_block_1_1159 );
  twobit_lexical( 0, 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_check( 3, 2, 0, 1159, compiled_block_1_1159 );
  twobit_reg( 3 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_check( 3, 2, 0, 1159, compiled_block_1_1159 );
  twobit_lexical( 0, 1 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_61( 4, 510, compiled_temp_1_510 ); /* + */
  twobit_return();
  twobit_label( 1158, compiled_block_1_1158 );
  twobit_reg_op1_check_652(reg(2),1160,compiled_block_1_1160); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 31 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 3, 30, 0, 1161, compiled_block_1_1161 );
  twobit_lexical( 0, 1 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 31 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 3, 30, 0, 1161, compiled_block_1_1161 );
  twobit_lexical( 0, 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op2_407( 31 ); /* <:fix:fix */
  twobit_setreg( 31 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 3, 30, 0, 1161, compiled_block_1_1161 );
  twobit_reg( 3 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 31 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 3, 30, 0, 1161, compiled_block_1_1161 );
  twobit_lexical( 0, 1 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_op2_63( 4, 511, compiled_temp_1_511 ); /* * */
  twobit_setreg( 31 );
  twobit_reg( 1 );
  twobit_op2_61( 31, 512, compiled_temp_1_512 ); /* + */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 3 );
  twobit_label( 1160, compiled_block_1_1160 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 1161, compiled_block_1_1161 );
  twobit_trap( 30, 3, 0, 160 );
  twobit_label( 1159, compiled_block_1_1159 );
  twobit_trap( 2, 3, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_10( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_const( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_11( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_const( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_12( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg_op2_check_662(reg(1),reg(4),1164,compiled_block_1_1164); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1164,compiled_block_1_1164); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_op2_63( 2, 505, compiled_temp_1_505 ); /* * */
  twobit_setreg( 31 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(4),1165,compiled_block_1_1165); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(4),1166,compiled_block_1_1166); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 506, compiled_temp_1_506 ); /* * */
  twobit_op2_61( 2, 507, compiled_temp_1_507 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 31 );
  twobit_op2_61( 4, 508, compiled_temp_1_508 ); /* + */
  twobit_return();
  twobit_label( 1165, compiled_block_1_1165 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1164, compiled_block_1_1164 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1166, compiled_block_1_1166 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_13( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1167,compiled_block_1_1167); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(4),1167,compiled_block_1_1167); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1168,compiled_block_1_1168); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_op2_63( 2, 503, compiled_temp_1_503 ); /* * */
  twobit_op2_61( 3, 504, compiled_temp_1_504 ); /* + */
  twobit_return();
  twobit_label( 1168, compiled_block_1_1168 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1167, compiled_block_1_1167 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_14( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_op2_601( 1 ); /* make-vector:1 */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_15( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_op2_602( 1 ); /* make-vector:2 */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op3_403( 3, 2 ); /* vector-set!:trusted */
  twobit_reg( 4 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_16( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_op2_603( 1 ); /* make-vector:3 */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_op3_403( 1, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op3_403( 3, 2 ); /* vector-set!:trusted */
  twobit_reg( 4 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_17( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_op2_604( 1 ); /* make-vector:4 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 31 );
  twobit_reg( 1 );
  twobit_op3_403( 31, 4 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 4, 3 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_reg( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_18( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 5 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_store( 4, 3 );
  twobit_store( 5, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 31 );
  twobit_reg( 1 );
  twobit_op2_58( 31 ); /* cons */
  twobit_setreg( 2 );
  twobit_movereg( 6, 1 );
  twobit_global( 1 ); /* append */
  twobit_setrtn( 1169, compiled_block_1_1169 );
  twobit_invoke( 2 );
  twobit_label( 1169, compiled_block_1_1169 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_global( 2 ); /* vector */
  twobit_setreg( 1 );
  twobit_movereg( 4, 6 );
  twobit_load( 2, 1 );
  twobit_load( 3, 2 );
  twobit_load( 4, 3 );
  twobit_load( 5, 4 );
  twobit_global( 3 ); /* apply */
  twobit_pop( 4 );
  twobit_invoke( 6 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_19( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_640( fixnum(0), 1172, compiled_block_1_1172 ); /* internal:branchf-eq?/imm */
  twobit_global( 1 ); /*  array:0~1ayXVW~11587 */
  twobit_return();
  twobit_label( 1172, compiled_block_1_1172 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_640( fixnum(1), 1174, compiled_block_1_1174 ); /* internal:branchf-eq?/imm */
  twobit_global( 2 ); /*  array:1~1ayXVW~11588 */
  twobit_return();
  twobit_label( 1174, compiled_block_1_1174 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_640( fixnum(2), 1176, compiled_block_1_1176 ); /* internal:branchf-eq?/imm */
  twobit_global( 3 ); /*  array:2~1ayXVW~11589 */
  twobit_return();
  twobit_label( 1176, compiled_block_1_1176 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_640( fixnum(3), 1178, compiled_block_1_1178 ); /* internal:branchf-eq?/imm */
  twobit_global( 4 ); /*  array:3~1ayXVW~11590 */
  twobit_return();
  twobit_label( 1178, compiled_block_1_1178 );
  twobit_global( 5 ); /*  array:n~1ayXVW~11591 */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_20( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(2),reg(4),1179,compiled_block_1_1179); /* internal:check-vector?/vector-length:vec with (0 2 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1179,compiled_block_1_1179); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_reg_op2_check_662(reg(1),reg(31),1180,compiled_block_1_1180); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(31),1180,compiled_block_1_1180); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 485, compiled_temp_1_485 ); /* * */
  twobit_setreg( 30 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(4),1181,compiled_block_1_1181); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(31),1182,compiled_block_1_1182); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 486, compiled_temp_1_486 ); /* * */
  twobit_setreg( 29 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(4),1183,compiled_block_1_1183); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(31),1184,compiled_block_1_1184); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 487, compiled_temp_1_487 ); /* * */
  twobit_setreg( 28 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(4),1185,compiled_block_1_1185); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(31),1186,compiled_block_1_1186); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 488, compiled_temp_1_488 ); /* * */
  twobit_setreg( 27 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_reg_op2_check_655(RESULT,reg(4),1187,compiled_block_1_1187); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_reg_op2_check_655(RESULT,reg(31),1188,compiled_block_1_1188); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 489, compiled_temp_1_489 ); /* * */
  twobit_setreg( 26 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_reg_op2_check_655(RESULT,reg(4),1189,compiled_block_1_1189); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_reg_op2_check_655(RESULT,reg(31),1190,compiled_block_1_1190); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 490, compiled_temp_1_490 ); /* * */
  twobit_setreg( 25 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_reg_op2_check_655(RESULT,reg(4),1191,compiled_block_1_1191); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(6) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_reg_op2_check_655(RESULT,reg(31),1192,compiled_block_1_1192); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(6) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 491, compiled_temp_1_491 ); /* * */
  twobit_setreg( 24 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_reg_op2_check_655(RESULT,reg(4),1193,compiled_block_1_1193); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(7) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_reg_op2_check_655(RESULT,reg(31),1194,compiled_block_1_1194); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(7) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 492, compiled_temp_1_492 ); /* * */
  twobit_setreg( 23 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_reg_op2_check_655(RESULT,reg(31),1195,compiled_block_1_1195); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(9) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_reg_op2_check_655(RESULT,reg(4),1196,compiled_block_1_1196); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(8) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_reg_op2_check_655(RESULT,reg(31),1197,compiled_block_1_1197); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(8) ); /* vector-ref:trusted */
  twobit_op2_63( 4, 493, compiled_temp_1_493 ); /* * */
  twobit_op2_61( 3, 494, compiled_temp_1_494 ); /* + */
  twobit_setreg( 2 );
  twobit_reg( 23 );
  twobit_op2_61( 2, 495, compiled_temp_1_495 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 24 );
  twobit_op2_61( 4, 496, compiled_temp_1_496 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 25 );
  twobit_op2_61( 4, 497, compiled_temp_1_497 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 26 );
  twobit_op2_61( 4, 498, compiled_temp_1_498 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 27 );
  twobit_op2_61( 4, 499, compiled_temp_1_499 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 28 );
  twobit_op2_61( 4, 500, compiled_temp_1_500 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 29 );
  twobit_op2_61( 4, 501, compiled_temp_1_501 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 30 );
  twobit_op2_61( 4, 502, compiled_temp_1_502 ); /* + */
  twobit_return();
  twobit_label( 1185, compiled_block_1_1185 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1191, compiled_block_1_1191 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1184, compiled_block_1_1184 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1190, compiled_block_1_1190 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1197, compiled_block_1_1197 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1181, compiled_block_1_1181 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1187, compiled_block_1_1187 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1193, compiled_block_1_1193 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1180, compiled_block_1_1180 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1186, compiled_block_1_1186 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1192, compiled_block_1_1192 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1195, compiled_block_1_1195 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1183, compiled_block_1_1183 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1189, compiled_block_1_1189 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1196, compiled_block_1_1196 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1182, compiled_block_1_1182 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1188, compiled_block_1_1188 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1194, compiled_block_1_1194 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1179, compiled_block_1_1179 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_21( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(2),reg(4),1198,compiled_block_1_1198); /* internal:check-vector?/vector-length:vec with (0 2 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1198,compiled_block_1_1198); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_reg_op2_check_662(reg(1),reg(31),1199,compiled_block_1_1199); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(31),1199,compiled_block_1_1199); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 469, compiled_temp_1_469 ); /* * */
  twobit_setreg( 30 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(4),1200,compiled_block_1_1200); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(31),1201,compiled_block_1_1201); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 470, compiled_temp_1_470 ); /* * */
  twobit_setreg( 29 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(4),1202,compiled_block_1_1202); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(31),1203,compiled_block_1_1203); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 471, compiled_temp_1_471 ); /* * */
  twobit_setreg( 28 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(4),1204,compiled_block_1_1204); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(31),1205,compiled_block_1_1205); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 472, compiled_temp_1_472 ); /* * */
  twobit_setreg( 27 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_reg_op2_check_655(RESULT,reg(4),1206,compiled_block_1_1206); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_reg_op2_check_655(RESULT,reg(31),1207,compiled_block_1_1207); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 473, compiled_temp_1_473 ); /* * */
  twobit_setreg( 26 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_reg_op2_check_655(RESULT,reg(4),1208,compiled_block_1_1208); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_reg_op2_check_655(RESULT,reg(31),1209,compiled_block_1_1209); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 474, compiled_temp_1_474 ); /* * */
  twobit_setreg( 25 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_reg_op2_check_655(RESULT,reg(4),1210,compiled_block_1_1210); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(6) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_reg_op2_check_655(RESULT,reg(31),1211,compiled_block_1_1211); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(6) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 475, compiled_temp_1_475 ); /* * */
  twobit_setreg( 24 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_reg_op2_check_655(RESULT,reg(31),1212,compiled_block_1_1212); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(8) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_reg_op2_check_655(RESULT,reg(4),1213,compiled_block_1_1213); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(7) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_reg_op2_check_655(RESULT,reg(31),1214,compiled_block_1_1214); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(7) ); /* vector-ref:trusted */
  twobit_op2_63( 4, 476, compiled_temp_1_476 ); /* * */
  twobit_op2_61( 3, 477, compiled_temp_1_477 ); /* + */
  twobit_setreg( 2 );
  twobit_reg( 24 );
  twobit_op2_61( 2, 478, compiled_temp_1_478 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 25 );
  twobit_op2_61( 4, 479, compiled_temp_1_479 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 26 );
  twobit_op2_61( 4, 480, compiled_temp_1_480 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 27 );
  twobit_op2_61( 4, 481, compiled_temp_1_481 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 28 );
  twobit_op2_61( 4, 482, compiled_temp_1_482 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 29 );
  twobit_op2_61( 4, 483, compiled_temp_1_483 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 30 );
  twobit_op2_61( 4, 484, compiled_temp_1_484 ); /* + */
  twobit_return();
  twobit_label( 1204, compiled_block_1_1204 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1210, compiled_block_1_1210 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1203, compiled_block_1_1203 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1209, compiled_block_1_1209 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1212, compiled_block_1_1212 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1200, compiled_block_1_1200 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1206, compiled_block_1_1206 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1213, compiled_block_1_1213 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1199, compiled_block_1_1199 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1205, compiled_block_1_1205 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1211, compiled_block_1_1211 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1202, compiled_block_1_1202 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1208, compiled_block_1_1208 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1201, compiled_block_1_1201 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1207, compiled_block_1_1207 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1214, compiled_block_1_1214 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1198, compiled_block_1_1198 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_22( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(2),reg(4),1215,compiled_block_1_1215); /* internal:check-vector?/vector-length:vec with (0 2 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1215,compiled_block_1_1215); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_reg_op2_check_662(reg(1),reg(31),1216,compiled_block_1_1216); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(31),1216,compiled_block_1_1216); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 455, compiled_temp_1_455 ); /* * */
  twobit_setreg( 30 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(4),1217,compiled_block_1_1217); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(31),1218,compiled_block_1_1218); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 456, compiled_temp_1_456 ); /* * */
  twobit_setreg( 29 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(4),1219,compiled_block_1_1219); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(31),1220,compiled_block_1_1220); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 457, compiled_temp_1_457 ); /* * */
  twobit_setreg( 28 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(4),1221,compiled_block_1_1221); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(31),1222,compiled_block_1_1222); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 458, compiled_temp_1_458 ); /* * */
  twobit_setreg( 27 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_reg_op2_check_655(RESULT,reg(4),1223,compiled_block_1_1223); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_reg_op2_check_655(RESULT,reg(31),1224,compiled_block_1_1224); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 459, compiled_temp_1_459 ); /* * */
  twobit_setreg( 26 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_reg_op2_check_655(RESULT,reg(4),1225,compiled_block_1_1225); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_reg_op2_check_655(RESULT,reg(31),1226,compiled_block_1_1226); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 460, compiled_temp_1_460 ); /* * */
  twobit_setreg( 25 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_reg_op2_check_655(RESULT,reg(31),1227,compiled_block_1_1227); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(7) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_reg_op2_check_655(RESULT,reg(4),1228,compiled_block_1_1228); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(6) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_reg_op2_check_655(RESULT,reg(31),1229,compiled_block_1_1229); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(6) ); /* vector-ref:trusted */
  twobit_op2_63( 4, 461, compiled_temp_1_461 ); /* * */
  twobit_op2_61( 3, 462, compiled_temp_1_462 ); /* + */
  twobit_setreg( 2 );
  twobit_reg( 25 );
  twobit_op2_61( 2, 463, compiled_temp_1_463 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 26 );
  twobit_op2_61( 4, 464, compiled_temp_1_464 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 27 );
  twobit_op2_61( 4, 465, compiled_temp_1_465 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 28 );
  twobit_op2_61( 4, 466, compiled_temp_1_466 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 29 );
  twobit_op2_61( 4, 467, compiled_temp_1_467 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 30 );
  twobit_op2_61( 4, 468, compiled_temp_1_468 ); /* + */
  twobit_return();
  twobit_label( 1221, compiled_block_1_1221 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1228, compiled_block_1_1228 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1220, compiled_block_1_1220 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1226, compiled_block_1_1226 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1217, compiled_block_1_1217 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1223, compiled_block_1_1223 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1216, compiled_block_1_1216 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1222, compiled_block_1_1222 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1229, compiled_block_1_1229 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1219, compiled_block_1_1219 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1225, compiled_block_1_1225 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1218, compiled_block_1_1218 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1224, compiled_block_1_1224 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1227, compiled_block_1_1227 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1215, compiled_block_1_1215 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_23( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(2),reg(4),1230,compiled_block_1_1230); /* internal:check-vector?/vector-length:vec with (0 2 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1230,compiled_block_1_1230); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_reg_op2_check_662(reg(1),reg(31),1231,compiled_block_1_1231); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(31),1231,compiled_block_1_1231); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 443, compiled_temp_1_443 ); /* * */
  twobit_setreg( 30 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(4),1232,compiled_block_1_1232); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(31),1233,compiled_block_1_1233); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 444, compiled_temp_1_444 ); /* * */
  twobit_setreg( 29 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(4),1234,compiled_block_1_1234); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(31),1235,compiled_block_1_1235); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 445, compiled_temp_1_445 ); /* * */
  twobit_setreg( 28 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(4),1236,compiled_block_1_1236); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(31),1237,compiled_block_1_1237); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 446, compiled_temp_1_446 ); /* * */
  twobit_setreg( 27 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_reg_op2_check_655(RESULT,reg(4),1238,compiled_block_1_1238); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_reg_op2_check_655(RESULT,reg(31),1239,compiled_block_1_1239); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 447, compiled_temp_1_447 ); /* * */
  twobit_setreg( 26 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_reg_op2_check_655(RESULT,reg(31),1240,compiled_block_1_1240); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(6) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_reg_op2_check_655(RESULT,reg(4),1241,compiled_block_1_1241); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_reg_op2_check_655(RESULT,reg(31),1242,compiled_block_1_1242); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_op2_63( 4, 448, compiled_temp_1_448 ); /* * */
  twobit_op2_61( 3, 449, compiled_temp_1_449 ); /* + */
  twobit_setreg( 2 );
  twobit_reg( 26 );
  twobit_op2_61( 2, 450, compiled_temp_1_450 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 27 );
  twobit_op2_61( 4, 451, compiled_temp_1_451 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 28 );
  twobit_op2_61( 4, 452, compiled_temp_1_452 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 29 );
  twobit_op2_61( 4, 453, compiled_temp_1_453 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 30 );
  twobit_op2_61( 4, 454, compiled_temp_1_454 ); /* + */
  twobit_return();
  twobit_label( 1236, compiled_block_1_1236 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1235, compiled_block_1_1235 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1242, compiled_block_1_1242 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1232, compiled_block_1_1232 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1238, compiled_block_1_1238 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1231, compiled_block_1_1231 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1237, compiled_block_1_1237 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1240, compiled_block_1_1240 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1234, compiled_block_1_1234 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1241, compiled_block_1_1241 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1233, compiled_block_1_1233 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1239, compiled_block_1_1239 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1230, compiled_block_1_1230 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_24( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(2),reg(4),1243,compiled_block_1_1243); /* internal:check-vector?/vector-length:vec with (0 2 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1243,compiled_block_1_1243); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_reg_op2_check_662(reg(1),reg(31),1244,compiled_block_1_1244); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(31),1244,compiled_block_1_1244); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 433, compiled_temp_1_433 ); /* * */
  twobit_setreg( 30 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(4),1245,compiled_block_1_1245); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(31),1246,compiled_block_1_1246); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 434, compiled_temp_1_434 ); /* * */
  twobit_setreg( 29 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(4),1247,compiled_block_1_1247); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(31),1248,compiled_block_1_1248); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 435, compiled_temp_1_435 ); /* * */
  twobit_setreg( 28 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(4),1249,compiled_block_1_1249); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(31),1250,compiled_block_1_1250); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 436, compiled_temp_1_436 ); /* * */
  twobit_setreg( 27 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_reg_op2_check_655(RESULT,reg(31),1251,compiled_block_1_1251); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_reg_op2_check_655(RESULT,reg(4),1252,compiled_block_1_1252); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_reg_op2_check_655(RESULT,reg(31),1253,compiled_block_1_1253); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_op2_63( 4, 437, compiled_temp_1_437 ); /* * */
  twobit_op2_61( 3, 438, compiled_temp_1_438 ); /* + */
  twobit_setreg( 2 );
  twobit_reg( 27 );
  twobit_op2_61( 2, 439, compiled_temp_1_439 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 28 );
  twobit_op2_61( 4, 440, compiled_temp_1_440 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 29 );
  twobit_op2_61( 4, 441, compiled_temp_1_441 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 30 );
  twobit_op2_61( 4, 442, compiled_temp_1_442 ); /* + */
  twobit_return();
  twobit_label( 1249, compiled_block_1_1249 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1248, compiled_block_1_1248 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1251, compiled_block_1_1251 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1245, compiled_block_1_1245 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1252, compiled_block_1_1252 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1244, compiled_block_1_1244 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1250, compiled_block_1_1250 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1247, compiled_block_1_1247 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1246, compiled_block_1_1246 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1253, compiled_block_1_1253 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1243, compiled_block_1_1243 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_25( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(2),reg(4),1254,compiled_block_1_1254); /* internal:check-vector?/vector-length:vec with (0 2 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1254,compiled_block_1_1254); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_reg_op2_check_662(reg(1),reg(31),1255,compiled_block_1_1255); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(31),1255,compiled_block_1_1255); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 425, compiled_temp_1_425 ); /* * */
  twobit_setreg( 30 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(4),1256,compiled_block_1_1256); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(31),1257,compiled_block_1_1257); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 426, compiled_temp_1_426 ); /* * */
  twobit_setreg( 29 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(4),1258,compiled_block_1_1258); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(31),1259,compiled_block_1_1259); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 427, compiled_temp_1_427 ); /* * */
  twobit_setreg( 28 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_reg_op2_check_655(RESULT,reg(31),1260,compiled_block_1_1260); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(4),1261,compiled_block_1_1261); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(31),1262,compiled_block_1_1262); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_op2_63( 4, 428, compiled_temp_1_428 ); /* * */
  twobit_op2_61( 3, 429, compiled_temp_1_429 ); /* + */
  twobit_setreg( 2 );
  twobit_reg( 28 );
  twobit_op2_61( 2, 430, compiled_temp_1_430 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 29 );
  twobit_op2_61( 4, 431, compiled_temp_1_431 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 30 );
  twobit_op2_61( 4, 432, compiled_temp_1_432 ); /* + */
  twobit_return();
  twobit_label( 1261, compiled_block_1_1261 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1259, compiled_block_1_1259 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1256, compiled_block_1_1256 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1255, compiled_block_1_1255 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1262, compiled_block_1_1262 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1258, compiled_block_1_1258 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1257, compiled_block_1_1257 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1260, compiled_block_1_1260 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1254, compiled_block_1_1254 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_26( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(2),reg(4),1263,compiled_block_1_1263); /* internal:check-vector?/vector-length:vec with (0 2 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1263,compiled_block_1_1263); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_reg_op2_check_662(reg(1),reg(31),1264,compiled_block_1_1264); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(31),1264,compiled_block_1_1264); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 419, compiled_temp_1_419 ); /* * */
  twobit_setreg( 30 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(4),1265,compiled_block_1_1265); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(31),1266,compiled_block_1_1266); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 420, compiled_temp_1_420 ); /* * */
  twobit_setreg( 29 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(31),1267,compiled_block_1_1267); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(4),1268,compiled_block_1_1268); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(31),1269,compiled_block_1_1269); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_op2_63( 4, 421, compiled_temp_1_421 ); /* * */
  twobit_op2_61( 3, 422, compiled_temp_1_422 ); /* + */
  twobit_setreg( 2 );
  twobit_reg( 29 );
  twobit_op2_61( 2, 423, compiled_temp_1_423 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 30 );
  twobit_op2_61( 4, 424, compiled_temp_1_424 ); /* + */
  twobit_return();
  twobit_label( 1269, compiled_block_1_1269 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1265, compiled_block_1_1265 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1264, compiled_block_1_1264 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1267, compiled_block_1_1267 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1268, compiled_block_1_1268 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1266, compiled_block_1_1266 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1263, compiled_block_1_1263 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_27( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(2),reg(4),1270,compiled_block_1_1270); /* internal:check-vector?/vector-length:vec with (0 2 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1270,compiled_block_1_1270); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_reg_op2_check_662(reg(1),reg(31),1271,compiled_block_1_1271); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(31),1271,compiled_block_1_1271); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 415, compiled_temp_1_415 ); /* * */
  twobit_setreg( 30 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(31),1272,compiled_block_1_1272); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(4),1273,compiled_block_1_1273); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(31),1274,compiled_block_1_1274); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_op2_63( 4, 416, compiled_temp_1_416 ); /* * */
  twobit_op2_61( 3, 417, compiled_temp_1_417 ); /* + */
  twobit_setreg( 2 );
  twobit_reg( 30 );
  twobit_op2_61( 2, 418, compiled_temp_1_418 ); /* + */
  twobit_return();
  twobit_label( 1272, compiled_block_1_1272 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1273, compiled_block_1_1273 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1271, compiled_block_1_1271 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1274, compiled_block_1_1274 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1270, compiled_block_1_1270 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_28( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1275,compiled_block_1_1275); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(4),1275,compiled_block_1_1275); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_reg_op2_check_662(reg(2),reg(31),1276,compiled_block_1_1276); /* internal:check-vector?/vector-length:vec with (0 2 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(31),1276,compiled_block_1_1276); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1277,compiled_block_1_1277); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_op2_63( 2, 413, compiled_temp_1_413 ); /* * */
  twobit_op2_61( 3, 414, compiled_temp_1_414 ); /* + */
  twobit_return();
  twobit_label( 1277, compiled_block_1_1277 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1275, compiled_block_1_1275 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1276, compiled_block_1_1276 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_29( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1278,compiled_block_1_1278); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1278,compiled_block_1_1278); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_op2imm_130( fixnum(0), 412, compiled_temp_1_412 ); /* + */
  twobit_return();
  twobit_label( 1278, compiled_block_1_1278 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_30( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lambda( compiled_start_1_384, 2, 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_384( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(10), 385, compiled_temp_1_385, 1281, compiled_block_1_1281 ); /* internal:branchf-</imm */
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1282, compiled_block_1_1282 );
  twobit_lexical( 1, 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1282, compiled_block_1_1282 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1282, compiled_block_1_1282 );
  twobit_lexical( 1, 1 );
  twobit_op2_402( 1 ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1281, compiled_block_1_1281 );
  twobit_label( 1279, compiled_block_1_1279 );
  twobit_lambda( compiled_start_1_386, 2, 1 );
  twobit_return();
  twobit_label( 1282, compiled_block_1_1282 );
  twobit_trap( 3, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_386( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 11 );
  twobit_store( 0, 0 );
  twobit_reg_op2_check_662(reg(2),reg(4),1284,compiled_block_1_1284); /* internal:check-vector?/vector-length:vec with (0 2 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1284,compiled_block_1_1284); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_reg_op2_check_662(reg(1),reg(31),1285,compiled_block_1_1285); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(31),1285,compiled_block_1_1285); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 387, compiled_temp_1_387 ); /* * */
  twobit_setreg( 30 );
  twobit_store( 30, 11 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(4),1286,compiled_block_1_1286); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(31),1287,compiled_block_1_1287); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 388, compiled_temp_1_388 ); /* * */
  twobit_setreg( 29 );
  twobit_store( 29, 10 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(4),1288,compiled_block_1_1288); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(31),1289,compiled_block_1_1289); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 389, compiled_temp_1_389 ); /* * */
  twobit_setreg( 28 );
  twobit_store( 28, 9 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(4),1290,compiled_block_1_1290); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(31),1291,compiled_block_1_1291); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 390, compiled_temp_1_390 ); /* * */
  twobit_setreg( 27 );
  twobit_store( 27, 8 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_reg_op2_check_655(RESULT,reg(4),1292,compiled_block_1_1292); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_reg_op2_check_655(RESULT,reg(31),1293,compiled_block_1_1293); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 391, compiled_temp_1_391 ); /* * */
  twobit_setreg( 26 );
  twobit_store( 26, 7 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_reg_op2_check_655(RESULT,reg(4),1294,compiled_block_1_1294); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_reg_op2_check_655(RESULT,reg(31),1295,compiled_block_1_1295); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 392, compiled_temp_1_392 ); /* * */
  twobit_setreg( 25 );
  twobit_store( 25, 6 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_reg_op2_check_655(RESULT,reg(4),1296,compiled_block_1_1296); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(6) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_reg_op2_check_655(RESULT,reg(31),1297,compiled_block_1_1297); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(6) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 393, compiled_temp_1_393 ); /* * */
  twobit_setreg( 24 );
  twobit_store( 24, 5 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_reg_op2_check_655(RESULT,reg(4),1298,compiled_block_1_1298); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(7) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_reg_op2_check_655(RESULT,reg(31),1299,compiled_block_1_1299); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(7) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 394, compiled_temp_1_394 ); /* * */
  twobit_setreg( 23 );
  twobit_store( 23, 4 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_reg_op2_check_655(RESULT,reg(4),1300,compiled_block_1_1300); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(8) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_reg_op2_check_655(RESULT,reg(31),1301,compiled_block_1_1301); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(8) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 395, compiled_temp_1_395 ); /* * */
  twobit_setreg( 22 );
  twobit_store( 22, 3 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_reg_op2_check_655(RESULT,reg(4),1302,compiled_block_1_1302); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(9) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_reg_op2_check_655(RESULT,reg(31),1303,compiled_block_1_1303); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(9) ); /* vector-ref:trusted */
  twobit_op2_63( 3, 396, compiled_temp_1_396 ); /* * */
  twobit_setreg( 21 );
  twobit_store( 21, 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 20 );
  twobit_reg( 3 );
  twobit_check( 20, 1, 0, 1304, compiled_block_1_1304 );
  twobit_lexical( 0, 1 );
  twobit_op2_407( 31 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 20 );
  twobit_reg( 3 );
  twobit_check( 20, 1, 0, 1304, compiled_block_1_1304 );
  twobit_lexical( 0, 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 20 );
  twobit_reg( 3 );
  twobit_check( 20, 1, 0, 1304, compiled_block_1_1304 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_lexical( 0, 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 20 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 19 );
  twobit_movereg( 31, 5 );
  twobit_movereg( 19, 3 );
  twobit_lambda( compiled_start_1_397, 3, 5 );
  twobit_setreg( 4 );
  twobit_movereg( 20, 2 );
  twobit_reg( 19 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 19 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1310, compiled_block_1_1310 );
  twobit_invoke( 2 );
  twobit_label( 1310, compiled_block_1_1310 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_61( 3, 398, compiled_temp_1_398 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_61( 4, 399, compiled_temp_1_399 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_61( 4, 400, compiled_temp_1_400 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_61( 4, 401, compiled_temp_1_401 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_61( 4, 402, compiled_temp_1_402 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_61( 4, 403, compiled_temp_1_403 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_61( 4, 404, compiled_temp_1_404 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_61( 4, 405, compiled_temp_1_405 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_61( 4, 406, compiled_temp_1_406 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_61( 4, 407, compiled_temp_1_407 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_61( 4, 408, compiled_temp_1_408 ); /* + */
  twobit_pop( 11 );
  twobit_return();
  twobit_label( 1304, compiled_block_1_1304 );
  twobit_trap( 1, 20, 0, 160 );
  twobit_label( 1286, compiled_block_1_1286 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1297, compiled_block_1_1297 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1300, compiled_block_1_1300 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1293, compiled_block_1_1293 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1296, compiled_block_1_1296 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1289, compiled_block_1_1289 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1292, compiled_block_1_1292 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1303, compiled_block_1_1303 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1285, compiled_block_1_1285 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1288, compiled_block_1_1288 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1299, compiled_block_1_1299 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1302, compiled_block_1_1302 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1284, compiled_block_1_1284 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1295, compiled_block_1_1295 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1298, compiled_block_1_1298 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1291, compiled_block_1_1291 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1294, compiled_block_1_1294 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1287, compiled_block_1_1287 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1290, compiled_block_1_1290 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1301, compiled_block_1_1301 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_397( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op2imm_branchf_635( fixnum(10), 409, compiled_temp_1_409, 1306, compiled_block_1_1306 ); /* internal:branchf-</imm */
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1306, compiled_block_1_1306 );
  twobit_reg( 2 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 2, 3, 0, 1307, compiled_block_1_1307 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 2, 3, 0, 1307, compiled_block_1_1307 );
  twobit_reg( 2 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 2, 3, 0, 1307, compiled_block_1_1307 );
  twobit_lexical( 0, 2 );
  twobit_op2_402( 2 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 2, 31, 0, 1308, compiled_block_1_1308 );
  twobit_lexical( 0, 1 );
  twobit_op2_402( 2 ); /* vector-ref:trusted */
  twobit_op2_63( 4, 410, compiled_temp_1_410 ); /* * */
  twobit_op2_61( 1, 411, compiled_temp_1_411 ); /* + */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 1308, compiled_block_1_1308 );
  twobit_trap( 31, 2, 0, 160 );
  twobit_label( 1307, compiled_block_1_1307 );
  twobit_trap( 3, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_31( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 14 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 1 );
  twobit_store( 3, 5 );
  twobit_reg_op2_check_662(reg(1),reg(4),1312,compiled_block_1_1312); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_store( 4, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1312,compiled_block_1_1312); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 31 );
  twobit_store( 31, 2 );
  twobit_movereg( 3, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1313, compiled_block_1_1313 );
  twobit_invoke( 2 );
  twobit_label( 1313, compiled_block_1_1313 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1314, compiled_block_1_1314 );
  twobit_stack( 1 );
  twobit_reg_op1_check_653(RESULT,1314,compiled_block_1_1314); /* internal:check-vector? with (4 1 0) */
  twobit_stack( 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 1 );
  twobit_check( 4, 2, 0, 1315, compiled_block_1_1315 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1315,compiled_block_1_1315); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 366, compiled_temp_1_366 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 14 );
  twobit_load( 2, 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_407( 2 ); /* <:fix:fix */
  twobit_load( 2, 4 );
  twobit_check( 0, 2, 0, 1316, compiled_block_1_1316 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1317, compiled_block_1_1317 );
  twobit_invoke( 2 );
  twobit_label( 1317, compiled_block_1_1317 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1314, compiled_block_1_1314 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1318, compiled_block_1_1318 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1314,compiled_block_1_1314); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 367, compiled_temp_1_367 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 13 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1319, compiled_block_1_1319 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1320, compiled_block_1_1320 );
  twobit_invoke( 2 );
  twobit_label( 1320, compiled_block_1_1320 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1314, compiled_block_1_1314 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1318, compiled_block_1_1318 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1314,compiled_block_1_1314); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 368, compiled_temp_1_368 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1321, compiled_block_1_1321 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1322, compiled_block_1_1322 );
  twobit_invoke( 2 );
  twobit_label( 1322, compiled_block_1_1322 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1314, compiled_block_1_1314 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1318, compiled_block_1_1318 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1314,compiled_block_1_1314); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 369, compiled_temp_1_369 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1323, compiled_block_1_1323 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1324, compiled_block_1_1324 );
  twobit_invoke( 2 );
  twobit_label( 1324, compiled_block_1_1324 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1314, compiled_block_1_1314 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1318, compiled_block_1_1318 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1314,compiled_block_1_1314); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 370, compiled_temp_1_370 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1325, compiled_block_1_1325 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1326, compiled_block_1_1326 );
  twobit_invoke( 2 );
  twobit_label( 1326, compiled_block_1_1326 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1314, compiled_block_1_1314 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1318, compiled_block_1_1318 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1314,compiled_block_1_1314); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 371, compiled_temp_1_371 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1327, compiled_block_1_1327 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(6) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1328, compiled_block_1_1328 );
  twobit_invoke( 2 );
  twobit_label( 1328, compiled_block_1_1328 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1314, compiled_block_1_1314 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1318, compiled_block_1_1318 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1314,compiled_block_1_1314); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 372, compiled_temp_1_372 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1329, compiled_block_1_1329 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(7) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1330, compiled_block_1_1330 );
  twobit_invoke( 2 );
  twobit_label( 1330, compiled_block_1_1330 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1314, compiled_block_1_1314 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1318, compiled_block_1_1318 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1314,compiled_block_1_1314); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 373, compiled_temp_1_373 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1331, compiled_block_1_1331 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(9) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_reg_op2_check_655(RESULT,reg(3),1332,compiled_block_1_1332); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(8) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1333, compiled_block_1_1333 );
  twobit_invoke( 2 );
  twobit_label( 1333, compiled_block_1_1333 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1314, compiled_block_1_1314 );
  twobit_load( 3, 6 );
  twobit_reg_op2_check_661(reg(4),reg(3),1314,compiled_block_1_1314); /* internal:check-range with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_63( 4, 374, compiled_temp_1_374 ); /* * */
  twobit_load( 3, 2 );
  twobit_op2_61( 3, 375, compiled_temp_1_375 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_61( 4, 376, compiled_temp_1_376 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_61( 4, 377, compiled_temp_1_377 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_61( 4, 378, compiled_temp_1_378 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_61( 4, 379, compiled_temp_1_379 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_61( 4, 380, compiled_temp_1_380 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_61( 4, 381, compiled_temp_1_381 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 13 );
  twobit_op2_61( 4, 382, compiled_temp_1_382 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 14 );
  twobit_op2_61( 4, 383, compiled_temp_1_383 ); /* + */
  twobit_pop( 14 );
  twobit_return();
  twobit_label( 1319, compiled_block_1_1319 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1325, compiled_block_1_1325 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1332, compiled_block_1_1332 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1316, compiled_block_1_1316 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1315, compiled_block_1_1315 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1312, compiled_block_1_1312 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1321, compiled_block_1_1321 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1327, compiled_block_1_1327 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1331, compiled_block_1_1331 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1318, compiled_block_1_1318 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_label( 1323, compiled_block_1_1323 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1314, compiled_block_1_1314 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_label( 1329, compiled_block_1_1329 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_32( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 13 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 1 );
  twobit_store( 3, 5 );
  twobit_reg_op2_check_662(reg(1),reg(4),1334,compiled_block_1_1334); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_store( 4, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1334,compiled_block_1_1334); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 31 );
  twobit_store( 31, 2 );
  twobit_movereg( 3, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1335, compiled_block_1_1335 );
  twobit_invoke( 2 );
  twobit_label( 1335, compiled_block_1_1335 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1336, compiled_block_1_1336 );
  twobit_stack( 1 );
  twobit_reg_op1_check_653(RESULT,1336,compiled_block_1_1336); /* internal:check-vector? with (4 1 0) */
  twobit_stack( 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 1 );
  twobit_check( 4, 2, 0, 1337, compiled_block_1_1337 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1337,compiled_block_1_1337); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 350, compiled_temp_1_350 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 13 );
  twobit_load( 2, 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_407( 2 ); /* <:fix:fix */
  twobit_load( 2, 4 );
  twobit_check( 0, 2, 0, 1338, compiled_block_1_1338 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1339, compiled_block_1_1339 );
  twobit_invoke( 2 );
  twobit_label( 1339, compiled_block_1_1339 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1336, compiled_block_1_1336 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1340, compiled_block_1_1340 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1336,compiled_block_1_1336); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 351, compiled_temp_1_351 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1341, compiled_block_1_1341 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1342, compiled_block_1_1342 );
  twobit_invoke( 2 );
  twobit_label( 1342, compiled_block_1_1342 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1336, compiled_block_1_1336 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1340, compiled_block_1_1340 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1336,compiled_block_1_1336); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 352, compiled_temp_1_352 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1343, compiled_block_1_1343 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1344, compiled_block_1_1344 );
  twobit_invoke( 2 );
  twobit_label( 1344, compiled_block_1_1344 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1336, compiled_block_1_1336 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1340, compiled_block_1_1340 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1336,compiled_block_1_1336); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 353, compiled_temp_1_353 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1345, compiled_block_1_1345 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1346, compiled_block_1_1346 );
  twobit_invoke( 2 );
  twobit_label( 1346, compiled_block_1_1346 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1336, compiled_block_1_1336 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1340, compiled_block_1_1340 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1336,compiled_block_1_1336); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 354, compiled_temp_1_354 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1347, compiled_block_1_1347 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1348, compiled_block_1_1348 );
  twobit_invoke( 2 );
  twobit_label( 1348, compiled_block_1_1348 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1336, compiled_block_1_1336 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1340, compiled_block_1_1340 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1336,compiled_block_1_1336); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 355, compiled_temp_1_355 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1349, compiled_block_1_1349 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(6) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1350, compiled_block_1_1350 );
  twobit_invoke( 2 );
  twobit_label( 1350, compiled_block_1_1350 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1336, compiled_block_1_1336 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1340, compiled_block_1_1340 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1336,compiled_block_1_1336); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 356, compiled_temp_1_356 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1351, compiled_block_1_1351 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(8) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_reg_op2_check_655(RESULT,reg(3),1352,compiled_block_1_1352); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(7) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1353, compiled_block_1_1353 );
  twobit_invoke( 2 );
  twobit_label( 1353, compiled_block_1_1353 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1336, compiled_block_1_1336 );
  twobit_load( 3, 6 );
  twobit_reg_op2_check_661(reg(4),reg(3),1336,compiled_block_1_1336); /* internal:check-range with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_63( 4, 357, compiled_temp_1_357 ); /* * */
  twobit_load( 3, 2 );
  twobit_op2_61( 3, 358, compiled_temp_1_358 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_61( 4, 359, compiled_temp_1_359 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_61( 4, 360, compiled_temp_1_360 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_61( 4, 361, compiled_temp_1_361 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_61( 4, 362, compiled_temp_1_362 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_61( 4, 363, compiled_temp_1_363 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_61( 4, 364, compiled_temp_1_364 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 13 );
  twobit_op2_61( 4, 365, compiled_temp_1_365 ); /* + */
  twobit_pop( 13 );
  twobit_return();
  twobit_label( 1341, compiled_block_1_1341 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1347, compiled_block_1_1347 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1351, compiled_block_1_1351 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1338, compiled_block_1_1338 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1337, compiled_block_1_1337 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1334, compiled_block_1_1334 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1343, compiled_block_1_1343 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1349, compiled_block_1_1349 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1340, compiled_block_1_1340 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_label( 1345, compiled_block_1_1345 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1336, compiled_block_1_1336 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_label( 1352, compiled_block_1_1352 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_33( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 12 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 1 );
  twobit_store( 3, 5 );
  twobit_reg_op2_check_662(reg(1),reg(4),1354,compiled_block_1_1354); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_store( 4, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1354,compiled_block_1_1354); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 31 );
  twobit_store( 31, 2 );
  twobit_movereg( 3, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1355, compiled_block_1_1355 );
  twobit_invoke( 2 );
  twobit_label( 1355, compiled_block_1_1355 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1356, compiled_block_1_1356 );
  twobit_stack( 1 );
  twobit_reg_op1_check_653(RESULT,1356,compiled_block_1_1356); /* internal:check-vector? with (4 1 0) */
  twobit_stack( 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 1 );
  twobit_check( 4, 2, 0, 1357, compiled_block_1_1357 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1357,compiled_block_1_1357); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 336, compiled_temp_1_336 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_load( 2, 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_407( 2 ); /* <:fix:fix */
  twobit_load( 2, 4 );
  twobit_check( 0, 2, 0, 1358, compiled_block_1_1358 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1359, compiled_block_1_1359 );
  twobit_invoke( 2 );
  twobit_label( 1359, compiled_block_1_1359 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1356, compiled_block_1_1356 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1360, compiled_block_1_1360 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1356,compiled_block_1_1356); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 337, compiled_temp_1_337 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1361, compiled_block_1_1361 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1362, compiled_block_1_1362 );
  twobit_invoke( 2 );
  twobit_label( 1362, compiled_block_1_1362 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1356, compiled_block_1_1356 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1360, compiled_block_1_1360 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1356,compiled_block_1_1356); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 338, compiled_temp_1_338 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1363, compiled_block_1_1363 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1364, compiled_block_1_1364 );
  twobit_invoke( 2 );
  twobit_label( 1364, compiled_block_1_1364 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1356, compiled_block_1_1356 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1360, compiled_block_1_1360 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1356,compiled_block_1_1356); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 339, compiled_temp_1_339 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1365, compiled_block_1_1365 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1366, compiled_block_1_1366 );
  twobit_invoke( 2 );
  twobit_label( 1366, compiled_block_1_1366 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1356, compiled_block_1_1356 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1360, compiled_block_1_1360 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1356,compiled_block_1_1356); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 340, compiled_temp_1_340 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1367, compiled_block_1_1367 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1368, compiled_block_1_1368 );
  twobit_invoke( 2 );
  twobit_label( 1368, compiled_block_1_1368 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1356, compiled_block_1_1356 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1360, compiled_block_1_1360 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1356,compiled_block_1_1356); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 341, compiled_temp_1_341 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1369, compiled_block_1_1369 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(7) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_reg_op2_check_655(RESULT,reg(3),1370,compiled_block_1_1370); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(6) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1371, compiled_block_1_1371 );
  twobit_invoke( 2 );
  twobit_label( 1371, compiled_block_1_1371 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1356, compiled_block_1_1356 );
  twobit_load( 3, 6 );
  twobit_reg_op2_check_661(reg(4),reg(3),1356,compiled_block_1_1356); /* internal:check-range with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_63( 4, 342, compiled_temp_1_342 ); /* * */
  twobit_load( 3, 2 );
  twobit_op2_61( 3, 343, compiled_temp_1_343 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_61( 4, 344, compiled_temp_1_344 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_61( 4, 345, compiled_temp_1_345 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_61( 4, 346, compiled_temp_1_346 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_61( 4, 347, compiled_temp_1_347 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_61( 4, 348, compiled_temp_1_348 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_61( 4, 349, compiled_temp_1_349 ); /* + */
  twobit_pop( 12 );
  twobit_return();
  twobit_label( 1361, compiled_block_1_1361 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1367, compiled_block_1_1367 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1358, compiled_block_1_1358 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1357, compiled_block_1_1357 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1354, compiled_block_1_1354 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1363, compiled_block_1_1363 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1370, compiled_block_1_1370 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1360, compiled_block_1_1360 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_label( 1365, compiled_block_1_1365 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1356, compiled_block_1_1356 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_label( 1369, compiled_block_1_1369 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_34( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 11 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 1 );
  twobit_store( 3, 5 );
  twobit_reg_op2_check_662(reg(1),reg(4),1372,compiled_block_1_1372); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_store( 4, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1372,compiled_block_1_1372); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 31 );
  twobit_store( 31, 2 );
  twobit_movereg( 3, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1373, compiled_block_1_1373 );
  twobit_invoke( 2 );
  twobit_label( 1373, compiled_block_1_1373 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1374, compiled_block_1_1374 );
  twobit_stack( 1 );
  twobit_reg_op1_check_653(RESULT,1374,compiled_block_1_1374); /* internal:check-vector? with (4 1 0) */
  twobit_stack( 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 1 );
  twobit_check( 4, 2, 0, 1375, compiled_block_1_1375 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1375,compiled_block_1_1375); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 324, compiled_temp_1_324 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_load( 2, 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_407( 2 ); /* <:fix:fix */
  twobit_load( 2, 4 );
  twobit_check( 0, 2, 0, 1376, compiled_block_1_1376 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1377, compiled_block_1_1377 );
  twobit_invoke( 2 );
  twobit_label( 1377, compiled_block_1_1377 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1374, compiled_block_1_1374 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1378, compiled_block_1_1378 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1374,compiled_block_1_1374); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 325, compiled_temp_1_325 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1379, compiled_block_1_1379 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1380, compiled_block_1_1380 );
  twobit_invoke( 2 );
  twobit_label( 1380, compiled_block_1_1380 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1374, compiled_block_1_1374 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1378, compiled_block_1_1378 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1374,compiled_block_1_1374); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 326, compiled_temp_1_326 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1381, compiled_block_1_1381 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1382, compiled_block_1_1382 );
  twobit_invoke( 2 );
  twobit_label( 1382, compiled_block_1_1382 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1374, compiled_block_1_1374 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1378, compiled_block_1_1378 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1374,compiled_block_1_1374); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 327, compiled_temp_1_327 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1383, compiled_block_1_1383 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1384, compiled_block_1_1384 );
  twobit_invoke( 2 );
  twobit_label( 1384, compiled_block_1_1384 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1374, compiled_block_1_1374 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1378, compiled_block_1_1378 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1374,compiled_block_1_1374); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 328, compiled_temp_1_328 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1385, compiled_block_1_1385 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(6) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_reg_op2_check_655(RESULT,reg(3),1386,compiled_block_1_1386); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1387, compiled_block_1_1387 );
  twobit_invoke( 2 );
  twobit_label( 1387, compiled_block_1_1387 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1374, compiled_block_1_1374 );
  twobit_load( 3, 6 );
  twobit_reg_op2_check_661(reg(4),reg(3),1374,compiled_block_1_1374); /* internal:check-range with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_63( 4, 329, compiled_temp_1_329 ); /* * */
  twobit_load( 3, 2 );
  twobit_op2_61( 3, 330, compiled_temp_1_330 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_61( 4, 331, compiled_temp_1_331 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_61( 4, 332, compiled_temp_1_332 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_61( 4, 333, compiled_temp_1_333 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_61( 4, 334, compiled_temp_1_334 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_61( 4, 335, compiled_temp_1_335 ); /* + */
  twobit_pop( 11 );
  twobit_return();
  twobit_label( 1379, compiled_block_1_1379 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1386, compiled_block_1_1386 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1376, compiled_block_1_1376 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1375, compiled_block_1_1375 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1372, compiled_block_1_1372 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1381, compiled_block_1_1381 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1385, compiled_block_1_1385 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1378, compiled_block_1_1378 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_label( 1383, compiled_block_1_1383 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1374, compiled_block_1_1374 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_35( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 10 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 1 );
  twobit_store( 3, 5 );
  twobit_reg_op2_check_662(reg(1),reg(4),1388,compiled_block_1_1388); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_store( 4, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1388,compiled_block_1_1388); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 31 );
  twobit_store( 31, 2 );
  twobit_movereg( 3, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1389, compiled_block_1_1389 );
  twobit_invoke( 2 );
  twobit_label( 1389, compiled_block_1_1389 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1390, compiled_block_1_1390 );
  twobit_stack( 1 );
  twobit_reg_op1_check_653(RESULT,1390,compiled_block_1_1390); /* internal:check-vector? with (4 1 0) */
  twobit_stack( 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 1 );
  twobit_check( 4, 2, 0, 1391, compiled_block_1_1391 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1391,compiled_block_1_1391); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 314, compiled_temp_1_314 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_load( 2, 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_407( 2 ); /* <:fix:fix */
  twobit_load( 2, 4 );
  twobit_check( 0, 2, 0, 1392, compiled_block_1_1392 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1393, compiled_block_1_1393 );
  twobit_invoke( 2 );
  twobit_label( 1393, compiled_block_1_1393 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1390, compiled_block_1_1390 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1394, compiled_block_1_1394 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1390,compiled_block_1_1390); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 315, compiled_temp_1_315 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1395, compiled_block_1_1395 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1396, compiled_block_1_1396 );
  twobit_invoke( 2 );
  twobit_label( 1396, compiled_block_1_1396 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1390, compiled_block_1_1390 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1394, compiled_block_1_1394 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1390,compiled_block_1_1390); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 316, compiled_temp_1_316 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1397, compiled_block_1_1397 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1398, compiled_block_1_1398 );
  twobit_invoke( 2 );
  twobit_label( 1398, compiled_block_1_1398 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1390, compiled_block_1_1390 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1394, compiled_block_1_1394 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1390,compiled_block_1_1390); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 317, compiled_temp_1_317 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1399, compiled_block_1_1399 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_reg_op2_check_655(RESULT,reg(3),1400,compiled_block_1_1400); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1401, compiled_block_1_1401 );
  twobit_invoke( 2 );
  twobit_label( 1401, compiled_block_1_1401 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1390, compiled_block_1_1390 );
  twobit_load( 3, 6 );
  twobit_reg_op2_check_661(reg(4),reg(3),1390,compiled_block_1_1390); /* internal:check-range with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_63( 4, 318, compiled_temp_1_318 ); /* * */
  twobit_load( 3, 2 );
  twobit_op2_61( 3, 319, compiled_temp_1_319 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_61( 4, 320, compiled_temp_1_320 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_61( 4, 321, compiled_temp_1_321 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_61( 4, 322, compiled_temp_1_322 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_61( 4, 323, compiled_temp_1_323 ); /* + */
  twobit_pop( 10 );
  twobit_return();
  twobit_label( 1395, compiled_block_1_1395 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1399, compiled_block_1_1399 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1392, compiled_block_1_1392 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1391, compiled_block_1_1391 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1388, compiled_block_1_1388 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1397, compiled_block_1_1397 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1394, compiled_block_1_1394 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_label( 1400, compiled_block_1_1400 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1390, compiled_block_1_1390 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_36( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 9 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 1 );
  twobit_store( 3, 5 );
  twobit_reg_op2_check_662(reg(1),reg(4),1402,compiled_block_1_1402); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_store( 4, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1402,compiled_block_1_1402); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 31 );
  twobit_store( 31, 2 );
  twobit_movereg( 3, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1403, compiled_block_1_1403 );
  twobit_invoke( 2 );
  twobit_label( 1403, compiled_block_1_1403 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1404, compiled_block_1_1404 );
  twobit_stack( 1 );
  twobit_reg_op1_check_653(RESULT,1404,compiled_block_1_1404); /* internal:check-vector? with (4 1 0) */
  twobit_stack( 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 1 );
  twobit_check( 4, 2, 0, 1405, compiled_block_1_1405 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1405,compiled_block_1_1405); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 306, compiled_temp_1_306 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_load( 2, 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_407( 2 ); /* <:fix:fix */
  twobit_load( 2, 4 );
  twobit_check( 0, 2, 0, 1406, compiled_block_1_1406 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1407, compiled_block_1_1407 );
  twobit_invoke( 2 );
  twobit_label( 1407, compiled_block_1_1407 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1404, compiled_block_1_1404 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1408, compiled_block_1_1408 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1404,compiled_block_1_1404); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 307, compiled_temp_1_307 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1409, compiled_block_1_1409 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1410, compiled_block_1_1410 );
  twobit_invoke( 2 );
  twobit_label( 1410, compiled_block_1_1410 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1404, compiled_block_1_1404 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1408, compiled_block_1_1408 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1404,compiled_block_1_1404); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 308, compiled_temp_1_308 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1411, compiled_block_1_1411 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(3),1412,compiled_block_1_1412); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1413, compiled_block_1_1413 );
  twobit_invoke( 2 );
  twobit_label( 1413, compiled_block_1_1413 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1404, compiled_block_1_1404 );
  twobit_load( 3, 6 );
  twobit_reg_op2_check_661(reg(4),reg(3),1404,compiled_block_1_1404); /* internal:check-range with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_63( 4, 309, compiled_temp_1_309 ); /* * */
  twobit_load( 3, 2 );
  twobit_op2_61( 3, 310, compiled_temp_1_310 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_61( 4, 311, compiled_temp_1_311 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_61( 4, 312, compiled_temp_1_312 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_61( 4, 313, compiled_temp_1_313 ); /* + */
  twobit_pop( 9 );
  twobit_return();
  twobit_label( 1409, compiled_block_1_1409 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1406, compiled_block_1_1406 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1405, compiled_block_1_1405 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1402, compiled_block_1_1402 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1412, compiled_block_1_1412 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1408, compiled_block_1_1408 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_label( 1411, compiled_block_1_1411 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1404, compiled_block_1_1404 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_37( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 1 );
  twobit_store( 3, 5 );
  twobit_reg_op2_check_662(reg(1),reg(4),1414,compiled_block_1_1414); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_store( 4, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1414,compiled_block_1_1414); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 31 );
  twobit_store( 31, 2 );
  twobit_movereg( 3, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1415, compiled_block_1_1415 );
  twobit_invoke( 2 );
  twobit_label( 1415, compiled_block_1_1415 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1416, compiled_block_1_1416 );
  twobit_stack( 1 );
  twobit_reg_op1_check_653(RESULT,1416,compiled_block_1_1416); /* internal:check-vector? with (4 1 0) */
  twobit_stack( 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 1 );
  twobit_check( 4, 2, 0, 1417, compiled_block_1_1417 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1417,compiled_block_1_1417); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 300, compiled_temp_1_300 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_load( 2, 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_407( 2 ); /* <:fix:fix */
  twobit_load( 2, 4 );
  twobit_check( 0, 2, 0, 1418, compiled_block_1_1418 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1419, compiled_block_1_1419 );
  twobit_invoke( 2 );
  twobit_label( 1419, compiled_block_1_1419 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1416, compiled_block_1_1416 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1420, compiled_block_1_1420 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1416,compiled_block_1_1416); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 301, compiled_temp_1_301 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1421, compiled_block_1_1421 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(3),1422,compiled_block_1_1422); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1423, compiled_block_1_1423 );
  twobit_invoke( 2 );
  twobit_label( 1423, compiled_block_1_1423 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1416, compiled_block_1_1416 );
  twobit_load( 3, 6 );
  twobit_reg_op2_check_661(reg(4),reg(3),1416,compiled_block_1_1416); /* internal:check-range with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_63( 4, 302, compiled_temp_1_302 ); /* * */
  twobit_load( 3, 2 );
  twobit_op2_61( 3, 303, compiled_temp_1_303 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_61( 4, 304, compiled_temp_1_304 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_61( 4, 305, compiled_temp_1_305 ); /* + */
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 1422, compiled_block_1_1422 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1418, compiled_block_1_1418 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1417, compiled_block_1_1417 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1414, compiled_block_1_1414 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1421, compiled_block_1_1421 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1420, compiled_block_1_1420 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_label( 1416, compiled_block_1_1416 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_38( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 1 );
  twobit_store( 3, 5 );
  twobit_reg_op2_check_662(reg(1),reg(4),1424,compiled_block_1_1424); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_store( 4, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1424,compiled_block_1_1424); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 31 );
  twobit_store( 31, 2 );
  twobit_movereg( 3, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1425, compiled_block_1_1425 );
  twobit_invoke( 2 );
  twobit_label( 1425, compiled_block_1_1425 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1426, compiled_block_1_1426 );
  twobit_stack( 1 );
  twobit_reg_op1_check_653(RESULT,1426,compiled_block_1_1426); /* internal:check-vector? with (4 1 0) */
  twobit_stack( 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 1 );
  twobit_check( 4, 2, 0, 1427, compiled_block_1_1427 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1427,compiled_block_1_1427); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 296, compiled_temp_1_296 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 2, 3 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_op2_407( 2 ); /* <:fix:fix */
  twobit_load( 2, 4 );
  twobit_check( 0, 2, 0, 1428, compiled_block_1_1428 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_407( 1 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1429, compiled_block_1_1429 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_store( 1, 4 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1430, compiled_block_1_1430 );
  twobit_invoke( 2 );
  twobit_label( 1430, compiled_block_1_1430 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1426, compiled_block_1_1426 );
  twobit_load( 3, 6 );
  twobit_reg_op2_check_661(reg(4),reg(3),1426,compiled_block_1_1426); /* internal:check-range with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_63( 4, 297, compiled_temp_1_297 ); /* * */
  twobit_load( 3, 2 );
  twobit_op2_61( 3, 298, compiled_temp_1_298 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_61( 4, 299, compiled_temp_1_299 ); /* + */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1427, compiled_block_1_1427 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1424, compiled_block_1_1424 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1428, compiled_block_1_1428 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1429, compiled_block_1_1429 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1426, compiled_block_1_1426 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_39( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_reg_op2_check_662(reg(1),reg(4),1431,compiled_block_1_1431); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(4),1431,compiled_block_1_1431); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 31 );
  twobit_store( 31, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1432,compiled_block_1_1432); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1433, compiled_block_1_1433 );
  twobit_invoke( 2 );
  twobit_label( 1433, compiled_block_1_1433 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1434, compiled_block_1_1434 );
  twobit_stack( 1 );
  twobit_reg_op1_check_653(RESULT,1434,compiled_block_1_1434); /* internal:check-vector? with (4 1 0) */
  twobit_stack( 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_reg_op2_check_661(reg(4),reg(3),1434,compiled_block_1_1434); /* internal:check-range with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 294, compiled_temp_1_294 ); /* * */
  twobit_load( 3, 3 );
  twobit_op2_61( 3, 295, compiled_temp_1_295 ); /* + */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1432, compiled_block_1_1432 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1431, compiled_block_1_1431 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1434, compiled_block_1_1434 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_40( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg_op2_check_662(reg(1),reg(4),1435,compiled_block_1_1435); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1435,compiled_block_1_1435); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_op2imm_130( fixnum(0), 293, compiled_temp_1_293 ); /* + */
  twobit_return();
  twobit_label( 1435, compiled_block_1_1435 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_41( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lambda( compiled_start_1_264, 2, 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_264( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(10), 265, compiled_temp_1_265, 1438, compiled_block_1_1438 ); /* internal:branchf-</imm */
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1439, compiled_block_1_1439 );
  twobit_lexical( 1, 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1439, compiled_block_1_1439 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1439, compiled_block_1_1439 );
  twobit_lexical( 1, 1 );
  twobit_op2_402( 1 ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1438, compiled_block_1_1438 );
  twobit_label( 1436, compiled_block_1_1436 );
  twobit_lambda( compiled_start_1_266, 2, 1 );
  twobit_return();
  twobit_label( 1439, compiled_block_1_1439 );
  twobit_trap( 3, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_266( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 17 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 1 );
  twobit_store( 3, 5 );
  twobit_reg_op2_check_662(reg(1),reg(4),1441,compiled_block_1_1441); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_store( 4, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1441,compiled_block_1_1441); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 31 );
  twobit_store( 31, 2 );
  twobit_movereg( 3, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1442, compiled_block_1_1442 );
  twobit_invoke( 2 );
  twobit_label( 1442, compiled_block_1_1442 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1443, compiled_block_1_1443 );
  twobit_stack( 1 );
  twobit_reg_op1_check_653(RESULT,1443,compiled_block_1_1443); /* internal:check-vector? with (4 1 0) */
  twobit_stack( 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 1 );
  twobit_check( 4, 2, 0, 1444, compiled_block_1_1444 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1444,compiled_block_1_1444); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 267, compiled_temp_1_267 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 17 );
  twobit_load( 2, 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_407( 2 ); /* <:fix:fix */
  twobit_load( 2, 4 );
  twobit_check( 0, 2, 0, 1445, compiled_block_1_1445 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1446, compiled_block_1_1446 );
  twobit_invoke( 2 );
  twobit_label( 1446, compiled_block_1_1446 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1443, compiled_block_1_1443 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1447, compiled_block_1_1447 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1443,compiled_block_1_1443); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 268, compiled_temp_1_268 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 16 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1448, compiled_block_1_1448 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1449, compiled_block_1_1449 );
  twobit_invoke( 2 );
  twobit_label( 1449, compiled_block_1_1449 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1443, compiled_block_1_1443 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1447, compiled_block_1_1447 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1443,compiled_block_1_1443); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 269, compiled_temp_1_269 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 15 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1450, compiled_block_1_1450 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1451, compiled_block_1_1451 );
  twobit_invoke( 2 );
  twobit_label( 1451, compiled_block_1_1451 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1443, compiled_block_1_1443 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1447, compiled_block_1_1447 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1443,compiled_block_1_1443); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 270, compiled_temp_1_270 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 14 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1452, compiled_block_1_1452 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1453, compiled_block_1_1453 );
  twobit_invoke( 2 );
  twobit_label( 1453, compiled_block_1_1453 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1443, compiled_block_1_1443 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1447, compiled_block_1_1447 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1443,compiled_block_1_1443); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 271, compiled_temp_1_271 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 13 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1454, compiled_block_1_1454 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1455, compiled_block_1_1455 );
  twobit_invoke( 2 );
  twobit_label( 1455, compiled_block_1_1455 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1443, compiled_block_1_1443 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1447, compiled_block_1_1447 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1443,compiled_block_1_1443); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 272, compiled_temp_1_272 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1456, compiled_block_1_1456 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(6) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1457, compiled_block_1_1457 );
  twobit_invoke( 2 );
  twobit_label( 1457, compiled_block_1_1457 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1443, compiled_block_1_1443 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1447, compiled_block_1_1447 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1443,compiled_block_1_1443); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 273, compiled_temp_1_273 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1458, compiled_block_1_1458 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(7) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1459, compiled_block_1_1459 );
  twobit_invoke( 2 );
  twobit_label( 1459, compiled_block_1_1459 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1443, compiled_block_1_1443 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1447, compiled_block_1_1447 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1443,compiled_block_1_1443); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 274, compiled_temp_1_274 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1460, compiled_block_1_1460 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(8) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1461, compiled_block_1_1461 );
  twobit_invoke( 2 );
  twobit_label( 1461, compiled_block_1_1461 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1443, compiled_block_1_1443 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1447, compiled_block_1_1447 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1443,compiled_block_1_1443); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 275, compiled_temp_1_275 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 1, 4 );
  twobit_check( 0, 1, 0, 1462, compiled_block_1_1462 );
  twobit_stack( 4 );
  twobit_op2imm_450( fixnum(9) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_load( 1, 5 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1463, compiled_block_1_1463 );
  twobit_invoke( 2 );
  twobit_label( 1463, compiled_block_1_1463 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1443, compiled_block_1_1443 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 4, 3, 0, 1447, compiled_block_1_1447 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1443,compiled_block_1_1443); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 276, compiled_temp_1_276 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_lexical( 0, 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 4 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 3, 1, 0, 1464, compiled_block_1_1464 );
  twobit_load( 3, 3 );
  twobit_lexical( 0, 1 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 4 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 2, 3, 0, 1465, compiled_block_1_1465 );
  twobit_lexical( 0, 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_load( 1, 4 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 3, 1, 0, 1464, compiled_block_1_1464 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 3, 7 );
  twobit_lexical( 0, 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 1 );
  twobit_load( 6, 3 );
  twobit_load( 5, 4 );
  twobit_load( 4, 5 );
  twobit_load( 3, 6 );
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_277, 4, 6 );
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_reg( 1 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1472, compiled_block_1_1472 );
  twobit_invoke( 2 );
  twobit_label( 1472, compiled_block_1_1472 );
  twobit_load( 0, 0 );
  twobit_load( 3, 7 );
  twobit_op2_61( 3, 278, compiled_temp_1_278 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_61( 4, 279, compiled_temp_1_279 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_61( 4, 280, compiled_temp_1_280 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_61( 4, 281, compiled_temp_1_281 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_61( 4, 282, compiled_temp_1_282 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_61( 4, 283, compiled_temp_1_283 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 13 );
  twobit_op2_61( 4, 284, compiled_temp_1_284 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 14 );
  twobit_op2_61( 4, 285, compiled_temp_1_285 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 15 );
  twobit_op2_61( 4, 286, compiled_temp_1_286 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 16 );
  twobit_op2_61( 4, 287, compiled_temp_1_287 ); /* + */
  twobit_setreg( 4 );
  twobit_stack( 17 );
  twobit_op2_61( 4, 288, compiled_temp_1_288 ); /* + */
  twobit_pop( 17 );
  twobit_return();
  twobit_label( 1448, compiled_block_1_1448 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1454, compiled_block_1_1454 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1460, compiled_block_1_1460 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1445, compiled_block_1_1445 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1444, compiled_block_1_1444 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1464, compiled_block_1_1464 );
  twobit_trap( 1, 3, 0, 160 );
  twobit_label( 1441, compiled_block_1_1441 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1450, compiled_block_1_1450 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1456, compiled_block_1_1456 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1462, compiled_block_1_1462 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1447, compiled_block_1_1447 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_label( 1465, compiled_block_1_1465 );
  twobit_trap( 3, 2, 0, 160 );
  twobit_label( 1452, compiled_block_1_1452 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 1443, compiled_block_1_1443 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_label( 1458, compiled_block_1_1458 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_277( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op2imm_branchf_635( fixnum(10), 289, compiled_temp_1_289, 1467, compiled_block_1_1467 ); /* internal:branchf-</imm */
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1467, compiled_block_1_1467 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_reg( 2 );
  twobit_op2imm_131( fixnum(1), 290, compiled_temp_1_290 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 2 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 2, 31, 0, 1468, compiled_block_1_1468 );
  twobit_lexical( 0, 6 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 2, 31, 0, 1468, compiled_block_1_1468 );
  twobit_reg( 2 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 2, 31, 0, 1468, compiled_block_1_1468 );
  twobit_lexical( 0, 5 );
  twobit_op2_402( 2 ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1469, compiled_block_1_1469 );
  twobit_invoke( 2 );
  twobit_label( 1469, compiled_block_1_1469 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 0, 1470, compiled_block_1_1470 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 0, 1470, compiled_block_1_1470 );
  twobit_reg( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 0, 1470, compiled_block_1_1470 );
  twobit_lexical( 0, 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_63( 4, 291, compiled_temp_1_291 ); /* * */
  twobit_load( 3, 3 );
  twobit_op2_61( 3, 292, compiled_temp_1_292 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1468, compiled_block_1_1468 );
  twobit_trap( 31, 2, 0, 160 );
  twobit_label( 1470, compiled_block_1_1470 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_42( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_reg_op2_check_662(reg(2),reg(4),1474,compiled_block_1_1474); /* internal:check-vector?/vector-length:vec with (0 2 0) */
  twobit_store( 4, 1 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_reg_op2_check_655(RESULT,reg(4),1474,compiled_block_1_1474); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(8) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_reg_op2_check_655(RESULT,reg(4),1475,compiled_block_1_1475); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(7) ); /* vector-ref:trusted */
  twobit_setreg( 31 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_reg_op2_check_655(RESULT,reg(4),1476,compiled_block_1_1476); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(6) ); /* vector-ref:trusted */
  twobit_setreg( 30 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_reg_op2_check_655(RESULT,reg(4),1477,compiled_block_1_1477); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_setreg( 29 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_reg_op2_check_655(RESULT,reg(4),1478,compiled_block_1_1478); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_setreg( 28 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(4),1479,compiled_block_1_1479); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 4, 1 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(4),1480,compiled_block_1_1480); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 1, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1481,compiled_block_1_1481); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(4),1482,compiled_block_1_1482); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_load( 4, 3 );
  twobit_movereg( 28, 5 );
  twobit_movereg( 29, 6 );
  twobit_movereg( 30, 7 );
  twobit_movereg( 31, 8 );
  twobit_load( 9, 4 );
  twobit_stack( 2 );
  twobit_pop( 4 );
  twobit_invoke( 9 );
  twobit_label( 1479, compiled_block_1_1479 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1476, compiled_block_1_1476 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1482, compiled_block_1_1482 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1478, compiled_block_1_1478 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1475, compiled_block_1_1475 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1480, compiled_block_1_1480 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1477, compiled_block_1_1477 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1474, compiled_block_1_1474 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1481, compiled_block_1_1481 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_43( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_reg_op2_check_662(reg(2),reg(4),1484,compiled_block_1_1484); /* internal:check-vector?/vector-length:vec with (0 2 0) */
  twobit_store( 4, 1 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_reg_op2_check_655(RESULT,reg(4),1484,compiled_block_1_1484); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(7) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_reg_op2_check_655(RESULT,reg(4),1485,compiled_block_1_1485); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(6) ); /* vector-ref:trusted */
  twobit_setreg( 31 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_reg_op2_check_655(RESULT,reg(4),1486,compiled_block_1_1486); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_setreg( 30 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_reg_op2_check_655(RESULT,reg(4),1487,compiled_block_1_1487); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_setreg( 29 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(4),1488,compiled_block_1_1488); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 4, 1 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(4),1489,compiled_block_1_1489); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 1, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1490,compiled_block_1_1490); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(4),1491,compiled_block_1_1491); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_load( 4, 3 );
  twobit_movereg( 29, 5 );
  twobit_movereg( 30, 6 );
  twobit_movereg( 31, 7 );
  twobit_load( 8, 4 );
  twobit_stack( 2 );
  twobit_pop( 4 );
  twobit_invoke( 8 );
  twobit_label( 1488, compiled_block_1_1488 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1485, compiled_block_1_1485 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1491, compiled_block_1_1491 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1487, compiled_block_1_1487 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1484, compiled_block_1_1484 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1489, compiled_block_1_1489 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1486, compiled_block_1_1486 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1490, compiled_block_1_1490 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_44( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_reg_op2_check_662(reg(2),reg(4),1493,compiled_block_1_1493); /* internal:check-vector?/vector-length:vec with (0 2 0) */
  twobit_store( 4, 1 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_reg_op2_check_655(RESULT,reg(4),1493,compiled_block_1_1493); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(6) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_reg_op2_check_655(RESULT,reg(4),1494,compiled_block_1_1494); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_setreg( 31 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_reg_op2_check_655(RESULT,reg(4),1495,compiled_block_1_1495); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_setreg( 30 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(4),1496,compiled_block_1_1496); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 4, 1 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(4),1497,compiled_block_1_1497); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 1, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1498,compiled_block_1_1498); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(4),1499,compiled_block_1_1499); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_load( 4, 3 );
  twobit_movereg( 30, 5 );
  twobit_movereg( 31, 6 );
  twobit_load( 7, 4 );
  twobit_stack( 2 );
  twobit_pop( 4 );
  twobit_invoke( 7 );
  twobit_label( 1496, compiled_block_1_1496 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1493, compiled_block_1_1493 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1499, compiled_block_1_1499 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1495, compiled_block_1_1495 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1497, compiled_block_1_1497 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1494, compiled_block_1_1494 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1498, compiled_block_1_1498 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_45( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_reg_op2_check_662(reg(2),reg(4),1501,compiled_block_1_1501); /* internal:check-vector?/vector-length:vec with (0 2 0) */
  twobit_store( 4, 1 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_reg_op2_check_655(RESULT,reg(4),1501,compiled_block_1_1501); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_reg_op2_check_655(RESULT,reg(4),1502,compiled_block_1_1502); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_setreg( 31 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(4),1503,compiled_block_1_1503); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 4, 1 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(4),1504,compiled_block_1_1504); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 1, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1505,compiled_block_1_1505); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(4),1506,compiled_block_1_1506); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_load( 4, 3 );
  twobit_movereg( 31, 5 );
  twobit_load( 6, 4 );
  twobit_stack( 2 );
  twobit_pop( 4 );
  twobit_invoke( 6 );
  twobit_label( 1503, compiled_block_1_1503 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1506, compiled_block_1_1506 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1502, compiled_block_1_1502 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1504, compiled_block_1_1504 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1501, compiled_block_1_1501 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1505, compiled_block_1_1505 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_46( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_reg_op2_check_662(reg(2),reg(4),1508,compiled_block_1_1508); /* internal:check-vector?/vector-length:vec with (0 2 0) */
  twobit_store( 4, 1 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_reg_op2_check_655(RESULT,reg(4),1508,compiled_block_1_1508); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(4),1509,compiled_block_1_1509); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 4, 1 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(4),1510,compiled_block_1_1510); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 1, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1511,compiled_block_1_1511); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(4),1512,compiled_block_1_1512); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_load( 4, 3 );
  twobit_load( 5, 4 );
  twobit_stack( 2 );
  twobit_pop( 4 );
  twobit_invoke( 5 );
  twobit_label( 1509, compiled_block_1_1509 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1512, compiled_block_1_1512 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1508, compiled_block_1_1508 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1510, compiled_block_1_1510 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1511, compiled_block_1_1511 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_47( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_reg_op2_check_662(reg(2),reg(4),1514,compiled_block_1_1514); /* internal:check-vector?/vector-length:vec with (0 2 0) */
  twobit_store( 4, 1 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(4),1514,compiled_block_1_1514); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 3, 1 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(3),1515,compiled_block_1_1515); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 1, 2 );
  twobit_load( 4, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1516,compiled_block_1_1516); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(4),1517,compiled_block_1_1517); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_load( 4, 3 );
  twobit_stack( 2 );
  twobit_pop( 3 );
  twobit_invoke( 4 );
  twobit_label( 1514, compiled_block_1_1514 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1517, compiled_block_1_1517 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1515, compiled_block_1_1515 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1516, compiled_block_1_1516 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_48( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg_op2_check_662(reg(2),reg(4),1519,compiled_block_1_1519); /* internal:check-vector?/vector-length:vec with (0 2 0) */
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(4),1519,compiled_block_1_1519); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1520,compiled_block_1_1520); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(4),1521,compiled_block_1_1521); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_label( 1521, compiled_block_1_1521 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1519, compiled_block_1_1519 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1520, compiled_block_1_1520 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_49( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 1, 4 );
  twobit_reg_op2_check_662(reg(2),reg(3),1523,compiled_block_1_1523); /* internal:check-vector?/vector-length:vec with (0 2 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(3),1523,compiled_block_1_1523); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(3),1524,compiled_block_1_1524); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 1524, compiled_block_1_1524 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1523, compiled_block_1_1523 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_50( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 1, 4 );
  twobit_reg_op2_check_662(reg(2),reg(3),1526,compiled_block_1_1526); /* internal:check-vector?/vector-length:vec with (0 2 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(3),1526,compiled_block_1_1526); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 1526, compiled_block_1_1526 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_51( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 1, 4 );
  twobit_reg( 4 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_52( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lambda( compiled_start_1_258, 2, 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_258( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(10), 259, compiled_temp_1_259, 1531, compiled_block_1_1531 ); /* internal:branchf-</imm */
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1532, compiled_block_1_1532 );
  twobit_lexical( 1, 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1532, compiled_block_1_1532 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1532, compiled_block_1_1532 );
  twobit_lexical( 1, 1 );
  twobit_op2_402( 1 ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1531, compiled_block_1_1531 );
  twobit_label( 1529, compiled_block_1_1529 );
  twobit_lambda( compiled_start_1_260, 2, 1 );
  twobit_return();
  twobit_label( 1532, compiled_block_1_1532 );
  twobit_trap( 3, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_260( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 12 );
  twobit_store( 0, 0 );
  twobit_store( 1, 11 );
  twobit_reg_op2_check_662(reg(2),reg(4),1534,compiled_block_1_1534); /* internal:check-vector?/vector-length:vec with (0 2 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1534,compiled_block_1_1534); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 3, 10 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(4),1535,compiled_block_1_1535); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 31 );
  twobit_store( 31, 9 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(4),1536,compiled_block_1_1536); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 30 );
  twobit_store( 30, 8 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(4),1537,compiled_block_1_1537); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 29 );
  twobit_store( 29, 7 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_reg_op2_check_655(RESULT,reg(4),1538,compiled_block_1_1538); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_setreg( 28 );
  twobit_store( 28, 6 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_reg_op2_check_655(RESULT,reg(4),1539,compiled_block_1_1539); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_setreg( 27 );
  twobit_store( 27, 5 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_reg_op2_check_655(RESULT,reg(4),1540,compiled_block_1_1540); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(6) ); /* vector-ref:trusted */
  twobit_setreg( 26 );
  twobit_store( 26, 4 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_reg_op2_check_655(RESULT,reg(4),1541,compiled_block_1_1541); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(7) ); /* vector-ref:trusted */
  twobit_setreg( 25 );
  twobit_store( 25, 3 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_reg_op2_check_655(RESULT,reg(4),1542,compiled_block_1_1542); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(8) ); /* vector-ref:trusted */
  twobit_setreg( 24 );
  twobit_store( 24, 2 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_reg_op2_check_655(RESULT,reg(4),1543,compiled_block_1_1543); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_reg( 2 );
  twobit_op2imm_450( fixnum(9) ); /* vector-ref:trusted */
  twobit_setreg( 23 );
  twobit_store( 23, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 22 );
  twobit_movereg( 4, 3 );
  twobit_movereg( 22, 1 );
  twobit_lambda( compiled_start_1_261, 3, 3 );
  twobit_setreg( 4 );
  twobit_reg( 22 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 22 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_setrtn( 1548, compiled_block_1_1548 );
  twobit_invoke( 2 );
  twobit_label( 1548, compiled_block_1_1548 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_stack( 1 );
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_stack( 2 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 1 );
  twobit_stack( 4 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_stack( 5 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_stack( 6 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_stack( 7 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 4, 8 );
  twobit_load( 3, 9 );
  twobit_load( 2, 10 );
  twobit_movereg( 1, 9 );
  twobit_load( 1, 11 );
  twobit_load( 5, 7 );
  twobit_load( 6, 6 );
  twobit_load( 7, 5 );
  twobit_load( 8, 4 );
  twobit_load( 10, 2 );
  twobit_load( 11, 1 );
  twobit_load( 12, 12 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 12 );
  twobit_invoke( 12 );
  twobit_label( 1537, compiled_block_1_1537 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1540, compiled_block_1_1540 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1543, compiled_block_1_1543 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1535, compiled_block_1_1535 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1538, compiled_block_1_1538 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1541, compiled_block_1_1541 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1536, compiled_block_1_1536 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1539, compiled_block_1_1539 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1542, compiled_block_1_1542 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1534, compiled_block_1_1534 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_261( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_639( fixnum(10), 262, compiled_temp_1_262, 1545, compiled_block_1_1545 ); /* internal:branchf-=/imm */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1545, compiled_block_1_1545 );
  twobit_reg( 1 );
  twobit_op2imm_131( fixnum(1), 263, compiled_temp_1_263 ); /* - */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 0, 1546, compiled_block_1_1546 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 0, 1546, compiled_block_1_1546 );
  twobit_reg( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 0, 1546, compiled_block_1_1546 );
  twobit_lexical( 0, 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_movereg( 4, 1 );
  twobit_reg( 3 );
  twobit_invoke( 2 );
  twobit_label( 1546, compiled_block_1_1546 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_53( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 10 );
  twobit_store( 0, 0 );
  twobit_store( 1, 9 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1551, compiled_block_1_1551 );
  twobit_invoke( 2 );
  twobit_label( 1551, compiled_block_1_1551 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1552, compiled_block_1_1552 );
  twobit_invoke( 2 );
  twobit_label( 1552, compiled_block_1_1552 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1553, compiled_block_1_1553 );
  twobit_invoke( 2 );
  twobit_label( 1553, compiled_block_1_1553 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1554, compiled_block_1_1554 );
  twobit_invoke( 2 );
  twobit_label( 1554, compiled_block_1_1554 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1555, compiled_block_1_1555 );
  twobit_invoke( 2 );
  twobit_label( 1555, compiled_block_1_1555 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1556, compiled_block_1_1556 );
  twobit_invoke( 2 );
  twobit_label( 1556, compiled_block_1_1556 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1557, compiled_block_1_1557 );
  twobit_invoke( 2 );
  twobit_label( 1557, compiled_block_1_1557 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1558, compiled_block_1_1558 );
  twobit_invoke( 2 );
  twobit_label( 1558, compiled_block_1_1558 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1559, compiled_block_1_1559 );
  twobit_invoke( 2 );
  twobit_label( 1559, compiled_block_1_1559 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 2, 2 );
  twobit_load( 3, 3 );
  twobit_load( 4, 4 );
  twobit_store( 4, 3 );
  twobit_stack( 5 );
  twobit_setreg( 1 );
  twobit_store( 1, 5 );
  twobit_stack( 6 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_stack( 7 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_stack( 8 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_stack( 9 );
  twobit_setreg( 4 );
  twobit_load( 1, 10 );
  twobit_movereg( 4, 10 );
  twobit_load( 4, 3 );
  twobit_load( 5, 5 );
  twobit_load( 6, 6 );
  twobit_load( 7, 7 );
  twobit_load( 8, 8 );
  twobit_load( 9, 1 );
  twobit_reg( 10 );
  twobit_pop( 10 );
  twobit_invoke( 9 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_54( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 9 );
  twobit_store( 0, 0 );
  twobit_store( 1, 8 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1561, compiled_block_1_1561 );
  twobit_invoke( 2 );
  twobit_label( 1561, compiled_block_1_1561 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1562, compiled_block_1_1562 );
  twobit_invoke( 2 );
  twobit_label( 1562, compiled_block_1_1562 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1563, compiled_block_1_1563 );
  twobit_invoke( 2 );
  twobit_label( 1563, compiled_block_1_1563 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1564, compiled_block_1_1564 );
  twobit_invoke( 2 );
  twobit_label( 1564, compiled_block_1_1564 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1565, compiled_block_1_1565 );
  twobit_invoke( 2 );
  twobit_label( 1565, compiled_block_1_1565 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1566, compiled_block_1_1566 );
  twobit_invoke( 2 );
  twobit_label( 1566, compiled_block_1_1566 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1567, compiled_block_1_1567 );
  twobit_invoke( 2 );
  twobit_label( 1567, compiled_block_1_1567 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1568, compiled_block_1_1568 );
  twobit_invoke( 2 );
  twobit_label( 1568, compiled_block_1_1568 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 2, 2 );
  twobit_load( 3, 3 );
  twobit_load( 4, 4 );
  twobit_store( 4, 3 );
  twobit_stack( 5 );
  twobit_setreg( 1 );
  twobit_store( 1, 5 );
  twobit_stack( 6 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_stack( 7 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_stack( 8 );
  twobit_setreg( 4 );
  twobit_load( 1, 9 );
  twobit_movereg( 4, 9 );
  twobit_load( 4, 3 );
  twobit_load( 5, 5 );
  twobit_load( 6, 6 );
  twobit_load( 7, 7 );
  twobit_load( 8, 1 );
  twobit_reg( 9 );
  twobit_pop( 9 );
  twobit_invoke( 8 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_55( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 7 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1570, compiled_block_1_1570 );
  twobit_invoke( 2 );
  twobit_label( 1570, compiled_block_1_1570 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1571, compiled_block_1_1571 );
  twobit_invoke( 2 );
  twobit_label( 1571, compiled_block_1_1571 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1572, compiled_block_1_1572 );
  twobit_invoke( 2 );
  twobit_label( 1572, compiled_block_1_1572 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1573, compiled_block_1_1573 );
  twobit_invoke( 2 );
  twobit_label( 1573, compiled_block_1_1573 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1574, compiled_block_1_1574 );
  twobit_invoke( 2 );
  twobit_label( 1574, compiled_block_1_1574 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1575, compiled_block_1_1575 );
  twobit_invoke( 2 );
  twobit_label( 1575, compiled_block_1_1575 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1576, compiled_block_1_1576 );
  twobit_invoke( 2 );
  twobit_label( 1576, compiled_block_1_1576 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 2, 2 );
  twobit_load( 3, 3 );
  twobit_load( 4, 4 );
  twobit_store( 4, 3 );
  twobit_stack( 5 );
  twobit_setreg( 1 );
  twobit_store( 1, 5 );
  twobit_stack( 6 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_stack( 7 );
  twobit_setreg( 4 );
  twobit_load( 1, 8 );
  twobit_movereg( 4, 8 );
  twobit_load( 4, 3 );
  twobit_load( 5, 5 );
  twobit_load( 6, 6 );
  twobit_load( 7, 1 );
  twobit_reg( 8 );
  twobit_pop( 8 );
  twobit_invoke( 7 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_56( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1578, compiled_block_1_1578 );
  twobit_invoke( 2 );
  twobit_label( 1578, compiled_block_1_1578 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1579, compiled_block_1_1579 );
  twobit_invoke( 2 );
  twobit_label( 1579, compiled_block_1_1579 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1580, compiled_block_1_1580 );
  twobit_invoke( 2 );
  twobit_label( 1580, compiled_block_1_1580 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1581, compiled_block_1_1581 );
  twobit_invoke( 2 );
  twobit_label( 1581, compiled_block_1_1581 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1582, compiled_block_1_1582 );
  twobit_invoke( 2 );
  twobit_label( 1582, compiled_block_1_1582 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1583, compiled_block_1_1583 );
  twobit_invoke( 2 );
  twobit_label( 1583, compiled_block_1_1583 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 2, 2 );
  twobit_load( 3, 3 );
  twobit_load( 4, 4 );
  twobit_store( 4, 3 );
  twobit_stack( 5 );
  twobit_setreg( 1 );
  twobit_store( 1, 5 );
  twobit_stack( 6 );
  twobit_setreg( 4 );
  twobit_load( 1, 7 );
  twobit_movereg( 4, 7 );
  twobit_load( 4, 3 );
  twobit_load( 5, 5 );
  twobit_load( 6, 1 );
  twobit_reg( 7 );
  twobit_pop( 7 );
  twobit_invoke( 6 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_57( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 5 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1585, compiled_block_1_1585 );
  twobit_invoke( 2 );
  twobit_label( 1585, compiled_block_1_1585 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1586, compiled_block_1_1586 );
  twobit_invoke( 2 );
  twobit_label( 1586, compiled_block_1_1586 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1587, compiled_block_1_1587 );
  twobit_invoke( 2 );
  twobit_label( 1587, compiled_block_1_1587 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1588, compiled_block_1_1588 );
  twobit_invoke( 2 );
  twobit_label( 1588, compiled_block_1_1588 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1589, compiled_block_1_1589 );
  twobit_invoke( 2 );
  twobit_label( 1589, compiled_block_1_1589 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 2, 2 );
  twobit_load( 3, 3 );
  twobit_load( 4, 4 );
  twobit_stack( 5 );
  twobit_setreg( 1 );
  twobit_store( 1, 5 );
  twobit_load( 1, 6 );
  twobit_load( 5, 1 );
  twobit_stack( 5 );
  twobit_pop( 6 );
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_58( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1591, compiled_block_1_1591 );
  twobit_invoke( 2 );
  twobit_label( 1591, compiled_block_1_1591 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1592, compiled_block_1_1592 );
  twobit_invoke( 2 );
  twobit_label( 1592, compiled_block_1_1592 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1593, compiled_block_1_1593 );
  twobit_invoke( 2 );
  twobit_label( 1593, compiled_block_1_1593 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1594, compiled_block_1_1594 );
  twobit_invoke( 2 );
  twobit_label( 1594, compiled_block_1_1594 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_load( 3, 3 );
  twobit_stack( 4 );
  twobit_setreg( 1 );
  twobit_store( 1, 4 );
  twobit_load( 1, 5 );
  twobit_stack( 4 );
  twobit_pop( 5 );
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_59( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1596, compiled_block_1_1596 );
  twobit_invoke( 2 );
  twobit_label( 1596, compiled_block_1_1596 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1597, compiled_block_1_1597 );
  twobit_invoke( 2 );
  twobit_label( 1597, compiled_block_1_1597 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1598, compiled_block_1_1598 );
  twobit_invoke( 2 );
  twobit_label( 1598, compiled_block_1_1598 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_60( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1600, compiled_block_1_1600 );
  twobit_invoke( 2 );
  twobit_label( 1600, compiled_block_1_1600 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1601, compiled_block_1_1601 );
  twobit_invoke( 2 );
  twobit_label( 1601, compiled_block_1_1601 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_61( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1603, compiled_block_1_1603 );
  twobit_invoke( 2 );
  twobit_label( 1603, compiled_block_1_1603 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_setreg( 3 );
  twobit_movereg( 4, 1 );
  twobit_reg( 3 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_62( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 1, 4 );
  twobit_reg( 4 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_63( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lambda( compiled_start_1_252, 2, 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_252( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(10), 253, compiled_temp_1_253, 1608, compiled_block_1_1608 ); /* internal:branchf-</imm */
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1609, compiled_block_1_1609 );
  twobit_lexical( 1, 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1609, compiled_block_1_1609 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1609, compiled_block_1_1609 );
  twobit_lexical( 1, 1 );
  twobit_op2_402( 1 ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1608, compiled_block_1_1608 );
  twobit_label( 1606, compiled_block_1_1606 );
  twobit_lambda( compiled_start_1_254, 2, 1 );
  twobit_return();
  twobit_label( 1609, compiled_block_1_1609 );
  twobit_trap( 3, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_254( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 12 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1611, compiled_block_1_1611 );
  twobit_invoke( 2 );
  twobit_label( 1611, compiled_block_1_1611 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1612, compiled_block_1_1612 );
  twobit_invoke( 2 );
  twobit_label( 1612, compiled_block_1_1612 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1613, compiled_block_1_1613 );
  twobit_invoke( 2 );
  twobit_label( 1613, compiled_block_1_1613 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1614, compiled_block_1_1614 );
  twobit_invoke( 2 );
  twobit_label( 1614, compiled_block_1_1614 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1615, compiled_block_1_1615 );
  twobit_invoke( 2 );
  twobit_label( 1615, compiled_block_1_1615 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1616, compiled_block_1_1616 );
  twobit_invoke( 2 );
  twobit_label( 1616, compiled_block_1_1616 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1617, compiled_block_1_1617 );
  twobit_invoke( 2 );
  twobit_label( 1617, compiled_block_1_1617 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1618, compiled_block_1_1618 );
  twobit_invoke( 2 );
  twobit_label( 1618, compiled_block_1_1618 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1619, compiled_block_1_1619 );
  twobit_invoke( 2 );
  twobit_label( 1619, compiled_block_1_1619 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1620, compiled_block_1_1620 );
  twobit_invoke( 2 );
  twobit_label( 1620, compiled_block_1_1620 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_255, 4, 2 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_setrtn( 1625, compiled_block_1_1625 );
  twobit_invoke( 2 );
  twobit_label( 1625, compiled_block_1_1625 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_stack( 2 );
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_stack( 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_stack( 4 );
  twobit_setreg( 1 );
  twobit_store( 1, 4 );
  twobit_stack( 5 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_stack( 6 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_stack( 7 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_stack( 8 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_load( 4, 9 );
  twobit_load( 3, 10 );
  twobit_load( 2, 11 );
  twobit_load( 1, 1 );
  twobit_load( 5, 8 );
  twobit_load( 6, 7 );
  twobit_load( 7, 6 );
  twobit_load( 8, 5 );
  twobit_load( 9, 4 );
  twobit_load( 10, 3 );
  twobit_load( 11, 2 );
  twobit_load( 12, 12 );
  twobit_global( 5 ); /* apply */
  twobit_pop( 12 );
  twobit_invoke( 12 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_255( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_639( fixnum(10), 256, compiled_temp_1_256, 1622, compiled_block_1_1622 ); /* internal:branchf-=/imm */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1622, compiled_block_1_1622 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_reg( 1 );
  twobit_op2imm_131( fixnum(1), 257, compiled_temp_1_257 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  array-ref~1ayXVW~11576 */
  twobit_setrtn( 1623, compiled_block_1_1623 );
  twobit_invoke( 2 );
  twobit_label( 1623, compiled_block_1_1623 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_64( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 13 );
  twobit_store( 0, 0 );
  twobit_store( 1, 11 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1628, compiled_block_1_1628 );
  twobit_invoke( 2 );
  twobit_label( 1628, compiled_block_1_1628 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1629, compiled_block_1_1629 );
  twobit_stack( 2 );
  twobit_reg_op1_check_653(RESULT,1629,compiled_block_1_1629); /* internal:check-vector? with (4 3 0) */
  twobit_stack( 2 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1630, compiled_block_1_1630 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1630,compiled_block_1_1630); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1631, compiled_block_1_1631 );
  twobit_invoke( 2 );
  twobit_label( 1631, compiled_block_1_1631 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1629, compiled_block_1_1629 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1630, compiled_block_1_1630 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1630,compiled_block_1_1630); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1632, compiled_block_1_1632 );
  twobit_invoke( 2 );
  twobit_label( 1632, compiled_block_1_1632 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1629, compiled_block_1_1629 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1630, compiled_block_1_1630 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1630,compiled_block_1_1630); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1633, compiled_block_1_1633 );
  twobit_invoke( 2 );
  twobit_label( 1633, compiled_block_1_1633 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1629, compiled_block_1_1629 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1630, compiled_block_1_1630 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1630,compiled_block_1_1630); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1634, compiled_block_1_1634 );
  twobit_invoke( 2 );
  twobit_label( 1634, compiled_block_1_1634 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1629, compiled_block_1_1629 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1630, compiled_block_1_1630 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1630,compiled_block_1_1630); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1635, compiled_block_1_1635 );
  twobit_invoke( 2 );
  twobit_label( 1635, compiled_block_1_1635 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1629, compiled_block_1_1629 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1630, compiled_block_1_1630 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1630,compiled_block_1_1630); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1636, compiled_block_1_1636 );
  twobit_invoke( 2 );
  twobit_label( 1636, compiled_block_1_1636 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1629, compiled_block_1_1629 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1630, compiled_block_1_1630 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1630,compiled_block_1_1630); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1637, compiled_block_1_1637 );
  twobit_invoke( 2 );
  twobit_label( 1637, compiled_block_1_1637 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1629, compiled_block_1_1629 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1630, compiled_block_1_1630 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1630,compiled_block_1_1630); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1638, compiled_block_1_1638 );
  twobit_invoke( 2 );
  twobit_label( 1638, compiled_block_1_1638 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_stack( 1 );
  twobit_setreg( 3 );
  twobit_store( 3, 13 );
  twobit_stack( 4 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_stack( 5 );
  twobit_setreg( 1 );
  twobit_store( 1, 4 );
  twobit_stack( 6 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 4, 7 );
  twobit_store( 4, 6 );
  twobit_load( 2, 8 );
  twobit_stack( 9 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 4, 2 );
  twobit_load( 3, 9 );
  twobit_check( 3, 4, 0, 1639, compiled_block_1_1639 );
  twobit_load( 4, 3 );
  twobit_stack( 9 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_load( 4, 2 );
  twobit_check( 3, 4, 0, 1639, compiled_block_1_1639 );
  twobit_stack( 9 );
  twobit_reg_op2imm_check_660(RESULT,fixnum(0),1639,compiled_block_1_1639); /* internal:check->=:fix:fix/imm with (3 4 0) */
  twobit_load( 4, 9 );
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_load( 3, 10 );
  twobit_stack( 11 );
  twobit_setreg( 4 );
  twobit_load( 1, 12 );
  twobit_movereg( 4, 10 );
  twobit_load( 4, 6 );
  twobit_load( 5, 5 );
  twobit_load( 6, 4 );
  twobit_load( 7, 1 );
  twobit_load( 8, 13 );
  twobit_load( 9, 9 );
  twobit_reg( 10 );
  twobit_pop( 13 );
  twobit_invoke( 9 );
  twobit_label( 1630, compiled_block_1_1630 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1639, compiled_block_1_1639 );
  twobit_trap( 4, 3, 0, 160 );
  twobit_label( 1629, compiled_block_1_1629 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_65( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 12 );
  twobit_store( 0, 0 );
  twobit_store( 1, 10 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1641, compiled_block_1_1641 );
  twobit_invoke( 2 );
  twobit_label( 1641, compiled_block_1_1641 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1642, compiled_block_1_1642 );
  twobit_stack( 2 );
  twobit_reg_op1_check_653(RESULT,1642,compiled_block_1_1642); /* internal:check-vector? with (4 3 0) */
  twobit_stack( 2 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1643, compiled_block_1_1643 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1643,compiled_block_1_1643); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1644, compiled_block_1_1644 );
  twobit_invoke( 2 );
  twobit_label( 1644, compiled_block_1_1644 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1642, compiled_block_1_1642 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1643, compiled_block_1_1643 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1643,compiled_block_1_1643); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1645, compiled_block_1_1645 );
  twobit_invoke( 2 );
  twobit_label( 1645, compiled_block_1_1645 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1642, compiled_block_1_1642 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1643, compiled_block_1_1643 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1643,compiled_block_1_1643); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1646, compiled_block_1_1646 );
  twobit_invoke( 2 );
  twobit_label( 1646, compiled_block_1_1646 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1642, compiled_block_1_1642 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1643, compiled_block_1_1643 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1643,compiled_block_1_1643); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1647, compiled_block_1_1647 );
  twobit_invoke( 2 );
  twobit_label( 1647, compiled_block_1_1647 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1642, compiled_block_1_1642 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1643, compiled_block_1_1643 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1643,compiled_block_1_1643); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1648, compiled_block_1_1648 );
  twobit_invoke( 2 );
  twobit_label( 1648, compiled_block_1_1648 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1642, compiled_block_1_1642 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1643, compiled_block_1_1643 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1643,compiled_block_1_1643); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1649, compiled_block_1_1649 );
  twobit_invoke( 2 );
  twobit_label( 1649, compiled_block_1_1649 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1642, compiled_block_1_1642 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1643, compiled_block_1_1643 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1643,compiled_block_1_1643); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1650, compiled_block_1_1650 );
  twobit_invoke( 2 );
  twobit_label( 1650, compiled_block_1_1650 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_stack( 1 );
  twobit_setreg( 3 );
  twobit_store( 3, 12 );
  twobit_stack( 4 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_stack( 5 );
  twobit_setreg( 1 );
  twobit_store( 1, 4 );
  twobit_load( 4, 6 );
  twobit_store( 4, 5 );
  twobit_load( 2, 7 );
  twobit_stack( 8 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 4, 2 );
  twobit_load( 3, 8 );
  twobit_check( 3, 4, 0, 1651, compiled_block_1_1651 );
  twobit_load( 4, 3 );
  twobit_stack( 8 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_load( 4, 2 );
  twobit_check( 3, 4, 0, 1651, compiled_block_1_1651 );
  twobit_stack( 8 );
  twobit_reg_op2imm_check_660(RESULT,fixnum(0),1651,compiled_block_1_1651); /* internal:check->=:fix:fix/imm with (3 4 0) */
  twobit_load( 4, 8 );
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_load( 3, 9 );
  twobit_stack( 10 );
  twobit_setreg( 4 );
  twobit_load( 1, 11 );
  twobit_movereg( 4, 9 );
  twobit_load( 4, 5 );
  twobit_load( 5, 4 );
  twobit_load( 6, 1 );
  twobit_load( 7, 12 );
  twobit_load( 8, 8 );
  twobit_reg( 9 );
  twobit_pop( 12 );
  twobit_invoke( 8 );
  twobit_label( 1643, compiled_block_1_1643 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1651, compiled_block_1_1651 );
  twobit_trap( 4, 3, 0, 160 );
  twobit_label( 1642, compiled_block_1_1642 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_66( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 11 );
  twobit_store( 0, 0 );
  twobit_store( 1, 9 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1653, compiled_block_1_1653 );
  twobit_invoke( 2 );
  twobit_label( 1653, compiled_block_1_1653 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1654, compiled_block_1_1654 );
  twobit_stack( 2 );
  twobit_reg_op1_check_653(RESULT,1654,compiled_block_1_1654); /* internal:check-vector? with (4 3 0) */
  twobit_stack( 2 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1655, compiled_block_1_1655 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1655,compiled_block_1_1655); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1656, compiled_block_1_1656 );
  twobit_invoke( 2 );
  twobit_label( 1656, compiled_block_1_1656 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1654, compiled_block_1_1654 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1655, compiled_block_1_1655 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1655,compiled_block_1_1655); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1657, compiled_block_1_1657 );
  twobit_invoke( 2 );
  twobit_label( 1657, compiled_block_1_1657 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1654, compiled_block_1_1654 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1655, compiled_block_1_1655 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1655,compiled_block_1_1655); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1658, compiled_block_1_1658 );
  twobit_invoke( 2 );
  twobit_label( 1658, compiled_block_1_1658 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1654, compiled_block_1_1654 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1655, compiled_block_1_1655 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1655,compiled_block_1_1655); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1659, compiled_block_1_1659 );
  twobit_invoke( 2 );
  twobit_label( 1659, compiled_block_1_1659 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1654, compiled_block_1_1654 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1655, compiled_block_1_1655 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1655,compiled_block_1_1655); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1660, compiled_block_1_1660 );
  twobit_invoke( 2 );
  twobit_label( 1660, compiled_block_1_1660 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1654, compiled_block_1_1654 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1655, compiled_block_1_1655 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1655,compiled_block_1_1655); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1661, compiled_block_1_1661 );
  twobit_invoke( 2 );
  twobit_label( 1661, compiled_block_1_1661 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_stack( 1 );
  twobit_setreg( 3 );
  twobit_store( 3, 11 );
  twobit_stack( 4 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_load( 4, 5 );
  twobit_store( 4, 4 );
  twobit_load( 2, 6 );
  twobit_stack( 7 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 2 );
  twobit_load( 4, 7 );
  twobit_check( 4, 1, 0, 1662, compiled_block_1_1662 );
  twobit_load( 4, 3 );
  twobit_stack( 7 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_load( 4, 2 );
  twobit_load( 1, 7 );
  twobit_check( 1, 4, 0, 1663, compiled_block_1_1663 );
  twobit_stack( 7 );
  twobit_reg_op2imm_check_660(RESULT,fixnum(0),1663,compiled_block_1_1663); /* internal:check->=:fix:fix/imm with (1 4 0) */
  twobit_load( 4, 7 );
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_load( 3, 8 );
  twobit_stack( 9 );
  twobit_setreg( 1 );
  twobit_store( 1, 9 );
  twobit_load( 1, 10 );
  twobit_movereg( 4, 7 );
  twobit_load( 4, 4 );
  twobit_load( 5, 1 );
  twobit_load( 6, 11 );
  twobit_stack( 9 );
  twobit_pop( 11 );
  twobit_invoke( 7 );
  twobit_label( 1655, compiled_block_1_1655 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1654, compiled_block_1_1654 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_label( 1663, compiled_block_1_1663 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_label( 1662, compiled_block_1_1662 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_67( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 10 );
  twobit_store( 0, 0 );
  twobit_store( 1, 8 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1665, compiled_block_1_1665 );
  twobit_invoke( 2 );
  twobit_label( 1665, compiled_block_1_1665 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1666, compiled_block_1_1666 );
  twobit_stack( 2 );
  twobit_reg_op1_check_653(RESULT,1666,compiled_block_1_1666); /* internal:check-vector? with (4 3 0) */
  twobit_stack( 2 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1667, compiled_block_1_1667 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1667,compiled_block_1_1667); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1668, compiled_block_1_1668 );
  twobit_invoke( 2 );
  twobit_label( 1668, compiled_block_1_1668 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1666, compiled_block_1_1666 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1667, compiled_block_1_1667 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1667,compiled_block_1_1667); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1669, compiled_block_1_1669 );
  twobit_invoke( 2 );
  twobit_label( 1669, compiled_block_1_1669 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1666, compiled_block_1_1666 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1667, compiled_block_1_1667 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1667,compiled_block_1_1667); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1670, compiled_block_1_1670 );
  twobit_invoke( 2 );
  twobit_label( 1670, compiled_block_1_1670 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1666, compiled_block_1_1666 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1667, compiled_block_1_1667 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1667,compiled_block_1_1667); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1671, compiled_block_1_1671 );
  twobit_invoke( 2 );
  twobit_label( 1671, compiled_block_1_1671 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1666, compiled_block_1_1666 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1667, compiled_block_1_1667 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1667,compiled_block_1_1667); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1672, compiled_block_1_1672 );
  twobit_invoke( 2 );
  twobit_label( 1672, compiled_block_1_1672 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_stack( 1 );
  twobit_setreg( 3 );
  twobit_store( 3, 10 );
  twobit_load( 4, 4 );
  twobit_store( 4, 1 );
  twobit_load( 2, 5 );
  twobit_stack( 6 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 2 );
  twobit_load( 4, 6 );
  twobit_check( 4, 1, 0, 1673, compiled_block_1_1673 );
  twobit_load( 4, 3 );
  twobit_stack( 6 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_load( 4, 2 );
  twobit_load( 1, 6 );
  twobit_check( 1, 4, 0, 1674, compiled_block_1_1674 );
  twobit_stack( 6 );
  twobit_reg_op2imm_check_660(RESULT,fixnum(0),1674,compiled_block_1_1674); /* internal:check->=:fix:fix/imm with (1 4 0) */
  twobit_load( 4, 6 );
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_load( 3, 7 );
  twobit_stack( 8 );
  twobit_setreg( 1 );
  twobit_store( 1, 8 );
  twobit_load( 1, 9 );
  twobit_movereg( 4, 6 );
  twobit_load( 4, 1 );
  twobit_load( 5, 10 );
  twobit_stack( 8 );
  twobit_pop( 10 );
  twobit_invoke( 6 );
  twobit_label( 1667, compiled_block_1_1667 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1666, compiled_block_1_1666 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_label( 1674, compiled_block_1_1674 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_label( 1673, compiled_block_1_1673 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_68( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 7 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1676, compiled_block_1_1676 );
  twobit_invoke( 2 );
  twobit_label( 1676, compiled_block_1_1676 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1677, compiled_block_1_1677 );
  twobit_stack( 2 );
  twobit_reg_op1_check_653(RESULT,1677,compiled_block_1_1677); /* internal:check-vector? with (4 3 0) */
  twobit_stack( 2 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1678, compiled_block_1_1678 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1678,compiled_block_1_1678); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1679, compiled_block_1_1679 );
  twobit_invoke( 2 );
  twobit_label( 1679, compiled_block_1_1679 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1677, compiled_block_1_1677 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1678, compiled_block_1_1678 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1678,compiled_block_1_1678); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1680, compiled_block_1_1680 );
  twobit_invoke( 2 );
  twobit_label( 1680, compiled_block_1_1680 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1677, compiled_block_1_1677 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1678, compiled_block_1_1678 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1678,compiled_block_1_1678); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1681, compiled_block_1_1681 );
  twobit_invoke( 2 );
  twobit_label( 1681, compiled_block_1_1681 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1677, compiled_block_1_1677 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1678, compiled_block_1_1678 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1678,compiled_block_1_1678); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1682, compiled_block_1_1682 );
  twobit_invoke( 2 );
  twobit_label( 1682, compiled_block_1_1682 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 4, 1 );
  twobit_load( 2, 4 );
  twobit_stack( 5 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_load( 1, 5 );
  twobit_check( 1, 3, 0, 1683, compiled_block_1_1683 );
  twobit_load( 3, 3 );
  twobit_stack( 5 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 2 );
  twobit_check( 1, 3, 0, 1683, compiled_block_1_1683 );
  twobit_stack( 5 );
  twobit_reg_op2imm_check_660(RESULT,fixnum(0),1683,compiled_block_1_1683); /* internal:check->=:fix:fix/imm with (1 3 0) */
  twobit_load( 3, 5 );
  twobit_stack( 2 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_load( 3, 6 );
  twobit_stack( 7 );
  twobit_setreg( 1 );
  twobit_store( 1, 7 );
  twobit_load( 1, 8 );
  twobit_load( 5, 5 );
  twobit_stack( 7 );
  twobit_pop( 8 );
  twobit_invoke( 5 );
  twobit_label( 1678, compiled_block_1_1678 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1683, compiled_block_1_1683 );
  twobit_trap( 3, 1, 0, 160 );
  twobit_label( 1677, compiled_block_1_1677 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_69( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 5 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1685, compiled_block_1_1685 );
  twobit_invoke( 2 );
  twobit_label( 1685, compiled_block_1_1685 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1686, compiled_block_1_1686 );
  twobit_stack( 2 );
  twobit_reg_op1_check_653(RESULT,1686,compiled_block_1_1686); /* internal:check-vector? with (4 3 0) */
  twobit_stack( 2 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1687, compiled_block_1_1687 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1687,compiled_block_1_1687); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1688, compiled_block_1_1688 );
  twobit_invoke( 2 );
  twobit_label( 1688, compiled_block_1_1688 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1686, compiled_block_1_1686 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1687, compiled_block_1_1687 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1687,compiled_block_1_1687); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1689, compiled_block_1_1689 );
  twobit_invoke( 2 );
  twobit_label( 1689, compiled_block_1_1689 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1686, compiled_block_1_1686 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1687, compiled_block_1_1687 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1687,compiled_block_1_1687); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1690, compiled_block_1_1690 );
  twobit_invoke( 2 );
  twobit_label( 1690, compiled_block_1_1690 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1686, compiled_block_1_1686 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1686, compiled_block_1_1686 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1686,compiled_block_1_1686); /* internal:check->=:fix:fix/imm with (4 3 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_stack( 5 );
  twobit_setreg( 1 );
  twobit_store( 1, 5 );
  twobit_load( 1, 6 );
  twobit_stack( 5 );
  twobit_pop( 6 );
  twobit_invoke( 4 );
  twobit_label( 1687, compiled_block_1_1687 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1686, compiled_block_1_1686 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_70( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1692, compiled_block_1_1692 );
  twobit_invoke( 2 );
  twobit_label( 1692, compiled_block_1_1692 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1693, compiled_block_1_1693 );
  twobit_stack( 2 );
  twobit_reg_op1_check_653(RESULT,1693,compiled_block_1_1693); /* internal:check-vector? with (4 3 0) */
  twobit_stack( 2 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1694, compiled_block_1_1694 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1694,compiled_block_1_1694); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1695, compiled_block_1_1695 );
  twobit_invoke( 2 );
  twobit_label( 1695, compiled_block_1_1695 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1693, compiled_block_1_1693 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1694, compiled_block_1_1694 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1694,compiled_block_1_1694); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1696, compiled_block_1_1696 );
  twobit_invoke( 2 );
  twobit_label( 1696, compiled_block_1_1696 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1693, compiled_block_1_1693 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1693, compiled_block_1_1693 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1693,compiled_block_1_1693); /* internal:check->=:fix:fix/imm with (4 3 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_setreg( 4 );
  twobit_load( 1, 5 );
  twobit_reg( 4 );
  twobit_pop( 5 );
  twobit_invoke( 3 );
  twobit_label( 1694, compiled_block_1_1694 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1693, compiled_block_1_1693 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_71( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1698, compiled_block_1_1698 );
  twobit_invoke( 2 );
  twobit_label( 1698, compiled_block_1_1698 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1699, compiled_block_1_1699 );
  twobit_stack( 2 );
  twobit_reg_op1_check_653(RESULT,1699,compiled_block_1_1699); /* internal:check-vector? with (4 3 0) */
  twobit_stack( 2 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1700, compiled_block_1_1700 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1700,compiled_block_1_1700); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1701, compiled_block_1_1701 );
  twobit_invoke( 2 );
  twobit_label( 1701, compiled_block_1_1701 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 2 );
  twobit_check( 4, 1, 0, 1702, compiled_block_1_1702 );
  twobit_load( 3, 1 );
  twobit_reg_op2_check_661(reg(4),reg(3),1702,compiled_block_1_1702); /* internal:check-range with (4 1 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_stack( 3 );
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 1700, compiled_block_1_1700 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1699, compiled_block_1_1699 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_label( 1702, compiled_block_1_1702 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_72( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 3, 1 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1704, compiled_block_1_1704 );
  twobit_invoke( 2 );
  twobit_label( 1704, compiled_block_1_1704 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1705, compiled_block_1_1705 );
  twobit_stack( 1 );
  twobit_reg_op1_check_653(RESULT,1705,compiled_block_1_1705); /* internal:check-vector? with (4 1 0) */
  twobit_stack( 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_reg_op2_check_661(reg(4),reg(3),1705,compiled_block_1_1705); /* internal:check-range with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_setreg( 3 );
  twobit_movereg( 4, 1 );
  twobit_reg( 3 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1705, compiled_block_1_1705 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_73( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_movereg( 1, 4 );
  twobit_reg( 4 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_74( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lambda( compiled_start_1_246, 2, 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_246( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(10), 247, compiled_temp_1_247, 1710, compiled_block_1_1710 ); /* internal:branchf-</imm */
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1711, compiled_block_1_1711 );
  twobit_lexical( 1, 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1711, compiled_block_1_1711 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1711, compiled_block_1_1711 );
  twobit_lexical( 1, 1 );
  twobit_op2_402( 1 ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1710, compiled_block_1_1710 );
  twobit_label( 1708, compiled_block_1_1708 );
  twobit_lambda( compiled_start_1_248, 2, 1 );
  twobit_return();
  twobit_label( 1711, compiled_block_1_1711 );
  twobit_trap( 3, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_248( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 14 );
  twobit_store( 0, 0 );
  twobit_store( 1, 14 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_movereg( 2, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1713, compiled_block_1_1713 );
  twobit_invoke( 2 );
  twobit_label( 1713, compiled_block_1_1713 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1714, compiled_block_1_1714 );
  twobit_stack( 2 );
  twobit_reg_op1_check_653(RESULT,1714,compiled_block_1_1714); /* internal:check-vector? with (4 3 0) */
  twobit_stack( 2 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1715, compiled_block_1_1715 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1715,compiled_block_1_1715); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 13 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1716, compiled_block_1_1716 );
  twobit_invoke( 2 );
  twobit_label( 1716, compiled_block_1_1716 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1714, compiled_block_1_1714 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1715, compiled_block_1_1715 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1715,compiled_block_1_1715); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1717, compiled_block_1_1717 );
  twobit_invoke( 2 );
  twobit_label( 1717, compiled_block_1_1717 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1714, compiled_block_1_1714 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1715, compiled_block_1_1715 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1715,compiled_block_1_1715); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1718, compiled_block_1_1718 );
  twobit_invoke( 2 );
  twobit_label( 1718, compiled_block_1_1718 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1714, compiled_block_1_1714 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1715, compiled_block_1_1715 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1715,compiled_block_1_1715); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1719, compiled_block_1_1719 );
  twobit_invoke( 2 );
  twobit_label( 1719, compiled_block_1_1719 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1714, compiled_block_1_1714 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1715, compiled_block_1_1715 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1715,compiled_block_1_1715); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1720, compiled_block_1_1720 );
  twobit_invoke( 2 );
  twobit_label( 1720, compiled_block_1_1720 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1714, compiled_block_1_1714 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1715, compiled_block_1_1715 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1715,compiled_block_1_1715); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1721, compiled_block_1_1721 );
  twobit_invoke( 2 );
  twobit_label( 1721, compiled_block_1_1721 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1714, compiled_block_1_1714 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1715, compiled_block_1_1715 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1715,compiled_block_1_1715); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1722, compiled_block_1_1722 );
  twobit_invoke( 2 );
  twobit_label( 1722, compiled_block_1_1722 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1714, compiled_block_1_1714 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1715, compiled_block_1_1715 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1715,compiled_block_1_1715); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1723, compiled_block_1_1723 );
  twobit_invoke( 2 );
  twobit_label( 1723, compiled_block_1_1723 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1714, compiled_block_1_1714 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 2 );
  twobit_check( 4, 2, 0, 1715, compiled_block_1_1715 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1715,compiled_block_1_1715); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1724, compiled_block_1_1724 );
  twobit_invoke( 2 );
  twobit_label( 1724, compiled_block_1_1724 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 2 );
  twobit_check( 4, 1, 0, 1725, compiled_block_1_1725 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 2 );
  twobit_check( 4, 3, 0, 1714, compiled_block_1_1714 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),1725,compiled_block_1_1725); /* internal:check->=:fix:fix/imm with (4 1 0) */
  twobit_stack( 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 4, 1 );
  twobit_load( 2, 3 );
  twobit_lambda( compiled_start_1_249, 4, 4 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_setrtn( 1731, compiled_block_1_1731 );
  twobit_invoke( 2 );
  twobit_label( 1731, compiled_block_1_1731 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_stack( 4 );
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_stack( 5 );
  twobit_setreg( 2 );
  twobit_store( 2, 5 );
  twobit_stack( 6 );
  twobit_setreg( 1 );
  twobit_stack( 7 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_stack( 8 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_stack( 9 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_stack( 10 );
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_load( 4, 11 );
  twobit_load( 3, 12 );
  twobit_load( 2, 13 );
  twobit_movereg( 1, 9 );
  twobit_load( 1, 14 );
  twobit_load( 5, 10 );
  twobit_load( 6, 9 );
  twobit_load( 7, 8 );
  twobit_load( 8, 7 );
  twobit_load( 10, 5 );
  twobit_load( 11, 4 );
  twobit_load( 12, 3 );
  twobit_global( 5 ); /* apply */
  twobit_pop( 14 );
  twobit_invoke( 12 );
  twobit_label( 1715, compiled_block_1_1715 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1714, compiled_block_1_1714 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_label( 1725, compiled_block_1_1725 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_249( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_639( fixnum(10), 250, compiled_temp_1_250, 1727, compiled_block_1_1727 ); /* internal:branchf-=/imm */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1727, compiled_block_1_1727 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_reg( 1 );
  twobit_op2imm_131( fixnum(1), 251, compiled_temp_1_251 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 2 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1728, compiled_block_1_1728 );
  twobit_invoke( 2 );
  twobit_label( 1728, compiled_block_1_1728 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 2, 0, 1729, compiled_block_1_1729 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 2, 0, 1729, compiled_block_1_1729 );
  twobit_reg( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 2, 0, 1729, compiled_block_1_1729 );
  twobit_lexical( 0, 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1729, compiled_block_1_1729 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_75( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  array:indexer/vector~1ayXVW~11593 */
  twobit_setrtn( 1734, compiled_block_1_1734 );
  twobit_invoke( 1 );
  twobit_label( 1734, compiled_block_1_1734 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_76( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 2, 3 );
  twobit_store( 3, 2 );
  twobit_store( 4, 1 );
  twobit_global( 1 ); /*  array:indexer/array~1ayXVW~11594 */
  twobit_setrtn( 1736, compiled_block_1_1736 );
  twobit_invoke( 1 );
  twobit_label( 1736, compiled_block_1_1736 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_77( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  array:applier-to-vector~1ayXVW~11595 */
  twobit_setrtn( 1738, compiled_block_1_1738 );
  twobit_invoke( 1 );
  twobit_label( 1738, compiled_block_1_1738 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_78( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  array:applier-to-actor~1ayXVW~11596 */
  twobit_setrtn( 1740, compiled_block_1_1740 );
  twobit_invoke( 1 );
  twobit_label( 1740, compiled_block_1_1740 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_79( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_global( 1 ); /*  array:good-shape?~1ayXVW~11617 */
  twobit_setrtn( 1742, compiled_block_1_1742 );
  twobit_invoke( 1 );
  twobit_label( 1742, compiled_block_1_1742 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1744, compiled_block_1_1744 );
  twobit_skip( 1743, compiled_block_1_1743 );
  twobit_label( 1744, compiled_block_1_1744 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 1745, compiled_block_1_1745 );
  twobit_invoke( 1 );
  twobit_label( 1745, compiled_block_1_1745 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_label( 1743, compiled_block_1_1743 );
  twobit_reg( 4 );
  twobit_load( 2, 1 );
  twobit_load( 3, 2 );
  twobit_global( 4 ); /*  array:make-array~1ayXVW~11604 */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* apply */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_80( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  array:size~1ayXVW~11615 */
  twobit_setrtn( 1747, compiled_block_1_1747 );
  twobit_invoke( 1 );
  twobit_label( 1747, compiled_block_1_1747 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 1 );
  twobit_op1_branchf_611( 1749, compiled_block_1_1749 ); /* internal:branchf-pair? */
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_244, 3, 1 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /* apply */
  twobit_setrtn( 1750, compiled_block_1_1750 );
  twobit_invoke( 2 );
  twobit_label( 1750, compiled_block_1_1750 );
  twobit_load( 0, 0 );
  twobit_skip( 1748, compiled_block_1_1748 );
  twobit_label( 1749, compiled_block_1_1749 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_80( 3 ); /* make-vector */
  twobit_label( 1748, compiled_block_1_1748 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_stack( 2 );
  twobit_op2imm_branchf_639( fixnum(0), 245, compiled_temp_1_245, 1752, compiled_block_1_1752 ); /* internal:branchf-=/imm */
  twobit_load( 1, 3 );
  twobit_global( 5 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 1753, compiled_block_1_1753 );
  twobit_invoke( 1 );
  twobit_label( 1753, compiled_block_1_1753 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op2_check_662(reg(4),reg(3),1754,compiled_block_1_1754); /* internal:check-vector?/vector-length:vec with (0 4 0) */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(3),1754,compiled_block_1_1754); /* internal:check-<:fix:fix with (0 4 0) */
  twobit_reg( 4 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  array:optimize-empty~1ayXVW~11580 */
  twobit_setrtn( 1755, compiled_block_1_1755 );
  twobit_invoke( 1 );
  twobit_label( 1755, compiled_block_1_1755 );
  twobit_load( 0, 0 );
  twobit_skip( 1751, compiled_block_1_1751 );
  twobit_label( 1752, compiled_block_1_1752 );
  twobit_load( 1, 3 );
  twobit_global( 7 ); /*  array:make-index~1ayXVW~11616 */
  twobit_setrtn( 1756, compiled_block_1_1756 );
  twobit_invoke( 1 );
  twobit_label( 1756, compiled_block_1_1756 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 3 );
  twobit_global( 5 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 1757, compiled_block_1_1757 );
  twobit_invoke( 1 );
  twobit_label( 1757, compiled_block_1_1757 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg_op2_check_662(reg(4),reg(3),1754,compiled_block_1_1754); /* internal:check-vector?/vector-length:vec with (0 4 0) */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(3),1754,compiled_block_1_1754); /* internal:check-<:fix:fix with (0 4 0) */
  twobit_reg( 4 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_global( 8 ); /*  array:optimize~1ayXVW~11579 */
  twobit_setrtn( 1758, compiled_block_1_1758 );
  twobit_invoke( 2 );
  twobit_label( 1758, compiled_block_1_1758 );
  twobit_load( 0, 0 );
  twobit_label( 1751, compiled_block_1_1751 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 3 );
  twobit_global( 9 ); /*  array:shape->vector~1ayXVW~11614 */
  twobit_setrtn( 1759, compiled_block_1_1759 );
  twobit_invoke( 1 );
  twobit_label( 1759, compiled_block_1_1759 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_load( 1, 4 );
  twobit_global( 10 ); /*  array:make~1ayXVW~11571 */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 1754, compiled_block_1_1754 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_244( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 1 );
  twobit_op2_80( 1 ); /* make-vector */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_81( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* list->vector */
  twobit_setrtn( 1761, compiled_block_1_1761 );
  twobit_invoke( 1 );
  twobit_label( 1761, compiled_block_1_1761 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg_op2_check_662(reg(4),reg(3),1762,compiled_block_1_1762); /* internal:check-vector?/vector-length:vec with (4 0 0) */
  twobit_store( 3, 2 );
  twobit_movereg( 3, 1 );
  twobit_global( 2 ); /* even? */
  twobit_setrtn( 1763, compiled_block_1_1763 );
  twobit_invoke( 1 );
  twobit_label( 1763, compiled_block_1_1763 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1765, compiled_block_1_1765 );
  twobit_skip( 1764, compiled_block_1_1764 );
  twobit_label( 1765, compiled_block_1_1765 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  array:list->string~1ayXVW~11630 */
  twobit_setrtn( 1766, compiled_block_1_1766 );
  twobit_invoke( 1 );
  twobit_label( 1766, compiled_block_1_1766 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /* string-append */
  twobit_setrtn( 1767, compiled_block_1_1767 );
  twobit_invoke( 2 );
  twobit_label( 1767, compiled_block_1_1767 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 1768, compiled_block_1_1768 );
  twobit_invoke( 1 );
  twobit_label( 1768, compiled_block_1_1768 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_label( 1764, compiled_block_1_1764 );
  twobit_reg( 4 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_65( 4, 243, compiled_temp_1_243 ); /* quotient */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 3 );
  twobit_op2_604( 3 ); /* make-vector:4 */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_op3_403( 2, 1 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op3_403( 2, 4 ); /* vector-set!:trusted */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_op3_403( 4, 1 ); /* vector-set!:trusted */
  twobit_stack( 1 );
  twobit_op1_branchf_611( 1770, compiled_block_1_1770 ); /* internal:branchf-pair? */
  twobit_global( 7 ); /*  array:shape-index~1ayXVW~11583 */
  twobit_setrtn( 1771, compiled_block_1_1771 );
  twobit_invoke( 0 );
  twobit_label( 1771, compiled_block_1_1771 );
  twobit_load( 0, 0 );
  twobit_skip( 1769, compiled_block_1_1769 );
  twobit_label( 1770, compiled_block_1_1770 );
  twobit_global( 8 ); /*  array:empty-shape-index~1ayXVW~11584 */
  twobit_setrtn( 1772, compiled_block_1_1772 );
  twobit_invoke( 0 );
  twobit_label( 1772, compiled_block_1_1772 );
  twobit_load( 0, 0 );
  twobit_label( 1769, compiled_block_1_1769 );
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_load( 3, 2 );
  twobit_global( 9 ); /*  array:make~1ayXVW~11571 */
  twobit_setrtn( 1773, compiled_block_1_1773 );
  twobit_invoke( 3 );
  twobit_label( 1773, compiled_block_1_1773 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 10 ); /*  array:good-shape?~1ayXVW~11617 */
  twobit_setrtn( 1774, compiled_block_1_1774 );
  twobit_invoke( 1 );
  twobit_label( 1774, compiled_block_1_1774 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1776, compiled_block_1_1776 );
  twobit_skip( 1775, compiled_block_1_1775 );
  twobit_label( 1776, compiled_block_1_1776 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  array:list->string~1ayXVW~11630 */
  twobit_setrtn( 1777, compiled_block_1_1777 );
  twobit_invoke( 1 );
  twobit_label( 1777, compiled_block_1_1777 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_const( 12 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* string-append */
  twobit_setrtn( 1778, compiled_block_1_1778 );
  twobit_invoke( 3 );
  twobit_label( 1778, compiled_block_1_1778 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 1779, compiled_block_1_1779 );
  twobit_invoke( 1 );
  twobit_label( 1779, compiled_block_1_1779 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_label( 1775, compiled_block_1_1775 );
  twobit_reg( 4 );
  twobit_stack( 2 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1762, compiled_block_1_1762 );
  twobit_trap( 4, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_82( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_global( 1 ); /*  array:good-shape?~1ayXVW~11617 */
  twobit_setrtn( 1780, compiled_block_1_1780 );
  twobit_invoke( 1 );
  twobit_label( 1780, compiled_block_1_1780 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1782, compiled_block_1_1782 );
  twobit_skip( 1781, compiled_block_1_1781 );
  twobit_label( 1782, compiled_block_1_1782 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  array:thing->string~1ayXVW~11632 */
  twobit_setrtn( 1783, compiled_block_1_1783 );
  twobit_invoke( 1 );
  twobit_label( 1783, compiled_block_1_1783 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_const( 4 );
  twobit_setreg( 3 );
  twobit_global( 5 ); /* string-append */
  twobit_setrtn( 1784, compiled_block_1_1784 );
  twobit_invoke( 3 );
  twobit_label( 1784, compiled_block_1_1784 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 1785, compiled_block_1_1785 );
  twobit_invoke( 1 );
  twobit_label( 1785, compiled_block_1_1785 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_label( 1781, compiled_block_1_1781 );
  twobit_reg( 4 );
  twobit_load( 1, 1 );
  twobit_global( 7 ); /*  array:size~1ayXVW~11615 */
  twobit_setrtn( 1786, compiled_block_1_1786 );
  twobit_invoke( 1 );
  twobit_label( 1786, compiled_block_1_1786 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 2 );
  twobit_global( 8 ); /* list->vector */
  twobit_setrtn( 1787, compiled_block_1_1787 );
  twobit_invoke( 1 );
  twobit_label( 1787, compiled_block_1_1787 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_reg_op2_check_662(reg(4),reg(3),1788,compiled_block_1_1788); /* internal:check-vector?/vector-length:vec with (4 0 0) */
  twobit_store( 3, 4 );
  twobit_load( 2, 3 );
  twobit_reg( 3 );
  twobit_op2_68( 2, 241, compiled_temp_1_241 ); /* = */
  twobit_setreg( 1 );
  twobit_reg( 1 );
  twobit_branchf( 1790, compiled_block_1_1790 );
  twobit_skip( 1789, compiled_block_1_1789 );
  twobit_label( 1790, compiled_block_1_1790 );
  twobit_load( 1, 1 );
  twobit_global( 9 ); /*  array:vector~1ayXVW~11573 */
  twobit_setrtn( 1791, compiled_block_1_1791 );
  twobit_invoke( 1 );
  twobit_label( 1791, compiled_block_1_1791 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 10 ); /*  array:shape-vector->string~1ayXVW~11631 */
  twobit_setrtn( 1792, compiled_block_1_1792 );
  twobit_invoke( 1 );
  twobit_label( 1792, compiled_block_1_1792 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 1, 3 );
  twobit_global( 11 ); /* number->string */
  twobit_setrtn( 1793, compiled_block_1_1793 );
  twobit_invoke( 1 );
  twobit_label( 1793, compiled_block_1_1793 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 4 );
  twobit_global( 11 ); /* number->string */
  twobit_setrtn( 1794, compiled_block_1_1794 );
  twobit_invoke( 1 );
  twobit_label( 1794, compiled_block_1_1794 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 2 );
  twobit_global( 12 ); /*  array:list->string~1ayXVW~11630 */
  twobit_setrtn( 1795, compiled_block_1_1795 );
  twobit_invoke( 1 );
  twobit_label( 1795, compiled_block_1_1795 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 4 );
  twobit_setreg( 3 );
  twobit_load( 4, 5 );
  twobit_load( 2, 6 );
  twobit_movereg( 3, 6 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_const( 15 );
  twobit_setreg( 5 );
  twobit_const( 16 );
  twobit_setreg( 7 );
  twobit_load( 8, 2 );
  twobit_global( 5 ); /* string-append */
  twobit_setrtn( 1796, compiled_block_1_1796 );
  twobit_invoke( 8 );
  twobit_label( 1796, compiled_block_1_1796 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 1797, compiled_block_1_1797 );
  twobit_invoke( 1 );
  twobit_label( 1797, compiled_block_1_1797 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_label( 1789, compiled_block_1_1789 );
  twobit_reg( 1 );
  twobit_stack( 3 );
  twobit_op2imm_branchf_639( fixnum(0), 242, compiled_temp_1_242, 1799, compiled_block_1_1799 ); /* internal:branchf-=/imm */
  twobit_load( 1, 1 );
  twobit_global( 17 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 1800, compiled_block_1_1800 );
  twobit_invoke( 1 );
  twobit_label( 1800, compiled_block_1_1800 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op2_check_662(reg(4),reg(3),1801,compiled_block_1_1801); /* internal:check-vector?/vector-length:vec with (0 4 0) */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(3),1801,compiled_block_1_1801); /* internal:check-<:fix:fix with (0 4 0) */
  twobit_reg( 4 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_global( 18 ); /*  array:optimize-empty~1ayXVW~11580 */
  twobit_setrtn( 1802, compiled_block_1_1802 );
  twobit_invoke( 1 );
  twobit_label( 1802, compiled_block_1_1802 );
  twobit_load( 0, 0 );
  twobit_skip( 1798, compiled_block_1_1798 );
  twobit_label( 1799, compiled_block_1_1799 );
  twobit_load( 1, 1 );
  twobit_global( 19 ); /*  array:make-index~1ayXVW~11616 */
  twobit_setrtn( 1803, compiled_block_1_1803 );
  twobit_invoke( 1 );
  twobit_label( 1803, compiled_block_1_1803 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 1 );
  twobit_global( 17 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 1804, compiled_block_1_1804 );
  twobit_invoke( 1 );
  twobit_label( 1804, compiled_block_1_1804 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 5 );
  twobit_reg_op2_check_662(reg(4),reg(3),1801,compiled_block_1_1801); /* internal:check-vector?/vector-length:vec with (0 4 0) */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(3),1801,compiled_block_1_1801); /* internal:check-<:fix:fix with (0 4 0) */
  twobit_reg( 4 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_global( 20 ); /*  array:optimize~1ayXVW~11579 */
  twobit_setrtn( 1805, compiled_block_1_1805 );
  twobit_invoke( 2 );
  twobit_label( 1805, compiled_block_1_1805 );
  twobit_load( 0, 0 );
  twobit_label( 1798, compiled_block_1_1798 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_global( 21 ); /*  array:shape->vector~1ayXVW~11614 */
  twobit_setrtn( 1806, compiled_block_1_1806 );
  twobit_invoke( 1 );
  twobit_label( 1806, compiled_block_1_1806 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 3 );
  twobit_load( 1, 7 );
  twobit_global( 22 ); /*  array:make~1ayXVW~11571 */
  twobit_pop( 7 );
  twobit_invoke( 3 );
  twobit_label( 1801, compiled_block_1_1801 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_label( 1788, compiled_block_1_1788 );
  twobit_trap( 4, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_83( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 1808, compiled_block_1_1808 );
  twobit_invoke( 1 );
  twobit_label( 1808, compiled_block_1_1808 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_653(reg(4),1809,compiled_block_1_1809); /* internal:check-vector? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_imm_const_setreg( fixnum(2), 3 ); /* 2 */
  twobit_op2_65( 3, 240, compiled_temp_1_240 ); /* quotient */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1809, compiled_block_1_1809 );
  twobit_trap( 4, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_84( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 1810, compiled_block_1_1810 );
  twobit_invoke( 1 );
  twobit_label( 1810, compiled_block_1_1810 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_reg( 3 );
  twobit_op2_61( 3, 239, compiled_temp_1_239 ); /* + */
  twobit_setreg( 3 );
  twobit_reg_op1_check_651(reg(3),1811,compiled_block_1_1811); /* internal:check-fixnum? with (3 4 0) */
  twobit_reg_op2_check_662(reg(4),reg(2),1811,compiled_block_1_1811); /* internal:check-vector?/vector-length:vec with (3 4 0) */
  twobit_reg_op2_check_661(reg(3),reg(2),1811,compiled_block_1_1811); /* internal:check-range with (3 4 0) */
  twobit_reg( 4 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1811, compiled_block_1_1811 );
  twobit_trap( 4, 3, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_85( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 1812, compiled_block_1_1812 );
  twobit_invoke( 1 );
  twobit_label( 1812, compiled_block_1_1812 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 237, compiled_temp_1_237 ); /* + */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_61( 3, 238, compiled_temp_1_238 ); /* + */
  twobit_setreg( 3 );
  twobit_reg_op1_check_651(reg(3),1813,compiled_block_1_1813); /* internal:check-fixnum? with (3 4 0) */
  twobit_reg_op2_check_662(reg(4),reg(2),1813,compiled_block_1_1813); /* internal:check-vector?/vector-length:vec with (3 4 0) */
  twobit_reg_op2_check_661(reg(3),reg(2),1813,compiled_block_1_1813); /* internal:check-range with (3 4 0) */
  twobit_reg( 4 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1813, compiled_block_1_1813 );
  twobit_trap( 4, 3, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_86( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  array:good-shape?~1ayXVW~11617 */
  twobit_setrtn( 1814, compiled_block_1_1814 );
  twobit_invoke( 1 );
  twobit_label( 1814, compiled_block_1_1814 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1816, compiled_block_1_1816 );
  twobit_skip( 1815, compiled_block_1_1815 );
  twobit_label( 1816, compiled_block_1_1816 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  array:thing->string~1ayXVW~11632 */
  twobit_setrtn( 1817, compiled_block_1_1817 );
  twobit_invoke( 1 );
  twobit_label( 1817, compiled_block_1_1817 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_const( 4 );
  twobit_setreg( 3 );
  twobit_global( 5 ); /* string-append */
  twobit_setrtn( 1818, compiled_block_1_1818 );
  twobit_invoke( 3 );
  twobit_label( 1818, compiled_block_1_1818 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 1819, compiled_block_1_1819 );
  twobit_invoke( 1 );
  twobit_label( 1819, compiled_block_1_1819 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_label( 1815, compiled_block_1_1815 );
  twobit_reg( 4 );
  twobit_load( 1, 1 );
  twobit_global( 7 ); /*  array:size~1ayXVW~11615 */
  twobit_setrtn( 1820, compiled_block_1_1820 );
  twobit_invoke( 1 );
  twobit_label( 1820, compiled_block_1_1820 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 2 );
  twobit_global( 8 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 1821, compiled_block_1_1821 );
  twobit_invoke( 1 );
  twobit_label( 1821, compiled_block_1_1821 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_load( 1, 1 );
  twobit_load( 3, 4 );
  twobit_global( 9 ); /*  array:good-share?~1ayXVW~11618 */
  twobit_setrtn( 1822, compiled_block_1_1822 );
  twobit_invoke( 4 );
  twobit_label( 1822, compiled_block_1_1822 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1824, compiled_block_1_1824 );
  twobit_skip( 1823, compiled_block_1_1823 );
  twobit_label( 1824, compiled_block_1_1824 );
  twobit_load( 1, 1 );
  twobit_global( 10 ); /*  array:vector~1ayXVW~11573 */
  twobit_setrtn( 1825, compiled_block_1_1825 );
  twobit_invoke( 1 );
  twobit_label( 1825, compiled_block_1_1825 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 11 ); /*  array:shape-vector->string~1ayXVW~11631 */
  twobit_setrtn( 1826, compiled_block_1_1826 );
  twobit_invoke( 1 );
  twobit_label( 1826, compiled_block_1_1826 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 1, 2 );
  twobit_global( 8 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 1827, compiled_block_1_1827 );
  twobit_invoke( 1 );
  twobit_label( 1827, compiled_block_1_1827 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 11 ); /*  array:shape-vector->string~1ayXVW~11631 */
  twobit_setrtn( 1828, compiled_block_1_1828 );
  twobit_invoke( 1 );
  twobit_label( 1828, compiled_block_1_1828 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 1 );
  twobit_global( 8 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 1829, compiled_block_1_1829 );
  twobit_invoke( 1 );
  twobit_label( 1829, compiled_block_1_1829 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_reg_op2_check_662(reg(4),reg(3),1830,compiled_block_1_1830); /* internal:check-vector?/vector-length:vec with (0 4 0) */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(3),1830,compiled_block_1_1830); /* internal:check-<:fix:fix with (0 4 0) */
  twobit_reg( 4 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_global( 12 ); /*  array:map->string~1ayXVW~11636 */
  twobit_setrtn( 1831, compiled_block_1_1831 );
  twobit_invoke( 2 );
  twobit_label( 1831, compiled_block_1_1831 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 4, 5 );
  twobit_load( 2, 6 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_const( 15 );
  twobit_setreg( 5 );
  twobit_load( 6, 7 );
  twobit_global( 5 ); /* string-append */
  twobit_setrtn( 1832, compiled_block_1_1832 );
  twobit_invoke( 6 );
  twobit_label( 1832, compiled_block_1_1832 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 1833, compiled_block_1_1833 );
  twobit_invoke( 1 );
  twobit_label( 1833, compiled_block_1_1833 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_label( 1823, compiled_block_1_1823 );
  twobit_reg( 4 );
  twobit_load( 1, 2 );
  twobit_global( 16 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 1834, compiled_block_1_1834 );
  twobit_invoke( 1 );
  twobit_label( 1834, compiled_block_1_1834 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_load( 1, 2 );
  twobit_global( 10 ); /*  array:vector~1ayXVW~11573 */
  twobit_setrtn( 1835, compiled_block_1_1835 );
  twobit_invoke( 1 );
  twobit_label( 1835, compiled_block_1_1835 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 3 );
  twobit_op2imm_branchf_639( fixnum(0), 233, compiled_temp_1_233, 1837, compiled_block_1_1837 ); /* internal:branchf-=/imm */
  twobit_load( 1, 1 );
  twobit_global( 8 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 1838, compiled_block_1_1838 );
  twobit_invoke( 1 );
  twobit_label( 1838, compiled_block_1_1838 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op2_check_662(reg(4),reg(3),1830,compiled_block_1_1830); /* internal:check-vector?/vector-length:vec with (0 4 0) */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(3),1830,compiled_block_1_1830); /* internal:check-<:fix:fix with (0 4 0) */
  twobit_reg( 4 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_global( 17 ); /*  array:optimize-empty~1ayXVW~11580 */
  twobit_setrtn( 1839, compiled_block_1_1839 );
  twobit_invoke( 1 );
  twobit_label( 1839, compiled_block_1_1839 );
  twobit_load( 0, 0 );
  twobit_skip( 1836, compiled_block_1_1836 );
  twobit_label( 1837, compiled_block_1_1837 );
  twobit_load( 1, 1 );
  twobit_store( 1, 5 );
  twobit_load( 2, 4 );
  twobit_load( 1, 8 );
  twobit_lambda( compiled_start_1_234, 19, 2 );
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_load( 1, 5 );
  twobit_global( 8 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 1843, compiled_block_1_1843 );
  twobit_invoke( 1 );
  twobit_label( 1843, compiled_block_1_1843 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 6 );
  twobit_reg_op2_check_662(reg(4),reg(3),1830,compiled_block_1_1830); /* internal:check-vector?/vector-length:vec with (0 4 0) */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(3),1830,compiled_block_1_1830); /* internal:check-<:fix:fix with (0 4 0) */
  twobit_reg( 4 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_global( 20 ); /*  array:optimize~1ayXVW~11579 */
  twobit_setrtn( 1844, compiled_block_1_1844 );
  twobit_invoke( 2 );
  twobit_label( 1844, compiled_block_1_1844 );
  twobit_load( 0, 0 );
  twobit_label( 1836, compiled_block_1_1836 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_global( 21 ); /*  array:shape->vector~1ayXVW~11614 */
  twobit_setrtn( 1845, compiled_block_1_1845 );
  twobit_invoke( 1 );
  twobit_label( 1845, compiled_block_1_1845 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 3 );
  twobit_load( 1, 2 );
  twobit_global( 22 ); /*  array:make~1ayXVW~11571 */
  twobit_pop( 8 );
  twobit_invoke( 3 );
  twobit_label( 1830, compiled_block_1_1830 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_234( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_lambda( compiled_start_1_235, 2, 1 );
  twobit_setreg( 1 );
  twobit_lambda( compiled_start_1_236, 4, 0 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_235( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /* apply */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_236( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  array:vector-index~1ayXVW~11582 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_87( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_store( 3, 3 );
  twobit_store( 4, 4 );
  twobit_global( 1 ); /*  array:vector~1ayXVW~11573 */
  twobit_setrtn( 1847, compiled_block_1_1847 );
  twobit_invoke( 1 );
  twobit_label( 1847, compiled_block_1_1847 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  array:size~1ayXVW~11615 */
  twobit_setrtn( 1848, compiled_block_1_1848 );
  twobit_invoke( 1 );
  twobit_label( 1848, compiled_block_1_1848 );
  twobit_load( 0, 0 );
  twobit_op2imm_branchf_639( fixnum(0), 228, compiled_temp_1_228, 1850, compiled_block_1_1850 ); /* internal:branchf-=/imm */
  twobit_load( 1, 2 );
  twobit_global( 3 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 1851, compiled_block_1_1851 );
  twobit_invoke( 1 );
  twobit_label( 1851, compiled_block_1_1851 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_653(reg(4),1852,compiled_block_1_1852); /* internal:check-vector? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_imm_const_setreg( fixnum(2), 3 ); /* 2 */
  twobit_op2_65( 3, 229, compiled_temp_1_229 ); /* quotient */
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  array:optimize-empty~1ayXVW~11580 */
  twobit_setrtn( 1853, compiled_block_1_1853 );
  twobit_invoke( 1 );
  twobit_label( 1853, compiled_block_1_1853 );
  twobit_load( 0, 0 );
  twobit_skip( 1849, compiled_block_1_1849 );
  twobit_label( 1850, compiled_block_1_1850 );
  twobit_load( 2, 3 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_230, 6, 2 );
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op1_41(); /* vector? */
  twobit_branchf( 1867, compiled_block_1_1867 );
  twobit_global( 7 ); /*  array:optimize/vector~1ayXVW~11612 */
  twobit_skip( 1866, compiled_block_1_1866 );
  twobit_label( 1867, compiled_block_1_1867 );
  twobit_global( 8 ); /*  array:optimize/actor~1ayXVW~11613 */
  twobit_label( 1866, compiled_block_1_1866 );
  twobit_setreg( 3 );
  twobit_load( 2, 4 );
  twobit_movereg( 4, 1 );
  twobit_reg( 3 );
  twobit_setrtn( 1868, compiled_block_1_1868 );
  twobit_invoke( 2 );
  twobit_label( 1868, compiled_block_1_1868 );
  twobit_load( 0, 0 );
  twobit_label( 1849, compiled_block_1_1849 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 1 );
  twobit_global( 9 ); /*  array:shape->vector~1ayXVW~11614 */
  twobit_setrtn( 1869, compiled_block_1_1869 );
  twobit_invoke( 1 );
  twobit_label( 1869, compiled_block_1_1869 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 5 );
  twobit_load( 1, 6 );
  twobit_global( 10 ); /*  array:make~1ayXVW~11571 */
  twobit_pop( 6 );
  twobit_invoke( 3 );
  twobit_label( 1852, compiled_block_1_1852 );
  twobit_trap( 4, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_230( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1854, compiled_block_1_1854 );
  twobit_invoke( 1 );
  twobit_label( 1854, compiled_block_1_1854 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_41(); /* vector? */
  twobit_branchf( 1856, compiled_block_1_1856 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 1857, compiled_block_1_1857 );
  twobit_invoke( 1 );
  twobit_label( 1857, compiled_block_1_1857 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_653(reg(4),1858,compiled_block_1_1858); /* internal:check-vector? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_imm_const_setreg( fixnum(2), 3 ); /* 2 */
  twobit_op2_65( 3, 231, compiled_temp_1_231 ); /* quotient */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 1859, compiled_block_1_1859 );
  twobit_invoke( 1 );
  twobit_label( 1859, compiled_block_1_1859 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_load( 3, 2 );
  twobit_global( 3 ); /*  array:index/vector~1ayXVW~11598 */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 1856, compiled_block_1_1856 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 1861, compiled_block_1_1861 );
  twobit_invoke( 1 );
  twobit_label( 1861, compiled_block_1_1861 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_653(reg(4),1858,compiled_block_1_1858); /* internal:check-vector? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_imm_const_setreg( fixnum(2), 3 ); /* 2 */
  twobit_op2_65( 3, 232, compiled_temp_1_232 ); /* quotient */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 1862, compiled_block_1_1862 );
  twobit_invoke( 1 );
  twobit_label( 1862, compiled_block_1_1862 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 2 );
  twobit_global( 4 ); /*  array:vector~1ayXVW~11573 */
  twobit_setrtn( 1863, compiled_block_1_1863 );
  twobit_invoke( 1 );
  twobit_label( 1863, compiled_block_1_1863 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 2 );
  twobit_global( 2 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 1864, compiled_block_1_1864 );
  twobit_invoke( 1 );
  twobit_label( 1864, compiled_block_1_1864 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_load( 2, 3 );
  twobit_load( 1, 4 );
  twobit_global( 5 ); /*  array:index/array~1ayXVW~11599 */
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 1858, compiled_block_1_1858 );
  twobit_trap( 4, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_88( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 3 );
  twobit_reg_op2_check_662(reg(2),reg(4),1871,compiled_block_1_1871); /* internal:check-vector?/vector-length:vec with (2 0 0) */
  twobit_store( 4, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_222, 3, 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op2_84( 31 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_setrtn( 1876, compiled_block_1_1876 );
  twobit_invoke( 1 );
  twobit_label( 1876, compiled_block_1_1876 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_movereg( 4, 1 );
  twobit_global( 4 ); /*  array:applier-to-vector~1ayXVW~11595 */
  twobit_setrtn( 1877, compiled_block_1_1877 );
  twobit_invoke( 1 );
  twobit_label( 1877, compiled_block_1_1877 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_stack( 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1878, compiled_block_1_1878 );
  twobit_invoke( 1 );
  twobit_label( 1878, compiled_block_1_1878 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_80( 3 ); /* make-vector */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_reg( 3 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(2),1879,compiled_block_1_1879); /* internal:check-<:fix:fix with (4 0 3) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_op3_403( 1, 4 ); /* vector-set!:trusted */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 1 );
  twobit_load( 7, 3 );
  twobit_load( 6, 2 );
  twobit_load( 5, 1 );
  twobit_lambda( compiled_start_1_223, 6, 7 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1886, compiled_block_1_1886 );
  twobit_invoke( 1 );
  twobit_label( 1886, compiled_block_1_1886 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 7 ); /*  array:maker~1ayXVW~11592 */
  twobit_setrtn( 1887, compiled_block_1_1887 );
  twobit_invoke( 1 );
  twobit_label( 1887, compiled_block_1_1887 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 4 );
  twobit_stack( 5 );
  twobit_pop( 5 );
  twobit_invoke( 2 );
  twobit_label( 1879, compiled_block_1_1879 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 3, 1, 4, 161 );
  twobit_label( 1871, compiled_block_1_1871 );
  twobit_trap( 2, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_222( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_623( 4, 227, compiled_temp_1_227, 1873, compiled_block_1_1873 ); /* internal:branchf-= */
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1873, compiled_block_1_1873 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 0, 1, 3, 1874, compiled_block_1_1874 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 0, 1, 3, 1874, compiled_block_1_1874 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 0, 1, 3, 1874, compiled_block_1_1874 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_op3_403( 1, 3 ); /* vector-set!:trusted */
  twobit_reg( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 1874, compiled_block_1_1874 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 3, 1, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_223( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 224, compiled_temp_1_224, 1881, compiled_block_1_1881 ); /* internal:branchf-< */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op2imm_130( fixnum(1), 225, compiled_temp_1_225 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 7 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 0, 1, 2, 1882, compiled_block_1_1882 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 7 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 0, 1, 2, 1882, compiled_block_1_1882 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 7 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 0, 1, 2, 1882, compiled_block_1_1882 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_lexical( 0, 7 );
  twobit_op3_403( 1, 2 ); /* vector-set!:trusted */
  twobit_lexical( 0, 7 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 6 );
  twobit_setrtn( 1883, compiled_block_1_1883 );
  twobit_invoke( 1 );
  twobit_label( 1883, compiled_block_1_1883 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_62( 4, 226, compiled_temp_1_226 ); /* - */
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 7 );
  twobit_op3_403( 3, 1 ); /* vector-set!:trusted */
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 2, 1884, compiled_block_1_1884 );
  twobit_load( 3, 2 );
  twobit_lexical( 0, 3 );
  twobit_op3_403( 3, 4 ); /* vector-set!:trusted */
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 3, 1 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1881, compiled_block_1_1881 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1884, compiled_block_1_1884 );
  twobit_trap( 2, 1, 4, 161 );
  twobit_label( 1882, compiled_block_1_1882 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 3 );
  twobit_trap( 2, 1, 3, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_89( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 5 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 1889, compiled_block_1_1889 );
  twobit_invoke( 1 );
  twobit_label( 1889, compiled_block_1_1889 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  array:vector~1ayXVW~11573 */
  twobit_setrtn( 1890, compiled_block_1_1890 );
  twobit_invoke( 1 );
  twobit_label( 1890, compiled_block_1_1890 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  array-end~1ayXVW~11609 */
  twobit_setrtn( 1891, compiled_block_1_1891 );
  twobit_invoke( 2 );
  twobit_label( 1891, compiled_block_1_1891 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_global( 4 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_214, 6, 4 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_setrtn( 1897, compiled_block_1_1897 );
  twobit_invoke( 1 );
  twobit_label( 1897, compiled_block_1_1897 );
  twobit_load( 0, 0 );
  twobit_stack( 4 );
  twobit_op2imm_130( fixnum(1), 215, compiled_temp_1_215 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_movereg( 4, 1 );
  twobit_global( 7 ); /*  array:applier-to-vector~1ayXVW~11595 */
  twobit_setrtn( 1898, compiled_block_1_1898 );
  twobit_invoke( 1 );
  twobit_label( 1898, compiled_block_1_1898 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_stack( 5 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 3 );
  twobit_setrtn( 1899, compiled_block_1_1899 );
  twobit_invoke( 1 );
  twobit_label( 1899, compiled_block_1_1899 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 6 );
  twobit_op2_80( 3 ); /* make-vector */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_reg( 3 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(2),1900,compiled_block_1_1900); /* internal:check-<:fix:fix with (4 0 3) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_op3_403( 1, 4 ); /* vector-set!:trusted */
  twobit_global( 4 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 1 );
  twobit_load( 9, 4 );
  twobit_load( 8, 3 );
  twobit_load( 7, 1 );
  twobit_load( 6, 5 );
  twobit_load( 5, 2 );
  twobit_lambda( compiled_start_1_216, 9, 9 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1908, compiled_block_1_1908 );
  twobit_invoke( 1 );
  twobit_label( 1908, compiled_block_1_1908 );
  twobit_load( 0, 0 );
  twobit_load( 1, 4 );
  twobit_global( 10 ); /*  array:maker~1ayXVW~11592 */
  twobit_setrtn( 1909, compiled_block_1_1909 );
  twobit_invoke( 1 );
  twobit_label( 1909, compiled_block_1_1909 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 6 );
  twobit_stack( 7 );
  twobit_pop( 7 );
  twobit_invoke( 2 );
  twobit_label( 1900, compiled_block_1_1900 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 3, 1, 4, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_214( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_623( 4, 220, compiled_temp_1_220, 1893, compiled_block_1_1893 ); /* internal:branchf-= */
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1893, compiled_block_1_1893 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1894, compiled_block_1_1894 );
  twobit_invoke( 2 );
  twobit_label( 1894, compiled_block_1_1894 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 0, 4, 2, 1895, compiled_block_1_1895 );
  twobit_lexical( 0, 1 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 0, 4, 2, 1895, compiled_block_1_1895 );
  twobit_lexical( 0, 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 0, 4, 2, 1895, compiled_block_1_1895 );
  twobit_reg( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 0, 4, 2, 1895, compiled_block_1_1895 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 221, compiled_temp_1_221 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1895, compiled_block_1_1895 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 2, 4, 1, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_216( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 9 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_619( 4, 217, compiled_temp_1_217, 1902, compiled_block_1_1902 ); /* internal:branchf-< */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 1903, compiled_block_1_1903 );
  twobit_invoke( 2 );
  twobit_label( 1903, compiled_block_1_1903 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 218, compiled_temp_1_218 ); /* + */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 8 );
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_check( 0, 4, 1, 1904, compiled_block_1_1904 );
  twobit_lexical( 0, 8 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 8 );
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_check( 0, 4, 1, 1904, compiled_block_1_1904 );
  twobit_lexical( 0, 8 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_407( 2 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 8 );
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_check( 0, 4, 1, 1904, compiled_block_1_1904 );
  twobit_reg( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 8 );
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_check( 0, 4, 1, 1904, compiled_block_1_1904 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 8 );
  twobit_op3_403( 4, 1 ); /* vector-set!:trusted */
  twobit_lexical( 0, 7 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 6 );
  twobit_setrtn( 1905, compiled_block_1_1905 );
  twobit_invoke( 1 );
  twobit_label( 1905, compiled_block_1_1905 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_62( 4, 219, compiled_temp_1_219 ); /* - */
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 8 );
  twobit_op3_403( 3, 1 ); /* vector-set!:trusted */
  twobit_stack( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 2, 1906, compiled_block_1_1906 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 2, 1906, compiled_block_1_1906 );
  twobit_stack( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 2, 1906, compiled_block_1_1906 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 3 );
  twobit_op3_403( 3, 4 ); /* vector-set!:trusted */
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 3, 1 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1902, compiled_block_1_1902 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1906, compiled_block_1_1906 );
  twobit_trap( 2, 1, 4, 161 );
  twobit_label( 1904, compiled_block_1_1904 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_trap( 1, 4, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_90( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 1911, compiled_block_1_1911 );
  twobit_invoke( 1 );
  twobit_label( 1911, compiled_block_1_1911 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op2_check_662(reg(4),reg(3),1912,compiled_block_1_1912); /* internal:check-vector?/vector-length:vec with (0 4 0) */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(3),1912,compiled_block_1_1912); /* internal:check-<:fix:fix with (0 4 0) */
  twobit_reg( 4 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  array:vector~1ayXVW~11573 */
  twobit_setrtn( 1913, compiled_block_1_1913 );
  twobit_invoke( 1 );
  twobit_label( 1913, compiled_block_1_1913 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 1914, compiled_block_1_1914 );
  twobit_invoke( 1 );
  twobit_label( 1914, compiled_block_1_1914 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_63( 3, 208, compiled_temp_1_208 ); /* * */
  twobit_imm_const_setreg( NIL_CONST, 2 ); /* () */
  twobit_op2_80( 2 ); /* make-vector */
  twobit_setreg( 3 );
  twobit_global( 4 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 2 );
  twobit_load( 5, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_209, 6, 5 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 1 );
  twobit_label( 1912, compiled_block_1_1912 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_209( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_623( 4, 210, compiled_temp_1_210, 1916, compiled_block_1_1916 ); /* internal:branchf-= */
  twobit_lexical( 0, 3 );
  twobit_return();
  twobit_label( 1916, compiled_block_1_1916 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  array:shape-vector-index~1ayXVW~11585 */
  twobit_setrtn( 1917, compiled_block_1_1917 );
  twobit_invoke( 3 );
  twobit_label( 1917, compiled_block_1_1917 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 2, 1 );
  twobit_store( 2, 3 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 0, 1918, compiled_block_1_1918 );
  twobit_lexical( 0, 1 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 0, 1918, compiled_block_1_1918 );
  twobit_lexical( 0, 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_reg( 1 );
  twobit_check( 3, 4, 0, 1919, compiled_block_1_1919 );
  twobit_stack( 2 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_load( 4, 2 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 0, 1920, compiled_block_1_1920 );
  twobit_lexical( 0, 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 3, 1 );
  twobit_reg( 3 );
  twobit_op2_61( 3, 211, compiled_temp_1_211 ); /* + */
  twobit_setreg( 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_reg( 3 );
  twobit_check( 2, 1, 4, 1921, compiled_block_1_1921 );
  twobit_lexical( 0, 3 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_load( 4, 2 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 2, 1922, compiled_block_1_1922 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_check( 2, 1, 3, 1923, compiled_block_1_1923 );
  twobit_load( 4, 2 );
  twobit_lexical( 0, 3 );
  twobit_op3_403( 1, 4 ); /* vector-set!:trusted */
  twobit_lexical( 0, 4 );
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  array:shape-vector-index~1ayXVW~11585 */
  twobit_setrtn( 1924, compiled_block_1_1924 );
  twobit_invoke( 3 );
  twobit_label( 1924, compiled_block_1_1924 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 2, 0, 1925, compiled_block_1_1925 );
  twobit_load( 3, 4 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 2, 0, 1925, compiled_block_1_1925 );
  twobit_reg( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 2, 0, 1925, compiled_block_1_1925 );
  twobit_lexical( 0, 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 212, compiled_temp_1_212 ); /* + */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_stack( 1 );
  twobit_op2_61( 3, 213, compiled_temp_1_213 ); /* + */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 4 );
  twobit_load( 3, 4 );
  twobit_reg( 1 );
  twobit_check( 3, 2, 4, 1926, compiled_block_1_1926 );
  twobit_load( 4, 5 );
  twobit_reg( 2 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_check( 1, 2, 3, 1927, compiled_block_1_1927 );
  twobit_reg( 2 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 2, 3, 1927, compiled_block_1_1927 );
  twobit_load( 4, 4 );
  twobit_lexical( 0, 3 );
  twobit_op3_403( 2, 4 ); /* vector-set!:trusted */
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 1927, compiled_block_1_1927 );
  twobit_trap( 3, 2, 1, 161 );
  twobit_label( 1923, compiled_block_1_1923 );
  twobit_trap( 3, 1, 2, 161 );
  twobit_label( 1926, compiled_block_1_1926 );
  twobit_trap( 4, 2, 3, 161 );
  twobit_label( 1925, compiled_block_1_1925 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1922, compiled_block_1_1922 );
  twobit_trap( 2, 1, 4, 161 );
  twobit_label( 1921, compiled_block_1_1921 );
  twobit_trap( 4, 1, 2, 161 );
  twobit_label( 1920, compiled_block_1_1920 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_label( 1919, compiled_block_1_1919 );
  twobit_trap( 4, 3, 0, 160 );
  twobit_label( 1918, compiled_block_1_1918 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_91( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 1930, compiled_block_1_1930 );
  twobit_invoke( 1 );
  twobit_label( 1930, compiled_block_1_1930 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op2_check_662(reg(4),reg(3),1931,compiled_block_1_1931); /* internal:check-vector?/vector-length:vec with (0 4 0) */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(3),1931,compiled_block_1_1931); /* internal:check-<:fix:fix with (0 4 0) */
  twobit_reg( 4 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  array:vector~1ayXVW~11573 */
  twobit_setrtn( 1932, compiled_block_1_1932 );
  twobit_invoke( 1 );
  twobit_label( 1932, compiled_block_1_1932 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 1933, compiled_block_1_1933 );
  twobit_invoke( 1 );
  twobit_label( 1933, compiled_block_1_1933 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_global( 4 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_203, 6, 4 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1931, compiled_block_1_1931 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_203( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_623( 4, 204, compiled_temp_1_204, 1935, compiled_block_1_1935 ); /* internal:branchf-= */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1935, compiled_block_1_1935 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 4 );
  twobit_movereg( 1, 2 );
  twobit_reg( 1 );
  twobit_op2imm_130( fixnum(1), 205, compiled_temp_1_205 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  array:shape-vector-index~1ayXVW~11585 */
  twobit_setrtn( 1936, compiled_block_1_1936 );
  twobit_invoke( 3 );
  twobit_label( 1936, compiled_block_1_1936 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 0, 1937, compiled_block_1_1937 );
  twobit_lexical( 0, 1 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 0, 1937, compiled_block_1_1937 );
  twobit_lexical( 0, 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_reg( 1 );
  twobit_check( 3, 4, 0, 1938, compiled_block_1_1938 );
  twobit_stack( 2 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_load( 4, 2 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 0, 1939, compiled_block_1_1939 );
  twobit_lexical( 0, 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  array:shape-vector-index~1ayXVW~11585 */
  twobit_setrtn( 1940, compiled_block_1_1940 );
  twobit_invoke( 3 );
  twobit_label( 1940, compiled_block_1_1940 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 0, 1941, compiled_block_1_1941 );
  twobit_load( 3, 1 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 0, 1941, compiled_block_1_1941 );
  twobit_reg( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 0, 1941, compiled_block_1_1941 );
  twobit_lexical( 0, 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_62( 4, 206, compiled_temp_1_206 ); /* - */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_63( 4, 207, compiled_temp_1_207 ); /* * */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 1941, compiled_block_1_1941 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1939, compiled_block_1_1939 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_label( 1938, compiled_block_1_1938 );
  twobit_trap( 4, 3, 0, 160 );
  twobit_label( 1937, compiled_block_1_1937 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_92( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 1944, compiled_block_1_1944 );
  twobit_invoke( 1 );
  twobit_label( 1944, compiled_block_1_1944 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op2_check_662(reg(4),reg(3),1945,compiled_block_1_1945); /* internal:check-vector?/vector-length:vec with (0 4 0) */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(3),1945,compiled_block_1_1945); /* internal:check-<:fix:fix with (0 4 0) */
  twobit_reg( 4 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  array:vector~1ayXVW~11573 */
  twobit_setrtn( 1946, compiled_block_1_1946 );
  twobit_invoke( 1 );
  twobit_label( 1946, compiled_block_1_1946 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 1947, compiled_block_1_1947 );
  twobit_invoke( 1 );
  twobit_label( 1947, compiled_block_1_1947 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_store( 3, 1 );
  twobit_lambda( compiled_start_1_192, 5, 0 );
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_global( 6 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 2 );
  twobit_movereg( 4, 3 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_193, 8, 3 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_load( 3, 1 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1945, compiled_block_1_1945 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_192( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_193( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 3 );
  twobit_op2imm_branchf_639( fixnum(0), 194, compiled_temp_1_194, 1949, compiled_block_1_1949 ); /* internal:branchf-=/imm */
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1949, compiled_block_1_1949 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 2, 5 );
  twobit_lambda( compiled_start_1_195, 2, 3 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 3 );
  twobit_op2imm_131( fixnum(1), 196, compiled_temp_1_196 ); /* - */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 3, 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  array:shape-vector-index~1ayXVW~11585 */
  twobit_setrtn( 1953, compiled_block_1_1953 );
  twobit_invoke( 3 );
  twobit_label( 1953, compiled_block_1_1953 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 2, 0, 1954, compiled_block_1_1954 );
  twobit_lexical( 0, 1 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 2, 0, 1954, compiled_block_1_1954 );
  twobit_lexical( 0, 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_check( 4, 1, 0, 1955, compiled_block_1_1955 );
  twobit_reg( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_check( 4, 1, 0, 1955, compiled_block_1_1955 );
  twobit_lexical( 0, 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_global( 3 ); /*  array:shape-vector-index~1ayXVW~11585 */
  twobit_setrtn( 1956, compiled_block_1_1956 );
  twobit_invoke( 3 );
  twobit_label( 1956, compiled_block_1_1956 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 0, 1954, compiled_block_1_1954 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 0, 1954, compiled_block_1_1954 );
  twobit_reg( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 4, 2, 0, 1954, compiled_block_1_1954 );
  twobit_lexical( 0, 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_62( 4, 197, compiled_temp_1_197 ); /* - */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_63( 4, 198, compiled_temp_1_198 ); /* * */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_reg( 4 );
  twobit_pop( 5 );
  twobit_invoke( 3 );
  twobit_label( 1954, compiled_block_1_1954 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1955, compiled_block_1_1955 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_195( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_lexical( 0, 3 );
  twobit_op2imm_131( fixnum(1), 199, compiled_temp_1_199 ); /* - */
  twobit_setreg( 2 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  array:shape-vector-index~1ayXVW~11585 */
  twobit_setrtn( 1950, compiled_block_1_1950 );
  twobit_invoke( 3 );
  twobit_label( 1950, compiled_block_1_1950 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 2, 0, 1951, compiled_block_1_1951 );
  twobit_lexical( 1, 1 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 2, 0, 1951, compiled_block_1_1951 );
  twobit_lexical( 1, 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 2, 0, 1951, compiled_block_1_1951 );
  twobit_reg( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 2, 0, 1951, compiled_block_1_1951 );
  twobit_lexical( 1, 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_62( 4, 200, compiled_temp_1_200 ); /* - */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_63( 4, 201, compiled_temp_1_201 ); /* * */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 2 ); /* apply */
  twobit_setrtn( 1952, compiled_block_1_1952 );
  twobit_invoke( 2 );
  twobit_label( 1952, compiled_block_1_1952 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_61( 4, 202, compiled_temp_1_202 ); /* + */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1951, compiled_block_1_1951 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_93( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  array:array?~1ayXVW~11572 */
  twobit_setrtn( 1959, compiled_block_1_1959 );
  twobit_invoke( 1 );
  twobit_label( 1959, compiled_block_1_1959 );
  twobit_load( 0, 0 );
  twobit_branchf( 1961, compiled_block_1_1961 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 1962, compiled_block_1_1962 );
  twobit_invoke( 1 );
  twobit_label( 1962, compiled_block_1_1962 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  array:vector~1ayXVW~11573 */
  twobit_setrtn( 1963, compiled_block_1_1963 );
  twobit_invoke( 1 );
  twobit_label( 1963, compiled_block_1_1963 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_global( 4 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 1964, compiled_block_1_1964 );
  twobit_invoke( 1 );
  twobit_label( 1964, compiled_block_1_1964 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op2_check_662(reg(4),reg(3),1965,compiled_block_1_1965); /* internal:check-vector?/vector-length:vec with (4 0 0) */
  twobit_reg( 3 );
  twobit_op2imm_451( fixnum(4) ); /* =:fix:fix */
  twobit_branchf( 1967, compiled_block_1_1967 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(3),1968,compiled_block_1_1968); /* internal:check-<:fix:fix with (0 4 0) */
  twobit_reg( 4 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_op2imm_branchf_639( fixnum(0), 185, compiled_temp_1_185, 1970, compiled_block_1_1970 ); /* internal:branchf-=/imm */
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(3),1971,compiled_block_1_1971); /* internal:check-<:fix:fix with (0 4 0) */
  twobit_reg( 4 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_op2imm_branchf_639( fixnum(0), 186, compiled_temp_1_186, 1973, compiled_block_1_1973 ); /* internal:branchf-=/imm */
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(3),1974,compiled_block_1_1974); /* internal:check-<:fix:fix with (0 4 0) */
  twobit_reg( 4 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_op2imm_134( fixnum(2), 187, compiled_temp_1_187 ); /* = */
  twobit_skip( 1966, compiled_block_1_1966 );
  twobit_label( 1973, compiled_block_1_1973 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1966, compiled_block_1_1966 );
  twobit_label( 1970, compiled_block_1_1970 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1966, compiled_block_1_1966 );
  twobit_label( 1967, compiled_block_1_1967 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1966, compiled_block_1_1966 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(3),1975,compiled_block_1_1975); /* internal:check-<:fix:fix with (0 4 0) */
  twobit_reg( 4 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_global( 5 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_188, 7, 4 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1961, compiled_block_1_1961 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1975, compiled_block_1_1975 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_label( 1971, compiled_block_1_1971 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_label( 1968, compiled_block_1_1968 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_label( 1974, compiled_block_1_1974 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 1 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_label( 1965, compiled_block_1_1965 );
  twobit_trap( 4, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_188( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_623( 4, 189, compiled_temp_1_189, 1977, compiled_block_1_1977 ); /* internal:branchf-= */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1977, compiled_block_1_1977 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 3 );
  twobit_movereg( 1, 2 );
  twobit_reg( 1 );
  twobit_op2imm_130( fixnum(1), 190, compiled_temp_1_190 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  array:shape-vector-index~1ayXVW~11585 */
  twobit_setrtn( 1978, compiled_block_1_1978 );
  twobit_invoke( 3 );
  twobit_label( 1978, compiled_block_1_1978 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 0, 1979, compiled_block_1_1979 );
  twobit_lexical( 0, 1 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_check( 4, 1, 0, 1979, compiled_block_1_1979 );
  twobit_lexical( 0, 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_reg( 1 );
  twobit_check( 3, 4, 0, 1980, compiled_block_1_1980 );
  twobit_stack( 2 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_load( 4, 2 );
  twobit_reg( 1 );
  twobit_check( 4, 3, 0, 1981, compiled_block_1_1981 );
  twobit_lexical( 0, 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  array:shape-vector-index~1ayXVW~11585 */
  twobit_setrtn( 1982, compiled_block_1_1982 );
  twobit_invoke( 3 );
  twobit_label( 1982, compiled_block_1_1982 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 2, 0, 1983, compiled_block_1_1983 );
  twobit_load( 3, 1 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 2, 0, 1983, compiled_block_1_1983 );
  twobit_reg( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 2, 0, 1983, compiled_block_1_1983 );
  twobit_lexical( 0, 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_branchf( 1985, compiled_block_1_1985 );
  twobit_reg( 4 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1987, compiled_block_1_1987 );
  twobit_reg( 4 );
  twobit_op1_25(); /* exact? */
  twobit_branchf( 1989, compiled_block_1_1989 );
  twobit_stack( 2 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1991, compiled_block_1_1991 );
  twobit_stack( 2 );
  twobit_op1_25(); /* exact? */
  twobit_branchf( 1993, compiled_block_1_1993 );
  twobit_load( 3, 2 );
  twobit_reg( 4 );
  twobit_op2_67( 3, 191, compiled_temp_1_191 ); /* <= */
  twobit_setreg( 2 );
  twobit_skip( 1984, compiled_block_1_1984 );
  twobit_label( 1993, compiled_block_1_1993 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_skip( 1984, compiled_block_1_1984 );
  twobit_label( 1991, compiled_block_1_1991 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_skip( 1984, compiled_block_1_1984 );
  twobit_label( 1989, compiled_block_1_1989 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_skip( 1984, compiled_block_1_1984 );
  twobit_label( 1987, compiled_block_1_1987 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_skip( 1984, compiled_block_1_1984 );
  twobit_label( 1985, compiled_block_1_1985 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_label( 1984, compiled_block_1_1984 );
  twobit_load( 1, 4 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 1983, compiled_block_1_1983 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 1981, compiled_block_1_1981 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_label( 1980, compiled_block_1_1980 );
  twobit_trap( 4, 3, 0, 160 );
  twobit_label( 1979, compiled_block_1_1979 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_94( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_reg( 2 );
  twobit_op1_31( 178, compiled_temp_1_178 ); /* zero? */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_branchf( 1997, compiled_block_1_1997 );
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1997, compiled_block_1_1997 );
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 3, 3 );
  twobit_store( 4, 2 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 31 );
  twobit_store( 31, 5 );
  twobit_reg( 2 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 30 );
  twobit_store( 30, 6 );
  twobit_reg( 2 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 2 );
  twobit_store( 2, 4 );
  twobit_global( 2 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 1998, compiled_block_1_1998 );
  twobit_invoke( 1 );
  twobit_label( 1998, compiled_block_1_1998 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  array:vector~1ayXVW~11573 */
  twobit_setrtn( 1999, compiled_block_1_1999 );
  twobit_invoke( 1 );
  twobit_label( 1999, compiled_block_1_1999 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 5, 2 );
  twobit_load( 4, 3 );
  twobit_load( 3, 4 );
  twobit_load( 2, 5 );
  twobit_load( 1, 6 );
  twobit_lambda( compiled_start_1_179, 5, 5 );
  twobit_setreg( 4 );
  twobit_load( 3, 7 );
  twobit_reg( 2 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_load( 3, 8 );
  twobit_reg( 1 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_stack( 4 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_load( 1, 1 );
  twobit_global( 6 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 2012, compiled_block_1_2012 );
  twobit_invoke( 1 );
  twobit_label( 2012, compiled_block_1_2012 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op2_check_662(reg(4),reg(3),2013,compiled_block_1_2013); /* internal:check-vector?/vector-length:vec with (0 4 0) */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(3),2013,compiled_block_1_2013); /* internal:check-<:fix:fix with (0 4 0) */
  twobit_reg( 4 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 7 ); /*  array:unchecked-share-depth?~1ayXVW~11619 */
  twobit_setrtn( 2014, compiled_block_1_2014 );
  twobit_invoke( 1 );
  twobit_label( 2014, compiled_block_1_2014 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2016, compiled_block_1_2016 );
  twobit_reg( 4 );
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 2016, compiled_block_1_2016 );
  twobit_stack( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 8 );
  twobit_invoke( 2 );
  twobit_label( 2013, compiled_block_1_2013 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_179( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_612( 180, compiled_temp_1_180, 2001, compiled_block_1_2001 ); /* internal:branchf-zero? */
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_181, 2, 1 );
  twobit_setreg( 1 );
  twobit_lambda( compiled_start_1_182, 4, 0 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_label( 2001, compiled_block_1_2001 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_reg( 1 );
  twobit_op2imm_131( fixnum(1), 183, compiled_temp_1_183 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_global( 6 ); /*  array:shape-vector-index~1ayXVW~11585 */
  twobit_setrtn( 2005, compiled_block_1_2005 );
  twobit_invoke( 3 );
  twobit_label( 2005, compiled_block_1_2005 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg_op1_check_651(reg(4),2006,compiled_block_1_2006); /* internal:check-fixnum? with (4 3 0) */
  twobit_reg_op2_check_662(reg(3),reg(2),2006,compiled_block_1_2006); /* internal:check-vector?/vector-length:vec with (4 3 0) */
  twobit_reg_op2_check_661(reg(4),reg(2),2006,compiled_block_1_2006); /* internal:check-range with (4 3 0) */
  twobit_reg( 3 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_setrtn( 2007, compiled_block_1_2007 );
  twobit_invoke( 2 );
  twobit_label( 2007, compiled_block_1_2007 );
  twobit_load( 0, 0 );
  twobit_branchf( 2009, compiled_block_1_2009 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 3 );
  twobit_global( 6 ); /*  array:shape-vector-index~1ayXVW~11585 */
  twobit_setrtn( 2010, compiled_block_1_2010 );
  twobit_invoke( 3 );
  twobit_label( 2010, compiled_block_1_2010 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg_op1_check_651(reg(4),2006,compiled_block_1_2006); /* internal:check-fixnum? with (4 3 0) */
  twobit_reg_op2_check_662(reg(3),reg(2),2006,compiled_block_1_2006); /* internal:check-vector?/vector-length:vec with (4 3 0) */
  twobit_reg_op2_check_661(reg(4),reg(2),2006,compiled_block_1_2006); /* internal:check-range with (4 3 0) */
  twobit_reg( 3 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_op2imm_131( fixnum(1), 184, compiled_temp_1_184 ); /* - */
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 2009, compiled_block_1_2009 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2006, compiled_block_1_2006 );
  twobit_trap( 3, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_181( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 4 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /* apply */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_182( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_lexical( 1, 5 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:good-indices?~1ayXVW~11624 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_95( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_636( fixnum(10), 177, compiled_temp_1_177, 2019, compiled_block_1_2019 ); /* internal:branchf->/imm */
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_const( 1 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 7 ); /* display */
  twobit_setrtn( 2020, compiled_block_1_2020 );
  twobit_invoke( 1 );
  twobit_label( 2020, compiled_block_1_2020 );
  twobit_load( 0, 0 );
  twobit_global( 8 ); /* newline */
  twobit_setrtn( 2021, compiled_block_1_2021 );
  twobit_invoke( 0 );
  twobit_label( 2021, compiled_block_1_2021 );
  twobit_load( 0, 0 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 2019, compiled_block_1_2019 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_96( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_movereg( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_global( 1 ); /*  array:good-indices?~1ayXVW~11624 */
  twobit_setrtn( 2022, compiled_block_1_2022 );
  twobit_invoke( 2 );
  twobit_label( 2022, compiled_block_1_2022 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2024, compiled_block_1_2024 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 2024, compiled_block_1_2024 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_load( 3, 3 );
  twobit_global( 2 ); /*  array:not-in~1ayXVW~11629 */
  twobit_setrtn( 2025, compiled_block_1_2025 );
  twobit_invoke( 3 );
  twobit_label( 2025, compiled_block_1_2025 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_pop( 3 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_97( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_store( 3, 3 );
  twobit_movereg( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_global( 1 ); /*  array:good-indices.o?~1ayXVW~11625 */
  twobit_setrtn( 2027, compiled_block_1_2027 );
  twobit_invoke( 2 );
  twobit_label( 2027, compiled_block_1_2027 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2029, compiled_block_1_2029 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 2029, compiled_block_1_2029 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* reverse */
  twobit_setrtn( 2030, compiled_block_1_2030 );
  twobit_invoke( 1 );
  twobit_label( 2030, compiled_block_1_2030 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),2031,compiled_block_1_2031); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_global( 2 ); /* reverse */
  twobit_setrtn( 2032, compiled_block_1_2032 );
  twobit_invoke( 1 );
  twobit_label( 2032, compiled_block_1_2032 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_load( 3, 3 );
  twobit_global( 3 ); /*  array:not-in~1ayXVW~11629 */
  twobit_setrtn( 2033, compiled_block_1_2033 );
  twobit_invoke( 3 );
  twobit_label( 2033, compiled_block_1_2033 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  error~1ayXVW~11537 */
  twobit_pop( 3 );
  twobit_invoke( 1 );
  twobit_label( 2031, compiled_block_1_2031 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_98( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_store( 3, 3 );
  twobit_movereg( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_global( 1 ); /*  array:good-index-vector?~1ayXVW~11626 */
  twobit_setrtn( 2035, compiled_block_1_2035 );
  twobit_invoke( 2 );
  twobit_label( 2035, compiled_block_1_2035 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2037, compiled_block_1_2037 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 2037, compiled_block_1_2037 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* vector->list */
  twobit_setrtn( 2038, compiled_block_1_2038 );
  twobit_invoke( 1 );
  twobit_label( 2038, compiled_block_1_2038 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_load( 3, 3 );
  twobit_global( 3 ); /*  array:not-in~1ayXVW~11629 */
  twobit_setrtn( 2039, compiled_block_1_2039 );
  twobit_invoke( 3 );
  twobit_label( 2039, compiled_block_1_2039 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  error~1ayXVW~11537 */
  twobit_pop( 3 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_99( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 2, 1 );
  twobit_store( 3, 4 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 2041, compiled_block_1_2041 );
  twobit_invoke( 1 );
  twobit_label( 2041, compiled_block_1_2041 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg_op2_check_662(reg(4),reg(3),2042,compiled_block_1_2042); /* internal:check-vector?/vector-length:vec with (4 0 0) */
  twobit_store( 3, 2 );
  twobit_reg( 3 );
  twobit_op2imm_451( fixnum(2) ); /* =:fix:fix */
  twobit_branchf( 2044, compiled_block_1_2044 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(3),2045,compiled_block_1_2045); /* internal:check-<:fix:fix with (0 4 0) */
  twobit_reg( 4 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_op2imm_134( fixnum(0), 173, compiled_temp_1_173 ); /* = */
  twobit_skip( 2043, compiled_block_1_2043 );
  twobit_label( 2044, compiled_block_1_2044 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2043, compiled_block_1_2043 );
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_branchf( 2047, compiled_block_1_2047 );
  twobit_skip( 2046, compiled_block_1_2046 );
  twobit_label( 2047, compiled_block_1_2047 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  error~1ayXVW~11537 */
  twobit_setrtn( 2048, compiled_block_1_2048 );
  twobit_invoke( 1 );
  twobit_label( 2048, compiled_block_1_2048 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_label( 2046, compiled_block_1_2046 );
  twobit_reg( 2 );
  twobit_load( 1, 1 );
  twobit_load( 4, 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_load( 3, 3 );
  twobit_check( 0, 3, 0, 2049, compiled_block_1_2049 );
  twobit_stack( 3 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_global( 4 ); /*  array:vector~1ayXVW~11573 */
  twobit_setrtn( 2050, compiled_block_1_2050 );
  twobit_invoke( 1 );
  twobit_label( 2050, compiled_block_1_2050 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 2051, compiled_block_1_2051 );
  twobit_invoke( 1 );
  twobit_label( 2051, compiled_block_1_2051 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 4, 4 );
  twobit_load( 2, 2 );
  twobit_load( 1, 5 );
  twobit_global( 6 ); /*  array:good-index-actor?~1ayXVW~11627 */
  twobit_setrtn( 2052, compiled_block_1_2052 );
  twobit_invoke( 4 );
  twobit_label( 2052, compiled_block_1_2052 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2054, compiled_block_1_2054 );
  twobit_reg( 4 );
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 2054, compiled_block_1_2054 );
  twobit_stack( 3 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_store( 1, 5 );
  twobit_global( 7 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_174, 9, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_setrtn( 2062, compiled_block_1_2062 );
  twobit_invoke( 2 );
  twobit_label( 2062, compiled_block_1_2062 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 6 );
  twobit_load( 3, 4 );
  twobit_global( 10 ); /*  array:not-in~1ayXVW~11629 */
  twobit_pop( 6 );
  twobit_invoke( 3 );
  twobit_label( 2049, compiled_block_1_2049 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 3, 1, 0, 160 );
  twobit_label( 2045, compiled_block_1_2045 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_label( 2042, compiled_block_1_2042 );
  twobit_trap( 4, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_174( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_639( fixnum(0), 175, compiled_temp_1_175, 2056, compiled_block_1_2056 ); /* internal:branchf-=/imm */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 2056, compiled_block_1_2056 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 2, 3 );
  twobit_reg( 1 );
  twobit_op2imm_131( fixnum(1), 176, compiled_temp_1_176 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 2057, compiled_block_1_2057 );
  twobit_invoke( 1 );
  twobit_label( 2057, compiled_block_1_2057 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 2 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 2058, compiled_block_1_2058 );
  twobit_invoke( 2 );
  twobit_label( 2058, compiled_block_1_2058 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  array:vector~1ayXVW~11573 */
  twobit_setrtn( 2059, compiled_block_1_2059 );
  twobit_invoke( 1 );
  twobit_label( 2059, compiled_block_1_2059 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 2 );
  twobit_check( 1, 4, 0, 2060, compiled_block_1_2060 );
  twobit_reg_op2_check_662(reg(4),reg(3),2060,compiled_block_1_2060); /* internal:check-vector?/vector-length:vec with (1 4 0) */
  twobit_stack( 2 );
  twobit_reg_op2_check_655(RESULT,reg(3),2060,compiled_block_1_2060); /* internal:check-<:fix:fix with (1 4 0) */
  twobit_stack( 2 );
  twobit_reg_op2imm_check_660(RESULT,fixnum(0),2060,compiled_block_1_2060); /* internal:check->=:fix:fix/imm with (1 4 0) */
  twobit_load( 3, 2 );
  twobit_reg( 4 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 2060, compiled_block_1_2060 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_100( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg_op2_check_662(reg(2),reg(4),2064,compiled_block_1_2064); /* internal:check-vector?/vector-length:vec with (2 0 0) */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_170, 3, 3 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_label( 2064, compiled_block_1_2064 );
  twobit_trap( 2, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_170( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_branchf_623( 4, 171, compiled_temp_1_171, 2066, compiled_block_1_2066 ); /* internal:branchf-= */
  twobit_reg( 3 );
  twobit_branchf( 2068, compiled_block_1_2068 );
  twobit_reg( 1 );
  twobit_op1_10(); /* null? */
  twobit_return();
  twobit_label( 2068, compiled_block_1_2068 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 2066, compiled_block_1_2066 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2070, compiled_block_1_2070 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_skip( 2069, compiled_block_1_2069 );
  twobit_label( 2070, compiled_block_1_2070 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 2069, compiled_block_1_2069 );
  twobit_setreg( 31 );
  twobit_store( 31, 1 );
  twobit_reg( 2 );
  twobit_op2imm_130( fixnum(2), 172, compiled_temp_1_172 ); /* + */
  twobit_setreg( 30 );
  twobit_store( 30, 2 );
  twobit_reg( 3 );
  twobit_branchf( 2072, compiled_block_1_2072 );
  twobit_reg( 4 );
  twobit_branchf( 2074, compiled_block_1_2074 );
  twobit_movereg( 2, 3 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:good-index?~1ayXVW~11628 */
  twobit_setrtn( 2075, compiled_block_1_2075 );
  twobit_invoke( 3 );
  twobit_label( 2075, compiled_block_1_2075 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_skip( 2071, compiled_block_1_2071 );
  twobit_label( 2074, compiled_block_1_2074 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_skip( 2071, compiled_block_1_2071 );
  twobit_label( 2072, compiled_block_1_2072 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_label( 2071, compiled_block_1_2071 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_101( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg_op2_check_662(reg(2),reg(4),2078,compiled_block_1_2078); /* internal:check-vector?/vector-length:vec with (2 0 0) */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_167, 3, 3 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_label( 2078, compiled_block_1_2078 );
  twobit_trap( 2, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_167( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_branchf_623( 4, 168, compiled_temp_1_168, 2080, compiled_block_1_2080 ); /* internal:branchf-= */
  twobit_reg( 3 );
  twobit_branchf( 2082, compiled_block_1_2082 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2084, compiled_block_1_2084 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_10(); /* null? */
  twobit_return();
  twobit_label( 2084, compiled_block_1_2084 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 2082, compiled_block_1_2082 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 2080, compiled_block_1_2080 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2086, compiled_block_1_2086 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_skip( 2085, compiled_block_1_2085 );
  twobit_label( 2086, compiled_block_1_2086 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 2085, compiled_block_1_2085 );
  twobit_setreg( 31 );
  twobit_store( 31, 1 );
  twobit_reg( 2 );
  twobit_op2imm_130( fixnum(2), 169, compiled_temp_1_169 ); /* + */
  twobit_setreg( 30 );
  twobit_store( 30, 2 );
  twobit_reg( 3 );
  twobit_branchf( 2088, compiled_block_1_2088 );
  twobit_reg( 4 );
  twobit_branchf( 2090, compiled_block_1_2090 );
  twobit_movereg( 2, 3 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:good-index?~1ayXVW~11628 */
  twobit_setrtn( 2091, compiled_block_1_2091 );
  twobit_invoke( 3 );
  twobit_label( 2091, compiled_block_1_2091 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_skip( 2087, compiled_block_1_2087 );
  twobit_label( 2090, compiled_block_1_2090 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_skip( 2087, compiled_block_1_2087 );
  twobit_label( 2088, compiled_block_1_2088 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_label( 2087, compiled_block_1_2087 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_102( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(2),reg(4),2094,compiled_block_1_2094); /* internal:check-vector?/vector-length:vec with (2 0 0) */
  twobit_reg_op2_check_662(reg(1),reg(3),2095,compiled_block_1_2095); /* internal:check-vector?/vector-length:vec with (1 0 0) */
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_op2_63( 3, 161, compiled_temp_1_161 ); /* * */
  twobit_op2_branchf_623( 4, 162, compiled_temp_1_162, 2097, compiled_block_1_2097 ); /* internal:branchf-= */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 31 );
  twobit_movereg( 31, 5 );
  twobit_lambda( compiled_start_1_163, 3, 5 );
  twobit_setreg( 4 );
  twobit_reg( 31 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 31 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_invoke( 3 );
  twobit_label( 2097, compiled_block_1_2097 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 2094, compiled_block_1_2094 );
  twobit_trap( 2, 0, 0, 162 );
  twobit_label( 2095, compiled_block_1_2095 );
  twobit_trap( 1, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_163( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_branchf_623( 4, 164, compiled_temp_1_164, 2099, compiled_block_1_2099 ); /* internal:branchf-= */
  twobit_reg( 3 );
  twobit_return();
  twobit_label( 2099, compiled_block_1_2099 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op2imm_130( fixnum(1), 165, compiled_temp_1_165 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 2 );
  twobit_op2imm_130( fixnum(2), 166, compiled_temp_1_166 ); /* + */
  twobit_setreg( 31 );
  twobit_store( 31, 2 );
  twobit_reg( 3 );
  twobit_branchf( 2101, compiled_block_1_2101 );
  twobit_movereg( 2, 3 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 30 );
  twobit_reg( 2 );
  twobit_check( 1, 30, 0, 2102, compiled_block_1_2102 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_op2_407( 2 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 30 );
  twobit_reg( 2 );
  twobit_check( 1, 30, 0, 2102, compiled_block_1_2102 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 30 );
  twobit_reg( 2 );
  twobit_check( 1, 30, 0, 2102, compiled_block_1_2102 );
  twobit_lexical( 0, 1 );
  twobit_op2_402( 1 ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  array:good-index?~1ayXVW~11628 */
  twobit_setrtn( 2103, compiled_block_1_2103 );
  twobit_invoke( 3 );
  twobit_label( 2103, compiled_block_1_2103 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_skip( 2100, compiled_block_1_2100 );
  twobit_label( 2101, compiled_block_1_2101 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_label( 2100, compiled_block_1_2100 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 5 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2102, compiled_block_1_2102 );
  twobit_trap( 30, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_103( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_reg_op2_check_662(reg(4),reg(31),2106,compiled_block_1_2106); /* internal:check-vector?/vector-length:vec with (4 0 0) */
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_op2_63( 1, 155, compiled_temp_1_155 ); /* * */
  twobit_op2_branchf_623( 31, 156, compiled_temp_1_156, 2108, compiled_block_1_2108 ); /* internal:branchf-= */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 31 );
  twobit_movereg( 31, 5 );
  twobit_lambda( compiled_start_1_157, 3, 5 );
  twobit_setreg( 4 );
  twobit_reg( 31 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 31 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_invoke( 3 );
  twobit_label( 2108, compiled_block_1_2108 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 2106, compiled_block_1_2106 );
  twobit_trap( 4, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_157( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_623( 4, 158, compiled_temp_1_158, 2110, compiled_block_1_2110 ); /* internal:branchf-= */
  twobit_reg( 3 );
  twobit_return();
  twobit_label( 2110, compiled_block_1_2110 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_reg( 1 );
  twobit_op2imm_130( fixnum(1), 159, compiled_temp_1_159 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 2 );
  twobit_op2imm_130( fixnum(2), 160, compiled_temp_1_160 ); /* + */
  twobit_setreg( 31 );
  twobit_store( 31, 3 );
  twobit_reg( 3 );
  twobit_branchf( 2112, compiled_block_1_2112 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 2113, compiled_block_1_2113 );
  twobit_invoke( 2 );
  twobit_label( 2113, compiled_block_1_2113 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_check( 4, 1, 0, 2114, compiled_block_1_2114 );
  twobit_lexical( 0, 2 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_check( 4, 1, 0, 2114, compiled_block_1_2114 );
  twobit_lexical( 0, 2 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_407( 2 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_check( 4, 1, 0, 2114, compiled_block_1_2114 );
  twobit_reg( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_check( 4, 1, 0, 2114, compiled_block_1_2114 );
  twobit_lexical( 0, 2 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  array:good-index?~1ayXVW~11628 */
  twobit_setrtn( 2115, compiled_block_1_2115 );
  twobit_invoke( 3 );
  twobit_label( 2115, compiled_block_1_2115 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_skip( 2111, compiled_block_1_2111 );
  twobit_label( 2112, compiled_block_1_2112 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_label( 2111, compiled_block_1_2111 );
  twobit_load( 1, 2 );
  twobit_load( 2, 3 );
  twobit_lexical( 0, 5 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 2114, compiled_block_1_2114 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_104( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 2119, compiled_block_1_2119 );
  twobit_reg( 1 );
  twobit_op1_25(); /* exact? */
  twobit_branchf( 2121, compiled_block_1_2121 );
  twobit_reg_op1_check_651(reg(3),2122,compiled_block_1_2122); /* internal:check-fixnum? with (3 2 0) */
  twobit_reg_op2_check_662(reg(2),reg(4),2122,compiled_block_1_2122); /* internal:check-vector?/vector-length:vec with (3 2 0) */
  twobit_reg_op2_check_661(reg(3),reg(4),2122,compiled_block_1_2122); /* internal:check-range with (3 2 0) */
  twobit_reg( 2 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_op2_branchf_622( 1, 153, compiled_temp_1_153, 2124, compiled_block_1_2124 ); /* internal:branchf-<= */
  twobit_reg( 3 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 3 );
  twobit_reg_op2_check_655(reg(3),reg(4),2122,compiled_block_1_2122); /* internal:check-<:fix:fix with (3 2 0) */
  twobit_reg( 2 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_66( 4, 154, compiled_temp_1_154 ); /* < */
  twobit_return();
  twobit_label( 2124, compiled_block_1_2124 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 2121, compiled_block_1_2121 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 2119, compiled_block_1_2119 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 2122, compiled_block_1_2122 );
  twobit_trap( 2, 3, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_105( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /*  array:shape-vector->string~1ayXVW~11631 */
  twobit_setrtn( 2125, compiled_block_1_2125 );
  twobit_invoke( 1 );
  twobit_label( 2125, compiled_block_1_2125 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  array:list->string~1ayXVW~11630 */
  twobit_setrtn( 2126, compiled_block_1_2126 );
  twobit_invoke( 1 );
  twobit_label( 2126, compiled_block_1_2126 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_movereg( 4, 5 );
  twobit_load( 1, 3 );
  twobit_const( 3 );
  twobit_setreg( 2 );
  twobit_const( 4 );
  twobit_setreg( 4 );
  twobit_global( 5 ); /* string-append */
  twobit_setrtn( 2127, compiled_block_1_2127 );
  twobit_invoke( 5 );
  twobit_label( 2127, compiled_block_1_2127 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  error~1ayXVW~11537 */
  twobit_pop( 3 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_106( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_152, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_152( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 2130, compiled_block_1_2130 ); /* internal:branchf-null? */
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 2130, compiled_block_1_2130 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg_op1_check_652(reg(2),2131,compiled_block_1_2131); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  array:thing->string~1ayXVW~11632 */
  twobit_setrtn( 2132, compiled_block_1_2132 );
  twobit_invoke( 1 );
  twobit_label( 2132, compiled_block_1_2132 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_global( 3 ); /* string-append */
  twobit_setrtn( 2133, compiled_block_1_2133 );
  twobit_invoke( 3 );
  twobit_label( 2133, compiled_block_1_2133 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 2131, compiled_block_1_2131 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_107( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_149, 3, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_149( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 2136, compiled_block_1_2136 );
  twobit_lexical( 0, 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_branchf_623( 4, 150, compiled_temp_1_150, 2138, compiled_block_1_2138 ); /* internal:branchf-= */
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 2138, compiled_block_1_2138 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 1 );
  twobit_store( 4, 2 );
  twobit_reg( 2 );
  twobit_op2imm_130( fixnum(2), 151, compiled_temp_1_151 ); /* + */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_reg( 2 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 31 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 2, 30, 0, 2139, compiled_block_1_2139 );
  twobit_reg( 2 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 31 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 2, 30, 0, 2139, compiled_block_1_2139 );
  twobit_reg( 2 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 31 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 2, 30, 0, 2139, compiled_block_1_2139 );
  twobit_lexical( 0, 1 );
  twobit_op2_402( 2 ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* number->string */
  twobit_setrtn( 2140, compiled_block_1_2140 );
  twobit_invoke( 1 );
  twobit_label( 2140, compiled_block_1_2140 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_stack( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_reg( 3 );
  twobit_op2_407( 2 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_check( 3, 1, 0, 2141, compiled_block_1_2141 );
  twobit_lexical( 0, 1 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* number->string */
  twobit_setrtn( 2142, compiled_block_1_2142 );
  twobit_invoke( 1 );
  twobit_label( 2142, compiled_block_1_2142 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 3 );
  twobit_movereg( 4, 5 );
  twobit_load( 1, 4 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 6 );
  twobit_const( 5 );
  twobit_setreg( 7 );
  twobit_global( 6 ); /* string-append */
  twobit_setrtn( 2143, compiled_block_1_2143 );
  twobit_invoke( 7 );
  twobit_label( 2143, compiled_block_1_2143 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 5 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 5 );
  twobit_invoke( 2 );
  twobit_label( 2139, compiled_block_1_2139 );
  twobit_trap( 30, 2, 0, 160 );
  twobit_label( 2141, compiled_block_1_2141 );
  twobit_trap( 1, 3, 0, 160 );
  twobit_label( 2136, compiled_block_1_2136 );
  twobit_trap( 4, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_108( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_18(); /* complex? */
  twobit_branchf( 2147, compiled_block_1_2147 );
  twobit_global( 1 ); /* number->string */
  twobit_invoke( 1 );
  twobit_label( 2147, compiled_block_1_2147 );
  twobit_reg( 1 );
  twobit_op1_17(); /* symbol? */
  twobit_branchf( 2150, compiled_block_1_2150 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 2 ); /* symbol->string */
  twobit_setrtn( 2151, compiled_block_1_2151 );
  twobit_invoke( 1 );
  twobit_label( 2151, compiled_block_1_2151 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* string-append */
  twobit_pop( 0 );
  twobit_invoke( 2 );
  twobit_label( 2150, compiled_block_1_2150 );
  twobit_reg( 1 );
  twobit_op1_branchf_615( 2154, compiled_block_1_2154 ); /* internal:branchf-char? */
  twobit_const( 5 );
  twobit_return();
  twobit_label( 2154, compiled_block_1_2154 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 2156, compiled_block_1_2156 );
  twobit_const( 6 );
  twobit_return();
  twobit_label( 2156, compiled_block_1_2156 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 7 ); /* list? */
  twobit_setrtn( 2157, compiled_block_1_2157 );
  twobit_invoke( 1 );
  twobit_label( 2157, compiled_block_1_2157 );
  twobit_load( 0, 0 );
  twobit_branchf( 2159, compiled_block_1_2159 );
  twobit_load( 1, 1 );
  twobit_global( 8 ); /* length */
  twobit_setrtn( 2160, compiled_block_1_2160 );
  twobit_invoke( 1 );
  twobit_label( 2160, compiled_block_1_2160 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* number->string */
  twobit_setrtn( 2161, compiled_block_1_2161 );
  twobit_invoke( 1 );
  twobit_label( 2161, compiled_block_1_2161 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_const( 10 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /* string-append */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_label( 2159, compiled_block_1_2159 );
  twobit_stack( 1 );
  twobit_op1_branchf_611( 2164, compiled_block_1_2164 ); /* internal:branchf-pair? */
  twobit_const( 11 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2164, compiled_block_1_2164 );
  twobit_load( 1, 1 );
  twobit_global( 12 ); /*  array?~1ayXVW~11602 */
  twobit_setrtn( 2165, compiled_block_1_2165 );
  twobit_invoke( 1 );
  twobit_label( 2165, compiled_block_1_2165 );
  twobit_load( 0, 0 );
  twobit_branchf( 2167, compiled_block_1_2167 );
  twobit_const( 13 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2167, compiled_block_1_2167 );
  twobit_stack( 1 );
  twobit_op1_41(); /* vector? */
  twobit_branchf( 2169, compiled_block_1_2169 );
  twobit_stack( 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* number->string */
  twobit_setrtn( 2170, compiled_block_1_2170 );
  twobit_invoke( 1 );
  twobit_label( 2170, compiled_block_1_2170 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /* string-append */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_label( 2169, compiled_block_1_2169 );
  twobit_stack( 1 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 2173, compiled_block_1_2173 );
  twobit_const( 15 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2173, compiled_block_1_2173 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_57( 4, 148, compiled_temp_1_148 ); /* eqv? */
  twobit_branchf( 2175, compiled_block_1_2175 );
  twobit_const( 16 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2175, compiled_block_1_2175 );
  twobit_stack( 1 );
  twobit_op2imm_branchf_640( TRUE_CONST, 2177, compiled_block_1_2177 ); /* internal:branchf-eq?/imm */
  twobit_const( 17 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2177, compiled_block_1_2177 );
  twobit_stack( 1 );
  twobit_op2imm_branchf_640( FALSE_CONST, 2179, compiled_block_1_2179 ); /* internal:branchf-eq?/imm */
  twobit_const( 18 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2179, compiled_block_1_2179 );
  twobit_const( 19 );
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_109( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_41(); /* vector? */
  twobit_branchf( 2181, compiled_block_1_2181 );
  twobit_reg_op1_check_651(reg(2),2182,compiled_block_1_2182); /* internal:check-fixnum? with (2 1 0) */
  twobit_reg( 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_reg_op2_check_661(reg(2),reg(4),2182,compiled_block_1_2182); /* internal:check-range with (2 1 0) */
  twobit_reg( 1 );
  twobit_op2_402( 2 ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 2181, compiled_block_1_2181 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 2183, compiled_block_1_2183 );
  twobit_invoke( 1 );
  twobit_label( 2183, compiled_block_1_2183 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 2 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 2184, compiled_block_1_2184 );
  twobit_invoke( 2 );
  twobit_label( 2184, compiled_block_1_2184 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 2 );
  twobit_global( 3 ); /*  array:vector~1ayXVW~11573 */
  twobit_setrtn( 2185, compiled_block_1_2185 );
  twobit_invoke( 1 );
  twobit_label( 2185, compiled_block_1_2185 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 1, 4, 0, 2186, compiled_block_1_2186 );
  twobit_reg_op2_check_662(reg(4),reg(3),2186,compiled_block_1_2186); /* internal:check-vector?/vector-length:vec with (1 4 0) */
  twobit_stack( 1 );
  twobit_reg_op2_check_655(RESULT,reg(3),2186,compiled_block_1_2186); /* internal:check-<:fix:fix with (1 4 0) */
  twobit_stack( 1 );
  twobit_reg_op2imm_check_660(RESULT,fixnum(0),2186,compiled_block_1_2186); /* internal:check->=:fix:fix/imm with (1 4 0) */
  twobit_load( 3, 1 );
  twobit_reg( 4 );
  twobit_op2_402( 3 ); /* vector-ref:trusted */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2182, compiled_block_1_2182 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_label( 2186, compiled_block_1_2186 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_110( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op1_41(); /* vector? */
  twobit_branchf( 2188, compiled_block_1_2188 );
  twobit_reg_op1_check_651(reg(2),2189,compiled_block_1_2189); /* internal:check-fixnum? with (3 2 1) */
  twobit_reg( 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_reg_op2_check_661(reg(2),reg(4),2189,compiled_block_1_2189); /* internal:check-range with (3 2 1) */
  twobit_reg( 1 );
  twobit_op3_403( 2, 3 ); /* vector-set!:trusted */
  twobit_return();
  twobit_label( 2188, compiled_block_1_2188 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_store( 3, 3 );
  twobit_global( 1 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 2190, compiled_block_1_2190 );
  twobit_invoke( 1 );
  twobit_label( 2190, compiled_block_1_2190 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 2 ); /*  array:actor-index~1ayXVW~11586 */
  twobit_setrtn( 2191, compiled_block_1_2191 );
  twobit_invoke( 2 );
  twobit_label( 2191, compiled_block_1_2191 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 2 );
  twobit_global( 3 ); /*  array:vector~1ayXVW~11573 */
  twobit_setrtn( 2192, compiled_block_1_2192 );
  twobit_invoke( 1 );
  twobit_label( 2192, compiled_block_1_2192 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 3, 1 );
  twobit_load( 2, 3 );
  twobit_check( 2, 3, 4, 2193, compiled_block_1_2193 );
  twobit_reg_op2_check_662(reg(4),reg(3),2193,compiled_block_1_2193); /* internal:check-vector?/vector-length:vec with (2 3 4) */
  twobit_stack( 1 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 3, 1 );
  twobit_check( 2, 3, 4, 2193, compiled_block_1_2193 );
  twobit_stack( 1 );
  twobit_reg_op2imm_check_660(RESULT,fixnum(0),2193,compiled_block_1_2193); /* internal:check->=:fix:fix/imm with (2 3 4) */
  twobit_reg( 4 );
  twobit_op3_403( 3, 2 ); /* vector-set!:trusted */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 2189, compiled_block_1_2189 );
  twobit_trap( 1, 2, 3, 161 );
  twobit_label( 2193, compiled_block_1_2193 );
  twobit_trap( 4, 3, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_111( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_41(); /* vector? */
  twobit_branchf( 2195, compiled_block_1_2195 );
  twobit_reg( 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_return();
  twobit_label( 2195, compiled_block_1_2195 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 2196, compiled_block_1_2196 );
  twobit_invoke( 1 );
  twobit_label( 2196, compiled_block_1_2196 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op2_check_662(reg(4),reg(3),2197,compiled_block_1_2197); /* internal:check-vector?/vector-length:vec with (0 4 0) */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(3),2197,compiled_block_1_2197); /* internal:check-<:fix:fix with (0 4 0) */
  twobit_reg( 4 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 2197, compiled_block_1_2197 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_112( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_global( 1 ); /*  array:grok/arguments~1ayXVW~11638 */
  twobit_setrtn( 2198, compiled_block_1_2198 );
  twobit_invoke( 2 );
  twobit_label( 2198, compiled_block_1_2198 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 2 ); /*  array:shape~1ayXVW~11575 */
  twobit_setrtn( 2199, compiled_block_1_2199 );
  twobit_invoke( 1 );
  twobit_label( 2199, compiled_block_1_2199 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op2_check_662(reg(4),reg(3),2200,compiled_block_1_2200); /* internal:check-vector?/vector-length:vec with (0 4 0) */
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(3),2200,compiled_block_1_2200); /* internal:check-<:fix:fix with (0 4 0) */
  twobit_reg( 4 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_142, 5, 4 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_const( 6 );
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2200, compiled_block_1_2200 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 1 );
  twobit_trap( 4, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_142( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_lexical( 0, 1 );
  twobit_op2_branchf_619( 3, 143, compiled_temp_1_143, 2202, compiled_block_1_2202 ); /* internal:branchf-< */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_144, 3, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_const( 4 );
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_invoke( 3 );
  twobit_label( 2202, compiled_block_1_2202 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 3, 1 );
  twobit_reg( 3 );
  twobit_op2imm_130( fixnum(1), 145, compiled_temp_1_145 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_global( 5 ); /* number->string */
  twobit_setrtn( 2210, compiled_block_1_2210 );
  twobit_invoke( 1 );
  twobit_label( 2210, compiled_block_1_2210 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_global( 7 ); /* string-append */
  twobit_setrtn( 2211, compiled_block_1_2211 );
  twobit_invoke( 4 );
  twobit_label( 2211, compiled_block_1_2211 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 3, 3 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_const( 8 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_144( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_lexical( 1, 4 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_branchf_623( 4, 146, compiled_temp_1_146, 2204, compiled_block_1_2204 ); /* internal:branchf-= */
  twobit_movereg( 1, 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_const( 1 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* string-append */
  twobit_invoke( 3 );
  twobit_label( 2204, compiled_block_1_2204 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_reg( 3 );
  twobit_op2imm_130( fixnum(1), 147, compiled_temp_1_147 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  array:map-column->string~1ayXVW~11637 */
  twobit_setrtn( 2206, compiled_block_1_2206 );
  twobit_invoke( 3 );
  twobit_label( 2206, compiled_block_1_2206 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 2 ); /* string-append */
  twobit_setrtn( 2207, compiled_block_1_2207 );
  twobit_invoke( 3 );
  twobit_label( 2207, compiled_block_1_2207 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 3, 3 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_113( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 4 );
  twobit_store( 3, 3 );
  twobit_global( 1 ); /*  array:index~1ayXVW~11574 */
  twobit_setrtn( 2214, compiled_block_1_2214 );
  twobit_invoke( 1 );
  twobit_label( 2214, compiled_block_1_2214 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  array:vector~1ayXVW~11573 */
  twobit_setrtn( 2215, compiled_block_1_2215 );
  twobit_invoke( 1 );
  twobit_label( 2215, compiled_block_1_2215 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  array:vector-index~1ayXVW~11582 */
  twobit_setrtn( 2216, compiled_block_1_2216 );
  twobit_invoke( 2 );
  twobit_label( 2216, compiled_block_1_2216 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 2217, compiled_block_1_2217 );
  twobit_stack( 1 );
  twobit_reg_op1_check_653(RESULT,2217,compiled_block_1_2217); /* internal:check-vector? with (4 1 0) */
  twobit_stack( 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_load( 2, 1 );
  twobit_check( 4, 2, 0, 2218, compiled_block_1_2218 );
  twobit_reg_op2imm_check_660(reg(4),fixnum(0),2218,compiled_block_1_2218); /* internal:check->=:fix:fix/imm with (4 2 0) */
  twobit_stack( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(0), 133, compiled_temp_1_133, 2220, compiled_block_1_2220 ); /* internal:branchf-=/imm */
  twobit_const( 4 );
  twobit_skip( 2219, compiled_block_1_2219 );
  twobit_label( 2220, compiled_block_1_2220 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* number->string */
  twobit_setrtn( 2221, compiled_block_1_2221 );
  twobit_invoke( 1 );
  twobit_label( 2221, compiled_block_1_2221 );
  twobit_load( 0, 0 );
  twobit_label( 2219, compiled_block_1_2219 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_global( 6 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 6, 4 );
  twobit_load( 5, 1 );
  twobit_load( 4, 5 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_134, 8, 6 );
  twobit_setreg( 4 );
  twobit_load( 2, 6 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_pop( 6 );
  twobit_invoke( 2 );
  twobit_label( 2218, compiled_block_1_2218 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_label( 2217, compiled_block_1_2217 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_134( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 6 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_622( 4, 135, compiled_temp_1_135, 2223, compiled_block_1_2223 ); /* internal:branchf-<= */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  array:vector-index~1ayXVW~11582 */
  twobit_setrtn( 2224, compiled_block_1_2224 );
  twobit_invoke( 2 );
  twobit_label( 2224, compiled_block_1_2224 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 2, 0, 2225, compiled_block_1_2225 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 2, 0, 2225, compiled_block_1_2225 );
  twobit_reg( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 1 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 4, 2, 0, 2225, compiled_block_1_2225 );
  twobit_lexical( 0, 5 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(0), 136, compiled_temp_1_136, 2227, compiled_block_1_2227 ); /* internal:branchf-=/imm */
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 137, compiled_temp_1_137 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 2227, compiled_block_1_2227 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(1), 138, compiled_temp_1_138, 2230, compiled_block_1_2230 ); /* internal:branchf-=/imm */
  twobit_const( 2 );
  twobit_skip( 2229, compiled_block_1_2229 );
  twobit_label( 2230, compiled_block_1_2230 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_639( fixnum(-1), 139, compiled_temp_1_139, 2232, compiled_block_1_2232 ); /* internal:branchf-=/imm */
  twobit_const( 3 );
  twobit_skip( 2229, compiled_block_1_2229 );
  twobit_label( 2232, compiled_block_1_2232 );
  twobit_movereg( 4, 1 );
  twobit_global( 4 ); /* number->string */
  twobit_setrtn( 2233, compiled_block_1_2233 );
  twobit_invoke( 1 );
  twobit_label( 2233, compiled_block_1_2233 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_const( 5 );
  twobit_setreg( 2 );
  twobit_global( 6 ); /* string-append */
  twobit_setrtn( 2234, compiled_block_1_2234 );
  twobit_invoke( 2 );
  twobit_label( 2234, compiled_block_1_2234 );
  twobit_load( 0, 0 );
  twobit_label( 2229, compiled_block_1_2229 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_global( 4 ); /* number->string */
  twobit_setrtn( 2235, compiled_block_1_2235 );
  twobit_invoke( 1 );
  twobit_label( 2235, compiled_block_1_2235 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 1, 3 );
  twobit_const( 7 );
  twobit_setreg( 2 );
  twobit_global( 6 ); /* string-append */
  twobit_setrtn( 2236, compiled_block_1_2236 );
  twobit_invoke( 3 );
  twobit_label( 2236, compiled_block_1_2236 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 2 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_global( 8 ); /* string=? */
  twobit_setrtn( 2237, compiled_block_1_2237 );
  twobit_invoke( 2 );
  twobit_label( 2237, compiled_block_1_2237 );
  twobit_load( 0, 0 );
  twobit_branchf( 2239, compiled_block_1_2239 );
  twobit_load( 2, 3 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 140, compiled_temp_1_140 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 2239, compiled_block_1_2239 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 141, compiled_temp_1_141 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 2 );
  twobit_const( 9 );
  twobit_setreg( 2 );
  twobit_load( 3, 3 );
  twobit_global( 6 ); /* string-append */
  twobit_setrtn( 2241, compiled_block_1_2241 );
  twobit_invoke( 3 );
  twobit_label( 2241, compiled_block_1_2241 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 2223, compiled_block_1_2223 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_global( 8 ); /* string=? */
  twobit_setrtn( 2243, compiled_block_1_2243 );
  twobit_invoke( 2 );
  twobit_label( 2243, compiled_block_1_2243 );
  twobit_load( 0, 0 );
  twobit_branchf( 2245, compiled_block_1_2245 );
  twobit_const( 10 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2245, compiled_block_1_2245 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2225, compiled_block_1_2225 );
  twobit_trap( 2, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_114( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lambda( compiled_start_1_131, 2, 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_80( 4 ); /* make-vector */
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  array:grok/index!~1ayXVW~11639 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_131( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_132, 2, 1 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* vector */
  twobit_setreg( 2 );
  twobit_global( 4 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_132( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  array:apply-to-vector~1ayXVW~11600 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_115( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  array:index-length~1ayXVW~11635 */
  twobit_setrtn( 2250, compiled_block_1_2250 );
  twobit_invoke( 1 );
  twobit_label( 2250, compiled_block_1_2250 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_116, 4, 3 );
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_op2_84( 1 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_setrtn( 2255, compiled_block_1_2255 );
  twobit_invoke( 1 );
  twobit_label( 2255, compiled_block_1_2255 );
  twobit_load( 0, 0 );
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 2256, compiled_block_1_2256 );
  twobit_invoke( 1 );
  twobit_label( 2256, compiled_block_1_2256 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /*  array:index-length~1ayXVW~11635 */
  twobit_setrtn( 2257, compiled_block_1_2257 );
  twobit_invoke( 1 );
  twobit_label( 2257, compiled_block_1_2257 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_stack( 3 );
  twobit_op2imm_130( fixnum(1), 117, compiled_temp_1_117 ); /* + */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_global( 5 ); /*  shape~1ayXVW~11605 */
  twobit_setrtn( 2258, compiled_block_1_2258 );
  twobit_invoke( 4 );
  twobit_label( 2258, compiled_block_1_2258 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  make-array~1ayXVW~11603 */
  twobit_setrtn( 2259, compiled_block_1_2259 );
  twobit_invoke( 1 );
  twobit_label( 2259, compiled_block_1_2259 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 2, 4 );
  twobit_load( 1, 5 );
  twobit_lambda( compiled_start_1_118, 8, 4 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_setrtn( 2265, compiled_block_1_2265 );
  twobit_invoke( 1 );
  twobit_label( 2265, compiled_block_1_2265 );
  twobit_load( 0, 0 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 7, 3 );
  twobit_load( 6, 2 );
  twobit_load( 5, 1 );
  twobit_load( 3, 6 );
  twobit_load( 2, 5 );
  twobit_load( 1, 4 );
  twobit_lambda( compiled_start_1_119, 10, 7 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 2279, compiled_block_1_2279 );
  twobit_invoke( 1 );
  twobit_label( 2279, compiled_block_1_2279 );
  twobit_load( 0, 0 );
  twobit_stack( 6 );
  twobit_pop( 6 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_116( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_623( 4, 129, compiled_temp_1_129, 2252, compiled_block_1_2252 ); /* internal:branchf-= */
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 2252, compiled_block_1_2252 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  array:index-set!~1ayXVW~11634 */
  twobit_setrtn( 2253, compiled_block_1_2253 );
  twobit_invoke( 3 );
  twobit_label( 2253, compiled_block_1_2253 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 130, compiled_temp_1_130 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_118( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_623( 4, 127, compiled_temp_1_127, 2261, compiled_block_1_2261 ); /* internal:branchf-= */
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 2261, compiled_block_1_2261 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  array:index-ref~1ayXVW~11633 */
  twobit_setrtn( 2262, compiled_block_1_2262 );
  twobit_invoke( 2 );
  twobit_label( 2262, compiled_block_1_2262 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  array-set!~1ayXVW~11577 */
  twobit_setrtn( 2263, compiled_block_1_2263 );
  twobit_invoke( 4 );
  twobit_label( 2263, compiled_block_1_2263 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 128, compiled_temp_1_128 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_119( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 7 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_623( 4, 120, compiled_temp_1_120, 2267, compiled_block_1_2267 ); /* internal:branchf-= */
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 2267, compiled_block_1_2267 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  array:index-set!~1ayXVW~11634 */
  twobit_setrtn( 2268, compiled_block_1_2268 );
  twobit_invoke( 3 );
  twobit_label( 2268, compiled_block_1_2268 );
  twobit_load( 0, 0 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 6 );
  twobit_setrtn( 2269, compiled_block_1_2269 );
  twobit_invoke( 1 );
  twobit_label( 2269, compiled_block_1_2269 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  array:index-set!~1ayXVW~11634 */
  twobit_setrtn( 2270, compiled_block_1_2270 );
  twobit_invoke( 3 );
  twobit_label( 2270, compiled_block_1_2270 );
  twobit_load( 0, 0 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_load( 2, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_121, 4, 3 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 2277, compiled_block_1_2277 );
  twobit_invoke( 1 );
  twobit_label( 2277, compiled_block_1_2277 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 122, compiled_temp_1_122 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 0, 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_121( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_623( 4, 123, compiled_temp_1_123, 2272, compiled_block_1_2272 ); /* internal:branchf-= */
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 2272, compiled_block_1_2272 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 3 );
  twobit_op2imm_130( fixnum(1), 124, compiled_temp_1_124 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  array:index-ref~1ayXVW~11633 */
  twobit_setrtn( 2273, compiled_block_1_2273 );
  twobit_invoke( 2 );
  twobit_label( 2273, compiled_block_1_2273 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 2, 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  array:index-ref~1ayXVW~11633 */
  twobit_setrtn( 2274, compiled_block_1_2274 );
  twobit_invoke( 2 );
  twobit_label( 2274, compiled_block_1_2274 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_load( 3, 1 );
  twobit_stack( 3 );
  twobit_op2_62( 4, 125, compiled_temp_1_125 ); /* - */
  twobit_setreg( 4 );
  twobit_lexical( 1, 3 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  array-set!~1ayXVW~11577 */
  twobit_setrtn( 2275, compiled_block_1_2275 );
  twobit_invoke( 4 );
  twobit_label( 2275, compiled_block_1_2275 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 126, compiled_temp_1_126 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


RTYPE twobit_thunk_5d26bd4c72f30db04dcc1ea3b0708b00_0(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_1_0(CONT_ACTUALS));
}
static RTYPE compiled_block_2_1004( CONT_PARAMS );
static RTYPE compiled_block_2_1003( CONT_PARAMS );
static RTYPE compiled_start_2_0( CONT_PARAMS );
static RTYPE compiled_start_2_3( CONT_PARAMS );
static RTYPE compiled_start_2_2( CONT_PARAMS );
static RTYPE compiled_start_2_1( CONT_PARAMS );

static RTYPE compiled_start_2_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_2_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_2_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1003, compiled_block_2_1003 );
  twobit_invoke( 8 );
  twobit_label( 1003, compiled_block_2_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1004, compiled_block_2_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_2_1004 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_5d26bd4c72f30db04dcc1ea3b0708b00_1(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_2_0(CONT_ACTUALS));
}
codeptr_t CDECL twobit_load_table[] = { 
  twobit_thunk_5d26bd4c72f30db04dcc1ea3b0708b00_0,
  twobit_thunk_5d26bd4c72f30db04dcc1ea3b0708b00_1,
  0  /* The table may be empty; some compilers complain */
};

/* Generated from /proj/will/pnkfelix/larcenytest/larceny-petit-Nightly-2009-08-19/larceny_src/lib/SRFI/srfi/%3a69.slfasl */
#include "petit-instr.h"

static RTYPE compiled_block_1_1004( CONT_PARAMS );
static RTYPE compiled_block_1_1003( CONT_PARAMS );
static RTYPE compiled_start_1_0( CONT_PARAMS );
static RTYPE compiled_start_1_3( CONT_PARAMS );
static RTYPE compiled_start_1_2( CONT_PARAMS );
static RTYPE compiled_start_1_1( CONT_PARAMS );

static RTYPE compiled_start_1_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1003, compiled_block_1_1003 );
  twobit_invoke( 8 );
  twobit_label( 1003, compiled_block_1_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1004, compiled_block_1_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_1_1004 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_2df901ee37ff4db439fa91b02efd9458_0(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_1_0(CONT_ACTUALS));
}
static RTYPE compiled_block_2_1218( CONT_PARAMS );
static RTYPE compiled_block_2_1217( CONT_PARAMS );
static RTYPE compiled_start_2_0( CONT_PARAMS );
static RTYPE compiled_block_2_1093( CONT_PARAMS );
static RTYPE compiled_block_2_1092( CONT_PARAMS );
static RTYPE compiled_start_2_3( CONT_PARAMS );
static RTYPE compiled_block_2_1208( CONT_PARAMS );
static RTYPE compiled_block_2_1214( CONT_PARAMS );
static RTYPE compiled_temp_2_25( CONT_PARAMS );
static RTYPE compiled_block_2_1209( CONT_PARAMS );
static RTYPE compiled_block_2_1210( CONT_PARAMS );
static RTYPE compiled_block_2_1212( CONT_PARAMS );
static RTYPE compiled_block_2_1207( CONT_PARAMS );
static RTYPE compiled_block_2_1205( CONT_PARAMS );
static RTYPE compiled_start_2_24( CONT_PARAMS );
static RTYPE compiled_block_2_1196( CONT_PARAMS );
static RTYPE compiled_block_2_1202( CONT_PARAMS );
static RTYPE compiled_temp_2_26( CONT_PARAMS );
static RTYPE compiled_block_2_1197( CONT_PARAMS );
static RTYPE compiled_block_2_1198( CONT_PARAMS );
static RTYPE compiled_block_2_1200( CONT_PARAMS );
static RTYPE compiled_block_2_1195( CONT_PARAMS );
static RTYPE compiled_block_2_1193( CONT_PARAMS );
static RTYPE compiled_start_2_23( CONT_PARAMS );
static RTYPE compiled_block_2_1184( CONT_PARAMS );
static RTYPE compiled_block_2_1190( CONT_PARAMS );
static RTYPE compiled_temp_2_27( CONT_PARAMS );
static RTYPE compiled_block_2_1185( CONT_PARAMS );
static RTYPE compiled_block_2_1186( CONT_PARAMS );
static RTYPE compiled_block_2_1188( CONT_PARAMS );
static RTYPE compiled_block_2_1183( CONT_PARAMS );
static RTYPE compiled_block_2_1181( CONT_PARAMS );
static RTYPE compiled_start_2_22( CONT_PARAMS );
static RTYPE compiled_block_2_1172( CONT_PARAMS );
static RTYPE compiled_block_2_1178( CONT_PARAMS );
static RTYPE compiled_temp_2_30( CONT_PARAMS );
static RTYPE compiled_block_2_1173( CONT_PARAMS );
static RTYPE compiled_block_2_1174( CONT_PARAMS );
static RTYPE compiled_block_2_1176( CONT_PARAMS );
static RTYPE compiled_block_2_1171( CONT_PARAMS );
static RTYPE compiled_block_2_1138( CONT_PARAMS );
static RTYPE compiled_block_2_1169( CONT_PARAMS );
static RTYPE compiled_block_2_1157( CONT_PARAMS );
static RTYPE compiled_block_2_1168( CONT_PARAMS );
static RTYPE compiled_block_2_1165( CONT_PARAMS );
static RTYPE compiled_block_2_1167( CONT_PARAMS );
static RTYPE compiled_block_2_1166( CONT_PARAMS );
static RTYPE compiled_temp_2_29( CONT_PARAMS );
static RTYPE compiled_block_2_1161( CONT_PARAMS );
static RTYPE compiled_block_2_1162( CONT_PARAMS );
static RTYPE compiled_block_2_1164( CONT_PARAMS );
static RTYPE compiled_temp_2_28( CONT_PARAMS );
static RTYPE compiled_block_2_1160( CONT_PARAMS );
static RTYPE compiled_block_2_1158( CONT_PARAMS );
static RTYPE compiled_block_2_1154( CONT_PARAMS );
static RTYPE compiled_block_2_1151( CONT_PARAMS );
static RTYPE compiled_block_2_1148( CONT_PARAMS );
static RTYPE compiled_block_2_1149( CONT_PARAMS );
static RTYPE compiled_block_2_1146( CONT_PARAMS );
static RTYPE compiled_block_2_1143( CONT_PARAMS );
static RTYPE compiled_block_2_1140( CONT_PARAMS );
static RTYPE compiled_start_2_21( CONT_PARAMS );
static RTYPE compiled_block_2_1129( CONT_PARAMS );
static RTYPE compiled_block_2_1135( CONT_PARAMS );
static RTYPE compiled_temp_2_33( CONT_PARAMS );
static RTYPE compiled_block_2_1130( CONT_PARAMS );
static RTYPE compiled_block_2_1131( CONT_PARAMS );
static RTYPE compiled_block_2_1133( CONT_PARAMS );
static RTYPE compiled_block_2_1128( CONT_PARAMS );
static RTYPE compiled_block_2_1095( CONT_PARAMS );
static RTYPE compiled_block_2_1126( CONT_PARAMS );
static RTYPE compiled_block_2_1114( CONT_PARAMS );
static RTYPE compiled_block_2_1125( CONT_PARAMS );
static RTYPE compiled_block_2_1122( CONT_PARAMS );
static RTYPE compiled_block_2_1124( CONT_PARAMS );
static RTYPE compiled_block_2_1123( CONT_PARAMS );
static RTYPE compiled_temp_2_32( CONT_PARAMS );
static RTYPE compiled_block_2_1118( CONT_PARAMS );
static RTYPE compiled_block_2_1119( CONT_PARAMS );
static RTYPE compiled_block_2_1121( CONT_PARAMS );
static RTYPE compiled_temp_2_31( CONT_PARAMS );
static RTYPE compiled_block_2_1117( CONT_PARAMS );
static RTYPE compiled_block_2_1115( CONT_PARAMS );
static RTYPE compiled_block_2_1111( CONT_PARAMS );
static RTYPE compiled_block_2_1108( CONT_PARAMS );
static RTYPE compiled_block_2_1105( CONT_PARAMS );
static RTYPE compiled_block_2_1106( CONT_PARAMS );
static RTYPE compiled_block_2_1103( CONT_PARAMS );
static RTYPE compiled_block_2_1100( CONT_PARAMS );
static RTYPE compiled_block_2_1097( CONT_PARAMS );
static RTYPE compiled_start_2_20( CONT_PARAMS );
static RTYPE compiled_start_2_19( CONT_PARAMS );
static RTYPE compiled_start_2_18( CONT_PARAMS );
static RTYPE compiled_block_2_1089( CONT_PARAMS );
static RTYPE compiled_start_2_17( CONT_PARAMS );
static RTYPE compiled_start_2_34( CONT_PARAMS );
static RTYPE compiled_start_2_16( CONT_PARAMS );
static RTYPE compiled_start_2_15( CONT_PARAMS );
static RTYPE compiled_block_2_1084( CONT_PARAMS );
static RTYPE compiled_start_2_36( CONT_PARAMS );
static RTYPE compiled_start_2_35( CONT_PARAMS );
static RTYPE compiled_start_2_14( CONT_PARAMS );
static RTYPE compiled_block_2_1074( CONT_PARAMS );
static RTYPE compiled_start_2_38( CONT_PARAMS );
static RTYPE compiled_block_2_1078( CONT_PARAMS );
static RTYPE compiled_block_2_1077( CONT_PARAMS );
static RTYPE compiled_block_2_1079( CONT_PARAMS );
static RTYPE compiled_temp_2_41( CONT_PARAMS );
static RTYPE compiled_block_2_1076( CONT_PARAMS );
static RTYPE compiled_temp_2_40( CONT_PARAMS );
static RTYPE compiled_start_2_39( CONT_PARAMS );
static RTYPE compiled_start_2_37( CONT_PARAMS );
static RTYPE compiled_start_2_13( CONT_PARAMS );
static RTYPE compiled_start_2_43( CONT_PARAMS );
static RTYPE compiled_start_2_42( CONT_PARAMS );
static RTYPE compiled_start_2_12( CONT_PARAMS );
static RTYPE compiled_start_2_45( CONT_PARAMS );
static RTYPE compiled_start_2_44( CONT_PARAMS );
static RTYPE compiled_block_2_1065( CONT_PARAMS );
static RTYPE compiled_start_2_11( CONT_PARAMS );
static RTYPE compiled_block_2_1063( CONT_PARAMS );
static RTYPE compiled_block_2_1062( CONT_PARAMS );
static RTYPE compiled_start_2_10( CONT_PARAMS );
static RTYPE compiled_block_2_1060( CONT_PARAMS );
static RTYPE compiled_block_2_1059( CONT_PARAMS );
static RTYPE compiled_start_2_9( CONT_PARAMS );
static RTYPE compiled_block_2_1057( CONT_PARAMS );
static RTYPE compiled_block_2_1053( CONT_PARAMS );
static RTYPE compiled_block_2_1055( CONT_PARAMS );
static RTYPE compiled_block_2_1051( CONT_PARAMS );
static RTYPE compiled_start_2_8( CONT_PARAMS );
static RTYPE compiled_block_2_1050( CONT_PARAMS );
static RTYPE compiled_block_2_1048( CONT_PARAMS );
static RTYPE compiled_block_2_1047( CONT_PARAMS );
static RTYPE compiled_block_2_1045( CONT_PARAMS );
static RTYPE compiled_start_2_7( CONT_PARAMS );
static RTYPE compiled_start_2_6( CONT_PARAMS );
static RTYPE compiled_block_2_1043( CONT_PARAMS );
static RTYPE compiled_block_2_1040( CONT_PARAMS );
static RTYPE compiled_block_2_1039( CONT_PARAMS );
static RTYPE compiled_start_2_5( CONT_PARAMS );
static RTYPE compiled_block_2_1041( CONT_PARAMS );
static RTYPE compiled_start_2_46( CONT_PARAMS );
static RTYPE compiled_block_2_1024( CONT_PARAMS );
static RTYPE compiled_block_2_1005( CONT_PARAMS );
static RTYPE compiled_block_2_1026( CONT_PARAMS );
static RTYPE compiled_block_2_1035( CONT_PARAMS );
static RTYPE compiled_block_2_1032( CONT_PARAMS );
static RTYPE compiled_block_2_1033( CONT_PARAMS );
static RTYPE compiled_block_2_1030( CONT_PARAMS );
static RTYPE compiled_block_2_1027( CONT_PARAMS );
static RTYPE compiled_block_2_1028( CONT_PARAMS );
static RTYPE compiled_block_2_1007( CONT_PARAMS );
static RTYPE compiled_block_2_1021( CONT_PARAMS );
static RTYPE compiled_block_2_1018( CONT_PARAMS );
static RTYPE compiled_block_2_1015( CONT_PARAMS );
static RTYPE compiled_block_2_1012( CONT_PARAMS );
static RTYPE compiled_block_2_1009( CONT_PARAMS );
static RTYPE compiled_block_2_1003( CONT_PARAMS );
static RTYPE compiled_start_2_4( CONT_PARAMS );
static RTYPE compiled_start_2_2( CONT_PARAMS );
static RTYPE compiled_start_2_1( CONT_PARAMS );

static RTYPE compiled_start_2_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 2 ); /*  hash-by-identity~1ayXVW~36086 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 3 ); /*  string-ci-hash~1ayXVW~36085 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 4 ); /*  string-hash~1ayXVW~36084 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 5 ); /*  hash~1ayXVW~36083 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 6 ); /*  %srfi69:hash-on-eqv~1ayXVW~36082 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 7 ); /*  %srfi69:hash-on-eq~1ayXVW~36081 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 8 ); /*  %srfi69:eqv-table~1ayXVW~36080 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 9 ); /*  %srfi69:eq-table~1ayXVW~36079 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 10 ); /*  %srfi69:modulus~1ayXVW~36078 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 11 ); /*  %srfi69:increment~1ayXVW~36077 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 12 ); /*  %srfi69:counter~1ayXVW~36076 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 13 ); /*  %srfi69:missing~1ayXVW~36075 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 14 ); /*  %srfi69:error:missing~1ayXVW~36074 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 15 ); /*  %srfi69:error~1ayXVW~36073 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 16 ); /*  hash-table-merge!~1ayXVW~36072 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 17 ); /*  hash-table-copy~1ayXVW~36071 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 18 ); /*  hash-table->alist~1ayXVW~36070 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 19 ); /*  hash-table-fold~1ayXVW~36069 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 20 ); /*  hash-table-walk~1ayXVW~36068 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 21 ); /*  hash-table-values~1ayXVW~36067 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 22 ); /*  hash-table-keys~1ayXVW~36066 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 23 ); /*  hash-table-size~1ayXVW~36065 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 24 ); /*  hash-table-update!/default~1ayXVW~36064 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 25 ); /*  hash-table-update!~1ayXVW~36063 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 26 ); /*  hash-table-exists?~1ayXVW~36062 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 27 ); /*  hash-table-delete!~1ayXVW~36061 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 28 ); /*  hash-table-set!~1ayXVW~36060 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 29 ); /*  hash-table-ref/default~1ayXVW~36059 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 30 ); /*  hash-table-ref~1ayXVW~36058 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 31 ); /*  hash-table-hash-function~1ayXVW~36057 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 32 ); /*  hash-table-equivalence-function~1ayXVW~36056 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 33 ); /*  alist->hash-table~1ayXVW~36055 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 34 ); /*  hash-table?~1ayXVW~36054 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 35 ); /*  make-hash-table~1ayXVW~36053 */
  twobit_lambda( compiled_start_2_1, 37, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_2_2, 39, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_2_3, 41, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 42 );
  twobit_setreg( 1 );
  twobit_const( 43 );
  twobit_setreg( 3 );
  twobit_const( 44 );
  twobit_setreg( 4 );
  twobit_const( 45 );
  twobit_setreg( 5 );
  twobit_const( 46 );
  twobit_setreg( 8 );
  twobit_global( 47 ); /* ex:make-library */
  twobit_setrtn( 1217, compiled_block_2_1217 );
  twobit_invoke( 8 );
  twobit_label( 1217, compiled_block_2_1217 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 48 ); /* ex:register-library! */
  twobit_setrtn( 1218, compiled_block_2_1218 );
  twobit_invoke( 1 );
  twobit_label( 1218, compiled_block_2_1218 );
  twobit_load( 0, 0 );
  twobit_global( 49 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 2 ); /*  hash-by-identity~1ayXVW~36086 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 3 ); /*  string-ci-hash~1ayXVW~36085 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 4 ); /*  string-hash~1ayXVW~36084 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 5 ); /*  hash~1ayXVW~36083 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 6 ); /*  %srfi69:hash-on-eqv~1ayXVW~36082 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 7 ); /*  %srfi69:hash-on-eq~1ayXVW~36081 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 8 ); /*  %srfi69:eqv-table~1ayXVW~36080 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 9 ); /*  %srfi69:eq-table~1ayXVW~36079 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 10 ); /*  %srfi69:modulus~1ayXVW~36078 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 11 ); /*  %srfi69:increment~1ayXVW~36077 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 12 ); /*  %srfi69:counter~1ayXVW~36076 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 13 ); /*  %srfi69:missing~1ayXVW~36075 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 14 ); /*  %srfi69:error:missing~1ayXVW~36074 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 15 ); /*  %srfi69:error~1ayXVW~36073 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 16 ); /*  hash-table-merge!~1ayXVW~36072 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 17 ); /*  hash-table-copy~1ayXVW~36071 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 18 ); /*  hash-table->alist~1ayXVW~36070 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 19 ); /*  hash-table-fold~1ayXVW~36069 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 20 ); /*  hash-table-walk~1ayXVW~36068 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 21 ); /*  hash-table-values~1ayXVW~36067 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 22 ); /*  hash-table-keys~1ayXVW~36066 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 23 ); /*  hash-table-size~1ayXVW~36065 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 24 ); /*  hash-table-update!/default~1ayXVW~36064 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 25 ); /*  hash-table-update!~1ayXVW~36063 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 26 ); /*  hash-table-exists?~1ayXVW~36062 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 27 ); /*  hash-table-delete!~1ayXVW~36061 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 28 ); /*  hash-table-set!~1ayXVW~36060 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 29 ); /*  hash-table-ref/default~1ayXVW~36059 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 30 ); /*  hash-table-ref~1ayXVW~36058 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 31 ); /*  hash-table-hash-function~1ayXVW~36057 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 32 ); /*  hash-table-equivalence-function~1ayXVW~36056 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 33 ); /*  alist->hash-table~1ayXVW~36055 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 34 ); /*  hash-table?~1ayXVW~36054 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 35 ); /*  make-hash-table~1ayXVW~36053 */
  twobit_lambda( compiled_start_2_4, 37, 0 );
  twobit_setglbl( 35 ); /*  make-hash-table~1ayXVW~36053 */
  twobit_global( 38 ); /* hashtable? */
  twobit_setglbl( 34 ); /*  hash-table?~1ayXVW~36054 */
  twobit_lambda( compiled_start_2_5, 40, 0 );
  twobit_setglbl( 33 ); /*  alist->hash-table~1ayXVW~36055 */
  twobit_lambda( compiled_start_2_6, 42, 0 );
  twobit_setglbl( 32 ); /*  hash-table-equivalence-function~1ayXVW~36056 */
  twobit_lambda( compiled_start_2_7, 44, 0 );
  twobit_setglbl( 31 ); /*  hash-table-hash-function~1ayXVW~36057 */
  twobit_lambda( compiled_start_2_8, 46, 0 );
  twobit_setglbl( 30 ); /*  hash-table-ref~1ayXVW~36058 */
  twobit_global( 47 ); /* hashtable-ref */
  twobit_setglbl( 29 ); /*  hash-table-ref/default~1ayXVW~36059 */
  twobit_global( 48 ); /* hashtable-set! */
  twobit_setglbl( 28 ); /*  hash-table-set!~1ayXVW~36060 */
  twobit_global( 49 ); /* hashtable-delete! */
  twobit_setglbl( 27 ); /*  hash-table-delete!~1ayXVW~36061 */
  twobit_global( 50 ); /* hashtable-contains? */
  twobit_setglbl( 26 ); /*  hash-table-exists?~1ayXVW~36062 */
  twobit_lambda( compiled_start_2_9, 52, 0 );
  twobit_setglbl( 25 ); /*  hash-table-update!~1ayXVW~36063 */
  twobit_lambda( compiled_start_2_10, 54, 0 );
  twobit_setglbl( 24 ); /*  hash-table-update!/default~1ayXVW~36064 */
  twobit_global( 55 ); /* hashtable-size */
  twobit_setglbl( 23 ); /*  hash-table-size~1ayXVW~36065 */
  twobit_lambda( compiled_start_2_11, 57, 0 );
  twobit_setglbl( 22 ); /*  hash-table-keys~1ayXVW~36066 */
  twobit_lambda( compiled_start_2_12, 59, 0 );
  twobit_setglbl( 21 ); /*  hash-table-values~1ayXVW~36067 */
  twobit_lambda( compiled_start_2_13, 61, 0 );
  twobit_setglbl( 20 ); /*  hash-table-walk~1ayXVW~36068 */
  twobit_lambda( compiled_start_2_14, 63, 0 );
  twobit_setglbl( 19 ); /*  hash-table-fold~1ayXVW~36069 */
  twobit_lambda( compiled_start_2_15, 65, 0 );
  twobit_setglbl( 18 ); /*  hash-table->alist~1ayXVW~36070 */
  twobit_lambda( compiled_start_2_16, 67, 0 );
  twobit_setglbl( 17 ); /*  hash-table-copy~1ayXVW~36071 */
  twobit_lambda( compiled_start_2_17, 69, 0 );
  twobit_setglbl( 16 ); /*  hash-table-merge!~1ayXVW~36072 */
  twobit_lambda( compiled_start_2_18, 71, 0 );
  twobit_setglbl( 15 ); /*  %srfi69:error~1ayXVW~36073 */
  twobit_lambda( compiled_start_2_19, 73, 0 );
  twobit_setglbl( 14 ); /*  %srfi69:error:missing~1ayXVW~36074 */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_const( 74 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setglbl( 13 ); /*  %srfi69:missing~1ayXVW~36075 */
  twobit_imm_const( fixnum(14151210) ); /* 14151210 */
  twobit_setglbl( 12 ); /*  %srfi69:counter~1ayXVW~36076 */
  twobit_imm_const( fixnum(268421) ); /* 268421 */
  twobit_setglbl( 11 ); /*  %srfi69:increment~1ayXVW~36077 */
  twobit_imm_const( fixnum(300489088) ); /* 300489088 */
  twobit_setglbl( 10 ); /*  %srfi69:modulus~1ayXVW~36078 */
  twobit_global( 75 ); /* make-eq-hashtable */
  twobit_setrtn( 1092, compiled_block_2_1092 );
  twobit_invoke( 0 );
  twobit_label( 1092, compiled_block_2_1092 );
  twobit_load( 0, 0 );
  twobit_setglbl( 9 ); /*  %srfi69:eq-table~1ayXVW~36079 */
  twobit_global( 76 ); /* make-eqv-hashtable */
  twobit_setrtn( 1093, compiled_block_2_1093 );
  twobit_invoke( 0 );
  twobit_label( 1093, compiled_block_2_1093 );
  twobit_load( 0, 0 );
  twobit_setglbl( 8 ); /*  %srfi69:eqv-table~1ayXVW~36080 */
  twobit_lambda( compiled_start_2_20, 78, 0 );
  twobit_setglbl( 7 ); /*  %srfi69:hash-on-eq~1ayXVW~36081 */
  twobit_lambda( compiled_start_2_21, 80, 0 );
  twobit_setglbl( 6 ); /*  %srfi69:hash-on-eqv~1ayXVW~36082 */
  twobit_lambda( compiled_start_2_22, 82, 0 );
  twobit_setglbl( 5 ); /*  hash~1ayXVW~36083 */
  twobit_lambda( compiled_start_2_23, 84, 0 );
  twobit_setglbl( 4 ); /*  string-hash~1ayXVW~36084 */
  twobit_lambda( compiled_start_2_24, 86, 0 );
  twobit_setglbl( 3 ); /*  string-ci-hash~1ayXVW~36085 */
  twobit_global( 7 ); /*  %srfi69:hash-on-eq~1ayXVW~36081 */
  twobit_setglbl( 2 ); /*  hash-by-identity~1ayXVW~36086 */
  twobit_global( 87 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1003, compiled_block_2_1003 ); /* internal:branchf-null? */
  twobit_global( 1 ); /*  hash~1ayXVW~36083 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /* equal? */
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  make-hashtable~1ayXVW~3623 */
  twobit_invoke( 2 );
  twobit_label( 1003, compiled_block_2_1003 );
  twobit_reg_op1_check_652(reg(1),1005,compiled_block_2_1005); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_610( 1007, compiled_block_2_1007 ); /* internal:branchf-null? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_global( 4 ); /* eq? */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 1009, compiled_block_2_1009 ); /* internal:branchf-eq? */
  twobit_global( 5 ); /* make-eq-hashtable */
  twobit_invoke( 0 );
  twobit_label( 1009, compiled_block_2_1009 );
  twobit_global( 6 ); /* eqv? */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 1012, compiled_block_2_1012 ); /* internal:branchf-eq? */
  twobit_global( 7 ); /* make-eqv-hashtable */
  twobit_invoke( 0 );
  twobit_label( 1012, compiled_block_2_1012 );
  twobit_global( 2 ); /* equal? */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 1015, compiled_block_2_1015 ); /* internal:branchf-eq? */
  twobit_global( 1 ); /*  hash~1ayXVW~36083 */
  twobit_setreg( 1 );
  twobit_movereg( 3, 2 );
  twobit_global( 3 ); /*  make-hashtable~1ayXVW~3623 */
  twobit_invoke( 2 );
  twobit_label( 1015, compiled_block_2_1015 );
  twobit_global( 8 ); /* string=? */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 1018, compiled_block_2_1018 ); /* internal:branchf-eq? */
  twobit_global( 9 ); /*  string-hash~1ayXVW~36084 */
  twobit_setreg( 1 );
  twobit_movereg( 3, 2 );
  twobit_global( 3 ); /*  make-hashtable~1ayXVW~3623 */
  twobit_invoke( 2 );
  twobit_label( 1018, compiled_block_2_1018 );
  twobit_global( 10 ); /* string-ci=? */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 1021, compiled_block_2_1021 ); /* internal:branchf-eq? */
  twobit_global( 11 ); /*  string-ci-hash~1ayXVW~36085 */
  twobit_setreg( 1 );
  twobit_movereg( 3, 2 );
  twobit_global( 3 ); /*  make-hashtable~1ayXVW~3623 */
  twobit_invoke( 2 );
  twobit_label( 1021, compiled_block_2_1021 );
  twobit_movereg( 1, 3 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_const( 13 );
  twobit_setreg( 2 );
  twobit_global( 14 ); /* assertion-violation */
  twobit_invoke( 3 );
  twobit_label( 1007, compiled_block_2_1007 );
  twobit_reg_op1_check_652(reg(4),1024,compiled_block_2_1024); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1026, compiled_block_2_1026 ); /* internal:branchf-null? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_global( 4 ); /* eq? */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2_branchf_624( 2, 1028, compiled_block_2_1028 ); /* internal:branchf-eq? */
  twobit_global( 15 ); /*  %srfi69:hash-on-eq~1ayXVW~36081 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_56( 2 ); /* eq? */
  twobit_skip( 1027, compiled_block_2_1027 );
  twobit_label( 1028, compiled_block_2_1028 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1027, compiled_block_2_1027 );
  twobit_branchf( 1030, compiled_block_2_1030 );
  twobit_global( 5 ); /* make-eq-hashtable */
  twobit_invoke( 0 );
  twobit_label( 1030, compiled_block_2_1030 );
  twobit_global( 6 ); /* eqv? */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2_branchf_624( 2, 1033, compiled_block_2_1033 ); /* internal:branchf-eq? */
  twobit_global( 16 ); /*  %srfi69:hash-on-eqv~1ayXVW~36082 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_56( 2 ); /* eq? */
  twobit_skip( 1032, compiled_block_2_1032 );
  twobit_label( 1033, compiled_block_2_1033 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1032, compiled_block_2_1032 );
  twobit_branchf( 1035, compiled_block_2_1035 );
  twobit_global( 7 ); /* make-eqv-hashtable */
  twobit_invoke( 0 );
  twobit_label( 1035, compiled_block_2_1035 );
  twobit_movereg( 4, 1 );
  twobit_movereg( 3, 2 );
  twobit_global( 3 ); /*  make-hashtable~1ayXVW~3623 */
  twobit_invoke( 2 );
  twobit_label( 1026, compiled_block_2_1026 );
  twobit_movereg( 1, 3 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_const( 17 );
  twobit_setreg( 2 );
  twobit_global( 14 ); /* assertion-violation */
  twobit_invoke( 3 );
  twobit_label( 1005, compiled_block_2_1005 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_label( 1024, compiled_block_2_1024 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* reverse */
  twobit_setrtn( 1039, compiled_block_2_1039 );
  twobit_invoke( 1 );
  twobit_label( 1039, compiled_block_2_1039 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_global( 2 ); /*  make-hash-table~1ayXVW~36053 */
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 3 ); /* apply */
  twobit_setrtn( 1040, compiled_block_2_1040 );
  twobit_invoke( 2 );
  twobit_label( 1040, compiled_block_2_1040 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 2, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_2_46, 5, 1 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  for-each~1ayXVW~1382 */
  twobit_setrtn( 1043, compiled_block_2_1043 );
  twobit_invoke( 2 );
  twobit_label( 1043, compiled_block_2_1043 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_46( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op1_check_652(reg(1),1041,compiled_block_2_1041); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* hashtable-set! */
  twobit_invoke( 3 );
  twobit_label( 1041, compiled_block_2_1041 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_6( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_global( 1 ); /* hashtable-equivalence-function */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_7( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* hashtable-hash-function */
  twobit_setrtn( 1045, compiled_block_2_1045 );
  twobit_invoke( 1 );
  twobit_label( 1045, compiled_block_2_1045 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1047, compiled_block_2_1047 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1047, compiled_block_2_1047 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* hashtable-equivalence-function */
  twobit_setrtn( 1048, compiled_block_2_1048 );
  twobit_invoke( 1 );
  twobit_label( 1048, compiled_block_2_1048 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_global( 3 ); /* eq? */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 1050, compiled_block_2_1050 ); /* internal:branchf-eq? */
  twobit_global( 4 ); /*  %srfi69:hash-on-eq~1ayXVW~36081 */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1050, compiled_block_2_1050 );
  twobit_global( 5 ); /*  %srfi69:hash-on-eqv~1ayXVW~36082 */
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_8( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 3 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  %srfi69:missing~1ayXVW~36075 */
  twobit_setreg( 3 );
  twobit_global( 2 ); /* hashtable-ref */
  twobit_setrtn( 1051, compiled_block_2_1051 );
  twobit_invoke( 3 );
  twobit_label( 1051, compiled_block_2_1051 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  %srfi69:missing~1ayXVW~36075 */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 1053, compiled_block_2_1053 ); /* internal:branchf-eq? */
  twobit_stack( 1 );
  twobit_op1_branchf_610( 1055, compiled_block_2_1055 ); /* internal:branchf-null? */
  twobit_load( 2, 2 );
  twobit_load( 3, 3 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  %srfi69:error:missing~1ayXVW~36074 */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1055, compiled_block_2_1055 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1057, compiled_block_2_1057 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 0 );
  twobit_label( 1053, compiled_block_2_1053 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1057, compiled_block_2_1057 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_9( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 3 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /*  hash-table-ref~1ayXVW~36058 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /* apply */
  twobit_setrtn( 1059, compiled_block_2_1059 );
  twobit_invoke( 4 );
  twobit_label( 1059, compiled_block_2_1059 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_stack( 1 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1060, compiled_block_2_1060 );
  twobit_invoke( 1 );
  twobit_label( 1060, compiled_block_2_1060 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 1, 2 );
  twobit_load( 2, 3 );
  twobit_global( 3 ); /*  hash-table-set!~1ayXVW~36060 */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_10( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 4, 3 );
  twobit_global( 1 ); /*  hash-table-ref/default~1ayXVW~36059 */
  twobit_setrtn( 1062, compiled_block_2_1062 );
  twobit_invoke( 3 );
  twobit_label( 1062, compiled_block_2_1062 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_stack( 1 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1063, compiled_block_2_1063 );
  twobit_invoke( 1 );
  twobit_label( 1063, compiled_block_2_1063 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 1, 2 );
  twobit_load( 2, 3 );
  twobit_global( 2 ); /*  hash-table-set!~1ayXVW~36060 */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_11( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* hashtable-keys */
  twobit_setrtn( 1065, compiled_block_2_1065 );
  twobit_invoke( 1 );
  twobit_label( 1065, compiled_block_2_1065 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* vector->list */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_12( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_2_44, 2, 1 );
  twobit_setreg( 1 );
  twobit_lambda( compiled_start_2_45, 4, 0 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_44( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* hashtable-entries */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_45( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /* vector->list */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_13( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_42, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_2_43, 4, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_42( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* hashtable-entries */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_43( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* vector-for-each */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_14( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_37, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_2_38, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_37( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* hashtable-entries */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_38( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1074,compiled_block_2_1074); /* internal:check-vector?/vector-length:vec with (1 0 0) */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_lambda( compiled_start_2_39, 3, 4 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 1074, compiled_block_2_1074 );
  twobit_trap( 1, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_39( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_623( 4, 40, compiled_temp_2_40, 1076, compiled_block_2_1076 ); /* internal:branchf-= */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1076, compiled_block_2_1076 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_movereg( 2, 3 );
  twobit_reg( 1 );
  twobit_op2imm_130( fixnum(1), 41, compiled_temp_2_41 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 31 );
  twobit_reg( 2 );
  twobit_check( 1, 31, 0, 1077, compiled_block_2_1077 );
  twobit_lexical( 0, 2 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 31 );
  twobit_reg( 2 );
  twobit_check( 1, 31, 0, 1077, compiled_block_2_1077 );
  twobit_lexical( 0, 2 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_op2_407( 2 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 31 );
  twobit_reg( 2 );
  twobit_check( 1, 31, 0, 1077, compiled_block_2_1077 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 31 );
  twobit_reg( 2 );
  twobit_check( 1, 31, 0, 1077, compiled_block_2_1077 );
  twobit_lexical( 0, 2 );
  twobit_op2_402( 1 ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 31 );
  twobit_reg( 1 );
  twobit_op2_407( 31 ); /* <:fix:fix */
  twobit_setreg( 31 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 1, 30, 0, 1078, compiled_block_2_1078 );
  twobit_lexical( 0, 1 );
  twobit_op2_402( 1 ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setrtn( 1079, compiled_block_2_1079 );
  twobit_invoke( 3 );
  twobit_label( 1079, compiled_block_2_1079 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1077, compiled_block_2_1077 );
  twobit_trap( 31, 1, 0, 160 );
  twobit_label( 1078, compiled_block_2_1078 );
  twobit_trap( 30, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_15( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_2_35, 2, 1 );
  twobit_setreg( 1 );
  twobit_lambda( compiled_start_2_36, 4, 0 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_35( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* hashtable-entries */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_36( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 2 ); /* vector-map */
  twobit_setrtn( 1084, compiled_block_2_1084 );
  twobit_invoke( 3 );
  twobit_label( 1084, compiled_block_2_1084 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* vector->list */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_16( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* hashtable-copy */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_17( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_lambda( compiled_start_2_34, 2, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  hash-table-walk~1ayXVW~36068 */
  twobit_setrtn( 1089, compiled_block_2_1089 );
  twobit_invoke( 2 );
  twobit_label( 1089, compiled_block_2_1089 );
  twobit_load( 0, 0 );
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_34( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  hash-table-set!~1ayXVW~36060 */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_18( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_global( 1 ); /* error */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_19( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 1 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* error */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_20( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1095, compiled_block_2_1095 ); /* internal:branchf-null? */
  twobit_reg( 1 );
  twobit_op1_17(); /* symbol? */
  twobit_branchf( 1097, compiled_block_2_1097 );
  twobit_global( 1 ); /* symbol-hash */
  twobit_invoke( 1 );
  twobit_label( 1097, compiled_block_2_1097 );
  twobit_reg( 1 );
  twobit_op1_branchf_614( 1100, compiled_block_2_1100 ); /* internal:branchf-fixnum? */
  twobit_global( 2 ); /* equal-hash */
  twobit_invoke( 1 );
  twobit_label( 1100, compiled_block_2_1100 );
  twobit_reg( 1 );
  twobit_op1_branchf_615( 1103, compiled_block_2_1103 ); /* internal:branchf-char? */
  twobit_global( 2 ); /* equal-hash */
  twobit_invoke( 1 );
  twobit_label( 1103, compiled_block_2_1103 );
  twobit_reg( 1 );
  twobit_op2imm_129( TRUE_CONST ); /* eq? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1106, compiled_block_2_1106 );
  twobit_reg( 4 );
  twobit_skip( 1105, compiled_block_2_1105 );
  twobit_label( 1106, compiled_block_2_1106 );
  twobit_reg( 1 );
  twobit_op2imm_129( FALSE_CONST ); /* eq? */
  twobit_label( 1105, compiled_block_2_1105 );
  twobit_branchf( 1108, compiled_block_2_1108 );
  twobit_global( 2 ); /* equal-hash */
  twobit_invoke( 1 );
  twobit_label( 1108, compiled_block_2_1108 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1111, compiled_block_2_1111 ); /* internal:branchf-null? */
  twobit_global( 2 ); /* equal-hash */
  twobit_invoke( 1 );
  twobit_label( 1111, compiled_block_2_1111 );
  twobit_global( 3 ); /*  %srfi69:eq-table~1ayXVW~36079 */
  twobit_branchf( 1114, compiled_block_2_1114 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_global( 3 ); /*  %srfi69:eq-table~1ayXVW~36079 */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_global( 4 ); /* hashtable-ref */
  twobit_setrtn( 1115, compiled_block_2_1115 );
  twobit_invoke( 3 );
  twobit_label( 1115, compiled_block_2_1115 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1117, compiled_block_2_1117 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1117, compiled_block_2_1117 );
  twobit_global( 5 ); /*  %srfi69:modulus~1ayXVW~36078 */
  twobit_setreg( 4 );
  twobit_global( 6 ); /*  %srfi69:increment~1ayXVW~36077 */
  twobit_setreg( 3 );
  twobit_global( 7 ); /*  %srfi69:counter~1ayXVW~36076 */
  twobit_op2_61( 3, 31, compiled_temp_2_31 ); /* + */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_614( 1119, compiled_block_2_1119 ); /* internal:branchf-fixnum? */
  twobit_reg( 4 );
  twobit_op1_branchf_614( 1121, compiled_block_2_1121 ); /* internal:branchf-fixnum? */
  twobit_reg( 2 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_skip( 1118, compiled_block_2_1118 );
  twobit_label( 1121, compiled_block_2_1121 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1118, compiled_block_2_1118 );
  twobit_label( 1119, compiled_block_2_1119 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1118, compiled_block_2_1118 );
  twobit_branchf( 1123, compiled_block_2_1123 );
  twobit_reg( 2 );
  twobit_op2_103( 4, 32, compiled_temp_2_32 ); /* remainder */
  twobit_skip( 1122, compiled_block_2_1122 );
  twobit_label( 1123, compiled_block_2_1123 );
  twobit_global( 8 ); /* mod */
  twobit_setreg( 1 );
  twobit_movereg( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_global( 9 ); /* apply */
  twobit_setrtn( 1124, compiled_block_2_1124 );
  twobit_invoke( 4 );
  twobit_label( 1124, compiled_block_2_1124 );
  twobit_load( 0, 0 );
  twobit_label( 1122, compiled_block_2_1122 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_setglbl( 7 ); /*  %srfi69:counter~1ayXVW~36076 */
  twobit_global( 3 ); /*  %srfi69:eq-table~1ayXVW~36079 */
  twobit_setreg( 1 );
  twobit_movereg( 4, 3 );
  twobit_global( 10 ); /* hashtable-set! */
  twobit_setrtn( 1125, compiled_block_2_1125 );
  twobit_invoke( 3 );
  twobit_label( 1125, compiled_block_2_1125 );
  twobit_load( 0, 0 );
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1114, compiled_block_2_1114 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 11 ); /* make-eq-hashtable */
  twobit_setrtn( 1126, compiled_block_2_1126 );
  twobit_invoke( 0 );
  twobit_label( 1126, compiled_block_2_1126 );
  twobit_load( 0, 0 );
  twobit_setglbl( 3 ); /*  %srfi69:eq-table~1ayXVW~36079 */
  twobit_load( 1, 1 );
  twobit_global( 12 ); /*  %srfi69:hash-on-eq~1ayXVW~36081 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1095, compiled_block_2_1095 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 12 ); /*  %srfi69:hash-on-eq~1ayXVW~36081 */
  twobit_setrtn( 1128, compiled_block_2_1128 );
  twobit_invoke( 1 );
  twobit_label( 1128, compiled_block_2_1128 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 2, 1 );
  twobit_check( 2, 0, 0, 1129, compiled_block_2_1129 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_614( 1131, compiled_block_2_1131 ); /* internal:branchf-fixnum? */
  twobit_reg( 3 );
  twobit_op1_branchf_614( 1133, compiled_block_2_1133 ); /* internal:branchf-fixnum? */
  twobit_reg( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_skip( 1130, compiled_block_2_1130 );
  twobit_label( 1133, compiled_block_2_1133 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1130, compiled_block_2_1130 );
  twobit_label( 1131, compiled_block_2_1131 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1130, compiled_block_2_1130 );
  twobit_branchf( 1135, compiled_block_2_1135 );
  twobit_reg( 4 );
  twobit_op2_103( 3, 33, compiled_temp_2_33 ); /* remainder */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1135, compiled_block_2_1135 );
  twobit_global( 8 ); /* mod */
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_global( 9 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 4 );
  twobit_label( 1129, compiled_block_2_1129 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_21( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1138, compiled_block_2_1138 ); /* internal:branchf-null? */
  twobit_reg( 1 );
  twobit_op1_17(); /* symbol? */
  twobit_branchf( 1140, compiled_block_2_1140 );
  twobit_global( 1 ); /* symbol-hash */
  twobit_invoke( 1 );
  twobit_label( 1140, compiled_block_2_1140 );
  twobit_reg( 1 );
  twobit_op1_18(); /* complex? */
  twobit_branchf( 1143, compiled_block_2_1143 );
  twobit_global( 2 ); /* equal-hash */
  twobit_invoke( 1 );
  twobit_label( 1143, compiled_block_2_1143 );
  twobit_reg( 1 );
  twobit_op1_branchf_615( 1146, compiled_block_2_1146 ); /* internal:branchf-char? */
  twobit_global( 2 ); /* equal-hash */
  twobit_invoke( 1 );
  twobit_label( 1146, compiled_block_2_1146 );
  twobit_reg( 1 );
  twobit_op2imm_129( TRUE_CONST ); /* eq? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1149, compiled_block_2_1149 );
  twobit_reg( 4 );
  twobit_skip( 1148, compiled_block_2_1148 );
  twobit_label( 1149, compiled_block_2_1149 );
  twobit_reg( 1 );
  twobit_op2imm_129( FALSE_CONST ); /* eq? */
  twobit_label( 1148, compiled_block_2_1148 );
  twobit_branchf( 1151, compiled_block_2_1151 );
  twobit_global( 2 ); /* equal-hash */
  twobit_invoke( 1 );
  twobit_label( 1151, compiled_block_2_1151 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1154, compiled_block_2_1154 ); /* internal:branchf-null? */
  twobit_global( 2 ); /* equal-hash */
  twobit_invoke( 1 );
  twobit_label( 1154, compiled_block_2_1154 );
  twobit_global( 3 ); /*  %srfi69:eqv-table~1ayXVW~36080 */
  twobit_branchf( 1157, compiled_block_2_1157 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_global( 3 ); /*  %srfi69:eqv-table~1ayXVW~36080 */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_global( 4 ); /* hashtable-ref */
  twobit_setrtn( 1158, compiled_block_2_1158 );
  twobit_invoke( 3 );
  twobit_label( 1158, compiled_block_2_1158 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1160, compiled_block_2_1160 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1160, compiled_block_2_1160 );
  twobit_global( 5 ); /*  %srfi69:modulus~1ayXVW~36078 */
  twobit_setreg( 4 );
  twobit_global( 6 ); /*  %srfi69:increment~1ayXVW~36077 */
  twobit_setreg( 3 );
  twobit_global( 7 ); /*  %srfi69:counter~1ayXVW~36076 */
  twobit_op2_61( 3, 28, compiled_temp_2_28 ); /* + */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_614( 1162, compiled_block_2_1162 ); /* internal:branchf-fixnum? */
  twobit_reg( 4 );
  twobit_op1_branchf_614( 1164, compiled_block_2_1164 ); /* internal:branchf-fixnum? */
  twobit_reg( 2 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_skip( 1161, compiled_block_2_1161 );
  twobit_label( 1164, compiled_block_2_1164 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1161, compiled_block_2_1161 );
  twobit_label( 1162, compiled_block_2_1162 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1161, compiled_block_2_1161 );
  twobit_branchf( 1166, compiled_block_2_1166 );
  twobit_reg( 2 );
  twobit_op2_103( 4, 29, compiled_temp_2_29 ); /* remainder */
  twobit_skip( 1165, compiled_block_2_1165 );
  twobit_label( 1166, compiled_block_2_1166 );
  twobit_global( 8 ); /* mod */
  twobit_setreg( 1 );
  twobit_movereg( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_global( 9 ); /* apply */
  twobit_setrtn( 1167, compiled_block_2_1167 );
  twobit_invoke( 4 );
  twobit_label( 1167, compiled_block_2_1167 );
  twobit_load( 0, 0 );
  twobit_label( 1165, compiled_block_2_1165 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_setglbl( 7 ); /*  %srfi69:counter~1ayXVW~36076 */
  twobit_global( 3 ); /*  %srfi69:eqv-table~1ayXVW~36080 */
  twobit_setreg( 1 );
  twobit_movereg( 4, 3 );
  twobit_global( 10 ); /* hashtable-set! */
  twobit_setrtn( 1168, compiled_block_2_1168 );
  twobit_invoke( 3 );
  twobit_label( 1168, compiled_block_2_1168 );
  twobit_load( 0, 0 );
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1157, compiled_block_2_1157 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 11 ); /* make-eqv-hashtable */
  twobit_setrtn( 1169, compiled_block_2_1169 );
  twobit_invoke( 0 );
  twobit_label( 1169, compiled_block_2_1169 );
  twobit_load( 0, 0 );
  twobit_setglbl( 3 ); /*  %srfi69:eqv-table~1ayXVW~36080 */
  twobit_load( 1, 1 );
  twobit_global( 12 ); /*  %srfi69:hash-on-eqv~1ayXVW~36082 */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1138, compiled_block_2_1138 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 12 ); /*  %srfi69:hash-on-eqv~1ayXVW~36082 */
  twobit_setrtn( 1171, compiled_block_2_1171 );
  twobit_invoke( 1 );
  twobit_label( 1171, compiled_block_2_1171 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 2, 1 );
  twobit_check( 2, 0, 0, 1172, compiled_block_2_1172 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_614( 1174, compiled_block_2_1174 ); /* internal:branchf-fixnum? */
  twobit_reg( 3 );
  twobit_op1_branchf_614( 1176, compiled_block_2_1176 ); /* internal:branchf-fixnum? */
  twobit_reg( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_skip( 1173, compiled_block_2_1173 );
  twobit_label( 1176, compiled_block_2_1176 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1173, compiled_block_2_1173 );
  twobit_label( 1174, compiled_block_2_1174 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1173, compiled_block_2_1173 );
  twobit_branchf( 1178, compiled_block_2_1178 );
  twobit_reg( 4 );
  twobit_op2_103( 3, 30, compiled_temp_2_30 ); /* remainder */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1178, compiled_block_2_1178 );
  twobit_global( 8 ); /* mod */
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_global( 9 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 4 );
  twobit_label( 1172, compiled_block_2_1172 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_22( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1181, compiled_block_2_1181 ); /* internal:branchf-null? */
  twobit_global( 1 ); /* equal-hash */
  twobit_invoke( 1 );
  twobit_label( 1181, compiled_block_2_1181 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* equal-hash */
  twobit_setrtn( 1183, compiled_block_2_1183 );
  twobit_invoke( 1 );
  twobit_label( 1183, compiled_block_2_1183 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 2, 1 );
  twobit_check( 2, 0, 0, 1184, compiled_block_2_1184 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_614( 1186, compiled_block_2_1186 ); /* internal:branchf-fixnum? */
  twobit_reg( 3 );
  twobit_op1_branchf_614( 1188, compiled_block_2_1188 ); /* internal:branchf-fixnum? */
  twobit_reg( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_skip( 1185, compiled_block_2_1185 );
  twobit_label( 1188, compiled_block_2_1188 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1185, compiled_block_2_1185 );
  twobit_label( 1186, compiled_block_2_1186 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1185, compiled_block_2_1185 );
  twobit_branchf( 1190, compiled_block_2_1190 );
  twobit_reg( 4 );
  twobit_op2_103( 3, 27, compiled_temp_2_27 ); /* remainder */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1190, compiled_block_2_1190 );
  twobit_global( 2 ); /* mod */
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_global( 3 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 4 );
  twobit_label( 1184, compiled_block_2_1184 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_23( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1193, compiled_block_2_1193 ); /* internal:branchf-null? */
  twobit_global( 1 ); /* string-hash */
  twobit_invoke( 1 );
  twobit_label( 1193, compiled_block_2_1193 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* string-hash */
  twobit_setrtn( 1195, compiled_block_2_1195 );
  twobit_invoke( 1 );
  twobit_label( 1195, compiled_block_2_1195 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 2, 1 );
  twobit_check( 2, 0, 0, 1196, compiled_block_2_1196 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_614( 1198, compiled_block_2_1198 ); /* internal:branchf-fixnum? */
  twobit_reg( 3 );
  twobit_op1_branchf_614( 1200, compiled_block_2_1200 ); /* internal:branchf-fixnum? */
  twobit_reg( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_skip( 1197, compiled_block_2_1197 );
  twobit_label( 1200, compiled_block_2_1200 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1197, compiled_block_2_1197 );
  twobit_label( 1198, compiled_block_2_1198 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1197, compiled_block_2_1197 );
  twobit_branchf( 1202, compiled_block_2_1202 );
  twobit_reg( 4 );
  twobit_op2_103( 3, 26, compiled_temp_2_26 ); /* remainder */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1202, compiled_block_2_1202 );
  twobit_global( 2 ); /* mod */
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_global( 3 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 4 );
  twobit_label( 1196, compiled_block_2_1196 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_24( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1205, compiled_block_2_1205 ); /* internal:branchf-null? */
  twobit_global( 1 ); /* string-ci-hash */
  twobit_invoke( 1 );
  twobit_label( 1205, compiled_block_2_1205 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* string-ci-hash */
  twobit_setrtn( 1207, compiled_block_2_1207 );
  twobit_invoke( 1 );
  twobit_label( 1207, compiled_block_2_1207 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 2, 1 );
  twobit_check( 2, 0, 0, 1208, compiled_block_2_1208 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_614( 1210, compiled_block_2_1210 ); /* internal:branchf-fixnum? */
  twobit_reg( 3 );
  twobit_op1_branchf_614( 1212, compiled_block_2_1212 ); /* internal:branchf-fixnum? */
  twobit_reg( 4 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_skip( 1209, compiled_block_2_1209 );
  twobit_label( 1212, compiled_block_2_1212 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1209, compiled_block_2_1209 );
  twobit_label( 1210, compiled_block_2_1210 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1209, compiled_block_2_1209 );
  twobit_branchf( 1214, compiled_block_2_1214 );
  twobit_reg( 4 );
  twobit_op2_103( 3, 25, compiled_temp_2_25 ); /* remainder */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1214, compiled_block_2_1214 );
  twobit_global( 2 ); /* mod */
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_global( 3 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 4 );
  twobit_label( 1208, compiled_block_2_1208 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_2df901ee37ff4db439fa91b02efd9458_1(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_2_0(CONT_ACTUALS));
}
static RTYPE compiled_block_3_1004( CONT_PARAMS );
static RTYPE compiled_block_3_1003( CONT_PARAMS );
static RTYPE compiled_start_3_0( CONT_PARAMS );
static RTYPE compiled_start_3_3( CONT_PARAMS );
static RTYPE compiled_start_3_2( CONT_PARAMS );
static RTYPE compiled_start_3_1( CONT_PARAMS );

static RTYPE compiled_start_3_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_3_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_3_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_3_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1003, compiled_block_3_1003 );
  twobit_invoke( 8 );
  twobit_label( 1003, compiled_block_3_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1004, compiled_block_3_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_3_1004 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_3_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_3_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_3_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_2df901ee37ff4db439fa91b02efd9458_2(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_3_0(CONT_ACTUALS));
}
codeptr_t CDECL twobit_load_table[] = { 
  twobit_thunk_2df901ee37ff4db439fa91b02efd9458_0,
  twobit_thunk_2df901ee37ff4db439fa91b02efd9458_1,
  twobit_thunk_2df901ee37ff4db439fa91b02efd9458_2,
  0  /* The table may be empty; some compilers complain */
};

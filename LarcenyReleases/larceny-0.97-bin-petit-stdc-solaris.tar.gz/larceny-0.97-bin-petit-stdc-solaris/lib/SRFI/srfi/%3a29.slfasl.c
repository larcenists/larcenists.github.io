/* Generated from /proj/will/pnkfelix/larcenytest/larceny-petit-Nightly-2009-08-19/larceny_src/lib/SRFI/srfi/%3a29.slfasl */
#include "petit-instr.h"

static RTYPE compiled_block_1_1146( CONT_PARAMS );
static RTYPE compiled_block_1_1145( CONT_PARAMS );
static RTYPE compiled_start_1_0( CONT_PARAMS );
static RTYPE compiled_start_1_3( CONT_PARAMS );
static RTYPE compiled_block_1_1143( CONT_PARAMS );
static RTYPE compiled_block_1_1142( CONT_PARAMS );
static RTYPE compiled_block_1_1140( CONT_PARAMS );
static RTYPE compiled_block_1_1139( CONT_PARAMS );
static RTYPE compiled_start_1_16( CONT_PARAMS );
static RTYPE compiled_block_1_1138( CONT_PARAMS );
static RTYPE compiled_block_1_1137( CONT_PARAMS );
static RTYPE compiled_block_1_1135( CONT_PARAMS );
static RTYPE compiled_block_1_1134( CONT_PARAMS );
static RTYPE compiled_start_1_15( CONT_PARAMS );
static RTYPE compiled_block_1_1055( CONT_PARAMS );
static RTYPE compiled_block_1_1054( CONT_PARAMS );
static RTYPE compiled_start_1_14( CONT_PARAMS );
static RTYPE compiled_block_1_1059( CONT_PARAMS );
static RTYPE compiled_block_1_1102( CONT_PARAMS );
static RTYPE compiled_block_1_1069( CONT_PARAMS );
static RTYPE compiled_block_1_1065( CONT_PARAMS );
static RTYPE compiled_block_1_1131( CONT_PARAMS );
static RTYPE compiled_block_1_1061( CONT_PARAMS );
static RTYPE compiled_block_1_1124( CONT_PARAMS );
static RTYPE compiled_block_1_1128( CONT_PARAMS );
static RTYPE compiled_block_1_1125( CONT_PARAMS );
static RTYPE compiled_block_1_1126( CONT_PARAMS );
static RTYPE compiled_block_1_1127( CONT_PARAMS );
static RTYPE compiled_block_1_1117( CONT_PARAMS );
static RTYPE compiled_block_1_1121( CONT_PARAMS );
static RTYPE compiled_block_1_1118( CONT_PARAMS );
static RTYPE compiled_block_1_1119( CONT_PARAMS );
static RTYPE compiled_block_1_1120( CONT_PARAMS );
static RTYPE compiled_block_1_1106( CONT_PARAMS );
static RTYPE compiled_block_1_1114( CONT_PARAMS );
static RTYPE compiled_block_1_1112( CONT_PARAMS );
static RTYPE compiled_block_1_1108( CONT_PARAMS );
static RTYPE compiled_block_1_1109( CONT_PARAMS );
static RTYPE compiled_block_1_1094( CONT_PARAMS );
static RTYPE compiled_block_1_1103( CONT_PARAMS );
static RTYPE compiled_block_1_1100( CONT_PARAMS );
static RTYPE compiled_block_1_1096( CONT_PARAMS );
static RTYPE compiled_block_1_1097( CONT_PARAMS );
static RTYPE compiled_block_1_1068( CONT_PARAMS );
static RTYPE compiled_block_1_1071( CONT_PARAMS );
static RTYPE compiled_block_1_1070( CONT_PARAMS );
static RTYPE compiled_block_1_1066( CONT_PARAMS );
static RTYPE compiled_block_1_1063( CONT_PARAMS );
static RTYPE compiled_block_1_1057( CONT_PARAMS );
static RTYPE compiled_start_1_17( CONT_PARAMS );
static RTYPE compiled_block_1_1075( CONT_PARAMS );
static RTYPE compiled_block_1_1083( CONT_PARAMS );
static RTYPE compiled_block_1_1086( CONT_PARAMS );
static RTYPE compiled_temp_1_20( CONT_PARAMS );
static RTYPE compiled_block_1_1090( CONT_PARAMS );
static RTYPE compiled_block_1_1089( CONT_PARAMS );
static RTYPE compiled_temp_1_19( CONT_PARAMS );
static RTYPE compiled_block_1_1085( CONT_PARAMS );
static RTYPE compiled_block_1_1087( CONT_PARAMS );
static RTYPE compiled_block_1_1081( CONT_PARAMS );
static RTYPE compiled_block_1_1082( CONT_PARAMS );
static RTYPE compiled_block_1_1079( CONT_PARAMS );
static RTYPE compiled_block_1_1076( CONT_PARAMS );
static RTYPE compiled_block_1_1077( CONT_PARAMS );
static RTYPE compiled_block_1_1073( CONT_PARAMS );
static RTYPE compiled_start_1_18( CONT_PARAMS );
static RTYPE compiled_block_1_1038( CONT_PARAMS );
static RTYPE compiled_block_1_1037( CONT_PARAMS );
static RTYPE compiled_start_1_13( CONT_PARAMS );
static RTYPE compiled_block_1_1047( CONT_PARAMS );
static RTYPE compiled_block_1_1048( CONT_PARAMS );
static RTYPE compiled_block_1_1043( CONT_PARAMS );
static RTYPE compiled_block_1_1051( CONT_PARAMS );
static RTYPE compiled_block_1_1050( CONT_PARAMS );
static RTYPE compiled_block_1_1046( CONT_PARAMS );
static RTYPE compiled_block_1_1044( CONT_PARAMS );
static RTYPE compiled_block_1_1041( CONT_PARAMS );
static RTYPE compiled_block_1_1040( CONT_PARAMS );
static RTYPE compiled_start_1_21( CONT_PARAMS );
static RTYPE compiled_block_1_1033( CONT_PARAMS );
static RTYPE compiled_block_1_1036( CONT_PARAMS );
static RTYPE compiled_block_1_1035( CONT_PARAMS );
static RTYPE compiled_start_1_12( CONT_PARAMS );
static RTYPE compiled_block_1_1031( CONT_PARAMS );
static RTYPE compiled_block_1_1030( CONT_PARAMS );
static RTYPE compiled_block_1_1028( CONT_PARAMS );
static RTYPE compiled_block_1_1026( CONT_PARAMS );
static RTYPE compiled_start_1_11( CONT_PARAMS );
static RTYPE compiled_block_1_1025( CONT_PARAMS );
static RTYPE compiled_start_1_10( CONT_PARAMS );
static RTYPE compiled_block_1_1019( CONT_PARAMS );
static RTYPE compiled_block_1_1020( CONT_PARAMS );
static RTYPE compiled_block_1_1024( CONT_PARAMS );
static RTYPE compiled_block_1_1023( CONT_PARAMS );
static RTYPE compiled_block_1_1021( CONT_PARAMS );
static RTYPE compiled_block_1_1018( CONT_PARAMS );
static RTYPE compiled_start_1_9( CONT_PARAMS );
static RTYPE compiled_start_1_8( CONT_PARAMS );
static RTYPE compiled_start_1_7( CONT_PARAMS );
static RTYPE compiled_block_1_1016( CONT_PARAMS );
static RTYPE compiled_block_1_1014( CONT_PARAMS );
static RTYPE compiled_block_1_1015( CONT_PARAMS );
static RTYPE compiled_start_1_6( CONT_PARAMS );
static RTYPE compiled_block_1_1013( CONT_PARAMS );
static RTYPE compiled_block_1_1008( CONT_PARAMS );
static RTYPE compiled_block_1_1009( CONT_PARAMS );
static RTYPE compiled_block_1_1012( CONT_PARAMS );
static RTYPE compiled_block_1_1011( CONT_PARAMS );
static RTYPE compiled_start_1_5( CONT_PARAMS );
static RTYPE compiled_block_1_1007( CONT_PARAMS );
static RTYPE compiled_block_1_1002( CONT_PARAMS );
static RTYPE compiled_block_1_1003( CONT_PARAMS );
static RTYPE compiled_block_1_1006( CONT_PARAMS );
static RTYPE compiled_block_1_1005( CONT_PARAMS );
static RTYPE compiled_start_1_4( CONT_PARAMS );
static RTYPE compiled_start_1_2( CONT_PARAMS );
static RTYPE compiled_start_1_1( CONT_PARAMS );

static RTYPE compiled_start_1_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 2 ); /*  store-bundle~1ayXVW~13667 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 3 ); /*  larceny/current-country~1ayXVW~13666 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 4 ); /*  larceny/current-language~1ayXVW~13665 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 5 ); /*  format~1ayXVW~13664 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 6 ); /*  localized-template~1ayXVW~13663 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 7 ); /*  declare-bundle!~1ayXVW~13662 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 8 ); /*  store-bundle!~1ayXVW~13661 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 9 ); /*  load-bundle!~1ayXVW~13660 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 10 ); /*  current-locale-details~1ayXVW~13659 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 11 ); /*  current-country~1ayXVW~13658 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 12 ); /*  current-language~1ayXVW~13657 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 13 ); /*  *localization-bundles*~1ayXVW~13656 */
  twobit_lambda( compiled_start_1_1, 15, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_2, 17, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_3, 19, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 20 );
  twobit_setreg( 1 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_const( 22 );
  twobit_setreg( 4 );
  twobit_const( 23 );
  twobit_setreg( 5 );
  twobit_const( 24 );
  twobit_setreg( 8 );
  twobit_global( 25 ); /* ex:make-library */
  twobit_setrtn( 1145, compiled_block_1_1145 );
  twobit_invoke( 8 );
  twobit_label( 1145, compiled_block_1_1145 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 26 ); /* ex:register-library! */
  twobit_setrtn( 1146, compiled_block_1_1146 );
  twobit_invoke( 1 );
  twobit_label( 1146, compiled_block_1_1146 );
  twobit_load( 0, 0 );
  twobit_global( 27 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 2 ); /*  store-bundle~1ayXVW~13667 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 3 ); /*  larceny/current-country~1ayXVW~13666 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 4 ); /*  larceny/current-language~1ayXVW~13665 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 5 ); /*  format~1ayXVW~13664 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 6 ); /*  localized-template~1ayXVW~13663 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 7 ); /*  declare-bundle!~1ayXVW~13662 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 8 ); /*  store-bundle!~1ayXVW~13661 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 9 ); /*  load-bundle!~1ayXVW~13660 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 10 ); /*  current-locale-details~1ayXVW~13659 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 11 ); /*  current-country~1ayXVW~13658 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 12 ); /*  current-language~1ayXVW~13657 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 13 ); /*  *localization-bundles*~1ayXVW~13656 */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setglbl( 13 ); /*  *localization-bundles*~1ayXVW~13656 */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_4, 15, 1 );
  twobit_setglbl( 12 ); /*  current-language~1ayXVW~13657 */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_5, 17, 1 );
  twobit_setglbl( 11 ); /*  current-country~1ayXVW~13658 */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_6, 19, 1 );
  twobit_setglbl( 10 ); /*  current-locale-details~1ayXVW~13659 */
  twobit_lambda( compiled_start_1_7, 21, 0 );
  twobit_setglbl( 9 ); /*  load-bundle!~1ayXVW~13660 */
  twobit_lambda( compiled_start_1_8, 23, 0 );
  twobit_setglbl( 8 ); /*  store-bundle!~1ayXVW~13661 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_9, 25, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_10, 27, 1 );
  twobit_setglbl( 7 ); /*  declare-bundle!~1ayXVW~13662 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_11, 29, 2 );
  twobit_setreg( 31 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_12, 31, 1 );
  twobit_setreg( 30 );
  twobit_reg( 3 );
  twobit_op2_84( 30 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op2_84( 31 ); /* cell-set! */
  twobit_movereg( 3, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_13, 33, 2 );
  twobit_setglbl( 6 ); /*  localized-template~1ayXVW~13663 */
  twobit_lambda( compiled_start_1_14, 35, 0 );
  twobit_setglbl( 5 ); /*  format~1ayXVW~13664 */
  twobit_lambda( compiled_start_1_15, 37, 0 );
  twobit_setglbl( 4 ); /*  larceny/current-language~1ayXVW~13665 */
  twobit_lambda( compiled_start_1_16, 39, 0 );
  twobit_setglbl( 3 ); /*  larceny/current-country~1ayXVW~13666 */
  twobit_global( 8 ); /*  store-bundle!~1ayXVW~13661 */
  twobit_setglbl( 2 ); /*  store-bundle~1ayXVW~13667 */
  twobit_global( 40 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1003, compiled_block_1_1003 ); /* internal:branchf-null? */
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_branchf( 1005, compiled_block_1_1005 );
  twobit_op1_3(); /* unspecified */
  twobit_skip( 1002, compiled_block_1_1002 );
  twobit_label( 1005, compiled_block_1_1005 );
  twobit_global( 1 ); /*  larceny/current-language~1ayXVW~13665 */
  twobit_setrtn( 1006, compiled_block_1_1006 );
  twobit_invoke( 0 );
  twobit_label( 1006, compiled_block_1_1006 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_skip( 1002, compiled_block_1_1002 );
  twobit_label( 1003, compiled_block_1_1003 );
  twobit_reg_op1_check_652(reg(1),1007,compiled_block_1_1007); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_label( 1002, compiled_block_1_1002 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1007, compiled_block_1_1007 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1009, compiled_block_1_1009 ); /* internal:branchf-null? */
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_branchf( 1011, compiled_block_1_1011 );
  twobit_op1_3(); /* unspecified */
  twobit_skip( 1008, compiled_block_1_1008 );
  twobit_label( 1011, compiled_block_1_1011 );
  twobit_global( 1 ); /*  larceny/current-country~1ayXVW~13666 */
  twobit_setrtn( 1012, compiled_block_1_1012 );
  twobit_invoke( 0 );
  twobit_label( 1012, compiled_block_1_1012 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_skip( 1008, compiled_block_1_1008 );
  twobit_label( 1009, compiled_block_1_1009 );
  twobit_reg_op1_check_652(reg(1),1013,compiled_block_1_1013); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_label( 1008, compiled_block_1_1008 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1013, compiled_block_1_1013 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_6( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1015, compiled_block_1_1015 ); /* internal:branchf-null? */
  twobit_op1_3(); /* unspecified */
  twobit_skip( 1014, compiled_block_1_1014 );
  twobit_label( 1015, compiled_block_1_1015 );
  twobit_reg_op1_check_652(reg(1),1016,compiled_block_1_1016); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_label( 1014, compiled_block_1_1014 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_return();
  twobit_label( 1016, compiled_block_1_1016 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_7( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_8( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_9( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1018, compiled_block_1_1018 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_label( 1018, compiled_block_1_1018 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_reg_op1_check_652(reg(2),1019,compiled_block_1_1019); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_movereg( 1, 2 );
  twobit_reg_op1_check_652(reg(4),1020,compiled_block_1_1020); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* equal? */
  twobit_setrtn( 1021, compiled_block_1_1021 );
  twobit_invoke( 2 );
  twobit_label( 1021, compiled_block_1_1021 );
  twobit_load( 0, 0 );
  twobit_branchf( 1023, compiled_block_1_1023 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1023, compiled_block_1_1023 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_load( 1, 2 );
  twobit_reg( 3 );
  twobit_setrtn( 1024, compiled_block_1_1024 );
  twobit_invoke( 2 );
  twobit_label( 1024, compiled_block_1_1024 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1020, compiled_block_1_1020 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 1019, compiled_block_1_1019 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_10( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_global( 1 ); /*  *localization-bundles*~1ayXVW~13656 */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1025, compiled_block_1_1025 );
  twobit_invoke( 2 );
  twobit_label( 1025, compiled_block_1_1025 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setglbl( 1 ); /*  *localization-bundles*~1ayXVW~13656 */
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_11( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_global( 1 ); /*  *localization-bundles*~1ayXVW~13656 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  assoc~1ayXVW~1405 */
  twobit_setrtn( 1026, compiled_block_1_1026 );
  twobit_invoke( 2 );
  twobit_label( 1026, compiled_block_1_1026 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1028, compiled_block_1_1028 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1028, compiled_block_1_1028 );
  twobit_stack( 1 );
  twobit_op1_branchf_610( 1030, compiled_block_1_1030 ); /* internal:branchf-null? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1030, compiled_block_1_1030 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1031, compiled_block_1_1031 );
  twobit_invoke( 1 );
  twobit_label( 1031, compiled_block_1_1031 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_12( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op1_check_652(reg(1),1033,compiled_block_1_1033); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_610( 1035, compiled_block_1_1035 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_label( 1035, compiled_block_1_1035 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_reg( 2 );
  twobit_setrtn( 1036, compiled_block_1_1036 );
  twobit_invoke( 1 );
  twobit_label( 1036, compiled_block_1_1036 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1033, compiled_block_1_1033 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_13( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 3 );
  twobit_global( 1 ); /*  current-language~1ayXVW~13657 */
  twobit_setrtn( 1037, compiled_block_1_1037 );
  twobit_invoke( 0 );
  twobit_label( 1037, compiled_block_1_1037 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_global( 2 ); /*  current-country~1ayXVW~13658 */
  twobit_setrtn( 1038, compiled_block_1_1038 );
  twobit_invoke( 0 );
  twobit_label( 1038, compiled_block_1_1038 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_21, 5, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_21( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1040, compiled_block_1_1040 ); /* internal:branchf-null? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1040, compiled_block_1_1040 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_setrtn( 1041, compiled_block_1_1041 );
  twobit_invoke( 2 );
  twobit_label( 1041, compiled_block_1_1041 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1043, compiled_block_1_1043 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 1 ); /* assq */
  twobit_setrtn( 1044, compiled_block_1_1044 );
  twobit_invoke( 2 );
  twobit_label( 1044, compiled_block_1_1044 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1046, compiled_block_1_1046 );
  twobit_reg_op1_check_652(reg(4),1047,compiled_block_1_1047); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1046, compiled_block_1_1046 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1048, compiled_block_1_1048 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1050, compiled_block_1_1050 ); /* internal:branchf-null? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1050, compiled_block_1_1050 );
  twobit_lexical( 1, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1051, compiled_block_1_1051 );
  twobit_invoke( 1 );
  twobit_label( 1051, compiled_block_1_1051 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1043, compiled_block_1_1043 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1048, compiled_block_1_1048 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_label( 1047, compiled_block_1_1047 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_14( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 4 );
  twobit_global( 1 ); /* open-output-string */
  twobit_setrtn( 1054, compiled_block_1_1054 );
  twobit_invoke( 0 );
  twobit_label( 1054, compiled_block_1_1054 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* string->list */
  twobit_setrtn( 1055, compiled_block_1_1055 );
  twobit_invoke( 1 );
  twobit_label( 1055, compiled_block_1_1055 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_store( 1, 3 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_17, 5, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_load( 2, 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_17( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1057, compiled_block_1_1057 ); /* internal:branchf-null? */
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* get-output-string */
  twobit_invoke( 1 );
  twobit_label( 1057, compiled_block_1_1057 );
  twobit_reg_op1_check_652(reg(1),1059,compiled_block_1_1059); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_641( int_to_char(126), 1061, compiled_block_1_1061 ); /* internal:branchf-char=?/imm */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_610( 1063, compiled_block_1_1063 ); /* internal:branchf-null? */
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 3 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1063, compiled_block_1_1063 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_store( 3, 4 );
  twobit_reg_op1_check_652(reg(4),1065,compiled_block_1_1065); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* char-numeric? */
  twobit_setrtn( 1066, compiled_block_1_1066 );
  twobit_invoke( 1 );
  twobit_label( 1066, compiled_block_1_1066 );
  twobit_load( 0, 0 );
  twobit_branchf( 1068, compiled_block_1_1068 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1069,compiled_block_1_1069); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 6 ); /* string */
  twobit_setrtn( 1070, compiled_block_1_1070 );
  twobit_invoke( 1 );
  twobit_label( 1070, compiled_block_1_1070 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /* string->number */
  twobit_setrtn( 1071, compiled_block_1_1071 );
  twobit_invoke( 1 );
  twobit_label( 1071, compiled_block_1_1071 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_store( 1, 3 );
  twobit_global( 8 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_18, 10, 2 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_movereg( 4, 2 );
  twobit_load( 4, 2 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 1068, compiled_block_1_1068 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1065,compiled_block_1_1065); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_imm_const( int_to_char(97) ); /* #\a */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 1094, compiled_block_1_1094 ); /* internal:branchf-eq? */
  twobit_stack( 4 );
  twobit_branchf( 1096, compiled_block_1_1096 );
  twobit_load( 1, 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_global( 11 ); /* display */
  twobit_setrtn( 1097, compiled_block_1_1097 );
  twobit_invoke( 2 );
  twobit_label( 1097, compiled_block_1_1097 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1069,compiled_block_1_1069); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 1096, compiled_block_1_1096 );
  twobit_stack( 2 );
  twobit_op1_branchf_610( 1100, compiled_block_1_1100 ); /* internal:branchf-null? */
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 12 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* error */
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 1100, compiled_block_1_1100 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 2 );
  twobit_check( 3, 0, 0, 1102, compiled_block_1_1102 );
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_global( 11 ); /* display */
  twobit_setrtn( 1103, compiled_block_1_1103 );
  twobit_invoke( 2 );
  twobit_label( 1103, compiled_block_1_1103 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1069,compiled_block_1_1069); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 1094, compiled_block_1_1094 );
  twobit_imm_const( int_to_char(115) ); /* #\s */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 1106, compiled_block_1_1106 ); /* internal:branchf-eq? */
  twobit_stack( 4 );
  twobit_branchf( 1108, compiled_block_1_1108 );
  twobit_load( 1, 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_global( 11 ); /* display */
  twobit_setrtn( 1109, compiled_block_1_1109 );
  twobit_invoke( 2 );
  twobit_label( 1109, compiled_block_1_1109 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1069,compiled_block_1_1069); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 1108, compiled_block_1_1108 );
  twobit_stack( 2 );
  twobit_op1_branchf_610( 1112, compiled_block_1_1112 ); /* internal:branchf-null? */
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 12 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* error */
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 1112, compiled_block_1_1112 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 2 );
  twobit_check( 3, 0, 0, 1102, compiled_block_1_1102 );
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_global( 13 ); /* write */
  twobit_setrtn( 1114, compiled_block_1_1114 );
  twobit_invoke( 2 );
  twobit_label( 1114, compiled_block_1_1114 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1069,compiled_block_1_1069); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 1106, compiled_block_1_1106 );
  twobit_imm_const( int_to_char(37) ); /* #\% */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 1117, compiled_block_1_1117 ); /* internal:branchf-eq? */
  twobit_stack( 4 );
  twobit_branchf( 1119, compiled_block_1_1119 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 14 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* error */
  twobit_setrtn( 1120, compiled_block_1_1120 );
  twobit_invoke( 2 );
  twobit_label( 1120, compiled_block_1_1120 );
  twobit_load( 0, 0 );
  twobit_skip( 1118, compiled_block_1_1118 );
  twobit_label( 1119, compiled_block_1_1119 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 1118, compiled_block_1_1118 );
  twobit_imm_const( int_to_char(10) ); /* #\newline */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_global( 11 ); /* display */
  twobit_setrtn( 1121, compiled_block_1_1121 );
  twobit_invoke( 2 );
  twobit_label( 1121, compiled_block_1_1121 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1069,compiled_block_1_1069); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 1117, compiled_block_1_1117 );
  twobit_imm_const( int_to_char(126) ); /* #\~ */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 1124, compiled_block_1_1124 ); /* internal:branchf-eq? */
  twobit_stack( 4 );
  twobit_branchf( 1126, compiled_block_1_1126 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 14 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* error */
  twobit_setrtn( 1127, compiled_block_1_1127 );
  twobit_invoke( 2 );
  twobit_label( 1127, compiled_block_1_1127 );
  twobit_load( 0, 0 );
  twobit_skip( 1125, compiled_block_1_1125 );
  twobit_label( 1126, compiled_block_1_1126 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 1125, compiled_block_1_1125 );
  twobit_imm_const( int_to_char(126) ); /* #\~ */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_global( 11 ); /* display */
  twobit_setrtn( 1128, compiled_block_1_1128 );
  twobit_invoke( 2 );
  twobit_label( 1128, compiled_block_1_1128 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1069,compiled_block_1_1069); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 1124, compiled_block_1_1124 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_const( 15 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* error */
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 1061, compiled_block_1_1061 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 4, 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_global( 11 ); /* display */
  twobit_setrtn( 1131, compiled_block_1_1131 );
  twobit_invoke( 2 );
  twobit_label( 1131, compiled_block_1_1131 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1065, compiled_block_1_1065 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 1069, compiled_block_1_1069 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_label( 1102, compiled_block_1_1102 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_label( 1059, compiled_block_1_1059 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_18( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1073, compiled_block_1_1073 ); /* internal:branchf-null? */
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1073, compiled_block_1_1073 );
  twobit_reg_op1_check_652(reg(1),1075,compiled_block_1_1075); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_imm_const( int_to_char(64) ); /* #\@ */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_56( 3 ); /* eq? */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_branchf( 1077, compiled_block_1_1077 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_10(); /* null? */
  twobit_skip( 1076, compiled_block_1_1076 );
  twobit_label( 1077, compiled_block_1_1077 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1076, compiled_block_1_1076 );
  twobit_branchf( 1079, compiled_block_1_1079 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /* error */
  twobit_invoke( 2 );
  twobit_label( 1079, compiled_block_1_1079 );
  twobit_reg( 3 );
  twobit_branchf( 1082, compiled_block_1_1082 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg_op1_check_652(reg(3),1083,compiled_block_1_1083); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_imm_const_setreg( int_to_char(42), 3 ); /* * */
  twobit_op2_56( 3 ); /* eq? */
  twobit_skip( 1081, compiled_block_1_1081 );
  twobit_label( 1082, compiled_block_1_1082 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1081, compiled_block_1_1081 );
  twobit_branchf( 1085, compiled_block_1_1085 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1086,compiled_block_1_1086); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* list-ref */
  twobit_setrtn( 1087, compiled_block_1_1087 );
  twobit_invoke( 2 );
  twobit_label( 1087, compiled_block_1_1087 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_label( 1085, compiled_block_1_1085 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_imm_const( fixnum(10) ); /* 10 */
  twobit_op2_63( 2, 19, compiled_temp_1_19 ); /* * */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* string */
  twobit_setrtn( 1089, compiled_block_1_1089 );
  twobit_invoke( 1 );
  twobit_label( 1089, compiled_block_1_1089 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /* string->number */
  twobit_setrtn( 1090, compiled_block_1_1090 );
  twobit_invoke( 1 );
  twobit_label( 1090, compiled_block_1_1090 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_stack( 2 );
  twobit_op2_61( 4, 20, compiled_temp_1_20 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1086, compiled_block_1_1086 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_label( 1083, compiled_block_1_1083 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_label( 1075, compiled_block_1_1075 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_15( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* system-features */
  twobit_setrtn( 1134, compiled_block_1_1134 );
  twobit_invoke( 0 );
  twobit_label( 1134, compiled_block_1_1134 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* assq */
  twobit_setrtn( 1135, compiled_block_1_1135 );
  twobit_invoke( 2 );
  twobit_label( 1135, compiled_block_1_1135 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1137, compiled_block_1_1137 );
  twobit_reg_op1_check_652(reg(4),1138,compiled_block_1_1138); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1137, compiled_block_1_1137 );
  twobit_const( 4 );
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1138, compiled_block_1_1138 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_16( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* system-features */
  twobit_setrtn( 1139, compiled_block_1_1139 );
  twobit_invoke( 0 );
  twobit_label( 1139, compiled_block_1_1139 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* assq */
  twobit_setrtn( 1140, compiled_block_1_1140 );
  twobit_invoke( 2 );
  twobit_label( 1140, compiled_block_1_1140 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1142, compiled_block_1_1142 );
  twobit_reg_op1_check_652(reg(4),1143,compiled_block_1_1143); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1142, compiled_block_1_1142 );
  twobit_const( 4 );
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1143, compiled_block_1_1143 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


RTYPE twobit_thunk_68defd73aedcf6c610242fd6cf0de85a_0(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_1_0(CONT_ACTUALS));
}
static RTYPE compiled_block_2_1004( CONT_PARAMS );
static RTYPE compiled_block_2_1003( CONT_PARAMS );
static RTYPE compiled_start_2_0( CONT_PARAMS );
static RTYPE compiled_start_2_3( CONT_PARAMS );
static RTYPE compiled_start_2_2( CONT_PARAMS );
static RTYPE compiled_start_2_1( CONT_PARAMS );

static RTYPE compiled_start_2_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_2_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_2_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1003, compiled_block_2_1003 );
  twobit_invoke( 8 );
  twobit_label( 1003, compiled_block_2_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1004, compiled_block_2_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_2_1004 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_68defd73aedcf6c610242fd6cf0de85a_1(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_2_0(CONT_ACTUALS));
}
codeptr_t CDECL twobit_load_table[] = { 
  twobit_thunk_68defd73aedcf6c610242fd6cf0de85a_0,
  twobit_thunk_68defd73aedcf6c610242fd6cf0de85a_1,
  0  /* The table may be empty; some compilers complain */
};

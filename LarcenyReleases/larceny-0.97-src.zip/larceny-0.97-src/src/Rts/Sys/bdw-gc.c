/* Copyright 1998 Lars T Hansen.
 * 
 * $Id: bdw-gc.c 2543 2005-07-20 21:54:03Z pnkfelix $
 *
 * Larceny run-time system -- wrapper for gc.c, with Boehm collector.
 */

#define BDW_GC
#include "gc.c"

/* eof */

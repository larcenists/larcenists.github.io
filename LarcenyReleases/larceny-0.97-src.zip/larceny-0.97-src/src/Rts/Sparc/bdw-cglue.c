/* Copyright 1998 Lars T Hansen.
 * 
 * $Id: bdw-cglue.c 2543 2005-07-20 21:54:03Z pnkfelix $
 *
 * Wrapper for Sparc/cglue.c, with Boehm collector.
 */

#define BDW_GC
#include "cglue.c"

/* eof */

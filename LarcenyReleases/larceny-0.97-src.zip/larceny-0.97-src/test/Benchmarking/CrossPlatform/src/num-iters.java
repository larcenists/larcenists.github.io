
class iters {
    public final int boyer_iters =       10;
    public final int browse_iters =     600;
    public final int conform_iters =     20;
    public final int cpstak_iters =     300;
    public final int ctak_iters =        30;
    public final int dderiv_iters =  800000;
    public final int deriv_iters =   800000;
    public final int destruc_iters =    300;
    public final int diviter_iters = 400000;
    public final int divrec_iters =  400000;
    public final int earley_iters =     150;
    public final int fft_iters =       2000;
    public final int fib_iters =         50;
    public final int fibfp_iters =       50;
    public final int maze_iters =      2500;
    public final int mazefun_iters =    100;
    public final int mbrot_iters =       30;
    public final int nucleic_iters =     10;
    public final int peval_iters =      100;
    public final int pnpoly_iters =   10000;
    public final int puzzle_iters =     100;
    public final int ray_iters =         10;
    public final int scheme_iters =    3000;
    public final int simplex_iters =  60000;
    public final int slatex_iters =      20;
    public final int sum_iters =      10000;
    public final int sumfp_iters =    10000;
    public final int tak_iters =       1000;
    public final int takl_iters =       200;
    public final int trav1_iters =       50;
    public final int trav2_iters =       10;
    public final int triangl_iters =     10;

    public final int smlboyer_iters =    10;
    public final int nboyer_iters =       3;
    public final int sboyer_iters =       3;
    public final int dynamic_iters =     10;
    public final int graphs_iters =      10;
    public final int lattice_iters =      1;
    public final int perm9_iters =        5;
}

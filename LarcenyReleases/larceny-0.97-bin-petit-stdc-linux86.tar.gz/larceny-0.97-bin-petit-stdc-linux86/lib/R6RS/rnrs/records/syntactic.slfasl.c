/* Generated from /home/henchman/larcenytest/larceny-petit-Nightly-2009-08-19/larceny_src/lib/R6RS/rnrs/records/syntactic.slfasl */
#include "petit-instr.h"

static RTYPE compiled_block_1_1012( CONT_PARAMS );
static RTYPE compiled_block_1_1011( CONT_PARAMS );
static RTYPE compiled_start_1_0( CONT_PARAMS );
static RTYPE compiled_block_1_1004( CONT_PARAMS );
static RTYPE compiled_start_1_3( CONT_PARAMS );
static RTYPE compiled_start_1_6( CONT_PARAMS );
static RTYPE compiled_block_1_1007( CONT_PARAMS );
static RTYPE compiled_block_1_1005( CONT_PARAMS );
static RTYPE compiled_start_1_5( CONT_PARAMS );
static RTYPE compiled_block_1_1002( CONT_PARAMS );
static RTYPE compiled_start_1_4( CONT_PARAMS );
static RTYPE compiled_start_1_2( CONT_PARAMS );
static RTYPE compiled_start_1_1( CONT_PARAMS );

static RTYPE compiled_start_1_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 2 ); /*  preferred-cd-set!~1ay%kV~2073 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 3 ); /*  preferred-cd~1ay%kV~2072 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 4 ); /*  preferred-cd-table~1ay%kV~2071 */
  twobit_lambda( compiled_start_1_1, 6, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_2, 8, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_3, 10, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_const( 13 );
  twobit_setreg( 4 );
  twobit_const( 14 );
  twobit_setreg( 5 );
  twobit_const( 15 );
  twobit_setreg( 8 );
  twobit_global( 16 ); /* ex:make-library */
  twobit_setrtn( 1011, compiled_block_1_1011 );
  twobit_invoke( 8 );
  twobit_label( 1011, compiled_block_1_1011 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 17 ); /* ex:register-library! */
  twobit_setrtn( 1012, compiled_block_1_1012 );
  twobit_invoke( 1 );
  twobit_label( 1012, compiled_block_1_1012 );
  twobit_load( 0, 0 );
  twobit_global( 18 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 2 ); /*  preferred-cd-set!~1ay%kV~2073 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 3 ); /*  preferred-cd~1ay%kV~2072 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 4 ); /*  preferred-cd-table~1ay%kV~2071 */
  twobit_lambda( compiled_start_1_4, 6, 0 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /* eqv? */
  twobit_setreg( 2 );
  twobit_global( 8 ); /* make-r6rs-hashtable */
  twobit_setrtn( 1004, compiled_block_1_1004 );
  twobit_invoke( 2 );
  twobit_label( 1004, compiled_block_1_1004 );
  twobit_load( 0, 0 );
  twobit_setglbl( 4 ); /*  preferred-cd-table~1ay%kV~2071 */
  twobit_lambda( compiled_start_1_5, 10, 0 );
  twobit_setglbl( 3 ); /*  preferred-cd~1ay%kV~2072 */
  twobit_lambda( compiled_start_1_6, 12, 0 );
  twobit_setglbl( 2 ); /*  preferred-cd-set!~1ay%kV~2073 */
  twobit_global( 13 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* record-type-name */
  twobit_setrtn( 1002, compiled_block_1_1002 );
  twobit_invoke( 1 );
  twobit_label( 1002, compiled_block_1_1002 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* symbol-hash */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /*  preferred-cd-table~1ay%kV~2071 */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_global( 2 ); /* hashtable-ref */
  twobit_setrtn( 1005, compiled_block_1_1005 );
  twobit_invoke( 3 );
  twobit_label( 1005, compiled_block_1_1005 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1007, compiled_block_1_1007 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1007, compiled_block_1_1007 );
  twobit_load( 1, 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 3 );
  twobit_global( 3 ); /* make-record-constructor-descriptor */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_6( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /*  preferred-cd-table~1ay%kV~2071 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /* hashtable-set! */
  twobit_invoke( 3 );
  twobit_epilogue();
}


RTYPE twobit_thunk_f93ad414f351d7d55a245a62a67f70db_0(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_1_0(CONT_ACTUALS));
}
static RTYPE compiled_block_2_2183( CONT_PARAMS );
static RTYPE compiled_block_2_2182( CONT_PARAMS );
static RTYPE compiled_start_2_0( CONT_PARAMS );
static RTYPE compiled_start_2_3( CONT_PARAMS );
static RTYPE compiled_start_2_5( CONT_PARAMS );
static RTYPE compiled_start_2_4( CONT_PARAMS );
static RTYPE compiled_block_2_2178( CONT_PARAMS );
static RTYPE compiled_block_2_2137( CONT_PARAMS );
static RTYPE compiled_block_2_2096( CONT_PARAMS );
static RTYPE compiled_block_2_2062( CONT_PARAMS );
static RTYPE compiled_block_2_2027( CONT_PARAMS );
static RTYPE compiled_block_2_1863( CONT_PARAMS );
static RTYPE compiled_block_2_1490( CONT_PARAMS );
static RTYPE compiled_block_2_1380( CONT_PARAMS );
static RTYPE compiled_block_2_1038( CONT_PARAMS );
static RTYPE compiled_start_2_2( CONT_PARAMS );
static RTYPE compiled_block_2_2161( CONT_PARAMS );
static RTYPE compiled_block_2_2163( CONT_PARAMS );
static RTYPE compiled_block_2_2165( CONT_PARAMS );
static RTYPE compiled_block_2_2167( CONT_PARAMS );
static RTYPE compiled_block_2_2169( CONT_PARAMS );
static RTYPE compiled_block_2_2172( CONT_PARAMS );
static RTYPE compiled_block_2_2171( CONT_PARAMS );
static RTYPE compiled_block_2_2170( CONT_PARAMS );
static RTYPE compiled_block_2_2138( CONT_PARAMS );
static RTYPE compiled_block_2_2141( CONT_PARAMS );
static RTYPE compiled_block_2_2143( CONT_PARAMS );
static RTYPE compiled_block_2_2145( CONT_PARAMS );
static RTYPE compiled_block_2_2147( CONT_PARAMS );
static RTYPE compiled_block_2_2150( CONT_PARAMS );
static RTYPE compiled_block_2_2152( CONT_PARAMS );
static RTYPE compiled_block_2_2153( CONT_PARAMS );
static RTYPE compiled_block_2_2148( CONT_PARAMS );
static RTYPE compiled_start_2_14( CONT_PARAMS );
static RTYPE compiled_block_2_2120( CONT_PARAMS );
static RTYPE compiled_block_2_2122( CONT_PARAMS );
static RTYPE compiled_block_2_2124( CONT_PARAMS );
static RTYPE compiled_block_2_2126( CONT_PARAMS );
static RTYPE compiled_block_2_2128( CONT_PARAMS );
static RTYPE compiled_block_2_2131( CONT_PARAMS );
static RTYPE compiled_block_2_2130( CONT_PARAMS );
static RTYPE compiled_block_2_2129( CONT_PARAMS );
static RTYPE compiled_block_2_2097( CONT_PARAMS );
static RTYPE compiled_block_2_2100( CONT_PARAMS );
static RTYPE compiled_block_2_2102( CONT_PARAMS );
static RTYPE compiled_block_2_2104( CONT_PARAMS );
static RTYPE compiled_block_2_2106( CONT_PARAMS );
static RTYPE compiled_block_2_2109( CONT_PARAMS );
static RTYPE compiled_block_2_2111( CONT_PARAMS );
static RTYPE compiled_block_2_2112( CONT_PARAMS );
static RTYPE compiled_block_2_2107( CONT_PARAMS );
static RTYPE compiled_start_2_13( CONT_PARAMS );
static RTYPE compiled_block_2_2083( CONT_PARAMS );
static RTYPE compiled_block_2_2085( CONT_PARAMS );
static RTYPE compiled_block_2_2087( CONT_PARAMS );
static RTYPE compiled_block_2_2089( CONT_PARAMS );
static RTYPE compiled_block_2_2091( CONT_PARAMS );
static RTYPE compiled_block_2_2090( CONT_PARAMS );
static RTYPE compiled_block_2_2063( CONT_PARAMS );
static RTYPE compiled_block_2_2066( CONT_PARAMS );
static RTYPE compiled_block_2_2068( CONT_PARAMS );
static RTYPE compiled_block_2_2070( CONT_PARAMS );
static RTYPE compiled_block_2_2073( CONT_PARAMS );
static RTYPE compiled_block_2_2075( CONT_PARAMS );
static RTYPE compiled_block_2_2076( CONT_PARAMS );
static RTYPE compiled_block_2_2071( CONT_PARAMS );
static RTYPE compiled_start_2_12( CONT_PARAMS );
static RTYPE compiled_block_2_2048( CONT_PARAMS );
static RTYPE compiled_block_2_2050( CONT_PARAMS );
static RTYPE compiled_block_2_2052( CONT_PARAMS );
static RTYPE compiled_block_2_2054( CONT_PARAMS );
static RTYPE compiled_block_2_2057( CONT_PARAMS );
static RTYPE compiled_block_2_2056( CONT_PARAMS );
static RTYPE compiled_block_2_2055( CONT_PARAMS );
static RTYPE compiled_block_2_2028( CONT_PARAMS );
static RTYPE compiled_block_2_2031( CONT_PARAMS );
static RTYPE compiled_block_2_2033( CONT_PARAMS );
static RTYPE compiled_block_2_2035( CONT_PARAMS );
static RTYPE compiled_block_2_2038( CONT_PARAMS );
static RTYPE compiled_block_2_2040( CONT_PARAMS );
static RTYPE compiled_block_2_2041( CONT_PARAMS );
static RTYPE compiled_block_2_2036( CONT_PARAMS );
static RTYPE compiled_start_2_11( CONT_PARAMS );
static RTYPE compiled_block_2_1995( CONT_PARAMS );
static RTYPE compiled_block_2_1997( CONT_PARAMS );
static RTYPE compiled_block_2_1999( CONT_PARAMS );
static RTYPE compiled_block_2_2001( CONT_PARAMS );
static RTYPE compiled_block_2_2004( CONT_PARAMS );
static RTYPE compiled_block_2_2006( CONT_PARAMS );
static RTYPE compiled_block_2_2009( CONT_PARAMS );
static RTYPE compiled_block_2_2011( CONT_PARAMS );
static RTYPE compiled_block_2_2013( CONT_PARAMS );
static RTYPE compiled_block_2_2017( CONT_PARAMS );
static RTYPE compiled_block_2_2016( CONT_PARAMS );
static RTYPE compiled_block_2_2015( CONT_PARAMS );
static RTYPE compiled_block_2_2014( CONT_PARAMS );
static RTYPE compiled_block_2_2007( CONT_PARAMS );
static RTYPE compiled_block_2_2002( CONT_PARAMS );
static RTYPE compiled_block_2_1867( CONT_PARAMS );
static RTYPE compiled_block_2_1962( CONT_PARAMS );
static RTYPE compiled_block_2_1964( CONT_PARAMS );
static RTYPE compiled_block_2_1966( CONT_PARAMS );
static RTYPE compiled_block_2_1968( CONT_PARAMS );
static RTYPE compiled_block_2_1970( CONT_PARAMS );
static RTYPE compiled_block_2_1973( CONT_PARAMS );
static RTYPE compiled_block_2_1975( CONT_PARAMS );
static RTYPE compiled_block_2_1978( CONT_PARAMS );
static RTYPE compiled_block_2_1980( CONT_PARAMS );
static RTYPE compiled_block_2_1984( CONT_PARAMS );
static RTYPE compiled_block_2_1983( CONT_PARAMS );
static RTYPE compiled_block_2_1982( CONT_PARAMS );
static RTYPE compiled_block_2_1981( CONT_PARAMS );
static RTYPE compiled_block_2_1976( CONT_PARAMS );
static RTYPE compiled_block_2_1971( CONT_PARAMS );
static RTYPE compiled_block_2_1866( CONT_PARAMS );
static RTYPE compiled_block_2_1932( CONT_PARAMS );
static RTYPE compiled_block_2_1934( CONT_PARAMS );
static RTYPE compiled_block_2_1936( CONT_PARAMS );
static RTYPE compiled_block_2_1938( CONT_PARAMS );
static RTYPE compiled_block_2_1940( CONT_PARAMS );
static RTYPE compiled_block_2_1943( CONT_PARAMS );
static RTYPE compiled_block_2_1945( CONT_PARAMS );
static RTYPE compiled_block_2_1947( CONT_PARAMS );
static RTYPE compiled_block_2_1952( CONT_PARAMS );
static RTYPE compiled_block_2_1951( CONT_PARAMS );
static RTYPE compiled_block_2_1950( CONT_PARAMS );
static RTYPE compiled_block_2_1949( CONT_PARAMS );
static RTYPE compiled_block_2_1948( CONT_PARAMS );
static RTYPE compiled_block_2_1941( CONT_PARAMS );
static RTYPE compiled_block_2_1865( CONT_PARAMS );
static RTYPE compiled_block_2_1907( CONT_PARAMS );
static RTYPE compiled_block_2_1909( CONT_PARAMS );
static RTYPE compiled_block_2_1911( CONT_PARAMS );
static RTYPE compiled_block_2_1913( CONT_PARAMS );
static RTYPE compiled_block_2_1915( CONT_PARAMS );
static RTYPE compiled_block_2_1917( CONT_PARAMS );
static RTYPE compiled_block_2_1919( CONT_PARAMS );
static RTYPE compiled_block_2_1923( CONT_PARAMS );
static RTYPE compiled_block_2_1922( CONT_PARAMS );
static RTYPE compiled_block_2_1921( CONT_PARAMS );
static RTYPE compiled_block_2_1920( CONT_PARAMS );
static RTYPE compiled_block_2_1864( CONT_PARAMS );
static RTYPE compiled_block_2_1870( CONT_PARAMS );
static RTYPE compiled_block_2_1872( CONT_PARAMS );
static RTYPE compiled_block_2_1874( CONT_PARAMS );
static RTYPE compiled_block_2_1876( CONT_PARAMS );
static RTYPE compiled_block_2_1879( CONT_PARAMS );
static RTYPE compiled_block_2_1881( CONT_PARAMS );
static RTYPE compiled_block_2_1884( CONT_PARAMS );
static RTYPE compiled_block_2_1886( CONT_PARAMS );
static RTYPE compiled_block_2_1889( CONT_PARAMS );
static RTYPE compiled_block_2_1891( CONT_PARAMS );
static RTYPE compiled_block_2_1895( CONT_PARAMS );
static RTYPE compiled_block_2_1894( CONT_PARAMS );
static RTYPE compiled_block_2_1893( CONT_PARAMS );
static RTYPE compiled_block_2_1892( CONT_PARAMS );
static RTYPE compiled_block_2_1887( CONT_PARAMS );
static RTYPE compiled_block_2_1882( CONT_PARAMS );
static RTYPE compiled_block_2_1877( CONT_PARAMS );
static RTYPE compiled_start_2_10( CONT_PARAMS );
static RTYPE compiled_block_2_1818( CONT_PARAMS );
static RTYPE compiled_block_2_1820( CONT_PARAMS );
static RTYPE compiled_block_2_1822( CONT_PARAMS );
static RTYPE compiled_block_2_1824( CONT_PARAMS );
static RTYPE compiled_block_2_1827( CONT_PARAMS );
static RTYPE compiled_block_2_1829( CONT_PARAMS );
static RTYPE compiled_block_2_1831( CONT_PARAMS );
static RTYPE compiled_block_2_1833( CONT_PARAMS );
static RTYPE compiled_block_2_1836( CONT_PARAMS );
static RTYPE compiled_block_2_1838( CONT_PARAMS );
static RTYPE compiled_block_2_1841( CONT_PARAMS );
static RTYPE compiled_block_2_1843( CONT_PARAMS );
static RTYPE compiled_block_2_1850( CONT_PARAMS );
static RTYPE compiled_block_2_1849( CONT_PARAMS );
static RTYPE compiled_block_2_1848( CONT_PARAMS );
static RTYPE compiled_block_2_1847( CONT_PARAMS );
static RTYPE compiled_block_2_1846( CONT_PARAMS );
static RTYPE compiled_block_2_1845( CONT_PARAMS );
static RTYPE compiled_block_2_1844( CONT_PARAMS );
static RTYPE compiled_block_2_1839( CONT_PARAMS );
static RTYPE compiled_block_2_1834( CONT_PARAMS );
static RTYPE compiled_block_2_1825( CONT_PARAMS );
static RTYPE compiled_block_2_1497( CONT_PARAMS );
static RTYPE compiled_block_2_1772( CONT_PARAMS );
static RTYPE compiled_block_2_1774( CONT_PARAMS );
static RTYPE compiled_block_2_1776( CONT_PARAMS );
static RTYPE compiled_block_2_1778( CONT_PARAMS );
static RTYPE compiled_block_2_1781( CONT_PARAMS );
static RTYPE compiled_block_2_1783( CONT_PARAMS );
static RTYPE compiled_block_2_1785( CONT_PARAMS );
static RTYPE compiled_block_2_1788( CONT_PARAMS );
static RTYPE compiled_block_2_1790( CONT_PARAMS );
static RTYPE compiled_block_2_1792( CONT_PARAMS );
static RTYPE compiled_block_2_1795( CONT_PARAMS );
static RTYPE compiled_block_2_1797( CONT_PARAMS );
static RTYPE compiled_block_2_1804( CONT_PARAMS );
static RTYPE compiled_block_2_1803( CONT_PARAMS );
static RTYPE compiled_block_2_1802( CONT_PARAMS );
static RTYPE compiled_block_2_1801( CONT_PARAMS );
static RTYPE compiled_block_2_1800( CONT_PARAMS );
static RTYPE compiled_block_2_1799( CONT_PARAMS );
static RTYPE compiled_block_2_1798( CONT_PARAMS );
static RTYPE compiled_block_2_1793( CONT_PARAMS );
static RTYPE compiled_block_2_1786( CONT_PARAMS );
static RTYPE compiled_block_2_1779( CONT_PARAMS );
static RTYPE compiled_block_2_1496( CONT_PARAMS );
static RTYPE compiled_block_2_1728( CONT_PARAMS );
static RTYPE compiled_block_2_1730( CONT_PARAMS );
static RTYPE compiled_block_2_1732( CONT_PARAMS );
static RTYPE compiled_block_2_1734( CONT_PARAMS );
static RTYPE compiled_block_2_1737( CONT_PARAMS );
static RTYPE compiled_block_2_1739( CONT_PARAMS );
static RTYPE compiled_block_2_1741( CONT_PARAMS );
static RTYPE compiled_block_2_1743( CONT_PARAMS );
static RTYPE compiled_block_2_1745( CONT_PARAMS );
static RTYPE compiled_block_2_1748( CONT_PARAMS );
static RTYPE compiled_block_2_1750( CONT_PARAMS );
static RTYPE compiled_block_2_1759( CONT_PARAMS );
static RTYPE compiled_block_2_1758( CONT_PARAMS );
static RTYPE compiled_block_2_1757( CONT_PARAMS );
static RTYPE compiled_block_2_1756( CONT_PARAMS );
static RTYPE compiled_block_2_1755( CONT_PARAMS );
static RTYPE compiled_block_2_1754( CONT_PARAMS );
static RTYPE compiled_block_2_1753( CONT_PARAMS );
static RTYPE compiled_block_2_1752( CONT_PARAMS );
static RTYPE compiled_block_2_1751( CONT_PARAMS );
static RTYPE compiled_block_2_1746( CONT_PARAMS );
static RTYPE compiled_block_2_1735( CONT_PARAMS );
static RTYPE compiled_block_2_1495( CONT_PARAMS );
static RTYPE compiled_block_2_1681( CONT_PARAMS );
static RTYPE compiled_block_2_1683( CONT_PARAMS );
static RTYPE compiled_block_2_1685( CONT_PARAMS );
static RTYPE compiled_block_2_1687( CONT_PARAMS );
static RTYPE compiled_block_2_1690( CONT_PARAMS );
static RTYPE compiled_block_2_1692( CONT_PARAMS );
static RTYPE compiled_block_2_1694( CONT_PARAMS );
static RTYPE compiled_block_2_1697( CONT_PARAMS );
static RTYPE compiled_block_2_1699( CONT_PARAMS );
static RTYPE compiled_block_2_1702( CONT_PARAMS );
static RTYPE compiled_block_2_1704( CONT_PARAMS );
static RTYPE compiled_block_2_1706( CONT_PARAMS );
static RTYPE compiled_block_2_1714( CONT_PARAMS );
static RTYPE compiled_block_2_1713( CONT_PARAMS );
static RTYPE compiled_block_2_1712( CONT_PARAMS );
static RTYPE compiled_block_2_1711( CONT_PARAMS );
static RTYPE compiled_block_2_1710( CONT_PARAMS );
static RTYPE compiled_block_2_1709( CONT_PARAMS );
static RTYPE compiled_block_2_1708( CONT_PARAMS );
static RTYPE compiled_block_2_1707( CONT_PARAMS );
static RTYPE compiled_block_2_1700( CONT_PARAMS );
static RTYPE compiled_block_2_1695( CONT_PARAMS );
static RTYPE compiled_block_2_1688( CONT_PARAMS );
static RTYPE compiled_block_2_1494( CONT_PARAMS );
static RTYPE compiled_block_2_1636( CONT_PARAMS );
static RTYPE compiled_block_2_1638( CONT_PARAMS );
static RTYPE compiled_block_2_1640( CONT_PARAMS );
static RTYPE compiled_block_2_1642( CONT_PARAMS );
static RTYPE compiled_block_2_1645( CONT_PARAMS );
static RTYPE compiled_block_2_1647( CONT_PARAMS );
static RTYPE compiled_block_2_1649( CONT_PARAMS );
static RTYPE compiled_block_2_1651( CONT_PARAMS );
static RTYPE compiled_block_2_1654( CONT_PARAMS );
static RTYPE compiled_block_2_1656( CONT_PARAMS );
static RTYPE compiled_block_2_1658( CONT_PARAMS );
static RTYPE compiled_block_2_1668( CONT_PARAMS );
static RTYPE compiled_block_2_1667( CONT_PARAMS );
static RTYPE compiled_block_2_1666( CONT_PARAMS );
static RTYPE compiled_block_2_1665( CONT_PARAMS );
static RTYPE compiled_block_2_1664( CONT_PARAMS );
static RTYPE compiled_block_2_1663( CONT_PARAMS );
static RTYPE compiled_block_2_1662( CONT_PARAMS );
static RTYPE compiled_block_2_1661( CONT_PARAMS );
static RTYPE compiled_block_2_1660( CONT_PARAMS );
static RTYPE compiled_block_2_1659( CONT_PARAMS );
static RTYPE compiled_block_2_1652( CONT_PARAMS );
static RTYPE compiled_block_2_1643( CONT_PARAMS );
static RTYPE compiled_block_2_1493( CONT_PARAMS );
static RTYPE compiled_block_2_1591( CONT_PARAMS );
static RTYPE compiled_block_2_1593( CONT_PARAMS );
static RTYPE compiled_block_2_1595( CONT_PARAMS );
static RTYPE compiled_block_2_1597( CONT_PARAMS );
static RTYPE compiled_block_2_1600( CONT_PARAMS );
static RTYPE compiled_block_2_1602( CONT_PARAMS );
static RTYPE compiled_block_2_1604( CONT_PARAMS );
static RTYPE compiled_block_2_1607( CONT_PARAMS );
static RTYPE compiled_block_2_1609( CONT_PARAMS );
static RTYPE compiled_block_2_1611( CONT_PARAMS );
static RTYPE compiled_block_2_1613( CONT_PARAMS );
static RTYPE compiled_block_2_1623( CONT_PARAMS );
static RTYPE compiled_block_2_1622( CONT_PARAMS );
static RTYPE compiled_block_2_1621( CONT_PARAMS );
static RTYPE compiled_block_2_1620( CONT_PARAMS );
static RTYPE compiled_block_2_1619( CONT_PARAMS );
static RTYPE compiled_block_2_1618( CONT_PARAMS );
static RTYPE compiled_block_2_1617( CONT_PARAMS );
static RTYPE compiled_block_2_1616( CONT_PARAMS );
static RTYPE compiled_block_2_1615( CONT_PARAMS );
static RTYPE compiled_block_2_1614( CONT_PARAMS );
static RTYPE compiled_block_2_1605( CONT_PARAMS );
static RTYPE compiled_block_2_1598( CONT_PARAMS );
static RTYPE compiled_block_2_1492( CONT_PARAMS );
static RTYPE compiled_block_2_1548( CONT_PARAMS );
static RTYPE compiled_block_2_1550( CONT_PARAMS );
static RTYPE compiled_block_2_1552( CONT_PARAMS );
static RTYPE compiled_block_2_1554( CONT_PARAMS );
static RTYPE compiled_block_2_1557( CONT_PARAMS );
static RTYPE compiled_block_2_1559( CONT_PARAMS );
static RTYPE compiled_block_2_1561( CONT_PARAMS );
static RTYPE compiled_block_2_1563( CONT_PARAMS );
static RTYPE compiled_block_2_1565( CONT_PARAMS );
static RTYPE compiled_block_2_1567( CONT_PARAMS );
static RTYPE compiled_block_2_1579( CONT_PARAMS );
static RTYPE compiled_block_2_1578( CONT_PARAMS );
static RTYPE compiled_block_2_1577( CONT_PARAMS );
static RTYPE compiled_block_2_1576( CONT_PARAMS );
static RTYPE compiled_block_2_1575( CONT_PARAMS );
static RTYPE compiled_block_2_1574( CONT_PARAMS );
static RTYPE compiled_block_2_1573( CONT_PARAMS );
static RTYPE compiled_block_2_1572( CONT_PARAMS );
static RTYPE compiled_block_2_1571( CONT_PARAMS );
static RTYPE compiled_block_2_1570( CONT_PARAMS );
static RTYPE compiled_block_2_1569( CONT_PARAMS );
static RTYPE compiled_block_2_1568( CONT_PARAMS );
static RTYPE compiled_block_2_1555( CONT_PARAMS );
static RTYPE compiled_block_2_1491( CONT_PARAMS );
static RTYPE compiled_block_2_1500( CONT_PARAMS );
static RTYPE compiled_block_2_1502( CONT_PARAMS );
static RTYPE compiled_block_2_1504( CONT_PARAMS );
static RTYPE compiled_block_2_1506( CONT_PARAMS );
static RTYPE compiled_block_2_1509( CONT_PARAMS );
static RTYPE compiled_block_2_1511( CONT_PARAMS );
static RTYPE compiled_block_2_1513( CONT_PARAMS );
static RTYPE compiled_block_2_1516( CONT_PARAMS );
static RTYPE compiled_block_2_1518( CONT_PARAMS );
static RTYPE compiled_block_2_1521( CONT_PARAMS );
static RTYPE compiled_block_2_1523( CONT_PARAMS );
static RTYPE compiled_block_2_1526( CONT_PARAMS );
static RTYPE compiled_block_2_1528( CONT_PARAMS );
static RTYPE compiled_block_2_1533( CONT_PARAMS );
static RTYPE compiled_block_2_1532( CONT_PARAMS );
static RTYPE compiled_block_2_1531( CONT_PARAMS );
static RTYPE compiled_block_2_1530( CONT_PARAMS );
static RTYPE compiled_block_2_1529( CONT_PARAMS );
static RTYPE compiled_block_2_1524( CONT_PARAMS );
static RTYPE compiled_block_2_1519( CONT_PARAMS );
static RTYPE compiled_block_2_1514( CONT_PARAMS );
static RTYPE compiled_block_2_1507( CONT_PARAMS );
static RTYPE compiled_start_2_9( CONT_PARAMS );
static RTYPE compiled_block_2_1382( CONT_PARAMS );
static RTYPE compiled_block_2_1384( CONT_PARAMS );
static RTYPE compiled_block_2_1386( CONT_PARAMS );
static RTYPE compiled_block_2_1388( CONT_PARAMS );
static RTYPE compiled_block_2_1390( CONT_PARAMS );
static RTYPE compiled_block_2_1392( CONT_PARAMS );
static RTYPE compiled_start_2_8( CONT_PARAMS );
static RTYPE compiled_block_2_1404( CONT_PARAMS );
static RTYPE compiled_block_2_1478( CONT_PARAMS );
static RTYPE compiled_block_2_1480( CONT_PARAMS );
static RTYPE compiled_block_2_1479( CONT_PARAMS );
static RTYPE compiled_start_2_16( CONT_PARAMS );
static RTYPE compiled_block_2_1476( CONT_PARAMS );
static RTYPE compiled_block_2_1460( CONT_PARAMS );
static RTYPE compiled_block_2_1459( CONT_PARAMS );
static RTYPE compiled_block_2_1475( CONT_PARAMS );
static RTYPE compiled_block_2_1473( CONT_PARAMS );
static RTYPE compiled_block_2_1470( CONT_PARAMS );
static RTYPE compiled_block_2_1471( CONT_PARAMS );
static RTYPE compiled_block_2_1407( CONT_PARAMS );
static RTYPE compiled_block_2_1468( CONT_PARAMS );
static RTYPE compiled_block_2_1466( CONT_PARAMS );
static RTYPE compiled_block_2_1463( CONT_PARAMS );
static RTYPE compiled_block_2_1464( CONT_PARAMS );
static RTYPE compiled_block_2_1406( CONT_PARAMS );
static RTYPE compiled_block_2_1461( CONT_PARAMS );
static RTYPE compiled_block_2_1457( CONT_PARAMS );
static RTYPE compiled_block_2_1454( CONT_PARAMS );
static RTYPE compiled_block_2_1455( CONT_PARAMS );
static RTYPE compiled_block_2_1405( CONT_PARAMS );
static RTYPE compiled_block_2_1410( CONT_PARAMS );
static RTYPE compiled_block_2_1412( CONT_PARAMS );
static RTYPE compiled_block_2_1414( CONT_PARAMS );
static RTYPE compiled_block_2_1416( CONT_PARAMS );
static RTYPE compiled_block_2_1418( CONT_PARAMS );
static RTYPE compiled_block_2_1420( CONT_PARAMS );
static RTYPE compiled_block_2_1422( CONT_PARAMS );
static RTYPE compiled_block_2_1446( CONT_PARAMS );
static RTYPE compiled_block_2_1442( CONT_PARAMS );
static RTYPE compiled_block_2_1445( CONT_PARAMS );
static RTYPE compiled_block_2_1443( CONT_PARAMS );
static RTYPE compiled_block_2_1444( CONT_PARAMS );
static RTYPE compiled_temp_2_20( CONT_PARAMS );
static RTYPE compiled_block_2_1441( CONT_PARAMS );
static RTYPE compiled_block_2_1440( CONT_PARAMS );
static RTYPE compiled_block_2_1436( CONT_PARAMS );
static RTYPE compiled_block_2_1439( CONT_PARAMS );
static RTYPE compiled_block_2_1437( CONT_PARAMS );
static RTYPE compiled_block_2_1438( CONT_PARAMS );
static RTYPE compiled_temp_2_19( CONT_PARAMS );
static RTYPE compiled_block_2_1435( CONT_PARAMS );
static RTYPE compiled_block_2_1434( CONT_PARAMS );
static RTYPE compiled_block_2_1433( CONT_PARAMS );
static RTYPE compiled_block_2_1432( CONT_PARAMS );
static RTYPE compiled_block_2_1431( CONT_PARAMS );
static RTYPE compiled_block_2_1427( CONT_PARAMS );
static RTYPE compiled_block_2_1430( CONT_PARAMS );
static RTYPE compiled_block_2_1428( CONT_PARAMS );
static RTYPE compiled_block_2_1429( CONT_PARAMS );
static RTYPE compiled_temp_2_18( CONT_PARAMS );
static RTYPE compiled_block_2_1426( CONT_PARAMS );
static RTYPE compiled_block_2_1425( CONT_PARAMS );
static RTYPE compiled_block_2_1424( CONT_PARAMS );
static RTYPE compiled_block_2_1423( CONT_PARAMS );
static RTYPE compiled_start_2_17( CONT_PARAMS );
static RTYPE compiled_block_2_1394( CONT_PARAMS );
static RTYPE compiled_block_2_1396( CONT_PARAMS );
static RTYPE compiled_block_2_1398( CONT_PARAMS );
static RTYPE compiled_block_2_1400( CONT_PARAMS );
static RTYPE compiled_block_2_1402( CONT_PARAMS );
static RTYPE compiled_start_2_15( CONT_PARAMS );
static RTYPE compiled_block_2_1263( CONT_PARAMS );
static RTYPE compiled_block_2_1264( CONT_PARAMS );
static RTYPE compiled_block_2_1268( CONT_PARAMS );
static RTYPE compiled_block_2_1123( CONT_PARAMS );
static RTYPE compiled_block_2_1153( CONT_PARAMS );
static RTYPE compiled_block_2_1345( CONT_PARAMS );
static RTYPE compiled_block_2_1347( CONT_PARAMS );
static RTYPE compiled_block_2_1349( CONT_PARAMS );
static RTYPE compiled_block_2_1351( CONT_PARAMS );
static RTYPE compiled_block_2_1353( CONT_PARAMS );
static RTYPE compiled_block_2_1355( CONT_PARAMS );
static RTYPE compiled_block_2_1357( CONT_PARAMS );
static RTYPE compiled_block_2_1359( CONT_PARAMS );
static RTYPE compiled_block_2_1361( CONT_PARAMS );
static RTYPE compiled_block_2_1363( CONT_PARAMS );
static RTYPE compiled_block_2_1365( CONT_PARAMS );
static RTYPE compiled_block_2_1367( CONT_PARAMS );
static RTYPE compiled_block_2_1343( CONT_PARAMS );
static RTYPE compiled_block_2_1342( CONT_PARAMS );
static RTYPE compiled_block_2_1341( CONT_PARAMS );
static RTYPE compiled_block_2_1340( CONT_PARAMS );
static RTYPE compiled_block_2_1339( CONT_PARAMS );
static RTYPE compiled_block_2_1338( CONT_PARAMS );
static RTYPE compiled_block_2_1337( CONT_PARAMS );
static RTYPE compiled_block_2_1336( CONT_PARAMS );
static RTYPE compiled_block_2_1335( CONT_PARAMS );
static RTYPE compiled_block_2_1334( CONT_PARAMS );
static RTYPE compiled_block_2_1333( CONT_PARAMS );
static RTYPE compiled_block_2_1332( CONT_PARAMS );
static RTYPE compiled_block_2_1331( CONT_PARAMS );
static RTYPE compiled_block_2_1043( CONT_PARAMS );
static RTYPE compiled_block_2_1311( CONT_PARAMS );
static RTYPE compiled_block_2_1313( CONT_PARAMS );
static RTYPE compiled_block_2_1316( CONT_PARAMS );
static RTYPE compiled_block_2_1319( CONT_PARAMS );
static RTYPE compiled_block_2_1325( CONT_PARAMS );
static RTYPE compiled_block_2_1321( CONT_PARAMS );
static RTYPE compiled_block_2_1322( CONT_PARAMS );
static RTYPE compiled_block_2_1323( CONT_PARAMS );
static RTYPE compiled_block_2_1320( CONT_PARAMS );
static RTYPE compiled_block_2_1317( CONT_PARAMS );
static RTYPE compiled_block_2_1314( CONT_PARAMS );
static RTYPE compiled_block_2_1042( CONT_PARAMS );
static RTYPE compiled_block_2_1304( CONT_PARAMS );
static RTYPE compiled_block_2_1307( CONT_PARAMS );
static RTYPE compiled_block_2_1305( CONT_PARAMS );
static RTYPE compiled_block_2_1041( CONT_PARAMS );
static RTYPE compiled_block_2_1296( CONT_PARAMS );
static RTYPE compiled_block_2_1298( CONT_PARAMS );
static RTYPE compiled_block_2_1301( CONT_PARAMS );
static RTYPE compiled_block_2_1299( CONT_PARAMS );
static RTYPE compiled_block_2_1040( CONT_PARAMS );
static RTYPE compiled_block_2_1291( CONT_PARAMS );
static RTYPE compiled_block_2_1293( CONT_PARAMS );
static RTYPE compiled_block_2_1292( CONT_PARAMS );
static RTYPE compiled_block_2_1289( CONT_PARAMS );
static RTYPE compiled_block_2_1287( CONT_PARAMS );
static RTYPE compiled_block_2_1039( CONT_PARAMS );
static RTYPE compiled_block_2_1046( CONT_PARAMS );
static RTYPE compiled_block_2_1048( CONT_PARAMS );
static RTYPE compiled_block_2_1050( CONT_PARAMS );
static RTYPE compiled_block_2_1052( CONT_PARAMS );
static RTYPE compiled_block_2_1054( CONT_PARAMS );
static RTYPE compiled_block_2_1057( CONT_PARAMS );
static RTYPE compiled_block_2_1275( CONT_PARAMS );
static RTYPE compiled_block_2_1278( CONT_PARAMS );
static RTYPE compiled_block_2_1279( CONT_PARAMS );
static RTYPE compiled_block_2_1276( CONT_PARAMS );
static RTYPE compiled_block_2_1272( CONT_PARAMS );
static RTYPE compiled_block_2_1273( CONT_PARAMS );
static RTYPE compiled_block_2_1274( CONT_PARAMS );
static RTYPE compiled_block_2_1269( CONT_PARAMS );
static RTYPE compiled_block_2_1270( CONT_PARAMS );
static RTYPE compiled_block_2_1271( CONT_PARAMS );
static RTYPE compiled_block_2_1265( CONT_PARAMS );
static RTYPE compiled_block_2_1266( CONT_PARAMS );
static RTYPE compiled_block_2_1267( CONT_PARAMS );
static RTYPE compiled_block_2_1261( CONT_PARAMS );
static RTYPE compiled_block_2_1262( CONT_PARAMS );
static RTYPE compiled_block_2_1257( CONT_PARAMS );
static RTYPE compiled_block_2_1260( CONT_PARAMS );
static RTYPE compiled_block_2_1258( CONT_PARAMS );
static RTYPE compiled_block_2_1254( CONT_PARAMS );
static RTYPE compiled_block_2_1256( CONT_PARAMS );
static RTYPE compiled_block_2_1255( CONT_PARAMS );
static RTYPE compiled_block_2_1253( CONT_PARAMS );
static RTYPE compiled_block_2_1250( CONT_PARAMS );
static RTYPE compiled_block_2_1251( CONT_PARAMS );
static RTYPE compiled_block_2_1252( CONT_PARAMS );
static RTYPE compiled_block_2_1193( CONT_PARAMS );
static RTYPE compiled_block_2_1197( CONT_PARAMS );
static RTYPE compiled_block_2_1196( CONT_PARAMS );
static RTYPE compiled_block_2_1195( CONT_PARAMS );
static RTYPE compiled_block_2_1194( CONT_PARAMS );
static RTYPE compiled_block_2_1192( CONT_PARAMS );
static RTYPE compiled_block_2_1187( CONT_PARAMS );
static RTYPE compiled_block_2_1191( CONT_PARAMS );
static RTYPE compiled_block_2_1190( CONT_PARAMS );
static RTYPE compiled_block_2_1189( CONT_PARAMS );
static RTYPE compiled_block_2_1188( CONT_PARAMS );
static RTYPE compiled_block_2_1186( CONT_PARAMS );
static RTYPE compiled_block_2_1185( CONT_PARAMS );
static RTYPE compiled_block_2_1074( CONT_PARAMS );
static RTYPE compiled_block_2_1075( CONT_PARAMS );
static RTYPE compiled_block_2_1084( CONT_PARAMS );
static RTYPE compiled_block_2_1126( CONT_PARAMS );
static RTYPE compiled_block_2_1136( CONT_PARAMS );
static RTYPE compiled_block_2_1144( CONT_PARAMS );
static RTYPE compiled_block_2_1157( CONT_PARAMS );
static RTYPE compiled_block_2_1169( CONT_PARAMS );
static RTYPE compiled_block_2_1178( CONT_PARAMS );
static RTYPE compiled_block_2_1183( CONT_PARAMS );
static RTYPE compiled_temp_2_26( CONT_PARAMS );
static RTYPE compiled_block_2_1184( CONT_PARAMS );
static RTYPE compiled_block_2_1181( CONT_PARAMS );
static RTYPE compiled_block_2_1180( CONT_PARAMS );
static RTYPE compiled_block_2_1170( CONT_PARAMS );
static RTYPE compiled_block_2_1174( CONT_PARAMS );
static RTYPE compiled_block_2_1176( CONT_PARAMS );
static RTYPE compiled_block_2_1172( CONT_PARAMS );
static RTYPE compiled_block_2_1171( CONT_PARAMS );
static RTYPE compiled_block_2_1158( CONT_PARAMS );
static RTYPE compiled_block_2_1162( CONT_PARAMS );
static RTYPE compiled_block_2_1165( CONT_PARAMS );
static RTYPE compiled_block_2_1167( CONT_PARAMS );
static RTYPE compiled_temp_2_25( CONT_PARAMS );
static RTYPE compiled_block_2_1163( CONT_PARAMS );
static RTYPE compiled_block_2_1160( CONT_PARAMS );
static RTYPE compiled_block_2_1159( CONT_PARAMS );
static RTYPE compiled_block_2_1145( CONT_PARAMS );
static RTYPE compiled_block_2_1149( CONT_PARAMS );
static RTYPE compiled_block_2_1152( CONT_PARAMS );
static RTYPE compiled_block_2_1155( CONT_PARAMS );
static RTYPE compiled_temp_2_24( CONT_PARAMS );
static RTYPE compiled_block_2_1150( CONT_PARAMS );
static RTYPE compiled_block_2_1147( CONT_PARAMS );
static RTYPE compiled_block_2_1146( CONT_PARAMS );
static RTYPE compiled_block_2_1137( CONT_PARAMS );
static RTYPE compiled_block_2_1141( CONT_PARAMS );
static RTYPE compiled_temp_2_23( CONT_PARAMS );
static RTYPE compiled_block_2_1142( CONT_PARAMS );
static RTYPE compiled_block_2_1139( CONT_PARAMS );
static RTYPE compiled_block_2_1138( CONT_PARAMS );
static RTYPE compiled_block_2_1127( CONT_PARAMS );
static RTYPE compiled_block_2_1131( CONT_PARAMS );
static RTYPE compiled_block_2_1134( CONT_PARAMS );
static RTYPE compiled_temp_2_22( CONT_PARAMS );
static RTYPE compiled_block_2_1132( CONT_PARAMS );
static RTYPE compiled_block_2_1129( CONT_PARAMS );
static RTYPE compiled_block_2_1128( CONT_PARAMS );
static RTYPE compiled_block_2_1085( CONT_PARAMS );
static RTYPE compiled_block_2_1089( CONT_PARAMS );
static RTYPE compiled_block_2_1124( CONT_PARAMS );
static RTYPE compiled_block_2_1087( CONT_PARAMS );
static RTYPE compiled_block_2_1086( CONT_PARAMS );
static RTYPE compiled_block_2_1077( CONT_PARAMS );
static RTYPE compiled_block_2_1078( CONT_PARAMS );
static RTYPE compiled_block_2_1081( CONT_PARAMS );
static RTYPE compiled_block_2_1082( CONT_PARAMS );
static RTYPE compiled_block_2_1079( CONT_PARAMS );
static RTYPE compiled_block_2_1076( CONT_PARAMS );
static RTYPE compiled_block_2_1073( CONT_PARAMS );
static RTYPE compiled_block_2_1072( CONT_PARAMS );
static RTYPE compiled_block_2_1071( CONT_PARAMS );
static RTYPE compiled_block_2_1070( CONT_PARAMS );
static RTYPE compiled_block_2_1069( CONT_PARAMS );
static RTYPE compiled_block_2_1068( CONT_PARAMS );
static RTYPE compiled_block_2_1067( CONT_PARAMS );
static RTYPE compiled_block_2_1066( CONT_PARAMS );
static RTYPE compiled_block_2_1065( CONT_PARAMS );
static RTYPE compiled_block_2_1064( CONT_PARAMS );
static RTYPE compiled_block_2_1063( CONT_PARAMS );
static RTYPE compiled_block_2_1062( CONT_PARAMS );
static RTYPE compiled_block_2_1061( CONT_PARAMS );
static RTYPE compiled_block_2_1060( CONT_PARAMS );
static RTYPE compiled_block_2_1059( CONT_PARAMS );
static RTYPE compiled_block_2_1058( CONT_PARAMS );
static RTYPE compiled_block_2_1055( CONT_PARAMS );
static RTYPE compiled_start_2_7( CONT_PARAMS );
static RTYPE compiled_block_2_1240( CONT_PARAMS );
static RTYPE compiled_block_2_1205( CONT_PARAMS );
static RTYPE compiled_block_2_1206( CONT_PARAMS );
static RTYPE compiled_block_2_1239( CONT_PARAMS );
static RTYPE compiled_block_2_1242( CONT_PARAMS );
static RTYPE compiled_block_2_1244( CONT_PARAMS );
static RTYPE compiled_block_2_1246( CONT_PARAMS );
static RTYPE compiled_temp_2_29( CONT_PARAMS );
static RTYPE compiled_block_2_1237( CONT_PARAMS );
static RTYPE compiled_block_2_1204( CONT_PARAMS );
static RTYPE compiled_block_2_1222( CONT_PARAMS );
static RTYPE compiled_block_2_1228( CONT_PARAMS );
static RTYPE compiled_block_2_1230( CONT_PARAMS );
static RTYPE compiled_block_2_1232( CONT_PARAMS );
static RTYPE compiled_block_2_1233( CONT_PARAMS );
static RTYPE compiled_block_2_1226( CONT_PARAMS );
static RTYPE compiled_block_2_1225( CONT_PARAMS );
static RTYPE compiled_block_2_1224( CONT_PARAMS );
static RTYPE compiled_block_2_1223( CONT_PARAMS );
static RTYPE compiled_block_2_1213( CONT_PARAMS );
static RTYPE compiled_block_2_1215( CONT_PARAMS );
static RTYPE compiled_block_2_1217( CONT_PARAMS );
static RTYPE compiled_block_2_1218( CONT_PARAMS );
static RTYPE compiled_block_2_1211( CONT_PARAMS );
static RTYPE compiled_block_2_1210( CONT_PARAMS );
static RTYPE compiled_block_2_1209( CONT_PARAMS );
static RTYPE compiled_block_2_1208( CONT_PARAMS );
static RTYPE compiled_block_2_1207( CONT_PARAMS );
static RTYPE compiled_temp_2_28( CONT_PARAMS );
static RTYPE compiled_block_2_1202( CONT_PARAMS );
static RTYPE compiled_block_2_1199( CONT_PARAMS );
static RTYPE compiled_block_2_1200( CONT_PARAMS );
static RTYPE compiled_block_2_1201( CONT_PARAMS );
static RTYPE compiled_block_2_1198( CONT_PARAMS );
static RTYPE compiled_start_2_27( CONT_PARAMS );
static RTYPE compiled_block_2_1098( CONT_PARAMS );
static RTYPE compiled_block_2_1116( CONT_PARAMS );
static RTYPE compiled_block_2_1103( CONT_PARAMS );
static RTYPE compiled_block_2_1106( CONT_PARAMS );
static RTYPE compiled_block_2_1094( CONT_PARAMS );
static RTYPE compiled_block_2_1097( CONT_PARAMS );
static RTYPE compiled_block_2_1105( CONT_PARAMS );
static RTYPE compiled_block_2_1108( CONT_PARAMS );
static RTYPE compiled_block_2_1118( CONT_PARAMS );
static RTYPE compiled_block_2_1120( CONT_PARAMS );
static RTYPE compiled_block_2_1122( CONT_PARAMS );
static RTYPE compiled_block_2_1113( CONT_PARAMS );
static RTYPE compiled_block_2_1115( CONT_PARAMS );
static RTYPE compiled_block_2_1111( CONT_PARAMS );
static RTYPE compiled_block_2_1109( CONT_PARAMS );
static RTYPE compiled_block_2_1099( CONT_PARAMS );
static RTYPE compiled_block_2_1102( CONT_PARAMS );
static RTYPE compiled_block_2_1100( CONT_PARAMS );
static RTYPE compiled_temp_2_30( CONT_PARAMS );
static RTYPE compiled_block_2_1095( CONT_PARAMS );
static RTYPE compiled_block_2_1092( CONT_PARAMS );
static RTYPE compiled_block_2_1091( CONT_PARAMS );
static RTYPE compiled_start_2_21( CONT_PARAMS );
static RTYPE compiled_block_2_1028( CONT_PARAMS );
static RTYPE compiled_block_2_1030( CONT_PARAMS );
static RTYPE compiled_block_2_1033( CONT_PARAMS );
static RTYPE compiled_block_2_1034( CONT_PARAMS );
static RTYPE compiled_block_2_1031( CONT_PARAMS );
static RTYPE compiled_block_2_1002( CONT_PARAMS );
static RTYPE compiled_block_2_1005( CONT_PARAMS );
static RTYPE compiled_block_2_1007( CONT_PARAMS );
static RTYPE compiled_block_2_1009( CONT_PARAMS );
static RTYPE compiled_block_2_1011( CONT_PARAMS );
static RTYPE compiled_block_2_1013( CONT_PARAMS );
static RTYPE compiled_block_2_1015( CONT_PARAMS );
static RTYPE compiled_block_2_1018( CONT_PARAMS );
static RTYPE compiled_block_2_1019( CONT_PARAMS );
static RTYPE compiled_block_2_1016( CONT_PARAMS );
static RTYPE compiled_start_2_6( CONT_PARAMS );
static RTYPE compiled_start_2_1( CONT_PARAMS );

static RTYPE compiled_start_2_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 2 ); /*  record-constructor-descriptor~1ay%kV~3305 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 3 ); /*  record-type-descriptor~1ay%kV~3304 */
  twobit_lambda( compiled_start_2_1, 5, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_2_2, 7, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_2_3, 9, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_const( 12 );
  twobit_setreg( 4 );
  twobit_const( 13 );
  twobit_setreg( 5 );
  twobit_const( 14 );
  twobit_setreg( 8 );
  twobit_global( 15 ); /* ex:make-library */
  twobit_setrtn( 2182, compiled_block_2_2182 );
  twobit_invoke( 8 );
  twobit_label( 2182, compiled_block_2_2182 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 16 ); /* ex:register-library! */
  twobit_setrtn( 2183, compiled_block_2_2183 );
  twobit_invoke( 1 );
  twobit_label( 2183, compiled_block_2_2183 );
  twobit_load( 0, 0 );
  twobit_global( 17 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* ex:uncompress */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_6, 2, 0 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1038, compiled_block_2_1038 );
  twobit_invoke( 2 );
  twobit_label( 1038, compiled_block_2_1038 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_2_7, 6, 0 );
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1380, compiled_block_2_1380 );
  twobit_invoke( 2 );
  twobit_label( 1380, compiled_block_2_1380 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_2_8, 9, 0 );
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1490, compiled_block_2_1490 );
  twobit_invoke( 2 );
  twobit_label( 1490, compiled_block_2_1490 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_2_9, 12, 0 );
  twobit_setreg( 2 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1863, compiled_block_2_1863 );
  twobit_invoke( 2 );
  twobit_label( 1863, compiled_block_2_1863 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_2_10, 15, 0 );
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 2027, compiled_block_2_2027 );
  twobit_invoke( 2 );
  twobit_label( 2027, compiled_block_2_2027 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_2_11, 18, 0 );
  twobit_setreg( 2 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 2062, compiled_block_2_2062 );
  twobit_invoke( 2 );
  twobit_label( 2062, compiled_block_2_2062 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_2_12, 21, 0 );
  twobit_setreg( 2 );
  twobit_const( 22 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 2096, compiled_block_2_2096 );
  twobit_invoke( 2 );
  twobit_label( 2096, compiled_block_2_2096 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_2_13, 24, 0 );
  twobit_setreg( 2 );
  twobit_const( 25 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 2137, compiled_block_2_2137 );
  twobit_invoke( 2 );
  twobit_label( 2137, compiled_block_2_2137 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_2_14, 27, 0 );
  twobit_setreg( 2 );
  twobit_const( 28 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 2178, compiled_block_2_2178 );
  twobit_invoke( 2 );
  twobit_label( 2178, compiled_block_2_2178 );
  twobit_load( 0, 0 );
  twobit_global( 29 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_6( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1005, compiled_block_2_1005 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1007, compiled_block_2_1007 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1009, compiled_block_2_1009 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1011, compiled_block_2_1011 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1013, compiled_block_2_1013 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1015, compiled_block_2_1015 ); /* internal:branchf-null? */
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 5 );
  twobit_store( 2, 4 );
  twobit_store( 30, 2 );
  twobit_store( 31, 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1016, compiled_block_2_1016 );
  twobit_invoke( 1 );
  twobit_label( 1016, compiled_block_2_1016 );
  twobit_load( 0, 0 );
  twobit_branchf( 1018, compiled_block_2_1018 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1019, compiled_block_2_1019 );
  twobit_invoke( 5 );
  twobit_label( 1019, compiled_block_2_1019 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1018, compiled_block_2_1018 );
  twobit_load( 1, 5 );
  twobit_pop( 5 );
  twobit_branch( 1002, compiled_block_2_1002 );
  twobit_label( 1015, compiled_block_2_1015 );
  twobit_branch( 1002, compiled_block_2_1002 );
  twobit_label( 1013, compiled_block_2_1013 );
  twobit_branch( 1002, compiled_block_2_1002 );
  twobit_label( 1011, compiled_block_2_1011 );
  twobit_branch( 1002, compiled_block_2_1002 );
  twobit_label( 1009, compiled_block_2_1009 );
  twobit_branch( 1002, compiled_block_2_1002 );
  twobit_label( 1007, compiled_block_2_1007 );
  twobit_branch( 1002, compiled_block_2_1002 );
  twobit_label( 1005, compiled_block_2_1005 );
  twobit_label( 1002, compiled_block_2_1002 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1028, compiled_block_2_1028 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1030, compiled_block_2_1030 ); /* internal:branchf-pair? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1031, compiled_block_2_1031 );
  twobit_invoke( 1 );
  twobit_label( 1031, compiled_block_2_1031 );
  twobit_load( 0, 0 );
  twobit_branchf( 1033, compiled_block_2_1033 );
  twobit_load( 4, 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1034, compiled_block_2_1034 );
  twobit_invoke( 5 );
  twobit_label( 1034, compiled_block_2_1034 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1033, compiled_block_2_1033 );
  twobit_load( 1, 3 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_pop( 3 );
  twobit_invoke( 1 );
  twobit_label( 1030, compiled_block_2_1030 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1028, compiled_block_2_1028 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_7( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1046, compiled_block_2_1046 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1048, compiled_block_2_1048 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1050, compiled_block_2_1050 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1052, compiled_block_2_1052 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1054, compiled_block_2_1054 ); /* internal:branchf-pair? */
  twobit_save( 21 );
  twobit_store( 0, 0 );
  twobit_store( 1, 21 );
  twobit_store( 2, 1 );
  twobit_store( 3, 11 );
  twobit_store( 31, 12 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_store( 30, 13 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1055, compiled_block_2_1055 );
  twobit_invoke( 1 );
  twobit_label( 1055, compiled_block_2_1055 );
  twobit_load( 0, 0 );
  twobit_branchf( 1057, compiled_block_2_1057 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* ex:syntax->datum */
  twobit_setrtn( 1058, compiled_block_2_1058 );
  twobit_invoke( 1 );
  twobit_label( 1058, compiled_block_2_1058 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_setrtn( 1059, compiled_block_2_1059 );
  twobit_branch( 1042, compiled_block_2_1042 );
  twobit_label( 1059, compiled_block_2_1059 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_setrtn( 1060, compiled_block_2_1060 );
  twobit_branch( 1042, compiled_block_2_1042 );
  twobit_label( 1060, compiled_block_2_1060 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_setrtn( 1061, compiled_block_2_1061 );
  twobit_branch( 1042, compiled_block_2_1042 );
  twobit_label( 1061, compiled_block_2_1061 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_setrtn( 1062, compiled_block_2_1062 );
  twobit_branch( 1042, compiled_block_2_1042 );
  twobit_label( 1062, compiled_block_2_1062 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_setrtn( 1063, compiled_block_2_1063 );
  twobit_branch( 1042, compiled_block_2_1042 );
  twobit_label( 1063, compiled_block_2_1063 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_setrtn( 1064, compiled_block_2_1064 );
  twobit_branch( 1042, compiled_block_2_1042 );
  twobit_label( 1064, compiled_block_2_1064 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_setrtn( 1065, compiled_block_2_1065 );
  twobit_branch( 1042, compiled_block_2_1042 );
  twobit_label( 1065, compiled_block_2_1065 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 2 );
  twobit_global( 2 ); /* ex:syntax->datum */
  twobit_setrtn( 1066, compiled_block_2_1066 );
  twobit_invoke( 1 );
  twobit_label( 1066, compiled_block_2_1066 );
  twobit_load( 0, 0 );
  twobit_load( 1, 3 );
  twobit_global( 2 ); /* ex:syntax->datum */
  twobit_setrtn( 1067, compiled_block_2_1067 );
  twobit_invoke( 1 );
  twobit_label( 1067, compiled_block_2_1067 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 19 );
  twobit_load( 1, 4 );
  twobit_global( 2 ); /* ex:syntax->datum */
  twobit_setrtn( 1068, compiled_block_2_1068 );
  twobit_invoke( 1 );
  twobit_label( 1068, compiled_block_2_1068 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 18 );
  twobit_load( 1, 5 );
  twobit_global( 2 ); /* ex:syntax->datum */
  twobit_setrtn( 1069, compiled_block_2_1069 );
  twobit_invoke( 1 );
  twobit_label( 1069, compiled_block_2_1069 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 17 );
  twobit_load( 1, 6 );
  twobit_global( 2 ); /* ex:syntax->datum */
  twobit_setrtn( 1070, compiled_block_2_1070 );
  twobit_invoke( 1 );
  twobit_label( 1070, compiled_block_2_1070 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 16 );
  twobit_load( 1, 7 );
  twobit_global( 2 ); /* ex:syntax->datum */
  twobit_setrtn( 1071, compiled_block_2_1071 );
  twobit_invoke( 1 );
  twobit_label( 1071, compiled_block_2_1071 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 15 );
  twobit_load( 1, 8 );
  twobit_global( 2 ); /* ex:syntax->datum */
  twobit_setrtn( 1072, compiled_block_2_1072 );
  twobit_invoke( 1 );
  twobit_label( 1072, compiled_block_2_1072 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 14 );
  twobit_load( 1, 9 );
  twobit_global( 2 ); /* ex:syntax->datum */
  twobit_setrtn( 1073, compiled_block_2_1073 );
  twobit_invoke( 1 );
  twobit_label( 1073, compiled_block_2_1073 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 10 );
  twobit_op1_17(); /* symbol? */
  twobit_branchf( 1075, compiled_block_2_1075 );
  twobit_load( 1, 11 );
  twobit_global( 2 ); /* ex:syntax->datum */
  twobit_setrtn( 1076, compiled_block_2_1076 );
  twobit_invoke( 1 );
  twobit_label( 1076, compiled_block_2_1076 );
  twobit_load( 0, 0 );
  twobit_branchf( 1078, compiled_block_2_1078 );
  twobit_load( 1, 12 );
  twobit_global( 2 ); /* ex:syntax->datum */
  twobit_setrtn( 1079, compiled_block_2_1079 );
  twobit_invoke( 1 );
  twobit_label( 1079, compiled_block_2_1079 );
  twobit_load( 0, 0 );
  twobit_op1_17(); /* symbol? */
  twobit_branchf( 1081, compiled_block_2_1081 );
  twobit_load( 1, 13 );
  twobit_global( 2 ); /* ex:syntax->datum */
  twobit_setrtn( 1082, compiled_block_2_1082 );
  twobit_invoke( 1 );
  twobit_label( 1082, compiled_block_2_1082 );
  twobit_load( 0, 0 );
  twobit_op1_17(); /* symbol? */
  twobit_skip( 1077, compiled_block_2_1077 );
  twobit_label( 1081, compiled_block_2_1081 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1077, compiled_block_2_1077 );
  twobit_label( 1078, compiled_block_2_1078 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_label( 1077, compiled_block_2_1077 );
  twobit_branchf( 1084, compiled_block_2_1084 );
  twobit_stack( 2 );
  twobit_op1_9(); /* not */
  twobit_branchf( 1086, compiled_block_2_1086 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1085, compiled_block_2_1085 );
  twobit_label( 1086, compiled_block_2_1086 );
  twobit_load( 1, 2 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1087, compiled_block_2_1087 );
  twobit_invoke( 1 );
  twobit_label( 1087, compiled_block_2_1087 );
  twobit_load( 0, 0 );
  twobit_branchf( 1089, compiled_block_2_1089 );
  twobit_lambda( compiled_start_2_21, 11, 0 );
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 2 );
  twobit_check( 3, 0, 0, 1123, compiled_block_2_1123 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_global( 12 ); /* for-all */
  twobit_setrtn( 1124, compiled_block_2_1124 );
  twobit_invoke( 2 );
  twobit_label( 1124, compiled_block_2_1124 );
  twobit_load( 0, 0 );
  twobit_skip( 1085, compiled_block_2_1085 );
  twobit_label( 1089, compiled_block_2_1089 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1085, compiled_block_2_1085 );
  twobit_branchf( 1126, compiled_block_2_1126 );
  twobit_stack( 14 );
  twobit_op1_9(); /* not */
  twobit_branchf( 1128, compiled_block_2_1128 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1127, compiled_block_2_1127 );
  twobit_label( 1128, compiled_block_2_1128 );
  twobit_load( 1, 14 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1129, compiled_block_2_1129 );
  twobit_invoke( 1 );
  twobit_label( 1129, compiled_block_2_1129 );
  twobit_load( 0, 0 );
  twobit_branchf( 1131, compiled_block_2_1131 );
  twobit_load( 1, 14 );
  twobit_global( 13 ); /* length */
  twobit_setrtn( 1132, compiled_block_2_1132 );
  twobit_invoke( 1 );
  twobit_label( 1132, compiled_block_2_1132 );
  twobit_load( 0, 0 );
  twobit_op2imm_branchf_639( fixnum(2), 22, compiled_temp_2_22, 1134, compiled_block_2_1134 ); /* internal:branchf-=/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1127, compiled_block_2_1127 );
  twobit_label( 1134, compiled_block_2_1134 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1127, compiled_block_2_1127 );
  twobit_label( 1131, compiled_block_2_1131 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1127, compiled_block_2_1127 );
  twobit_branchf( 1136, compiled_block_2_1136 );
  twobit_stack( 15 );
  twobit_op1_9(); /* not */
  twobit_branchf( 1138, compiled_block_2_1138 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1137, compiled_block_2_1137 );
  twobit_label( 1138, compiled_block_2_1138 );
  twobit_load( 1, 15 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1139, compiled_block_2_1139 );
  twobit_invoke( 1 );
  twobit_label( 1139, compiled_block_2_1139 );
  twobit_load( 0, 0 );
  twobit_branchf( 1141, compiled_block_2_1141 );
  twobit_load( 1, 15 );
  twobit_global( 13 ); /* length */
  twobit_setrtn( 1142, compiled_block_2_1142 );
  twobit_invoke( 1 );
  twobit_label( 1142, compiled_block_2_1142 );
  twobit_load( 0, 0 );
  twobit_op2imm_134( fixnum(2), 23, compiled_temp_2_23 ); /* = */
  twobit_skip( 1137, compiled_block_2_1137 );
  twobit_label( 1141, compiled_block_2_1141 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1137, compiled_block_2_1137 );
  twobit_branchf( 1144, compiled_block_2_1144 );
  twobit_stack( 16 );
  twobit_op1_9(); /* not */
  twobit_branchf( 1146, compiled_block_2_1146 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1145, compiled_block_2_1145 );
  twobit_label( 1146, compiled_block_2_1146 );
  twobit_load( 1, 16 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1147, compiled_block_2_1147 );
  twobit_invoke( 1 );
  twobit_label( 1147, compiled_block_2_1147 );
  twobit_load( 0, 0 );
  twobit_branchf( 1149, compiled_block_2_1149 );
  twobit_load( 1, 16 );
  twobit_global( 13 ); /* length */
  twobit_setrtn( 1150, compiled_block_2_1150 );
  twobit_invoke( 1 );
  twobit_label( 1150, compiled_block_2_1150 );
  twobit_load( 0, 0 );
  twobit_op2imm_branchf_639( fixnum(2), 24, compiled_temp_2_24, 1152, compiled_block_2_1152 ); /* internal:branchf-=/imm */
  twobit_stack( 16 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 16 );
  twobit_check( 3, 0, 0, 1123, compiled_block_2_1123 );
  twobit_stack( 16 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1153,compiled_block_2_1153); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_129( TRUE_CONST ); /* eq? */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_branchf( 1155, compiled_block_2_1155 );
  twobit_reg( 3 );
  twobit_skip( 1145, compiled_block_2_1145 );
  twobit_label( 1155, compiled_block_2_1155 );
  twobit_reg( 4 );
  twobit_op2imm_129( FALSE_CONST ); /* eq? */
  twobit_skip( 1145, compiled_block_2_1145 );
  twobit_label( 1152, compiled_block_2_1152 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1145, compiled_block_2_1145 );
  twobit_label( 1149, compiled_block_2_1149 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1145, compiled_block_2_1145 );
  twobit_branchf( 1157, compiled_block_2_1157 );
  twobit_stack( 17 );
  twobit_op1_9(); /* not */
  twobit_branchf( 1159, compiled_block_2_1159 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1158, compiled_block_2_1158 );
  twobit_label( 1159, compiled_block_2_1159 );
  twobit_load( 1, 17 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1160, compiled_block_2_1160 );
  twobit_invoke( 1 );
  twobit_label( 1160, compiled_block_2_1160 );
  twobit_load( 0, 0 );
  twobit_branchf( 1162, compiled_block_2_1162 );
  twobit_load( 1, 17 );
  twobit_global( 13 ); /* length */
  twobit_setrtn( 1163, compiled_block_2_1163 );
  twobit_invoke( 1 );
  twobit_label( 1163, compiled_block_2_1163 );
  twobit_load( 0, 0 );
  twobit_op2imm_branchf_639( fixnum(2), 25, compiled_temp_2_25, 1165, compiled_block_2_1165 ); /* internal:branchf-=/imm */
  twobit_stack( 17 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 17 );
  twobit_check( 3, 0, 0, 1123, compiled_block_2_1123 );
  twobit_stack( 17 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1153,compiled_block_2_1153); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_129( TRUE_CONST ); /* eq? */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_branchf( 1167, compiled_block_2_1167 );
  twobit_reg( 3 );
  twobit_skip( 1158, compiled_block_2_1158 );
  twobit_label( 1167, compiled_block_2_1167 );
  twobit_reg( 4 );
  twobit_op2imm_129( FALSE_CONST ); /* eq? */
  twobit_skip( 1158, compiled_block_2_1158 );
  twobit_label( 1165, compiled_block_2_1165 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1158, compiled_block_2_1158 );
  twobit_label( 1162, compiled_block_2_1162 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1158, compiled_block_2_1158 );
  twobit_branchf( 1169, compiled_block_2_1169 );
  twobit_stack( 18 );
  twobit_op1_9(); /* not */
  twobit_branchf( 1171, compiled_block_2_1171 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1170, compiled_block_2_1170 );
  twobit_label( 1171, compiled_block_2_1171 );
  twobit_load( 1, 18 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1172, compiled_block_2_1172 );
  twobit_invoke( 1 );
  twobit_label( 1172, compiled_block_2_1172 );
  twobit_load( 0, 0 );
  twobit_branchf( 1174, compiled_block_2_1174 );
  twobit_stack( 18 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 18 );
  twobit_check( 3, 0, 0, 1123, compiled_block_2_1123 );
  twobit_stack( 18 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_10(); /* null? */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_branchf( 1176, compiled_block_2_1176 );
  twobit_reg( 3 );
  twobit_skip( 1170, compiled_block_2_1170 );
  twobit_label( 1176, compiled_block_2_1176 );
  twobit_reg_op1_check_652(reg(4),1153,compiled_block_2_1153); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_op1_17(); /* symbol? */
  twobit_skip( 1170, compiled_block_2_1170 );
  twobit_label( 1174, compiled_block_2_1174 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1170, compiled_block_2_1170 );
  twobit_branchf( 1178, compiled_block_2_1178 );
  twobit_stack( 19 );
  twobit_op1_9(); /* not */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1180, compiled_block_2_1180 );
  twobit_reg( 4 );
  twobit_skip( 1074, compiled_block_2_1074 );
  twobit_label( 1180, compiled_block_2_1180 );
  twobit_load( 1, 19 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1181, compiled_block_2_1181 );
  twobit_invoke( 1 );
  twobit_label( 1181, compiled_block_2_1181 );
  twobit_load( 0, 0 );
  twobit_branchf( 1183, compiled_block_2_1183 );
  twobit_load( 1, 19 );
  twobit_global( 13 ); /* length */
  twobit_setrtn( 1184, compiled_block_2_1184 );
  twobit_invoke( 1 );
  twobit_label( 1184, compiled_block_2_1184 );
  twobit_load( 0, 0 );
  twobit_op2imm_134( fixnum(3), 26, compiled_temp_2_26 ); /* = */
  twobit_skip( 1074, compiled_block_2_1074 );
  twobit_label( 1183, compiled_block_2_1183 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1074, compiled_block_2_1074 );
  twobit_label( 1178, compiled_block_2_1178 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1074, compiled_block_2_1074 );
  twobit_label( 1169, compiled_block_2_1169 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1074, compiled_block_2_1074 );
  twobit_label( 1157, compiled_block_2_1157 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1074, compiled_block_2_1074 );
  twobit_label( 1144, compiled_block_2_1144 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1074, compiled_block_2_1074 );
  twobit_label( 1136, compiled_block_2_1136 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1074, compiled_block_2_1074 );
  twobit_label( 1126, compiled_block_2_1126 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1074, compiled_block_2_1074 );
  twobit_label( 1084, compiled_block_2_1084 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1074, compiled_block_2_1074 );
  twobit_label( 1075, compiled_block_2_1075 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1074, compiled_block_2_1074 );
  twobit_setreg( 4 );
  twobit_store( 4, 20 );
  twobit_load( 1, 10 );
  twobit_global( 14 ); /* symbol->string */
  twobit_setrtn( 1185, compiled_block_2_1185 );
  twobit_invoke( 1 );
  twobit_label( 1185, compiled_block_2_1185 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 12 );
  twobit_global( 2 ); /* ex:syntax->datum */
  twobit_setrtn( 1186, compiled_block_2_1186 );
  twobit_invoke( 1 );
  twobit_label( 1186, compiled_block_2_1186 );
  twobit_load( 0, 0 );
  twobit_op1_17(); /* symbol? */
  twobit_branchf( 1188, compiled_block_2_1188 );
  twobit_stack( 12 );
  twobit_skip( 1187, compiled_block_2_1187 );
  twobit_label( 1188, compiled_block_2_1188 );
  twobit_load( 2, 2 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_global( 16 ); /* string-append */
  twobit_setrtn( 1189, compiled_block_2_1189 );
  twobit_invoke( 2 );
  twobit_label( 1189, compiled_block_2_1189 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 17 ); /* string->symbol */
  twobit_setrtn( 1190, compiled_block_2_1190 );
  twobit_invoke( 1 );
  twobit_label( 1190, compiled_block_2_1190 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 18 ); /* ex:datum->syntax */
  twobit_setrtn( 1191, compiled_block_2_1191 );
  twobit_invoke( 2 );
  twobit_label( 1191, compiled_block_2_1191 );
  twobit_load( 0, 0 );
  twobit_label( 1187, compiled_block_2_1187 );
  twobit_setreg( 4 );
  twobit_store( 4, 14 );
  twobit_load( 1, 13 );
  twobit_global( 2 ); /* ex:syntax->datum */
  twobit_setrtn( 1192, compiled_block_2_1192 );
  twobit_invoke( 1 );
  twobit_label( 1192, compiled_block_2_1192 );
  twobit_load( 0, 0 );
  twobit_op1_17(); /* symbol? */
  twobit_branchf( 1194, compiled_block_2_1194 );
  twobit_stack( 13 );
  twobit_skip( 1193, compiled_block_2_1193 );
  twobit_label( 1194, compiled_block_2_1194 );
  twobit_load( 1, 2 );
  twobit_const( 19 );
  twobit_setreg( 2 );
  twobit_global( 16 ); /* string-append */
  twobit_setrtn( 1195, compiled_block_2_1195 );
  twobit_invoke( 2 );
  twobit_label( 1195, compiled_block_2_1195 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 17 ); /* string->symbol */
  twobit_setrtn( 1196, compiled_block_2_1196 );
  twobit_invoke( 1 );
  twobit_label( 1196, compiled_block_2_1196 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 18 ); /* ex:datum->syntax */
  twobit_setrtn( 1197, compiled_block_2_1197 );
  twobit_invoke( 2 );
  twobit_label( 1197, compiled_block_2_1197 );
  twobit_load( 0, 0 );
  twobit_label( 1193, compiled_block_2_1193 );
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_2_27, 21, 1 );
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_stack( 9 );
  twobit_branchf( 1251, compiled_block_2_1251 );
  twobit_load( 1, 9 );
  twobit_setrtn( 1252, compiled_block_2_1252 );
  twobit_branch( 1041, compiled_block_2_1041 );
  twobit_label( 1252, compiled_block_2_1252 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_skip( 1250, compiled_block_2_1250 );
  twobit_label( 1251, compiled_block_2_1251 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_label( 1250, compiled_block_2_1250 );
  twobit_load( 1, 2 );
  twobit_global( 22 ); /*  map~1ay%kV~1381 */
  twobit_setrtn( 1253, compiled_block_2_1253 );
  twobit_invoke( 2 );
  twobit_label( 1253, compiled_block_2_1253 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 20 );
  twobit_branchf( 1255, compiled_block_2_1255 );
  twobit_op1_3(); /* unspecified */
  twobit_skip( 1254, compiled_block_2_1254 );
  twobit_label( 1255, compiled_block_2_1255 );
  twobit_load( 3, 21 );
  twobit_const( 23 );
  twobit_setreg( 1 );
  twobit_const( 24 );
  twobit_setreg( 2 );
  twobit_global( 25 ); /* ex:syntax-violation */
  twobit_setrtn( 1256, compiled_block_2_1256 );
  twobit_invoke( 3 );
  twobit_label( 1256, compiled_block_2_1256 );
  twobit_load( 0, 0 );
  twobit_label( 1254, compiled_block_2_1254 );
  twobit_stack( 8 );
  twobit_branchf( 1258, compiled_block_2_1258 );
  twobit_stack( 8 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 8 );
  twobit_check( 3, 0, 0, 1123, compiled_block_2_1123 );
  twobit_stack( 8 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1153,compiled_block_2_1153); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 1257, compiled_block_2_1257 );
  twobit_label( 1258, compiled_block_2_1258 );
  twobit_stack( 3 );
  twobit_branchf( 1260, compiled_block_2_1260 );
  twobit_stack( 3 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 3 );
  twobit_check( 3, 0, 0, 1123, compiled_block_2_1123 );
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1153,compiled_block_2_1153); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 1257, compiled_block_2_1257 );
  twobit_label( 1260, compiled_block_2_1260 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1257, compiled_block_2_1257 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_stack( 3 );
  twobit_branchf( 1262, compiled_block_2_1262 );
  twobit_stack( 3 );
  twobit_op1_11(); /* pair? */
  twobit_load( 2, 3 );
  twobit_check( 2, 0, 0, 1263, compiled_block_2_1263 );
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg_op1_check_652(reg(3),1123,compiled_block_2_1123); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg_op1_check_652(reg(3),1264,compiled_block_2_1264); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 1261, compiled_block_2_1261 );
  twobit_label( 1262, compiled_block_2_1262 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1261, compiled_block_2_1261 );
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_stack( 7 );
  twobit_branchf( 1266, compiled_block_2_1266 );
  twobit_load( 1, 7 );
  twobit_global( 2 ); /* ex:syntax->datum */
  twobit_setrtn( 1267, compiled_block_2_1267 );
  twobit_invoke( 1 );
  twobit_label( 1267, compiled_block_2_1267 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1268,compiled_block_2_1268); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1153,compiled_block_2_1153); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 1265, compiled_block_2_1265 );
  twobit_label( 1266, compiled_block_2_1266 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1265, compiled_block_2_1265 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_stack( 6 );
  twobit_branchf( 1270, compiled_block_2_1270 );
  twobit_load( 1, 6 );
  twobit_global( 2 ); /* ex:syntax->datum */
  twobit_setrtn( 1271, compiled_block_2_1271 );
  twobit_invoke( 1 );
  twobit_label( 1271, compiled_block_2_1271 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1268,compiled_block_2_1268); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1153,compiled_block_2_1153); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 1269, compiled_block_2_1269 );
  twobit_label( 1270, compiled_block_2_1270 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1269, compiled_block_2_1269 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_stack( 5 );
  twobit_branchf( 1273, compiled_block_2_1273 );
  twobit_load( 1, 5 );
  twobit_global( 2 ); /* ex:syntax->datum */
  twobit_setrtn( 1274, compiled_block_2_1274 );
  twobit_invoke( 1 );
  twobit_label( 1274, compiled_block_2_1274 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1268,compiled_block_2_1268); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1153,compiled_block_2_1153); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 1272, compiled_block_2_1272 );
  twobit_label( 1273, compiled_block_2_1273 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1272, compiled_block_2_1272 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_stack( 4 );
  twobit_op2imm_branchf_640( FALSE_CONST, 1276, compiled_block_2_1276 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1275, compiled_block_2_1275 );
  twobit_label( 1276, compiled_block_2_1276 );
  twobit_stack( 4 );
  twobit_op1_11(); /* pair? */
  twobit_load( 2, 4 );
  twobit_check( 2, 0, 0, 1263, compiled_block_2_1263 );
  twobit_stack( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_610( 1278, compiled_block_2_1278 ); /* internal:branchf-null? */
  twobit_const( 26 );
  twobit_setreg( 1 );
  twobit_global( 27 ); /* gensym */
  twobit_setrtn( 1279, compiled_block_2_1279 );
  twobit_invoke( 1 );
  twobit_label( 1279, compiled_block_2_1279 );
  twobit_load( 0, 0 );
  twobit_skip( 1275, compiled_block_2_1275 );
  twobit_label( 1278, compiled_block_2_1278 );
  twobit_reg_op1_check_652(reg(3),1264,compiled_block_2_1264); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_label( 1275, compiled_block_2_1275 );
  twobit_setreg( 4 );
  twobit_store( 4, 21 );
  twobit_stack( 3 );
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_stack( 8 );
  twobit_setreg( 2 );
  twobit_store( 2, 8 );
  twobit_stack( 5 );
  twobit_setreg( 1 );
  twobit_stack( 6 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_stack( 7 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_load( 3, 12 );
  twobit_load( 2, 14 );
  twobit_movereg( 4, 5 );
  twobit_movereg( 1, 8 );
  twobit_load( 1, 1 );
  twobit_load( 4, 10 );
  twobit_load( 6, 7 );
  twobit_load( 7, 6 );
  twobit_load( 9, 21 );
  twobit_load( 10, 8 );
  twobit_load( 11, 3 );
  twobit_pop( 21 );
  twobit_branch( 1043, compiled_block_2_1043 );
  twobit_label( 1057, compiled_block_2_1057 );
  twobit_load( 1, 21 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_pop( 21 );
  twobit_invoke( 1 );
  twobit_label( 1054, compiled_block_2_1054 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1052, compiled_block_2_1052 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1050, compiled_block_2_1050 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1048, compiled_block_2_1048 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1046, compiled_block_2_1046 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1039, compiled_block_2_1039 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 29 ); /* ex:identifier? */
  twobit_setrtn( 1287, compiled_block_2_1287 );
  twobit_invoke( 1 );
  twobit_label( 1287, compiled_block_2_1287 );
  twobit_load( 0, 0 );
  twobit_branchf( 1289, compiled_block_2_1289 );
  twobit_stack( 1 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1289, compiled_block_2_1289 );
  twobit_stack( 1 );
  twobit_op1_branchf_611( 1291, compiled_block_2_1291 ); /* internal:branchf-pair? */
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_setrtn( 1292, compiled_block_2_1292 );
  twobit_branch( 1039, compiled_block_2_1039 );
  twobit_label( 1292, compiled_block_2_1292 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_setrtn( 1293, compiled_block_2_1293 );
  twobit_branch( 1039, compiled_block_2_1039 );
  twobit_label( 1293, compiled_block_2_1293 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1291, compiled_block_2_1291 );
  twobit_load( 1, 2 );
  twobit_load( 2, 1 );
  twobit_global( 18 ); /* ex:datum->syntax */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1040, compiled_block_2_1040 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1296, compiled_block_2_1296 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1298, compiled_block_2_1298 ); /* internal:branchf-pair? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1299, compiled_block_2_1299 );
  twobit_invoke( 1 );
  twobit_label( 1299, compiled_block_2_1299 );
  twobit_load( 0, 0 );
  twobit_branchf( 1301, compiled_block_2_1301 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_pop( 3 );
  twobit_branch( 1042, compiled_block_2_1042 );
  twobit_label( 1301, compiled_block_2_1301 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1298, compiled_block_2_1298 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1296, compiled_block_2_1296 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1041, compiled_block_2_1041 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1304, compiled_block_2_1304 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1305, compiled_block_2_1305 );
  twobit_invoke( 1 );
  twobit_label( 1305, compiled_block_2_1305 );
  twobit_load( 0, 0 );
  twobit_branchf( 1307, compiled_block_2_1307 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1307, compiled_block_2_1307 );
  twobit_load( 1, 2 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1304, compiled_block_2_1304 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1042, compiled_block_2_1042 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1311, compiled_block_2_1311 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1313, compiled_block_2_1313 ); /* internal:branchf-pair? */
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1314, compiled_block_2_1314 );
  twobit_invoke( 1 );
  twobit_label( 1314, compiled_block_2_1314 );
  twobit_load( 0, 0 );
  twobit_branchf( 1316, compiled_block_2_1316 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1317, compiled_block_2_1317 );
  twobit_invoke( 1 );
  twobit_label( 1317, compiled_block_2_1317 );
  twobit_load( 0, 0 );
  twobit_branchf( 1319, compiled_block_2_1319 );
  twobit_load( 1, 2 );
  twobit_global( 29 ); /* ex:identifier? */
  twobit_setrtn( 1320, compiled_block_2_1320 );
  twobit_invoke( 1 );
  twobit_label( 1320, compiled_block_2_1320 );
  twobit_load( 0, 0 );
  twobit_branchf( 1322, compiled_block_2_1322 );
  twobit_load( 1, 2 );
  twobit_global( 2 ); /* ex:syntax->datum */
  twobit_setrtn( 1323, compiled_block_2_1323 );
  twobit_invoke( 1 );
  twobit_label( 1323, compiled_block_2_1323 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_56( 4 ); /* eq? */
  twobit_skip( 1321, compiled_block_2_1321 );
  twobit_label( 1322, compiled_block_2_1322 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1321, compiled_block_2_1321 );
  twobit_branchf( 1325, compiled_block_2_1325 );
  twobit_load( 4, 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1325, compiled_block_2_1325 );
  twobit_load( 1, 3 );
  twobit_load( 2, 5 );
  twobit_pop( 5 );
  twobit_branch( 1042, compiled_block_2_1042 );
  twobit_label( 1319, compiled_block_2_1319 );
  twobit_load( 1, 3 );
  twobit_load( 2, 1 );
  twobit_pop( 5 );
  twobit_branch( 1040, compiled_block_2_1040 );
  twobit_label( 1316, compiled_block_2_1316 );
  twobit_load( 1, 3 );
  twobit_load( 2, 1 );
  twobit_pop( 5 );
  twobit_branch( 1040, compiled_block_2_1040 );
  twobit_label( 1313, compiled_block_2_1313 );
  twobit_branch( 1040, compiled_block_2_1040 );
  twobit_label( 1311, compiled_block_2_1311 );
  twobit_branch( 1040, compiled_block_2_1040 );
  twobit_label( 1043, compiled_block_2_1043 );
  twobit_save( 13 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_store( 4, 4 );
  twobit_store( 5, 5 );
  twobit_store( 6, 6 );
  twobit_store( 7, 7 );
  twobit_store( 8, 8 );
  twobit_store( 9, 9 );
  twobit_store( 10, 10 );
  twobit_store( 11, 11 );
  twobit_const( 30 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 31 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 32 );
  twobit_setreg( 5 );
  twobit_global( 33 ); /* ex:syntax-rename */
  twobit_setrtn( 1331, compiled_block_2_1331 );
  twobit_invoke( 5 );
  twobit_label( 1331, compiled_block_2_1331 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_setrtn( 1332, compiled_block_2_1332 );
  twobit_branch( 1039, compiled_block_2_1039 );
  twobit_label( 1332, compiled_block_2_1332 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 13 );
  twobit_load( 2, 1 );
  twobit_load( 1, 1 );
  twobit_setrtn( 1333, compiled_block_2_1333 );
  twobit_branch( 1039, compiled_block_2_1039 );
  twobit_label( 1333, compiled_block_2_1333 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_setrtn( 1334, compiled_block_2_1334 );
  twobit_branch( 1039, compiled_block_2_1039 );
  twobit_label( 1334, compiled_block_2_1334 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 2, 3 );
  twobit_load( 1, 1 );
  twobit_setrtn( 1335, compiled_block_2_1335 );
  twobit_branch( 1039, compiled_block_2_1039 );
  twobit_label( 1335, compiled_block_2_1335 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 2, 4 );
  twobit_load( 1, 1 );
  twobit_setrtn( 1336, compiled_block_2_1336 );
  twobit_branch( 1039, compiled_block_2_1039 );
  twobit_label( 1336, compiled_block_2_1336 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 2, 5 );
  twobit_load( 1, 1 );
  twobit_setrtn( 1337, compiled_block_2_1337 );
  twobit_branch( 1039, compiled_block_2_1039 );
  twobit_label( 1337, compiled_block_2_1337 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 2, 6 );
  twobit_load( 1, 1 );
  twobit_setrtn( 1338, compiled_block_2_1338 );
  twobit_branch( 1039, compiled_block_2_1039 );
  twobit_label( 1338, compiled_block_2_1338 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 2, 7 );
  twobit_load( 1, 1 );
  twobit_setrtn( 1339, compiled_block_2_1339 );
  twobit_branch( 1039, compiled_block_2_1039 );
  twobit_label( 1339, compiled_block_2_1339 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 2, 8 );
  twobit_load( 1, 1 );
  twobit_setrtn( 1340, compiled_block_2_1340 );
  twobit_branch( 1039, compiled_block_2_1039 );
  twobit_label( 1340, compiled_block_2_1340 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_load( 2, 9 );
  twobit_load( 1, 1 );
  twobit_setrtn( 1341, compiled_block_2_1341 );
  twobit_branch( 1039, compiled_block_2_1039 );
  twobit_label( 1341, compiled_block_2_1341 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_load( 2, 10 );
  twobit_load( 1, 1 );
  twobit_setrtn( 1342, compiled_block_2_1342 );
  twobit_branch( 1039, compiled_block_2_1039 );
  twobit_label( 1342, compiled_block_2_1342 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_load( 2, 11 );
  twobit_load( 1, 1 );
  twobit_setrtn( 1343, compiled_block_2_1343 );
  twobit_branch( 1039, compiled_block_2_1039 );
  twobit_label( 1343, compiled_block_2_1343 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 13 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1345, compiled_block_2_1345 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1347, compiled_block_2_1347 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1349, compiled_block_2_1349 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1351, compiled_block_2_1351 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1353, compiled_block_2_1353 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1355, compiled_block_2_1355 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1357, compiled_block_2_1357 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1359, compiled_block_2_1359 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1361, compiled_block_2_1361 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1363, compiled_block_2_1363 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 13 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1365, compiled_block_2_1365 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1367, compiled_block_2_1367 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 13 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 13 );
  twobit_return();
  twobit_label( 1367, compiled_block_2_1367 );
  twobit_load( 1, 9 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_pop( 13 );
  twobit_invoke( 1 );
  twobit_label( 1365, compiled_block_2_1365 );
  twobit_load( 1, 9 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_pop( 13 );
  twobit_invoke( 1 );
  twobit_label( 1363, compiled_block_2_1363 );
  twobit_load( 1, 9 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_pop( 13 );
  twobit_invoke( 1 );
  twobit_label( 1361, compiled_block_2_1361 );
  twobit_load( 1, 9 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_pop( 13 );
  twobit_invoke( 1 );
  twobit_label( 1359, compiled_block_2_1359 );
  twobit_load( 1, 9 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_pop( 13 );
  twobit_invoke( 1 );
  twobit_label( 1357, compiled_block_2_1357 );
  twobit_load( 1, 9 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_pop( 13 );
  twobit_invoke( 1 );
  twobit_label( 1355, compiled_block_2_1355 );
  twobit_load( 1, 9 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_pop( 13 );
  twobit_invoke( 1 );
  twobit_label( 1353, compiled_block_2_1353 );
  twobit_load( 1, 9 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_pop( 13 );
  twobit_invoke( 1 );
  twobit_label( 1351, compiled_block_2_1351 );
  twobit_load( 1, 9 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_pop( 13 );
  twobit_invoke( 1 );
  twobit_label( 1349, compiled_block_2_1349 );
  twobit_load( 1, 9 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_pop( 13 );
  twobit_invoke( 1 );
  twobit_label( 1347, compiled_block_2_1347 );
  twobit_movereg( 4, 1 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_pop( 13 );
  twobit_invoke( 1 );
  twobit_label( 1345, compiled_block_2_1345 );
  twobit_movereg( 4, 1 );
  twobit_global( 28 ); /* ex:invalid-form */
  twobit_pop( 13 );
  twobit_invoke( 1 );
  twobit_label( 1153, compiled_block_2_1153 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 1123, compiled_block_2_1123 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_label( 1268, compiled_block_2_1268 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_label( 1264, compiled_block_2_1264 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_label( 1263, compiled_block_2_1263 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_21( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_17(); /* symbol? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1091, compiled_block_2_1091 );
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1091, compiled_block_2_1091 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1092, compiled_block_2_1092 );
  twobit_invoke( 1 );
  twobit_label( 1092, compiled_block_2_1092 );
  twobit_load( 0, 0 );
  twobit_branchf( 1094, compiled_block_2_1094 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* length */
  twobit_setrtn( 1095, compiled_block_2_1095 );
  twobit_invoke( 1 );
  twobit_label( 1095, compiled_block_2_1095 );
  twobit_load( 0, 0 );
  twobit_op2imm_branchf_637( fixnum(2), 30, compiled_temp_2_30, 1097, compiled_block_2_1097 ); /* internal:branchf->=/imm */
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1098, compiled_block_2_1098 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 1100, compiled_block_2_1100 ); /* internal:branchf-eq? */
  twobit_const( 4 );
  twobit_skip( 1099, compiled_block_2_1099 );
  twobit_label( 1100, compiled_block_2_1100 );
  twobit_const( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_const( 5 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 2, 1102, compiled_block_2_1102 ); /* internal:branchf-eq? */
  twobit_reg( 3 );
  twobit_skip( 1099, compiled_block_2_1099 );
  twobit_label( 1102, compiled_block_2_1102 );
  twobit_reg_op1_check_652(reg(3),1103,compiled_block_2_1103); /* internal:check-pair? with (3 0 0) */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1099, compiled_block_2_1099 );
  twobit_branchf( 1105, compiled_block_2_1105 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1106,compiled_block_2_1106); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_op1_17(); /* symbol? */
  twobit_branchf( 1108, compiled_block_2_1108 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* length */
  twobit_setrtn( 1109, compiled_block_2_1109 );
  twobit_invoke( 1 );
  twobit_label( 1109, compiled_block_2_1109 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(2), 1111, compiled_block_2_1111 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1111, compiled_block_2_1111 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(3), 1113, compiled_block_2_1113 ); /* internal:branchf-eq?/imm */
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_const_setreg( 3, 3 );
  twobit_op2_branchf_624( 3, 1115, compiled_block_2_1115 ); /* internal:branchf-eq? */
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1116,compiled_block_2_1116); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1106,compiled_block_2_1106); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_op1_17(); /* symbol? */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1115, compiled_block_2_1115 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1113, compiled_block_2_1113 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(4), 1118, compiled_block_2_1118 ); /* internal:branchf-eq?/imm */
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_const_setreg( 5, 3 );
  twobit_op2_branchf_624( 3, 1120, compiled_block_2_1120 ); /* internal:branchf-eq? */
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1116,compiled_block_2_1116); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1106,compiled_block_2_1106); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_op1_17(); /* symbol? */
  twobit_branchf( 1122, compiled_block_2_1122 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1106,compiled_block_2_1106); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_op1_17(); /* symbol? */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1122, compiled_block_2_1122 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1120, compiled_block_2_1120 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1118, compiled_block_2_1118 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1108, compiled_block_2_1108 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1105, compiled_block_2_1105 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1097, compiled_block_2_1097 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1094, compiled_block_2_1094 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1106, compiled_block_2_1106 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 1103, compiled_block_2_1103 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_label( 1116, compiled_block_2_1116 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_label( 1098, compiled_block_2_1098 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_27( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:identifier? */
  twobit_setrtn( 1198, compiled_block_2_1198 );
  twobit_invoke( 1 );
  twobit_label( 1198, compiled_block_2_1198 );
  twobit_load( 0, 0 );
  twobit_branchf( 1200, compiled_block_2_1200 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1201, compiled_block_2_1201 );
  twobit_invoke( 5 );
  twobit_label( 1201, compiled_block_2_1201 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_skip( 1199, compiled_block_2_1199 );
  twobit_label( 1200, compiled_block_2_1200 );
  twobit_stack( 1 );
  twobit_label( 1199, compiled_block_2_1199 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1202, compiled_block_2_1202 );
  twobit_invoke( 1 );
  twobit_label( 1202, compiled_block_2_1202 );
  twobit_load( 0, 0 );
  twobit_op2imm_branchf_639( fixnum(2), 28, compiled_temp_2_28, 1204, compiled_block_2_1204 ); /* internal:branchf-=/imm */
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 2 );
  twobit_check( 3, 0, 0, 1205, compiled_block_2_1205 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1206,compiled_block_2_1206); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 7 ); /* ex:syntax->datum */
  twobit_setrtn( 1207, compiled_block_2_1207 );
  twobit_invoke( 1 );
  twobit_label( 1207, compiled_block_2_1207 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 8 ); /* symbol->string */
  twobit_setrtn( 1208, compiled_block_2_1208 );
  twobit_invoke( 1 );
  twobit_label( 1208, compiled_block_2_1208 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_const( 9 );
  twobit_setreg( 2 );
  twobit_global( 10 ); /* string-append */
  twobit_setrtn( 1209, compiled_block_2_1209 );
  twobit_invoke( 3 );
  twobit_label( 1209, compiled_block_2_1209 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 11 ); /* string->symbol */
  twobit_setrtn( 1210, compiled_block_2_1210 );
  twobit_invoke( 1 );
  twobit_label( 1210, compiled_block_2_1210 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 7 ); /* ex:syntax->datum */
  twobit_setrtn( 1211, compiled_block_2_1211 );
  twobit_invoke( 1 );
  twobit_label( 1211, compiled_block_2_1211 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 1213, compiled_block_2_1213 ); /* internal:branchf-eq? */
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1206,compiled_block_2_1206); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1215, compiled_block_2_1215 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1217, compiled_block_2_1217 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1218, compiled_block_2_1218 );
  twobit_invoke( 5 );
  twobit_label( 1218, compiled_block_2_1218 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1217, compiled_block_2_1217 );
  twobit_movereg( 4, 1 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1215, compiled_block_2_1215 );
  twobit_movereg( 4, 1 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1213, compiled_block_2_1213 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 1222, compiled_block_2_1222 ); /* internal:branchf-eq? */
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1206,compiled_block_2_1206); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 7 ); /* ex:syntax->datum */
  twobit_setrtn( 1223, compiled_block_2_1223 );
  twobit_invoke( 1 );
  twobit_label( 1223, compiled_block_2_1223 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 8 ); /* symbol->string */
  twobit_setrtn( 1224, compiled_block_2_1224 );
  twobit_invoke( 1 );
  twobit_label( 1224, compiled_block_2_1224 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_const( 9 );
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 4 );
  twobit_global( 10 ); /* string-append */
  twobit_setrtn( 1225, compiled_block_2_1225 );
  twobit_invoke( 4 );
  twobit_label( 1225, compiled_block_2_1225 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 11 ); /* string->symbol */
  twobit_setrtn( 1226, compiled_block_2_1226 );
  twobit_invoke( 1 );
  twobit_label( 1226, compiled_block_2_1226 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1228, compiled_block_2_1228 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1230, compiled_block_2_1230 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1232, compiled_block_2_1232 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1233, compiled_block_2_1233 );
  twobit_invoke( 5 );
  twobit_label( 1233, compiled_block_2_1233 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1232, compiled_block_2_1232 );
  twobit_load( 1, 1 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1230, compiled_block_2_1230 );
  twobit_movereg( 4, 1 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1228, compiled_block_2_1228 );
  twobit_movereg( 4, 1 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1222, compiled_block_2_1222 );
  twobit_op1_3(); /* unspecified */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1204, compiled_block_2_1204 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1237, compiled_block_2_1237 );
  twobit_invoke( 1 );
  twobit_label( 1237, compiled_block_2_1237 );
  twobit_load( 0, 0 );
  twobit_op2imm_branchf_639( fixnum(3), 29, compiled_temp_2_29, 1239, compiled_block_2_1239 ); /* internal:branchf-=/imm */
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 2 );
  twobit_check( 3, 0, 0, 1240, compiled_block_2_1240 );
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg_op1_check_652(reg(3),1240,compiled_block_2_1240); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg_op1_check_652(reg(3),1240,compiled_block_2_1240); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_imm_const_setreg( NIL_CONST, 1 ); /* () */
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1242, compiled_block_2_1242 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1244, compiled_block_2_1244 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1246, compiled_block_2_1246 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1246, compiled_block_2_1246 );
  twobit_load( 1, 2 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1244, compiled_block_2_1244 );
  twobit_movereg( 4, 1 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1242, compiled_block_2_1242 );
  twobit_movereg( 4, 1 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1239, compiled_block_2_1239 );
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1206, compiled_block_2_1206 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 1205, compiled_block_2_1205 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_label( 1240, compiled_block_2_1240 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_8( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1382, compiled_block_2_1382 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1384, compiled_block_2_1384 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1386, compiled_block_2_1386 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1388, compiled_block_2_1388 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1390, compiled_block_2_1390 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1392, compiled_block_2_1392 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_lambda( compiled_start_2_15, 2, 0 );
  twobit_setreg( 29 );
  twobit_movereg( 31, 6 );
  twobit_load( 5, 1 );
  twobit_movereg( 30, 2 );
  twobit_lambda( compiled_start_2_16, 4, 6 );
  twobit_setreg( 3 );
  twobit_movereg( 29, 1 );
  twobit_load( 2, 2 );
  twobit_global( 5 ); /* ex:map-while */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1392, compiled_block_2_1392 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1390, compiled_block_2_1390 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1388, compiled_block_2_1388 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1386, compiled_block_2_1386 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1384, compiled_block_2_1384 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1382, compiled_block_2_1382 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_15( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1394, compiled_block_2_1394 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1396, compiled_block_2_1396 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1398, compiled_block_2_1398 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1400, compiled_block_2_1400 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1402, compiled_block_2_1402 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 31 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_return();
  twobit_label( 1402, compiled_block_2_1402 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1400, compiled_block_2_1400 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1398, compiled_block_2_1398 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1396, compiled_block_2_1396 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1394, compiled_block_2_1394 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_16( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1404, compiled_block_2_1404 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_17, 2, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1479, compiled_block_2_1479 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_skip( 1478, compiled_block_2_1478 );
  twobit_label( 1479, compiled_block_2_1479 );
  twobit_movereg( 1, 3 );
  twobit_global( 4 ); /* map */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* list */
  twobit_setreg( 2 );
  twobit_global( 6 ); /* apply */
  twobit_setrtn( 1480, compiled_block_2_1480 );
  twobit_invoke( 3 );
  twobit_label( 1480, compiled_block_2_1480 );
  twobit_load( 0, 0 );
  twobit_label( 1478, compiled_block_2_1478 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1404, compiled_block_2_1404 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_17( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_lexical( 1, 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_branchf_611( 1410, compiled_block_2_1410 ); /* internal:branchf-pair? */
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_branchf_611( 1412, compiled_block_2_1412 ); /* internal:branchf-pair? */
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 29 );
  twobit_reg( 31 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_branchf_611( 1414, compiled_block_2_1414 ); /* internal:branchf-pair? */
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 28 );
  twobit_reg( 31 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_branchf_611( 1416, compiled_block_2_1416 ); /* internal:branchf-pair? */
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 27 );
  twobit_reg( 31 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_branchf_611( 1418, compiled_block_2_1418 ); /* internal:branchf-pair? */
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 26 );
  twobit_reg( 31 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_branchf_611( 1420, compiled_block_2_1420 ); /* internal:branchf-pair? */
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 25 );
  twobit_reg( 31 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1422, compiled_block_2_1422 ); /* internal:branchf-null? */
  twobit_save( 12 );
  twobit_store( 0, 0 );
  twobit_store( 1, 5 );
  twobit_store( 2, 6 );
  twobit_store( 3, 10 );
  twobit_store( 4, 11 );
  twobit_store( 25, 9 );
  twobit_store( 26, 4 );
  twobit_store( 27, 1 );
  twobit_store( 28, 2 );
  twobit_store( 29, 3 );
  twobit_store( 30, 8 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1423, compiled_block_2_1423 );
  twobit_invoke( 5 );
  twobit_label( 1423, compiled_block_2_1423 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1424, compiled_block_2_1424 );
  twobit_invoke( 5 );
  twobit_label( 1424, compiled_block_2_1424 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_load( 1, 5 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1425, compiled_block_2_1425 );
  twobit_invoke( 1 );
  twobit_label( 1425, compiled_block_2_1425 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 6 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1426, compiled_block_2_1426 );
  twobit_invoke( 1 );
  twobit_label( 1426, compiled_block_2_1426 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_branchf_623( 4, 18, compiled_temp_2_18, 1428, compiled_block_2_1428 ); /* internal:branchf-= */
  twobit_load( 1, 5 );
  twobit_load( 2, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_setrtn( 1429, compiled_block_2_1429 );
  twobit_branch( 1407, compiled_block_2_1407 );
  twobit_label( 1429, compiled_block_2_1429 );
  twobit_load( 0, 0 );
  twobit_skip( 1427, compiled_block_2_1427 );
  twobit_label( 1428, compiled_block_2_1428 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_global( 10 ); /* ex:syntax-violation */
  twobit_setrtn( 1430, compiled_block_2_1430 );
  twobit_invoke( 4 );
  twobit_label( 1430, compiled_block_2_1430 );
  twobit_load( 0, 0 );
  twobit_label( 1427, compiled_block_2_1427 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_lexical( 1, 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_lexical( 1, 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 8 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 9 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_lexical( 1, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1431, compiled_block_2_1431 );
  twobit_invoke( 5 );
  twobit_label( 1431, compiled_block_2_1431 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_lexical( 1, 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_lexical( 1, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1432, compiled_block_2_1432 );
  twobit_invoke( 5 );
  twobit_label( 1432, compiled_block_2_1432 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_lexical( 1, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_lexical( 1, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1433, compiled_block_2_1433 );
  twobit_invoke( 5 );
  twobit_label( 1433, compiled_block_2_1433 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 6 );
  twobit_load( 3, 4 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1434, compiled_block_2_1434 );
  twobit_invoke( 1 );
  twobit_label( 1434, compiled_block_2_1434 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 10 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1435, compiled_block_2_1435 );
  twobit_invoke( 1 );
  twobit_label( 1435, compiled_block_2_1435 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_branchf_623( 4, 19, compiled_temp_2_19, 1437, compiled_block_2_1437 ); /* internal:branchf-= */
  twobit_load( 1, 6 );
  twobit_load( 2, 10 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_setrtn( 1438, compiled_block_2_1438 );
  twobit_branch( 1406, compiled_block_2_1406 );
  twobit_label( 1438, compiled_block_2_1438 );
  twobit_load( 0, 0 );
  twobit_skip( 1436, compiled_block_2_1436 );
  twobit_label( 1437, compiled_block_2_1437 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_global( 10 ); /* ex:syntax-violation */
  twobit_setrtn( 1439, compiled_block_2_1439 );
  twobit_invoke( 4 );
  twobit_label( 1439, compiled_block_2_1439 );
  twobit_load( 0, 0 );
  twobit_label( 1436, compiled_block_2_1436 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 6 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1440, compiled_block_2_1440 );
  twobit_invoke( 1 );
  twobit_label( 1440, compiled_block_2_1440 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_load( 1, 11 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1441, compiled_block_2_1441 );
  twobit_invoke( 1 );
  twobit_label( 1441, compiled_block_2_1441 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_branchf_623( 4, 20, compiled_temp_2_20, 1443, compiled_block_2_1443 ); /* internal:branchf-= */
  twobit_load( 1, 6 );
  twobit_load( 2, 11 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_setrtn( 1444, compiled_block_2_1444 );
  twobit_branch( 1405, compiled_block_2_1405 );
  twobit_label( 1444, compiled_block_2_1444 );
  twobit_load( 0, 0 );
  twobit_skip( 1442, compiled_block_2_1442 );
  twobit_label( 1443, compiled_block_2_1443 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_global( 10 ); /* ex:syntax-violation */
  twobit_setrtn( 1445, compiled_block_2_1445 );
  twobit_invoke( 4 );
  twobit_label( 1445, compiled_block_2_1445 );
  twobit_load( 0, 0 );
  twobit_label( 1442, compiled_block_2_1442 );
  twobit_setreg( 2 );
  twobit_load( 1, 4 );
  twobit_global( 16 ); /* append */
  twobit_setrtn( 1446, compiled_block_2_1446 );
  twobit_invoke( 2 );
  twobit_label( 1446, compiled_block_2_1446 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 12 );
  twobit_return();
  twobit_label( 1422, compiled_block_2_1422 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 17 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1420, compiled_block_2_1420 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 17 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1418, compiled_block_2_1418 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 17 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1416, compiled_block_2_1416 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 17 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1414, compiled_block_2_1414 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 17 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1412, compiled_block_2_1412 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 17 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1410, compiled_block_2_1410 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 17 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1405, compiled_block_2_1405 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1455, compiled_block_2_1455 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1454, compiled_block_2_1454 );
  twobit_label( 1455, compiled_block_2_1455 );
  twobit_reg( 2 );
  twobit_op1_10(); /* null? */
  twobit_label( 1454, compiled_block_2_1454 );
  twobit_branchf( 1457, compiled_block_2_1457 );
  twobit_movereg( 3, 1 );
  twobit_global( 18 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1457, compiled_block_2_1457 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 3, 4 );
  twobit_reg_op1_check_652(reg(1),1459,compiled_block_2_1459); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg_op1_check_652(reg(2),1460,compiled_block_2_1460); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 1 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 30 );
  twobit_reg( 2 );
  twobit_op2_58( 30 ); /* cons */
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_lexical( 1, 3 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1461, compiled_block_2_1461 );
  twobit_invoke( 5 );
  twobit_label( 1461, compiled_block_2_1461 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_load( 1, 2 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_pop( 4 );
  twobit_branch( 1405, compiled_block_2_1405 );
  twobit_label( 1406, compiled_block_2_1406 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1464, compiled_block_2_1464 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1463, compiled_block_2_1463 );
  twobit_label( 1464, compiled_block_2_1464 );
  twobit_reg( 2 );
  twobit_op1_10(); /* null? */
  twobit_label( 1463, compiled_block_2_1463 );
  twobit_branchf( 1466, compiled_block_2_1466 );
  twobit_movereg( 3, 1 );
  twobit_global( 18 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1466, compiled_block_2_1466 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 3, 4 );
  twobit_reg_op1_check_652(reg(1),1459,compiled_block_2_1459); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg_op1_check_652(reg(2),1460,compiled_block_2_1460); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 1 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 30 );
  twobit_reg( 2 );
  twobit_op2_58( 30 ); /* cons */
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_lexical( 1, 3 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_const( 20 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1468, compiled_block_2_1468 );
  twobit_invoke( 5 );
  twobit_label( 1468, compiled_block_2_1468 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_load( 1, 2 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_pop( 4 );
  twobit_branch( 1406, compiled_block_2_1406 );
  twobit_label( 1407, compiled_block_2_1407 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1471, compiled_block_2_1471 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1470, compiled_block_2_1470 );
  twobit_label( 1471, compiled_block_2_1471 );
  twobit_reg( 2 );
  twobit_op1_10(); /* null? */
  twobit_label( 1470, compiled_block_2_1470 );
  twobit_branchf( 1473, compiled_block_2_1473 );
  twobit_movereg( 3, 1 );
  twobit_global( 18 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1473, compiled_block_2_1473 );
  twobit_reg_op1_check_652(reg(2),1475,compiled_block_2_1475); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(1),1476,compiled_block_2_1476); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op2_58( 30 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 31 );
  twobit_op2_58( 4 ); /* cons */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_branch( 1407, compiled_block_2_1407 );
  twobit_label( 1475, compiled_block_2_1475 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 1459, compiled_block_2_1459 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_label( 1460, compiled_block_2_1460 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_label( 1476, compiled_block_2_1476 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_9( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1500, compiled_block_2_1500 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1502, compiled_block_2_1502 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1504, compiled_block_2_1504 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1506, compiled_block_2_1506 ); /* internal:branchf-pair? */
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 8 );
  twobit_store( 2, 2 );
  twobit_store( 3, 6 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 4 );
  twobit_movereg( 31, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1507, compiled_block_2_1507 );
  twobit_invoke( 1 );
  twobit_label( 1507, compiled_block_2_1507 );
  twobit_load( 0, 0 );
  twobit_branchf( 1509, compiled_block_2_1509 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1511, compiled_block_2_1511 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1513, compiled_block_2_1513 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1514, compiled_block_2_1514 );
  twobit_invoke( 2 );
  twobit_label( 1514, compiled_block_2_1514 );
  twobit_load( 0, 0 );
  twobit_branchf( 1516, compiled_block_2_1516 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1518, compiled_block_2_1518 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1519, compiled_block_2_1519 );
  twobit_invoke( 2 );
  twobit_label( 1519, compiled_block_2_1519 );
  twobit_load( 0, 0 );
  twobit_branchf( 1521, compiled_block_2_1521 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1523, compiled_block_2_1523 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1524, compiled_block_2_1524 );
  twobit_invoke( 2 );
  twobit_label( 1524, compiled_block_2_1524 );
  twobit_load( 0, 0 );
  twobit_branchf( 1526, compiled_block_2_1526 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1528, compiled_block_2_1528 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 4 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1529, compiled_block_2_1529 );
  twobit_invoke( 5 );
  twobit_label( 1529, compiled_block_2_1529 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 4 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1530, compiled_block_2_1530 );
  twobit_invoke( 5 );
  twobit_label( 1530, compiled_block_2_1530 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 4 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1531, compiled_block_2_1531 );
  twobit_invoke( 5 );
  twobit_label( 1531, compiled_block_2_1531 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 4 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1532, compiled_block_2_1532 );
  twobit_invoke( 5 );
  twobit_label( 1532, compiled_block_2_1532 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 4 );
  twobit_global( 9 ); /* list->vector */
  twobit_setrtn( 1533, compiled_block_2_1533 );
  twobit_invoke( 1 );
  twobit_label( 1533, compiled_block_2_1533 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 1528, compiled_block_2_1528 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1497, compiled_block_2_1497 );
  twobit_label( 1526, compiled_block_2_1526 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1497, compiled_block_2_1497 );
  twobit_label( 1523, compiled_block_2_1523 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1497, compiled_block_2_1497 );
  twobit_label( 1521, compiled_block_2_1521 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1497, compiled_block_2_1497 );
  twobit_label( 1518, compiled_block_2_1518 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1497, compiled_block_2_1497 );
  twobit_label( 1516, compiled_block_2_1516 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1497, compiled_block_2_1497 );
  twobit_label( 1513, compiled_block_2_1513 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1497, compiled_block_2_1497 );
  twobit_label( 1511, compiled_block_2_1511 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1497, compiled_block_2_1497 );
  twobit_label( 1509, compiled_block_2_1509 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1497, compiled_block_2_1497 );
  twobit_label( 1506, compiled_block_2_1506 );
  twobit_branch( 1497, compiled_block_2_1497 );
  twobit_label( 1504, compiled_block_2_1504 );
  twobit_branch( 1497, compiled_block_2_1497 );
  twobit_label( 1502, compiled_block_2_1502 );
  twobit_branch( 1497, compiled_block_2_1497 );
  twobit_label( 1500, compiled_block_2_1500 );
  twobit_branch( 1497, compiled_block_2_1497 );
  twobit_label( 1491, compiled_block_2_1491 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1548, compiled_block_2_1548 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1550, compiled_block_2_1550 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1552, compiled_block_2_1552 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1554, compiled_block_2_1554 ); /* internal:branchf-pair? */
  twobit_save( 11 );
  twobit_store( 0, 0 );
  twobit_store( 1, 11 );
  twobit_store( 2, 2 );
  twobit_store( 3, 9 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 3 );
  twobit_movereg( 31, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1555, compiled_block_2_1555 );
  twobit_invoke( 1 );
  twobit_label( 1555, compiled_block_2_1555 );
  twobit_load( 0, 0 );
  twobit_branchf( 1557, compiled_block_2_1557 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1559, compiled_block_2_1559 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1561, compiled_block_2_1561 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1563, compiled_block_2_1563 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1565, compiled_block_2_1565 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1567, compiled_block_2_1567 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1568, compiled_block_2_1568 );
  twobit_invoke( 5 );
  twobit_label( 1568, compiled_block_2_1568 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1569, compiled_block_2_1569 );
  twobit_invoke( 5 );
  twobit_label( 1569, compiled_block_2_1569 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1570, compiled_block_2_1570 );
  twobit_invoke( 5 );
  twobit_label( 1570, compiled_block_2_1570 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1571, compiled_block_2_1571 );
  twobit_invoke( 5 );
  twobit_label( 1571, compiled_block_2_1571 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 3 );
  twobit_global( 9 ); /* list->vector */
  twobit_setrtn( 1572, compiled_block_2_1572 );
  twobit_invoke( 1 );
  twobit_label( 1572, compiled_block_2_1572 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1573, compiled_block_2_1573 );
  twobit_invoke( 5 );
  twobit_label( 1573, compiled_block_2_1573 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1574, compiled_block_2_1574 );
  twobit_invoke( 5 );
  twobit_label( 1574, compiled_block_2_1574 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1575, compiled_block_2_1575 );
  twobit_invoke( 5 );
  twobit_label( 1575, compiled_block_2_1575 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1576, compiled_block_2_1576 );
  twobit_invoke( 5 );
  twobit_label( 1576, compiled_block_2_1576 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1577, compiled_block_2_1577 );
  twobit_invoke( 5 );
  twobit_label( 1577, compiled_block_2_1577 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1578, compiled_block_2_1578 );
  twobit_invoke( 5 );
  twobit_label( 1578, compiled_block_2_1578 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1579, compiled_block_2_1579 );
  twobit_invoke( 5 );
  twobit_label( 1579, compiled_block_2_1579 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 11 );
  twobit_return();
  twobit_label( 1567, compiled_block_2_1567 );
  twobit_load( 1, 11 );
  twobit_global( 14 ); /* ex:invalid-form */
  twobit_pop( 11 );
  twobit_invoke( 1 );
  twobit_label( 1565, compiled_block_2_1565 );
  twobit_load( 1, 11 );
  twobit_global( 14 ); /* ex:invalid-form */
  twobit_pop( 11 );
  twobit_invoke( 1 );
  twobit_label( 1563, compiled_block_2_1563 );
  twobit_load( 1, 11 );
  twobit_global( 14 ); /* ex:invalid-form */
  twobit_pop( 11 );
  twobit_invoke( 1 );
  twobit_label( 1561, compiled_block_2_1561 );
  twobit_load( 1, 11 );
  twobit_global( 14 ); /* ex:invalid-form */
  twobit_pop( 11 );
  twobit_invoke( 1 );
  twobit_label( 1559, compiled_block_2_1559 );
  twobit_load( 1, 11 );
  twobit_global( 14 ); /* ex:invalid-form */
  twobit_pop( 11 );
  twobit_invoke( 1 );
  twobit_label( 1557, compiled_block_2_1557 );
  twobit_load( 1, 11 );
  twobit_global( 14 ); /* ex:invalid-form */
  twobit_pop( 11 );
  twobit_invoke( 1 );
  twobit_label( 1554, compiled_block_2_1554 );
  twobit_global( 14 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1552, compiled_block_2_1552 );
  twobit_global( 14 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1550, compiled_block_2_1550 );
  twobit_global( 14 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1548, compiled_block_2_1548 );
  twobit_global( 14 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1492, compiled_block_2_1492 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1591, compiled_block_2_1591 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1593, compiled_block_2_1593 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1595, compiled_block_2_1595 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1597, compiled_block_2_1597 ); /* internal:branchf-pair? */
  twobit_save( 10 );
  twobit_store( 0, 0 );
  twobit_store( 1, 10 );
  twobit_store( 2, 2 );
  twobit_store( 3, 8 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 3 );
  twobit_movereg( 31, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1598, compiled_block_2_1598 );
  twobit_invoke( 1 );
  twobit_label( 1598, compiled_block_2_1598 );
  twobit_load( 0, 0 );
  twobit_branchf( 1600, compiled_block_2_1600 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1602, compiled_block_2_1602 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1604, compiled_block_2_1604 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1605, compiled_block_2_1605 );
  twobit_invoke( 2 );
  twobit_label( 1605, compiled_block_2_1605 );
  twobit_load( 0, 0 );
  twobit_branchf( 1607, compiled_block_2_1607 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1609, compiled_block_2_1609 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1611, compiled_block_2_1611 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1613, compiled_block_2_1613 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1614, compiled_block_2_1614 );
  twobit_invoke( 5 );
  twobit_label( 1614, compiled_block_2_1614 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1615, compiled_block_2_1615 );
  twobit_invoke( 5 );
  twobit_label( 1615, compiled_block_2_1615 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1616, compiled_block_2_1616 );
  twobit_invoke( 5 );
  twobit_label( 1616, compiled_block_2_1616 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1617, compiled_block_2_1617 );
  twobit_invoke( 5 );
  twobit_label( 1617, compiled_block_2_1617 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 3 );
  twobit_global( 9 ); /* list->vector */
  twobit_setrtn( 1618, compiled_block_2_1618 );
  twobit_invoke( 1 );
  twobit_label( 1618, compiled_block_2_1618 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1619, compiled_block_2_1619 );
  twobit_invoke( 5 );
  twobit_label( 1619, compiled_block_2_1619 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1620, compiled_block_2_1620 );
  twobit_invoke( 5 );
  twobit_label( 1620, compiled_block_2_1620 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1621, compiled_block_2_1621 );
  twobit_invoke( 5 );
  twobit_label( 1621, compiled_block_2_1621 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1622, compiled_block_2_1622 );
  twobit_invoke( 5 );
  twobit_label( 1622, compiled_block_2_1622 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1623, compiled_block_2_1623 );
  twobit_invoke( 5 );
  twobit_label( 1623, compiled_block_2_1623 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 10 );
  twobit_return();
  twobit_label( 1613, compiled_block_2_1613 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1491, compiled_block_2_1491 );
  twobit_label( 1611, compiled_block_2_1611 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1491, compiled_block_2_1491 );
  twobit_label( 1609, compiled_block_2_1609 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1491, compiled_block_2_1491 );
  twobit_label( 1607, compiled_block_2_1607 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1491, compiled_block_2_1491 );
  twobit_label( 1604, compiled_block_2_1604 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1491, compiled_block_2_1491 );
  twobit_label( 1602, compiled_block_2_1602 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1491, compiled_block_2_1491 );
  twobit_label( 1600, compiled_block_2_1600 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1491, compiled_block_2_1491 );
  twobit_label( 1597, compiled_block_2_1597 );
  twobit_branch( 1491, compiled_block_2_1491 );
  twobit_label( 1595, compiled_block_2_1595 );
  twobit_branch( 1491, compiled_block_2_1491 );
  twobit_label( 1593, compiled_block_2_1593 );
  twobit_branch( 1491, compiled_block_2_1491 );
  twobit_label( 1591, compiled_block_2_1591 );
  twobit_branch( 1491, compiled_block_2_1491 );
  twobit_label( 1493, compiled_block_2_1493 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1636, compiled_block_2_1636 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1638, compiled_block_2_1638 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1640, compiled_block_2_1640 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1642, compiled_block_2_1642 ); /* internal:branchf-pair? */
  twobit_save( 10 );
  twobit_store( 0, 0 );
  twobit_store( 1, 10 );
  twobit_store( 2, 2 );
  twobit_store( 3, 8 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 3 );
  twobit_movereg( 31, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1643, compiled_block_2_1643 );
  twobit_invoke( 1 );
  twobit_label( 1643, compiled_block_2_1643 );
  twobit_load( 0, 0 );
  twobit_branchf( 1645, compiled_block_2_1645 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1647, compiled_block_2_1647 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1649, compiled_block_2_1649 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1651, compiled_block_2_1651 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1652, compiled_block_2_1652 );
  twobit_invoke( 2 );
  twobit_label( 1652, compiled_block_2_1652 );
  twobit_load( 0, 0 );
  twobit_branchf( 1654, compiled_block_2_1654 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1656, compiled_block_2_1656 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1658, compiled_block_2_1658 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1659, compiled_block_2_1659 );
  twobit_invoke( 5 );
  twobit_label( 1659, compiled_block_2_1659 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1660, compiled_block_2_1660 );
  twobit_invoke( 5 );
  twobit_label( 1660, compiled_block_2_1660 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1661, compiled_block_2_1661 );
  twobit_invoke( 5 );
  twobit_label( 1661, compiled_block_2_1661 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1662, compiled_block_2_1662 );
  twobit_invoke( 5 );
  twobit_label( 1662, compiled_block_2_1662 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 3 );
  twobit_global( 9 ); /* list->vector */
  twobit_setrtn( 1663, compiled_block_2_1663 );
  twobit_invoke( 1 );
  twobit_label( 1663, compiled_block_2_1663 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1664, compiled_block_2_1664 );
  twobit_invoke( 5 );
  twobit_label( 1664, compiled_block_2_1664 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1665, compiled_block_2_1665 );
  twobit_invoke( 5 );
  twobit_label( 1665, compiled_block_2_1665 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1666, compiled_block_2_1666 );
  twobit_invoke( 5 );
  twobit_label( 1666, compiled_block_2_1666 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1667, compiled_block_2_1667 );
  twobit_invoke( 5 );
  twobit_label( 1667, compiled_block_2_1667 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1668, compiled_block_2_1668 );
  twobit_invoke( 5 );
  twobit_label( 1668, compiled_block_2_1668 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 10 );
  twobit_return();
  twobit_label( 1658, compiled_block_2_1658 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1492, compiled_block_2_1492 );
  twobit_label( 1656, compiled_block_2_1656 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1492, compiled_block_2_1492 );
  twobit_label( 1654, compiled_block_2_1654 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1492, compiled_block_2_1492 );
  twobit_label( 1651, compiled_block_2_1651 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1492, compiled_block_2_1492 );
  twobit_label( 1649, compiled_block_2_1649 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1492, compiled_block_2_1492 );
  twobit_label( 1647, compiled_block_2_1647 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1492, compiled_block_2_1492 );
  twobit_label( 1645, compiled_block_2_1645 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1492, compiled_block_2_1492 );
  twobit_label( 1642, compiled_block_2_1642 );
  twobit_branch( 1492, compiled_block_2_1492 );
  twobit_label( 1640, compiled_block_2_1640 );
  twobit_branch( 1492, compiled_block_2_1492 );
  twobit_label( 1638, compiled_block_2_1638 );
  twobit_branch( 1492, compiled_block_2_1492 );
  twobit_label( 1636, compiled_block_2_1636 );
  twobit_branch( 1492, compiled_block_2_1492 );
  twobit_label( 1494, compiled_block_2_1494 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1681, compiled_block_2_1681 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1683, compiled_block_2_1683 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1685, compiled_block_2_1685 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1687, compiled_block_2_1687 ); /* internal:branchf-pair? */
  twobit_save( 9 );
  twobit_store( 0, 0 );
  twobit_store( 1, 9 );
  twobit_store( 2, 2 );
  twobit_store( 3, 7 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 3 );
  twobit_movereg( 31, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1688, compiled_block_2_1688 );
  twobit_invoke( 1 );
  twobit_label( 1688, compiled_block_2_1688 );
  twobit_load( 0, 0 );
  twobit_branchf( 1690, compiled_block_2_1690 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1692, compiled_block_2_1692 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1694, compiled_block_2_1694 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1695, compiled_block_2_1695 );
  twobit_invoke( 2 );
  twobit_label( 1695, compiled_block_2_1695 );
  twobit_load( 0, 0 );
  twobit_branchf( 1697, compiled_block_2_1697 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1699, compiled_block_2_1699 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1700, compiled_block_2_1700 );
  twobit_invoke( 2 );
  twobit_label( 1700, compiled_block_2_1700 );
  twobit_load( 0, 0 );
  twobit_branchf( 1702, compiled_block_2_1702 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1704, compiled_block_2_1704 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1706, compiled_block_2_1706 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 17 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1707, compiled_block_2_1707 );
  twobit_invoke( 5 );
  twobit_label( 1707, compiled_block_2_1707 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 17 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1708, compiled_block_2_1708 );
  twobit_invoke( 5 );
  twobit_label( 1708, compiled_block_2_1708 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 17 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1709, compiled_block_2_1709 );
  twobit_invoke( 5 );
  twobit_label( 1709, compiled_block_2_1709 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 17 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1710, compiled_block_2_1710 );
  twobit_invoke( 5 );
  twobit_label( 1710, compiled_block_2_1710 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 3 );
  twobit_global( 9 ); /* list->vector */
  twobit_setrtn( 1711, compiled_block_2_1711 );
  twobit_invoke( 1 );
  twobit_label( 1711, compiled_block_2_1711 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 17 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1712, compiled_block_2_1712 );
  twobit_invoke( 5 );
  twobit_label( 1712, compiled_block_2_1712 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 17 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1713, compiled_block_2_1713 );
  twobit_invoke( 5 );
  twobit_label( 1713, compiled_block_2_1713 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 17 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1714, compiled_block_2_1714 );
  twobit_invoke( 5 );
  twobit_label( 1714, compiled_block_2_1714 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 9 );
  twobit_return();
  twobit_label( 1706, compiled_block_2_1706 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1493, compiled_block_2_1493 );
  twobit_label( 1704, compiled_block_2_1704 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1493, compiled_block_2_1493 );
  twobit_label( 1702, compiled_block_2_1702 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1493, compiled_block_2_1493 );
  twobit_label( 1699, compiled_block_2_1699 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1493, compiled_block_2_1493 );
  twobit_label( 1697, compiled_block_2_1697 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1493, compiled_block_2_1493 );
  twobit_label( 1694, compiled_block_2_1694 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1493, compiled_block_2_1493 );
  twobit_label( 1692, compiled_block_2_1692 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1493, compiled_block_2_1493 );
  twobit_label( 1690, compiled_block_2_1690 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1493, compiled_block_2_1493 );
  twobit_label( 1687, compiled_block_2_1687 );
  twobit_branch( 1493, compiled_block_2_1493 );
  twobit_label( 1685, compiled_block_2_1685 );
  twobit_branch( 1493, compiled_block_2_1493 );
  twobit_label( 1683, compiled_block_2_1683 );
  twobit_branch( 1493, compiled_block_2_1493 );
  twobit_label( 1681, compiled_block_2_1681 );
  twobit_branch( 1493, compiled_block_2_1493 );
  twobit_label( 1495, compiled_block_2_1495 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1728, compiled_block_2_1728 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1730, compiled_block_2_1730 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1732, compiled_block_2_1732 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1734, compiled_block_2_1734 ); /* internal:branchf-pair? */
  twobit_save( 9 );
  twobit_store( 0, 0 );
  twobit_store( 1, 9 );
  twobit_store( 2, 2 );
  twobit_store( 3, 7 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 3 );
  twobit_movereg( 31, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1735, compiled_block_2_1735 );
  twobit_invoke( 1 );
  twobit_label( 1735, compiled_block_2_1735 );
  twobit_load( 0, 0 );
  twobit_branchf( 1737, compiled_block_2_1737 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1739, compiled_block_2_1739 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1741, compiled_block_2_1741 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1743, compiled_block_2_1743 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1745, compiled_block_2_1745 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1746, compiled_block_2_1746 );
  twobit_invoke( 2 );
  twobit_label( 1746, compiled_block_2_1746 );
  twobit_load( 0, 0 );
  twobit_branchf( 1748, compiled_block_2_1748 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1750, compiled_block_2_1750 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 18 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1751, compiled_block_2_1751 );
  twobit_invoke( 5 );
  twobit_label( 1751, compiled_block_2_1751 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 18 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1752, compiled_block_2_1752 );
  twobit_invoke( 5 );
  twobit_label( 1752, compiled_block_2_1752 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 18 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1753, compiled_block_2_1753 );
  twobit_invoke( 5 );
  twobit_label( 1753, compiled_block_2_1753 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 18 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1754, compiled_block_2_1754 );
  twobit_invoke( 5 );
  twobit_label( 1754, compiled_block_2_1754 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 3 );
  twobit_global( 9 ); /* list->vector */
  twobit_setrtn( 1755, compiled_block_2_1755 );
  twobit_invoke( 1 );
  twobit_label( 1755, compiled_block_2_1755 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 18 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1756, compiled_block_2_1756 );
  twobit_invoke( 5 );
  twobit_label( 1756, compiled_block_2_1756 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 18 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1757, compiled_block_2_1757 );
  twobit_invoke( 5 );
  twobit_label( 1757, compiled_block_2_1757 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 18 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1758, compiled_block_2_1758 );
  twobit_invoke( 5 );
  twobit_label( 1758, compiled_block_2_1758 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 18 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1759, compiled_block_2_1759 );
  twobit_invoke( 5 );
  twobit_label( 1759, compiled_block_2_1759 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 9 );
  twobit_return();
  twobit_label( 1750, compiled_block_2_1750 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1494, compiled_block_2_1494 );
  twobit_label( 1748, compiled_block_2_1748 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1494, compiled_block_2_1494 );
  twobit_label( 1745, compiled_block_2_1745 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1494, compiled_block_2_1494 );
  twobit_label( 1743, compiled_block_2_1743 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1494, compiled_block_2_1494 );
  twobit_label( 1741, compiled_block_2_1741 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1494, compiled_block_2_1494 );
  twobit_label( 1739, compiled_block_2_1739 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1494, compiled_block_2_1494 );
  twobit_label( 1737, compiled_block_2_1737 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1494, compiled_block_2_1494 );
  twobit_label( 1734, compiled_block_2_1734 );
  twobit_branch( 1494, compiled_block_2_1494 );
  twobit_label( 1732, compiled_block_2_1732 );
  twobit_branch( 1494, compiled_block_2_1494 );
  twobit_label( 1730, compiled_block_2_1730 );
  twobit_branch( 1494, compiled_block_2_1494 );
  twobit_label( 1728, compiled_block_2_1728 );
  twobit_branch( 1494, compiled_block_2_1494 );
  twobit_label( 1496, compiled_block_2_1496 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1772, compiled_block_2_1772 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1774, compiled_block_2_1774 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1776, compiled_block_2_1776 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1778, compiled_block_2_1778 ); /* internal:branchf-pair? */
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 8 );
  twobit_store( 2, 2 );
  twobit_store( 3, 6 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 3 );
  twobit_movereg( 31, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1779, compiled_block_2_1779 );
  twobit_invoke( 1 );
  twobit_label( 1779, compiled_block_2_1779 );
  twobit_load( 0, 0 );
  twobit_branchf( 1781, compiled_block_2_1781 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1783, compiled_block_2_1783 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1785, compiled_block_2_1785 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1786, compiled_block_2_1786 );
  twobit_invoke( 2 );
  twobit_label( 1786, compiled_block_2_1786 );
  twobit_load( 0, 0 );
  twobit_branchf( 1788, compiled_block_2_1788 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1790, compiled_block_2_1790 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1792, compiled_block_2_1792 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1793, compiled_block_2_1793 );
  twobit_invoke( 2 );
  twobit_label( 1793, compiled_block_2_1793 );
  twobit_load( 0, 0 );
  twobit_branchf( 1795, compiled_block_2_1795 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1797, compiled_block_2_1797 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 19 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1798, compiled_block_2_1798 );
  twobit_invoke( 5 );
  twobit_label( 1798, compiled_block_2_1798 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 19 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1799, compiled_block_2_1799 );
  twobit_invoke( 5 );
  twobit_label( 1799, compiled_block_2_1799 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 19 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1800, compiled_block_2_1800 );
  twobit_invoke( 5 );
  twobit_label( 1800, compiled_block_2_1800 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 19 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1801, compiled_block_2_1801 );
  twobit_invoke( 5 );
  twobit_label( 1801, compiled_block_2_1801 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 3 );
  twobit_global( 9 ); /* list->vector */
  twobit_setrtn( 1802, compiled_block_2_1802 );
  twobit_invoke( 1 );
  twobit_label( 1802, compiled_block_2_1802 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 19 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1803, compiled_block_2_1803 );
  twobit_invoke( 5 );
  twobit_label( 1803, compiled_block_2_1803 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 19 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1804, compiled_block_2_1804 );
  twobit_invoke( 5 );
  twobit_label( 1804, compiled_block_2_1804 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 1797, compiled_block_2_1797 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1495, compiled_block_2_1495 );
  twobit_label( 1795, compiled_block_2_1795 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1495, compiled_block_2_1495 );
  twobit_label( 1792, compiled_block_2_1792 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1495, compiled_block_2_1495 );
  twobit_label( 1790, compiled_block_2_1790 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1495, compiled_block_2_1495 );
  twobit_label( 1788, compiled_block_2_1788 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1495, compiled_block_2_1495 );
  twobit_label( 1785, compiled_block_2_1785 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1495, compiled_block_2_1495 );
  twobit_label( 1783, compiled_block_2_1783 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1495, compiled_block_2_1495 );
  twobit_label( 1781, compiled_block_2_1781 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1495, compiled_block_2_1495 );
  twobit_label( 1778, compiled_block_2_1778 );
  twobit_branch( 1495, compiled_block_2_1495 );
  twobit_label( 1776, compiled_block_2_1776 );
  twobit_branch( 1495, compiled_block_2_1495 );
  twobit_label( 1774, compiled_block_2_1774 );
  twobit_branch( 1495, compiled_block_2_1495 );
  twobit_label( 1772, compiled_block_2_1772 );
  twobit_branch( 1495, compiled_block_2_1495 );
  twobit_label( 1497, compiled_block_2_1497 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1818, compiled_block_2_1818 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1820, compiled_block_2_1820 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1822, compiled_block_2_1822 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1824, compiled_block_2_1824 ); /* internal:branchf-pair? */
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 8 );
  twobit_store( 2, 2 );
  twobit_store( 3, 6 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 3 );
  twobit_movereg( 31, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1825, compiled_block_2_1825 );
  twobit_invoke( 1 );
  twobit_label( 1825, compiled_block_2_1825 );
  twobit_load( 0, 0 );
  twobit_branchf( 1827, compiled_block_2_1827 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1829, compiled_block_2_1829 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1831, compiled_block_2_1831 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1833, compiled_block_2_1833 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1834, compiled_block_2_1834 );
  twobit_invoke( 2 );
  twobit_label( 1834, compiled_block_2_1834 );
  twobit_load( 0, 0 );
  twobit_branchf( 1836, compiled_block_2_1836 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1838, compiled_block_2_1838 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1839, compiled_block_2_1839 );
  twobit_invoke( 2 );
  twobit_label( 1839, compiled_block_2_1839 );
  twobit_load( 0, 0 );
  twobit_branchf( 1841, compiled_block_2_1841 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1843, compiled_block_2_1843 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 20 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1844, compiled_block_2_1844 );
  twobit_invoke( 5 );
  twobit_label( 1844, compiled_block_2_1844 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 20 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1845, compiled_block_2_1845 );
  twobit_invoke( 5 );
  twobit_label( 1845, compiled_block_2_1845 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 20 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1846, compiled_block_2_1846 );
  twobit_invoke( 5 );
  twobit_label( 1846, compiled_block_2_1846 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 20 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1847, compiled_block_2_1847 );
  twobit_invoke( 5 );
  twobit_label( 1847, compiled_block_2_1847 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 3 );
  twobit_global( 9 ); /* list->vector */
  twobit_setrtn( 1848, compiled_block_2_1848 );
  twobit_invoke( 1 );
  twobit_label( 1848, compiled_block_2_1848 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 20 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1849, compiled_block_2_1849 );
  twobit_invoke( 5 );
  twobit_label( 1849, compiled_block_2_1849 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 20 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 5 );
  twobit_global( 6 ); /* ex:syntax-rename */
  twobit_setrtn( 1850, compiled_block_2_1850 );
  twobit_invoke( 5 );
  twobit_label( 1850, compiled_block_2_1850 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 1843, compiled_block_2_1843 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1496, compiled_block_2_1496 );
  twobit_label( 1841, compiled_block_2_1841 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1496, compiled_block_2_1496 );
  twobit_label( 1838, compiled_block_2_1838 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1496, compiled_block_2_1496 );
  twobit_label( 1836, compiled_block_2_1836 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1496, compiled_block_2_1496 );
  twobit_label( 1833, compiled_block_2_1833 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1496, compiled_block_2_1496 );
  twobit_label( 1831, compiled_block_2_1831 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1496, compiled_block_2_1496 );
  twobit_label( 1829, compiled_block_2_1829 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1496, compiled_block_2_1496 );
  twobit_label( 1827, compiled_block_2_1827 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1496, compiled_block_2_1496 );
  twobit_label( 1824, compiled_block_2_1824 );
  twobit_branch( 1496, compiled_block_2_1496 );
  twobit_label( 1822, compiled_block_2_1822 );
  twobit_branch( 1496, compiled_block_2_1496 );
  twobit_label( 1820, compiled_block_2_1820 );
  twobit_branch( 1496, compiled_block_2_1496 );
  twobit_label( 1818, compiled_block_2_1818 );
  twobit_branch( 1496, compiled_block_2_1496 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_10( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1870, compiled_block_2_1870 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1872, compiled_block_2_1872 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1874, compiled_block_2_1874 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1876, compiled_block_2_1876 ); /* internal:branchf-pair? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 3, 2 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* equal? */
  twobit_setrtn( 1877, compiled_block_2_1877 );
  twobit_invoke( 2 );
  twobit_label( 1877, compiled_block_2_1877 );
  twobit_load( 0, 0 );
  twobit_branchf( 1879, compiled_block_2_1879 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1881, compiled_block_2_1881 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* equal? */
  twobit_setrtn( 1882, compiled_block_2_1882 );
  twobit_invoke( 2 );
  twobit_label( 1882, compiled_block_2_1882 );
  twobit_load( 0, 0 );
  twobit_branchf( 1884, compiled_block_2_1884 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1886, compiled_block_2_1886 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* equal? */
  twobit_setrtn( 1887, compiled_block_2_1887 );
  twobit_invoke( 2 );
  twobit_label( 1887, compiled_block_2_1887 );
  twobit_load( 0, 0 );
  twobit_branchf( 1889, compiled_block_2_1889 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1891, compiled_block_2_1891 ); /* internal:branchf-null? */
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1892, compiled_block_2_1892 );
  twobit_invoke( 5 );
  twobit_label( 1892, compiled_block_2_1892 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1893, compiled_block_2_1893 );
  twobit_invoke( 5 );
  twobit_label( 1893, compiled_block_2_1893 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1894, compiled_block_2_1894 );
  twobit_invoke( 5 );
  twobit_label( 1894, compiled_block_2_1894 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1895, compiled_block_2_1895 );
  twobit_invoke( 5 );
  twobit_label( 1895, compiled_block_2_1895 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1891, compiled_block_2_1891 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1867, compiled_block_2_1867 );
  twobit_label( 1889, compiled_block_2_1889 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1867, compiled_block_2_1867 );
  twobit_label( 1886, compiled_block_2_1886 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1867, compiled_block_2_1867 );
  twobit_label( 1884, compiled_block_2_1884 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1867, compiled_block_2_1867 );
  twobit_label( 1881, compiled_block_2_1881 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1867, compiled_block_2_1867 );
  twobit_label( 1879, compiled_block_2_1879 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1867, compiled_block_2_1867 );
  twobit_label( 1876, compiled_block_2_1876 );
  twobit_branch( 1867, compiled_block_2_1867 );
  twobit_label( 1874, compiled_block_2_1874 );
  twobit_branch( 1867, compiled_block_2_1867 );
  twobit_label( 1872, compiled_block_2_1872 );
  twobit_branch( 1867, compiled_block_2_1867 );
  twobit_label( 1870, compiled_block_2_1870 );
  twobit_branch( 1867, compiled_block_2_1867 );
  twobit_label( 1864, compiled_block_2_1864 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1907, compiled_block_2_1907 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1909, compiled_block_2_1909 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1911, compiled_block_2_1911 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1913, compiled_block_2_1913 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1915, compiled_block_2_1915 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1917, compiled_block_2_1917 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1919, compiled_block_2_1919 ); /* internal:branchf-null? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_store( 31, 1 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1920, compiled_block_2_1920 );
  twobit_invoke( 5 );
  twobit_label( 1920, compiled_block_2_1920 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1921, compiled_block_2_1921 );
  twobit_invoke( 5 );
  twobit_label( 1921, compiled_block_2_1921 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1922, compiled_block_2_1922 );
  twobit_invoke( 5 );
  twobit_label( 1922, compiled_block_2_1922 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1923, compiled_block_2_1923 );
  twobit_invoke( 5 );
  twobit_label( 1923, compiled_block_2_1923 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1919, compiled_block_2_1919 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1917, compiled_block_2_1917 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1915, compiled_block_2_1915 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1913, compiled_block_2_1913 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1911, compiled_block_2_1911 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1909, compiled_block_2_1909 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1907, compiled_block_2_1907 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1865, compiled_block_2_1865 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1932, compiled_block_2_1932 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1934, compiled_block_2_1934 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1936, compiled_block_2_1936 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1938, compiled_block_2_1938 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1940, compiled_block_2_1940 ); /* internal:branchf-pair? */
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 8 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* equal? */
  twobit_setrtn( 1941, compiled_block_2_1941 );
  twobit_invoke( 2 );
  twobit_label( 1941, compiled_block_2_1941 );
  twobit_load( 0, 0 );
  twobit_branchf( 1943, compiled_block_2_1943 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1945, compiled_block_2_1945 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1947, compiled_block_2_1947 ); /* internal:branchf-null? */
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1948, compiled_block_2_1948 );
  twobit_invoke( 5 );
  twobit_label( 1948, compiled_block_2_1948 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1949, compiled_block_2_1949 );
  twobit_invoke( 5 );
  twobit_label( 1949, compiled_block_2_1949 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1950, compiled_block_2_1950 );
  twobit_invoke( 5 );
  twobit_label( 1950, compiled_block_2_1950 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1951, compiled_block_2_1951 );
  twobit_invoke( 5 );
  twobit_label( 1951, compiled_block_2_1951 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 2 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1952, compiled_block_2_1952 );
  twobit_invoke( 5 );
  twobit_label( 1952, compiled_block_2_1952 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 1947, compiled_block_2_1947 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1864, compiled_block_2_1864 );
  twobit_label( 1945, compiled_block_2_1945 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1864, compiled_block_2_1864 );
  twobit_label( 1943, compiled_block_2_1943 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1864, compiled_block_2_1864 );
  twobit_label( 1940, compiled_block_2_1940 );
  twobit_branch( 1864, compiled_block_2_1864 );
  twobit_label( 1938, compiled_block_2_1938 );
  twobit_branch( 1864, compiled_block_2_1864 );
  twobit_label( 1936, compiled_block_2_1936 );
  twobit_branch( 1864, compiled_block_2_1864 );
  twobit_label( 1934, compiled_block_2_1934 );
  twobit_branch( 1864, compiled_block_2_1864 );
  twobit_label( 1932, compiled_block_2_1932 );
  twobit_branch( 1864, compiled_block_2_1864 );
  twobit_label( 1866, compiled_block_2_1866 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1962, compiled_block_2_1962 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1964, compiled_block_2_1964 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1966, compiled_block_2_1966 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1968, compiled_block_2_1968 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1970, compiled_block_2_1970 ); /* internal:branchf-pair? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 3, 2 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* equal? */
  twobit_setrtn( 1971, compiled_block_2_1971 );
  twobit_invoke( 2 );
  twobit_label( 1971, compiled_block_2_1971 );
  twobit_load( 0, 0 );
  twobit_branchf( 1973, compiled_block_2_1973 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1975, compiled_block_2_1975 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* equal? */
  twobit_setrtn( 1976, compiled_block_2_1976 );
  twobit_invoke( 2 );
  twobit_label( 1976, compiled_block_2_1976 );
  twobit_load( 0, 0 );
  twobit_branchf( 1978, compiled_block_2_1978 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1980, compiled_block_2_1980 ); /* internal:branchf-null? */
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 13 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1981, compiled_block_2_1981 );
  twobit_invoke( 5 );
  twobit_label( 1981, compiled_block_2_1981 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 13 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1982, compiled_block_2_1982 );
  twobit_invoke( 5 );
  twobit_label( 1982, compiled_block_2_1982 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 13 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1983, compiled_block_2_1983 );
  twobit_invoke( 5 );
  twobit_label( 1983, compiled_block_2_1983 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 13 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1984, compiled_block_2_1984 );
  twobit_invoke( 5 );
  twobit_label( 1984, compiled_block_2_1984 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1980, compiled_block_2_1980 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1865, compiled_block_2_1865 );
  twobit_label( 1978, compiled_block_2_1978 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1865, compiled_block_2_1865 );
  twobit_label( 1975, compiled_block_2_1975 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1865, compiled_block_2_1865 );
  twobit_label( 1973, compiled_block_2_1973 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1865, compiled_block_2_1865 );
  twobit_label( 1970, compiled_block_2_1970 );
  twobit_branch( 1865, compiled_block_2_1865 );
  twobit_label( 1968, compiled_block_2_1968 );
  twobit_branch( 1865, compiled_block_2_1865 );
  twobit_label( 1966, compiled_block_2_1966 );
  twobit_branch( 1865, compiled_block_2_1865 );
  twobit_label( 1964, compiled_block_2_1964 );
  twobit_branch( 1865, compiled_block_2_1865 );
  twobit_label( 1962, compiled_block_2_1962 );
  twobit_branch( 1865, compiled_block_2_1865 );
  twobit_label( 1867, compiled_block_2_1867 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1995, compiled_block_2_1995 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1997, compiled_block_2_1997 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1999, compiled_block_2_1999 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2001, compiled_block_2_2001 ); /* internal:branchf-pair? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 6 );
  twobit_store( 3, 2 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* equal? */
  twobit_setrtn( 2002, compiled_block_2_2002 );
  twobit_invoke( 2 );
  twobit_label( 2002, compiled_block_2_2002 );
  twobit_load( 0, 0 );
  twobit_branchf( 2004, compiled_block_2_2004 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2006, compiled_block_2_2006 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* equal? */
  twobit_setrtn( 2007, compiled_block_2_2007 );
  twobit_invoke( 2 );
  twobit_label( 2007, compiled_block_2_2007 );
  twobit_load( 0, 0 );
  twobit_branchf( 2009, compiled_block_2_2009 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2011, compiled_block_2_2011 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2013, compiled_block_2_2013 ); /* internal:branchf-null? */
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 2014, compiled_block_2_2014 );
  twobit_invoke( 5 );
  twobit_label( 2014, compiled_block_2_2014 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 2015, compiled_block_2_2015 );
  twobit_invoke( 5 );
  twobit_label( 2015, compiled_block_2_2015 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 2016, compiled_block_2_2016 );
  twobit_invoke( 5 );
  twobit_label( 2016, compiled_block_2_2016 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 2017, compiled_block_2_2017 );
  twobit_invoke( 5 );
  twobit_label( 2017, compiled_block_2_2017 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 2013, compiled_block_2_2013 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1866, compiled_block_2_1866 );
  twobit_label( 2011, compiled_block_2_2011 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1866, compiled_block_2_1866 );
  twobit_label( 2009, compiled_block_2_2009 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1866, compiled_block_2_1866 );
  twobit_label( 2006, compiled_block_2_2006 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1866, compiled_block_2_1866 );
  twobit_label( 2004, compiled_block_2_2004 );
  twobit_load( 1, 6 );
  twobit_pop( 6 );
  twobit_branch( 1866, compiled_block_2_1866 );
  twobit_label( 2001, compiled_block_2_2001 );
  twobit_branch( 1866, compiled_block_2_1866 );
  twobit_label( 1999, compiled_block_2_1999 );
  twobit_branch( 1866, compiled_block_2_1866 );
  twobit_label( 1997, compiled_block_2_1997 );
  twobit_branch( 1866, compiled_block_2_1866 );
  twobit_label( 1995, compiled_block_2_1995 );
  twobit_branch( 1866, compiled_block_2_1866 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_11( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2031, compiled_block_2_2031 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2033, compiled_block_2_2033 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2035, compiled_block_2_2035 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* equal? */
  twobit_setrtn( 2036, compiled_block_2_2036 );
  twobit_invoke( 2 );
  twobit_label( 2036, compiled_block_2_2036 );
  twobit_load( 0, 0 );
  twobit_branchf( 2038, compiled_block_2_2038 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2040, compiled_block_2_2040 ); /* internal:branchf-null? */
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 2041, compiled_block_2_2041 );
  twobit_invoke( 5 );
  twobit_label( 2041, compiled_block_2_2041 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2040, compiled_block_2_2040 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 2028, compiled_block_2_2028 );
  twobit_label( 2038, compiled_block_2_2038 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 2028, compiled_block_2_2028 );
  twobit_label( 2035, compiled_block_2_2035 );
  twobit_branch( 2028, compiled_block_2_2028 );
  twobit_label( 2033, compiled_block_2_2033 );
  twobit_branch( 2028, compiled_block_2_2028 );
  twobit_label( 2031, compiled_block_2_2031 );
  twobit_label( 2028, compiled_block_2_2028 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2048, compiled_block_2_2048 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2050, compiled_block_2_2050 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2052, compiled_block_2_2052 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2054, compiled_block_2_2054 ); /* internal:branchf-null? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 2, 3 );
  twobit_store( 3, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 2055, compiled_block_2_2055 );
  twobit_invoke( 5 );
  twobit_label( 2055, compiled_block_2_2055 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 2056, compiled_block_2_2056 );
  twobit_invoke( 5 );
  twobit_label( 2056, compiled_block_2_2056 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 2057, compiled_block_2_2057 );
  twobit_invoke( 5 );
  twobit_label( 2057, compiled_block_2_2057 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2054, compiled_block_2_2054 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2052, compiled_block_2_2052 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2050, compiled_block_2_2050 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2048, compiled_block_2_2048 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_12( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2066, compiled_block_2_2066 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2068, compiled_block_2_2068 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2070, compiled_block_2_2070 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* equal? */
  twobit_setrtn( 2071, compiled_block_2_2071 );
  twobit_invoke( 2 );
  twobit_label( 2071, compiled_block_2_2071 );
  twobit_load( 0, 0 );
  twobit_branchf( 2073, compiled_block_2_2073 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2075, compiled_block_2_2075 ); /* internal:branchf-null? */
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 2076, compiled_block_2_2076 );
  twobit_invoke( 5 );
  twobit_label( 2076, compiled_block_2_2076 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2075, compiled_block_2_2075 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 2063, compiled_block_2_2063 );
  twobit_label( 2073, compiled_block_2_2073 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 2063, compiled_block_2_2063 );
  twobit_label( 2070, compiled_block_2_2070 );
  twobit_branch( 2063, compiled_block_2_2063 );
  twobit_label( 2068, compiled_block_2_2068 );
  twobit_branch( 2063, compiled_block_2_2063 );
  twobit_label( 2066, compiled_block_2_2066 );
  twobit_label( 2063, compiled_block_2_2063 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2083, compiled_block_2_2083 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2085, compiled_block_2_2085 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2087, compiled_block_2_2087 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2089, compiled_block_2_2089 ); /* internal:branchf-null? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 3, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 2090, compiled_block_2_2090 );
  twobit_invoke( 5 );
  twobit_label( 2090, compiled_block_2_2090 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 2091, compiled_block_2_2091 );
  twobit_invoke( 5 );
  twobit_label( 2091, compiled_block_2_2091 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 2089, compiled_block_2_2089 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2087, compiled_block_2_2087 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2085, compiled_block_2_2085 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2083, compiled_block_2_2083 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_13( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2100, compiled_block_2_2100 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2102, compiled_block_2_2102 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2104, compiled_block_2_2104 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2106, compiled_block_2_2106 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* equal? */
  twobit_setrtn( 2107, compiled_block_2_2107 );
  twobit_invoke( 2 );
  twobit_label( 2107, compiled_block_2_2107 );
  twobit_load( 0, 0 );
  twobit_branchf( 2109, compiled_block_2_2109 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2111, compiled_block_2_2111 ); /* internal:branchf-null? */
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 2112, compiled_block_2_2112 );
  twobit_invoke( 5 );
  twobit_label( 2112, compiled_block_2_2112 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2111, compiled_block_2_2111 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 2097, compiled_block_2_2097 );
  twobit_label( 2109, compiled_block_2_2109 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 2097, compiled_block_2_2097 );
  twobit_label( 2106, compiled_block_2_2106 );
  twobit_branch( 2097, compiled_block_2_2097 );
  twobit_label( 2104, compiled_block_2_2104 );
  twobit_branch( 2097, compiled_block_2_2097 );
  twobit_label( 2102, compiled_block_2_2102 );
  twobit_branch( 2097, compiled_block_2_2097 );
  twobit_label( 2100, compiled_block_2_2100 );
  twobit_label( 2097, compiled_block_2_2097 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2120, compiled_block_2_2120 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2122, compiled_block_2_2122 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2124, compiled_block_2_2124 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2126, compiled_block_2_2126 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2128, compiled_block_2_2128 ); /* internal:branchf-null? */
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_store( 31, 4 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 2129, compiled_block_2_2129 );
  twobit_invoke( 5 );
  twobit_label( 2129, compiled_block_2_2129 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 2130, compiled_block_2_2130 );
  twobit_invoke( 5 );
  twobit_label( 2130, compiled_block_2_2130 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 2131, compiled_block_2_2131 );
  twobit_invoke( 5 );
  twobit_label( 2131, compiled_block_2_2131 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 2128, compiled_block_2_2128 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2126, compiled_block_2_2126 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2124, compiled_block_2_2124 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2122, compiled_block_2_2122 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2120, compiled_block_2_2120 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_14( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2141, compiled_block_2_2141 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2143, compiled_block_2_2143 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2145, compiled_block_2_2145 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2147, compiled_block_2_2147 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* equal? */
  twobit_setrtn( 2148, compiled_block_2_2148 );
  twobit_invoke( 2 );
  twobit_label( 2148, compiled_block_2_2148 );
  twobit_load( 0, 0 );
  twobit_branchf( 2150, compiled_block_2_2150 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2152, compiled_block_2_2152 ); /* internal:branchf-null? */
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 2153, compiled_block_2_2153 );
  twobit_invoke( 5 );
  twobit_label( 2153, compiled_block_2_2153 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2152, compiled_block_2_2152 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 2138, compiled_block_2_2138 );
  twobit_label( 2150, compiled_block_2_2150 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 2138, compiled_block_2_2138 );
  twobit_label( 2147, compiled_block_2_2147 );
  twobit_branch( 2138, compiled_block_2_2138 );
  twobit_label( 2145, compiled_block_2_2145 );
  twobit_branch( 2138, compiled_block_2_2138 );
  twobit_label( 2143, compiled_block_2_2143 );
  twobit_branch( 2138, compiled_block_2_2138 );
  twobit_label( 2141, compiled_block_2_2141 );
  twobit_label( 2138, compiled_block_2_2138 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2161, compiled_block_2_2161 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2163, compiled_block_2_2163 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2165, compiled_block_2_2165 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2167, compiled_block_2_2167 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2169, compiled_block_2_2169 ); /* internal:branchf-null? */
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_store( 31, 4 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 2170, compiled_block_2_2170 );
  twobit_invoke( 5 );
  twobit_label( 2170, compiled_block_2_2170 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 2171, compiled_block_2_2171 );
  twobit_invoke( 5 );
  twobit_label( 2171, compiled_block_2_2171 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 2172, compiled_block_2_2172 );
  twobit_invoke( 5 );
  twobit_label( 2172, compiled_block_2_2172 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 2169, compiled_block_2_2169 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2167, compiled_block_2_2167 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2165, compiled_block_2_2165 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2163, compiled_block_2_2163 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2161, compiled_block_2_2161 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 2 ); /*  record-constructor-descriptor~1ay%kV~3305 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 3 ); /*  record-type-descriptor~1ay%kV~3304 */
  twobit_lambda( compiled_start_2_4, 5, 0 );
  twobit_setglbl( 3 ); /*  record-type-descriptor~1ay%kV~3304 */
  twobit_lambda( compiled_start_2_5, 7, 0 );
  twobit_setglbl( 2 ); /*  record-constructor-descriptor~1ay%kV~3305 */
  twobit_global( 8 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_global( 1 ); /*  preferred-cd~1ay%kV~2072 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


RTYPE twobit_thunk_f93ad414f351d7d55a245a62a67f70db_1(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_2_0(CONT_ACTUALS));
}
codeptr_t CDECL twobit_load_table[] = { 
  twobit_thunk_f93ad414f351d7d55a245a62a67f70db_0,
  twobit_thunk_f93ad414f351d7d55a245a62a67f70db_1,
  0  /* The table may be empty; some compilers complain */
};

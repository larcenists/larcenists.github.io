/* Generated from /home/henchman/larcenytest/larceny-petit-Nightly-2009-08-19/larceny_src/lib/SRFI/srfi/%3a5.slfasl */
#include "petit-instr.h"

static RTYPE compiled_block_1_1332( CONT_PARAMS );
static RTYPE compiled_block_1_1331( CONT_PARAMS );
static RTYPE compiled_start_1_0( CONT_PARAMS );
static RTYPE compiled_start_1_3( CONT_PARAMS );
static RTYPE compiled_block_1_1328( CONT_PARAMS );
static RTYPE compiled_block_1_1143( CONT_PARAMS );
static RTYPE compiled_block_1_1027( CONT_PARAMS );
static RTYPE compiled_start_1_2( CONT_PARAMS );
static RTYPE compiled_block_1_1243( CONT_PARAMS );
static RTYPE compiled_block_1_1242( CONT_PARAMS );
static RTYPE compiled_block_1_1280( CONT_PARAMS );
static RTYPE compiled_block_1_1282( CONT_PARAMS );
static RTYPE compiled_block_1_1285( CONT_PARAMS );
static RTYPE compiled_block_1_1287( CONT_PARAMS );
static RTYPE compiled_block_1_1289( CONT_PARAMS );
static RTYPE compiled_block_1_1292( CONT_PARAMS );
static RTYPE compiled_block_1_1294( CONT_PARAMS );
static RTYPE compiled_block_1_1297( CONT_PARAMS );
static RTYPE compiled_block_1_1299( CONT_PARAMS );
static RTYPE compiled_block_1_1302( CONT_PARAMS );
static RTYPE compiled_block_1_1304( CONT_PARAMS );
static RTYPE compiled_block_1_1306( CONT_PARAMS );
static RTYPE compiled_block_1_1315( CONT_PARAMS );
static RTYPE compiled_block_1_1314( CONT_PARAMS );
static RTYPE compiled_block_1_1310( CONT_PARAMS );
static RTYPE compiled_block_1_1313( CONT_PARAMS );
static RTYPE compiled_block_1_1311( CONT_PARAMS );
static RTYPE compiled_block_1_1312( CONT_PARAMS );
static RTYPE compiled_temp_1_7( CONT_PARAMS );
static RTYPE compiled_block_1_1309( CONT_PARAMS );
static RTYPE compiled_block_1_1308( CONT_PARAMS );
static RTYPE compiled_block_1_1307( CONT_PARAMS );
static RTYPE compiled_block_1_1300( CONT_PARAMS );
static RTYPE compiled_block_1_1295( CONT_PARAMS );
static RTYPE compiled_block_1_1290( CONT_PARAMS );
static RTYPE compiled_block_1_1283( CONT_PARAMS );
static RTYPE compiled_block_1_1147( CONT_PARAMS );
static RTYPE compiled_block_1_1246( CONT_PARAMS );
static RTYPE compiled_block_1_1248( CONT_PARAMS );
static RTYPE compiled_block_1_1250( CONT_PARAMS );
static RTYPE compiled_block_1_1252( CONT_PARAMS );
static RTYPE compiled_block_1_1254( CONT_PARAMS );
static RTYPE compiled_block_1_1257( CONT_PARAMS );
static RTYPE compiled_block_1_1259( CONT_PARAMS );
static RTYPE compiled_block_1_1262( CONT_PARAMS );
static RTYPE compiled_block_1_1264( CONT_PARAMS );
static RTYPE compiled_block_1_1266( CONT_PARAMS );
static RTYPE compiled_block_1_1268( CONT_PARAMS );
static RTYPE compiled_block_1_1267( CONT_PARAMS );
static RTYPE compiled_block_1_1260( CONT_PARAMS );
static RTYPE compiled_block_1_1255( CONT_PARAMS );
static RTYPE compiled_block_1_1146( CONT_PARAMS );
static RTYPE compiled_block_1_1240( CONT_PARAMS );
static RTYPE compiled_block_1_1237( CONT_PARAMS );
static RTYPE compiled_block_1_1238( CONT_PARAMS );
static RTYPE compiled_block_1_1145( CONT_PARAMS );
static RTYPE compiled_block_1_1198( CONT_PARAMS );
static RTYPE compiled_block_1_1200( CONT_PARAMS );
static RTYPE compiled_block_1_1202( CONT_PARAMS );
static RTYPE compiled_block_1_1204( CONT_PARAMS );
static RTYPE compiled_block_1_1207( CONT_PARAMS );
static RTYPE compiled_block_1_1209( CONT_PARAMS );
static RTYPE compiled_block_1_1212( CONT_PARAMS );
static RTYPE compiled_block_1_1214( CONT_PARAMS );
static RTYPE compiled_block_1_1217( CONT_PARAMS );
static RTYPE compiled_block_1_1219( CONT_PARAMS );
static RTYPE compiled_block_1_1221( CONT_PARAMS );
static RTYPE compiled_block_1_1225( CONT_PARAMS );
static RTYPE compiled_block_1_1224( CONT_PARAMS );
static RTYPE compiled_block_1_1223( CONT_PARAMS );
static RTYPE compiled_block_1_1222( CONT_PARAMS );
static RTYPE compiled_block_1_1215( CONT_PARAMS );
static RTYPE compiled_block_1_1210( CONT_PARAMS );
static RTYPE compiled_block_1_1205( CONT_PARAMS );
static RTYPE compiled_block_1_1144( CONT_PARAMS );
static RTYPE compiled_block_1_1150( CONT_PARAMS );
static RTYPE compiled_block_1_1152( CONT_PARAMS );
static RTYPE compiled_block_1_1154( CONT_PARAMS );
static RTYPE compiled_block_1_1156( CONT_PARAMS );
static RTYPE compiled_block_1_1158( CONT_PARAMS );
static RTYPE compiled_block_1_1160( CONT_PARAMS );
static RTYPE compiled_block_1_1162( CONT_PARAMS );
static RTYPE compiled_block_1_1165( CONT_PARAMS );
static RTYPE compiled_block_1_1167( CONT_PARAMS );
static RTYPE compiled_block_1_1170( CONT_PARAMS );
static RTYPE compiled_block_1_1172( CONT_PARAMS );
static RTYPE compiled_block_1_1175( CONT_PARAMS );
static RTYPE compiled_block_1_1177( CONT_PARAMS );
static RTYPE compiled_block_1_1179( CONT_PARAMS );
static RTYPE compiled_block_1_1182( CONT_PARAMS );
static RTYPE compiled_block_1_1181( CONT_PARAMS );
static RTYPE compiled_block_1_1180( CONT_PARAMS );
static RTYPE compiled_block_1_1173( CONT_PARAMS );
static RTYPE compiled_block_1_1168( CONT_PARAMS );
static RTYPE compiled_block_1_1163( CONT_PARAMS );
static RTYPE compiled_start_1_6( CONT_PARAMS );
static RTYPE compiled_block_1_1103( CONT_PARAMS );
static RTYPE compiled_block_1_1105( CONT_PARAMS );
static RTYPE compiled_block_1_1031( CONT_PARAMS );
static RTYPE compiled_block_1_1080( CONT_PARAMS );
static RTYPE compiled_block_1_1082( CONT_PARAMS );
static RTYPE compiled_block_1_1084( CONT_PARAMS );
static RTYPE compiled_block_1_1086( CONT_PARAMS );
static RTYPE compiled_block_1_1088( CONT_PARAMS );
static RTYPE compiled_block_1_1090( CONT_PARAMS );
static RTYPE compiled_block_1_1093( CONT_PARAMS );
static RTYPE compiled_block_1_1094( CONT_PARAMS );
static RTYPE compiled_block_1_1091( CONT_PARAMS );
static RTYPE compiled_block_1_1030( CONT_PARAMS );
static RTYPE compiled_block_1_1062( CONT_PARAMS );
static RTYPE compiled_block_1_1064( CONT_PARAMS );
static RTYPE compiled_block_1_1066( CONT_PARAMS );
static RTYPE compiled_block_1_1069( CONT_PARAMS );
static RTYPE compiled_block_1_1072( CONT_PARAMS );
static RTYPE compiled_block_1_1073( CONT_PARAMS );
static RTYPE compiled_block_1_1070( CONT_PARAMS );
static RTYPE compiled_block_1_1067( CONT_PARAMS );
static RTYPE compiled_block_1_1029( CONT_PARAMS );
static RTYPE compiled_block_1_1048( CONT_PARAMS );
static RTYPE compiled_block_1_1050( CONT_PARAMS );
static RTYPE compiled_block_1_1052( CONT_PARAMS );
static RTYPE compiled_block_1_1055( CONT_PARAMS );
static RTYPE compiled_block_1_1056( CONT_PARAMS );
static RTYPE compiled_block_1_1053( CONT_PARAMS );
static RTYPE compiled_block_1_1028( CONT_PARAMS );
static RTYPE compiled_block_1_1034( CONT_PARAMS );
static RTYPE compiled_block_1_1036( CONT_PARAMS );
static RTYPE compiled_block_1_1038( CONT_PARAMS );
static RTYPE compiled_block_1_1041( CONT_PARAMS );
static RTYPE compiled_block_1_1042( CONT_PARAMS );
static RTYPE compiled_block_1_1039( CONT_PARAMS );
static RTYPE compiled_start_1_5( CONT_PARAMS );
static RTYPE compiled_block_1_1135( CONT_PARAMS );
static RTYPE compiled_block_1_1137( CONT_PARAMS );
static RTYPE compiled_block_1_1139( CONT_PARAMS );
static RTYPE compiled_start_1_9( CONT_PARAMS );
static RTYPE compiled_block_1_1107( CONT_PARAMS );
static RTYPE compiled_block_1_1129( CONT_PARAMS );
static RTYPE compiled_block_1_1131( CONT_PARAMS );
static RTYPE compiled_block_1_1130( CONT_PARAMS );
static RTYPE compiled_start_1_8( CONT_PARAMS );
static RTYPE compiled_block_1_1127( CONT_PARAMS );
static RTYPE compiled_block_1_1126( CONT_PARAMS );
static RTYPE compiled_block_1_1124( CONT_PARAMS );
static RTYPE compiled_block_1_1121( CONT_PARAMS );
static RTYPE compiled_block_1_1122( CONT_PARAMS );
static RTYPE compiled_block_1_1108( CONT_PARAMS );
static RTYPE compiled_block_1_1112( CONT_PARAMS );
static RTYPE compiled_block_1_1116( CONT_PARAMS );
static RTYPE compiled_block_1_1119( CONT_PARAMS );
static RTYPE compiled_block_1_1117( CONT_PARAMS );
static RTYPE compiled_block_1_1118( CONT_PARAMS );
static RTYPE compiled_temp_1_11( CONT_PARAMS );
static RTYPE compiled_block_1_1115( CONT_PARAMS );
static RTYPE compiled_block_1_1114( CONT_PARAMS );
static RTYPE compiled_block_1_1113( CONT_PARAMS );
static RTYPE compiled_block_1_1110( CONT_PARAMS );
static RTYPE compiled_start_1_10( CONT_PARAMS );
static RTYPE compiled_block_1_1003( CONT_PARAMS );
static RTYPE compiled_block_1_1005( CONT_PARAMS );
static RTYPE compiled_start_1_4( CONT_PARAMS );
static RTYPE compiled_block_1_1013( CONT_PARAMS );
static RTYPE compiled_block_1_1019( CONT_PARAMS );
static RTYPE compiled_block_1_1021( CONT_PARAMS );
static RTYPE compiled_block_1_1020( CONT_PARAMS );
static RTYPE compiled_start_1_13( CONT_PARAMS );
static RTYPE compiled_block_1_1016( CONT_PARAMS );
static RTYPE compiled_block_1_1017( CONT_PARAMS );
static RTYPE compiled_block_1_1014( CONT_PARAMS );
static RTYPE compiled_start_1_14( CONT_PARAMS );
static RTYPE compiled_block_1_1007( CONT_PARAMS );
static RTYPE compiled_block_1_1009( CONT_PARAMS );
static RTYPE compiled_block_1_1011( CONT_PARAMS );
static RTYPE compiled_start_1_12( CONT_PARAMS );
static RTYPE compiled_start_1_1( CONT_PARAMS );

static RTYPE compiled_start_1_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1331, compiled_block_1_1331 );
  twobit_invoke( 8 );
  twobit_label( 1331, compiled_block_1_1331 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1332, compiled_block_1_1332 );
  twobit_invoke( 1 );
  twobit_label( 1332, compiled_block_1_1332 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* ex:uncompress */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_4, 2, 0 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1027, compiled_block_1_1027 );
  twobit_invoke( 2 );
  twobit_label( 1027, compiled_block_1_1027 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_5, 6, 0 );
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1143, compiled_block_1_1143 );
  twobit_invoke( 2 );
  twobit_label( 1143, compiled_block_1_1143 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_6, 9, 0 );
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1328, compiled_block_1_1328 );
  twobit_invoke( 2 );
  twobit_label( 1328, compiled_block_1_1328 );
  twobit_load( 0, 0 );
  twobit_global( 11 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1003, compiled_block_1_1003 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1005, compiled_block_1_1005 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_lambda( compiled_start_1_12, 2, 0 );
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_13, 4, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 5 ); /* ex:map-while */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1005, compiled_block_1_1005 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1003, compiled_block_1_1003 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_12( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1007, compiled_block_1_1007 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1009, compiled_block_1_1009 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1011, compiled_block_1_1011 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_return();
  twobit_label( 1011, compiled_block_1_1011 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1009, compiled_block_1_1009 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1007, compiled_block_1_1007 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_13( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1013, compiled_block_1_1013 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_14, 2, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1020, compiled_block_1_1020 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_skip( 1019, compiled_block_1_1019 );
  twobit_label( 1020, compiled_block_1_1020 );
  twobit_movereg( 1, 3 );
  twobit_global( 4 ); /* map */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* list */
  twobit_setreg( 2 );
  twobit_global( 6 ); /* apply */
  twobit_setrtn( 1021, compiled_block_1_1021 );
  twobit_invoke( 3 );
  twobit_label( 1021, compiled_block_1_1021 );
  twobit_load( 0, 0 );
  twobit_label( 1019, compiled_block_1_1019 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1013, compiled_block_1_1013 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_14( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 3 );
  twobit_lexical( 1, 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1014, compiled_block_1_1014 );
  twobit_invoke( 1 );
  twobit_label( 1014, compiled_block_1_1014 );
  twobit_load( 0, 0 );
  twobit_branchf( 1016, compiled_block_1_1016 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1017, compiled_block_1_1017 );
  twobit_invoke( 5 );
  twobit_label( 1017, compiled_block_1_1017 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1016, compiled_block_1_1016 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_pop( 3 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1034, compiled_block_1_1034 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1036, compiled_block_1_1036 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_op1_branchf_610( 1038, compiled_block_1_1038 ); /* internal:branchf-null? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1039, compiled_block_1_1039 );
  twobit_invoke( 1 );
  twobit_label( 1039, compiled_block_1_1039 );
  twobit_load( 0, 0 );
  twobit_branchf( 1041, compiled_block_1_1041 );
  twobit_load( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1042, compiled_block_1_1042 );
  twobit_invoke( 5 );
  twobit_label( 1042, compiled_block_1_1042 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1041, compiled_block_1_1041 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 1031, compiled_block_1_1031 );
  twobit_label( 1038, compiled_block_1_1038 );
  twobit_branch( 1031, compiled_block_1_1031 );
  twobit_label( 1036, compiled_block_1_1036 );
  twobit_branch( 1031, compiled_block_1_1031 );
  twobit_label( 1034, compiled_block_1_1034 );
  twobit_branch( 1031, compiled_block_1_1031 );
  twobit_label( 1028, compiled_block_1_1028 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1048, compiled_block_1_1048 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1050, compiled_block_1_1050 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1052, compiled_block_1_1052 ); /* internal:branchf-pair? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1053, compiled_block_1_1053 );
  twobit_invoke( 1 );
  twobit_label( 1053, compiled_block_1_1053 );
  twobit_load( 0, 0 );
  twobit_branchf( 1055, compiled_block_1_1055 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1056, compiled_block_1_1056 );
  twobit_invoke( 5 );
  twobit_label( 1056, compiled_block_1_1056 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1055, compiled_block_1_1055 );
  twobit_load( 1, 4 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 1052, compiled_block_1_1052 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1050, compiled_block_1_1050 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1048, compiled_block_1_1048 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1029, compiled_block_1_1029 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1062, compiled_block_1_1062 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1064, compiled_block_1_1064 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1066, compiled_block_1_1066 ); /* internal:branchf-pair? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 4, 1 );
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1067, compiled_block_1_1067 );
  twobit_invoke( 1 );
  twobit_label( 1067, compiled_block_1_1067 );
  twobit_load( 0, 0 );
  twobit_branchf( 1069, compiled_block_1_1069 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1070, compiled_block_1_1070 );
  twobit_invoke( 1 );
  twobit_label( 1070, compiled_block_1_1070 );
  twobit_load( 0, 0 );
  twobit_branchf( 1072, compiled_block_1_1072 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1073, compiled_block_1_1073 );
  twobit_invoke( 5 );
  twobit_label( 1073, compiled_block_1_1073 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1072, compiled_block_1_1072 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1028, compiled_block_1_1028 );
  twobit_label( 1069, compiled_block_1_1069 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1028, compiled_block_1_1028 );
  twobit_label( 1066, compiled_block_1_1066 );
  twobit_branch( 1028, compiled_block_1_1028 );
  twobit_label( 1064, compiled_block_1_1064 );
  twobit_branch( 1028, compiled_block_1_1028 );
  twobit_label( 1062, compiled_block_1_1062 );
  twobit_branch( 1028, compiled_block_1_1028 );
  twobit_label( 1030, compiled_block_1_1030 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1080, compiled_block_1_1080 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1082, compiled_block_1_1082 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1084, compiled_block_1_1084 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1086, compiled_block_1_1086 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1088, compiled_block_1_1088 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1090, compiled_block_1_1090 ); /* internal:branchf-null? */
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 5 );
  twobit_store( 30, 2 );
  twobit_store( 31, 3 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1091, compiled_block_1_1091 );
  twobit_invoke( 1 );
  twobit_label( 1091, compiled_block_1_1091 );
  twobit_load( 0, 0 );
  twobit_branchf( 1093, compiled_block_1_1093 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 3 );
  twobit_op2_58( 2 ); /* cons */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1094, compiled_block_1_1094 );
  twobit_invoke( 5 );
  twobit_label( 1094, compiled_block_1_1094 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1093, compiled_block_1_1093 );
  twobit_load( 1, 5 );
  twobit_pop( 5 );
  twobit_branch( 1029, compiled_block_1_1029 );
  twobit_label( 1090, compiled_block_1_1090 );
  twobit_branch( 1029, compiled_block_1_1029 );
  twobit_label( 1088, compiled_block_1_1088 );
  twobit_branch( 1029, compiled_block_1_1029 );
  twobit_label( 1086, compiled_block_1_1086 );
  twobit_branch( 1029, compiled_block_1_1029 );
  twobit_label( 1084, compiled_block_1_1084 );
  twobit_branch( 1029, compiled_block_1_1029 );
  twobit_label( 1082, compiled_block_1_1082 );
  twobit_branch( 1029, compiled_block_1_1029 );
  twobit_label( 1080, compiled_block_1_1080 );
  twobit_branch( 1029, compiled_block_1_1029 );
  twobit_label( 1031, compiled_block_1_1031 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1103, compiled_block_1_1103 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1105, compiled_block_1_1105 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_8, 12, 2 );
  twobit_setreg( 3 );
  twobit_lambda( compiled_start_1_9, 14, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 15 ); /* ex:map-while */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_label( 1105, compiled_block_1_1105 );
  twobit_branch( 1030, compiled_block_1_1030 );
  twobit_label( 1103, compiled_block_1_1103 );
  twobit_branch( 1030, compiled_block_1_1030 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_8( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1107, compiled_block_1_1107 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_10, 2, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1130, compiled_block_1_1130 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_skip( 1129, compiled_block_1_1129 );
  twobit_label( 1130, compiled_block_1_1130 );
  twobit_movereg( 1, 3 );
  twobit_global( 4 ); /* map */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* list */
  twobit_setreg( 2 );
  twobit_global( 6 ); /* apply */
  twobit_setrtn( 1131, compiled_block_1_1131 );
  twobit_invoke( 3 );
  twobit_label( 1131, compiled_block_1_1131 );
  twobit_load( 0, 0 );
  twobit_label( 1129, compiled_block_1_1129 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1107, compiled_block_1_1107 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_jump( 1, 1030, compiled_block_1_1030 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_10( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_lexical( 1, 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1110, compiled_block_1_1110 );
  twobit_invoke( 1 );
  twobit_label( 1110, compiled_block_1_1110 );
  twobit_load( 0, 0 );
  twobit_branchf( 1112, compiled_block_1_1112 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1113, compiled_block_1_1113 );
  twobit_invoke( 5 );
  twobit_label( 1113, compiled_block_1_1113 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1114, compiled_block_1_1114 );
  twobit_invoke( 1 );
  twobit_label( 1114, compiled_block_1_1114 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1115, compiled_block_1_1115 );
  twobit_invoke( 1 );
  twobit_label( 1115, compiled_block_1_1115 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_branchf_623( 4, 11, compiled_temp_1_11, 1117, compiled_block_1_1117 ); /* internal:branchf-= */
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_setrtn( 1118, compiled_block_1_1118 );
  twobit_branch( 1108, compiled_block_1_1108 );
  twobit_label( 1118, compiled_block_1_1118 );
  twobit_load( 0, 0 );
  twobit_skip( 1116, compiled_block_1_1116 );
  twobit_label( 1117, compiled_block_1_1117 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_global( 10 ); /* ex:syntax-violation */
  twobit_setrtn( 1119, compiled_block_1_1119 );
  twobit_invoke( 4 );
  twobit_label( 1119, compiled_block_1_1119 );
  twobit_load( 0, 0 );
  twobit_label( 1116, compiled_block_1_1116 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1112, compiled_block_1_1112 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_pop( 5 );
  twobit_jump( 2, 1030, compiled_block_1_1030 );
  twobit_label( 1108, compiled_block_1_1108 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1122, compiled_block_1_1122 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1121, compiled_block_1_1121 );
  twobit_label( 1122, compiled_block_1_1122 );
  twobit_reg( 2 );
  twobit_op1_10(); /* null? */
  twobit_label( 1121, compiled_block_1_1121 );
  twobit_branchf( 1124, compiled_block_1_1124 );
  twobit_movereg( 3, 1 );
  twobit_global( 11 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1124, compiled_block_1_1124 );
  twobit_reg_op1_check_652(reg(2),1126,compiled_block_1_1126); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(1),1127,compiled_block_1_1127); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op2_58( 30 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 31 );
  twobit_op2_58( 4 ); /* cons */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_branch( 1108, compiled_block_1_1108 );
  twobit_label( 1126, compiled_block_1_1126 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 1127, compiled_block_1_1127 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_9( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1135, compiled_block_1_1135 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1137, compiled_block_1_1137 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1139, compiled_block_1_1139 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_return();
  twobit_label( 1139, compiled_block_1_1139 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1137, compiled_block_1_1137 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1135, compiled_block_1_1135 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_6( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1150, compiled_block_1_1150 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1152, compiled_block_1_1152 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1154, compiled_block_1_1154 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1156, compiled_block_1_1156 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_branchf_611( 1158, compiled_block_1_1158 ); /* internal:branchf-pair? */
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_branchf_611( 1160, compiled_block_1_1160 ); /* internal:branchf-pair? */
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 29 );
  twobit_reg( 31 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1162, compiled_block_1_1162 ); /* internal:branchf-null? */
  twobit_save( 9 );
  twobit_store( 0, 0 );
  twobit_store( 1, 9 );
  twobit_store( 3, 7 );
  twobit_store( 4, 1 );
  twobit_store( 29, 4 );
  twobit_store( 30, 2 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 6 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1163, compiled_block_1_1163 );
  twobit_invoke( 1 );
  twobit_label( 1163, compiled_block_1_1163 );
  twobit_load( 0, 0 );
  twobit_branchf( 1165, compiled_block_1_1165 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1167, compiled_block_1_1167 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1168, compiled_block_1_1168 );
  twobit_invoke( 1 );
  twobit_label( 1168, compiled_block_1_1168 );
  twobit_load( 0, 0 );
  twobit_branchf( 1170, compiled_block_1_1170 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1172, compiled_block_1_1172 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1173, compiled_block_1_1173 );
  twobit_invoke( 1 );
  twobit_label( 1173, compiled_block_1_1173 );
  twobit_load( 0, 0 );
  twobit_branchf( 1175, compiled_block_1_1175 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1177, compiled_block_1_1177 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1179, compiled_block_1_1179 ); /* internal:branchf-null? */
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1180, compiled_block_1_1180 );
  twobit_invoke( 5 );
  twobit_label( 1180, compiled_block_1_1180 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_global( 6 ); /* append */
  twobit_setrtn( 1181, compiled_block_1_1181 );
  twobit_invoke( 2 );
  twobit_label( 1181, compiled_block_1_1181 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 4 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 5 );
  twobit_global( 6 ); /* append */
  twobit_setrtn( 1182, compiled_block_1_1182 );
  twobit_invoke( 2 );
  twobit_label( 1182, compiled_block_1_1182 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 9 );
  twobit_return();
  twobit_label( 1179, compiled_block_1_1179 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1147, compiled_block_1_1147 );
  twobit_label( 1177, compiled_block_1_1177 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1147, compiled_block_1_1147 );
  twobit_label( 1175, compiled_block_1_1175 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1147, compiled_block_1_1147 );
  twobit_label( 1172, compiled_block_1_1172 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1147, compiled_block_1_1147 );
  twobit_label( 1170, compiled_block_1_1170 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1147, compiled_block_1_1147 );
  twobit_label( 1167, compiled_block_1_1167 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1147, compiled_block_1_1147 );
  twobit_label( 1165, compiled_block_1_1165 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1147, compiled_block_1_1147 );
  twobit_label( 1162, compiled_block_1_1162 );
  twobit_branch( 1147, compiled_block_1_1147 );
  twobit_label( 1160, compiled_block_1_1160 );
  twobit_branch( 1147, compiled_block_1_1147 );
  twobit_label( 1158, compiled_block_1_1158 );
  twobit_branch( 1147, compiled_block_1_1147 );
  twobit_label( 1156, compiled_block_1_1156 );
  twobit_branch( 1147, compiled_block_1_1147 );
  twobit_label( 1154, compiled_block_1_1154 );
  twobit_branch( 1147, compiled_block_1_1147 );
  twobit_label( 1152, compiled_block_1_1152 );
  twobit_branch( 1147, compiled_block_1_1147 );
  twobit_label( 1150, compiled_block_1_1150 );
  twobit_branch( 1147, compiled_block_1_1147 );
  twobit_label( 1144, compiled_block_1_1144 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1198, compiled_block_1_1198 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1200, compiled_block_1_1200 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1202, compiled_block_1_1202 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1204, compiled_block_1_1204 ); /* internal:branchf-pair? */
  twobit_save( 10 );
  twobit_store( 0, 0 );
  twobit_store( 1, 10 );
  twobit_store( 3, 2 );
  twobit_store( 4, 1 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 3 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 9 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1205, compiled_block_1_1205 );
  twobit_invoke( 1 );
  twobit_label( 1205, compiled_block_1_1205 );
  twobit_load( 0, 0 );
  twobit_branchf( 1207, compiled_block_1_1207 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1209, compiled_block_1_1209 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1210, compiled_block_1_1210 );
  twobit_invoke( 1 );
  twobit_label( 1210, compiled_block_1_1210 );
  twobit_load( 0, 0 );
  twobit_branchf( 1212, compiled_block_1_1212 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1214, compiled_block_1_1214 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 8 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1215, compiled_block_1_1215 );
  twobit_invoke( 1 );
  twobit_label( 1215, compiled_block_1_1215 );
  twobit_load( 0, 0 );
  twobit_branchf( 1217, compiled_block_1_1217 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1219, compiled_block_1_1219 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1221, compiled_block_1_1221 ); /* internal:branchf-null? */
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1222, compiled_block_1_1222 );
  twobit_invoke( 5 );
  twobit_label( 1222, compiled_block_1_1222 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1223, compiled_block_1_1223 );
  twobit_invoke( 5 );
  twobit_label( 1223, compiled_block_1_1223 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 2, 3 );
  twobit_load( 1, 4 );
  twobit_global( 6 ); /* append */
  twobit_setrtn( 1224, compiled_block_1_1224 );
  twobit_invoke( 2 );
  twobit_label( 1224, compiled_block_1_1224 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 1, 8 );
  twobit_load( 2, 9 );
  twobit_global( 6 ); /* append */
  twobit_setrtn( 1225, compiled_block_1_1225 );
  twobit_invoke( 2 );
  twobit_label( 1225, compiled_block_1_1225 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 10 );
  twobit_return();
  twobit_label( 1221, compiled_block_1_1221 );
  twobit_load( 1, 10 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_pop( 10 );
  twobit_invoke( 1 );
  twobit_label( 1219, compiled_block_1_1219 );
  twobit_load( 1, 10 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_pop( 10 );
  twobit_invoke( 1 );
  twobit_label( 1217, compiled_block_1_1217 );
  twobit_load( 1, 10 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_pop( 10 );
  twobit_invoke( 1 );
  twobit_label( 1214, compiled_block_1_1214 );
  twobit_load( 1, 10 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_pop( 10 );
  twobit_invoke( 1 );
  twobit_label( 1212, compiled_block_1_1212 );
  twobit_load( 1, 10 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_pop( 10 );
  twobit_invoke( 1 );
  twobit_label( 1209, compiled_block_1_1209 );
  twobit_load( 1, 10 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_pop( 10 );
  twobit_invoke( 1 );
  twobit_label( 1207, compiled_block_1_1207 );
  twobit_load( 1, 10 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_pop( 10 );
  twobit_invoke( 1 );
  twobit_label( 1204, compiled_block_1_1204 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1202, compiled_block_1_1202 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1200, compiled_block_1_1200 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1198, compiled_block_1_1198 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1145, compiled_block_1_1145 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1238, compiled_block_1_1238 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1237, compiled_block_1_1237 );
  twobit_label( 1238, compiled_block_1_1238 );
  twobit_reg( 2 );
  twobit_op1_10(); /* null? */
  twobit_label( 1237, compiled_block_1_1237 );
  twobit_branchf( 1240, compiled_block_1_1240 );
  twobit_movereg( 3, 1 );
  twobit_global( 11 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1240, compiled_block_1_1240 );
  twobit_reg_op1_check_652(reg(2),1242,compiled_block_1_1242); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(1),1243,compiled_block_1_1243); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op2_58( 30 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 31 );
  twobit_op2_58( 4 ); /* cons */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_branch( 1145, compiled_block_1_1145 );
  twobit_label( 1146, compiled_block_1_1146 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1246, compiled_block_1_1246 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1248, compiled_block_1_1248 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1250, compiled_block_1_1250 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_op1_branchf_610( 1252, compiled_block_1_1252 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1254, compiled_block_1_1254 ); /* internal:branchf-pair? */
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 7 );
  twobit_store( 3, 2 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1255, compiled_block_1_1255 );
  twobit_invoke( 1 );
  twobit_label( 1255, compiled_block_1_1255 );
  twobit_load( 0, 0 );
  twobit_branchf( 1257, compiled_block_1_1257 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1259, compiled_block_1_1259 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1260, compiled_block_1_1260 );
  twobit_invoke( 1 );
  twobit_label( 1260, compiled_block_1_1260 );
  twobit_load( 0, 0 );
  twobit_branchf( 1262, compiled_block_1_1262 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1264, compiled_block_1_1264 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1266, compiled_block_1_1266 ); /* internal:branchf-null? */
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1267, compiled_block_1_1267 );
  twobit_invoke( 5 );
  twobit_label( 1267, compiled_block_1_1267 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_load( 2, 1 );
  twobit_stack( 3 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1268, compiled_block_1_1268 );
  twobit_invoke( 5 );
  twobit_label( 1268, compiled_block_1_1268 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1266, compiled_block_1_1266 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1144, compiled_block_1_1144 );
  twobit_label( 1264, compiled_block_1_1264 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1144, compiled_block_1_1144 );
  twobit_label( 1262, compiled_block_1_1262 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1144, compiled_block_1_1144 );
  twobit_label( 1259, compiled_block_1_1259 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1144, compiled_block_1_1144 );
  twobit_label( 1257, compiled_block_1_1257 );
  twobit_load( 1, 7 );
  twobit_pop( 7 );
  twobit_branch( 1144, compiled_block_1_1144 );
  twobit_label( 1254, compiled_block_1_1254 );
  twobit_branch( 1144, compiled_block_1_1144 );
  twobit_label( 1252, compiled_block_1_1252 );
  twobit_branch( 1144, compiled_block_1_1144 );
  twobit_label( 1250, compiled_block_1_1250 );
  twobit_branch( 1144, compiled_block_1_1144 );
  twobit_label( 1248, compiled_block_1_1248 );
  twobit_branch( 1144, compiled_block_1_1144 );
  twobit_label( 1246, compiled_block_1_1246 );
  twobit_branch( 1144, compiled_block_1_1144 );
  twobit_label( 1147, compiled_block_1_1147 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1280, compiled_block_1_1280 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1282, compiled_block_1_1282 ); /* internal:branchf-pair? */
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 8 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 13 ); /* equal? */
  twobit_setrtn( 1283, compiled_block_1_1283 );
  twobit_invoke( 2 );
  twobit_label( 1283, compiled_block_1_1283 );
  twobit_load( 0, 0 );
  twobit_branchf( 1285, compiled_block_1_1285 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1287, compiled_block_1_1287 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1289, compiled_block_1_1289 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 5 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1290, compiled_block_1_1290 );
  twobit_invoke( 1 );
  twobit_label( 1290, compiled_block_1_1290 );
  twobit_load( 0, 0 );
  twobit_branchf( 1292, compiled_block_1_1292 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1294, compiled_block_1_1294 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1295, compiled_block_1_1295 );
  twobit_invoke( 1 );
  twobit_label( 1295, compiled_block_1_1295 );
  twobit_load( 0, 0 );
  twobit_branchf( 1297, compiled_block_1_1297 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1299, compiled_block_1_1299 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1300, compiled_block_1_1300 );
  twobit_invoke( 1 );
  twobit_label( 1300, compiled_block_1_1300 );
  twobit_load( 0, 0 );
  twobit_branchf( 1302, compiled_block_1_1302 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1304, compiled_block_1_1304 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1306, compiled_block_1_1306 ); /* internal:branchf-null? */
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1307, compiled_block_1_1307 );
  twobit_invoke( 5 );
  twobit_label( 1307, compiled_block_1_1307 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 1, 2 );
  twobit_global( 16 ); /* length */
  twobit_setrtn( 1308, compiled_block_1_1308 );
  twobit_invoke( 1 );
  twobit_label( 1308, compiled_block_1_1308 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 3 );
  twobit_global( 16 ); /* length */
  twobit_setrtn( 1309, compiled_block_1_1309 );
  twobit_invoke( 1 );
  twobit_label( 1309, compiled_block_1_1309 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_branchf_623( 4, 7, compiled_temp_1_7, 1311, compiled_block_1_1311 ); /* internal:branchf-= */
  twobit_load( 1, 2 );
  twobit_load( 2, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_setrtn( 1312, compiled_block_1_1312 );
  twobit_branch( 1145, compiled_block_1_1145 );
  twobit_label( 1312, compiled_block_1_1312 );
  twobit_load( 0, 0 );
  twobit_skip( 1310, compiled_block_1_1310 );
  twobit_label( 1311, compiled_block_1_1311 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 17 );
  twobit_setreg( 1 );
  twobit_const( 18 );
  twobit_setreg( 2 );
  twobit_const( 19 );
  twobit_setreg( 3 );
  twobit_global( 20 ); /* ex:syntax-violation */
  twobit_setrtn( 1313, compiled_block_1_1313 );
  twobit_invoke( 4 );
  twobit_label( 1313, compiled_block_1_1313 );
  twobit_load( 0, 0 );
  twobit_label( 1310, compiled_block_1_1310 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 21 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 15 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1314, compiled_block_1_1314 );
  twobit_invoke( 5 );
  twobit_label( 1314, compiled_block_1_1314 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 3, 4 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_global( 6 ); /* append */
  twobit_setrtn( 1315, compiled_block_1_1315 );
  twobit_invoke( 2 );
  twobit_label( 1315, compiled_block_1_1315 );
  twobit_load( 0, 0 );
  twobit_load( 3, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 1306, compiled_block_1_1306 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1146, compiled_block_1_1146 );
  twobit_label( 1304, compiled_block_1_1304 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1146, compiled_block_1_1146 );
  twobit_label( 1302, compiled_block_1_1302 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1146, compiled_block_1_1146 );
  twobit_label( 1299, compiled_block_1_1299 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1146, compiled_block_1_1146 );
  twobit_label( 1297, compiled_block_1_1297 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1146, compiled_block_1_1146 );
  twobit_label( 1294, compiled_block_1_1294 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1146, compiled_block_1_1146 );
  twobit_label( 1292, compiled_block_1_1292 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1146, compiled_block_1_1146 );
  twobit_label( 1289, compiled_block_1_1289 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1146, compiled_block_1_1146 );
  twobit_label( 1287, compiled_block_1_1287 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1146, compiled_block_1_1146 );
  twobit_label( 1285, compiled_block_1_1285 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1146, compiled_block_1_1146 );
  twobit_label( 1282, compiled_block_1_1282 );
  twobit_branch( 1146, compiled_block_1_1146 );
  twobit_label( 1280, compiled_block_1_1280 );
  twobit_branch( 1146, compiled_block_1_1146 );
  twobit_label( 1242, compiled_block_1_1242 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 1243, compiled_block_1_1243 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_75ac9dde519b9b69ac99fc75816fa3ee_0(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_1_0(CONT_ACTUALS));
}
static RTYPE compiled_block_2_1004( CONT_PARAMS );
static RTYPE compiled_block_2_1003( CONT_PARAMS );
static RTYPE compiled_start_2_0( CONT_PARAMS );
static RTYPE compiled_start_2_3( CONT_PARAMS );
static RTYPE compiled_start_2_2( CONT_PARAMS );
static RTYPE compiled_start_2_1( CONT_PARAMS );

static RTYPE compiled_start_2_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_2_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_2_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1003, compiled_block_2_1003 );
  twobit_invoke( 8 );
  twobit_label( 1003, compiled_block_2_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1004, compiled_block_2_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_2_1004 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_75ac9dde519b9b69ac99fc75816fa3ee_1(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_2_0(CONT_ACTUALS));
}
codeptr_t CDECL twobit_load_table[] = { 
  twobit_thunk_75ac9dde519b9b69ac99fc75816fa3ee_0,
  twobit_thunk_75ac9dde519b9b69ac99fc75816fa3ee_1,
  0  /* The table may be empty; some compilers complain */
};

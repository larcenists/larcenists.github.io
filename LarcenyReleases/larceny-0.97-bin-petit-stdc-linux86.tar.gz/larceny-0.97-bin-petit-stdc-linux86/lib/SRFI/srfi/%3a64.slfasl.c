/* Generated from /home/henchman/larcenytest/larceny-petit-Nightly-2009-08-19/larceny_src/lib/SRFI/srfi/%3a64.slfasl */
#include "petit-instr.h"

static RTYPE compiled_block_1_2300( CONT_PARAMS );
static RTYPE compiled_block_1_2299( CONT_PARAMS );
static RTYPE compiled_start_1_0( CONT_PARAMS );
static RTYPE compiled_start_1_3( CONT_PARAMS );
static RTYPE compiled_block_1_2285( CONT_PARAMS );
static RTYPE compiled_block_1_2288( CONT_PARAMS );
static RTYPE compiled_block_1_2295( CONT_PARAMS );
static RTYPE compiled_block_1_2296( CONT_PARAMS );
static RTYPE compiled_block_1_2291( CONT_PARAMS );
static RTYPE compiled_block_1_2293( CONT_PARAMS );
static RTYPE compiled_block_1_2292( CONT_PARAMS );
static RTYPE compiled_block_1_2289( CONT_PARAMS );
static RTYPE compiled_block_1_2290( CONT_PARAMS );
static RTYPE compiled_block_1_2286( CONT_PARAMS );
static RTYPE compiled_block_1_2287( CONT_PARAMS );
static RTYPE compiled_block_1_2284( CONT_PARAMS );
static RTYPE compiled_block_1_2283( CONT_PARAMS );
static RTYPE compiled_start_1_91( CONT_PARAMS );
static RTYPE compiled_start_1_90( CONT_PARAMS );
static RTYPE compiled_block_1_2281( CONT_PARAMS );
static RTYPE compiled_start_1_92( CONT_PARAMS );
static RTYPE compiled_block_1_2278( CONT_PARAMS );
static RTYPE compiled_block_1_2275( CONT_PARAMS );
static RTYPE compiled_block_1_2273( CONT_PARAMS );
static RTYPE compiled_start_1_89( CONT_PARAMS );
static RTYPE compiled_start_1_88( CONT_PARAMS );
static RTYPE compiled_start_1_93( CONT_PARAMS );
static RTYPE compiled_block_1_2266( CONT_PARAMS );
static RTYPE compiled_block_1_2268( CONT_PARAMS );
static RTYPE compiled_block_1_2269( CONT_PARAMS );
static RTYPE compiled_block_1_2267( CONT_PARAMS );
static RTYPE compiled_block_1_2265( CONT_PARAMS );
static RTYPE compiled_start_1_94( CONT_PARAMS );
static RTYPE compiled_start_1_87( CONT_PARAMS );
static RTYPE compiled_start_1_95( CONT_PARAMS );
static RTYPE compiled_block_1_2258( CONT_PARAMS );
static RTYPE compiled_block_1_2260( CONT_PARAMS );
static RTYPE compiled_block_1_2261( CONT_PARAMS );
static RTYPE compiled_block_1_2259( CONT_PARAMS );
static RTYPE compiled_block_1_2257( CONT_PARAMS );
static RTYPE compiled_start_1_96( CONT_PARAMS );
static RTYPE compiled_start_1_86( CONT_PARAMS );
static RTYPE compiled_block_1_2255( CONT_PARAMS );
static RTYPE compiled_temp_1_101( CONT_PARAMS );
static RTYPE compiled_temp_1_100( CONT_PARAMS );
static RTYPE compiled_temp_1_99( CONT_PARAMS );
static RTYPE compiled_temp_1_98( CONT_PARAMS );
static RTYPE compiled_start_1_97( CONT_PARAMS );
static RTYPE compiled_block_1_2252( CONT_PARAMS );
static RTYPE compiled_block_1_2251( CONT_PARAMS );
static RTYPE compiled_block_1_2249( CONT_PARAMS );
static RTYPE compiled_block_1_2237( CONT_PARAMS );
static RTYPE compiled_block_1_2247( CONT_PARAMS );
static RTYPE compiled_block_1_2246( CONT_PARAMS );
static RTYPE compiled_block_1_2244( CONT_PARAMS );
static RTYPE compiled_block_1_2245( CONT_PARAMS );
static RTYPE compiled_block_1_2240( CONT_PARAMS );
static RTYPE compiled_block_1_2242( CONT_PARAMS );
static RTYPE compiled_block_1_2241( CONT_PARAMS );
static RTYPE compiled_block_1_2238( CONT_PARAMS );
static RTYPE compiled_block_1_2233( CONT_PARAMS );
static RTYPE compiled_block_1_2231( CONT_PARAMS );
static RTYPE compiled_start_1_85( CONT_PARAMS );
static RTYPE compiled_start_1_107( CONT_PARAMS );
static RTYPE compiled_start_1_106( CONT_PARAMS );
static RTYPE compiled_start_1_105( CONT_PARAMS );
static RTYPE compiled_start_1_104( CONT_PARAMS );
static RTYPE compiled_start_1_103( CONT_PARAMS );
static RTYPE compiled_start_1_102( CONT_PARAMS );
static RTYPE compiled_start_1_84( CONT_PARAMS );
static RTYPE compiled_block_1_2230( CONT_PARAMS );
static RTYPE compiled_temp_1_112( CONT_PARAMS );
static RTYPE compiled_temp_1_111( CONT_PARAMS );
static RTYPE compiled_temp_1_110( CONT_PARAMS );
static RTYPE compiled_temp_1_109( CONT_PARAMS );
static RTYPE compiled_start_1_108( CONT_PARAMS );
static RTYPE compiled_block_1_2228( CONT_PARAMS );
static RTYPE compiled_block_1_2227( CONT_PARAMS );
static RTYPE compiled_block_1_2225( CONT_PARAMS );
static RTYPE compiled_block_1_2224( CONT_PARAMS );
static RTYPE compiled_start_1_83( CONT_PARAMS );
static RTYPE compiled_block_1_2216( CONT_PARAMS );
static RTYPE compiled_block_1_2217( CONT_PARAMS );
static RTYPE compiled_block_1_2222( CONT_PARAMS );
static RTYPE compiled_block_1_2218( CONT_PARAMS );
static RTYPE compiled_block_1_2220( CONT_PARAMS );
static RTYPE compiled_block_1_2214( CONT_PARAMS );
static RTYPE compiled_block_1_2215( CONT_PARAMS );
static RTYPE compiled_block_1_2213( CONT_PARAMS );
static RTYPE compiled_block_1_2212( CONT_PARAMS );
static RTYPE compiled_start_1_82( CONT_PARAMS );
static RTYPE compiled_block_1_2211( CONT_PARAMS );
static RTYPE compiled_block_1_2209( CONT_PARAMS );
static RTYPE compiled_block_1_2210( CONT_PARAMS );
static RTYPE compiled_block_1_2208( CONT_PARAMS );
static RTYPE compiled_block_1_2207( CONT_PARAMS );
static RTYPE compiled_block_1_2206( CONT_PARAMS );
static RTYPE compiled_block_1_2205( CONT_PARAMS );
static RTYPE compiled_block_1_2204( CONT_PARAMS );
static RTYPE compiled_start_1_81( CONT_PARAMS );
static RTYPE compiled_start_1_80( CONT_PARAMS );
static RTYPE compiled_block_1_2202( CONT_PARAMS );
static RTYPE compiled_block_1_2201( CONT_PARAMS );
static RTYPE compiled_temp_1_118( CONT_PARAMS );
static RTYPE compiled_block_1_2200( CONT_PARAMS );
static RTYPE compiled_block_1_2182( CONT_PARAMS );
static RTYPE compiled_block_1_2199( CONT_PARAMS );
static RTYPE compiled_temp_1_117( CONT_PARAMS );
static RTYPE compiled_block_1_2198( CONT_PARAMS );
static RTYPE compiled_block_1_2195( CONT_PARAMS );
static RTYPE compiled_block_1_2197( CONT_PARAMS );
static RTYPE compiled_temp_1_116( CONT_PARAMS );
static RTYPE compiled_block_1_2196( CONT_PARAMS );
static RTYPE compiled_block_1_2191( CONT_PARAMS );
static RTYPE compiled_block_1_2193( CONT_PARAMS );
static RTYPE compiled_temp_1_115( CONT_PARAMS );
static RTYPE compiled_block_1_2192( CONT_PARAMS );
static RTYPE compiled_block_1_2187( CONT_PARAMS );
static RTYPE compiled_block_1_2189( CONT_PARAMS );
static RTYPE compiled_temp_1_114( CONT_PARAMS );
static RTYPE compiled_block_1_2188( CONT_PARAMS );
static RTYPE compiled_block_1_2183( CONT_PARAMS );
static RTYPE compiled_block_1_2185( CONT_PARAMS );
static RTYPE compiled_temp_1_113( CONT_PARAMS );
static RTYPE compiled_block_1_2184( CONT_PARAMS );
static RTYPE compiled_block_1_2181( CONT_PARAMS );
static RTYPE compiled_block_1_2180( CONT_PARAMS );
static RTYPE compiled_start_1_79( CONT_PARAMS );
static RTYPE compiled_block_1_2174( CONT_PARAMS );
static RTYPE compiled_block_1_2179( CONT_PARAMS );
static RTYPE compiled_block_1_2178( CONT_PARAMS );
static RTYPE compiled_block_1_2176( CONT_PARAMS );
static RTYPE compiled_block_1_2172( CONT_PARAMS );
static RTYPE compiled_block_1_2173( CONT_PARAMS );
static RTYPE compiled_block_1_2171( CONT_PARAMS );
static RTYPE compiled_block_1_2170( CONT_PARAMS );
static RTYPE compiled_block_1_2167( CONT_PARAMS );
static RTYPE compiled_block_1_2169( CONT_PARAMS );
static RTYPE compiled_block_1_2168( CONT_PARAMS );
static RTYPE compiled_start_1_78( CONT_PARAMS );
static RTYPE compiled_block_1_2166( CONT_PARAMS );
static RTYPE compiled_block_1_2165( CONT_PARAMS );
static RTYPE compiled_block_1_2163( CONT_PARAMS );
static RTYPE compiled_block_1_2162( CONT_PARAMS );
static RTYPE compiled_block_1_2160( CONT_PARAMS );
static RTYPE compiled_block_1_2161( CONT_PARAMS );
static RTYPE compiled_start_1_77( CONT_PARAMS );
static RTYPE compiled_block_1_2152( CONT_PARAMS );
static RTYPE compiled_block_1_2158( CONT_PARAMS );
static RTYPE compiled_block_1_2150( CONT_PARAMS );
static RTYPE compiled_block_1_2149( CONT_PARAMS );
static RTYPE compiled_start_1_76( CONT_PARAMS );
static RTYPE compiled_block_1_2156( CONT_PARAMS );
static RTYPE compiled_block_1_2155( CONT_PARAMS );
static RTYPE compiled_block_1_2157( CONT_PARAMS );
static RTYPE compiled_block_1_2154( CONT_PARAMS );
static RTYPE compiled_start_1_119( CONT_PARAMS );
static RTYPE compiled_start_1_75( CONT_PARAMS );
static RTYPE compiled_block_1_2146( CONT_PARAMS );
static RTYPE compiled_block_1_2144( CONT_PARAMS );
static RTYPE compiled_block_1_2143( CONT_PARAMS );
static RTYPE compiled_start_1_74( CONT_PARAMS );
static RTYPE compiled_block_1_2138( CONT_PARAMS );
static RTYPE compiled_block_1_2141( CONT_PARAMS );
static RTYPE compiled_block_1_2140( CONT_PARAMS );
static RTYPE compiled_block_1_2139( CONT_PARAMS );
static RTYPE compiled_block_1_2137( CONT_PARAMS );
static RTYPE compiled_start_1_73( CONT_PARAMS );
static RTYPE compiled_block_1_2099( CONT_PARAMS );
static RTYPE compiled_block_1_2080( CONT_PARAMS );
static RTYPE compiled_block_1_2086( CONT_PARAMS );
static RTYPE compiled_block_1_2116( CONT_PARAMS );
static RTYPE compiled_block_1_2119( CONT_PARAMS );
static RTYPE compiled_block_1_2118( CONT_PARAMS );
static RTYPE compiled_block_1_2117( CONT_PARAMS );
static RTYPE compiled_block_1_2114( CONT_PARAMS );
static RTYPE compiled_block_1_2087( CONT_PARAMS );
static RTYPE compiled_block_1_2088( CONT_PARAMS );
static RTYPE compiled_block_1_2113( CONT_PARAMS );
static RTYPE compiled_block_1_2109( CONT_PARAMS );
static RTYPE compiled_block_1_2110( CONT_PARAMS );
static RTYPE compiled_block_1_2112( CONT_PARAMS );
static RTYPE compiled_block_1_2111( CONT_PARAMS );
static RTYPE compiled_block_1_2108( CONT_PARAMS );
static RTYPE compiled_block_1_2106( CONT_PARAMS );
static RTYPE compiled_block_1_2107( CONT_PARAMS );
static RTYPE compiled_block_1_2095( CONT_PARAMS );
static RTYPE compiled_block_1_2096( CONT_PARAMS );
static RTYPE compiled_block_1_2105( CONT_PARAMS );
static RTYPE compiled_block_1_2102( CONT_PARAMS );
static RTYPE compiled_block_1_2103( CONT_PARAMS );
static RTYPE compiled_block_1_2104( CONT_PARAMS );
static RTYPE compiled_block_1_2101( CONT_PARAMS );
static RTYPE compiled_block_1_2097( CONT_PARAMS );
static RTYPE compiled_block_1_2098( CONT_PARAMS );
static RTYPE compiled_block_1_2100( CONT_PARAMS );
static RTYPE compiled_block_1_2093( CONT_PARAMS );
static RTYPE compiled_block_1_2094( CONT_PARAMS );
static RTYPE compiled_block_1_2092( CONT_PARAMS );
static RTYPE compiled_block_1_2091( CONT_PARAMS );
static RTYPE compiled_block_1_2090( CONT_PARAMS );
static RTYPE compiled_block_1_2089( CONT_PARAMS );
static RTYPE compiled_block_1_2082( CONT_PARAMS );
static RTYPE compiled_block_1_2085( CONT_PARAMS );
static RTYPE compiled_block_1_2083( CONT_PARAMS );
static RTYPE compiled_block_1_2081( CONT_PARAMS );
static RTYPE compiled_block_1_2078( CONT_PARAMS );
static RTYPE compiled_block_1_2079( CONT_PARAMS );
static RTYPE compiled_block_1_2077( CONT_PARAMS );
static RTYPE compiled_block_1_2076( CONT_PARAMS );
static RTYPE compiled_start_1_72( CONT_PARAMS );
static RTYPE compiled_block_1_2127( CONT_PARAMS );
static RTYPE compiled_block_1_2122( CONT_PARAMS );
static RTYPE compiled_block_1_2121( CONT_PARAMS );
static RTYPE compiled_block_1_2132( CONT_PARAMS );
static RTYPE compiled_block_1_2134( CONT_PARAMS );
static RTYPE compiled_block_1_2133( CONT_PARAMS );
static RTYPE compiled_block_1_2123( CONT_PARAMS );
static RTYPE compiled_block_1_2131( CONT_PARAMS );
static RTYPE compiled_block_1_2129( CONT_PARAMS );
static RTYPE compiled_block_1_2126( CONT_PARAMS );
static RTYPE compiled_block_1_2124( CONT_PARAMS );
static RTYPE compiled_start_1_120( CONT_PARAMS );
static RTYPE compiled_block_1_2056( CONT_PARAMS );
static RTYPE compiled_block_1_2074( CONT_PARAMS );
static RTYPE compiled_block_1_2070( CONT_PARAMS );
static RTYPE compiled_block_1_2071( CONT_PARAMS );
static RTYPE compiled_block_1_2072( CONT_PARAMS );
static RTYPE compiled_block_1_2067( CONT_PARAMS );
static RTYPE compiled_block_1_2068( CONT_PARAMS );
static RTYPE compiled_block_1_2069( CONT_PARAMS );
static RTYPE compiled_block_1_2064( CONT_PARAMS );
static RTYPE compiled_block_1_2065( CONT_PARAMS );
static RTYPE compiled_block_1_2066( CONT_PARAMS );
static RTYPE compiled_block_1_2063( CONT_PARAMS );
static RTYPE compiled_block_1_2062( CONT_PARAMS );
static RTYPE compiled_block_1_2061( CONT_PARAMS );
static RTYPE compiled_block_1_2060( CONT_PARAMS );
static RTYPE compiled_block_1_2059( CONT_PARAMS );
static RTYPE compiled_block_1_2058( CONT_PARAMS );
static RTYPE compiled_block_1_2057( CONT_PARAMS );
static RTYPE compiled_block_1_2054( CONT_PARAMS );
static RTYPE compiled_block_1_2053( CONT_PARAMS );
static RTYPE compiled_start_1_71( CONT_PARAMS );
static RTYPE compiled_block_1_2018( CONT_PARAMS );
static RTYPE compiled_block_1_2037( CONT_PARAMS );
static RTYPE compiled_block_1_2025( CONT_PARAMS );
static RTYPE compiled_block_1_2026( CONT_PARAMS );
static RTYPE compiled_block_1_2050( CONT_PARAMS );
static RTYPE compiled_block_1_2051( CONT_PARAMS );
static RTYPE compiled_block_1_2048( CONT_PARAMS );
static RTYPE compiled_block_1_2047( CONT_PARAMS );
static RTYPE compiled_block_1_2046( CONT_PARAMS );
static RTYPE compiled_block_1_2045( CONT_PARAMS );
static RTYPE compiled_block_1_2044( CONT_PARAMS );
static RTYPE compiled_block_1_2043( CONT_PARAMS );
static RTYPE compiled_block_1_2042( CONT_PARAMS );
static RTYPE compiled_block_1_2041( CONT_PARAMS );
static RTYPE compiled_block_1_2040( CONT_PARAMS );
static RTYPE compiled_block_1_2039( CONT_PARAMS );
static RTYPE compiled_block_1_2038( CONT_PARAMS );
static RTYPE compiled_block_1_2036( CONT_PARAMS );
static RTYPE compiled_block_1_2035( CONT_PARAMS );
static RTYPE compiled_block_1_2034( CONT_PARAMS );
static RTYPE compiled_block_1_2030( CONT_PARAMS );
static RTYPE compiled_block_1_2031( CONT_PARAMS );
static RTYPE compiled_block_1_2033( CONT_PARAMS );
static RTYPE compiled_block_1_2032( CONT_PARAMS );
static RTYPE compiled_block_1_2028( CONT_PARAMS );
static RTYPE compiled_block_1_2029( CONT_PARAMS );
static RTYPE compiled_temp_1_122( CONT_PARAMS );
static RTYPE compiled_temp_1_121( CONT_PARAMS );
static RTYPE compiled_block_1_2027( CONT_PARAMS );
static RTYPE compiled_block_1_2024( CONT_PARAMS );
static RTYPE compiled_block_1_2020( CONT_PARAMS );
static RTYPE compiled_block_1_2021( CONT_PARAMS );
static RTYPE compiled_block_1_2023( CONT_PARAMS );
static RTYPE compiled_block_1_2022( CONT_PARAMS );
static RTYPE compiled_block_1_2016( CONT_PARAMS );
static RTYPE compiled_block_1_2017( CONT_PARAMS );
static RTYPE compiled_block_1_2019( CONT_PARAMS );
static RTYPE compiled_block_1_2011( CONT_PARAMS );
static RTYPE compiled_block_1_2012( CONT_PARAMS );
static RTYPE compiled_block_1_2015( CONT_PARAMS );
static RTYPE compiled_block_1_2014( CONT_PARAMS );
static RTYPE compiled_block_1_2013( CONT_PARAMS );
static RTYPE compiled_block_1_2010( CONT_PARAMS );
static RTYPE compiled_block_1_2009( CONT_PARAMS );
static RTYPE compiled_block_1_2008( CONT_PARAMS );
static RTYPE compiled_block_1_2007( CONT_PARAMS );
static RTYPE compiled_start_1_70( CONT_PARAMS );
static RTYPE compiled_block_1_2001( CONT_PARAMS );
static RTYPE compiled_block_1_2004( CONT_PARAMS );
static RTYPE compiled_block_1_2003( CONT_PARAMS );
static RTYPE compiled_block_1_2005( CONT_PARAMS );
static RTYPE compiled_block_1_1999( CONT_PARAMS );
static RTYPE compiled_block_1_2000( CONT_PARAMS );
static RTYPE compiled_block_1_1998( CONT_PARAMS );
static RTYPE compiled_block_1_1997( CONT_PARAMS );
static RTYPE compiled_block_1_1996( CONT_PARAMS );
static RTYPE compiled_start_1_69( CONT_PARAMS );
static RTYPE compiled_block_1_1994( CONT_PARAMS );
static RTYPE compiled_block_1_1992( CONT_PARAMS );
static RTYPE compiled_block_1_1991( CONT_PARAMS );
static RTYPE compiled_block_1_1990( CONT_PARAMS );
static RTYPE compiled_block_1_1989( CONT_PARAMS );
static RTYPE compiled_start_1_68( CONT_PARAMS );
static RTYPE compiled_block_1_1987( CONT_PARAMS );
static RTYPE compiled_block_1_1986( CONT_PARAMS );
static RTYPE compiled_block_1_1985( CONT_PARAMS );
static RTYPE compiled_block_1_1984( CONT_PARAMS );
static RTYPE compiled_block_1_1983( CONT_PARAMS );
static RTYPE compiled_block_1_1982( CONT_PARAMS );
static RTYPE compiled_block_1_1981( CONT_PARAMS );
static RTYPE compiled_block_1_1980( CONT_PARAMS );
static RTYPE compiled_block_1_1979( CONT_PARAMS );
static RTYPE compiled_start_1_67( CONT_PARAMS );
static RTYPE compiled_block_1_1975( CONT_PARAMS );
static RTYPE compiled_block_1_1977( CONT_PARAMS );
static RTYPE compiled_block_1_1976( CONT_PARAMS );
static RTYPE compiled_temp_1_123( CONT_PARAMS );
static RTYPE compiled_start_1_66( CONT_PARAMS );
static RTYPE compiled_block_1_1972( CONT_PARAMS );
static RTYPE compiled_block_1_1971( CONT_PARAMS );
static RTYPE compiled_block_1_1970( CONT_PARAMS );
static RTYPE compiled_start_1_65( CONT_PARAMS );
static RTYPE compiled_block_1_1968( CONT_PARAMS );
static RTYPE compiled_block_1_1966( CONT_PARAMS );
static RTYPE compiled_block_1_1965( CONT_PARAMS );
static RTYPE compiled_block_1_1964( CONT_PARAMS );
static RTYPE compiled_block_1_1963( CONT_PARAMS );
static RTYPE compiled_start_1_64( CONT_PARAMS );
static RTYPE compiled_block_1_1961( CONT_PARAMS );
static RTYPE compiled_block_1_1960( CONT_PARAMS );
static RTYPE compiled_block_1_1959( CONT_PARAMS );
static RTYPE compiled_block_1_1958( CONT_PARAMS );
static RTYPE compiled_block_1_1957( CONT_PARAMS );
static RTYPE compiled_block_1_1956( CONT_PARAMS );
static RTYPE compiled_block_1_1955( CONT_PARAMS );
static RTYPE compiled_start_1_63( CONT_PARAMS );
static RTYPE compiled_block_1_1951( CONT_PARAMS );
static RTYPE compiled_block_1_1947( CONT_PARAMS );
static RTYPE compiled_block_1_1948( CONT_PARAMS );
static RTYPE compiled_block_1_1954( CONT_PARAMS );
static RTYPE compiled_block_1_1953( CONT_PARAMS );
static RTYPE compiled_block_1_1952( CONT_PARAMS );
static RTYPE compiled_block_1_1950( CONT_PARAMS );
static RTYPE compiled_block_1_1949( CONT_PARAMS );
static RTYPE compiled_block_1_1946( CONT_PARAMS );
static RTYPE compiled_block_1_1945( CONT_PARAMS );
static RTYPE compiled_start_1_62( CONT_PARAMS );
static RTYPE compiled_block_1_1940( CONT_PARAMS );
static RTYPE compiled_block_1_1941( CONT_PARAMS );
static RTYPE compiled_block_1_1944( CONT_PARAMS );
static RTYPE compiled_block_1_1943( CONT_PARAMS );
static RTYPE compiled_block_1_1942( CONT_PARAMS );
static RTYPE compiled_block_1_1939( CONT_PARAMS );
static RTYPE compiled_block_1_1938( CONT_PARAMS );
static RTYPE compiled_block_1_1918( CONT_PARAMS );
static RTYPE compiled_block_1_1919( CONT_PARAMS );
static RTYPE compiled_block_1_1937( CONT_PARAMS );
static RTYPE compiled_block_1_1922( CONT_PARAMS );
static RTYPE compiled_block_1_1923( CONT_PARAMS );
static RTYPE compiled_block_1_1936( CONT_PARAMS );
static RTYPE compiled_block_1_1935( CONT_PARAMS );
static RTYPE compiled_block_1_1934( CONT_PARAMS );
static RTYPE compiled_block_1_1933( CONT_PARAMS );
static RTYPE compiled_block_1_1932( CONT_PARAMS );
static RTYPE compiled_block_1_1931( CONT_PARAMS );
static RTYPE compiled_block_1_1930( CONT_PARAMS );
static RTYPE compiled_block_1_1929( CONT_PARAMS );
static RTYPE compiled_block_1_1928( CONT_PARAMS );
static RTYPE compiled_block_1_1927( CONT_PARAMS );
static RTYPE compiled_block_1_1924( CONT_PARAMS );
static RTYPE compiled_block_1_1926( CONT_PARAMS );
static RTYPE compiled_block_1_1925( CONT_PARAMS );
static RTYPE compiled_block_1_1921( CONT_PARAMS );
static RTYPE compiled_block_1_1920( CONT_PARAMS );
static RTYPE compiled_block_1_1917( CONT_PARAMS );
static RTYPE compiled_start_1_61( CONT_PARAMS );
static RTYPE compiled_block_1_1915( CONT_PARAMS );
static RTYPE compiled_block_1_1914( CONT_PARAMS );
static RTYPE compiled_block_1_1913( CONT_PARAMS );
static RTYPE compiled_block_1_1912( CONT_PARAMS );
static RTYPE compiled_block_1_1911( CONT_PARAMS );
static RTYPE compiled_block_1_1910( CONT_PARAMS );
static RTYPE compiled_block_1_1909( CONT_PARAMS );
static RTYPE compiled_block_1_1908( CONT_PARAMS );
static RTYPE compiled_block_1_1907( CONT_PARAMS );
static RTYPE compiled_block_1_1906( CONT_PARAMS );
static RTYPE compiled_block_1_1905( CONT_PARAMS );
static RTYPE compiled_block_1_1904( CONT_PARAMS );
static RTYPE compiled_block_1_1901( CONT_PARAMS );
static RTYPE compiled_block_1_1903( CONT_PARAMS );
static RTYPE compiled_block_1_1902( CONT_PARAMS );
static RTYPE compiled_start_1_60( CONT_PARAMS );
static RTYPE compiled_block_1_1899( CONT_PARAMS );
static RTYPE compiled_block_1_1900( CONT_PARAMS );
static RTYPE compiled_block_1_1897( CONT_PARAMS );
static RTYPE compiled_block_1_1896( CONT_PARAMS );
static RTYPE compiled_block_1_1894( CONT_PARAMS );
static RTYPE compiled_block_1_1895( CONT_PARAMS );
static RTYPE compiled_block_1_1889( CONT_PARAMS );
static RTYPE compiled_block_1_1892( CONT_PARAMS );
static RTYPE compiled_block_1_1891( CONT_PARAMS );
static RTYPE compiled_block_1_1890( CONT_PARAMS );
static RTYPE compiled_block_1_1886( CONT_PARAMS );
static RTYPE compiled_block_1_1888( CONT_PARAMS );
static RTYPE compiled_block_1_1887( CONT_PARAMS );
static RTYPE compiled_temp_1_124( CONT_PARAMS );
static RTYPE compiled_block_1_1885( CONT_PARAMS );
static RTYPE compiled_start_1_59( CONT_PARAMS );
static RTYPE compiled_start_1_58( CONT_PARAMS );
static RTYPE compiled_block_1_1879( CONT_PARAMS );
static RTYPE compiled_block_1_1881( CONT_PARAMS );
static RTYPE compiled_block_1_1882( CONT_PARAMS );
static RTYPE compiled_block_1_1880( CONT_PARAMS );
static RTYPE compiled_block_1_1878( CONT_PARAMS );
static RTYPE compiled_start_1_125( CONT_PARAMS );
static RTYPE compiled_start_1_57( CONT_PARAMS );
static RTYPE compiled_start_1_56( CONT_PARAMS );
static RTYPE compiled_block_1_1873( CONT_PARAMS );
static RTYPE compiled_block_1_1874( CONT_PARAMS );
static RTYPE compiled_start_1_55( CONT_PARAMS );
static RTYPE compiled_block_1_1872( CONT_PARAMS );
static RTYPE compiled_block_1_1871( CONT_PARAMS );
static RTYPE compiled_block_1_1870( CONT_PARAMS );
static RTYPE compiled_block_1_1869( CONT_PARAMS );
static RTYPE compiled_block_1_1868( CONT_PARAMS );
static RTYPE compiled_block_1_1867( CONT_PARAMS );
static RTYPE compiled_block_1_1866( CONT_PARAMS );
static RTYPE compiled_block_1_1865( CONT_PARAMS );
static RTYPE compiled_block_1_1864( CONT_PARAMS );
static RTYPE compiled_start_1_54( CONT_PARAMS );
static RTYPE compiled_block_1_1863( CONT_PARAMS );
static RTYPE compiled_block_1_1862( CONT_PARAMS );
static RTYPE compiled_block_1_1861( CONT_PARAMS );
static RTYPE compiled_block_1_1860( CONT_PARAMS );
static RTYPE compiled_block_1_1859( CONT_PARAMS );
static RTYPE compiled_block_1_1858( CONT_PARAMS );
static RTYPE compiled_block_1_1857( CONT_PARAMS );
static RTYPE compiled_block_1_1856( CONT_PARAMS );
static RTYPE compiled_block_1_1855( CONT_PARAMS );
static RTYPE compiled_start_1_53( CONT_PARAMS );
static RTYPE compiled_start_1_128( CONT_PARAMS );
static RTYPE compiled_start_1_127( CONT_PARAMS );
static RTYPE compiled_start_1_126( CONT_PARAMS );
static RTYPE compiled_start_1_52( CONT_PARAMS );
static RTYPE compiled_block_1_1853( CONT_PARAMS );
static RTYPE compiled_start_1_51( CONT_PARAMS );
static RTYPE compiled_block_1_1851( CONT_PARAMS );
static RTYPE compiled_block_1_1850( CONT_PARAMS );
static RTYPE compiled_block_1_1849( CONT_PARAMS );
static RTYPE compiled_block_1_1848( CONT_PARAMS );
static RTYPE compiled_block_1_1847( CONT_PARAMS );
static RTYPE compiled_block_1_1846( CONT_PARAMS );
static RTYPE compiled_block_1_1845( CONT_PARAMS );
static RTYPE compiled_block_1_1844( CONT_PARAMS );
static RTYPE compiled_block_1_1843( CONT_PARAMS );
static RTYPE compiled_block_1_1842( CONT_PARAMS );
static RTYPE compiled_block_1_1841( CONT_PARAMS );
static RTYPE compiled_block_1_1840( CONT_PARAMS );
static RTYPE compiled_start_1_50( CONT_PARAMS );
static RTYPE compiled_block_1_1839( CONT_PARAMS );
static RTYPE compiled_start_1_49( CONT_PARAMS );
static RTYPE compiled_block_1_1838( CONT_PARAMS );
static RTYPE compiled_start_1_48( CONT_PARAMS );
static RTYPE compiled_block_1_1837( CONT_PARAMS );
static RTYPE compiled_start_1_47( CONT_PARAMS );
static RTYPE compiled_block_1_1836( CONT_PARAMS );
static RTYPE compiled_start_1_46( CONT_PARAMS );
static RTYPE compiled_block_1_1835( CONT_PARAMS );
static RTYPE compiled_start_1_45( CONT_PARAMS );
static RTYPE compiled_block_1_1834( CONT_PARAMS );
static RTYPE compiled_start_1_44( CONT_PARAMS );
static RTYPE compiled_block_1_1833( CONT_PARAMS );
static RTYPE compiled_start_1_43( CONT_PARAMS );
static RTYPE compiled_block_1_1832( CONT_PARAMS );
static RTYPE compiled_start_1_42( CONT_PARAMS );
static RTYPE compiled_block_1_1831( CONT_PARAMS );
static RTYPE compiled_start_1_41( CONT_PARAMS );
static RTYPE compiled_block_1_1830( CONT_PARAMS );
static RTYPE compiled_start_1_40( CONT_PARAMS );
static RTYPE compiled_block_1_1829( CONT_PARAMS );
static RTYPE compiled_start_1_39( CONT_PARAMS );
static RTYPE compiled_block_1_1828( CONT_PARAMS );
static RTYPE compiled_start_1_38( CONT_PARAMS );
static RTYPE compiled_block_1_1827( CONT_PARAMS );
static RTYPE compiled_start_1_37( CONT_PARAMS );
static RTYPE compiled_block_1_1826( CONT_PARAMS );
static RTYPE compiled_start_1_36( CONT_PARAMS );
static RTYPE compiled_block_1_1825( CONT_PARAMS );
static RTYPE compiled_start_1_35( CONT_PARAMS );
static RTYPE compiled_block_1_1824( CONT_PARAMS );
static RTYPE compiled_start_1_34( CONT_PARAMS );
static RTYPE compiled_block_1_1823( CONT_PARAMS );
static RTYPE compiled_start_1_33( CONT_PARAMS );
static RTYPE compiled_block_1_1822( CONT_PARAMS );
static RTYPE compiled_start_1_32( CONT_PARAMS );
static RTYPE compiled_block_1_1821( CONT_PARAMS );
static RTYPE compiled_start_1_31( CONT_PARAMS );
static RTYPE compiled_block_1_1820( CONT_PARAMS );
static RTYPE compiled_start_1_30( CONT_PARAMS );
static RTYPE compiled_block_1_1819( CONT_PARAMS );
static RTYPE compiled_start_1_29( CONT_PARAMS );
static RTYPE compiled_block_1_1818( CONT_PARAMS );
static RTYPE compiled_start_1_28( CONT_PARAMS );
static RTYPE compiled_block_1_1817( CONT_PARAMS );
static RTYPE compiled_start_1_27( CONT_PARAMS );
static RTYPE compiled_block_1_1816( CONT_PARAMS );
static RTYPE compiled_start_1_26( CONT_PARAMS );
static RTYPE compiled_block_1_1815( CONT_PARAMS );
static RTYPE compiled_start_1_25( CONT_PARAMS );
static RTYPE compiled_block_1_1814( CONT_PARAMS );
static RTYPE compiled_start_1_24( CONT_PARAMS );
static RTYPE compiled_block_1_1813( CONT_PARAMS );
static RTYPE compiled_start_1_23( CONT_PARAMS );
static RTYPE compiled_block_1_1812( CONT_PARAMS );
static RTYPE compiled_start_1_22( CONT_PARAMS );
static RTYPE compiled_block_1_1811( CONT_PARAMS );
static RTYPE compiled_start_1_21( CONT_PARAMS );
static RTYPE compiled_block_1_1810( CONT_PARAMS );
static RTYPE compiled_start_1_20( CONT_PARAMS );
static RTYPE compiled_block_1_1809( CONT_PARAMS );
static RTYPE compiled_start_1_19( CONT_PARAMS );
static RTYPE compiled_block_1_1808( CONT_PARAMS );
static RTYPE compiled_start_1_18( CONT_PARAMS );
static RTYPE compiled_block_1_1807( CONT_PARAMS );
static RTYPE compiled_start_1_17( CONT_PARAMS );
static RTYPE compiled_block_1_1806( CONT_PARAMS );
static RTYPE compiled_start_1_16( CONT_PARAMS );
static RTYPE compiled_block_1_1805( CONT_PARAMS );
static RTYPE compiled_start_1_15( CONT_PARAMS );
static RTYPE compiled_block_1_1804( CONT_PARAMS );
static RTYPE compiled_start_1_14( CONT_PARAMS );
static RTYPE compiled_block_1_1803( CONT_PARAMS );
static RTYPE compiled_start_1_13( CONT_PARAMS );
static RTYPE compiled_block_1_1802( CONT_PARAMS );
static RTYPE compiled_start_1_12( CONT_PARAMS );
static RTYPE compiled_block_1_1801( CONT_PARAMS );
static RTYPE compiled_start_1_11( CONT_PARAMS );
static RTYPE compiled_block_1_1800( CONT_PARAMS );
static RTYPE compiled_start_1_10( CONT_PARAMS );
static RTYPE compiled_block_1_1799( CONT_PARAMS );
static RTYPE compiled_start_1_9( CONT_PARAMS );
static RTYPE compiled_block_1_1798( CONT_PARAMS );
static RTYPE compiled_start_1_8( CONT_PARAMS );
static RTYPE compiled_block_1_1797( CONT_PARAMS );
static RTYPE compiled_start_1_7( CONT_PARAMS );
static RTYPE compiled_block_1_1796( CONT_PARAMS );
static RTYPE compiled_start_1_6( CONT_PARAMS );
static RTYPE compiled_block_1_1795( CONT_PARAMS );
static RTYPE compiled_start_1_5( CONT_PARAMS );
static RTYPE compiled_block_1_1793( CONT_PARAMS );
static RTYPE compiled_block_1_1790( CONT_PARAMS );
static RTYPE compiled_block_1_1792( CONT_PARAMS );
static RTYPE compiled_start_1_4( CONT_PARAMS );
static RTYPE compiled_block_1_1787( CONT_PARAMS );
static RTYPE compiled_block_1_1761( CONT_PARAMS );
static RTYPE compiled_block_1_1735( CONT_PARAMS );
static RTYPE compiled_block_1_1717( CONT_PARAMS );
static RTYPE compiled_block_1_1699( CONT_PARAMS );
static RTYPE compiled_block_1_1673( CONT_PARAMS );
static RTYPE compiled_block_1_1652( CONT_PARAMS );
static RTYPE compiled_block_1_1606( CONT_PARAMS );
static RTYPE compiled_block_1_1582( CONT_PARAMS );
static RTYPE compiled_block_1_1542( CONT_PARAMS );
static RTYPE compiled_block_1_1536( CONT_PARAMS );
static RTYPE compiled_block_1_1530( CONT_PARAMS );
static RTYPE compiled_block_1_1524( CONT_PARAMS );
static RTYPE compiled_block_1_1468( CONT_PARAMS );
static RTYPE compiled_block_1_1426( CONT_PARAMS );
static RTYPE compiled_block_1_1404( CONT_PARAMS );
static RTYPE compiled_block_1_1377( CONT_PARAMS );
static RTYPE compiled_block_1_1338( CONT_PARAMS );
static RTYPE compiled_block_1_1328( CONT_PARAMS );
static RTYPE compiled_block_1_1289( CONT_PARAMS );
static RTYPE compiled_block_1_1235( CONT_PARAMS );
static RTYPE compiled_block_1_1210( CONT_PARAMS );
static RTYPE compiled_block_1_1184( CONT_PARAMS );
static RTYPE compiled_block_1_1163( CONT_PARAMS );
static RTYPE compiled_block_1_1142( CONT_PARAMS );
static RTYPE compiled_block_1_1052( CONT_PARAMS );
static RTYPE compiled_block_1_1047( CONT_PARAMS );
static RTYPE compiled_start_1_2( CONT_PARAMS );
static RTYPE compiled_block_1_1784( CONT_PARAMS );
static RTYPE compiled_block_1_1785( CONT_PARAMS );
static RTYPE compiled_block_1_1782( CONT_PARAMS );
static RTYPE compiled_block_1_1762( CONT_PARAMS );
static RTYPE compiled_block_1_1765( CONT_PARAMS );
static RTYPE compiled_block_1_1768( CONT_PARAMS );
static RTYPE compiled_block_1_1778( CONT_PARAMS );
static RTYPE compiled_block_1_1777( CONT_PARAMS );
static RTYPE compiled_block_1_1776( CONT_PARAMS );
static RTYPE compiled_block_1_1775( CONT_PARAMS );
static RTYPE compiled_block_1_1774( CONT_PARAMS );
static RTYPE compiled_block_1_1773( CONT_PARAMS );
static RTYPE compiled_block_1_1772( CONT_PARAMS );
static RTYPE compiled_block_1_1771( CONT_PARAMS );
static RTYPE compiled_block_1_1770( CONT_PARAMS );
static RTYPE compiled_block_1_1769( CONT_PARAMS );
static RTYPE compiled_block_1_1766( CONT_PARAMS );
static RTYPE compiled_start_1_155( CONT_PARAMS );
static RTYPE compiled_block_1_1758( CONT_PARAMS );
static RTYPE compiled_block_1_1759( CONT_PARAMS );
static RTYPE compiled_block_1_1756( CONT_PARAMS );
static RTYPE compiled_block_1_1736( CONT_PARAMS );
static RTYPE compiled_block_1_1739( CONT_PARAMS );
static RTYPE compiled_block_1_1742( CONT_PARAMS );
static RTYPE compiled_block_1_1752( CONT_PARAMS );
static RTYPE compiled_block_1_1751( CONT_PARAMS );
static RTYPE compiled_block_1_1750( CONT_PARAMS );
static RTYPE compiled_block_1_1749( CONT_PARAMS );
static RTYPE compiled_block_1_1748( CONT_PARAMS );
static RTYPE compiled_block_1_1747( CONT_PARAMS );
static RTYPE compiled_block_1_1746( CONT_PARAMS );
static RTYPE compiled_block_1_1745( CONT_PARAMS );
static RTYPE compiled_block_1_1744( CONT_PARAMS );
static RTYPE compiled_block_1_1743( CONT_PARAMS );
static RTYPE compiled_block_1_1740( CONT_PARAMS );
static RTYPE compiled_start_1_154( CONT_PARAMS );
static RTYPE compiled_block_1_1732( CONT_PARAMS );
static RTYPE compiled_block_1_1733( CONT_PARAMS );
static RTYPE compiled_block_1_1730( CONT_PARAMS );
static RTYPE compiled_block_1_1718( CONT_PARAMS );
static RTYPE compiled_block_1_1721( CONT_PARAMS );
static RTYPE compiled_block_1_1724( CONT_PARAMS );
static RTYPE compiled_block_1_1726( CONT_PARAMS );
static RTYPE compiled_block_1_1725( CONT_PARAMS );
static RTYPE compiled_block_1_1722( CONT_PARAMS );
static RTYPE compiled_start_1_153( CONT_PARAMS );
static RTYPE compiled_block_1_1714( CONT_PARAMS );
static RTYPE compiled_block_1_1715( CONT_PARAMS );
static RTYPE compiled_block_1_1712( CONT_PARAMS );
static RTYPE compiled_block_1_1700( CONT_PARAMS );
static RTYPE compiled_block_1_1703( CONT_PARAMS );
static RTYPE compiled_block_1_1706( CONT_PARAMS );
static RTYPE compiled_block_1_1708( CONT_PARAMS );
static RTYPE compiled_block_1_1707( CONT_PARAMS );
static RTYPE compiled_block_1_1704( CONT_PARAMS );
static RTYPE compiled_start_1_152( CONT_PARAMS );
static RTYPE compiled_block_1_1687( CONT_PARAMS );
static RTYPE compiled_block_1_1689( CONT_PARAMS );
static RTYPE compiled_block_1_1691( CONT_PARAMS );
static RTYPE compiled_block_1_1693( CONT_PARAMS );
static RTYPE compiled_block_1_1694( CONT_PARAMS );
static RTYPE compiled_block_1_1674( CONT_PARAMS );
static RTYPE compiled_block_1_1677( CONT_PARAMS );
static RTYPE compiled_block_1_1679( CONT_PARAMS );
static RTYPE compiled_block_1_1681( CONT_PARAMS );
static RTYPE compiled_block_1_1682( CONT_PARAMS );
static RTYPE compiled_start_1_151( CONT_PARAMS );
static RTYPE compiled_block_1_1654( CONT_PARAMS );
static RTYPE compiled_block_1_1656( CONT_PARAMS );
static RTYPE compiled_block_1_1659( CONT_PARAMS );
static RTYPE compiled_block_1_1669( CONT_PARAMS );
static RTYPE compiled_block_1_1668( CONT_PARAMS );
static RTYPE compiled_block_1_1667( CONT_PARAMS );
static RTYPE compiled_block_1_1666( CONT_PARAMS );
static RTYPE compiled_block_1_1665( CONT_PARAMS );
static RTYPE compiled_block_1_1664( CONT_PARAMS );
static RTYPE compiled_block_1_1663( CONT_PARAMS );
static RTYPE compiled_block_1_1662( CONT_PARAMS );
static RTYPE compiled_block_1_1661( CONT_PARAMS );
static RTYPE compiled_block_1_1660( CONT_PARAMS );
static RTYPE compiled_block_1_1657( CONT_PARAMS );
static RTYPE compiled_start_1_150( CONT_PARAMS );
static RTYPE compiled_block_1_1639( CONT_PARAMS );
static RTYPE compiled_block_1_1641( CONT_PARAMS );
static RTYPE compiled_block_1_1643( CONT_PARAMS );
static RTYPE compiled_block_1_1645( CONT_PARAMS );
static RTYPE compiled_block_1_1647( CONT_PARAMS );
static RTYPE compiled_block_1_1646( CONT_PARAMS );
static RTYPE compiled_block_1_1608( CONT_PARAMS );
static RTYPE compiled_block_1_1628( CONT_PARAMS );
static RTYPE compiled_block_1_1630( CONT_PARAMS );
static RTYPE compiled_block_1_1632( CONT_PARAMS );
static RTYPE compiled_block_1_1634( CONT_PARAMS );
static RTYPE compiled_block_1_1633( CONT_PARAMS );
static RTYPE compiled_block_1_1607( CONT_PARAMS );
static RTYPE compiled_block_1_1611( CONT_PARAMS );
static RTYPE compiled_block_1_1613( CONT_PARAMS );
static RTYPE compiled_block_1_1615( CONT_PARAMS );
static RTYPE compiled_block_1_1617( CONT_PARAMS );
static RTYPE compiled_block_1_1619( CONT_PARAMS );
static RTYPE compiled_block_1_1621( CONT_PARAMS );
static RTYPE compiled_block_1_1620( CONT_PARAMS );
static RTYPE compiled_start_1_149( CONT_PARAMS );
static RTYPE compiled_block_1_1584( CONT_PARAMS );
static RTYPE compiled_block_1_1586( CONT_PARAMS );
static RTYPE compiled_block_1_1588( CONT_PARAMS );
static RTYPE compiled_block_1_1590( CONT_PARAMS );
static RTYPE compiled_block_1_1592( CONT_PARAMS );
static RTYPE compiled_block_1_1600( CONT_PARAMS );
static RTYPE compiled_block_1_1599( CONT_PARAMS );
static RTYPE compiled_block_1_1598( CONT_PARAMS );
static RTYPE compiled_block_1_1597( CONT_PARAMS );
static RTYPE compiled_block_1_1596( CONT_PARAMS );
static RTYPE compiled_block_1_1595( CONT_PARAMS );
static RTYPE compiled_block_1_1594( CONT_PARAMS );
static RTYPE compiled_block_1_1593( CONT_PARAMS );
static RTYPE compiled_start_1_148( CONT_PARAMS );
static RTYPE compiled_block_1_1566( CONT_PARAMS );
static RTYPE compiled_block_1_1568( CONT_PARAMS );
static RTYPE compiled_block_1_1570( CONT_PARAMS );
static RTYPE compiled_block_1_1572( CONT_PARAMS );
static RTYPE compiled_block_1_1574( CONT_PARAMS );
static RTYPE compiled_block_1_1576( CONT_PARAMS );
static RTYPE compiled_block_1_1575( CONT_PARAMS );
static RTYPE compiled_block_1_1543( CONT_PARAMS );
static RTYPE compiled_block_1_1546( CONT_PARAMS );
static RTYPE compiled_block_1_1548( CONT_PARAMS );
static RTYPE compiled_block_1_1550( CONT_PARAMS );
static RTYPE compiled_block_1_1552( CONT_PARAMS );
static RTYPE compiled_block_1_1554( CONT_PARAMS );
static RTYPE compiled_block_1_1556( CONT_PARAMS );
static RTYPE compiled_block_1_1558( CONT_PARAMS );
static RTYPE compiled_block_1_1557( CONT_PARAMS );
static RTYPE compiled_start_1_147( CONT_PARAMS );
static RTYPE compiled_block_1_1538( CONT_PARAMS );
static RTYPE compiled_block_1_1540( CONT_PARAMS );
static RTYPE compiled_block_1_1539( CONT_PARAMS );
static RTYPE compiled_start_1_146( CONT_PARAMS );
static RTYPE compiled_block_1_1532( CONT_PARAMS );
static RTYPE compiled_block_1_1534( CONT_PARAMS );
static RTYPE compiled_block_1_1533( CONT_PARAMS );
static RTYPE compiled_start_1_145( CONT_PARAMS );
static RTYPE compiled_block_1_1526( CONT_PARAMS );
static RTYPE compiled_block_1_1528( CONT_PARAMS );
static RTYPE compiled_block_1_1527( CONT_PARAMS );
static RTYPE compiled_start_1_144( CONT_PARAMS );
static RTYPE compiled_block_1_1502( CONT_PARAMS );
static RTYPE compiled_block_1_1504( CONT_PARAMS );
static RTYPE compiled_block_1_1506( CONT_PARAMS );
static RTYPE compiled_block_1_1508( CONT_PARAMS );
static RTYPE compiled_block_1_1510( CONT_PARAMS );
static RTYPE compiled_block_1_1518( CONT_PARAMS );
static RTYPE compiled_block_1_1517( CONT_PARAMS );
static RTYPE compiled_block_1_1516( CONT_PARAMS );
static RTYPE compiled_block_1_1515( CONT_PARAMS );
static RTYPE compiled_block_1_1514( CONT_PARAMS );
static RTYPE compiled_block_1_1513( CONT_PARAMS );
static RTYPE compiled_block_1_1512( CONT_PARAMS );
static RTYPE compiled_block_1_1511( CONT_PARAMS );
static RTYPE compiled_block_1_1469( CONT_PARAMS );
static RTYPE compiled_block_1_1472( CONT_PARAMS );
static RTYPE compiled_block_1_1474( CONT_PARAMS );
static RTYPE compiled_block_1_1476( CONT_PARAMS );
static RTYPE compiled_block_1_1478( CONT_PARAMS );
static RTYPE compiled_block_1_1480( CONT_PARAMS );
static RTYPE compiled_block_1_1482( CONT_PARAMS );
static RTYPE compiled_block_1_1494( CONT_PARAMS );
static RTYPE compiled_block_1_1493( CONT_PARAMS );
static RTYPE compiled_block_1_1492( CONT_PARAMS );
static RTYPE compiled_block_1_1491( CONT_PARAMS );
static RTYPE compiled_block_1_1490( CONT_PARAMS );
static RTYPE compiled_block_1_1489( CONT_PARAMS );
static RTYPE compiled_block_1_1488( CONT_PARAMS );
static RTYPE compiled_block_1_1487( CONT_PARAMS );
static RTYPE compiled_block_1_1486( CONT_PARAMS );
static RTYPE compiled_block_1_1485( CONT_PARAMS );
static RTYPE compiled_block_1_1484( CONT_PARAMS );
static RTYPE compiled_block_1_1483( CONT_PARAMS );
static RTYPE compiled_start_1_143( CONT_PARAMS );
static RTYPE compiled_block_1_1452( CONT_PARAMS );
static RTYPE compiled_block_1_1454( CONT_PARAMS );
static RTYPE compiled_block_1_1456( CONT_PARAMS );
static RTYPE compiled_block_1_1464( CONT_PARAMS );
static RTYPE compiled_block_1_1463( CONT_PARAMS );
static RTYPE compiled_block_1_1462( CONT_PARAMS );
static RTYPE compiled_block_1_1461( CONT_PARAMS );
static RTYPE compiled_block_1_1460( CONT_PARAMS );
static RTYPE compiled_block_1_1459( CONT_PARAMS );
static RTYPE compiled_block_1_1458( CONT_PARAMS );
static RTYPE compiled_block_1_1457( CONT_PARAMS );
static RTYPE compiled_block_1_1427( CONT_PARAMS );
static RTYPE compiled_block_1_1430( CONT_PARAMS );
static RTYPE compiled_block_1_1432( CONT_PARAMS );
static RTYPE compiled_block_1_1434( CONT_PARAMS );
static RTYPE compiled_block_1_1436( CONT_PARAMS );
static RTYPE compiled_block_1_1446( CONT_PARAMS );
static RTYPE compiled_block_1_1445( CONT_PARAMS );
static RTYPE compiled_block_1_1444( CONT_PARAMS );
static RTYPE compiled_block_1_1443( CONT_PARAMS );
static RTYPE compiled_block_1_1442( CONT_PARAMS );
static RTYPE compiled_block_1_1441( CONT_PARAMS );
static RTYPE compiled_block_1_1440( CONT_PARAMS );
static RTYPE compiled_block_1_1439( CONT_PARAMS );
static RTYPE compiled_block_1_1438( CONT_PARAMS );
static RTYPE compiled_block_1_1437( CONT_PARAMS );
static RTYPE compiled_start_1_142( CONT_PARAMS );
static RTYPE compiled_block_1_1416( CONT_PARAMS );
static RTYPE compiled_block_1_1418( CONT_PARAMS );
static RTYPE compiled_block_1_1420( CONT_PARAMS );
static RTYPE compiled_block_1_1422( CONT_PARAMS );
static RTYPE compiled_block_1_1421( CONT_PARAMS );
static RTYPE compiled_block_1_1405( CONT_PARAMS );
static RTYPE compiled_block_1_1408( CONT_PARAMS );
static RTYPE compiled_block_1_1410( CONT_PARAMS );
static RTYPE compiled_block_1_1412( CONT_PARAMS );
static RTYPE compiled_block_1_1411( CONT_PARAMS );
static RTYPE compiled_start_1_141( CONT_PARAMS );
static RTYPE compiled_block_1_1379( CONT_PARAMS );
static RTYPE compiled_block_1_1381( CONT_PARAMS );
static RTYPE compiled_block_1_1383( CONT_PARAMS );
static RTYPE compiled_block_1_1385( CONT_PARAMS );
static RTYPE compiled_block_1_1399( CONT_PARAMS );
static RTYPE compiled_block_1_1398( CONT_PARAMS );
static RTYPE compiled_block_1_1397( CONT_PARAMS );
static RTYPE compiled_block_1_1396( CONT_PARAMS );
static RTYPE compiled_block_1_1395( CONT_PARAMS );
static RTYPE compiled_block_1_1394( CONT_PARAMS );
static RTYPE compiled_block_1_1393( CONT_PARAMS );
static RTYPE compiled_block_1_1392( CONT_PARAMS );
static RTYPE compiled_block_1_1391( CONT_PARAMS );
static RTYPE compiled_block_1_1390( CONT_PARAMS );
static RTYPE compiled_block_1_1389( CONT_PARAMS );
static RTYPE compiled_block_1_1388( CONT_PARAMS );
static RTYPE compiled_block_1_1387( CONT_PARAMS );
static RTYPE compiled_block_1_1386( CONT_PARAMS );
static RTYPE compiled_start_1_140( CONT_PARAMS );
static RTYPE compiled_block_1_1340( CONT_PARAMS );
static RTYPE compiled_block_1_1342( CONT_PARAMS );
static RTYPE compiled_block_1_1344( CONT_PARAMS );
static RTYPE compiled_block_1_1346( CONT_PARAMS );
static RTYPE compiled_block_1_1348( CONT_PARAMS );
static RTYPE compiled_block_1_1350( CONT_PARAMS );
static RTYPE compiled_block_1_1370( CONT_PARAMS );
static RTYPE compiled_block_1_1369( CONT_PARAMS );
static RTYPE compiled_block_1_1368( CONT_PARAMS );
static RTYPE compiled_block_1_1367( CONT_PARAMS );
static RTYPE compiled_block_1_1366( CONT_PARAMS );
static RTYPE compiled_block_1_1365( CONT_PARAMS );
static RTYPE compiled_block_1_1364( CONT_PARAMS );
static RTYPE compiled_block_1_1363( CONT_PARAMS );
static RTYPE compiled_block_1_1362( CONT_PARAMS );
static RTYPE compiled_block_1_1361( CONT_PARAMS );
static RTYPE compiled_block_1_1360( CONT_PARAMS );
static RTYPE compiled_block_1_1359( CONT_PARAMS );
static RTYPE compiled_block_1_1358( CONT_PARAMS );
static RTYPE compiled_block_1_1357( CONT_PARAMS );
static RTYPE compiled_block_1_1356( CONT_PARAMS );
static RTYPE compiled_block_1_1355( CONT_PARAMS );
static RTYPE compiled_block_1_1354( CONT_PARAMS );
static RTYPE compiled_block_1_1353( CONT_PARAMS );
static RTYPE compiled_block_1_1352( CONT_PARAMS );
static RTYPE compiled_block_1_1351( CONT_PARAMS );
static RTYPE compiled_start_1_139( CONT_PARAMS );
static RTYPE compiled_block_1_1330( CONT_PARAMS );
static RTYPE compiled_block_1_1332( CONT_PARAMS );
static RTYPE compiled_block_1_1334( CONT_PARAMS );
static RTYPE compiled_start_1_138( CONT_PARAMS );
static RTYPE compiled_block_1_1306( CONT_PARAMS );
static RTYPE compiled_block_1_1308( CONT_PARAMS );
static RTYPE compiled_block_1_1310( CONT_PARAMS );
static RTYPE compiled_block_1_1312( CONT_PARAMS );
static RTYPE compiled_block_1_1314( CONT_PARAMS );
static RTYPE compiled_block_1_1322( CONT_PARAMS );
static RTYPE compiled_block_1_1321( CONT_PARAMS );
static RTYPE compiled_block_1_1320( CONT_PARAMS );
static RTYPE compiled_block_1_1319( CONT_PARAMS );
static RTYPE compiled_block_1_1318( CONT_PARAMS );
static RTYPE compiled_block_1_1317( CONT_PARAMS );
static RTYPE compiled_block_1_1316( CONT_PARAMS );
static RTYPE compiled_block_1_1315( CONT_PARAMS );
static RTYPE compiled_block_1_1290( CONT_PARAMS );
static RTYPE compiled_block_1_1293( CONT_PARAMS );
static RTYPE compiled_block_1_1295( CONT_PARAMS );
static RTYPE compiled_block_1_1297( CONT_PARAMS );
static RTYPE compiled_block_1_1299( CONT_PARAMS );
static RTYPE compiled_block_1_1300( CONT_PARAMS );
static RTYPE compiled_start_1_137( CONT_PARAMS );
static RTYPE compiled_block_1_1277( CONT_PARAMS );
static RTYPE compiled_block_1_1279( CONT_PARAMS );
static RTYPE compiled_block_1_1281( CONT_PARAMS );
static RTYPE compiled_block_1_1283( CONT_PARAMS );
static RTYPE compiled_block_1_1284( CONT_PARAMS );
static RTYPE compiled_block_1_1237( CONT_PARAMS );
static RTYPE compiled_block_1_1260( CONT_PARAMS );
static RTYPE compiled_block_1_1262( CONT_PARAMS );
static RTYPE compiled_block_1_1264( CONT_PARAMS );
static RTYPE compiled_block_1_1266( CONT_PARAMS );
static RTYPE compiled_block_1_1268( CONT_PARAMS );
static RTYPE compiled_block_1_1270( CONT_PARAMS );
static RTYPE compiled_block_1_1269( CONT_PARAMS );
static RTYPE compiled_block_1_1236( CONT_PARAMS );
static RTYPE compiled_block_1_1240( CONT_PARAMS );
static RTYPE compiled_block_1_1242( CONT_PARAMS );
static RTYPE compiled_block_1_1244( CONT_PARAMS );
static RTYPE compiled_block_1_1246( CONT_PARAMS );
static RTYPE compiled_block_1_1248( CONT_PARAMS );
static RTYPE compiled_block_1_1253( CONT_PARAMS );
static RTYPE compiled_block_1_1252( CONT_PARAMS );
static RTYPE compiled_block_1_1251( CONT_PARAMS );
static RTYPE compiled_block_1_1250( CONT_PARAMS );
static RTYPE compiled_block_1_1249( CONT_PARAMS );
static RTYPE compiled_start_1_136( CONT_PARAMS );
static RTYPE compiled_block_1_1212( CONT_PARAMS );
static RTYPE compiled_block_1_1214( CONT_PARAMS );
static RTYPE compiled_block_1_1232( CONT_PARAMS );
static RTYPE compiled_block_1_1231( CONT_PARAMS );
static RTYPE compiled_block_1_1230( CONT_PARAMS );
static RTYPE compiled_block_1_1229( CONT_PARAMS );
static RTYPE compiled_block_1_1228( CONT_PARAMS );
static RTYPE compiled_block_1_1227( CONT_PARAMS );
static RTYPE compiled_block_1_1226( CONT_PARAMS );
static RTYPE compiled_block_1_1225( CONT_PARAMS );
static RTYPE compiled_block_1_1224( CONT_PARAMS );
static RTYPE compiled_block_1_1223( CONT_PARAMS );
static RTYPE compiled_block_1_1222( CONT_PARAMS );
static RTYPE compiled_block_1_1221( CONT_PARAMS );
static RTYPE compiled_block_1_1220( CONT_PARAMS );
static RTYPE compiled_block_1_1219( CONT_PARAMS );
static RTYPE compiled_block_1_1218( CONT_PARAMS );
static RTYPE compiled_block_1_1217( CONT_PARAMS );
static RTYPE compiled_block_1_1216( CONT_PARAMS );
static RTYPE compiled_block_1_1215( CONT_PARAMS );
static RTYPE compiled_start_1_135( CONT_PARAMS );
static RTYPE compiled_block_1_1198( CONT_PARAMS );
static RTYPE compiled_block_1_1200( CONT_PARAMS );
static RTYPE compiled_block_1_1202( CONT_PARAMS );
static RTYPE compiled_block_1_1204( CONT_PARAMS );
static RTYPE compiled_block_1_1205( CONT_PARAMS );
static RTYPE compiled_block_1_1185( CONT_PARAMS );
static RTYPE compiled_block_1_1188( CONT_PARAMS );
static RTYPE compiled_block_1_1190( CONT_PARAMS );
static RTYPE compiled_block_1_1192( CONT_PARAMS );
static RTYPE compiled_block_1_1193( CONT_PARAMS );
static RTYPE compiled_start_1_134( CONT_PARAMS );
static RTYPE compiled_block_1_1174( CONT_PARAMS );
static RTYPE compiled_block_1_1176( CONT_PARAMS );
static RTYPE compiled_block_1_1178( CONT_PARAMS );
static RTYPE compiled_block_1_1180( CONT_PARAMS );
static RTYPE compiled_block_1_1179( CONT_PARAMS );
static RTYPE compiled_block_1_1164( CONT_PARAMS );
static RTYPE compiled_block_1_1167( CONT_PARAMS );
static RTYPE compiled_block_1_1169( CONT_PARAMS );
static RTYPE compiled_start_1_133( CONT_PARAMS );
static RTYPE compiled_block_1_1153( CONT_PARAMS );
static RTYPE compiled_block_1_1155( CONT_PARAMS );
static RTYPE compiled_block_1_1157( CONT_PARAMS );
static RTYPE compiled_block_1_1159( CONT_PARAMS );
static RTYPE compiled_block_1_1158( CONT_PARAMS );
static RTYPE compiled_block_1_1143( CONT_PARAMS );
static RTYPE compiled_block_1_1146( CONT_PARAMS );
static RTYPE compiled_block_1_1148( CONT_PARAMS );
static RTYPE compiled_start_1_132( CONT_PARAMS );
static RTYPE compiled_block_1_1054( CONT_PARAMS );
static RTYPE compiled_block_1_1056( CONT_PARAMS );
static RTYPE compiled_block_1_1058( CONT_PARAMS );
static RTYPE compiled_start_1_131( CONT_PARAMS );
static RTYPE compiled_block_1_1070( CONT_PARAMS );
static RTYPE compiled_block_1_1133( CONT_PARAMS );
static RTYPE compiled_block_1_1135( CONT_PARAMS );
static RTYPE compiled_block_1_1134( CONT_PARAMS );
static RTYPE compiled_start_1_157( CONT_PARAMS );
static RTYPE compiled_block_1_1115( CONT_PARAMS );
static RTYPE compiled_block_1_1114( CONT_PARAMS );
static RTYPE compiled_block_1_1131( CONT_PARAMS );
static RTYPE compiled_block_1_1130( CONT_PARAMS );
static RTYPE compiled_block_1_1129( CONT_PARAMS );
static RTYPE compiled_block_1_1128( CONT_PARAMS );
static RTYPE compiled_block_1_1126( CONT_PARAMS );
static RTYPE compiled_block_1_1123( CONT_PARAMS );
static RTYPE compiled_block_1_1124( CONT_PARAMS );
static RTYPE compiled_block_1_1072( CONT_PARAMS );
static RTYPE compiled_block_1_1121( CONT_PARAMS );
static RTYPE compiled_block_1_1120( CONT_PARAMS );
static RTYPE compiled_block_1_1119( CONT_PARAMS );
static RTYPE compiled_block_1_1118( CONT_PARAMS );
static RTYPE compiled_block_1_1117( CONT_PARAMS );
static RTYPE compiled_block_1_1116( CONT_PARAMS );
static RTYPE compiled_block_1_1112( CONT_PARAMS );
static RTYPE compiled_block_1_1109( CONT_PARAMS );
static RTYPE compiled_block_1_1110( CONT_PARAMS );
static RTYPE compiled_block_1_1071( CONT_PARAMS );
static RTYPE compiled_block_1_1105( CONT_PARAMS );
static RTYPE compiled_block_1_1108( CONT_PARAMS );
static RTYPE compiled_block_1_1106( CONT_PARAMS );
static RTYPE compiled_block_1_1107( CONT_PARAMS );
static RTYPE compiled_temp_1_160( CONT_PARAMS );
static RTYPE compiled_block_1_1104( CONT_PARAMS );
static RTYPE compiled_block_1_1103( CONT_PARAMS );
static RTYPE compiled_block_1_1102( CONT_PARAMS );
static RTYPE compiled_block_1_1098( CONT_PARAMS );
static RTYPE compiled_block_1_1101( CONT_PARAMS );
static RTYPE compiled_block_1_1099( CONT_PARAMS );
static RTYPE compiled_block_1_1100( CONT_PARAMS );
static RTYPE compiled_temp_1_159( CONT_PARAMS );
static RTYPE compiled_block_1_1097( CONT_PARAMS );
static RTYPE compiled_block_1_1096( CONT_PARAMS );
static RTYPE compiled_block_1_1095( CONT_PARAMS );
static RTYPE compiled_block_1_1094( CONT_PARAMS );
static RTYPE compiled_block_1_1093( CONT_PARAMS );
static RTYPE compiled_block_1_1092( CONT_PARAMS );
static RTYPE compiled_block_1_1091( CONT_PARAMS );
static RTYPE compiled_block_1_1090( CONT_PARAMS );
static RTYPE compiled_block_1_1089( CONT_PARAMS );
static RTYPE compiled_block_1_1088( CONT_PARAMS );
static RTYPE compiled_block_1_1087( CONT_PARAMS );
static RTYPE compiled_block_1_1086( CONT_PARAMS );
static RTYPE compiled_block_1_1085( CONT_PARAMS );
static RTYPE compiled_block_1_1084( CONT_PARAMS );
static RTYPE compiled_block_1_1083( CONT_PARAMS );
static RTYPE compiled_block_1_1082( CONT_PARAMS );
static RTYPE compiled_block_1_1081( CONT_PARAMS );
static RTYPE compiled_block_1_1080( CONT_PARAMS );
static RTYPE compiled_block_1_1079( CONT_PARAMS );
static RTYPE compiled_block_1_1078( CONT_PARAMS );
static RTYPE compiled_block_1_1077( CONT_PARAMS );
static RTYPE compiled_block_1_1076( CONT_PARAMS );
static RTYPE compiled_block_1_1075( CONT_PARAMS );
static RTYPE compiled_block_1_1074( CONT_PARAMS );
static RTYPE compiled_start_1_158( CONT_PARAMS );
static RTYPE compiled_block_1_1060( CONT_PARAMS );
static RTYPE compiled_block_1_1062( CONT_PARAMS );
static RTYPE compiled_block_1_1064( CONT_PARAMS );
static RTYPE compiled_block_1_1066( CONT_PARAMS );
static RTYPE compiled_block_1_1068( CONT_PARAMS );
static RTYPE compiled_start_1_156( CONT_PARAMS );
static RTYPE compiled_block_1_1049( CONT_PARAMS );
static RTYPE compiled_block_1_1050( CONT_PARAMS );
static RTYPE compiled_start_1_130( CONT_PARAMS );
static RTYPE compiled_block_1_1030( CONT_PARAMS );
static RTYPE compiled_block_1_1032( CONT_PARAMS );
static RTYPE compiled_block_1_1034( CONT_PARAMS );
static RTYPE compiled_block_1_1037( CONT_PARAMS );
static RTYPE compiled_block_1_1040( CONT_PARAMS );
static RTYPE compiled_block_1_1041( CONT_PARAMS );
static RTYPE compiled_block_1_1038( CONT_PARAMS );
static RTYPE compiled_block_1_1035( CONT_PARAMS );
static RTYPE compiled_block_1_1002( CONT_PARAMS );
static RTYPE compiled_block_1_1005( CONT_PARAMS );
static RTYPE compiled_block_1_1007( CONT_PARAMS );
static RTYPE compiled_block_1_1009( CONT_PARAMS );
static RTYPE compiled_block_1_1016( CONT_PARAMS );
static RTYPE compiled_block_1_1019( CONT_PARAMS );
static RTYPE compiled_block_1_1021( CONT_PARAMS );
static RTYPE compiled_block_1_1022( CONT_PARAMS );
static RTYPE compiled_block_1_1017( CONT_PARAMS );
static RTYPE compiled_block_1_1011( CONT_PARAMS );
static RTYPE compiled_block_1_1012( CONT_PARAMS );
static RTYPE compiled_block_1_1014( CONT_PARAMS );
static RTYPE compiled_block_1_1013( CONT_PARAMS );
static RTYPE compiled_block_1_1010( CONT_PARAMS );
static RTYPE compiled_start_1_129( CONT_PARAMS );
static RTYPE compiled_start_1_1( CONT_PARAMS );

static RTYPE compiled_start_1_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 2 ); /*  test-read-eval-string~1ay%kV~30673 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 3 ); /*  test-match-name~1ay%kV~30672 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 4 ); /*  %test-as-specifier~1ay%kV~30645 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 5 ); /*  %test-match-any~1ay%kV~30631 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 6 ); /*  %test-match-all~1ay%kV~30617 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 7 ); /*  %test-match-nth~1ay%kV~30589 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 8 ); /*  test-apply~1ay%kV~30572 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 9 ); /*  %test-approximimate=~1ay%kV~30314 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 10 ); /*  test-runner-test-name~1ay%kV~30289 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 11 ); /*  %test-on-test-end~1ay%kV~30288 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 12 ); /*  %test-on-test-begin~1ay%kV~30287 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 13 ); /*  %test-source-line2~1ay%kV~30286 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 14 ); /*  %test-report-result~1ay%kV~30264 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 15 ); /*  test-passed?~1ay%kV~30263 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 16 ); /*  test-result-kind~1ay%kV~30262 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 17 ); /*  test-result-remove~1ay%kV~30261 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 18 ); /*  test-result-clear~1ay%kV~30260 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 19 ); /*  test-result-set!~1ay%kV~30259 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 20 ); /*  %test-write-result1~1ay%kV~30258 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 21 ); /*  test-on-test-end-simple~1ay%kV~30257 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 22 ); /*  test-on-test-begin-simple~1ay%kV~30223 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 23 ); /*  %test-end~1ay%kV~30154 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 24 ); /*  %test-format-line~1ay%kV~30153 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 25 ); /*  test-on-final-simple~1ay%kV~30152 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 26 ); /*  %test-final-report-simple~1ay%kV~30151 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 27 ); /*  %test-final-report1~1ay%kV~30150 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 28 ); /*  test-on-bad-end-name-simple~1ay%kV~30149 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 29 ); /*  test-on-bad-count-simple~1ay%kV~30148 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 30 ); /*  %test-on-bad-count-write~1ay%kV~30147 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 31 ); /*  test-on-group-end-simple~1ay%kV~30146 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 32 ); /*  test-on-group-begin-simple~1ay%kV~30145 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 33 ); /*  %test-begin~1ay%kV~30115 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 34 ); /*  %test-should-execute~1ay%kV~30114 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 35 ); /*  %test-any-specifier-matches~1ay%kV~30113 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 36 ); /*  test-runner-create~1ay%kV~30112 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 37 ); /*  %test-specificier-matches~1ay%kV~30111 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 38 ); /*  test-runner-get~1ay%kV~30110 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 39 ); /*  %test-runner-factory~1ay%kV~30088 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 40 ); /*  %test-runner-current~1ay%kV~30066 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 41 ); /*  test-runner-simple~1ay%kV~30063 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 42 ); /*  test-log-to-file~1ay%kV~30062 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 43 ); /*  test-runner-null~1ay%kV~30061 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 44 ); /*  %test-null-callback~1ay%kV~30060 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 45 ); /*  test-runner-group-path~1ay%kV~30059 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 46 ); /*  test-runner-reset~1ay%kV~30058 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 47 ); /*  test-runner-aux-value!~1ay%kV~30057 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 48 ); /*  test-result-alist!~1ay%kV~30056 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 49 ); /*  %test-runner-count-list!~1ay%kV~30055 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 50 ); /*  %test-runner-total-count!~1ay%kV~30054 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 51 ); /*  test-runner-on-bad-end-name!~1ay%kV~30053 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 52 ); /*  test-runner-on-bad-count!~1ay%kV~30052 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 53 ); /*  test-runner-on-final!~1ay%kV~30051 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 54 ); /*  test-runner-on-group-end!~1ay%kV~30050 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 55 ); /*  test-runner-on-group-begin!~1ay%kV~30049 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 56 ); /*  test-runner-on-test-end!~1ay%kV~30048 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 57 ); /*  test-runner-on-test-begin!~1ay%kV~30047 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 58 ); /*  test-runner-group-stack!~1ay%kV~30046 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 59 ); /*  %test-runner-fail-save!~1ay%kV~30045 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 60 ); /*  %test-runner-skip-save!~1ay%kV~30044 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 61 ); /*  %test-runner-run-list!~1ay%kV~30043 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 62 ); /*  %test-runner-fail-list!~1ay%kV~30042 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 63 ); /*  %test-runner-skip-list!~1ay%kV~30041 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 64 ); /*  test-runner-skip-count!~1ay%kV~30040 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 65 ); /*  test-runner-xfail-count!~1ay%kV~30039 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 66 ); /*  test-runner-xpass-count!~1ay%kV~30038 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 67 ); /*  test-runner-fail-count!~1ay%kV~30037 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 68 ); /*  test-runner-pass-count!~1ay%kV~30036 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 69 ); /*  test-runner-aux-value~1ay%kV~30035 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 70 ); /*  test-result-alist~1ay%kV~30034 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 71 ); /*  %test-runner-count-list~1ay%kV~30033 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 72 ); /*  %test-runner-total-count~1ay%kV~30032 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 73 ); /*  test-runner-on-bad-end-name~1ay%kV~30031 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 74 ); /*  test-runner-on-bad-count~1ay%kV~30030 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 75 ); /*  test-runner-on-final~1ay%kV~30029 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 76 ); /*  test-runner-on-group-end~1ay%kV~30028 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 77 ); /*  test-runner-on-group-begin~1ay%kV~30027 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 78 ); /*  test-runner-on-test-end~1ay%kV~30026 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 79 ); /*  test-runner-on-test-begin~1ay%kV~30025 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 80 ); /*  test-runner-group-stack~1ay%kV~30024 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 81 ); /*  %test-runner-fail-save~1ay%kV~30023 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 82 ); /*  %test-runner-skip-save~1ay%kV~30022 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 83 ); /*  %test-runner-run-list~1ay%kV~30021 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 84 ); /*  %test-runner-fail-list~1ay%kV~30020 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 85 ); /*  %test-runner-skip-list~1ay%kV~30019 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 86 ); /*  test-runner-skip-count~1ay%kV~30018 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 87 ); /*  test-runner-xfail-count~1ay%kV~30017 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 88 ); /*  test-runner-xpass-count~1ay%kV~30016 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 89 ); /*  test-runner-fail-count~1ay%kV~30015 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 90 ); /*  test-runner-pass-count~1ay%kV~30014 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 91 ); /*  %test-runner-alloc~1ay%kV~30013 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 92 ); /*  test-runner?~1ay%kV~30012 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 93 ); /*  %test-runner-cookie~1ay%kV~29978 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 94 ); /*  ignored2~1ay%kV~29975 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 95 ); /*  ignored1~1ay%kV~29959 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 96 ); /*  eq~1ay%kV~29923 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 97 ); /*  reverse!~1ay%kV~29922 */
  twobit_lambda( compiled_start_1_1, 99, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_2, 101, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_3, 103, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 104 );
  twobit_setreg( 1 );
  twobit_const( 105 );
  twobit_setreg( 3 );
  twobit_const( 106 );
  twobit_setreg( 4 );
  twobit_const( 107 );
  twobit_setreg( 5 );
  twobit_const( 108 );
  twobit_setreg( 8 );
  twobit_global( 109 ); /* ex:make-library */
  twobit_setrtn( 2299, compiled_block_1_2299 );
  twobit_invoke( 8 );
  twobit_label( 2299, compiled_block_1_2299 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 110 ); /* ex:register-library! */
  twobit_setrtn( 2300, compiled_block_1_2300 );
  twobit_invoke( 1 );
  twobit_label( 2300, compiled_block_1_2300 );
  twobit_load( 0, 0 );
  twobit_global( 111 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* ex:uncompress */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_129, 2, 0 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1047, compiled_block_1_1047 );
  twobit_invoke( 2 );
  twobit_label( 1047, compiled_block_1_1047 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_130, 6, 0 );
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1052, compiled_block_1_1052 );
  twobit_invoke( 2 );
  twobit_label( 1052, compiled_block_1_1052 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_131, 9, 0 );
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1142, compiled_block_1_1142 );
  twobit_invoke( 2 );
  twobit_label( 1142, compiled_block_1_1142 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_132, 12, 0 );
  twobit_setreg( 2 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1163, compiled_block_1_1163 );
  twobit_invoke( 2 );
  twobit_label( 1163, compiled_block_1_1163 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_133, 15, 0 );
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1184, compiled_block_1_1184 );
  twobit_invoke( 2 );
  twobit_label( 1184, compiled_block_1_1184 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_134, 18, 0 );
  twobit_setreg( 2 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1210, compiled_block_1_1210 );
  twobit_invoke( 2 );
  twobit_label( 1210, compiled_block_1_1210 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_135, 21, 0 );
  twobit_setreg( 2 );
  twobit_const( 22 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1235, compiled_block_1_1235 );
  twobit_invoke( 2 );
  twobit_label( 1235, compiled_block_1_1235 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_136, 24, 0 );
  twobit_setreg( 2 );
  twobit_const( 25 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1289, compiled_block_1_1289 );
  twobit_invoke( 2 );
  twobit_label( 1289, compiled_block_1_1289 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_137, 27, 0 );
  twobit_setreg( 2 );
  twobit_const( 28 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1328, compiled_block_1_1328 );
  twobit_invoke( 2 );
  twobit_label( 1328, compiled_block_1_1328 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_138, 30, 0 );
  twobit_setreg( 2 );
  twobit_const( 31 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1338, compiled_block_1_1338 );
  twobit_invoke( 2 );
  twobit_label( 1338, compiled_block_1_1338 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_139, 33, 0 );
  twobit_setreg( 2 );
  twobit_const( 34 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1377, compiled_block_1_1377 );
  twobit_invoke( 2 );
  twobit_label( 1377, compiled_block_1_1377 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_140, 36, 0 );
  twobit_setreg( 2 );
  twobit_const( 37 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1404, compiled_block_1_1404 );
  twobit_invoke( 2 );
  twobit_label( 1404, compiled_block_1_1404 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_141, 39, 0 );
  twobit_setreg( 2 );
  twobit_const( 40 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1426, compiled_block_1_1426 );
  twobit_invoke( 2 );
  twobit_label( 1426, compiled_block_1_1426 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_142, 42, 0 );
  twobit_setreg( 2 );
  twobit_const( 43 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1468, compiled_block_1_1468 );
  twobit_invoke( 2 );
  twobit_label( 1468, compiled_block_1_1468 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_143, 45, 0 );
  twobit_setreg( 2 );
  twobit_const( 46 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1524, compiled_block_1_1524 );
  twobit_invoke( 2 );
  twobit_label( 1524, compiled_block_1_1524 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_144, 48, 0 );
  twobit_setreg( 2 );
  twobit_const( 49 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1530, compiled_block_1_1530 );
  twobit_invoke( 2 );
  twobit_label( 1530, compiled_block_1_1530 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_145, 51, 0 );
  twobit_setreg( 2 );
  twobit_const( 52 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1536, compiled_block_1_1536 );
  twobit_invoke( 2 );
  twobit_label( 1536, compiled_block_1_1536 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_146, 54, 0 );
  twobit_setreg( 2 );
  twobit_const( 55 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1542, compiled_block_1_1542 );
  twobit_invoke( 2 );
  twobit_label( 1542, compiled_block_1_1542 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_147, 57, 0 );
  twobit_setreg( 2 );
  twobit_const( 58 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1582, compiled_block_1_1582 );
  twobit_invoke( 2 );
  twobit_label( 1582, compiled_block_1_1582 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_148, 60, 0 );
  twobit_setreg( 2 );
  twobit_const( 61 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1606, compiled_block_1_1606 );
  twobit_invoke( 2 );
  twobit_label( 1606, compiled_block_1_1606 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_149, 63, 0 );
  twobit_setreg( 2 );
  twobit_const( 64 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1652, compiled_block_1_1652 );
  twobit_invoke( 2 );
  twobit_label( 1652, compiled_block_1_1652 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_150, 66, 0 );
  twobit_setreg( 2 );
  twobit_const( 67 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1673, compiled_block_1_1673 );
  twobit_invoke( 2 );
  twobit_label( 1673, compiled_block_1_1673 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_151, 69, 0 );
  twobit_setreg( 2 );
  twobit_const( 70 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1699, compiled_block_1_1699 );
  twobit_invoke( 2 );
  twobit_label( 1699, compiled_block_1_1699 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_152, 72, 0 );
  twobit_setreg( 2 );
  twobit_const( 73 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1717, compiled_block_1_1717 );
  twobit_invoke( 2 );
  twobit_label( 1717, compiled_block_1_1717 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_153, 75, 0 );
  twobit_setreg( 2 );
  twobit_const( 76 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1735, compiled_block_1_1735 );
  twobit_invoke( 2 );
  twobit_label( 1735, compiled_block_1_1735 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_154, 78, 0 );
  twobit_setreg( 2 );
  twobit_const( 79 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1761, compiled_block_1_1761 );
  twobit_invoke( 2 );
  twobit_label( 1761, compiled_block_1_1761 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_155, 81, 0 );
  twobit_setreg( 2 );
  twobit_const( 82 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1787, compiled_block_1_1787 );
  twobit_invoke( 2 );
  twobit_label( 1787, compiled_block_1_1787 );
  twobit_load( 0, 0 );
  twobit_global( 83 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_129( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1005, compiled_block_1_1005 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1007, compiled_block_1_1007 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1009, compiled_block_1_1009 ); /* internal:branchf-pair? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 3, 2 );
  twobit_store( 4, 3 );
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /* ex:identifier? */
  twobit_setrtn( 1010, compiled_block_1_1010 );
  twobit_invoke( 1 );
  twobit_label( 1010, compiled_block_1_1010 );
  twobit_load( 0, 0 );
  twobit_branchf( 1012, compiled_block_1_1012 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1013, compiled_block_1_1013 );
  twobit_invoke( 5 );
  twobit_label( 1013, compiled_block_1_1013 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* ex:free-identifier=? */
  twobit_setrtn( 1014, compiled_block_1_1014 );
  twobit_invoke( 2 );
  twobit_label( 1014, compiled_block_1_1014 );
  twobit_load( 0, 0 );
  twobit_skip( 1011, compiled_block_1_1011 );
  twobit_label( 1012, compiled_block_1_1012 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1011, compiled_block_1_1011 );
  twobit_branchf( 1016, compiled_block_1_1016 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 7 ); /* list? */
  twobit_setrtn( 1017, compiled_block_1_1017 );
  twobit_invoke( 1 );
  twobit_label( 1017, compiled_block_1_1017 );
  twobit_load( 0, 0 );
  twobit_branchf( 1019, compiled_block_1_1019 );
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1021, compiled_block_1_1021 ); /* internal:branchf-null? */
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1022, compiled_block_1_1022 );
  twobit_invoke( 5 );
  twobit_label( 1022, compiled_block_1_1022 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1021, compiled_block_1_1021 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1019, compiled_block_1_1019 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1016, compiled_block_1_1016 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1009, compiled_block_1_1009 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1007, compiled_block_1_1007 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1005, compiled_block_1_1005 );
  twobit_label( 1002, compiled_block_1_1002 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1030, compiled_block_1_1030 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1032, compiled_block_1_1032 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1034, compiled_block_1_1034 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 4, 1 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_global( 7 ); /* list? */
  twobit_setrtn( 1035, compiled_block_1_1035 );
  twobit_invoke( 1 );
  twobit_label( 1035, compiled_block_1_1035 );
  twobit_load( 0, 0 );
  twobit_branchf( 1037, compiled_block_1_1037 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 7 ); /* list? */
  twobit_setrtn( 1038, compiled_block_1_1038 );
  twobit_invoke( 1 );
  twobit_label( 1038, compiled_block_1_1038 );
  twobit_load( 0, 0 );
  twobit_branchf( 1040, compiled_block_1_1040 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1041, compiled_block_1_1041 );
  twobit_invoke( 5 );
  twobit_label( 1041, compiled_block_1_1041 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1040, compiled_block_1_1040 );
  twobit_load( 1, 2 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1037, compiled_block_1_1037 );
  twobit_load( 1, 2 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1034, compiled_block_1_1034 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1032, compiled_block_1_1032 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1030, compiled_block_1_1030 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_130( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1049, compiled_block_1_1049 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1050, compiled_block_1_1050 );
  twobit_invoke( 5 );
  twobit_label( 1050, compiled_block_1_1050 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1049, compiled_block_1_1049 );
  twobit_global( 5 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_131( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1054, compiled_block_1_1054 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1056, compiled_block_1_1056 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1058, compiled_block_1_1058 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_lambda( compiled_start_1_156, 2, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_157, 4, 3 );
  twobit_setreg( 3 );
  twobit_movereg( 4, 1 );
  twobit_load( 2, 2 );
  twobit_global( 5 ); /* ex:map-while */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1058, compiled_block_1_1058 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1056, compiled_block_1_1056 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1054, compiled_block_1_1054 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_156( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1060, compiled_block_1_1060 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1062, compiled_block_1_1062 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1064, compiled_block_1_1064 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1066, compiled_block_1_1066 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1068, compiled_block_1_1068 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 31 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_return();
  twobit_label( 1068, compiled_block_1_1068 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1066, compiled_block_1_1066 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1064, compiled_block_1_1064 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1062, compiled_block_1_1062 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1060, compiled_block_1_1060 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_157( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1070, compiled_block_1_1070 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_158, 2, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1134, compiled_block_1_1134 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_skip( 1133, compiled_block_1_1133 );
  twobit_label( 1134, compiled_block_1_1134 );
  twobit_movereg( 1, 3 );
  twobit_global( 4 ); /* map */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* list */
  twobit_setreg( 2 );
  twobit_global( 6 ); /* apply */
  twobit_setrtn( 1135, compiled_block_1_1135 );
  twobit_invoke( 3 );
  twobit_label( 1135, compiled_block_1_1135 );
  twobit_load( 0, 0 );
  twobit_label( 1133, compiled_block_1_1133 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1070, compiled_block_1_1070 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_158( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 12 );
  twobit_store( 0, 0 );
  twobit_store( 2, 10 );
  twobit_store( 3, 9 );
  twobit_store( 4, 11 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1074, compiled_block_1_1074 );
  twobit_invoke( 5 );
  twobit_label( 1074, compiled_block_1_1074 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1075, compiled_block_1_1075 );
  twobit_invoke( 5 );
  twobit_label( 1075, compiled_block_1_1075 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1076, compiled_block_1_1076 );
  twobit_invoke( 5 );
  twobit_label( 1076, compiled_block_1_1076 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_lexical( 1, 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1077, compiled_block_1_1077 );
  twobit_invoke( 5 );
  twobit_label( 1077, compiled_block_1_1077 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1078, compiled_block_1_1078 );
  twobit_invoke( 5 );
  twobit_label( 1078, compiled_block_1_1078 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1079, compiled_block_1_1079 );
  twobit_invoke( 5 );
  twobit_label( 1079, compiled_block_1_1079 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1080, compiled_block_1_1080 );
  twobit_invoke( 5 );
  twobit_label( 1080, compiled_block_1_1080 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1081, compiled_block_1_1081 );
  twobit_invoke( 5 );
  twobit_label( 1081, compiled_block_1_1081 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1082, compiled_block_1_1082 );
  twobit_invoke( 5 );
  twobit_label( 1082, compiled_block_1_1082 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1083, compiled_block_1_1083 );
  twobit_invoke( 5 );
  twobit_label( 1083, compiled_block_1_1083 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1084, compiled_block_1_1084 );
  twobit_invoke( 5 );
  twobit_label( 1084, compiled_block_1_1084 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1085, compiled_block_1_1085 );
  twobit_invoke( 5 );
  twobit_label( 1085, compiled_block_1_1085 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1086, compiled_block_1_1086 );
  twobit_invoke( 5 );
  twobit_label( 1086, compiled_block_1_1086 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1087, compiled_block_1_1087 );
  twobit_invoke( 5 );
  twobit_label( 1087, compiled_block_1_1087 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_lexical( 1, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1088, compiled_block_1_1088 );
  twobit_invoke( 5 );
  twobit_label( 1088, compiled_block_1_1088 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1089, compiled_block_1_1089 );
  twobit_invoke( 5 );
  twobit_label( 1089, compiled_block_1_1089 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(23) ); /* 23 */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 8 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1090, compiled_block_1_1090 );
  twobit_invoke( 5 );
  twobit_label( 1090, compiled_block_1_1090 );
  twobit_load( 0, 0 );
  twobit_load( 3, 8 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 17 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1091, compiled_block_1_1091 );
  twobit_invoke( 5 );
  twobit_label( 1091, compiled_block_1_1091 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1092, compiled_block_1_1092 );
  twobit_invoke( 5 );
  twobit_label( 1092, compiled_block_1_1092 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1093, compiled_block_1_1093 );
  twobit_invoke( 5 );
  twobit_label( 1093, compiled_block_1_1093 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1094, compiled_block_1_1094 );
  twobit_invoke( 5 );
  twobit_label( 1094, compiled_block_1_1094 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1095, compiled_block_1_1095 );
  twobit_invoke( 5 );
  twobit_label( 1095, compiled_block_1_1095 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 9 );
  twobit_global( 18 ); /* length */
  twobit_setrtn( 1096, compiled_block_1_1096 );
  twobit_invoke( 1 );
  twobit_label( 1096, compiled_block_1_1096 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 10 );
  twobit_global( 18 ); /* length */
  twobit_setrtn( 1097, compiled_block_1_1097 );
  twobit_invoke( 1 );
  twobit_label( 1097, compiled_block_1_1097 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_branchf_623( 4, 159, compiled_temp_1_159, 1099, compiled_block_1_1099 ); /* internal:branchf-= */
  twobit_load( 1, 9 );
  twobit_load( 2, 10 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_setrtn( 1100, compiled_block_1_1100 );
  twobit_branch( 1072, compiled_block_1_1072 );
  twobit_label( 1100, compiled_block_1_1100 );
  twobit_load( 0, 0 );
  twobit_skip( 1098, compiled_block_1_1098 );
  twobit_label( 1099, compiled_block_1_1099 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_const( 20 );
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_global( 22 ); /* ex:syntax-violation */
  twobit_setrtn( 1101, compiled_block_1_1101 );
  twobit_invoke( 4 );
  twobit_label( 1101, compiled_block_1_1101 );
  twobit_load( 0, 0 );
  twobit_label( 1098, compiled_block_1_1098 );
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1102, compiled_block_1_1102 );
  twobit_invoke( 5 );
  twobit_label( 1102, compiled_block_1_1102 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_load( 1, 11 );
  twobit_global( 18 ); /* length */
  twobit_setrtn( 1103, compiled_block_1_1103 );
  twobit_invoke( 1 );
  twobit_label( 1103, compiled_block_1_1103 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 10 );
  twobit_global( 18 ); /* length */
  twobit_setrtn( 1104, compiled_block_1_1104 );
  twobit_invoke( 1 );
  twobit_label( 1104, compiled_block_1_1104 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_branchf_623( 4, 160, compiled_temp_1_160, 1106, compiled_block_1_1106 ); /* internal:branchf-= */
  twobit_load( 1, 11 );
  twobit_load( 2, 10 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_setrtn( 1107, compiled_block_1_1107 );
  twobit_branch( 1071, compiled_block_1_1071 );
  twobit_label( 1107, compiled_block_1_1107 );
  twobit_load( 0, 0 );
  twobit_skip( 1105, compiled_block_1_1105 );
  twobit_label( 1106, compiled_block_1_1106 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_const( 20 );
  twobit_setreg( 2 );
  twobit_const( 23 );
  twobit_setreg( 3 );
  twobit_global( 22 ); /* ex:syntax-violation */
  twobit_setrtn( 1108, compiled_block_1_1108 );
  twobit_invoke( 4 );
  twobit_label( 1108, compiled_block_1_1108 );
  twobit_load( 0, 0 );
  twobit_label( 1105, compiled_block_1_1105 );
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 12 );
  twobit_return();
  twobit_label( 1071, compiled_block_1_1071 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1110, compiled_block_1_1110 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1109, compiled_block_1_1109 );
  twobit_label( 1110, compiled_block_1_1110 );
  twobit_reg( 2 );
  twobit_op1_10(); /* null? */
  twobit_label( 1109, compiled_block_1_1109 );
  twobit_branchf( 1112, compiled_block_1_1112 );
  twobit_movereg( 3, 1 );
  twobit_global( 24 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1112, compiled_block_1_1112 );
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 3, 8 );
  twobit_reg_op1_check_652(reg(1),1114,compiled_block_1_1114); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_reg_op1_check_652(reg(2),1115,compiled_block_1_1115); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 3 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 5 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1116, compiled_block_1_1116 );
  twobit_invoke( 5 );
  twobit_label( 1116, compiled_block_1_1116 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1117, compiled_block_1_1117 );
  twobit_invoke( 5 );
  twobit_label( 1117, compiled_block_1_1117 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 25 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1118, compiled_block_1_1118 );
  twobit_invoke( 5 );
  twobit_label( 1118, compiled_block_1_1118 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 17 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1119, compiled_block_1_1119 );
  twobit_invoke( 5 );
  twobit_label( 1119, compiled_block_1_1119 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1120, compiled_block_1_1120 );
  twobit_invoke( 5 );
  twobit_label( 1120, compiled_block_1_1120 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 25 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1121, compiled_block_1_1121 );
  twobit_invoke( 5 );
  twobit_label( 1121, compiled_block_1_1121 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_load( 1, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 8 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_pop( 8 );
  twobit_branch( 1071, compiled_block_1_1071 );
  twobit_label( 1072, compiled_block_1_1072 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1124, compiled_block_1_1124 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1123, compiled_block_1_1123 );
  twobit_label( 1124, compiled_block_1_1124 );
  twobit_reg( 2 );
  twobit_op1_10(); /* null? */
  twobit_label( 1123, compiled_block_1_1123 );
  twobit_branchf( 1126, compiled_block_1_1126 );
  twobit_movereg( 3, 1 );
  twobit_global( 24 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1126, compiled_block_1_1126 );
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 3, 7 );
  twobit_reg_op1_check_652(reg(1),1114,compiled_block_1_1114); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_reg_op1_check_652(reg(2),1115,compiled_block_1_1115); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 3 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1128, compiled_block_1_1128 );
  twobit_invoke( 5 );
  twobit_label( 1128, compiled_block_1_1128 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1129, compiled_block_1_1129 );
  twobit_invoke( 5 );
  twobit_label( 1129, compiled_block_1_1129 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1130, compiled_block_1_1130 );
  twobit_invoke( 5 );
  twobit_label( 1130, compiled_block_1_1130 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1131, compiled_block_1_1131 );
  twobit_invoke( 5 );
  twobit_label( 1131, compiled_block_1_1131 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_load( 1, 4 );
  twobit_load( 3, 2 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 7 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_pop( 7 );
  twobit_branch( 1072, compiled_block_1_1072 );
  twobit_label( 1114, compiled_block_1_1114 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_label( 1115, compiled_block_1_1115 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_132( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1146, compiled_block_1_1146 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1148, compiled_block_1_1148 ); /* internal:branchf-null? */
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_invoke( 5 );
  twobit_label( 1148, compiled_block_1_1148 );
  twobit_branch( 1143, compiled_block_1_1143 );
  twobit_label( 1146, compiled_block_1_1146 );
  twobit_label( 1143, compiled_block_1_1143 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1153, compiled_block_1_1153 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1155, compiled_block_1_1155 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1157, compiled_block_1_1157 ); /* internal:branchf-null? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1158, compiled_block_1_1158 );
  twobit_invoke( 5 );
  twobit_label( 1158, compiled_block_1_1158 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1159, compiled_block_1_1159 );
  twobit_invoke( 5 );
  twobit_label( 1159, compiled_block_1_1159 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1157, compiled_block_1_1157 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1155, compiled_block_1_1155 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1153, compiled_block_1_1153 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_133( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1167, compiled_block_1_1167 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1169, compiled_block_1_1169 ); /* internal:branchf-null? */
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_invoke( 5 );
  twobit_label( 1169, compiled_block_1_1169 );
  twobit_branch( 1164, compiled_block_1_1164 );
  twobit_label( 1167, compiled_block_1_1167 );
  twobit_label( 1164, compiled_block_1_1164 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1174, compiled_block_1_1174 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1176, compiled_block_1_1176 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1178, compiled_block_1_1178 ); /* internal:branchf-null? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1179, compiled_block_1_1179 );
  twobit_invoke( 5 );
  twobit_label( 1179, compiled_block_1_1179 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1180, compiled_block_1_1180 );
  twobit_invoke( 5 );
  twobit_label( 1180, compiled_block_1_1180 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1178, compiled_block_1_1178 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1176, compiled_block_1_1176 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1174, compiled_block_1_1174 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_134( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1188, compiled_block_1_1188 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1190, compiled_block_1_1190 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1192, compiled_block_1_1192 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1193, compiled_block_1_1193 );
  twobit_invoke( 5 );
  twobit_label( 1193, compiled_block_1_1193 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1192, compiled_block_1_1192 );
  twobit_branch( 1185, compiled_block_1_1185 );
  twobit_label( 1190, compiled_block_1_1190 );
  twobit_branch( 1185, compiled_block_1_1185 );
  twobit_label( 1188, compiled_block_1_1188 );
  twobit_label( 1185, compiled_block_1_1185 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1198, compiled_block_1_1198 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1200, compiled_block_1_1200 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1202, compiled_block_1_1202 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1204, compiled_block_1_1204 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 5 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1205, compiled_block_1_1205 );
  twobit_invoke( 5 );
  twobit_label( 1205, compiled_block_1_1205 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1204, compiled_block_1_1204 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1202, compiled_block_1_1202 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1200, compiled_block_1_1200 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1198, compiled_block_1_1198 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_135( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1212, compiled_block_1_1212 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1214, compiled_block_1_1214 ); /* internal:branchf-pair? */
  twobit_save( 10 );
  twobit_store( 0, 0 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1215, compiled_block_1_1215 );
  twobit_invoke( 5 );
  twobit_label( 1215, compiled_block_1_1215 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1216, compiled_block_1_1216 );
  twobit_invoke( 5 );
  twobit_label( 1216, compiled_block_1_1216 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1217, compiled_block_1_1217 );
  twobit_invoke( 5 );
  twobit_label( 1217, compiled_block_1_1217 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1218, compiled_block_1_1218 );
  twobit_invoke( 5 );
  twobit_label( 1218, compiled_block_1_1218 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1219, compiled_block_1_1219 );
  twobit_invoke( 5 );
  twobit_label( 1219, compiled_block_1_1219 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1220, compiled_block_1_1220 );
  twobit_invoke( 5 );
  twobit_label( 1220, compiled_block_1_1220 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1221, compiled_block_1_1221 );
  twobit_invoke( 5 );
  twobit_label( 1221, compiled_block_1_1221 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1222, compiled_block_1_1222 );
  twobit_invoke( 5 );
  twobit_label( 1222, compiled_block_1_1222 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1223, compiled_block_1_1223 );
  twobit_invoke( 5 );
  twobit_label( 1223, compiled_block_1_1223 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1224, compiled_block_1_1224 );
  twobit_invoke( 5 );
  twobit_label( 1224, compiled_block_1_1224 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1225, compiled_block_1_1225 );
  twobit_invoke( 5 );
  twobit_label( 1225, compiled_block_1_1225 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1226, compiled_block_1_1226 );
  twobit_invoke( 5 );
  twobit_label( 1226, compiled_block_1_1226 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1227, compiled_block_1_1227 );
  twobit_invoke( 5 );
  twobit_label( 1227, compiled_block_1_1227 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1228, compiled_block_1_1228 );
  twobit_invoke( 5 );
  twobit_label( 1228, compiled_block_1_1228 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 7 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1229, compiled_block_1_1229 );
  twobit_invoke( 5 );
  twobit_label( 1229, compiled_block_1_1229 );
  twobit_load( 0, 0 );
  twobit_load( 3, 7 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 3, 8 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 8 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1230, compiled_block_1_1230 );
  twobit_invoke( 5 );
  twobit_label( 1230, compiled_block_1_1230 );
  twobit_load( 0, 0 );
  twobit_load( 3, 8 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1231, compiled_block_1_1231 );
  twobit_invoke( 5 );
  twobit_label( 1231, compiled_block_1_1231 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 17 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1232, compiled_block_1_1232 );
  twobit_invoke( 5 );
  twobit_label( 1232, compiled_block_1_1232 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 10 );
  twobit_return();
  twobit_label( 1214, compiled_block_1_1214 );
  twobit_global( 18 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1212, compiled_block_1_1212 );
  twobit_global( 18 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_136( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1240, compiled_block_1_1240 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1242, compiled_block_1_1242 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1244, compiled_block_1_1244 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1246, compiled_block_1_1246 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1248, compiled_block_1_1248 ); /* internal:branchf-null? */
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 3, 6 );
  twobit_store( 31, 3 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1249, compiled_block_1_1249 );
  twobit_invoke( 5 );
  twobit_label( 1249, compiled_block_1_1249 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1250, compiled_block_1_1250 );
  twobit_invoke( 5 );
  twobit_label( 1250, compiled_block_1_1250 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1251, compiled_block_1_1251 );
  twobit_invoke( 5 );
  twobit_label( 1251, compiled_block_1_1251 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1252, compiled_block_1_1252 );
  twobit_invoke( 5 );
  twobit_label( 1252, compiled_block_1_1252 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1253, compiled_block_1_1253 );
  twobit_invoke( 5 );
  twobit_label( 1253, compiled_block_1_1253 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1248, compiled_block_1_1248 );
  twobit_branch( 1237, compiled_block_1_1237 );
  twobit_label( 1246, compiled_block_1_1246 );
  twobit_branch( 1237, compiled_block_1_1237 );
  twobit_label( 1244, compiled_block_1_1244 );
  twobit_branch( 1237, compiled_block_1_1237 );
  twobit_label( 1242, compiled_block_1_1242 );
  twobit_branch( 1237, compiled_block_1_1237 );
  twobit_label( 1240, compiled_block_1_1240 );
  twobit_branch( 1237, compiled_block_1_1237 );
  twobit_label( 1236, compiled_block_1_1236 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1260, compiled_block_1_1260 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1262, compiled_block_1_1262 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1264, compiled_block_1_1264 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1266, compiled_block_1_1266 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1268, compiled_block_1_1268 ); /* internal:branchf-pair? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 2, 4 );
  twobit_store( 3, 5 );
  twobit_store( 31, 3 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1269, compiled_block_1_1269 );
  twobit_invoke( 5 );
  twobit_label( 1269, compiled_block_1_1269 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 3, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 3 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_stack( 4 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 4 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1270, compiled_block_1_1270 );
  twobit_invoke( 5 );
  twobit_label( 1270, compiled_block_1_1270 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1268, compiled_block_1_1268 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1266, compiled_block_1_1266 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1264, compiled_block_1_1264 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1262, compiled_block_1_1262 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1260, compiled_block_1_1260 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1237, compiled_block_1_1237 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1277, compiled_block_1_1277 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1279, compiled_block_1_1279 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1281, compiled_block_1_1281 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1283, compiled_block_1_1283 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1284, compiled_block_1_1284 );
  twobit_invoke( 5 );
  twobit_label( 1284, compiled_block_1_1284 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1283, compiled_block_1_1283 );
  twobit_branch( 1236, compiled_block_1_1236 );
  twobit_label( 1281, compiled_block_1_1281 );
  twobit_branch( 1236, compiled_block_1_1236 );
  twobit_label( 1279, compiled_block_1_1279 );
  twobit_branch( 1236, compiled_block_1_1236 );
  twobit_label( 1277, compiled_block_1_1277 );
  twobit_branch( 1236, compiled_block_1_1236 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_137( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1293, compiled_block_1_1293 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1295, compiled_block_1_1295 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1297, compiled_block_1_1297 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1299, compiled_block_1_1299 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1300, compiled_block_1_1300 );
  twobit_invoke( 5 );
  twobit_label( 1300, compiled_block_1_1300 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1299, compiled_block_1_1299 );
  twobit_branch( 1290, compiled_block_1_1290 );
  twobit_label( 1297, compiled_block_1_1297 );
  twobit_branch( 1290, compiled_block_1_1290 );
  twobit_label( 1295, compiled_block_1_1295 );
  twobit_branch( 1290, compiled_block_1_1290 );
  twobit_label( 1293, compiled_block_1_1293 );
  twobit_label( 1290, compiled_block_1_1290 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1306, compiled_block_1_1306 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1308, compiled_block_1_1308 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1310, compiled_block_1_1310 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1312, compiled_block_1_1312 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1314, compiled_block_1_1314 ); /* internal:branchf-null? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 3, 1 );
  twobit_store( 31, 5 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1315, compiled_block_1_1315 );
  twobit_invoke( 5 );
  twobit_label( 1315, compiled_block_1_1315 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1316, compiled_block_1_1316 );
  twobit_invoke( 5 );
  twobit_label( 1316, compiled_block_1_1316 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1317, compiled_block_1_1317 );
  twobit_invoke( 5 );
  twobit_label( 1317, compiled_block_1_1317 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1318, compiled_block_1_1318 );
  twobit_invoke( 5 );
  twobit_label( 1318, compiled_block_1_1318 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1319, compiled_block_1_1319 );
  twobit_invoke( 5 );
  twobit_label( 1319, compiled_block_1_1319 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1320, compiled_block_1_1320 );
  twobit_invoke( 5 );
  twobit_label( 1320, compiled_block_1_1320 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1321, compiled_block_1_1321 );
  twobit_invoke( 5 );
  twobit_label( 1321, compiled_block_1_1321 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1322, compiled_block_1_1322 );
  twobit_invoke( 5 );
  twobit_label( 1322, compiled_block_1_1322 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1314, compiled_block_1_1314 );
  twobit_global( 12 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1312, compiled_block_1_1312 );
  twobit_global( 12 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1310, compiled_block_1_1310 );
  twobit_global( 12 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1308, compiled_block_1_1308 );
  twobit_global( 12 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1306, compiled_block_1_1306 );
  twobit_global( 12 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_138( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1330, compiled_block_1_1330 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1332, compiled_block_1_1332 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1334, compiled_block_1_1334 ); /* internal:branchf-null? */
  twobit_reg( 3 );
  twobit_return();
  twobit_label( 1334, compiled_block_1_1334 );
  twobit_global( 1 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1332, compiled_block_1_1332 );
  twobit_global( 1 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1330, compiled_block_1_1330 );
  twobit_global( 1 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_139( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1340, compiled_block_1_1340 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1342, compiled_block_1_1342 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1344, compiled_block_1_1344 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1346, compiled_block_1_1346 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1348, compiled_block_1_1348 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1350, compiled_block_1_1350 ); /* internal:branchf-null? */
  twobit_save( 13 );
  twobit_store( 0, 0 );
  twobit_store( 2, 5 );
  twobit_store( 3, 1 );
  twobit_store( 30, 4 );
  twobit_store( 31, 3 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1351, compiled_block_1_1351 );
  twobit_invoke( 5 );
  twobit_label( 1351, compiled_block_1_1351 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 13 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1352, compiled_block_1_1352 );
  twobit_invoke( 5 );
  twobit_label( 1352, compiled_block_1_1352 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1353, compiled_block_1_1353 );
  twobit_invoke( 5 );
  twobit_label( 1353, compiled_block_1_1353 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1354, compiled_block_1_1354 );
  twobit_invoke( 5 );
  twobit_label( 1354, compiled_block_1_1354 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1355, compiled_block_1_1355 );
  twobit_invoke( 5 );
  twobit_label( 1355, compiled_block_1_1355 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1356, compiled_block_1_1356 );
  twobit_invoke( 5 );
  twobit_label( 1356, compiled_block_1_1356 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1357, compiled_block_1_1357 );
  twobit_invoke( 5 );
  twobit_label( 1357, compiled_block_1_1357 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1358, compiled_block_1_1358 );
  twobit_invoke( 5 );
  twobit_label( 1358, compiled_block_1_1358 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1359, compiled_block_1_1359 );
  twobit_invoke( 5 );
  twobit_label( 1359, compiled_block_1_1359 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1360, compiled_block_1_1360 );
  twobit_invoke( 5 );
  twobit_label( 1360, compiled_block_1_1360 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1361, compiled_block_1_1361 );
  twobit_invoke( 5 );
  twobit_label( 1361, compiled_block_1_1361 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1362, compiled_block_1_1362 );
  twobit_invoke( 5 );
  twobit_label( 1362, compiled_block_1_1362 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1363, compiled_block_1_1363 );
  twobit_invoke( 5 );
  twobit_label( 1363, compiled_block_1_1363 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1364, compiled_block_1_1364 );
  twobit_invoke( 5 );
  twobit_label( 1364, compiled_block_1_1364 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1365, compiled_block_1_1365 );
  twobit_invoke( 5 );
  twobit_label( 1365, compiled_block_1_1365 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1366, compiled_block_1_1366 );
  twobit_invoke( 5 );
  twobit_label( 1366, compiled_block_1_1366 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1367, compiled_block_1_1367 );
  twobit_invoke( 5 );
  twobit_label( 1367, compiled_block_1_1367 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1368, compiled_block_1_1368 );
  twobit_invoke( 5 );
  twobit_label( 1368, compiled_block_1_1368 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1369, compiled_block_1_1369 );
  twobit_invoke( 5 );
  twobit_label( 1369, compiled_block_1_1369 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1370, compiled_block_1_1370 );
  twobit_invoke( 5 );
  twobit_label( 1370, compiled_block_1_1370 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 13 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 13 );
  twobit_return();
  twobit_label( 1350, compiled_block_1_1350 );
  twobit_global( 16 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1348, compiled_block_1_1348 );
  twobit_global( 16 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1346, compiled_block_1_1346 );
  twobit_global( 16 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1344, compiled_block_1_1344 );
  twobit_global( 16 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1342, compiled_block_1_1342 );
  twobit_global( 16 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1340, compiled_block_1_1340 );
  twobit_global( 16 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_140( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1379, compiled_block_1_1379 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1381, compiled_block_1_1381 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1383, compiled_block_1_1383 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1385, compiled_block_1_1385 ); /* internal:branchf-null? */
  twobit_save( 9 );
  twobit_store( 0, 0 );
  twobit_store( 2, 3 );
  twobit_store( 3, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1386, compiled_block_1_1386 );
  twobit_invoke( 5 );
  twobit_label( 1386, compiled_block_1_1386 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1387, compiled_block_1_1387 );
  twobit_invoke( 5 );
  twobit_label( 1387, compiled_block_1_1387 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1388, compiled_block_1_1388 );
  twobit_invoke( 5 );
  twobit_label( 1388, compiled_block_1_1388 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1389, compiled_block_1_1389 );
  twobit_invoke( 5 );
  twobit_label( 1389, compiled_block_1_1389 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1390, compiled_block_1_1390 );
  twobit_invoke( 5 );
  twobit_label( 1390, compiled_block_1_1390 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1391, compiled_block_1_1391 );
  twobit_invoke( 5 );
  twobit_label( 1391, compiled_block_1_1391 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1392, compiled_block_1_1392 );
  twobit_invoke( 5 );
  twobit_label( 1392, compiled_block_1_1392 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1393, compiled_block_1_1393 );
  twobit_invoke( 5 );
  twobit_label( 1393, compiled_block_1_1393 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1394, compiled_block_1_1394 );
  twobit_invoke( 5 );
  twobit_label( 1394, compiled_block_1_1394 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1395, compiled_block_1_1395 );
  twobit_invoke( 5 );
  twobit_label( 1395, compiled_block_1_1395 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1396, compiled_block_1_1396 );
  twobit_invoke( 5 );
  twobit_label( 1396, compiled_block_1_1396 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1397, compiled_block_1_1397 );
  twobit_invoke( 5 );
  twobit_label( 1397, compiled_block_1_1397 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1398, compiled_block_1_1398 );
  twobit_invoke( 5 );
  twobit_label( 1398, compiled_block_1_1398 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1399, compiled_block_1_1399 );
  twobit_invoke( 5 );
  twobit_label( 1399, compiled_block_1_1399 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 9 );
  twobit_return();
  twobit_label( 1385, compiled_block_1_1385 );
  twobit_global( 14 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1383, compiled_block_1_1383 );
  twobit_global( 14 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1381, compiled_block_1_1381 );
  twobit_global( 14 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1379, compiled_block_1_1379 );
  twobit_global( 14 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_141( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1408, compiled_block_1_1408 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1410, compiled_block_1_1410 ); /* internal:branchf-null? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1411, compiled_block_1_1411 );
  twobit_invoke( 5 );
  twobit_label( 1411, compiled_block_1_1411 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1412, compiled_block_1_1412 );
  twobit_invoke( 5 );
  twobit_label( 1412, compiled_block_1_1412 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1410, compiled_block_1_1410 );
  twobit_branch( 1405, compiled_block_1_1405 );
  twobit_label( 1408, compiled_block_1_1408 );
  twobit_label( 1405, compiled_block_1_1405 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1416, compiled_block_1_1416 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1418, compiled_block_1_1418 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1420, compiled_block_1_1420 ); /* internal:branchf-null? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 3, 2 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1421, compiled_block_1_1421 );
  twobit_invoke( 5 );
  twobit_label( 1421, compiled_block_1_1421 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1422, compiled_block_1_1422 );
  twobit_invoke( 5 );
  twobit_label( 1422, compiled_block_1_1422 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1420, compiled_block_1_1420 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1418, compiled_block_1_1418 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1416, compiled_block_1_1416 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_142( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1430, compiled_block_1_1430 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1432, compiled_block_1_1432 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1434, compiled_block_1_1434 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1436, compiled_block_1_1436 ); /* internal:branchf-null? */
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 2, 5 );
  twobit_store( 3, 2 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1437, compiled_block_1_1437 );
  twobit_invoke( 5 );
  twobit_label( 1437, compiled_block_1_1437 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1438, compiled_block_1_1438 );
  twobit_invoke( 5 );
  twobit_label( 1438, compiled_block_1_1438 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1439, compiled_block_1_1439 );
  twobit_invoke( 5 );
  twobit_label( 1439, compiled_block_1_1439 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1440, compiled_block_1_1440 );
  twobit_invoke( 5 );
  twobit_label( 1440, compiled_block_1_1440 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1441, compiled_block_1_1441 );
  twobit_invoke( 5 );
  twobit_label( 1441, compiled_block_1_1441 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1442, compiled_block_1_1442 );
  twobit_invoke( 5 );
  twobit_label( 1442, compiled_block_1_1442 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1443, compiled_block_1_1443 );
  twobit_invoke( 5 );
  twobit_label( 1443, compiled_block_1_1443 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1444, compiled_block_1_1444 );
  twobit_invoke( 5 );
  twobit_label( 1444, compiled_block_1_1444 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1445, compiled_block_1_1445 );
  twobit_invoke( 5 );
  twobit_label( 1445, compiled_block_1_1445 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1446, compiled_block_1_1446 );
  twobit_invoke( 5 );
  twobit_label( 1446, compiled_block_1_1446 );
  twobit_load( 0, 0 );
  twobit_load( 3, 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1436, compiled_block_1_1436 );
  twobit_branch( 1427, compiled_block_1_1427 );
  twobit_label( 1434, compiled_block_1_1434 );
  twobit_branch( 1427, compiled_block_1_1427 );
  twobit_label( 1432, compiled_block_1_1432 );
  twobit_branch( 1427, compiled_block_1_1427 );
  twobit_label( 1430, compiled_block_1_1430 );
  twobit_label( 1427, compiled_block_1_1427 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1452, compiled_block_1_1452 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1454, compiled_block_1_1454 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1456, compiled_block_1_1456 ); /* internal:branchf-null? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 3, 4 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1457, compiled_block_1_1457 );
  twobit_invoke( 5 );
  twobit_label( 1457, compiled_block_1_1457 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1458, compiled_block_1_1458 );
  twobit_invoke( 5 );
  twobit_label( 1458, compiled_block_1_1458 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1459, compiled_block_1_1459 );
  twobit_invoke( 5 );
  twobit_label( 1459, compiled_block_1_1459 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1460, compiled_block_1_1460 );
  twobit_invoke( 5 );
  twobit_label( 1460, compiled_block_1_1460 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1461, compiled_block_1_1461 );
  twobit_invoke( 5 );
  twobit_label( 1461, compiled_block_1_1461 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1462, compiled_block_1_1462 );
  twobit_invoke( 5 );
  twobit_label( 1462, compiled_block_1_1462 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1463, compiled_block_1_1463 );
  twobit_invoke( 5 );
  twobit_label( 1463, compiled_block_1_1463 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1464, compiled_block_1_1464 );
  twobit_invoke( 5 );
  twobit_label( 1464, compiled_block_1_1464 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1456, compiled_block_1_1456 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1454, compiled_block_1_1454 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1452, compiled_block_1_1452 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_143( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1472, compiled_block_1_1472 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1474, compiled_block_1_1474 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1476, compiled_block_1_1476 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1478, compiled_block_1_1478 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1480, compiled_block_1_1480 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1482, compiled_block_1_1482 ); /* internal:branchf-null? */
  twobit_save( 11 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 3, 9 );
  twobit_store( 30, 7 );
  twobit_store( 31, 8 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1483, compiled_block_1_1483 );
  twobit_invoke( 5 );
  twobit_label( 1483, compiled_block_1_1483 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1484, compiled_block_1_1484 );
  twobit_invoke( 5 );
  twobit_label( 1484, compiled_block_1_1484 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1485, compiled_block_1_1485 );
  twobit_invoke( 5 );
  twobit_label( 1485, compiled_block_1_1485 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1486, compiled_block_1_1486 );
  twobit_invoke( 5 );
  twobit_label( 1486, compiled_block_1_1486 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1487, compiled_block_1_1487 );
  twobit_invoke( 5 );
  twobit_label( 1487, compiled_block_1_1487 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1488, compiled_block_1_1488 );
  twobit_invoke( 5 );
  twobit_label( 1488, compiled_block_1_1488 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1489, compiled_block_1_1489 );
  twobit_invoke( 5 );
  twobit_label( 1489, compiled_block_1_1489 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1490, compiled_block_1_1490 );
  twobit_invoke( 5 );
  twobit_label( 1490, compiled_block_1_1490 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1491, compiled_block_1_1491 );
  twobit_invoke( 5 );
  twobit_label( 1491, compiled_block_1_1491 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1492, compiled_block_1_1492 );
  twobit_invoke( 5 );
  twobit_label( 1492, compiled_block_1_1492 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1493, compiled_block_1_1493 );
  twobit_invoke( 5 );
  twobit_label( 1493, compiled_block_1_1493 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 7 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 8 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 9 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 9 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1494, compiled_block_1_1494 );
  twobit_invoke( 5 );
  twobit_label( 1494, compiled_block_1_1494 );
  twobit_load( 0, 0 );
  twobit_load( 3, 9 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 11 );
  twobit_return();
  twobit_label( 1482, compiled_block_1_1482 );
  twobit_branch( 1469, compiled_block_1_1469 );
  twobit_label( 1480, compiled_block_1_1480 );
  twobit_branch( 1469, compiled_block_1_1469 );
  twobit_label( 1478, compiled_block_1_1478 );
  twobit_branch( 1469, compiled_block_1_1469 );
  twobit_label( 1476, compiled_block_1_1476 );
  twobit_branch( 1469, compiled_block_1_1469 );
  twobit_label( 1474, compiled_block_1_1474 );
  twobit_branch( 1469, compiled_block_1_1469 );
  twobit_label( 1472, compiled_block_1_1472 );
  twobit_label( 1469, compiled_block_1_1469 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1502, compiled_block_1_1502 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1504, compiled_block_1_1504 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1506, compiled_block_1_1506 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1508, compiled_block_1_1508 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1510, compiled_block_1_1510 ); /* internal:branchf-null? */
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 2, 5 );
  twobit_store( 3, 6 );
  twobit_store( 31, 4 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1511, compiled_block_1_1511 );
  twobit_invoke( 5 );
  twobit_label( 1511, compiled_block_1_1511 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1512, compiled_block_1_1512 );
  twobit_invoke( 5 );
  twobit_label( 1512, compiled_block_1_1512 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1513, compiled_block_1_1513 );
  twobit_invoke( 5 );
  twobit_label( 1513, compiled_block_1_1513 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1514, compiled_block_1_1514 );
  twobit_invoke( 5 );
  twobit_label( 1514, compiled_block_1_1514 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1515, compiled_block_1_1515 );
  twobit_invoke( 5 );
  twobit_label( 1515, compiled_block_1_1515 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1516, compiled_block_1_1516 );
  twobit_invoke( 5 );
  twobit_label( 1516, compiled_block_1_1516 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1517, compiled_block_1_1517 );
  twobit_invoke( 5 );
  twobit_label( 1517, compiled_block_1_1517 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1518, compiled_block_1_1518 );
  twobit_invoke( 5 );
  twobit_label( 1518, compiled_block_1_1518 );
  twobit_load( 0, 0 );
  twobit_load( 3, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 1510, compiled_block_1_1510 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1508, compiled_block_1_1508 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1506, compiled_block_1_1506 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1504, compiled_block_1_1504 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1502, compiled_block_1_1502 );
  twobit_global( 15 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_144( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1526, compiled_block_1_1526 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1527, compiled_block_1_1527 );
  twobit_invoke( 5 );
  twobit_label( 1527, compiled_block_1_1527 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1528, compiled_block_1_1528 );
  twobit_invoke( 5 );
  twobit_label( 1528, compiled_block_1_1528 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1526, compiled_block_1_1526 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_145( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1532, compiled_block_1_1532 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1533, compiled_block_1_1533 );
  twobit_invoke( 5 );
  twobit_label( 1533, compiled_block_1_1533 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1534, compiled_block_1_1534 );
  twobit_invoke( 5 );
  twobit_label( 1534, compiled_block_1_1534 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1532, compiled_block_1_1532 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_146( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1538, compiled_block_1_1538 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1539, compiled_block_1_1539 );
  twobit_invoke( 5 );
  twobit_label( 1539, compiled_block_1_1539 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1540, compiled_block_1_1540 );
  twobit_invoke( 5 );
  twobit_label( 1540, compiled_block_1_1540 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1538, compiled_block_1_1538 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_147( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1546, compiled_block_1_1546 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1548, compiled_block_1_1548 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1550, compiled_block_1_1550 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1552, compiled_block_1_1552 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1554, compiled_block_1_1554 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1556, compiled_block_1_1556 ); /* internal:branchf-null? */
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_store( 30, 4 );
  twobit_store( 31, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1557, compiled_block_1_1557 );
  twobit_invoke( 5 );
  twobit_label( 1557, compiled_block_1_1557 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 4 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 4 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1558, compiled_block_1_1558 );
  twobit_invoke( 5 );
  twobit_label( 1558, compiled_block_1_1558 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1556, compiled_block_1_1556 );
  twobit_branch( 1543, compiled_block_1_1543 );
  twobit_label( 1554, compiled_block_1_1554 );
  twobit_branch( 1543, compiled_block_1_1543 );
  twobit_label( 1552, compiled_block_1_1552 );
  twobit_branch( 1543, compiled_block_1_1543 );
  twobit_label( 1550, compiled_block_1_1550 );
  twobit_branch( 1543, compiled_block_1_1543 );
  twobit_label( 1548, compiled_block_1_1548 );
  twobit_branch( 1543, compiled_block_1_1543 );
  twobit_label( 1546, compiled_block_1_1546 );
  twobit_label( 1543, compiled_block_1_1543 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1566, compiled_block_1_1566 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1568, compiled_block_1_1568 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1570, compiled_block_1_1570 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1572, compiled_block_1_1572 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1574, compiled_block_1_1574 ); /* internal:branchf-null? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_store( 31, 3 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1575, compiled_block_1_1575 );
  twobit_invoke( 5 );
  twobit_label( 1575, compiled_block_1_1575 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 3 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1576, compiled_block_1_1576 );
  twobit_invoke( 5 );
  twobit_label( 1576, compiled_block_1_1576 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1574, compiled_block_1_1574 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1572, compiled_block_1_1572 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1570, compiled_block_1_1570 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1568, compiled_block_1_1568 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1566, compiled_block_1_1566 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_148( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1584, compiled_block_1_1584 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1586, compiled_block_1_1586 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1588, compiled_block_1_1588 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1590, compiled_block_1_1590 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1592, compiled_block_1_1592 ); /* internal:branchf-null? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1593, compiled_block_1_1593 );
  twobit_invoke( 5 );
  twobit_label( 1593, compiled_block_1_1593 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 1 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1594, compiled_block_1_1594 );
  twobit_invoke( 5 );
  twobit_label( 1594, compiled_block_1_1594 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1595, compiled_block_1_1595 );
  twobit_invoke( 5 );
  twobit_label( 1595, compiled_block_1_1595 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1596, compiled_block_1_1596 );
  twobit_invoke( 5 );
  twobit_label( 1596, compiled_block_1_1596 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1597, compiled_block_1_1597 );
  twobit_invoke( 5 );
  twobit_label( 1597, compiled_block_1_1597 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1598, compiled_block_1_1598 );
  twobit_invoke( 5 );
  twobit_label( 1598, compiled_block_1_1598 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1599, compiled_block_1_1599 );
  twobit_invoke( 5 );
  twobit_label( 1599, compiled_block_1_1599 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1600, compiled_block_1_1600 );
  twobit_invoke( 5 );
  twobit_label( 1600, compiled_block_1_1600 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1592, compiled_block_1_1592 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1590, compiled_block_1_1590 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1588, compiled_block_1_1588 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1586, compiled_block_1_1586 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1584, compiled_block_1_1584 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_149( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1611, compiled_block_1_1611 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1613, compiled_block_1_1613 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1615, compiled_block_1_1615 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1617, compiled_block_1_1617 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1619, compiled_block_1_1619 ); /* internal:branchf-null? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_store( 31, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1620, compiled_block_1_1620 );
  twobit_invoke( 5 );
  twobit_label( 1620, compiled_block_1_1620 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1621, compiled_block_1_1621 );
  twobit_invoke( 5 );
  twobit_label( 1621, compiled_block_1_1621 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1619, compiled_block_1_1619 );
  twobit_branch( 1608, compiled_block_1_1608 );
  twobit_label( 1617, compiled_block_1_1617 );
  twobit_branch( 1608, compiled_block_1_1608 );
  twobit_label( 1615, compiled_block_1_1615 );
  twobit_branch( 1608, compiled_block_1_1608 );
  twobit_label( 1613, compiled_block_1_1613 );
  twobit_branch( 1608, compiled_block_1_1608 );
  twobit_label( 1611, compiled_block_1_1611 );
  twobit_branch( 1608, compiled_block_1_1608 );
  twobit_label( 1607, compiled_block_1_1607 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1628, compiled_block_1_1628 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1630, compiled_block_1_1630 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1632, compiled_block_1_1632 ); /* internal:branchf-null? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1633, compiled_block_1_1633 );
  twobit_invoke( 5 );
  twobit_label( 1633, compiled_block_1_1633 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1634, compiled_block_1_1634 );
  twobit_invoke( 5 );
  twobit_label( 1634, compiled_block_1_1634 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1632, compiled_block_1_1632 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1630, compiled_block_1_1630 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1628, compiled_block_1_1628 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1608, compiled_block_1_1608 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1639, compiled_block_1_1639 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1641, compiled_block_1_1641 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1643, compiled_block_1_1643 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1645, compiled_block_1_1645 ); /* internal:branchf-null? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1646, compiled_block_1_1646 );
  twobit_invoke( 5 );
  twobit_label( 1646, compiled_block_1_1646 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1647, compiled_block_1_1647 );
  twobit_invoke( 5 );
  twobit_label( 1647, compiled_block_1_1647 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1645, compiled_block_1_1645 );
  twobit_branch( 1607, compiled_block_1_1607 );
  twobit_label( 1643, compiled_block_1_1643 );
  twobit_branch( 1607, compiled_block_1_1607 );
  twobit_label( 1641, compiled_block_1_1641 );
  twobit_branch( 1607, compiled_block_1_1607 );
  twobit_label( 1639, compiled_block_1_1639 );
  twobit_branch( 1607, compiled_block_1_1607 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_150( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1654, compiled_block_1_1654 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1656, compiled_block_1_1656 ); /* internal:branchf-pair? */
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 8 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1657, compiled_block_1_1657 );
  twobit_invoke( 1 );
  twobit_label( 1657, compiled_block_1_1657 );
  twobit_load( 0, 0 );
  twobit_branchf( 1659, compiled_block_1_1659 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1660, compiled_block_1_1660 );
  twobit_invoke( 5 );
  twobit_label( 1660, compiled_block_1_1660 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1661, compiled_block_1_1661 );
  twobit_invoke( 5 );
  twobit_label( 1661, compiled_block_1_1661 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1662, compiled_block_1_1662 );
  twobit_invoke( 5 );
  twobit_label( 1662, compiled_block_1_1662 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1663, compiled_block_1_1663 );
  twobit_invoke( 5 );
  twobit_label( 1663, compiled_block_1_1663 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1664, compiled_block_1_1664 );
  twobit_invoke( 5 );
  twobit_label( 1664, compiled_block_1_1664 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1665, compiled_block_1_1665 );
  twobit_invoke( 5 );
  twobit_label( 1665, compiled_block_1_1665 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 3, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1666, compiled_block_1_1666 );
  twobit_invoke( 5 );
  twobit_label( 1666, compiled_block_1_1666 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1667, compiled_block_1_1667 );
  twobit_invoke( 5 );
  twobit_label( 1667, compiled_block_1_1667 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1668, compiled_block_1_1668 );
  twobit_invoke( 5 );
  twobit_label( 1668, compiled_block_1_1668 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1669, compiled_block_1_1669 );
  twobit_invoke( 5 );
  twobit_label( 1669, compiled_block_1_1669 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 1659, compiled_block_1_1659 );
  twobit_load( 1, 8 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 1656, compiled_block_1_1656 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1654, compiled_block_1_1654 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_151( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1677, compiled_block_1_1677 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1679, compiled_block_1_1679 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1681, compiled_block_1_1681 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1682, compiled_block_1_1682 );
  twobit_invoke( 5 );
  twobit_label( 1682, compiled_block_1_1682 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1681, compiled_block_1_1681 );
  twobit_branch( 1674, compiled_block_1_1674 );
  twobit_label( 1679, compiled_block_1_1679 );
  twobit_branch( 1674, compiled_block_1_1674 );
  twobit_label( 1677, compiled_block_1_1677 );
  twobit_label( 1674, compiled_block_1_1674 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1687, compiled_block_1_1687 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1689, compiled_block_1_1689 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1691, compiled_block_1_1691 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1693, compiled_block_1_1693 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1694, compiled_block_1_1694 );
  twobit_invoke( 5 );
  twobit_label( 1694, compiled_block_1_1694 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1693, compiled_block_1_1693 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1691, compiled_block_1_1691 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1689, compiled_block_1_1689 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1687, compiled_block_1_1687 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_152( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1703, compiled_block_1_1703 ); /* internal:branchf-pair? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1704, compiled_block_1_1704 );
  twobit_invoke( 1 );
  twobit_label( 1704, compiled_block_1_1704 );
  twobit_load( 0, 0 );
  twobit_branchf( 1706, compiled_block_1_1706 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1707, compiled_block_1_1707 );
  twobit_invoke( 5 );
  twobit_label( 1707, compiled_block_1_1707 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_setrtn( 1708, compiled_block_1_1708 );
  twobit_branch( 1700, compiled_block_1_1700 );
  twobit_label( 1708, compiled_block_1_1708 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1706, compiled_block_1_1706 );
  twobit_load( 1, 3 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_pop( 3 );
  twobit_invoke( 1 );
  twobit_label( 1703, compiled_block_1_1703 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1700, compiled_block_1_1700 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1712, compiled_block_1_1712 ); /* internal:branchf-null? */
  twobit_movereg( 2, 1 );
  twobit_global( 7 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1712, compiled_block_1_1712 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 2, 3 );
  twobit_reg_op1_check_652(reg(1),1714,compiled_block_1_1714); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_imm_const_setreg( NIL_CONST, 1 ); /* () */
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1715, compiled_block_1_1715 );
  twobit_invoke( 5 );
  twobit_label( 1715, compiled_block_1_1715 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 3, 2 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_pop( 3 );
  twobit_branch( 1700, compiled_block_1_1700 );
  twobit_label( 1714, compiled_block_1_1714 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_153( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1721, compiled_block_1_1721 ); /* internal:branchf-pair? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1722, compiled_block_1_1722 );
  twobit_invoke( 1 );
  twobit_label( 1722, compiled_block_1_1722 );
  twobit_load( 0, 0 );
  twobit_branchf( 1724, compiled_block_1_1724 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1725, compiled_block_1_1725 );
  twobit_invoke( 5 );
  twobit_label( 1725, compiled_block_1_1725 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_setrtn( 1726, compiled_block_1_1726 );
  twobit_branch( 1718, compiled_block_1_1718 );
  twobit_label( 1726, compiled_block_1_1726 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1724, compiled_block_1_1724 );
  twobit_load( 1, 3 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_pop( 3 );
  twobit_invoke( 1 );
  twobit_label( 1721, compiled_block_1_1721 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1718, compiled_block_1_1718 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1730, compiled_block_1_1730 ); /* internal:branchf-null? */
  twobit_movereg( 2, 1 );
  twobit_global( 7 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1730, compiled_block_1_1730 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 2, 3 );
  twobit_reg_op1_check_652(reg(1),1732,compiled_block_1_1732); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_imm_const_setreg( NIL_CONST, 1 ); /* () */
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1733, compiled_block_1_1733 );
  twobit_invoke( 5 );
  twobit_label( 1733, compiled_block_1_1733 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 3, 2 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_pop( 3 );
  twobit_branch( 1718, compiled_block_1_1718 );
  twobit_label( 1732, compiled_block_1_1732 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_154( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1739, compiled_block_1_1739 ); /* internal:branchf-pair? */
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 8 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1740, compiled_block_1_1740 );
  twobit_invoke( 1 );
  twobit_label( 1740, compiled_block_1_1740 );
  twobit_load( 0, 0 );
  twobit_branchf( 1742, compiled_block_1_1742 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1743, compiled_block_1_1743 );
  twobit_invoke( 5 );
  twobit_label( 1743, compiled_block_1_1743 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1744, compiled_block_1_1744 );
  twobit_invoke( 5 );
  twobit_label( 1744, compiled_block_1_1744 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1745, compiled_block_1_1745 );
  twobit_invoke( 5 );
  twobit_label( 1745, compiled_block_1_1745 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1746, compiled_block_1_1746 );
  twobit_invoke( 5 );
  twobit_label( 1746, compiled_block_1_1746 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1747, compiled_block_1_1747 );
  twobit_invoke( 5 );
  twobit_label( 1747, compiled_block_1_1747 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1748, compiled_block_1_1748 );
  twobit_invoke( 5 );
  twobit_label( 1748, compiled_block_1_1748 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1749, compiled_block_1_1749 );
  twobit_invoke( 5 );
  twobit_label( 1749, compiled_block_1_1749 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_setrtn( 1750, compiled_block_1_1750 );
  twobit_branch( 1736, compiled_block_1_1736 );
  twobit_label( 1750, compiled_block_1_1750 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1751, compiled_block_1_1751 );
  twobit_invoke( 5 );
  twobit_label( 1751, compiled_block_1_1751 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1752, compiled_block_1_1752 );
  twobit_invoke( 5 );
  twobit_label( 1752, compiled_block_1_1752 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 1742, compiled_block_1_1742 );
  twobit_load( 1, 8 );
  twobit_global( 12 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 1739, compiled_block_1_1739 );
  twobit_global( 12 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1736, compiled_block_1_1736 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1756, compiled_block_1_1756 ); /* internal:branchf-null? */
  twobit_movereg( 2, 1 );
  twobit_global( 13 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1756, compiled_block_1_1756 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 2, 3 );
  twobit_reg_op1_check_652(reg(1),1758,compiled_block_1_1758); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_imm_const_setreg( NIL_CONST, 1 ); /* () */
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1759, compiled_block_1_1759 );
  twobit_invoke( 5 );
  twobit_label( 1759, compiled_block_1_1759 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 3, 2 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_pop( 3 );
  twobit_branch( 1736, compiled_block_1_1736 );
  twobit_label( 1758, compiled_block_1_1758 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_155( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1765, compiled_block_1_1765 ); /* internal:branchf-pair? */
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 8 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1766, compiled_block_1_1766 );
  twobit_invoke( 1 );
  twobit_label( 1766, compiled_block_1_1766 );
  twobit_load( 0, 0 );
  twobit_branchf( 1768, compiled_block_1_1768 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1769, compiled_block_1_1769 );
  twobit_invoke( 5 );
  twobit_label( 1769, compiled_block_1_1769 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1770, compiled_block_1_1770 );
  twobit_invoke( 5 );
  twobit_label( 1770, compiled_block_1_1770 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1771, compiled_block_1_1771 );
  twobit_invoke( 5 );
  twobit_label( 1771, compiled_block_1_1771 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1772, compiled_block_1_1772 );
  twobit_invoke( 5 );
  twobit_label( 1772, compiled_block_1_1772 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1773, compiled_block_1_1773 );
  twobit_invoke( 5 );
  twobit_label( 1773, compiled_block_1_1773 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1774, compiled_block_1_1774 );
  twobit_invoke( 5 );
  twobit_label( 1774, compiled_block_1_1774 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1775, compiled_block_1_1775 );
  twobit_invoke( 5 );
  twobit_label( 1775, compiled_block_1_1775 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_setrtn( 1776, compiled_block_1_1776 );
  twobit_branch( 1762, compiled_block_1_1762 );
  twobit_label( 1776, compiled_block_1_1776 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1777, compiled_block_1_1777 );
  twobit_invoke( 5 );
  twobit_label( 1777, compiled_block_1_1777 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1778, compiled_block_1_1778 );
  twobit_invoke( 5 );
  twobit_label( 1778, compiled_block_1_1778 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 1768, compiled_block_1_1768 );
  twobit_load( 1, 8 );
  twobit_global( 12 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 1765, compiled_block_1_1765 );
  twobit_global( 12 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1762, compiled_block_1_1762 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1782, compiled_block_1_1782 ); /* internal:branchf-null? */
  twobit_movereg( 2, 1 );
  twobit_global( 13 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1782, compiled_block_1_1782 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 2, 3 );
  twobit_reg_op1_check_652(reg(1),1784,compiled_block_1_1784); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_imm_const_setreg( NIL_CONST, 1 ); /* () */
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1785, compiled_block_1_1785 );
  twobit_invoke( 5 );
  twobit_label( 1785, compiled_block_1_1785 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 3, 2 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_pop( 3 );
  twobit_branch( 1762, compiled_block_1_1762 );
  twobit_label( 1784, compiled_block_1_1784 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 2 ); /*  test-read-eval-string~1ay%kV~30673 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 3 ); /*  test-match-name~1ay%kV~30672 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 4 ); /*  %test-as-specifier~1ay%kV~30645 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 5 ); /*  %test-match-any~1ay%kV~30631 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 6 ); /*  %test-match-all~1ay%kV~30617 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 7 ); /*  %test-match-nth~1ay%kV~30589 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 8 ); /*  test-apply~1ay%kV~30572 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 9 ); /*  %test-approximimate=~1ay%kV~30314 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 10 ); /*  test-runner-test-name~1ay%kV~30289 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 11 ); /*  %test-on-test-end~1ay%kV~30288 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 12 ); /*  %test-on-test-begin~1ay%kV~30287 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 13 ); /*  %test-source-line2~1ay%kV~30286 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 14 ); /*  %test-report-result~1ay%kV~30264 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 15 ); /*  test-passed?~1ay%kV~30263 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 16 ); /*  test-result-kind~1ay%kV~30262 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 17 ); /*  test-result-remove~1ay%kV~30261 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 18 ); /*  test-result-clear~1ay%kV~30260 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 19 ); /*  test-result-set!~1ay%kV~30259 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 20 ); /*  %test-write-result1~1ay%kV~30258 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 21 ); /*  test-on-test-end-simple~1ay%kV~30257 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 22 ); /*  test-on-test-begin-simple~1ay%kV~30223 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 23 ); /*  %test-end~1ay%kV~30154 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 24 ); /*  %test-format-line~1ay%kV~30153 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 25 ); /*  test-on-final-simple~1ay%kV~30152 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 26 ); /*  %test-final-report-simple~1ay%kV~30151 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 27 ); /*  %test-final-report1~1ay%kV~30150 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 28 ); /*  test-on-bad-end-name-simple~1ay%kV~30149 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 29 ); /*  test-on-bad-count-simple~1ay%kV~30148 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 30 ); /*  %test-on-bad-count-write~1ay%kV~30147 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 31 ); /*  test-on-group-end-simple~1ay%kV~30146 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 32 ); /*  test-on-group-begin-simple~1ay%kV~30145 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 33 ); /*  %test-begin~1ay%kV~30115 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 34 ); /*  %test-should-execute~1ay%kV~30114 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 35 ); /*  %test-any-specifier-matches~1ay%kV~30113 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 36 ); /*  test-runner-create~1ay%kV~30112 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 37 ); /*  %test-specificier-matches~1ay%kV~30111 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 38 ); /*  test-runner-get~1ay%kV~30110 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 39 ); /*  %test-runner-factory~1ay%kV~30088 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 40 ); /*  %test-runner-current~1ay%kV~30066 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 41 ); /*  test-runner-simple~1ay%kV~30063 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 42 ); /*  test-log-to-file~1ay%kV~30062 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 43 ); /*  test-runner-null~1ay%kV~30061 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 44 ); /*  %test-null-callback~1ay%kV~30060 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 45 ); /*  test-runner-group-path~1ay%kV~30059 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 46 ); /*  test-runner-reset~1ay%kV~30058 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 47 ); /*  test-runner-aux-value!~1ay%kV~30057 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 48 ); /*  test-result-alist!~1ay%kV~30056 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 49 ); /*  %test-runner-count-list!~1ay%kV~30055 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 50 ); /*  %test-runner-total-count!~1ay%kV~30054 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 51 ); /*  test-runner-on-bad-end-name!~1ay%kV~30053 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 52 ); /*  test-runner-on-bad-count!~1ay%kV~30052 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 53 ); /*  test-runner-on-final!~1ay%kV~30051 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 54 ); /*  test-runner-on-group-end!~1ay%kV~30050 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 55 ); /*  test-runner-on-group-begin!~1ay%kV~30049 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 56 ); /*  test-runner-on-test-end!~1ay%kV~30048 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 57 ); /*  test-runner-on-test-begin!~1ay%kV~30047 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 58 ); /*  test-runner-group-stack!~1ay%kV~30046 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 59 ); /*  %test-runner-fail-save!~1ay%kV~30045 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 60 ); /*  %test-runner-skip-save!~1ay%kV~30044 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 61 ); /*  %test-runner-run-list!~1ay%kV~30043 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 62 ); /*  %test-runner-fail-list!~1ay%kV~30042 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 63 ); /*  %test-runner-skip-list!~1ay%kV~30041 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 64 ); /*  test-runner-skip-count!~1ay%kV~30040 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 65 ); /*  test-runner-xfail-count!~1ay%kV~30039 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 66 ); /*  test-runner-xpass-count!~1ay%kV~30038 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 67 ); /*  test-runner-fail-count!~1ay%kV~30037 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 68 ); /*  test-runner-pass-count!~1ay%kV~30036 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 69 ); /*  test-runner-aux-value~1ay%kV~30035 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 70 ); /*  test-result-alist~1ay%kV~30034 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 71 ); /*  %test-runner-count-list~1ay%kV~30033 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 72 ); /*  %test-runner-total-count~1ay%kV~30032 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 73 ); /*  test-runner-on-bad-end-name~1ay%kV~30031 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 74 ); /*  test-runner-on-bad-count~1ay%kV~30030 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 75 ); /*  test-runner-on-final~1ay%kV~30029 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 76 ); /*  test-runner-on-group-end~1ay%kV~30028 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 77 ); /*  test-runner-on-group-begin~1ay%kV~30027 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 78 ); /*  test-runner-on-test-end~1ay%kV~30026 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 79 ); /*  test-runner-on-test-begin~1ay%kV~30025 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 80 ); /*  test-runner-group-stack~1ay%kV~30024 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 81 ); /*  %test-runner-fail-save~1ay%kV~30023 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 82 ); /*  %test-runner-skip-save~1ay%kV~30022 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 83 ); /*  %test-runner-run-list~1ay%kV~30021 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 84 ); /*  %test-runner-fail-list~1ay%kV~30020 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 85 ); /*  %test-runner-skip-list~1ay%kV~30019 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 86 ); /*  test-runner-skip-count~1ay%kV~30018 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 87 ); /*  test-runner-xfail-count~1ay%kV~30017 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 88 ); /*  test-runner-xpass-count~1ay%kV~30016 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 89 ); /*  test-runner-fail-count~1ay%kV~30015 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 90 ); /*  test-runner-pass-count~1ay%kV~30014 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 91 ); /*  %test-runner-alloc~1ay%kV~30013 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 92 ); /*  test-runner?~1ay%kV~30012 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 93 ); /*  %test-runner-cookie~1ay%kV~29978 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 94 ); /*  ignored2~1ay%kV~29975 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 95 ); /*  ignored1~1ay%kV~29959 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 96 ); /*  eq~1ay%kV~29923 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 97 ); /*  reverse!~1ay%kV~29922 */
  twobit_global( 98 ); /* reverse */
  twobit_setglbl( 99 ); /*  reverse!~1ay%kV~29922 */
  twobit_global( 100 ); /* eq? */
  twobit_setglbl( 101 ); /*  eq~1ay%kV~29923 */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setglbl( 102 ); /*  ignored1~1ay%kV~29959 */
  twobit_op1_3(); /* unspecified */
  twobit_setglbl( 103 ); /*  ignored2~1ay%kV~29975 */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_const( 104 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setglbl( 105 ); /*  %test-runner-cookie~1ay%kV~29978 */
  twobit_lambda( compiled_start_1_4, 107, 0 );
  twobit_setglbl( 108 ); /*  test-runner?~1ay%kV~30012 */
  twobit_lambda( compiled_start_1_5, 110, 0 );
  twobit_setglbl( 111 ); /*  %test-runner-alloc~1ay%kV~30013 */
  twobit_lambda( compiled_start_1_6, 113, 0 );
  twobit_setglbl( 114 ); /*  test-runner-pass-count~1ay%kV~30014 */
  twobit_lambda( compiled_start_1_7, 116, 0 );
  twobit_setglbl( 117 ); /*  test-runner-fail-count~1ay%kV~30015 */
  twobit_lambda( compiled_start_1_8, 119, 0 );
  twobit_setglbl( 120 ); /*  test-runner-xpass-count~1ay%kV~30016 */
  twobit_lambda( compiled_start_1_9, 122, 0 );
  twobit_setglbl( 123 ); /*  test-runner-xfail-count~1ay%kV~30017 */
  twobit_lambda( compiled_start_1_10, 125, 0 );
  twobit_setglbl( 126 ); /*  test-runner-skip-count~1ay%kV~30018 */
  twobit_lambda( compiled_start_1_11, 128, 0 );
  twobit_setglbl( 129 ); /*  %test-runner-skip-list~1ay%kV~30019 */
  twobit_lambda( compiled_start_1_12, 131, 0 );
  twobit_setglbl( 132 ); /*  %test-runner-fail-list~1ay%kV~30020 */
  twobit_lambda( compiled_start_1_13, 134, 0 );
  twobit_setglbl( 135 ); /*  %test-runner-run-list~1ay%kV~30021 */
  twobit_lambda( compiled_start_1_14, 137, 0 );
  twobit_setglbl( 138 ); /*  %test-runner-skip-save~1ay%kV~30022 */
  twobit_lambda( compiled_start_1_15, 140, 0 );
  twobit_setglbl( 141 ); /*  %test-runner-fail-save~1ay%kV~30023 */
  twobit_lambda( compiled_start_1_16, 143, 0 );
  twobit_setglbl( 144 ); /*  test-runner-group-stack~1ay%kV~30024 */
  twobit_lambda( compiled_start_1_17, 146, 0 );
  twobit_setglbl( 147 ); /*  test-runner-on-test-begin~1ay%kV~30025 */
  twobit_lambda( compiled_start_1_18, 149, 0 );
  twobit_setglbl( 150 ); /*  test-runner-on-test-end~1ay%kV~30026 */
  twobit_lambda( compiled_start_1_19, 152, 0 );
  twobit_setglbl( 153 ); /*  test-runner-on-group-begin~1ay%kV~30027 */
  twobit_lambda( compiled_start_1_20, 155, 0 );
  twobit_setglbl( 156 ); /*  test-runner-on-group-end~1ay%kV~30028 */
  twobit_lambda( compiled_start_1_21, 158, 0 );
  twobit_setglbl( 159 ); /*  test-runner-on-final~1ay%kV~30029 */
  twobit_lambda( compiled_start_1_22, 161, 0 );
  twobit_setglbl( 162 ); /*  test-runner-on-bad-count~1ay%kV~30030 */
  twobit_lambda( compiled_start_1_23, 164, 0 );
  twobit_setglbl( 165 ); /*  test-runner-on-bad-end-name~1ay%kV~30031 */
  twobit_lambda( compiled_start_1_24, 167, 0 );
  twobit_setglbl( 168 ); /*  %test-runner-total-count~1ay%kV~30032 */
  twobit_lambda( compiled_start_1_25, 170, 0 );
  twobit_setglbl( 171 ); /*  %test-runner-count-list~1ay%kV~30033 */
  twobit_lambda( compiled_start_1_26, 173, 0 );
  twobit_setglbl( 174 ); /*  test-result-alist~1ay%kV~30034 */
  twobit_lambda( compiled_start_1_27, 176, 0 );
  twobit_setglbl( 177 ); /*  test-runner-aux-value~1ay%kV~30035 */
  twobit_lambda( compiled_start_1_28, 179, 0 );
  twobit_setglbl( 180 ); /*  test-runner-pass-count!~1ay%kV~30036 */
  twobit_lambda( compiled_start_1_29, 182, 0 );
  twobit_setglbl( 183 ); /*  test-runner-fail-count!~1ay%kV~30037 */
  twobit_lambda( compiled_start_1_30, 185, 0 );
  twobit_setglbl( 186 ); /*  test-runner-xpass-count!~1ay%kV~30038 */
  twobit_lambda( compiled_start_1_31, 188, 0 );
  twobit_setglbl( 189 ); /*  test-runner-xfail-count!~1ay%kV~30039 */
  twobit_lambda( compiled_start_1_32, 191, 0 );
  twobit_setglbl( 192 ); /*  test-runner-skip-count!~1ay%kV~30040 */
  twobit_lambda( compiled_start_1_33, 194, 0 );
  twobit_setglbl( 195 ); /*  %test-runner-skip-list!~1ay%kV~30041 */
  twobit_lambda( compiled_start_1_34, 197, 0 );
  twobit_setglbl( 198 ); /*  %test-runner-fail-list!~1ay%kV~30042 */
  twobit_lambda( compiled_start_1_35, 200, 0 );
  twobit_setglbl( 201 ); /*  %test-runner-run-list!~1ay%kV~30043 */
  twobit_lambda( compiled_start_1_36, 203, 0 );
  twobit_setglbl( 204 ); /*  %test-runner-skip-save!~1ay%kV~30044 */
  twobit_lambda( compiled_start_1_37, 206, 0 );
  twobit_setglbl( 207 ); /*  %test-runner-fail-save!~1ay%kV~30045 */
  twobit_lambda( compiled_start_1_38, 209, 0 );
  twobit_setglbl( 210 ); /*  test-runner-group-stack!~1ay%kV~30046 */
  twobit_lambda( compiled_start_1_39, 212, 0 );
  twobit_setglbl( 213 ); /*  test-runner-on-test-begin!~1ay%kV~30047 */
  twobit_lambda( compiled_start_1_40, 215, 0 );
  twobit_setglbl( 216 ); /*  test-runner-on-test-end!~1ay%kV~30048 */
  twobit_lambda( compiled_start_1_41, 218, 0 );
  twobit_setglbl( 219 ); /*  test-runner-on-group-begin!~1ay%kV~30049 */
  twobit_lambda( compiled_start_1_42, 221, 0 );
  twobit_setglbl( 222 ); /*  test-runner-on-group-end!~1ay%kV~30050 */
  twobit_lambda( compiled_start_1_43, 224, 0 );
  twobit_setglbl( 225 ); /*  test-runner-on-final!~1ay%kV~30051 */
  twobit_lambda( compiled_start_1_44, 227, 0 );
  twobit_setglbl( 228 ); /*  test-runner-on-bad-count!~1ay%kV~30052 */
  twobit_lambda( compiled_start_1_45, 230, 0 );
  twobit_setglbl( 231 ); /*  test-runner-on-bad-end-name!~1ay%kV~30053 */
  twobit_lambda( compiled_start_1_46, 233, 0 );
  twobit_setglbl( 234 ); /*  %test-runner-total-count!~1ay%kV~30054 */
  twobit_lambda( compiled_start_1_47, 236, 0 );
  twobit_setglbl( 49 ); /*  %test-runner-count-list!~1ay%kV~30055 */
  twobit_lambda( compiled_start_1_48, 238, 0 );
  twobit_setglbl( 48 ); /*  test-result-alist!~1ay%kV~30056 */
  twobit_lambda( compiled_start_1_49, 240, 0 );
  twobit_setglbl( 47 ); /*  test-runner-aux-value!~1ay%kV~30057 */
  twobit_lambda( compiled_start_1_50, 242, 0 );
  twobit_setglbl( 46 ); /*  test-runner-reset~1ay%kV~30058 */
  twobit_lambda( compiled_start_1_51, 244, 0 );
  twobit_setglbl( 45 ); /*  test-runner-group-path~1ay%kV~30059 */
  twobit_lambda( compiled_start_1_52, 246, 0 );
  twobit_setglbl( 44 ); /*  %test-null-callback~1ay%kV~30060 */
  twobit_lambda( compiled_start_1_53, 248, 0 );
  twobit_setglbl( 43 ); /*  test-runner-null~1ay%kV~30061 */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setglbl( 42 ); /*  test-log-to-file~1ay%kV~30062 */
  twobit_lambda( compiled_start_1_54, 250, 0 );
  twobit_setglbl( 41 ); /*  test-runner-simple~1ay%kV~30063 */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setglbl( 40 ); /*  %test-runner-current~1ay%kV~30066 */
  twobit_global( 41 ); /*  test-runner-simple~1ay%kV~30063 */
  twobit_setglbl( 39 ); /*  %test-runner-factory~1ay%kV~30088 */
  twobit_lambda( compiled_start_1_55, 252, 0 );
  twobit_setglbl( 38 ); /*  test-runner-get~1ay%kV~30110 */
  twobit_lambda( compiled_start_1_56, 254, 0 );
  twobit_setglbl( 37 ); /*  %test-specificier-matches~1ay%kV~30111 */
  twobit_lambda( compiled_start_1_57, 256, 0 );
  twobit_setglbl( 36 ); /*  test-runner-create~1ay%kV~30112 */
  twobit_lambda( compiled_start_1_58, 258, 0 );
  twobit_setglbl( 35 ); /*  %test-any-specifier-matches~1ay%kV~30113 */
  twobit_lambda( compiled_start_1_59, 260, 0 );
  twobit_setglbl( 34 ); /*  %test-should-execute~1ay%kV~30114 */
  twobit_lambda( compiled_start_1_60, 262, 0 );
  twobit_setglbl( 33 ); /*  %test-begin~1ay%kV~30115 */
  twobit_lambda( compiled_start_1_61, 264, 0 );
  twobit_setglbl( 32 ); /*  test-on-group-begin-simple~1ay%kV~30145 */
  twobit_lambda( compiled_start_1_62, 266, 0 );
  twobit_setglbl( 31 ); /*  test-on-group-end-simple~1ay%kV~30146 */
  twobit_lambda( compiled_start_1_63, 268, 0 );
  twobit_setglbl( 30 ); /*  %test-on-bad-count-write~1ay%kV~30147 */
  twobit_lambda( compiled_start_1_64, 270, 0 );
  twobit_setglbl( 29 ); /*  test-on-bad-count-simple~1ay%kV~30148 */
  twobit_lambda( compiled_start_1_65, 272, 0 );
  twobit_setglbl( 28 ); /*  test-on-bad-end-name-simple~1ay%kV~30149 */
  twobit_lambda( compiled_start_1_66, 274, 0 );
  twobit_setglbl( 27 ); /*  %test-final-report1~1ay%kV~30150 */
  twobit_lambda( compiled_start_1_67, 276, 0 );
  twobit_setglbl( 26 ); /*  %test-final-report-simple~1ay%kV~30151 */
  twobit_lambda( compiled_start_1_68, 278, 0 );
  twobit_setglbl( 25 ); /*  test-on-final-simple~1ay%kV~30152 */
  twobit_lambda( compiled_start_1_69, 280, 0 );
  twobit_setglbl( 24 ); /*  %test-format-line~1ay%kV~30153 */
  twobit_lambda( compiled_start_1_70, 282, 0 );
  twobit_setglbl( 23 ); /*  %test-end~1ay%kV~30154 */
  twobit_lambda( compiled_start_1_71, 284, 0 );
  twobit_setglbl( 22 ); /*  test-on-test-begin-simple~1ay%kV~30223 */
  twobit_lambda( compiled_start_1_72, 286, 0 );
  twobit_setglbl( 21 ); /*  test-on-test-end-simple~1ay%kV~30257 */
  twobit_lambda( compiled_start_1_73, 288, 0 );
  twobit_setglbl( 20 ); /*  %test-write-result1~1ay%kV~30258 */
  twobit_lambda( compiled_start_1_74, 290, 0 );
  twobit_setglbl( 19 ); /*  test-result-set!~1ay%kV~30259 */
  twobit_lambda( compiled_start_1_75, 292, 0 );
  twobit_setglbl( 18 ); /*  test-result-clear~1ay%kV~30260 */
  twobit_lambda( compiled_start_1_76, 294, 0 );
  twobit_setglbl( 17 ); /*  test-result-remove~1ay%kV~30261 */
  twobit_lambda( compiled_start_1_77, 296, 0 );
  twobit_setglbl( 16 ); /*  test-result-kind~1ay%kV~30262 */
  twobit_lambda( compiled_start_1_78, 298, 0 );
  twobit_setglbl( 15 ); /*  test-passed?~1ay%kV~30263 */
  twobit_lambda( compiled_start_1_79, 300, 0 );
  twobit_setglbl( 14 ); /*  %test-report-result~1ay%kV~30264 */
  twobit_lambda( compiled_start_1_80, 302, 0 );
  twobit_setglbl( 13 ); /*  %test-source-line2~1ay%kV~30286 */
  twobit_lambda( compiled_start_1_81, 304, 0 );
  twobit_setglbl( 12 ); /*  %test-on-test-begin~1ay%kV~30287 */
  twobit_lambda( compiled_start_1_82, 306, 0 );
  twobit_setglbl( 11 ); /*  %test-on-test-end~1ay%kV~30288 */
  twobit_lambda( compiled_start_1_83, 308, 0 );
  twobit_setglbl( 10 ); /*  test-runner-test-name~1ay%kV~30289 */
  twobit_lambda( compiled_start_1_84, 310, 0 );
  twobit_setglbl( 9 ); /*  %test-approximimate=~1ay%kV~30314 */
  twobit_lambda( compiled_start_1_85, 312, 0 );
  twobit_setglbl( 8 ); /*  test-apply~1ay%kV~30572 */
  twobit_lambda( compiled_start_1_86, 314, 0 );
  twobit_setglbl( 7 ); /*  %test-match-nth~1ay%kV~30589 */
  twobit_lambda( compiled_start_1_87, 316, 0 );
  twobit_setglbl( 6 ); /*  %test-match-all~1ay%kV~30617 */
  twobit_lambda( compiled_start_1_88, 318, 0 );
  twobit_setglbl( 5 ); /*  %test-match-any~1ay%kV~30631 */
  twobit_lambda( compiled_start_1_89, 320, 0 );
  twobit_setglbl( 4 ); /*  %test-as-specifier~1ay%kV~30645 */
  twobit_lambda( compiled_start_1_90, 322, 0 );
  twobit_setglbl( 3 ); /*  test-match-name~1ay%kV~30672 */
  twobit_lambda( compiled_start_1_91, 324, 0 );
  twobit_setglbl( 2 ); /*  test-read-eval-string~1ay%kV~30673 */
  twobit_global( 325 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_41(); /* vector? */
  twobit_branchf( 1790, compiled_block_1_1790 );
  twobit_reg( 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_454( fixnum(1) ); /* >:fix:fix */
  twobit_branchf( 1792, compiled_block_1_1792 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(4),1793,compiled_block_1_1793); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %test-runner-cookie~1ay%kV~29978 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  eq~1ay%kV~29923 */
  twobit_invoke( 2 );
  twobit_label( 1792, compiled_block_1_1792 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1790, compiled_block_1_1790 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1793, compiled_block_1_1793 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(23) ); /* 23 */
  twobit_op2_80( 4 ); /* make-vector */
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  %test-runner-cookie~1ay%kV~29978 */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(2),1795,compiled_block_1_1795); /* internal:check-<:fix:fix with (3 0 4) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op3_403( 2, 3 ); /* vector-set!:trusted */
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1795, compiled_block_1_1795 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 4, 1, 3, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_6( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op2_check_662(reg(1),reg(4),1796,compiled_block_1_1796); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(4),1796,compiled_block_1_1796); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1796, compiled_block_1_1796 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_7( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op2_check_662(reg(1),reg(4),1797,compiled_block_1_1797); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(4),1797,compiled_block_1_1797); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1797, compiled_block_1_1797 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_8( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op2_check_662(reg(1),reg(4),1798,compiled_block_1_1798); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(4),1798,compiled_block_1_1798); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(3) ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1798, compiled_block_1_1798 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_9( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op2_check_662(reg(1),reg(4),1799,compiled_block_1_1799); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_reg_op2_check_655(RESULT,reg(4),1799,compiled_block_1_1799); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(4) ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1799, compiled_block_1_1799 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_10( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op2_check_662(reg(1),reg(4),1800,compiled_block_1_1800); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_reg_op2_check_655(RESULT,reg(4),1800,compiled_block_1_1800); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(5) ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1800, compiled_block_1_1800 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_11( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op2_check_662(reg(1),reg(4),1801,compiled_block_1_1801); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_reg_op2_check_655(RESULT,reg(4),1801,compiled_block_1_1801); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(6) ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1801, compiled_block_1_1801 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_12( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op2_check_662(reg(1),reg(4),1802,compiled_block_1_1802); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_reg_op2_check_655(RESULT,reg(4),1802,compiled_block_1_1802); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(7) ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1802, compiled_block_1_1802 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_13( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op2_check_662(reg(1),reg(4),1803,compiled_block_1_1803); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_reg_op2_check_655(RESULT,reg(4),1803,compiled_block_1_1803); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(8) ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1803, compiled_block_1_1803 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_14( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op2_check_662(reg(1),reg(4),1804,compiled_block_1_1804); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_reg_op2_check_655(RESULT,reg(4),1804,compiled_block_1_1804); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(9) ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1804, compiled_block_1_1804 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_15( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op2_check_662(reg(1),reg(4),1805,compiled_block_1_1805); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(10) ); /* 10 */
  twobit_reg_op2_check_655(RESULT,reg(4),1805,compiled_block_1_1805); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(10) ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1805, compiled_block_1_1805 );
  twobit_imm_const( fixnum(10) ); /* 10 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_16( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op2_check_662(reg(1),reg(4),1806,compiled_block_1_1806); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(11) ); /* 11 */
  twobit_reg_op2_check_655(RESULT,reg(4),1806,compiled_block_1_1806); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(11) ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1806, compiled_block_1_1806 );
  twobit_imm_const( fixnum(11) ); /* 11 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_17( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op2_check_662(reg(1),reg(4),1807,compiled_block_1_1807); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(12) ); /* 12 */
  twobit_reg_op2_check_655(RESULT,reg(4),1807,compiled_block_1_1807); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(12) ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1807, compiled_block_1_1807 );
  twobit_imm_const( fixnum(12) ); /* 12 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_18( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op2_check_662(reg(1),reg(4),1808,compiled_block_1_1808); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(13) ); /* 13 */
  twobit_reg_op2_check_655(RESULT,reg(4),1808,compiled_block_1_1808); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(13) ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1808, compiled_block_1_1808 );
  twobit_imm_const( fixnum(13) ); /* 13 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_19( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op2_check_662(reg(1),reg(4),1809,compiled_block_1_1809); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(14) ); /* 14 */
  twobit_reg_op2_check_655(RESULT,reg(4),1809,compiled_block_1_1809); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(14) ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1809, compiled_block_1_1809 );
  twobit_imm_const( fixnum(14) ); /* 14 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_20( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op2_check_662(reg(1),reg(4),1810,compiled_block_1_1810); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(15) ); /* 15 */
  twobit_reg_op2_check_655(RESULT,reg(4),1810,compiled_block_1_1810); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(15) ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1810, compiled_block_1_1810 );
  twobit_imm_const( fixnum(15) ); /* 15 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_21( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op2_check_662(reg(1),reg(4),1811,compiled_block_1_1811); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(16) ); /* 16 */
  twobit_reg_op2_check_655(RESULT,reg(4),1811,compiled_block_1_1811); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(16) ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1811, compiled_block_1_1811 );
  twobit_imm_const( fixnum(16) ); /* 16 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_22( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op2_check_662(reg(1),reg(4),1812,compiled_block_1_1812); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(17) ); /* 17 */
  twobit_reg_op2_check_655(RESULT,reg(4),1812,compiled_block_1_1812); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(17) ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1812, compiled_block_1_1812 );
  twobit_imm_const( fixnum(17) ); /* 17 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_23( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op2_check_662(reg(1),reg(4),1813,compiled_block_1_1813); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(18) ); /* 18 */
  twobit_reg_op2_check_655(RESULT,reg(4),1813,compiled_block_1_1813); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(18) ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1813, compiled_block_1_1813 );
  twobit_imm_const( fixnum(18) ); /* 18 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_24( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op2_check_662(reg(1),reg(4),1814,compiled_block_1_1814); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(19) ); /* 19 */
  twobit_reg_op2_check_655(RESULT,reg(4),1814,compiled_block_1_1814); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(19) ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1814, compiled_block_1_1814 );
  twobit_imm_const( fixnum(19) ); /* 19 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_25( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op2_check_662(reg(1),reg(4),1815,compiled_block_1_1815); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(20) ); /* 20 */
  twobit_reg_op2_check_655(RESULT,reg(4),1815,compiled_block_1_1815); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(20) ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1815, compiled_block_1_1815 );
  twobit_imm_const( fixnum(20) ); /* 20 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_26( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op2_check_662(reg(1),reg(4),1816,compiled_block_1_1816); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(21) ); /* 21 */
  twobit_reg_op2_check_655(RESULT,reg(4),1816,compiled_block_1_1816); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(21) ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1816, compiled_block_1_1816 );
  twobit_imm_const( fixnum(21) ); /* 21 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_27( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op2_check_662(reg(1),reg(4),1817,compiled_block_1_1817); /* internal:check-vector?/vector-length:vec with (0 1 0) */
  twobit_imm_const( fixnum(22) ); /* 22 */
  twobit_reg_op2_check_655(RESULT,reg(4),1817,compiled_block_1_1817); /* internal:check-<:fix:fix with (0 1 0) */
  twobit_reg( 1 );
  twobit_op2imm_450( fixnum(22) ); /* vector-ref:trusted */
  twobit_return();
  twobit_label( 1817, compiled_block_1_1817 );
  twobit_imm_const( fixnum(22) ); /* 22 */
  twobit_setreg( 2 );
  twobit_trap( 1, 2, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_28( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1818,compiled_block_1_1818); /* internal:check-vector?/vector-length:vec with (2 0 1) */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_reg_op2_check_655(RESULT,reg(4),1818,compiled_block_1_1818); /* internal:check-<:fix:fix with (2 0 1) */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_return();
  twobit_label( 1818, compiled_block_1_1818 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 3 );
  twobit_trap( 1, 3, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_29( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1819,compiled_block_1_1819); /* internal:check-vector?/vector-length:vec with (2 0 1) */
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_reg_op2_check_655(RESULT,reg(4),1819,compiled_block_1_1819); /* internal:check-<:fix:fix with (2 0 1) */
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_return();
  twobit_label( 1819, compiled_block_1_1819 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 3 );
  twobit_trap( 1, 3, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_30( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1820,compiled_block_1_1820); /* internal:check-vector?/vector-length:vec with (2 0 1) */
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_reg_op2_check_655(RESULT,reg(4),1820,compiled_block_1_1820); /* internal:check-<:fix:fix with (2 0 1) */
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_return();
  twobit_label( 1820, compiled_block_1_1820 );
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_setreg( 3 );
  twobit_trap( 1, 3, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_31( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1821,compiled_block_1_1821); /* internal:check-vector?/vector-length:vec with (2 0 1) */
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_reg_op2_check_655(RESULT,reg(4),1821,compiled_block_1_1821); /* internal:check-<:fix:fix with (2 0 1) */
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_return();
  twobit_label( 1821, compiled_block_1_1821 );
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 3 );
  twobit_trap( 1, 3, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_32( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1822,compiled_block_1_1822); /* internal:check-vector?/vector-length:vec with (2 0 1) */
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_reg_op2_check_655(RESULT,reg(4),1822,compiled_block_1_1822); /* internal:check-<:fix:fix with (2 0 1) */
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_return();
  twobit_label( 1822, compiled_block_1_1822 );
  twobit_imm_const( fixnum(5) ); /* 5 */
  twobit_setreg( 3 );
  twobit_trap( 1, 3, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_33( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1823,compiled_block_1_1823); /* internal:check-vector?/vector-length:vec with (2 0 1) */
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_reg_op2_check_655(RESULT,reg(4),1823,compiled_block_1_1823); /* internal:check-<:fix:fix with (2 0 1) */
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_return();
  twobit_label( 1823, compiled_block_1_1823 );
  twobit_imm_const( fixnum(6) ); /* 6 */
  twobit_setreg( 3 );
  twobit_trap( 1, 3, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_34( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1824,compiled_block_1_1824); /* internal:check-vector?/vector-length:vec with (2 0 1) */
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_reg_op2_check_655(RESULT,reg(4),1824,compiled_block_1_1824); /* internal:check-<:fix:fix with (2 0 1) */
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_return();
  twobit_label( 1824, compiled_block_1_1824 );
  twobit_imm_const( fixnum(7) ); /* 7 */
  twobit_setreg( 3 );
  twobit_trap( 1, 3, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_35( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1825,compiled_block_1_1825); /* internal:check-vector?/vector-length:vec with (2 0 1) */
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_reg_op2_check_655(RESULT,reg(4),1825,compiled_block_1_1825); /* internal:check-<:fix:fix with (2 0 1) */
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_return();
  twobit_label( 1825, compiled_block_1_1825 );
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 3 );
  twobit_trap( 1, 3, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_36( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1826,compiled_block_1_1826); /* internal:check-vector?/vector-length:vec with (2 0 1) */
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_reg_op2_check_655(RESULT,reg(4),1826,compiled_block_1_1826); /* internal:check-<:fix:fix with (2 0 1) */
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_return();
  twobit_label( 1826, compiled_block_1_1826 );
  twobit_imm_const( fixnum(9) ); /* 9 */
  twobit_setreg( 3 );
  twobit_trap( 1, 3, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_37( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1827,compiled_block_1_1827); /* internal:check-vector?/vector-length:vec with (2 0 1) */
  twobit_imm_const( fixnum(10) ); /* 10 */
  twobit_reg_op2_check_655(RESULT,reg(4),1827,compiled_block_1_1827); /* internal:check-<:fix:fix with (2 0 1) */
  twobit_imm_const( fixnum(10) ); /* 10 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_return();
  twobit_label( 1827, compiled_block_1_1827 );
  twobit_imm_const( fixnum(10) ); /* 10 */
  twobit_setreg( 3 );
  twobit_trap( 1, 3, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_38( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1828,compiled_block_1_1828); /* internal:check-vector?/vector-length:vec with (2 0 1) */
  twobit_imm_const( fixnum(11) ); /* 11 */
  twobit_reg_op2_check_655(RESULT,reg(4),1828,compiled_block_1_1828); /* internal:check-<:fix:fix with (2 0 1) */
  twobit_imm_const( fixnum(11) ); /* 11 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_return();
  twobit_label( 1828, compiled_block_1_1828 );
  twobit_imm_const( fixnum(11) ); /* 11 */
  twobit_setreg( 3 );
  twobit_trap( 1, 3, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_39( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1829,compiled_block_1_1829); /* internal:check-vector?/vector-length:vec with (2 0 1) */
  twobit_imm_const( fixnum(12) ); /* 12 */
  twobit_reg_op2_check_655(RESULT,reg(4),1829,compiled_block_1_1829); /* internal:check-<:fix:fix with (2 0 1) */
  twobit_imm_const( fixnum(12) ); /* 12 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_return();
  twobit_label( 1829, compiled_block_1_1829 );
  twobit_imm_const( fixnum(12) ); /* 12 */
  twobit_setreg( 3 );
  twobit_trap( 1, 3, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_40( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1830,compiled_block_1_1830); /* internal:check-vector?/vector-length:vec with (2 0 1) */
  twobit_imm_const( fixnum(13) ); /* 13 */
  twobit_reg_op2_check_655(RESULT,reg(4),1830,compiled_block_1_1830); /* internal:check-<:fix:fix with (2 0 1) */
  twobit_imm_const( fixnum(13) ); /* 13 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_return();
  twobit_label( 1830, compiled_block_1_1830 );
  twobit_imm_const( fixnum(13) ); /* 13 */
  twobit_setreg( 3 );
  twobit_trap( 1, 3, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_41( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1831,compiled_block_1_1831); /* internal:check-vector?/vector-length:vec with (2 0 1) */
  twobit_imm_const( fixnum(14) ); /* 14 */
  twobit_reg_op2_check_655(RESULT,reg(4),1831,compiled_block_1_1831); /* internal:check-<:fix:fix with (2 0 1) */
  twobit_imm_const( fixnum(14) ); /* 14 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_return();
  twobit_label( 1831, compiled_block_1_1831 );
  twobit_imm_const( fixnum(14) ); /* 14 */
  twobit_setreg( 3 );
  twobit_trap( 1, 3, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_42( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1832,compiled_block_1_1832); /* internal:check-vector?/vector-length:vec with (2 0 1) */
  twobit_imm_const( fixnum(15) ); /* 15 */
  twobit_reg_op2_check_655(RESULT,reg(4),1832,compiled_block_1_1832); /* internal:check-<:fix:fix with (2 0 1) */
  twobit_imm_const( fixnum(15) ); /* 15 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_return();
  twobit_label( 1832, compiled_block_1_1832 );
  twobit_imm_const( fixnum(15) ); /* 15 */
  twobit_setreg( 3 );
  twobit_trap( 1, 3, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_43( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1833,compiled_block_1_1833); /* internal:check-vector?/vector-length:vec with (2 0 1) */
  twobit_imm_const( fixnum(16) ); /* 16 */
  twobit_reg_op2_check_655(RESULT,reg(4),1833,compiled_block_1_1833); /* internal:check-<:fix:fix with (2 0 1) */
  twobit_imm_const( fixnum(16) ); /* 16 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_return();
  twobit_label( 1833, compiled_block_1_1833 );
  twobit_imm_const( fixnum(16) ); /* 16 */
  twobit_setreg( 3 );
  twobit_trap( 1, 3, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_44( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1834,compiled_block_1_1834); /* internal:check-vector?/vector-length:vec with (2 0 1) */
  twobit_imm_const( fixnum(17) ); /* 17 */
  twobit_reg_op2_check_655(RESULT,reg(4),1834,compiled_block_1_1834); /* internal:check-<:fix:fix with (2 0 1) */
  twobit_imm_const( fixnum(17) ); /* 17 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_return();
  twobit_label( 1834, compiled_block_1_1834 );
  twobit_imm_const( fixnum(17) ); /* 17 */
  twobit_setreg( 3 );
  twobit_trap( 1, 3, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_45( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1835,compiled_block_1_1835); /* internal:check-vector?/vector-length:vec with (2 0 1) */
  twobit_imm_const( fixnum(18) ); /* 18 */
  twobit_reg_op2_check_655(RESULT,reg(4),1835,compiled_block_1_1835); /* internal:check-<:fix:fix with (2 0 1) */
  twobit_imm_const( fixnum(18) ); /* 18 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_return();
  twobit_label( 1835, compiled_block_1_1835 );
  twobit_imm_const( fixnum(18) ); /* 18 */
  twobit_setreg( 3 );
  twobit_trap( 1, 3, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_46( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1836,compiled_block_1_1836); /* internal:check-vector?/vector-length:vec with (2 0 1) */
  twobit_imm_const( fixnum(19) ); /* 19 */
  twobit_reg_op2_check_655(RESULT,reg(4),1836,compiled_block_1_1836); /* internal:check-<:fix:fix with (2 0 1) */
  twobit_imm_const( fixnum(19) ); /* 19 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_return();
  twobit_label( 1836, compiled_block_1_1836 );
  twobit_imm_const( fixnum(19) ); /* 19 */
  twobit_setreg( 3 );
  twobit_trap( 1, 3, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_47( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1837,compiled_block_1_1837); /* internal:check-vector?/vector-length:vec with (2 0 1) */
  twobit_imm_const( fixnum(20) ); /* 20 */
  twobit_reg_op2_check_655(RESULT,reg(4),1837,compiled_block_1_1837); /* internal:check-<:fix:fix with (2 0 1) */
  twobit_imm_const( fixnum(20) ); /* 20 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_return();
  twobit_label( 1837, compiled_block_1_1837 );
  twobit_imm_const( fixnum(20) ); /* 20 */
  twobit_setreg( 3 );
  twobit_trap( 1, 3, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_48( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1838,compiled_block_1_1838); /* internal:check-vector?/vector-length:vec with (2 0 1) */
  twobit_imm_const( fixnum(21) ); /* 21 */
  twobit_reg_op2_check_655(RESULT,reg(4),1838,compiled_block_1_1838); /* internal:check-<:fix:fix with (2 0 1) */
  twobit_imm_const( fixnum(21) ); /* 21 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_return();
  twobit_label( 1838, compiled_block_1_1838 );
  twobit_imm_const( fixnum(21) ); /* 21 */
  twobit_setreg( 3 );
  twobit_trap( 1, 3, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_49( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op2_check_662(reg(1),reg(4),1839,compiled_block_1_1839); /* internal:check-vector?/vector-length:vec with (2 0 1) */
  twobit_imm_const( fixnum(22) ); /* 22 */
  twobit_reg_op2_check_655(RESULT,reg(4),1839,compiled_block_1_1839); /* internal:check-<:fix:fix with (2 0 1) */
  twobit_imm_const( fixnum(22) ); /* 22 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted */
  twobit_return();
  twobit_label( 1839, compiled_block_1_1839 );
  twobit_imm_const( fixnum(22) ); /* 22 */
  twobit_setreg( 3 );
  twobit_trap( 1, 3, 2, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_50( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  test-runner-pass-count!~1ay%kV~30036 */
  twobit_setrtn( 1840, compiled_block_1_1840 );
  twobit_invoke( 2 );
  twobit_label( 1840, compiled_block_1_1840 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  test-runner-fail-count!~1ay%kV~30037 */
  twobit_setrtn( 1841, compiled_block_1_1841 );
  twobit_invoke( 2 );
  twobit_label( 1841, compiled_block_1_1841 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  test-runner-xpass-count!~1ay%kV~30038 */
  twobit_setrtn( 1842, compiled_block_1_1842 );
  twobit_invoke( 2 );
  twobit_label( 1842, compiled_block_1_1842 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 4 ); /*  test-runner-xfail-count!~1ay%kV~30039 */
  twobit_setrtn( 1843, compiled_block_1_1843 );
  twobit_invoke( 2 );
  twobit_label( 1843, compiled_block_1_1843 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 5 ); /*  test-runner-skip-count!~1ay%kV~30040 */
  twobit_setrtn( 1844, compiled_block_1_1844 );
  twobit_invoke( 2 );
  twobit_label( 1844, compiled_block_1_1844 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 6 ); /*  %test-runner-total-count!~1ay%kV~30054 */
  twobit_setrtn( 1845, compiled_block_1_1845 );
  twobit_invoke( 2 );
  twobit_label( 1845, compiled_block_1_1845 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 7 ); /*  %test-runner-count-list!~1ay%kV~30055 */
  twobit_setrtn( 1846, compiled_block_1_1846 );
  twobit_invoke( 2 );
  twobit_label( 1846, compiled_block_1_1846 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 2 );
  twobit_global( 8 ); /*  %test-runner-run-list!~1ay%kV~30043 */
  twobit_setrtn( 1847, compiled_block_1_1847 );
  twobit_invoke( 2 );
  twobit_label( 1847, compiled_block_1_1847 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 9 ); /*  %test-runner-skip-list!~1ay%kV~30041 */
  twobit_setrtn( 1848, compiled_block_1_1848 );
  twobit_invoke( 2 );
  twobit_label( 1848, compiled_block_1_1848 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 10 ); /*  %test-runner-fail-list!~1ay%kV~30042 */
  twobit_setrtn( 1849, compiled_block_1_1849 );
  twobit_invoke( 2 );
  twobit_label( 1849, compiled_block_1_1849 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 11 ); /*  %test-runner-skip-save!~1ay%kV~30044 */
  twobit_setrtn( 1850, compiled_block_1_1850 );
  twobit_invoke( 2 );
  twobit_label( 1850, compiled_block_1_1850 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 12 ); /*  %test-runner-fail-save!~1ay%kV~30045 */
  twobit_setrtn( 1851, compiled_block_1_1851 );
  twobit_invoke( 2 );
  twobit_label( 1851, compiled_block_1_1851 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 13 ); /*  test-runner-group-stack!~1ay%kV~30046 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_51( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  test-runner-group-stack~1ay%kV~30024 */
  twobit_setrtn( 1853, compiled_block_1_1853 );
  twobit_invoke( 1 );
  twobit_label( 1853, compiled_block_1_1853 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* reverse */
  twobit_pop( 0 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_52( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_53( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  %test-runner-alloc~1ay%kV~30013 */
  twobit_setrtn( 1855, compiled_block_1_1855 );
  twobit_invoke( 0 );
  twobit_label( 1855, compiled_block_1_1855 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 2 ); /*  test-runner-reset~1ay%kV~30058 */
  twobit_setrtn( 1856, compiled_block_1_1856 );
  twobit_invoke( 1 );
  twobit_label( 1856, compiled_block_1_1856 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_126, 4, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /*  test-runner-on-group-begin!~1ay%kV~30049 */
  twobit_setrtn( 1857, compiled_block_1_1857 );
  twobit_invoke( 2 );
  twobit_label( 1857, compiled_block_1_1857 );
  twobit_load( 0, 0 );
  twobit_global( 6 ); /*  %test-null-callback~1ay%kV~30060 */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 7 ); /*  test-runner-on-group-end!~1ay%kV~30050 */
  twobit_setrtn( 1858, compiled_block_1_1858 );
  twobit_invoke( 2 );
  twobit_label( 1858, compiled_block_1_1858 );
  twobit_load( 0, 0 );
  twobit_global( 6 ); /*  %test-null-callback~1ay%kV~30060 */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 8 ); /*  test-runner-on-final!~1ay%kV~30051 */
  twobit_setrtn( 1859, compiled_block_1_1859 );
  twobit_invoke( 2 );
  twobit_label( 1859, compiled_block_1_1859 );
  twobit_load( 0, 0 );
  twobit_global( 6 ); /*  %test-null-callback~1ay%kV~30060 */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 9 ); /*  test-runner-on-test-begin!~1ay%kV~30047 */
  twobit_setrtn( 1860, compiled_block_1_1860 );
  twobit_invoke( 2 );
  twobit_label( 1860, compiled_block_1_1860 );
  twobit_load( 0, 0 );
  twobit_global( 6 ); /*  %test-null-callback~1ay%kV~30060 */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 10 ); /*  test-runner-on-test-end!~1ay%kV~30048 */
  twobit_setrtn( 1861, compiled_block_1_1861 );
  twobit_invoke( 2 );
  twobit_label( 1861, compiled_block_1_1861 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_127, 12, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 13 ); /*  test-runner-on-bad-count!~1ay%kV~30052 */
  twobit_setrtn( 1862, compiled_block_1_1862 );
  twobit_invoke( 2 );
  twobit_label( 1862, compiled_block_1_1862 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_128, 15, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 16 ); /*  test-runner-on-bad-end-name!~1ay%kV~30053 */
  twobit_setrtn( 1863, compiled_block_1_1863 );
  twobit_invoke( 2 );
  twobit_label( 1863, compiled_block_1_1863 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_126( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_127( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_128( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_54( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  %test-runner-alloc~1ay%kV~30013 */
  twobit_setrtn( 1864, compiled_block_1_1864 );
  twobit_invoke( 0 );
  twobit_label( 1864, compiled_block_1_1864 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 2 ); /*  test-runner-reset~1ay%kV~30058 */
  twobit_setrtn( 1865, compiled_block_1_1865 );
  twobit_invoke( 1 );
  twobit_label( 1865, compiled_block_1_1865 );
  twobit_load( 0, 0 );
  twobit_global( 3 ); /*  test-on-group-begin-simple~1ay%kV~30145 */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 4 ); /*  test-runner-on-group-begin!~1ay%kV~30049 */
  twobit_setrtn( 1866, compiled_block_1_1866 );
  twobit_invoke( 2 );
  twobit_label( 1866, compiled_block_1_1866 );
  twobit_load( 0, 0 );
  twobit_global( 5 ); /*  test-on-group-end-simple~1ay%kV~30146 */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /*  test-runner-on-group-end!~1ay%kV~30050 */
  twobit_setrtn( 1867, compiled_block_1_1867 );
  twobit_invoke( 2 );
  twobit_label( 1867, compiled_block_1_1867 );
  twobit_load( 0, 0 );
  twobit_global( 7 ); /*  test-on-final-simple~1ay%kV~30152 */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 8 ); /*  test-runner-on-final!~1ay%kV~30051 */
  twobit_setrtn( 1868, compiled_block_1_1868 );
  twobit_invoke( 2 );
  twobit_label( 1868, compiled_block_1_1868 );
  twobit_load( 0, 0 );
  twobit_global( 9 ); /*  test-on-test-begin-simple~1ay%kV~30223 */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 10 ); /*  test-runner-on-test-begin!~1ay%kV~30047 */
  twobit_setrtn( 1869, compiled_block_1_1869 );
  twobit_invoke( 2 );
  twobit_label( 1869, compiled_block_1_1869 );
  twobit_load( 0, 0 );
  twobit_global( 11 ); /*  test-on-test-end-simple~1ay%kV~30257 */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 12 ); /*  test-runner-on-test-end!~1ay%kV~30048 */
  twobit_setrtn( 1870, compiled_block_1_1870 );
  twobit_invoke( 2 );
  twobit_label( 1870, compiled_block_1_1870 );
  twobit_load( 0, 0 );
  twobit_global( 13 ); /*  test-on-bad-count-simple~1ay%kV~30148 */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 14 ); /*  test-runner-on-bad-count!~1ay%kV~30052 */
  twobit_setrtn( 1871, compiled_block_1_1871 );
  twobit_invoke( 2 );
  twobit_label( 1871, compiled_block_1_1871 );
  twobit_load( 0, 0 );
  twobit_global( 15 ); /*  test-on-bad-end-name-simple~1ay%kV~30149 */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 16 ); /*  test-runner-on-bad-end-name!~1ay%kV~30053 */
  twobit_setrtn( 1872, compiled_block_1_1872 );
  twobit_invoke( 2 );
  twobit_label( 1872, compiled_block_1_1872 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_55( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  %test-runner-current~1ay%kV~30066 */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1874, compiled_block_1_1874 );
  twobit_op1_3(); /* unspecified */
  twobit_skip( 1873, compiled_block_1_1873 );
  twobit_label( 1874, compiled_block_1_1874 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_label( 1873, compiled_block_1_1873 );
  twobit_reg( 4 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_56( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_movereg( 1, 4 );
  twobit_movereg( 2, 1 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_57( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  %test-runner-factory~1ay%kV~30088 */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_58( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_125, 3, 3 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_125( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1878, compiled_block_1_1878 ); /* internal:branchf-null? */
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_return();
  twobit_label( 1878, compiled_block_1_1878 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg_op1_check_652(reg(1),1879,compiled_block_1_1879); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  %test-specificier-matches~1ay%kV~30111 */
  twobit_setrtn( 1880, compiled_block_1_1880 );
  twobit_invoke( 2 );
  twobit_label( 1880, compiled_block_1_1880 );
  twobit_load( 0, 0 );
  twobit_branchf( 1882, compiled_block_1_1882 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_skip( 1881, compiled_block_1_1881 );
  twobit_label( 1882, compiled_block_1_1882 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 1881, compiled_block_1_1881 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1879, compiled_block_1_1879 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_59( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  %test-runner-run-list~1ay%kV~30021 */
  twobit_setrtn( 1885, compiled_block_1_1885 );
  twobit_invoke( 1 );
  twobit_label( 1885, compiled_block_1_1885 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_57( 3, 124, compiled_temp_1_124 ); /* eqv? */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_branchf( 1887, compiled_block_1_1887 );
  twobit_reg( 3 );
  twobit_skip( 1886, compiled_block_1_1886 );
  twobit_label( 1887, compiled_block_1_1887 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 2 ); /*  %test-any-specifier-matches~1ay%kV~30113 */
  twobit_setrtn( 1888, compiled_block_1_1888 );
  twobit_invoke( 2 );
  twobit_label( 1888, compiled_block_1_1888 );
  twobit_load( 0, 0 );
  twobit_label( 1886, compiled_block_1_1886 );
  twobit_op1_9(); /* not */
  twobit_branchf( 1890, compiled_block_1_1890 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1889, compiled_block_1_1889 );
  twobit_label( 1890, compiled_block_1_1890 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  %test-runner-skip-list~1ay%kV~30019 */
  twobit_setrtn( 1891, compiled_block_1_1891 );
  twobit_invoke( 1 );
  twobit_label( 1891, compiled_block_1_1891 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 2 ); /*  %test-any-specifier-matches~1ay%kV~30113 */
  twobit_setrtn( 1892, compiled_block_1_1892 );
  twobit_invoke( 2 );
  twobit_label( 1892, compiled_block_1_1892 );
  twobit_load( 0, 0 );
  twobit_label( 1889, compiled_block_1_1889 );
  twobit_branchf( 1894, compiled_block_1_1894 );
  twobit_load( 1, 1 );
  twobit_const( 4 );
  twobit_setreg( 2 );
  twobit_const( 5 );
  twobit_setreg( 3 );
  twobit_global( 6 ); /*  test-result-set!~1ay%kV~30259 */
  twobit_setrtn( 1895, compiled_block_1_1895 );
  twobit_invoke( 3 );
  twobit_label( 1895, compiled_block_1_1895 );
  twobit_load( 0, 0 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1894, compiled_block_1_1894 );
  twobit_load( 1, 1 );
  twobit_global( 7 ); /*  %test-runner-fail-list~1ay%kV~30020 */
  twobit_setrtn( 1896, compiled_block_1_1896 );
  twobit_invoke( 1 );
  twobit_label( 1896, compiled_block_1_1896 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 2 ); /*  %test-any-specifier-matches~1ay%kV~30113 */
  twobit_setrtn( 1897, compiled_block_1_1897 );
  twobit_invoke( 2 );
  twobit_label( 1897, compiled_block_1_1897 );
  twobit_load( 0, 0 );
  twobit_branchf( 1899, compiled_block_1_1899 );
  twobit_load( 1, 1 );
  twobit_const( 4 );
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_global( 6 ); /*  test-result-set!~1ay%kV~30259 */
  twobit_setrtn( 1900, compiled_block_1_1900 );
  twobit_invoke( 3 );
  twobit_label( 1900, compiled_block_1_1900 );
  twobit_load( 0, 0 );
  twobit_const( 8 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1899, compiled_block_1_1899 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_60( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  %test-runner-current~1ay%kV~30066 */
  twobit_branchf( 1902, compiled_block_1_1902 );
  twobit_op1_3(); /* unspecified */
  twobit_skip( 1901, compiled_block_1_1901 );
  twobit_label( 1902, compiled_block_1_1902 );
  twobit_global( 2 ); /*  test-runner-create~1ay%kV~30112 */
  twobit_setrtn( 1903, compiled_block_1_1903 );
  twobit_invoke( 0 );
  twobit_label( 1903, compiled_block_1_1903 );
  twobit_load( 0, 0 );
  twobit_setglbl( 1 ); /*  %test-runner-current~1ay%kV~30066 */
  twobit_label( 1901, compiled_block_1_1901 );
  twobit_global( 1 ); /*  %test-runner-current~1ay%kV~30066 */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_movereg( 4, 1 );
  twobit_global( 3 ); /*  test-runner-on-group-begin~1ay%kV~30027 */
  twobit_setrtn( 1904, compiled_block_1_1904 );
  twobit_invoke( 1 );
  twobit_label( 1904, compiled_block_1_1904 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_setrtn( 1905, compiled_block_1_1905 );
  twobit_invoke( 3 );
  twobit_label( 1905, compiled_block_1_1905 );
  twobit_load( 0, 0 );
  twobit_load( 1, 3 );
  twobit_global( 4 ); /*  %test-runner-skip-list~1ay%kV~30019 */
  twobit_setrtn( 1906, compiled_block_1_1906 );
  twobit_invoke( 1 );
  twobit_label( 1906, compiled_block_1_1906 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 3 );
  twobit_global( 5 ); /*  %test-runner-skip-save~1ay%kV~30022 */
  twobit_setrtn( 1907, compiled_block_1_1907 );
  twobit_invoke( 1 );
  twobit_label( 1907, compiled_block_1_1907 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_global( 6 ); /*  %test-runner-skip-save!~1ay%kV~30044 */
  twobit_setrtn( 1908, compiled_block_1_1908 );
  twobit_invoke( 2 );
  twobit_label( 1908, compiled_block_1_1908 );
  twobit_load( 0, 0 );
  twobit_load( 1, 3 );
  twobit_global( 7 ); /*  %test-runner-fail-list~1ay%kV~30020 */
  twobit_setrtn( 1909, compiled_block_1_1909 );
  twobit_invoke( 1 );
  twobit_label( 1909, compiled_block_1_1909 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 3 );
  twobit_global( 8 ); /*  %test-runner-fail-save~1ay%kV~30023 */
  twobit_setrtn( 1910, compiled_block_1_1910 );
  twobit_invoke( 1 );
  twobit_label( 1910, compiled_block_1_1910 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_global( 9 ); /*  %test-runner-fail-save!~1ay%kV~30045 */
  twobit_setrtn( 1911, compiled_block_1_1911 );
  twobit_invoke( 2 );
  twobit_label( 1911, compiled_block_1_1911 );
  twobit_load( 0, 0 );
  twobit_load( 1, 3 );
  twobit_global( 10 ); /*  %test-runner-total-count~1ay%kV~30032 */
  twobit_setrtn( 1912, compiled_block_1_1912 );
  twobit_invoke( 1 );
  twobit_label( 1912, compiled_block_1_1912 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 3 );
  twobit_global( 11 ); /*  %test-runner-count-list~1ay%kV~30033 */
  twobit_setrtn( 1913, compiled_block_1_1913 );
  twobit_invoke( 1 );
  twobit_label( 1913, compiled_block_1_1913 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_global( 12 ); /*  %test-runner-count-list!~1ay%kV~30055 */
  twobit_setrtn( 1914, compiled_block_1_1914 );
  twobit_invoke( 2 );
  twobit_label( 1914, compiled_block_1_1914 );
  twobit_load( 0, 0 );
  twobit_load( 1, 3 );
  twobit_global( 13 ); /*  test-runner-group-stack~1ay%kV~30024 */
  twobit_setrtn( 1915, compiled_block_1_1915 );
  twobit_invoke( 1 );
  twobit_label( 1915, compiled_block_1_1915 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_global( 14 ); /*  test-runner-group-stack!~1ay%kV~30046 */
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_61( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  test-runner-group-stack~1ay%kV~30024 */
  twobit_setrtn( 1917, compiled_block_1_1917 );
  twobit_invoke( 1 );
  twobit_label( 1917, compiled_block_1_1917 );
  twobit_load( 0, 0 );
  twobit_op1_branchf_610( 1919, compiled_block_1_1919 ); /* internal:branchf-null? */
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* display */
  twobit_setrtn( 1920, compiled_block_1_1920 );
  twobit_invoke( 1 );
  twobit_label( 1920, compiled_block_1_1920 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /* display */
  twobit_setrtn( 1921, compiled_block_1_1921 );
  twobit_invoke( 1 );
  twobit_label( 1921, compiled_block_1_1921 );
  twobit_load( 0, 0 );
  twobit_global( 4 ); /*  test-log-to-file~1ay%kV~30062 */
  twobit_branchf( 1923, compiled_block_1_1923 );
  twobit_global( 4 ); /*  test-log-to-file~1ay%kV~30062 */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 1925, compiled_block_1_1925 );
  twobit_reg( 4 );
  twobit_skip( 1924, compiled_block_1_1924 );
  twobit_label( 1925, compiled_block_1_1925 );
  twobit_load( 1, 1 );
  twobit_const( 5 );
  twobit_setreg( 2 );
  twobit_global( 6 ); /* string-append */
  twobit_setrtn( 1926, compiled_block_1_1926 );
  twobit_invoke( 2 );
  twobit_label( 1926, compiled_block_1_1926 );
  twobit_load( 0, 0 );
  twobit_label( 1924, compiled_block_1_1924 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_global( 7 ); /* no-fail */
  twobit_setreg( 1 );
  twobit_global( 8 ); /* file-options */
  twobit_setrtn( 1927, compiled_block_1_1927 );
  twobit_invoke( 1 );
  twobit_label( 1927, compiled_block_1_1927 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_global( 9 ); /* native-transcoder */
  twobit_setrtn( 1928, compiled_block_1_1928 );
  twobit_invoke( 0 );
  twobit_label( 1928, compiled_block_1_1928 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_const( 10 );
  twobit_setreg( 3 );
  twobit_global( 11 ); /* open-file-output-port */
  twobit_setrtn( 1929, compiled_block_1_1929 );
  twobit_invoke( 4 );
  twobit_label( 1929, compiled_block_1_1929 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 2 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* display */
  twobit_setrtn( 1930, compiled_block_1_1930 );
  twobit_invoke( 2 );
  twobit_label( 1930, compiled_block_1_1930 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 3 ); /* display */
  twobit_setrtn( 1931, compiled_block_1_1931 );
  twobit_invoke( 2 );
  twobit_label( 1931, compiled_block_1_1931 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_global( 12 ); /* newline */
  twobit_setrtn( 1932, compiled_block_1_1932 );
  twobit_invoke( 1 );
  twobit_label( 1932, compiled_block_1_1932 );
  twobit_load( 0, 0 );
  twobit_load( 1, 4 );
  twobit_load( 2, 2 );
  twobit_global( 13 ); /*  test-runner-aux-value!~1ay%kV~30057 */
  twobit_setrtn( 1933, compiled_block_1_1933 );
  twobit_invoke( 2 );
  twobit_label( 1933, compiled_block_1_1933 );
  twobit_load( 0, 0 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* display */
  twobit_setrtn( 1934, compiled_block_1_1934 );
  twobit_invoke( 1 );
  twobit_label( 1934, compiled_block_1_1934 );
  twobit_load( 0, 0 );
  twobit_load( 1, 3 );
  twobit_global( 3 ); /* display */
  twobit_setrtn( 1935, compiled_block_1_1935 );
  twobit_invoke( 1 );
  twobit_label( 1935, compiled_block_1_1935 );
  twobit_load( 0, 0 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* display */
  twobit_setrtn( 1936, compiled_block_1_1936 );
  twobit_invoke( 1 );
  twobit_label( 1936, compiled_block_1_1936 );
  twobit_load( 0, 0 );
  twobit_skip( 1922, compiled_block_1_1922 );
  twobit_label( 1923, compiled_block_1_1923 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 1922, compiled_block_1_1922 );
  twobit_global( 12 ); /* newline */
  twobit_setrtn( 1937, compiled_block_1_1937 );
  twobit_invoke( 0 );
  twobit_label( 1937, compiled_block_1_1937 );
  twobit_load( 0, 0 );
  twobit_skip( 1918, compiled_block_1_1918 );
  twobit_label( 1919, compiled_block_1_1919 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 1918, compiled_block_1_1918 );
  twobit_load( 1, 4 );
  twobit_global( 16 ); /*  test-runner-aux-value~1ay%kV~30035 */
  twobit_setrtn( 1938, compiled_block_1_1938 );
  twobit_invoke( 1 );
  twobit_label( 1938, compiled_block_1_1938 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_movereg( 4, 1 );
  twobit_global( 17 ); /* output-port? */
  twobit_setrtn( 1939, compiled_block_1_1939 );
  twobit_invoke( 1 );
  twobit_label( 1939, compiled_block_1_1939 );
  twobit_load( 0, 0 );
  twobit_branchf( 1941, compiled_block_1_1941 );
  twobit_const( 18 );
  twobit_setreg( 1 );
  twobit_load( 2, 4 );
  twobit_global( 3 ); /* display */
  twobit_setrtn( 1942, compiled_block_1_1942 );
  twobit_invoke( 2 );
  twobit_label( 1942, compiled_block_1_1942 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_load( 2, 4 );
  twobit_global( 3 ); /* display */
  twobit_setrtn( 1943, compiled_block_1_1943 );
  twobit_invoke( 2 );
  twobit_label( 1943, compiled_block_1_1943 );
  twobit_load( 0, 0 );
  twobit_load( 1, 4 );
  twobit_global( 12 ); /* newline */
  twobit_setrtn( 1944, compiled_block_1_1944 );
  twobit_invoke( 1 );
  twobit_label( 1944, compiled_block_1_1944 );
  twobit_load( 0, 0 );
  twobit_skip( 1940, compiled_block_1_1940 );
  twobit_label( 1941, compiled_block_1_1941 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 1940, compiled_block_1_1940 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 4 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_62( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_global( 1 ); /*  test-runner-aux-value~1ay%kV~30035 */
  twobit_setrtn( 1945, compiled_block_1_1945 );
  twobit_invoke( 1 );
  twobit_label( 1945, compiled_block_1_1945 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 2 ); /* output-port? */
  twobit_setrtn( 1946, compiled_block_1_1946 );
  twobit_invoke( 1 );
  twobit_label( 1946, compiled_block_1_1946 );
  twobit_load( 0, 0 );
  twobit_branchf( 1948, compiled_block_1_1948 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /* display */
  twobit_setrtn( 1949, compiled_block_1_1949 );
  twobit_invoke( 2 );
  twobit_label( 1949, compiled_block_1_1949 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_global( 5 ); /*  test-runner-group-stack~1ay%kV~30024 */
  twobit_setrtn( 1950, compiled_block_1_1950 );
  twobit_invoke( 1 );
  twobit_label( 1950, compiled_block_1_1950 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1951,compiled_block_1_1951); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /* display */
  twobit_setrtn( 1952, compiled_block_1_1952 );
  twobit_invoke( 2 );
  twobit_label( 1952, compiled_block_1_1952 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* newline */
  twobit_setrtn( 1953, compiled_block_1_1953 );
  twobit_invoke( 1 );
  twobit_label( 1953, compiled_block_1_1953 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 7 ); /* close-output-port */
  twobit_setrtn( 1954, compiled_block_1_1954 );
  twobit_invoke( 1 );
  twobit_label( 1954, compiled_block_1_1954 );
  twobit_load( 0, 0 );
  twobit_skip( 1947, compiled_block_1_1947 );
  twobit_label( 1948, compiled_block_1_1948 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 1947, compiled_block_1_1947 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1951, compiled_block_1_1951 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_63( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 2 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* display */
  twobit_setrtn( 1955, compiled_block_1_1955 );
  twobit_invoke( 2 );
  twobit_label( 1955, compiled_block_1_1955 );
  twobit_load( 0, 0 );
  twobit_load( 2, 1 );
  twobit_load( 1, 2 );
  twobit_global( 2 ); /* display */
  twobit_setrtn( 1956, compiled_block_1_1956 );
  twobit_invoke( 2 );
  twobit_label( 1956, compiled_block_1_1956 );
  twobit_load( 0, 0 );
  twobit_load( 2, 1 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* display */
  twobit_setrtn( 1957, compiled_block_1_1957 );
  twobit_invoke( 2 );
  twobit_label( 1957, compiled_block_1_1957 );
  twobit_load( 0, 0 );
  twobit_load( 2, 1 );
  twobit_load( 1, 3 );
  twobit_global( 2 ); /* display */
  twobit_setrtn( 1958, compiled_block_1_1958 );
  twobit_invoke( 2 );
  twobit_label( 1958, compiled_block_1_1958 );
  twobit_load( 0, 0 );
  twobit_load( 2, 1 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* display */
  twobit_setrtn( 1959, compiled_block_1_1959 );
  twobit_invoke( 2 );
  twobit_label( 1959, compiled_block_1_1959 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* newline */
  twobit_setrtn( 1960, compiled_block_1_1960 );
  twobit_invoke( 1 );
  twobit_label( 1960, compiled_block_1_1960 );
  twobit_load( 0, 0 );
  twobit_load( 2, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* display */
  twobit_setrtn( 1961, compiled_block_1_1961 );
  twobit_invoke( 2 );
  twobit_label( 1961, compiled_block_1_1961 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* newline */
  twobit_pop( 3 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_64( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_global( 1 ); /* current-output-port */
  twobit_setrtn( 1963, compiled_block_1_1963 );
  twobit_invoke( 0 );
  twobit_label( 1963, compiled_block_1_1963 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_load( 3, 3 );
  twobit_global( 2 ); /*  %test-on-bad-count-write~1ay%kV~30147 */
  twobit_setrtn( 1964, compiled_block_1_1964 );
  twobit_invoke( 4 );
  twobit_label( 1964, compiled_block_1_1964 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  test-runner-aux-value~1ay%kV~30035 */
  twobit_setrtn( 1965, compiled_block_1_1965 );
  twobit_invoke( 1 );
  twobit_label( 1965, compiled_block_1_1965 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_movereg( 4, 1 );
  twobit_global( 4 ); /* output-port? */
  twobit_setrtn( 1966, compiled_block_1_1966 );
  twobit_invoke( 1 );
  twobit_label( 1966, compiled_block_1_1966 );
  twobit_load( 0, 0 );
  twobit_branchf( 1968, compiled_block_1_1968 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_load( 3, 3 );
  twobit_load( 4, 4 );
  twobit_global( 2 ); /*  %test-on-bad-count-write~1ay%kV~30147 */
  twobit_pop( 4 );
  twobit_invoke( 4 );
  twobit_label( 1968, compiled_block_1_1968 );
  twobit_op1_3(); /* unspecified */
  twobit_pop( 4 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_65( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  %test-format-line~1ay%kV~30153 */
  twobit_setrtn( 1970, compiled_block_1_1970 );
  twobit_invoke( 1 );
  twobit_label( 1970, compiled_block_1_1970 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_stack( 1 );
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_movereg( 4, 5 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 4 );
  twobit_global( 4 ); /* string-append */
  twobit_setrtn( 1971, compiled_block_1_1971 );
  twobit_invoke( 5 );
  twobit_label( 1971, compiled_block_1_1971 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /* display */
  twobit_setrtn( 1972, compiled_block_1_1972 );
  twobit_invoke( 1 );
  twobit_label( 1972, compiled_block_1_1972 );
  twobit_load( 0, 0 );
  twobit_global( 6 ); /* newline */
  twobit_pop( 2 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_66( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_636( fixnum(0), 123, compiled_temp_1_123, 1975, compiled_block_1_1975 ); /* internal:branchf->/imm */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 3, 1 );
  twobit_movereg( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_global( 1 ); /* display */
  twobit_setrtn( 1976, compiled_block_1_1976 );
  twobit_invoke( 2 );
  twobit_label( 1976, compiled_block_1_1976 );
  twobit_load( 0, 0 );
  twobit_load( 2, 1 );
  twobit_load( 1, 2 );
  twobit_global( 1 ); /* display */
  twobit_setrtn( 1977, compiled_block_1_1977 );
  twobit_invoke( 2 );
  twobit_label( 1977, compiled_block_1_1977 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* newline */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1975, compiled_block_1_1975 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_67( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  test-runner-pass-count~1ay%kV~30014 */
  twobit_setrtn( 1979, compiled_block_1_1979 );
  twobit_invoke( 1 );
  twobit_label( 1979, compiled_block_1_1979 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 3, 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  %test-final-report1~1ay%kV~30150 */
  twobit_setrtn( 1980, compiled_block_1_1980 );
  twobit_invoke( 3 );
  twobit_label( 1980, compiled_block_1_1980 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_global( 4 ); /*  test-runner-xfail-count~1ay%kV~30017 */
  twobit_setrtn( 1981, compiled_block_1_1981 );
  twobit_invoke( 1 );
  twobit_label( 1981, compiled_block_1_1981 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 3, 1 );
  twobit_const( 5 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  %test-final-report1~1ay%kV~30150 */
  twobit_setrtn( 1982, compiled_block_1_1982 );
  twobit_invoke( 3 );
  twobit_label( 1982, compiled_block_1_1982 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /*  test-runner-xpass-count~1ay%kV~30016 */
  twobit_setrtn( 1983, compiled_block_1_1983 );
  twobit_invoke( 1 );
  twobit_label( 1983, compiled_block_1_1983 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 3, 1 );
  twobit_const( 7 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  %test-final-report1~1ay%kV~30150 */
  twobit_setrtn( 1984, compiled_block_1_1984 );
  twobit_invoke( 3 );
  twobit_label( 1984, compiled_block_1_1984 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_global( 8 ); /*  test-runner-fail-count~1ay%kV~30015 */
  twobit_setrtn( 1985, compiled_block_1_1985 );
  twobit_invoke( 1 );
  twobit_label( 1985, compiled_block_1_1985 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 3, 1 );
  twobit_const( 9 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  %test-final-report1~1ay%kV~30150 */
  twobit_setrtn( 1986, compiled_block_1_1986 );
  twobit_invoke( 3 );
  twobit_label( 1986, compiled_block_1_1986 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_global( 10 ); /*  test-runner-skip-count~1ay%kV~30018 */
  twobit_setrtn( 1987, compiled_block_1_1987 );
  twobit_invoke( 1 );
  twobit_label( 1987, compiled_block_1_1987 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 3, 1 );
  twobit_const( 11 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  %test-final-report1~1ay%kV~30150 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_68( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* current-output-port */
  twobit_setrtn( 1989, compiled_block_1_1989 );
  twobit_invoke( 0 );
  twobit_label( 1989, compiled_block_1_1989 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  %test-final-report-simple~1ay%kV~30151 */
  twobit_setrtn( 1990, compiled_block_1_1990 );
  twobit_invoke( 2 );
  twobit_label( 1990, compiled_block_1_1990 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  test-runner-aux-value~1ay%kV~30035 */
  twobit_setrtn( 1991, compiled_block_1_1991 );
  twobit_invoke( 1 );
  twobit_label( 1991, compiled_block_1_1991 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 4 ); /* output-port? */
  twobit_setrtn( 1992, compiled_block_1_1992 );
  twobit_invoke( 1 );
  twobit_label( 1992, compiled_block_1_1992 );
  twobit_load( 0, 0 );
  twobit_branchf( 1994, compiled_block_1_1994 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 2 ); /*  %test-final-report-simple~1ay%kV~30151 */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1994, compiled_block_1_1994 );
  twobit_op1_3(); /* unspecified */
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_69( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  test-result-alist~1ay%kV~30034 */
  twobit_setrtn( 1996, compiled_block_1_1996 );
  twobit_invoke( 1 );
  twobit_label( 1996, compiled_block_1_1996 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 2 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* assq */
  twobit_setrtn( 1997, compiled_block_1_1997 );
  twobit_invoke( 2 );
  twobit_label( 1997, compiled_block_1_1997 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 3 ); /* assq */
  twobit_setrtn( 1998, compiled_block_1_1998 );
  twobit_invoke( 2 );
  twobit_label( 1998, compiled_block_1_1998 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_branchf( 2000, compiled_block_1_2000 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 2, 2 );
  twobit_check( 2, 0, 0, 2001, compiled_block_1_2001 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_skip( 1999, compiled_block_1_1999 );
  twobit_label( 2000, compiled_block_1_2000 );
  twobit_const( 5 );
  twobit_label( 1999, compiled_block_1_1999 );
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_branchf( 2003, compiled_block_1_2003 );
  twobit_reg_op1_check_652(reg(4),2004,compiled_block_1_2004); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_global( 6 ); /* number->string */
  twobit_setrtn( 2005, compiled_block_1_2005 );
  twobit_invoke( 1 );
  twobit_label( 2005, compiled_block_1_2005 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 1, 2 );
  twobit_const( 7 );
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_setreg( 4 );
  twobit_global( 9 ); /* string-append */
  twobit_pop( 2 );
  twobit_invoke( 4 );
  twobit_label( 2003, compiled_block_1_2003 );
  twobit_const( 5 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2004, compiled_block_1_2004 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_label( 2001, compiled_block_1_2001 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_70( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 5 );
  twobit_store( 2, 2 );
  twobit_global( 1 ); /*  test-runner-get~1ay%kV~30110 */
  twobit_setrtn( 2007, compiled_block_1_2007 );
  twobit_invoke( 0 );
  twobit_label( 2007, compiled_block_1_2007 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 2 ); /*  test-runner-group-stack~1ay%kV~30024 */
  twobit_setrtn( 2008, compiled_block_1_2008 );
  twobit_invoke( 1 );
  twobit_label( 2008, compiled_block_1_2008 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  %test-format-line~1ay%kV~30153 */
  twobit_setrtn( 2009, compiled_block_1_2009 );
  twobit_invoke( 1 );
  twobit_label( 2009, compiled_block_1_2009 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 4 ); /*  test-result-alist!~1ay%kV~30056 */
  twobit_setrtn( 2010, compiled_block_1_2010 );
  twobit_invoke( 2 );
  twobit_label( 2010, compiled_block_1_2010 );
  twobit_load( 0, 0 );
  twobit_stack( 3 );
  twobit_op1_branchf_610( 2012, compiled_block_1_2012 ); /* internal:branchf-null? */
  twobit_load( 1, 4 );
  twobit_const( 5 );
  twobit_setreg( 2 );
  twobit_global( 6 ); /* string-append */
  twobit_setrtn( 2013, compiled_block_1_2013 );
  twobit_invoke( 2 );
  twobit_label( 2013, compiled_block_1_2013 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /* display */
  twobit_setrtn( 2014, compiled_block_1_2014 );
  twobit_invoke( 1 );
  twobit_label( 2014, compiled_block_1_2014 );
  twobit_load( 0, 0 );
  twobit_global( 8 ); /* newline */
  twobit_setrtn( 2015, compiled_block_1_2015 );
  twobit_invoke( 0 );
  twobit_label( 2015, compiled_block_1_2015 );
  twobit_load( 0, 0 );
  twobit_skip( 2011, compiled_block_1_2011 );
  twobit_label( 2012, compiled_block_1_2012 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 2011, compiled_block_1_2011 );
  twobit_stack( 5 );
  twobit_branchf( 2017, compiled_block_1_2017 );
  twobit_stack( 3 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 3 );
  twobit_check( 3, 0, 0, 2018, compiled_block_1_2018 );
  twobit_stack( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_load( 1, 5 );
  twobit_global( 9 ); /* equal? */
  twobit_setrtn( 2019, compiled_block_1_2019 );
  twobit_invoke( 2 );
  twobit_label( 2019, compiled_block_1_2019 );
  twobit_load( 0, 0 );
  twobit_op1_9(); /* not */
  twobit_skip( 2016, compiled_block_1_2016 );
  twobit_label( 2017, compiled_block_1_2017 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2016, compiled_block_1_2016 );
  twobit_branchf( 2021, compiled_block_1_2021 );
  twobit_stack( 3 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 3 );
  twobit_check( 3, 0, 0, 2018, compiled_block_1_2018 );
  twobit_stack( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 1 );
  twobit_global( 10 ); /*  test-runner-on-bad-end-name~1ay%kV~30031 */
  twobit_setrtn( 2022, compiled_block_1_2022 );
  twobit_invoke( 1 );
  twobit_label( 2022, compiled_block_1_2022 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 4 );
  twobit_load( 2, 5 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 2023, compiled_block_1_2023 );
  twobit_invoke( 3 );
  twobit_label( 2023, compiled_block_1_2023 );
  twobit_load( 0, 0 );
  twobit_skip( 2020, compiled_block_1_2020 );
  twobit_label( 2021, compiled_block_1_2021 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 2020, compiled_block_1_2020 );
  twobit_load( 1, 1 );
  twobit_global( 11 ); /*  %test-runner-count-list~1ay%kV~30033 */
  twobit_setrtn( 2024, compiled_block_1_2024 );
  twobit_invoke( 1 );
  twobit_label( 2024, compiled_block_1_2024 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg_op1_check_652(reg(4),2025,compiled_block_1_2025); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg_op1_check_652(reg(3),2026,compiled_block_1_2026); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 5 );
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_load( 1, 1 );
  twobit_global( 12 ); /*  %test-runner-total-count~1ay%kV~30032 */
  twobit_setrtn( 2027, compiled_block_1_2027 );
  twobit_invoke( 1 );
  twobit_label( 2027, compiled_block_1_2027 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_62( 3, 121, compiled_temp_1_121 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_stack( 5 );
  twobit_branchf( 2029, compiled_block_1_2029 );
  twobit_stack( 5 );
  twobit_op2_68( 4, 122, compiled_temp_1_122 ); /* = */
  twobit_op1_9(); /* not */
  twobit_skip( 2028, compiled_block_1_2028 );
  twobit_label( 2029, compiled_block_1_2029 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2028, compiled_block_1_2028 );
  twobit_branchf( 2031, compiled_block_1_2031 );
  twobit_load( 1, 1 );
  twobit_global( 13 ); /*  test-runner-on-bad-count~1ay%kV~30030 */
  twobit_setrtn( 2032, compiled_block_1_2032 );
  twobit_invoke( 1 );
  twobit_label( 2032, compiled_block_1_2032 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 2, 4 );
  twobit_load( 3, 5 );
  twobit_reg( 4 );
  twobit_setrtn( 2033, compiled_block_1_2033 );
  twobit_invoke( 3 );
  twobit_label( 2033, compiled_block_1_2033 );
  twobit_load( 0, 0 );
  twobit_skip( 2030, compiled_block_1_2030 );
  twobit_label( 2031, compiled_block_1_2031 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 2030, compiled_block_1_2030 );
  twobit_load( 1, 1 );
  twobit_global( 14 ); /*  test-runner-on-group-end~1ay%kV~30028 */
  twobit_setrtn( 2034, compiled_block_1_2034 );
  twobit_invoke( 1 );
  twobit_label( 2034, compiled_block_1_2034 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 2035, compiled_block_1_2035 );
  twobit_invoke( 1 );
  twobit_label( 2035, compiled_block_1_2035 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  test-runner-group-stack~1ay%kV~30024 */
  twobit_setrtn( 2036, compiled_block_1_2036 );
  twobit_invoke( 1 );
  twobit_label( 2036, compiled_block_1_2036 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),2037,compiled_block_1_2037); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 15 ); /*  test-runner-group-stack!~1ay%kV~30046 */
  twobit_setrtn( 2038, compiled_block_1_2038 );
  twobit_invoke( 2 );
  twobit_label( 2038, compiled_block_1_2038 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 16 ); /*  %test-runner-skip-save~1ay%kV~30022 */
  twobit_setrtn( 2039, compiled_block_1_2039 );
  twobit_invoke( 1 );
  twobit_label( 2039, compiled_block_1_2039 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),2025,compiled_block_1_2025); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 17 ); /*  %test-runner-skip-list!~1ay%kV~30041 */
  twobit_setrtn( 2040, compiled_block_1_2040 );
  twobit_invoke( 2 );
  twobit_label( 2040, compiled_block_1_2040 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 16 ); /*  %test-runner-skip-save~1ay%kV~30022 */
  twobit_setrtn( 2041, compiled_block_1_2041 );
  twobit_invoke( 1 );
  twobit_label( 2041, compiled_block_1_2041 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),2037,compiled_block_1_2037); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 18 ); /*  %test-runner-skip-save!~1ay%kV~30044 */
  twobit_setrtn( 2042, compiled_block_1_2042 );
  twobit_invoke( 2 );
  twobit_label( 2042, compiled_block_1_2042 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 19 ); /*  %test-runner-fail-save~1ay%kV~30023 */
  twobit_setrtn( 2043, compiled_block_1_2043 );
  twobit_invoke( 1 );
  twobit_label( 2043, compiled_block_1_2043 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),2025,compiled_block_1_2025); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 20 ); /*  %test-runner-fail-list!~1ay%kV~30042 */
  twobit_setrtn( 2044, compiled_block_1_2044 );
  twobit_invoke( 2 );
  twobit_label( 2044, compiled_block_1_2044 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 19 ); /*  %test-runner-fail-save~1ay%kV~30023 */
  twobit_setrtn( 2045, compiled_block_1_2045 );
  twobit_invoke( 1 );
  twobit_label( 2045, compiled_block_1_2045 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),2037,compiled_block_1_2037); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 21 ); /*  %test-runner-fail-save!~1ay%kV~30045 */
  twobit_setrtn( 2046, compiled_block_1_2046 );
  twobit_invoke( 2 );
  twobit_label( 2046, compiled_block_1_2046 );
  twobit_load( 0, 0 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 22 ); /*  %test-runner-count-list!~1ay%kV~30055 */
  twobit_setrtn( 2047, compiled_block_1_2047 );
  twobit_invoke( 2 );
  twobit_label( 2047, compiled_block_1_2047 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  test-runner-group-stack~1ay%kV~30024 */
  twobit_setrtn( 2048, compiled_block_1_2048 );
  twobit_invoke( 1 );
  twobit_label( 2048, compiled_block_1_2048 );
  twobit_load( 0, 0 );
  twobit_op1_branchf_610( 2050, compiled_block_1_2050 ); /* internal:branchf-null? */
  twobit_load( 1, 1 );
  twobit_global( 23 ); /*  test-runner-on-final~1ay%kV~30029 */
  twobit_setrtn( 2051, compiled_block_1_2051 );
  twobit_invoke( 1 );
  twobit_label( 2051, compiled_block_1_2051 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 2050, compiled_block_1_2050 );
  twobit_op1_3(); /* unspecified */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 2026, compiled_block_1_2026 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_label( 2025, compiled_block_1_2025 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 2037, compiled_block_1_2037 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_label( 2018, compiled_block_1_2018 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_71( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  test-runner-aux-value~1ay%kV~30035 */
  twobit_setrtn( 2053, compiled_block_1_2053 );
  twobit_invoke( 1 );
  twobit_label( 2053, compiled_block_1_2053 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 2 ); /* output-port? */
  twobit_setrtn( 2054, compiled_block_1_2054 );
  twobit_invoke( 1 );
  twobit_label( 2054, compiled_block_1_2054 );
  twobit_load( 0, 0 );
  twobit_branchf( 2056, compiled_block_1_2056 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  test-result-alist~1ay%kV~30034 */
  twobit_setrtn( 2057, compiled_block_1_2057 );
  twobit_invoke( 1 );
  twobit_label( 2057, compiled_block_1_2057 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 2 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /* assq */
  twobit_setrtn( 2058, compiled_block_1_2058 );
  twobit_invoke( 2 );
  twobit_label( 2058, compiled_block_1_2058 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* assq */
  twobit_setrtn( 2059, compiled_block_1_2059 );
  twobit_invoke( 2 );
  twobit_label( 2059, compiled_block_1_2059 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* assq */
  twobit_setrtn( 2060, compiled_block_1_2060 );
  twobit_invoke( 2 );
  twobit_label( 2060, compiled_block_1_2060 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* assq */
  twobit_setrtn( 2061, compiled_block_1_2061 );
  twobit_invoke( 2 );
  twobit_label( 2061, compiled_block_1_2061 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 10 ); /* display */
  twobit_setrtn( 2062, compiled_block_1_2062 );
  twobit_invoke( 2 );
  twobit_label( 2062, compiled_block_1_2062 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_global( 11 ); /* newline */
  twobit_setrtn( 2063, compiled_block_1_2063 );
  twobit_invoke( 1 );
  twobit_label( 2063, compiled_block_1_2063 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_branchf( 2065, compiled_block_1_2065 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 12 ); /*  %test-write-result1~1ay%kV~30258 */
  twobit_setrtn( 2066, compiled_block_1_2066 );
  twobit_invoke( 2 );
  twobit_label( 2066, compiled_block_1_2066 );
  twobit_load( 0, 0 );
  twobit_skip( 2064, compiled_block_1_2064 );
  twobit_label( 2065, compiled_block_1_2065 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 2064, compiled_block_1_2064 );
  twobit_stack( 3 );
  twobit_branchf( 2068, compiled_block_1_2068 );
  twobit_load( 1, 3 );
  twobit_load( 2, 2 );
  twobit_global( 12 ); /*  %test-write-result1~1ay%kV~30258 */
  twobit_setrtn( 2069, compiled_block_1_2069 );
  twobit_invoke( 2 );
  twobit_label( 2069, compiled_block_1_2069 );
  twobit_load( 0, 0 );
  twobit_skip( 2067, compiled_block_1_2067 );
  twobit_label( 2068, compiled_block_1_2068 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 2067, compiled_block_1_2067 );
  twobit_stack( 4 );
  twobit_branchf( 2071, compiled_block_1_2071 );
  twobit_load( 1, 4 );
  twobit_load( 2, 2 );
  twobit_global( 12 ); /*  %test-write-result1~1ay%kV~30258 */
  twobit_setrtn( 2072, compiled_block_1_2072 );
  twobit_invoke( 2 );
  twobit_label( 2072, compiled_block_1_2072 );
  twobit_load( 0, 0 );
  twobit_skip( 2070, compiled_block_1_2070 );
  twobit_label( 2071, compiled_block_1_2071 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 2070, compiled_block_1_2070 );
  twobit_stack( 3 );
  twobit_branchf( 2074, compiled_block_1_2074 );
  twobit_load( 1, 5 );
  twobit_load( 2, 2 );
  twobit_global( 12 ); /*  %test-write-result1~1ay%kV~30258 */
  twobit_pop( 5 );
  twobit_invoke( 2 );
  twobit_label( 2074, compiled_block_1_2074 );
  twobit_op1_3(); /* unspecified */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 2056, compiled_block_1_2056 );
  twobit_op1_3(); /* unspecified */
  twobit_pop( 5 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_72( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  test-result-alist~1ay%kV~30034 */
  twobit_setrtn( 2076, compiled_block_1_2076 );
  twobit_invoke( 1 );
  twobit_label( 2076, compiled_block_1_2076 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* assq */
  twobit_setrtn( 2077, compiled_block_1_2077 );
  twobit_invoke( 2 );
  twobit_label( 2077, compiled_block_1_2077 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2079, compiled_block_1_2079 );
  twobit_reg_op1_check_652(reg(4),2080,compiled_block_1_2080); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_skip( 2078, compiled_block_1_2078 );
  twobit_label( 2079, compiled_block_1_2079 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2078, compiled_block_1_2078 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 4 ); /*  test-runner-aux-value~1ay%kV~30035 */
  twobit_setrtn( 2081, compiled_block_1_2081 );
  twobit_invoke( 1 );
  twobit_label( 2081, compiled_block_1_2081 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 5 );
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_branchf_624( 3, 2083, compiled_block_1_2083 ); /* internal:branchf-eq? */
  twobit_const( 6 );
  twobit_skip( 2082, compiled_block_1_2082 );
  twobit_label( 2083, compiled_block_1_2083 );
  twobit_const( 6 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_const( 7 );
  twobit_setreg( 2 );
  twobit_stack( 2 );
  twobit_op2_branchf_624( 2, 2085, compiled_block_1_2085 ); /* internal:branchf-eq? */
  twobit_reg( 3 );
  twobit_skip( 2082, compiled_block_1_2082 );
  twobit_label( 2085, compiled_block_1_2085 );
  twobit_reg_op1_check_652(reg(3),2086,compiled_block_1_2086); /* internal:check-pair? with (3 0 0) */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2082, compiled_block_1_2082 );
  twobit_branchf( 2088, compiled_block_1_2088 );
  twobit_load( 1, 1 );
  twobit_global( 1 ); /*  test-result-alist~1ay%kV~30034 */
  twobit_setrtn( 2089, compiled_block_1_2089 );
  twobit_invoke( 1 );
  twobit_label( 2089, compiled_block_1_2089 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_movereg( 4, 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* assq */
  twobit_setrtn( 2090, compiled_block_1_2090 );
  twobit_invoke( 2 );
  twobit_label( 2090, compiled_block_1_2090 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_global( 3 ); /* assq */
  twobit_setrtn( 2091, compiled_block_1_2091 );
  twobit_invoke( 2 );
  twobit_label( 2091, compiled_block_1_2091 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_global( 3 ); /* assq */
  twobit_setrtn( 2092, compiled_block_1_2092 );
  twobit_invoke( 2 );
  twobit_label( 2092, compiled_block_1_2092 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_stack( 4 );
  twobit_branchf( 2094, compiled_block_1_2094 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2093, compiled_block_1_2093 );
  twobit_label( 2094, compiled_block_1_2094 );
  twobit_stack( 5 );
  twobit_label( 2093, compiled_block_1_2093 );
  twobit_branchf( 2096, compiled_block_1_2096 );
  twobit_stack( 4 );
  twobit_branchf( 2098, compiled_block_1_2098 );
  twobit_stack( 4 );
  twobit_op1_11(); /* pair? */
  twobit_load( 2, 4 );
  twobit_check( 2, 0, 0, 2099, compiled_block_1_2099 );
  twobit_stack( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_global( 11 ); /* display */
  twobit_setrtn( 2100, compiled_block_1_2100 );
  twobit_invoke( 1 );
  twobit_label( 2100, compiled_block_1_2100 );
  twobit_load( 0, 0 );
  twobit_skip( 2097, compiled_block_1_2097 );
  twobit_label( 2098, compiled_block_1_2098 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 2097, compiled_block_1_2097 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_global( 11 ); /* display */
  twobit_setrtn( 2101, compiled_block_1_2101 );
  twobit_invoke( 1 );
  twobit_label( 2101, compiled_block_1_2101 );
  twobit_load( 0, 0 );
  twobit_stack( 5 );
  twobit_branchf( 2103, compiled_block_1_2103 );
  twobit_stack( 5 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 5 );
  twobit_check( 3, 0, 0, 2086, compiled_block_1_2086 );
  twobit_stack( 5 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_global( 11 ); /* display */
  twobit_setrtn( 2104, compiled_block_1_2104 );
  twobit_invoke( 1 );
  twobit_label( 2104, compiled_block_1_2104 );
  twobit_load( 0, 0 );
  twobit_skip( 2102, compiled_block_1_2102 );
  twobit_label( 2103, compiled_block_1_2103 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 2102, compiled_block_1_2102 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_global( 11 ); /* display */
  twobit_setrtn( 2105, compiled_block_1_2105 );
  twobit_invoke( 1 );
  twobit_label( 2105, compiled_block_1_2105 );
  twobit_load( 0, 0 );
  twobit_skip( 2095, compiled_block_1_2095 );
  twobit_label( 2096, compiled_block_1_2096 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 2095, compiled_block_1_2095 );
  twobit_const( 7 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_branchf_624( 4, 2107, compiled_block_1_2107 ); /* internal:branchf-eq? */
  twobit_const( 14 );
  twobit_skip( 2106, compiled_block_1_2106 );
  twobit_label( 2107, compiled_block_1_2107 );
  twobit_const( 15 );
  twobit_label( 2106, compiled_block_1_2106 );
  twobit_setreg( 1 );
  twobit_global( 11 ); /* display */
  twobit_setrtn( 2108, compiled_block_1_2108 );
  twobit_invoke( 1 );
  twobit_label( 2108, compiled_block_1_2108 );
  twobit_load( 0, 0 );
  twobit_stack( 3 );
  twobit_branchf( 2110, compiled_block_1_2110 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_global( 11 ); /* display */
  twobit_setrtn( 2111, compiled_block_1_2111 );
  twobit_invoke( 1 );
  twobit_label( 2111, compiled_block_1_2111 );
  twobit_load( 0, 0 );
  twobit_stack( 3 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 3 );
  twobit_check( 3, 0, 0, 2086, compiled_block_1_2086 );
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_global( 11 ); /* display */
  twobit_setrtn( 2112, compiled_block_1_2112 );
  twobit_invoke( 1 );
  twobit_label( 2112, compiled_block_1_2112 );
  twobit_load( 0, 0 );
  twobit_skip( 2109, compiled_block_1_2109 );
  twobit_label( 2110, compiled_block_1_2110 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 2109, compiled_block_1_2109 );
  twobit_global( 17 ); /* newline */
  twobit_setrtn( 2113, compiled_block_1_2113 );
  twobit_invoke( 0 );
  twobit_label( 2113, compiled_block_1_2113 );
  twobit_load( 0, 0 );
  twobit_skip( 2087, compiled_block_1_2087 );
  twobit_label( 2088, compiled_block_1_2088 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 2087, compiled_block_1_2087 );
  twobit_load( 1, 6 );
  twobit_global( 18 ); /* output-port? */
  twobit_setrtn( 2114, compiled_block_1_2114 );
  twobit_invoke( 1 );
  twobit_label( 2114, compiled_block_1_2114 );
  twobit_load( 0, 0 );
  twobit_branchf( 2116, compiled_block_1_2116 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_load( 2, 6 );
  twobit_global( 11 ); /* display */
  twobit_setrtn( 2117, compiled_block_1_2117 );
  twobit_invoke( 2 );
  twobit_label( 2117, compiled_block_1_2117 );
  twobit_load( 0, 0 );
  twobit_load( 1, 6 );
  twobit_global( 17 ); /* newline */
  twobit_setrtn( 2118, compiled_block_1_2118 );
  twobit_invoke( 1 );
  twobit_label( 2118, compiled_block_1_2118 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 1 ); /*  test-result-alist~1ay%kV~30034 */
  twobit_setrtn( 2119, compiled_block_1_2119 );
  twobit_invoke( 1 );
  twobit_label( 2119, compiled_block_1_2119 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_global( 20 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 6 );
  twobit_lambda( compiled_start_1_120, 22, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 6 );
  twobit_invoke( 1 );
  twobit_label( 2116, compiled_block_1_2116 );
  twobit_op1_3(); /* unspecified */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 2086, compiled_block_1_2086 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_label( 2080, compiled_block_1_2080 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_label( 2099, compiled_block_1_2099 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_120( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2121, compiled_block_1_2121 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),2122,compiled_block_1_2122); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_const( 1 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2_branchf_624( 2, 2124, compiled_block_1_2124 ); /* internal:branchf-eq? */
  twobit_const( 2 );
  twobit_skip( 2123, compiled_block_1_2123 );
  twobit_label( 2124, compiled_block_1_2124 );
  twobit_const( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op2_branchf_624( 31, 2126, compiled_block_1_2126 ); /* internal:branchf-eq? */
  twobit_reg( 2 );
  twobit_skip( 2123, compiled_block_1_2123 );
  twobit_label( 2126, compiled_block_1_2126 );
  twobit_reg_op1_check_652(reg(2),2127,compiled_block_1_2127); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_const( 4 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op2_branchf_624( 31, 2129, compiled_block_1_2129 ); /* internal:branchf-eq? */
  twobit_reg( 2 );
  twobit_skip( 2123, compiled_block_1_2123 );
  twobit_label( 2129, compiled_block_1_2129 );
  twobit_reg_op1_check_652(reg(2),2127,compiled_block_1_2127); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_const( 5 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op2_branchf_624( 31, 2131, compiled_block_1_2131 ); /* internal:branchf-eq? */
  twobit_reg( 2 );
  twobit_skip( 2123, compiled_block_1_2123 );
  twobit_label( 2131, compiled_block_1_2131 );
  twobit_reg_op1_check_652(reg(2),2127,compiled_block_1_2127); /* internal:check-pair? with (2 0 0) */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2123, compiled_block_1_2123 );
  twobit_branchf( 2133, compiled_block_1_2133 );
  twobit_op1_3(); /* unspecified */
  twobit_skip( 2132, compiled_block_1_2132 );
  twobit_label( 2133, compiled_block_1_2133 );
  twobit_movereg( 4, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 6 ); /*  %test-write-result1~1ay%kV~30258 */
  twobit_setrtn( 2134, compiled_block_1_2134 );
  twobit_invoke( 2 );
  twobit_label( 2134, compiled_block_1_2134 );
  twobit_load( 0, 0 );
  twobit_label( 2132, compiled_block_1_2132 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 2121, compiled_block_1_2121 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 2122, compiled_block_1_2122 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 2127, compiled_block_1_2127 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_73( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* display */
  twobit_setrtn( 2137, compiled_block_1_2137 );
  twobit_invoke( 2 );
  twobit_label( 2137, compiled_block_1_2137 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 2138, compiled_block_1_2138 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 2 ); /* display */
  twobit_setrtn( 2139, compiled_block_1_2139 );
  twobit_invoke( 2 );
  twobit_label( 2139, compiled_block_1_2139 );
  twobit_load( 0, 0 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 2 ); /* display */
  twobit_setrtn( 2140, compiled_block_1_2140 );
  twobit_invoke( 2 );
  twobit_label( 2140, compiled_block_1_2140 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 4 ); /* write */
  twobit_setrtn( 2141, compiled_block_1_2141 );
  twobit_invoke( 2 );
  twobit_label( 2141, compiled_block_1_2141 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_global( 5 ); /* newline */
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 2138, compiled_block_1_2138 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_74( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_global( 1 ); /*  test-result-alist~1ay%kV~30034 */
  twobit_setrtn( 2143, compiled_block_1_2143 );
  twobit_invoke( 1 );
  twobit_label( 2143, compiled_block_1_2143 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 2 ); /* assq */
  twobit_setrtn( 2144, compiled_block_1_2144 );
  twobit_invoke( 2 );
  twobit_label( 2144, compiled_block_1_2144 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2146, compiled_block_1_2146 );
  twobit_load( 3, 2 );
  twobit_reg( 4 );
  twobit_op2_60( 3 ); /* set-cdr! */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2146, compiled_block_1_2146 );
  twobit_load( 3, 2 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 4 );
  twobit_global( 3 ); /*  test-result-alist!~1ay%kV~30056 */
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_75( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  test-result-alist!~1ay%kV~30056 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_76( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  test-result-alist~1ay%kV~30034 */
  twobit_setrtn( 2149, compiled_block_1_2149 );
  twobit_invoke( 1 );
  twobit_label( 2149, compiled_block_1_2149 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 2 ); /* assq */
  twobit_setrtn( 2150, compiled_block_1_2150 );
  twobit_invoke( 2 );
  twobit_label( 2150, compiled_block_1_2150 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2152, compiled_block_1_2152 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_119, 5, 2 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_setrtn( 2158, compiled_block_1_2158 );
  twobit_invoke( 1 );
  twobit_label( 2158, compiled_block_1_2158 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_global( 6 ); /*  test-result-alist!~1ay%kV~30056 */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 2152, compiled_block_1_2152 );
  twobit_op1_3(); /* unspecified */
  twobit_pop( 3 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_119( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 4, 2154, compiled_block_1_2154 ); /* internal:branchf-eq? */
  twobit_reg_op1_check_652(reg(1),2155,compiled_block_1_2155); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_return();
  twobit_label( 2154, compiled_block_1_2154 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg_op1_check_652(reg(1),2156,compiled_block_1_2156); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 2157, compiled_block_1_2157 );
  twobit_invoke( 1 );
  twobit_label( 2157, compiled_block_1_2157 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2155, compiled_block_1_2155 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_label( 2156, compiled_block_1_2156 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_77( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2161, compiled_block_1_2161 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 2160, compiled_block_1_2160 );
  twobit_label( 2161, compiled_block_1_2161 );
  twobit_global( 1 ); /*  %test-runner-current~1ay%kV~30066 */
  twobit_label( 2160, compiled_block_1_2160 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  test-result-alist~1ay%kV~30034 */
  twobit_setrtn( 2162, compiled_block_1_2162 );
  twobit_invoke( 1 );
  twobit_label( 2162, compiled_block_1_2162 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* assq */
  twobit_setrtn( 2163, compiled_block_1_2163 );
  twobit_invoke( 2 );
  twobit_label( 2163, compiled_block_1_2163 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2165, compiled_block_1_2165 );
  twobit_reg_op1_check_652(reg(4),2166,compiled_block_1_2166); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 2165, compiled_block_1_2165 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 2166, compiled_block_1_2166 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_78( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2168, compiled_block_1_2168 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 2167, compiled_block_1_2167 );
  twobit_label( 2168, compiled_block_1_2168 );
  twobit_global( 1 ); /*  test-runner-get~1ay%kV~30110 */
  twobit_setrtn( 2169, compiled_block_1_2169 );
  twobit_invoke( 0 );
  twobit_label( 2169, compiled_block_1_2169 );
  twobit_load( 0, 0 );
  twobit_label( 2167, compiled_block_1_2167 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  test-result-alist~1ay%kV~30034 */
  twobit_setrtn( 2170, compiled_block_1_2170 );
  twobit_invoke( 1 );
  twobit_label( 2170, compiled_block_1_2170 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* assq */
  twobit_setrtn( 2171, compiled_block_1_2171 );
  twobit_invoke( 2 );
  twobit_label( 2171, compiled_block_1_2171 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2173, compiled_block_1_2173 );
  twobit_reg_op1_check_652(reg(4),2174,compiled_block_1_2174); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_skip( 2172, compiled_block_1_2172 );
  twobit_label( 2173, compiled_block_1_2173 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2172, compiled_block_1_2172 );
  twobit_setreg( 4 );
  twobit_const( 5 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 2176, compiled_block_1_2176 ); /* internal:branchf-eq? */
  twobit_const( 6 );
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 2176, compiled_block_1_2176 );
  twobit_const( 6 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_const( 7 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 2, 2178, compiled_block_1_2178 ); /* internal:branchf-eq? */
  twobit_reg( 3 );
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 2178, compiled_block_1_2178 );
  twobit_reg_op1_check_652(reg(3),2179,compiled_block_1_2179); /* internal:check-pair? with (3 0 0) */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 2179, compiled_block_1_2179 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_label( 2174, compiled_block_1_2174 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_79( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  test-runner-get~1ay%kV~30110 */
  twobit_setrtn( 2180, compiled_block_1_2180 );
  twobit_invoke( 0 );
  twobit_label( 2180, compiled_block_1_2180 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 2 ); /*  test-result-kind~1ay%kV~30262 */
  twobit_setrtn( 2181, compiled_block_1_2181 );
  twobit_invoke( 1 );
  twobit_label( 2181, compiled_block_1_2181 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 2183, compiled_block_1_2183 ); /* internal:branchf-eq? */
  twobit_load( 1, 1 );
  twobit_global( 4 ); /*  test-runner-pass-count~1ay%kV~30014 */
  twobit_setrtn( 2184, compiled_block_1_2184 );
  twobit_invoke( 1 );
  twobit_label( 2184, compiled_block_1_2184 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 4, 113, compiled_temp_1_113 ); /* + */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /*  test-runner-pass-count!~1ay%kV~30036 */
  twobit_setrtn( 2185, compiled_block_1_2185 );
  twobit_invoke( 2 );
  twobit_label( 2185, compiled_block_1_2185 );
  twobit_load( 0, 0 );
  twobit_skip( 2182, compiled_block_1_2182 );
  twobit_label( 2183, compiled_block_1_2183 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 2187, compiled_block_1_2187 ); /* internal:branchf-eq? */
  twobit_load( 1, 1 );
  twobit_global( 7 ); /*  test-runner-fail-count~1ay%kV~30015 */
  twobit_setrtn( 2188, compiled_block_1_2188 );
  twobit_invoke( 1 );
  twobit_label( 2188, compiled_block_1_2188 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 4, 114, compiled_temp_1_114 ); /* + */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 8 ); /*  test-runner-fail-count!~1ay%kV~30037 */
  twobit_setrtn( 2189, compiled_block_1_2189 );
  twobit_invoke( 2 );
  twobit_label( 2189, compiled_block_1_2189 );
  twobit_load( 0, 0 );
  twobit_skip( 2182, compiled_block_1_2182 );
  twobit_label( 2187, compiled_block_1_2187 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 2191, compiled_block_1_2191 ); /* internal:branchf-eq? */
  twobit_load( 1, 1 );
  twobit_global( 10 ); /*  test-runner-xpass-count~1ay%kV~30016 */
  twobit_setrtn( 2192, compiled_block_1_2192 );
  twobit_invoke( 1 );
  twobit_label( 2192, compiled_block_1_2192 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 4, 115, compiled_temp_1_115 ); /* + */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 11 ); /*  test-runner-xpass-count!~1ay%kV~30038 */
  twobit_setrtn( 2193, compiled_block_1_2193 );
  twobit_invoke( 2 );
  twobit_label( 2193, compiled_block_1_2193 );
  twobit_load( 0, 0 );
  twobit_skip( 2182, compiled_block_1_2182 );
  twobit_label( 2191, compiled_block_1_2191 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 2195, compiled_block_1_2195 ); /* internal:branchf-eq? */
  twobit_load( 1, 1 );
  twobit_global( 13 ); /*  test-runner-xfail-count~1ay%kV~30017 */
  twobit_setrtn( 2196, compiled_block_1_2196 );
  twobit_invoke( 1 );
  twobit_label( 2196, compiled_block_1_2196 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 4, 116, compiled_temp_1_116 ); /* + */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 14 ); /*  test-runner-xfail-count!~1ay%kV~30039 */
  twobit_setrtn( 2197, compiled_block_1_2197 );
  twobit_invoke( 2 );
  twobit_label( 2197, compiled_block_1_2197 );
  twobit_load( 0, 0 );
  twobit_skip( 2182, compiled_block_1_2182 );
  twobit_label( 2195, compiled_block_1_2195 );
  twobit_load( 1, 1 );
  twobit_global( 15 ); /*  test-runner-skip-count~1ay%kV~30018 */
  twobit_setrtn( 2198, compiled_block_1_2198 );
  twobit_invoke( 1 );
  twobit_label( 2198, compiled_block_1_2198 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 4, 117, compiled_temp_1_117 ); /* + */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 16 ); /*  test-runner-skip-count!~1ay%kV~30040 */
  twobit_setrtn( 2199, compiled_block_1_2199 );
  twobit_invoke( 2 );
  twobit_label( 2199, compiled_block_1_2199 );
  twobit_load( 0, 0 );
  twobit_label( 2182, compiled_block_1_2182 );
  twobit_load( 1, 1 );
  twobit_global( 17 ); /*  %test-runner-total-count~1ay%kV~30032 */
  twobit_setrtn( 2200, compiled_block_1_2200 );
  twobit_invoke( 1 );
  twobit_label( 2200, compiled_block_1_2200 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 4, 118, compiled_temp_1_118 ); /* + */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 18 ); /*  %test-runner-total-count!~1ay%kV~30054 */
  twobit_setrtn( 2201, compiled_block_1_2201 );
  twobit_invoke( 2 );
  twobit_label( 2201, compiled_block_1_2201 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 19 ); /*  test-runner-on-test-end~1ay%kV~30026 */
  twobit_setrtn( 2202, compiled_block_1_2202 );
  twobit_invoke( 1 );
  twobit_label( 2202, compiled_block_1_2202 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_80( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_81( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  %test-should-execute~1ay%kV~30114 */
  twobit_setrtn( 2204, compiled_block_1_2204 );
  twobit_invoke( 1 );
  twobit_label( 2204, compiled_block_1_2204 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  test-runner-on-test-begin~1ay%kV~30025 */
  twobit_setrtn( 2205, compiled_block_1_2205 );
  twobit_invoke( 1 );
  twobit_label( 2205, compiled_block_1_2205 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 2206, compiled_block_1_2206 );
  twobit_invoke( 1 );
  twobit_label( 2206, compiled_block_1_2206 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  test-result-alist~1ay%kV~30034 */
  twobit_setrtn( 2207, compiled_block_1_2207 );
  twobit_invoke( 1 );
  twobit_label( 2207, compiled_block_1_2207 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /* assq */
  twobit_setrtn( 2208, compiled_block_1_2208 );
  twobit_invoke( 2 );
  twobit_label( 2208, compiled_block_1_2208 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2210, compiled_block_1_2210 );
  twobit_reg_op1_check_652(reg(4),2211,compiled_block_1_2211); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_skip( 2209, compiled_block_1_2209 );
  twobit_label( 2210, compiled_block_1_2210 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2209, compiled_block_1_2209 );
  twobit_setreg( 4 );
  twobit_const( 6 );
  twobit_op2_56( 4 ); /* eq? */
  twobit_op1_9(); /* not */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2211, compiled_block_1_2211 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_82( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  test-result-alist~1ay%kV~30034 */
  twobit_setrtn( 2212, compiled_block_1_2212 );
  twobit_invoke( 1 );
  twobit_label( 2212, compiled_block_1_2212 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* assq */
  twobit_setrtn( 2213, compiled_block_1_2213 );
  twobit_invoke( 2 );
  twobit_label( 2213, compiled_block_1_2213 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2215, compiled_block_1_2215 );
  twobit_reg_op1_check_652(reg(4),2216,compiled_block_1_2216); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_skip( 2214, compiled_block_1_2214 );
  twobit_label( 2215, compiled_block_1_2215 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2214, compiled_block_1_2214 );
  twobit_const_setreg( 4, 3 );
  twobit_op2_branchf_624( 3, 2218, compiled_block_1_2218 ); /* internal:branchf-eq? */
  twobit_stack( 1 );
  twobit_branchf( 2220, compiled_block_1_2220 );
  twobit_const( 5 );
  twobit_skip( 2217, compiled_block_1_2217 );
  twobit_label( 2220, compiled_block_1_2220 );
  twobit_const( 4 );
  twobit_skip( 2217, compiled_block_1_2217 );
  twobit_label( 2218, compiled_block_1_2218 );
  twobit_stack( 1 );
  twobit_branchf( 2222, compiled_block_1_2222 );
  twobit_const( 6 );
  twobit_skip( 2217, compiled_block_1_2217 );
  twobit_label( 2222, compiled_block_1_2222 );
  twobit_const( 7 );
  twobit_label( 2217, compiled_block_1_2217 );
  twobit_setreg( 3 );
  twobit_load( 1, 2 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_global( 8 ); /*  test-result-set!~1ay%kV~30259 */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 2216, compiled_block_1_2216 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_83( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  test-result-alist~1ay%kV~30034 */
  twobit_setrtn( 2224, compiled_block_1_2224 );
  twobit_invoke( 1 );
  twobit_label( 2224, compiled_block_1_2224 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* assq */
  twobit_setrtn( 2225, compiled_block_1_2225 );
  twobit_invoke( 2 );
  twobit_label( 2225, compiled_block_1_2225 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2227, compiled_block_1_2227 );
  twobit_reg_op1_check_652(reg(4),2228,compiled_block_1_2228); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 2227, compiled_block_1_2227 );
  twobit_const( 4 );
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 2228, compiled_block_1_2228 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_84( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_108, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_108( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_62( 4, 109, compiled_temp_1_109 ); /* - */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_621( 4, 110, compiled_temp_1_110, 2230, compiled_block_1_2230 ); /* internal:branchf->= */
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_61( 4, 111, compiled_temp_1_111 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_67( 4, 112, compiled_temp_1_112 ); /* <= */
  twobit_return();
  twobit_label( 2230, compiled_block_1_2230 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_85( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_global( 1 ); /*  test-runner?~1ay%kV~30012 */
  twobit_setrtn( 2231, compiled_block_1_2231 );
  twobit_invoke( 1 );
  twobit_label( 2231, compiled_block_1_2231 );
  twobit_load( 0, 0 );
  twobit_branchf( 2233, compiled_block_1_2233 );
  twobit_global( 2 ); /*  %test-runner-current~1ay%kV~30066 */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_102, 4, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 3 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_103, 6, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_104, 8, 1 );
  twobit_setreg( 3 );
  twobit_load( 1, 3 );
  twobit_global( 9 ); /* dynamic-wind */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 2233, compiled_block_1_2233 );
  twobit_global( 2 ); /*  %test-runner-current~1ay%kV~30066 */
  twobit_branchf( 2237, compiled_block_1_2237 );
  twobit_global( 2 ); /*  %test-runner-current~1ay%kV~30066 */
  twobit_setreg( 1 );
  twobit_global( 10 ); /*  %test-runner-run-list~1ay%kV~30021 */
  twobit_setrtn( 2238, compiled_block_1_2238 );
  twobit_invoke( 1 );
  twobit_label( 2238, compiled_block_1_2238 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_stack( 2 );
  twobit_op1_branchf_610( 2240, compiled_block_1_2240 ); /* internal:branchf-null? */
  twobit_movereg( 4, 1 );
  twobit_global( 11 ); /*  reverse!~1ay%kV~29922 */
  twobit_setrtn( 2241, compiled_block_1_2241 );
  twobit_invoke( 1 );
  twobit_label( 2241, compiled_block_1_2241 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %test-runner-current~1ay%kV~30066 */
  twobit_setreg( 1 );
  twobit_global( 12 ); /*  %test-runner-run-list!~1ay%kV~30043 */
  twobit_setrtn( 2242, compiled_block_1_2242 );
  twobit_invoke( 2 );
  twobit_label( 2242, compiled_block_1_2242 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 0 );
  twobit_label( 2240, compiled_block_1_2240 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( TRUE_CONST, 2245, compiled_block_1_2245 ); /* internal:branchf-eq?/imm */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_skip( 2244, compiled_block_1_2244 );
  twobit_label( 2245, compiled_block_1_2245 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_label( 2244, compiled_block_1_2244 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  %test-runner-current~1ay%kV~30066 */
  twobit_setreg( 1 );
  twobit_global( 12 ); /*  %test-runner-run-list!~1ay%kV~30043 */
  twobit_setrtn( 2246, compiled_block_1_2246 );
  twobit_invoke( 2 );
  twobit_label( 2246, compiled_block_1_2246 );
  twobit_load( 0, 0 );
  twobit_global( 13 ); /*  test-apply~1ay%kV~30572 */
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 14 ); /* apply */
  twobit_setrtn( 2247, compiled_block_1_2247 );
  twobit_invoke( 2 );
  twobit_label( 2247, compiled_block_1_2247 );
  twobit_load( 0, 0 );
  twobit_global( 2 ); /*  %test-runner-current~1ay%kV~30066 */
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_global( 12 ); /*  %test-runner-run-list!~1ay%kV~30043 */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 2237, compiled_block_1_2237 );
  twobit_global( 15 ); /*  test-runner-create~1ay%kV~30112 */
  twobit_setrtn( 2249, compiled_block_1_2249 );
  twobit_invoke( 0 );
  twobit_label( 2249, compiled_block_1_2249 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 2, 2 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_105, 17, 2 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_106, 19, 1 );
  twobit_setreg( 1 );
  twobit_lambda( compiled_start_1_107, 21, 0 );
  twobit_setreg( 3 );
  twobit_global( 9 ); /* dynamic-wind */
  twobit_setrtn( 2251, compiled_block_1_2251 );
  twobit_invoke( 3 );
  twobit_label( 2251, compiled_block_1_2251 );
  twobit_load( 0, 0 );
  twobit_load( 1, 3 );
  twobit_global( 22 ); /*  test-runner-on-final~1ay%kV~30029 */
  twobit_setrtn( 2252, compiled_block_1_2252 );
  twobit_invoke( 1 );
  twobit_label( 2252, compiled_block_1_2252 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_102( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setglbl( 1 ); /*  %test-runner-current~1ay%kV~30066 */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_103( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  test-apply~1ay%kV~30572 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* apply */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_104( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setglbl( 1 ); /*  %test-runner-current~1ay%kV~30066 */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_105( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /*  test-apply~1ay%kV~30572 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /* apply */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_106( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setglbl( 1 ); /*  %test-runner-current~1ay%kV~30066 */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_107( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setglbl( 1 ); /*  %test-runner-current~1ay%kV~30066 */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_86( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_97, 2, 3 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_97( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_op2imm_130( fixnum(1), 98, compiled_temp_1_98 ); /* + */
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_621( 3, 99, compiled_temp_1_99, 2255, compiled_block_1_2255 ); /* internal:branchf->= */
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op2_61( 3, 100, compiled_temp_1_100 ); /* + */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_66( 3, 101, compiled_temp_1_101 ); /* < */
  twobit_return();
  twobit_label( 2255, compiled_block_1_2255 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_87( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_lambda( compiled_start_1_95, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_95( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_96, 3, 3 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_96( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 2257, compiled_block_1_2257 ); /* internal:branchf-null? */
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_return();
  twobit_label( 2257, compiled_block_1_2257 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg_op1_check_652(reg(1),2258,compiled_block_1_2258); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 2259, compiled_block_1_2259 );
  twobit_invoke( 1 );
  twobit_label( 2259, compiled_block_1_2259 );
  twobit_load( 0, 0 );
  twobit_branchf( 2261, compiled_block_1_2261 );
  twobit_op1_3(); /* unspecified */
  twobit_skip( 2260, compiled_block_1_2260 );
  twobit_label( 2261, compiled_block_1_2261 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_label( 2260, compiled_block_1_2260 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 2258, compiled_block_1_2258 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_88( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_lambda( compiled_start_1_93, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_93( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_94, 3, 3 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_94( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 2265, compiled_block_1_2265 ); /* internal:branchf-null? */
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_return();
  twobit_label( 2265, compiled_block_1_2265 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg_op1_check_652(reg(1),2266,compiled_block_1_2266); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 2267, compiled_block_1_2267 );
  twobit_invoke( 1 );
  twobit_label( 2267, compiled_block_1_2267 );
  twobit_load( 0, 0 );
  twobit_branchf( 2269, compiled_block_1_2269 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_skip( 2268, compiled_block_1_2268 );
  twobit_label( 2269, compiled_block_1_2269 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 2268, compiled_block_1_2268 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 2266, compiled_block_1_2266 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_89( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 2273, compiled_block_1_2273 );
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 2273, compiled_block_1_2273 );
  twobit_reg( 1 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 2275, compiled_block_1_2275 );
  twobit_movereg( 1, 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %test-match-nth~1ay%kV~30589 */
  twobit_invoke( 2 );
  twobit_label( 2275, compiled_block_1_2275 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 2278, compiled_block_1_2278 );
  twobit_global( 2 ); /*  test-match-name~1ay%kV~30672 */
  twobit_invoke( 1 );
  twobit_label( 2278, compiled_block_1_2278 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* error */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_90( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_92, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_92( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  test-runner-test-name~1ay%kV~30289 */
  twobit_setrtn( 2281, compiled_block_1_2281 );
  twobit_invoke( 1 );
  twobit_label( 2281, compiled_block_1_2281 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* equal? */
  twobit_pop( 0 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_91( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* open-input-string */
  twobit_setrtn( 2283, compiled_block_1_2283 );
  twobit_invoke( 1 );
  twobit_label( 2283, compiled_block_1_2283 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 2 ); /* read */
  twobit_setrtn( 2284, compiled_block_1_2284 );
  twobit_invoke( 1 );
  twobit_label( 2284, compiled_block_1_2284 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 1 );
  twobit_op1_13(); /* port? */
  twobit_load( 2, 1 );
  twobit_check( 2, 0, 0, 2285, compiled_block_1_2285 );
  twobit_stack( 1 );
  twobit_op2imm_450( fixnum(2) ); /* vector-ref:trusted */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2imm_450( fixnum(1) ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_stack( 1 );
  twobit_op2imm_450( fixnum(0) ); /* vector-ref:trusted */
  twobit_op2imm_branchf_640( fixnum(3), 2287, compiled_block_1_2287 ); /* internal:branchf-eq?/imm */
  twobit_reg_op1_check_651(reg(3),2288,compiled_block_1_2288); /* internal:check-fixnum? with (3 2 0) */
  twobit_reg( 2 );
  twobit_op1_43(); /* bytevector? */
  twobit_check( 3, 2, 0, 2288, compiled_block_1_2288 );
  twobit_reg( 2 );
  twobit_op1_102(); /* bytevector-like-length */
  twobit_setreg( 1 );
  twobit_reg_op2_check_661(reg(3),reg(1),2288,compiled_block_1_2288); /* internal:check-range with (3 2 0) */
  twobit_reg( 2 );
  twobit_op2_96( 3 ); /* bytevector-like-ref */
  twobit_skip( 2286, compiled_block_1_2286 );
  twobit_label( 2287, compiled_block_1_2287 );
  twobit_imm_const( fixnum(255) ); /* 255 */
  twobit_label( 2286, compiled_block_1_2286 );
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(13) ); /* 13 */
  twobit_op2_407( 1 ); /* <:fix:fix */
  twobit_branchf( 2290, compiled_block_1_2290 );
  twobit_reg( 1 );
  twobit_op2imm_452( fixnum(128) ); /* <:fix:fix */
  twobit_skip( 2289, compiled_block_1_2289 );
  twobit_label( 2290, compiled_block_1_2290 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2289, compiled_block_1_2289 );
  twobit_branchf( 2292, compiled_block_1_2292 );
  twobit_reg( 3 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op3_403( 4, 2 ); /* vector-set!:trusted:nwb */
  twobit_reg( 1 );
  twobit_op1_38(); /* integer->char */
  twobit_skip( 2291, compiled_block_1_2291 );
  twobit_label( 2292, compiled_block_1_2292 );
  twobit_load( 1, 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 3 ); /* io/get-char */
  twobit_setrtn( 2293, compiled_block_1_2293 );
  twobit_invoke( 2 );
  twobit_label( 2293, compiled_block_1_2293 );
  twobit_load( 0, 0 );
  twobit_label( 2291, compiled_block_1_2291 );
  twobit_op1_branchf_613( 2295, compiled_block_1_2295 ); /* internal:branchf-eof-object? */
  twobit_const( 4 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /* ex:environment */
  twobit_setrtn( 2296, compiled_block_1_2296 );
  twobit_invoke( 1 );
  twobit_label( 2296, compiled_block_1_2296 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /* ex:eval */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 2295, compiled_block_1_2295 );
  twobit_const( 7 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2288, compiled_block_1_2288 );
  twobit_trap( 2, 3, 0, 70 );
  twobit_label( 2285, compiled_block_1_2285 );
  twobit_trap( 2, 0, 0, 112 );
  twobit_epilogue();
}


RTYPE twobit_thunk_383aa0261d53ea7e2d11c5d2d14dba21_0(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_1_0(CONT_ACTUALS));
}
static RTYPE compiled_block_2_1004( CONT_PARAMS );
static RTYPE compiled_block_2_1003( CONT_PARAMS );
static RTYPE compiled_start_2_0( CONT_PARAMS );
static RTYPE compiled_start_2_3( CONT_PARAMS );
static RTYPE compiled_start_2_2( CONT_PARAMS );
static RTYPE compiled_start_2_1( CONT_PARAMS );

static RTYPE compiled_start_2_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_2_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_2_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1003, compiled_block_2_1003 );
  twobit_invoke( 8 );
  twobit_label( 1003, compiled_block_2_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1004, compiled_block_2_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_2_1004 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_383aa0261d53ea7e2d11c5d2d14dba21_1(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_2_0(CONT_ACTUALS));
}
codeptr_t CDECL twobit_load_table[] = { 
  twobit_thunk_383aa0261d53ea7e2d11c5d2d14dba21_0,
  twobit_thunk_383aa0261d53ea7e2d11c5d2d14dba21_1,
  0  /* The table may be empty; some compilers complain */
};

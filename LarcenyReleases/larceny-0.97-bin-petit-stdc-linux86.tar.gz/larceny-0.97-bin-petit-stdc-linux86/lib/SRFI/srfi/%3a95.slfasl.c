/* Generated from /home/henchman/larcenytest/larceny-petit-Nightly-2009-08-19/larceny_src/lib/SRFI/srfi/%3a95.slfasl */
#include "petit-instr.h"

static RTYPE compiled_block_1_1188( CONT_PARAMS );
static RTYPE compiled_block_1_1187( CONT_PARAMS );
static RTYPE compiled_start_1_0( CONT_PARAMS );
static RTYPE compiled_start_1_3( CONT_PARAMS );
static RTYPE compiled_block_1_1170( CONT_PARAMS );
static RTYPE compiled_block_1_1184( CONT_PARAMS );
static RTYPE compiled_block_1_1173( CONT_PARAMS );
static RTYPE compiled_block_1_1177( CONT_PARAMS );
static RTYPE compiled_block_1_1176( CONT_PARAMS );
static RTYPE compiled_block_1_1175( CONT_PARAMS );
static RTYPE compiled_block_1_1174( CONT_PARAMS );
static RTYPE compiled_block_1_1171( CONT_PARAMS );
static RTYPE compiled_block_1_1168( CONT_PARAMS );
static RTYPE compiled_block_1_1169( CONT_PARAMS );
static RTYPE compiled_start_1_11( CONT_PARAMS );
static RTYPE compiled_block_1_1180( CONT_PARAMS );
static RTYPE compiled_temp_1_13( CONT_PARAMS );
static RTYPE compiled_block_1_1181( CONT_PARAMS );
static RTYPE compiled_block_1_1179( CONT_PARAMS );
static RTYPE compiled_start_1_12( CONT_PARAMS );
static RTYPE compiled_block_1_1145( CONT_PARAMS );
static RTYPE compiled_block_1_1159( CONT_PARAMS );
static RTYPE compiled_block_1_1167( CONT_PARAMS );
static RTYPE compiled_block_1_1160( CONT_PARAMS );
static RTYPE compiled_block_1_1158( CONT_PARAMS );
static RTYPE compiled_block_1_1148( CONT_PARAMS );
static RTYPE compiled_block_1_1151( CONT_PARAMS );
static RTYPE compiled_block_1_1150( CONT_PARAMS );
static RTYPE compiled_block_1_1149( CONT_PARAMS );
static RTYPE compiled_block_1_1146( CONT_PARAMS );
static RTYPE compiled_block_1_1143( CONT_PARAMS );
static RTYPE compiled_block_1_1144( CONT_PARAMS );
static RTYPE compiled_start_1_10( CONT_PARAMS );
static RTYPE compiled_block_1_1164( CONT_PARAMS );
static RTYPE compiled_block_1_1161( CONT_PARAMS );
static RTYPE compiled_block_1_1165( CONT_PARAMS );
static RTYPE compiled_block_1_1163( CONT_PARAMS );
static RTYPE compiled_start_1_15( CONT_PARAMS );
static RTYPE compiled_block_1_1154( CONT_PARAMS );
static RTYPE compiled_temp_1_16( CONT_PARAMS );
static RTYPE compiled_block_1_1155( CONT_PARAMS );
static RTYPE compiled_block_1_1153( CONT_PARAMS );
static RTYPE compiled_start_1_14( CONT_PARAMS );
static RTYPE compiled_block_1_1137( CONT_PARAMS );
static RTYPE compiled_temp_1_17( CONT_PARAMS );
static RTYPE compiled_block_1_1136( CONT_PARAMS );
static RTYPE compiled_start_1_9( CONT_PARAMS );
static RTYPE compiled_block_1_1140( CONT_PARAMS );
static RTYPE compiled_temp_1_20( CONT_PARAMS );
static RTYPE compiled_block_1_1139( CONT_PARAMS );
static RTYPE compiled_temp_1_19( CONT_PARAMS );
static RTYPE compiled_start_1_18( CONT_PARAMS );
static RTYPE compiled_block_1_1134( CONT_PARAMS );
static RTYPE compiled_block_1_1129( CONT_PARAMS );
static RTYPE compiled_block_1_1133( CONT_PARAMS );
static RTYPE compiled_block_1_1132( CONT_PARAMS );
static RTYPE compiled_block_1_1131( CONT_PARAMS );
static RTYPE compiled_block_1_1130( CONT_PARAMS );
static RTYPE compiled_block_1_1100( CONT_PARAMS );
static RTYPE compiled_block_1_1101( CONT_PARAMS );
static RTYPE compiled_start_1_8( CONT_PARAMS );
static RTYPE compiled_block_1_1125( CONT_PARAMS );
static RTYPE compiled_block_1_1126( CONT_PARAMS );
static RTYPE compiled_block_1_1124( CONT_PARAMS );
static RTYPE compiled_start_1_23( CONT_PARAMS );
static RTYPE compiled_block_1_1120( CONT_PARAMS );
static RTYPE compiled_block_1_1121( CONT_PARAMS );
static RTYPE compiled_block_1_1119( CONT_PARAMS );
static RTYPE compiled_start_1_22( CONT_PARAMS );
static RTYPE compiled_block_1_1110( CONT_PARAMS );
static RTYPE compiled_block_1_1109( CONT_PARAMS );
static RTYPE compiled_block_1_1117( CONT_PARAMS );
static RTYPE compiled_temp_1_28( CONT_PARAMS );
static RTYPE compiled_block_1_1108( CONT_PARAMS );
static RTYPE compiled_block_1_1114( CONT_PARAMS );
static RTYPE compiled_block_1_1115( CONT_PARAMS );
static RTYPE compiled_block_1_1113( CONT_PARAMS );
static RTYPE compiled_block_1_1112( CONT_PARAMS );
static RTYPE compiled_block_1_1111( CONT_PARAMS );
static RTYPE compiled_temp_1_27( CONT_PARAMS );
static RTYPE compiled_block_1_1103( CONT_PARAMS );
static RTYPE compiled_block_1_1105( CONT_PARAMS );
static RTYPE compiled_temp_1_26( CONT_PARAMS );
static RTYPE compiled_block_1_1104( CONT_PARAMS );
static RTYPE compiled_temp_1_25( CONT_PARAMS );
static RTYPE compiled_temp_1_24( CONT_PARAMS );
static RTYPE compiled_start_1_21( CONT_PARAMS );
static RTYPE compiled_block_1_1098( CONT_PARAMS );
static RTYPE compiled_block_1_1096( CONT_PARAMS );
static RTYPE compiled_block_1_1097( CONT_PARAMS );
static RTYPE compiled_start_1_7( CONT_PARAMS );
static RTYPE compiled_block_1_1070( CONT_PARAMS );
static RTYPE compiled_block_1_1089( CONT_PARAMS );
static RTYPE compiled_block_1_1068( CONT_PARAMS );
static RTYPE compiled_block_1_1077( CONT_PARAMS );
static RTYPE compiled_block_1_1094( CONT_PARAMS );
static RTYPE compiled_block_1_1093( CONT_PARAMS );
static RTYPE compiled_block_1_1086( CONT_PARAMS );
static RTYPE compiled_block_1_1090( CONT_PARAMS );
static RTYPE compiled_block_1_1088( CONT_PARAMS );
static RTYPE compiled_block_1_1084( CONT_PARAMS );
static RTYPE compiled_block_1_1062( CONT_PARAMS );
static RTYPE compiled_block_1_1080( CONT_PARAMS );
static RTYPE compiled_block_1_1083( CONT_PARAMS );
static RTYPE compiled_block_1_1082( CONT_PARAMS );
static RTYPE compiled_block_1_1081( CONT_PARAMS );
static RTYPE compiled_block_1_1074( CONT_PARAMS );
static RTYPE compiled_block_1_1075( CONT_PARAMS );
static RTYPE compiled_block_1_1079( CONT_PARAMS );
static RTYPE compiled_block_1_1078( CONT_PARAMS );
static RTYPE compiled_block_1_1076( CONT_PARAMS );
static RTYPE compiled_block_1_1072( CONT_PARAMS );
static RTYPE compiled_block_1_1071( CONT_PARAMS );
static RTYPE compiled_block_1_1069( CONT_PARAMS );
static RTYPE compiled_block_1_1067( CONT_PARAMS );
static RTYPE compiled_block_1_1065( CONT_PARAMS );
static RTYPE compiled_start_1_6( CONT_PARAMS );
static RTYPE compiled_block_1_1045( CONT_PARAMS );
static RTYPE compiled_block_1_1046( CONT_PARAMS );
static RTYPE compiled_block_1_1040( CONT_PARAMS );
static RTYPE compiled_block_1_1048( CONT_PARAMS );
static RTYPE compiled_block_1_1047( CONT_PARAMS );
static RTYPE compiled_block_1_1044( CONT_PARAMS );
static RTYPE compiled_block_1_1042( CONT_PARAMS );
static RTYPE compiled_block_1_1038( CONT_PARAMS );
static RTYPE compiled_block_1_1039( CONT_PARAMS );
static RTYPE compiled_start_1_5( CONT_PARAMS );
static RTYPE compiled_block_1_1054( CONT_PARAMS );
static RTYPE compiled_block_1_1060( CONT_PARAMS );
static RTYPE compiled_block_1_1059( CONT_PARAMS );
static RTYPE compiled_block_1_1058( CONT_PARAMS );
static RTYPE compiled_block_1_1051( CONT_PARAMS );
static RTYPE compiled_block_1_1056( CONT_PARAMS );
static RTYPE compiled_block_1_1055( CONT_PARAMS );
static RTYPE compiled_block_1_1053( CONT_PARAMS );
static RTYPE compiled_block_1_1049( CONT_PARAMS );
static RTYPE compiled_start_1_29( CONT_PARAMS );
static RTYPE compiled_block_1_1004( CONT_PARAMS );
static RTYPE compiled_block_1_1011( CONT_PARAMS );
static RTYPE compiled_block_1_1025( CONT_PARAMS );
static RTYPE compiled_block_1_1028( CONT_PARAMS );
static RTYPE compiled_block_1_1027( CONT_PARAMS );
static RTYPE compiled_block_1_1009( CONT_PARAMS );
static RTYPE compiled_block_1_1015( CONT_PARAMS );
static RTYPE compiled_block_1_1014( CONT_PARAMS );
static RTYPE compiled_temp_1_32( CONT_PARAMS );
static RTYPE compiled_block_1_1013( CONT_PARAMS );
static RTYPE compiled_temp_1_31( CONT_PARAMS );
static RTYPE compiled_temp_1_30( CONT_PARAMS );
static RTYPE compiled_block_1_1010( CONT_PARAMS );
static RTYPE compiled_block_1_1007( CONT_PARAMS );
static RTYPE compiled_block_1_1006( CONT_PARAMS );
static RTYPE compiled_block_1_1002( CONT_PARAMS );
static RTYPE compiled_block_1_1003( CONT_PARAMS );
static RTYPE compiled_start_1_4( CONT_PARAMS );
static RTYPE compiled_block_1_1031( CONT_PARAMS );
static RTYPE compiled_block_1_1035( CONT_PARAMS );
static RTYPE compiled_block_1_1033( CONT_PARAMS );
static RTYPE compiled_block_1_1032( CONT_PARAMS );
static RTYPE compiled_block_1_1030( CONT_PARAMS );
static RTYPE compiled_start_1_34( CONT_PARAMS );
static RTYPE compiled_temp_1_36( CONT_PARAMS );
static RTYPE compiled_block_1_1022( CONT_PARAMS );
static RTYPE compiled_block_1_1020( CONT_PARAMS );
static RTYPE compiled_block_1_1019( CONT_PARAMS );
static RTYPE compiled_block_1_1018( CONT_PARAMS );
static RTYPE compiled_block_1_1017( CONT_PARAMS );
static RTYPE compiled_temp_1_35( CONT_PARAMS );
static RTYPE compiled_start_1_33( CONT_PARAMS );
static RTYPE compiled_start_1_2( CONT_PARAMS );
static RTYPE compiled_start_1_1( CONT_PARAMS );

static RTYPE compiled_start_1_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 2 ); /*  sort~1ay%kV~38450 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 3 ); /*  sort!~1ay%kV~38449 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 4 ); /*  rank-1-array->list~1ay%kV~38448 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 5 ); /*  sort:sort-list!~1ay%kV~38447 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 6 ); /*  merge!~1ay%kV~38446 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 7 ); /*  sort:merge!~1ay%kV~38445 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 8 ); /*  merge~1ay%kV~38444 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 9 ); /*  sorted?~1ay%kV~38443 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 10 ); /*  identity~1ay%kV~38442 */
  twobit_lambda( compiled_start_1_1, 12, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_2, 14, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_3, 16, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 17 );
  twobit_setreg( 1 );
  twobit_const( 18 );
  twobit_setreg( 3 );
  twobit_const( 19 );
  twobit_setreg( 4 );
  twobit_const( 20 );
  twobit_setreg( 5 );
  twobit_const( 21 );
  twobit_setreg( 8 );
  twobit_global( 22 ); /* ex:make-library */
  twobit_setrtn( 1187, compiled_block_1_1187 );
  twobit_invoke( 8 );
  twobit_label( 1187, compiled_block_1_1187 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 23 ); /* ex:register-library! */
  twobit_setrtn( 1188, compiled_block_1_1188 );
  twobit_invoke( 1 );
  twobit_label( 1188, compiled_block_1_1188 );
  twobit_load( 0, 0 );
  twobit_global( 24 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 2 ); /*  sort~1ay%kV~38450 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 3 ); /*  sort!~1ay%kV~38449 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 4 ); /*  rank-1-array->list~1ay%kV~38448 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 5 ); /*  sort:sort-list!~1ay%kV~38447 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 6 ); /*  merge!~1ay%kV~38446 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 7 ); /*  sort:merge!~1ay%kV~38445 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 8 ); /*  merge~1ay%kV~38444 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 9 ); /*  sorted?~1ay%kV~38443 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 10 ); /*  identity~1ay%kV~38442 */
  twobit_global( 11 ); /* values */
  twobit_setglbl( 10 ); /*  identity~1ay%kV~38442 */
  twobit_lambda( compiled_start_1_4, 13, 0 );
  twobit_setglbl( 9 ); /*  sorted?~1ay%kV~38443 */
  twobit_lambda( compiled_start_1_5, 15, 0 );
  twobit_setglbl( 8 ); /*  merge~1ay%kV~38444 */
  twobit_lambda( compiled_start_1_6, 17, 0 );
  twobit_setglbl( 7 ); /*  sort:merge!~1ay%kV~38445 */
  twobit_lambda( compiled_start_1_7, 19, 0 );
  twobit_setglbl( 6 ); /*  merge!~1ay%kV~38446 */
  twobit_lambda( compiled_start_1_8, 21, 0 );
  twobit_setglbl( 5 ); /*  sort:sort-list!~1ay%kV~38447 */
  twobit_lambda( compiled_start_1_9, 23, 0 );
  twobit_setglbl( 4 ); /*  rank-1-array->list~1ay%kV~38448 */
  twobit_lambda( compiled_start_1_10, 25, 0 );
  twobit_setglbl( 3 ); /*  sort!~1ay%kV~38449 */
  twobit_lambda( compiled_start_1_11, 27, 0 );
  twobit_setglbl( 2 ); /*  sort~1ay%kV~38450 */
  twobit_global( 11 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_reg( 3 );
  twobit_op1_branchf_610( 1003, compiled_block_1_1003 ); /* internal:branchf-null? */
  twobit_global( 1 ); /*  identity~1ay%kV~38442 */
  twobit_skip( 1002, compiled_block_1_1002 );
  twobit_label( 1003, compiled_block_1_1003 );
  twobit_reg_op1_check_652(reg(3),1004,compiled_block_1_1004); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_label( 1002, compiled_block_1_1002 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1006, compiled_block_1_1006 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_return();
  twobit_label( 1006, compiled_block_1_1006 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 3 );
  twobit_store( 4, 2 );
  twobit_global( 2 ); /*  array?~1ay%kV~29347 */
  twobit_setrtn( 1007, compiled_block_1_1007 );
  twobit_invoke( 1 );
  twobit_label( 1007, compiled_block_1_1007 );
  twobit_load( 0, 0 );
  twobit_branchf( 1009, compiled_block_1_1009 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  array-dimensions~1ay%kV~29350 */
  twobit_setrtn( 1010, compiled_block_1_1010 );
  twobit_invoke( 1 );
  twobit_label( 1010, compiled_block_1_1010 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1011,compiled_block_1_1011); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 4, 30, compiled_temp_1_30 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_133( fixnum(1), 31, compiled_temp_1_31 ); /* <= */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_branchf( 1013, compiled_block_1_1013 );
  twobit_reg( 3 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1013, compiled_block_1_1013 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 4, 32, compiled_temp_1_32 ); /* + */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_load( 1, 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 4 ); /*  array-ref~1ay%kV~29360 */
  twobit_setrtn( 1014, compiled_block_1_1014 );
  twobit_invoke( 2 );
  twobit_label( 1014, compiled_block_1_1014 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_setrtn( 1015, compiled_block_1_1015 );
  twobit_invoke( 1 );
  twobit_label( 1015, compiled_block_1_1015 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_global( 5 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 4, 1 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_33, 7, 4 );
  twobit_setreg( 4 );
  twobit_load( 2, 4 );
  twobit_load( 1, 5 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 5 );
  twobit_invoke( 2 );
  twobit_label( 1009, compiled_block_1_1009 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1025, compiled_block_1_1025 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_610( 1027, compiled_block_1_1027 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1027, compiled_block_1_1027 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_setrtn( 1028, compiled_block_1_1028 );
  twobit_invoke( 1 );
  twobit_label( 1028, compiled_block_1_1028 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_global( 5 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_load( 2, 3 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_34, 9, 3 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 2, 4 );
  twobit_reg( 4 );
  twobit_pop( 5 );
  twobit_invoke( 2 );
  twobit_label( 1025, compiled_block_1_1025 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_label( 1011, compiled_block_1_1011 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 1004, compiled_block_1_1004 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_33( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op2imm_132( fixnum(0), 35, compiled_temp_1_35 ); /* < */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1017, compiled_block_1_1017 );
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1017, compiled_block_1_1017 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  array-ref~1ay%kV~29360 */
  twobit_setrtn( 1018, compiled_block_1_1018 );
  twobit_invoke( 2 );
  twobit_label( 1018, compiled_block_1_1018 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1019, compiled_block_1_1019 );
  twobit_invoke( 1 );
  twobit_label( 1019, compiled_block_1_1019 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_movereg( 4, 2 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1020, compiled_block_1_1020 );
  twobit_invoke( 2 );
  twobit_label( 1020, compiled_block_1_1020 );
  twobit_load( 0, 0 );
  twobit_branchf( 1022, compiled_block_1_1022 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1022, compiled_block_1_1022 );
  twobit_load( 4, 2 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 4, 36, compiled_temp_1_36 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_34( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_10(); /* null? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1030, compiled_block_1_1030 );
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1030, compiled_block_1_1030 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_reg_op1_check_652(reg(2),1031,compiled_block_1_1031); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_setrtn( 1032, compiled_block_1_1032 );
  twobit_invoke( 1 );
  twobit_label( 1032, compiled_block_1_1032 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1033, compiled_block_1_1033 );
  twobit_invoke( 2 );
  twobit_label( 1033, compiled_block_1_1033 );
  twobit_load( 0, 0 );
  twobit_branchf( 1035, compiled_block_1_1035 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1035, compiled_block_1_1035 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1031, compiled_block_1_1031 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_610( 1039, compiled_block_1_1039 ); /* internal:branchf-null? */
  twobit_global( 1 ); /*  identity~1ay%kV~38442 */
  twobit_skip( 1038, compiled_block_1_1038 );
  twobit_label( 1039, compiled_block_1_1039 );
  twobit_reg_op1_check_652(reg(4),1040,compiled_block_1_1040); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_label( 1038, compiled_block_1_1038 );
  twobit_setreg( 31 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1042, compiled_block_1_1042 ); /* internal:branchf-null? */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1042, compiled_block_1_1042 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1044, compiled_block_1_1044 ); /* internal:branchf-null? */
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1044, compiled_block_1_1044 );
  twobit_save( 9 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_store( 3, 6 );
  twobit_store( 31, 2 );
  twobit_reg_op1_check_652(reg(1),1045,compiled_block_1_1045); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 7 );
  twobit_movereg( 4, 1 );
  twobit_reg_op1_check_652(reg(2),1046,compiled_block_1_1046); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_store( 30, 4 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 29 );
  twobit_store( 29, 5 );
  twobit_reg( 31 );
  twobit_setrtn( 1047, compiled_block_1_1047 );
  twobit_invoke( 1 );
  twobit_label( 1047, compiled_block_1_1047 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_setrtn( 1048, compiled_block_1_1048 );
  twobit_invoke( 1 );
  twobit_label( 1048, compiled_block_1_1048 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_load( 2, 3 );
  twobit_store( 2, 1 );
  twobit_load( 4, 4 );
  twobit_stack( 5 );
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 1 );
  twobit_load( 3, 6 );
  twobit_load( 2, 2 );
  twobit_lambda( compiled_start_1_29, 4, 3 );
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_load( 3, 7 );
  twobit_load( 2, 2 );
  twobit_reg( 1 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_movereg( 2, 7 );
  twobit_load( 1, 8 );
  twobit_load( 2, 1 );
  twobit_load( 5, 9 );
  twobit_load( 6, 5 );
  twobit_reg( 7 );
  twobit_pop( 9 );
  twobit_invoke( 6 );
  twobit_label( 1040, compiled_block_1_1040 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 1046, compiled_block_1_1046 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 1045, compiled_block_1_1045 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_29( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 6 );
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 5 );
  twobit_store( 3, 2 );
  twobit_store( 4, 4 );
  twobit_store( 5, 7 );
  twobit_store( 6, 1 );
  twobit_movereg( 5, 1 );
  twobit_lexical( 0, 3 );
  twobit_setrtn( 1049, compiled_block_1_1049 );
  twobit_invoke( 2 );
  twobit_label( 1049, compiled_block_1_1049 );
  twobit_load( 0, 0 );
  twobit_branchf( 1051, compiled_block_1_1051 );
  twobit_stack( 1 );
  twobit_op1_branchf_610( 1053, compiled_block_1_1053 ); /* internal:branchf-null? */
  twobit_load( 4, 2 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1053, compiled_block_1_1053 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1054, compiled_block_1_1054 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_movereg( 4, 1 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1055, compiled_block_1_1055 );
  twobit_invoke( 1 );
  twobit_label( 1055, compiled_block_1_1055 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_movereg( 2, 7 );
  twobit_movereg( 3, 6 );
  twobit_movereg( 4, 5 );
  twobit_load( 1, 3 );
  twobit_load( 2, 5 );
  twobit_load( 3, 2 );
  twobit_load( 4, 6 );
  twobit_reg( 7 );
  twobit_setrtn( 1056, compiled_block_1_1056 );
  twobit_invoke( 6 );
  twobit_label( 1056, compiled_block_1_1056 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1051, compiled_block_1_1051 );
  twobit_stack( 2 );
  twobit_op1_branchf_610( 1058, compiled_block_1_1058 ); /* internal:branchf-null? */
  twobit_load( 4, 1 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1058, compiled_block_1_1058 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 2 );
  twobit_check( 3, 0, 0, 1054, compiled_block_1_1054 );
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_movereg( 4, 1 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1059, compiled_block_1_1059 );
  twobit_invoke( 1 );
  twobit_label( 1059, compiled_block_1_1059 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 3, 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 4, 7 );
  twobit_load( 1, 5 );
  twobit_load( 4, 4 );
  twobit_load( 5, 7 );
  twobit_load( 6, 1 );
  twobit_reg( 7 );
  twobit_setrtn( 1060, compiled_block_1_1060 );
  twobit_invoke( 6 );
  twobit_label( 1060, compiled_block_1_1060 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1054, compiled_block_1_1054 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_6( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1065, compiled_block_1_1065 ); /* internal:branchf-null? */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1065, compiled_block_1_1065 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1067, compiled_block_1_1067 ); /* internal:branchf-null? */
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1067, compiled_block_1_1067 );
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 5 );
  twobit_store( 3, 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 31 );
  twobit_reg_op1_check_652(reg(2),1068,compiled_block_1_1068); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 31 );
  twobit_setrtn( 1069, compiled_block_1_1069 );
  twobit_invoke( 1 );
  twobit_label( 1069, compiled_block_1_1069 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_stack( 1 );
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 1, 2 );
  twobit_check( 1, 0, 0, 1070, compiled_block_1_1070 );
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_setrtn( 1071, compiled_block_1_1071 );
  twobit_invoke( 1 );
  twobit_label( 1071, compiled_block_1_1071 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 1, 3 );
  twobit_movereg( 4, 2 );
  twobit_stack( 4 );
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1072, compiled_block_1_1072 );
  twobit_invoke( 2 );
  twobit_label( 1072, compiled_block_1_1072 );
  twobit_load( 0, 0 );
  twobit_branchf( 1074, compiled_block_1_1074 );
  twobit_stack( 5 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_610( 1076, compiled_block_1_1076 ); /* internal:branchf-null? */
  twobit_load( 3, 2 );
  twobit_stack( 5 );
  twobit_op2_60( 3 ); /* set-cdr! */
  twobit_skip( 1075, compiled_block_1_1075 );
  twobit_label( 1076, compiled_block_1_1076 );
  twobit_stack( 1 );
  twobit_setreg( 3 );
  twobit_reg_op1_check_652(reg(4),1077,compiled_block_1_1077); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_setrtn( 1078, compiled_block_1_1078 );
  twobit_invoke( 1 );
  twobit_label( 1078, compiled_block_1_1078 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 4, 2 );
  twobit_load( 3, 5 );
  twobit_load( 2, 1 );
  twobit_load( 1, 4 );
  twobit_load( 5, 6 );
  twobit_load( 6, 3 );
  twobit_load( 7, 7 );
  twobit_setrtn( 1079, compiled_block_1_1079 );
  twobit_branch( 1062, compiled_block_1_1062 );
  twobit_label( 1079, compiled_block_1_1079 );
  twobit_load( 0, 0 );
  twobit_label( 1075, compiled_block_1_1075 );
  twobit_stack( 5 );
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1074, compiled_block_1_1074 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_reg( 4 );
  twobit_op1_branchf_610( 1081, compiled_block_1_1081 ); /* internal:branchf-null? */
  twobit_load( 3, 5 );
  twobit_stack( 2 );
  twobit_op2_60( 3 ); /* set-cdr! */
  twobit_skip( 1080, compiled_block_1_1080 );
  twobit_label( 1081, compiled_block_1_1081 );
  twobit_stack( 1 );
  twobit_setreg( 3 );
  twobit_reg_op1_check_652(reg(4),1077,compiled_block_1_1077); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 3 );
  twobit_setrtn( 1082, compiled_block_1_1082 );
  twobit_invoke( 1 );
  twobit_label( 1082, compiled_block_1_1082 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_setreg( 3 );
  twobit_store( 3, 7 );
  twobit_load( 3, 2 );
  twobit_load( 2, 1 );
  twobit_load( 1, 4 );
  twobit_movereg( 4, 5 );
  twobit_load( 4, 6 );
  twobit_load( 6, 7 );
  twobit_load( 7, 3 );
  twobit_setrtn( 1083, compiled_block_1_1083 );
  twobit_branch( 1062, compiled_block_1_1062 );
  twobit_label( 1083, compiled_block_1_1083 );
  twobit_load( 0, 0 );
  twobit_label( 1080, compiled_block_1_1080 );
  twobit_stack( 2 );
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1062, compiled_block_1_1062 );
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 5 );
  twobit_store( 2, 4 );
  twobit_store( 3, 2 );
  twobit_store( 4, 3 );
  twobit_store( 5, 6 );
  twobit_store( 6, 1 );
  twobit_store( 7, 7 );
  twobit_movereg( 5, 2 );
  twobit_movereg( 1, 31 );
  twobit_movereg( 7, 1 );
  twobit_reg( 31 );
  twobit_setrtn( 1084, compiled_block_1_1084 );
  twobit_invoke( 2 );
  twobit_label( 1084, compiled_block_1_1084 );
  twobit_load( 0, 0 );
  twobit_branchf( 1086, compiled_block_1_1086 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_op2_60( 4 ); /* set-cdr! */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 3 );
  twobit_op1_branchf_610( 1088, compiled_block_1_1088 ); /* internal:branchf-null? */
  twobit_load( 2, 3 );
  twobit_reg( 4 );
  twobit_op2_60( 2 ); /* set-cdr! */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1088, compiled_block_1_1088 );
  twobit_stack( 4 );
  twobit_setreg( 2 );
  twobit_reg_op1_check_652(reg(3),1089,compiled_block_1_1089); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_setrtn( 1090, compiled_block_1_1090 );
  twobit_invoke( 1 );
  twobit_label( 1090, compiled_block_1_1090 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_movereg( 4, 7 );
  twobit_load( 1, 5 );
  twobit_load( 2, 4 );
  twobit_load( 4, 3 );
  twobit_load( 5, 6 );
  twobit_load( 6, 2 );
  twobit_pop( 7 );
  twobit_branch( 1062, compiled_block_1_1062 );
  twobit_label( 1086, compiled_block_1_1086 );
  twobit_load( 4, 3 );
  twobit_stack( 2 );
  twobit_op2_60( 4 ); /* set-cdr! */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_reg( 3 );
  twobit_op1_branchf_610( 1093, compiled_block_1_1093 ); /* internal:branchf-null? */
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_op2_60( 2 ); /* set-cdr! */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1093, compiled_block_1_1093 );
  twobit_stack( 4 );
  twobit_setreg( 2 );
  twobit_reg_op1_check_652(reg(3),1089,compiled_block_1_1089); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_setrtn( 1094, compiled_block_1_1094 );
  twobit_invoke( 1 );
  twobit_label( 1094, compiled_block_1_1094 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 3 );
  twobit_movereg( 4, 5 );
  twobit_load( 1, 5 );
  twobit_load( 2, 4 );
  twobit_load( 4, 6 );
  twobit_load( 6, 1 );
  twobit_load( 7, 7 );
  twobit_pop( 7 );
  twobit_branch( 1062, compiled_block_1_1062 );
  twobit_label( 1077, compiled_block_1_1077 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 1068, compiled_block_1_1068 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 1089, compiled_block_1_1089 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_label( 1070, compiled_block_1_1070 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_7( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_610( 1097, compiled_block_1_1097 ); /* internal:branchf-null? */
  twobit_global( 1 ); /*  identity~1ay%kV~38442 */
  twobit_skip( 1096, compiled_block_1_1096 );
  twobit_label( 1097, compiled_block_1_1097 );
  twobit_reg_op1_check_652(reg(4),1098,compiled_block_1_1098); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_label( 1096, compiled_block_1_1096 );
  twobit_setreg( 4 );
  twobit_global( 2 ); /*  sort:merge!~1ay%kV~38445 */
  twobit_invoke( 4 );
  twobit_label( 1098, compiled_block_1_1098 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_8( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_reg( 1 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setreg( 1 );
  twobit_reg( 1 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 31 );
  twobit_store( 31, 4 );
  twobit_reg( 1 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 30 );
  twobit_reg( 1 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 1 );
  twobit_store( 1, 3 );
  twobit_reg( 3 );
  twobit_branchf( 1101, compiled_block_1_1101 );
  twobit_global( 2 ); /* car */
  twobit_skip( 1100, compiled_block_1_1100 );
  twobit_label( 1101, compiled_block_1_1101 );
  twobit_global( 3 ); /*  identity~1ay%kV~38442 */
  twobit_label( 1100, compiled_block_1_1100 );
  twobit_setreg( 29 );
  twobit_movereg( 29, 3 );
  twobit_lambda( compiled_start_1_21, 5, 4 );
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_load( 2, 1 );
  twobit_movereg( 30, 1 );
  twobit_lambda( compiled_start_1_22, 7, 2 );
  twobit_setreg( 3 );
  twobit_reg( 30 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_movereg( 31, 1 );
  twobit_lambda( compiled_start_1_23, 9, 1 );
  twobit_setreg( 3 );
  twobit_reg( 31 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 2 );
  twobit_branchf( 1129, compiled_block_1_1129 );
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_reg( 30 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1130, compiled_block_1_1130 );
  twobit_invoke( 1 );
  twobit_label( 1130, compiled_block_1_1130 );
  twobit_load( 0, 0 );
  twobit_stack( 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_global( 10 ); /* length */
  twobit_setrtn( 1131, compiled_block_1_1131 );
  twobit_invoke( 1 );
  twobit_label( 1131, compiled_block_1_1131 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_stack( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1132, compiled_block_1_1132 );
  twobit_invoke( 1 );
  twobit_label( 1132, compiled_block_1_1132 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_stack( 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_stack( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1133, compiled_block_1_1133 );
  twobit_invoke( 1 );
  twobit_label( 1133, compiled_block_1_1133 );
  twobit_load( 0, 0 );
  twobit_stack( 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1129, compiled_block_1_1129 );
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_global( 10 ); /* length */
  twobit_setrtn( 1134, compiled_block_1_1134 );
  twobit_invoke( 1 );
  twobit_label( 1134, compiled_block_1_1134 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_stack( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_21( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_636( fixnum(2), 24, compiled_temp_1_24, 1103, compiled_block_1_1103 ); /* internal:branchf->/imm */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_65( 4, 25, compiled_temp_1_25 ); /* quotient */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1104, compiled_block_1_1104 );
  twobit_invoke( 1 );
  twobit_label( 1104, compiled_block_1_1104 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 3, 1 );
  twobit_stack( 2 );
  twobit_op2_62( 3, 26, compiled_temp_1_26 ); /* - */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1105, compiled_block_1_1105 );
  twobit_invoke( 1 );
  twobit_label( 1105, compiled_block_1_1105 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 4 );
  twobit_global( 1 ); /*  sort:merge!~1ay%kV~38445 */
  twobit_pop( 3 );
  twobit_invoke( 4 );
  twobit_label( 1103, compiled_block_1_1103 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_639( fixnum(2), 27, compiled_temp_1_27, 1108, compiled_block_1_1108 ); /* internal:branchf-=/imm */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_reg_op1_check_652(reg(4),1109,compiled_block_1_1109); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg_op1_check_652(reg(3),1110,compiled_block_1_1110); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_movereg( 2, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 1 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_lexical( 0, 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_lexical( 0, 3 );
  twobit_setrtn( 1111, compiled_block_1_1111 );
  twobit_invoke( 1 );
  twobit_label( 1111, compiled_block_1_1111 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 3 );
  twobit_setrtn( 1112, compiled_block_1_1112 );
  twobit_invoke( 1 );
  twobit_label( 1112, compiled_block_1_1112 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1113, compiled_block_1_1113 );
  twobit_invoke( 2 );
  twobit_label( 1113, compiled_block_1_1113 );
  twobit_load( 0, 0 );
  twobit_branchf( 1115, compiled_block_1_1115 );
  twobit_load( 4, 3 );
  twobit_stack( 4 );
  twobit_op2_59( 4 ); /* set-car! */
  twobit_stack( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_load( 2, 1 );
  twobit_op2_59( 2 ); /* set-car! */
  twobit_skip( 1114, compiled_block_1_1114 );
  twobit_label( 1115, compiled_block_1_1115 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 1114, compiled_block_1_1114 );
  twobit_stack( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_60( 3 ); /* set-cdr! */
  twobit_stack( 4 );
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1108, compiled_block_1_1108 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_639( fixnum(1), 28, compiled_temp_1_28, 1117, compiled_block_1_1117 ); /* internal:branchf-=/imm */
  twobit_lexical( 0, 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1109,compiled_block_1_1109); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_lexical( 0, 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_60( 3 ); /* set-cdr! */
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1117, compiled_block_1_1117 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_label( 1109, compiled_block_1_1109 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_label( 1110, compiled_block_1_1110 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_22( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_10(); /* null? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1119, compiled_block_1_1119 );
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1119, compiled_block_1_1119 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_reg_op1_check_652(reg(1),1120,compiled_block_1_1120); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1121, compiled_block_1_1121 );
  twobit_invoke( 1 );
  twobit_label( 1121, compiled_block_1_1121 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_59( 4 ); /* set-car! */
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1120, compiled_block_1_1120 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_23( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_10(); /* null? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1124, compiled_block_1_1124 );
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1124, compiled_block_1_1124 );
  twobit_reg_op1_check_652(reg(1),1125,compiled_block_1_1125); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1126,compiled_block_1_1126); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_59( 4 ); /* set-car! */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 1126, compiled_block_1_1126 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_label( 1125, compiled_block_1_1125 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_9( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  array-dimensions~1ay%kV~29350 */
  twobit_setrtn( 1136, compiled_block_1_1136 );
  twobit_invoke( 1 );
  twobit_label( 1136, compiled_block_1_1136 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1137,compiled_block_1_1137); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 4, 17, compiled_temp_1_17 ); /* + */
  twobit_setreg( 4 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_18, 4, 2 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1137, compiled_block_1_1137 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_18( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(0), 19, compiled_temp_1_19, 1139, compiled_block_1_1139 ); /* internal:branchf-</imm */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1139, compiled_block_1_1139 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_movereg( 1, 2 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 1, 20, compiled_temp_1_20 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  array-ref~1ay%kV~29360 */
  twobit_setrtn( 1140, compiled_block_1_1140 );
  twobit_invoke( 2 );
  twobit_label( 1140, compiled_block_1_1140 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 3, 2 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_10( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_610( 1144, compiled_block_1_1144 ); /* internal:branchf-null? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1143, compiled_block_1_1143 );
  twobit_label( 1144, compiled_block_1_1144 );
  twobit_reg_op1_check_652(reg(3),1145,compiled_block_1_1145); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_label( 1143, compiled_block_1_1143 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_global( 1 ); /*  array?~1ay%kV~29347 */
  twobit_setrtn( 1146, compiled_block_1_1146 );
  twobit_invoke( 1 );
  twobit_label( 1146, compiled_block_1_1146 );
  twobit_load( 0, 0 );
  twobit_branchf( 1148, compiled_block_1_1148 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  array-dimensions~1ay%kV~29350 */
  twobit_setrtn( 1149, compiled_block_1_1149 );
  twobit_invoke( 1 );
  twobit_label( 1149, compiled_block_1_1149 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /*  rank-1-array->list~1ay%kV~38448 */
  twobit_setrtn( 1150, compiled_block_1_1150 );
  twobit_invoke( 1 );
  twobit_label( 1150, compiled_block_1_1150 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 3, 2 );
  twobit_load( 2, 3 );
  twobit_global( 4 ); /*  sort:sort-list!~1ay%kV~38447 */
  twobit_setrtn( 1151, compiled_block_1_1151 );
  twobit_invoke( 3 );
  twobit_label( 1151, compiled_block_1_1151 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_global( 5 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_14, 7, 2 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1148, compiled_block_1_1148 );
  twobit_load( 1, 1 );
  twobit_load( 2, 3 );
  twobit_load( 3, 2 );
  twobit_global( 4 ); /*  sort:sort-list!~1ay%kV~38447 */
  twobit_setrtn( 1158, compiled_block_1_1158 );
  twobit_invoke( 3 );
  twobit_label( 1158, compiled_block_1_1158 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 1160, compiled_block_1_1160 ); /* internal:branchf-eq? */
  twobit_op1_3(); /* unspecified */
  twobit_skip( 1159, compiled_block_1_1159 );
  twobit_label( 1160, compiled_block_1_1160 );
  twobit_global( 5 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_15, 9, 3 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_movereg( 4, 1 );
  twobit_reg( 3 );
  twobit_setrtn( 1167, compiled_block_1_1167 );
  twobit_invoke( 1 );
  twobit_label( 1167, compiled_block_1_1167 );
  twobit_load( 0, 0 );
  twobit_label( 1159, compiled_block_1_1159 );
  twobit_stack( 1 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1145, compiled_block_1_1145 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_14( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1153, compiled_block_1_1153 ); /* internal:branchf-null? */
  twobit_lexical( 0, 2 );
  twobit_return();
  twobit_label( 1153, compiled_block_1_1153 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 3 );
  twobit_reg_op1_check_652(reg(1),1154,compiled_block_1_1154); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  array-set!~1ay%kV~29361 */
  twobit_setrtn( 1155, compiled_block_1_1155 );
  twobit_invoke( 3 );
  twobit_label( 1155, compiled_block_1_1155 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op2imm_130( fixnum(1), 16, compiled_temp_1_16 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1154, compiled_block_1_1154 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_15( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op1_check_652(reg(1),1161,compiled_block_1_1161); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 1163, compiled_block_1_1163 ); /* internal:branchf-eq? */
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op2_60( 3 ); /* set-cdr! */
  twobit_lexical( 0, 3 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 1164, compiled_block_1_1164 );
  twobit_lexical( 0, 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_check( 2, 0, 0, 1165, compiled_block_1_1165 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_op2_59( 2 ); /* set-car! */
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_op2_60( 2 ); /* set-cdr! */
  twobit_lexical( 0, 1 );
  twobit_op2_59( 3 ); /* set-car! */
  twobit_lexical( 0, 1 );
  twobit_op2_60( 4 ); /* set-cdr! */
  twobit_return();
  twobit_label( 1163, compiled_block_1_1163 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_movereg( 4, 1 );
  twobit_reg( 3 );
  twobit_invoke( 1 );
  twobit_label( 1165, compiled_block_1_1165 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 1161, compiled_block_1_1161 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_label( 1164, compiled_block_1_1164 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_11( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_610( 1169, compiled_block_1_1169 ); /* internal:branchf-null? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1168, compiled_block_1_1168 );
  twobit_label( 1169, compiled_block_1_1169 );
  twobit_reg_op1_check_652(reg(3),1170,compiled_block_1_1170); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_label( 1168, compiled_block_1_1168 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_global( 1 ); /*  array?~1ay%kV~29347 */
  twobit_setrtn( 1171, compiled_block_1_1171 );
  twobit_invoke( 1 );
  twobit_label( 1171, compiled_block_1_1171 );
  twobit_load( 0, 0 );
  twobit_branchf( 1173, compiled_block_1_1173 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  array-dimensions~1ay%kV~29350 */
  twobit_setrtn( 1174, compiled_block_1_1174 );
  twobit_invoke( 1 );
  twobit_label( 1174, compiled_block_1_1174 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_global( 3 ); /*  make-array~1ay%kV~29351 */
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_setrtn( 1175, compiled_block_1_1175 );
  twobit_invoke( 3 );
  twobit_label( 1175, compiled_block_1_1175 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /*  rank-1-array->list~1ay%kV~38448 */
  twobit_setrtn( 1176, compiled_block_1_1176 );
  twobit_invoke( 1 );
  twobit_label( 1176, compiled_block_1_1176 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 3, 2 );
  twobit_load( 2, 3 );
  twobit_global( 6 ); /*  sort:sort-list!~1ay%kV~38447 */
  twobit_setrtn( 1177, compiled_block_1_1177 );
  twobit_invoke( 3 );
  twobit_label( 1177, compiled_block_1_1177 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_global( 7 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_12, 9, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 1173, compiled_block_1_1173 );
  twobit_load( 1, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 10 ); /* append */
  twobit_setrtn( 1184, compiled_block_1_1184 );
  twobit_invoke( 2 );
  twobit_label( 1184, compiled_block_1_1184 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_load( 3, 2 );
  twobit_global( 6 ); /*  sort:sort-list!~1ay%kV~38447 */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 1170, compiled_block_1_1170 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_12( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1179, compiled_block_1_1179 ); /* internal:branchf-null? */
  twobit_lexical( 0, 2 );
  twobit_return();
  twobit_label( 1179, compiled_block_1_1179 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 3 );
  twobit_reg_op1_check_652(reg(1),1180,compiled_block_1_1180); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  array-set!~1ay%kV~29361 */
  twobit_setrtn( 1181, compiled_block_1_1181 );
  twobit_invoke( 3 );
  twobit_label( 1181, compiled_block_1_1181 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op2imm_130( fixnum(1), 13, compiled_temp_1_13 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1180, compiled_block_1_1180 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_d243440325e6c248bf6079a00a0e1b2f_0(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_1_0(CONT_ACTUALS));
}
static RTYPE compiled_block_2_1004( CONT_PARAMS );
static RTYPE compiled_block_2_1003( CONT_PARAMS );
static RTYPE compiled_start_2_0( CONT_PARAMS );
static RTYPE compiled_start_2_3( CONT_PARAMS );
static RTYPE compiled_start_2_2( CONT_PARAMS );
static RTYPE compiled_start_2_1( CONT_PARAMS );

static RTYPE compiled_start_2_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_2_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_2_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1003, compiled_block_2_1003 );
  twobit_invoke( 8 );
  twobit_label( 1003, compiled_block_2_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1004, compiled_block_2_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_2_1004 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_d243440325e6c248bf6079a00a0e1b2f_1(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_2_0(CONT_ACTUALS));
}
codeptr_t CDECL twobit_load_table[] = { 
  twobit_thunk_d243440325e6c248bf6079a00a0e1b2f_0,
  twobit_thunk_d243440325e6c248bf6079a00a0e1b2f_1,
  0  /* The table may be empty; some compilers complain */
};

/* Generated from /home/henchman/larcenytest/larceny-petit-Nightly-2009-08-19/larceny_src/lib/SRFI/srfi/%3a63.slfasl */
#include "petit-instr.h"

static RTYPE compiled_block_1_1363( CONT_PARAMS );
static RTYPE compiled_block_1_1362( CONT_PARAMS );
static RTYPE compiled_start_1_0( CONT_PARAMS );
static RTYPE compiled_block_1_1360( CONT_PARAMS );
static RTYPE compiled_block_1_1359( CONT_PARAMS );
static RTYPE compiled_block_1_1358( CONT_PARAMS );
static RTYPE compiled_block_1_1357( CONT_PARAMS );
static RTYPE compiled_block_1_1356( CONT_PARAMS );
static RTYPE compiled_block_1_1355( CONT_PARAMS );
static RTYPE compiled_block_1_1354( CONT_PARAMS );
static RTYPE compiled_block_1_1353( CONT_PARAMS );
static RTYPE compiled_block_1_1352( CONT_PARAMS );
static RTYPE compiled_block_1_1351( CONT_PARAMS );
static RTYPE compiled_block_1_1350( CONT_PARAMS );
static RTYPE compiled_block_1_1349( CONT_PARAMS );
static RTYPE compiled_block_1_1348( CONT_PARAMS );
static RTYPE compiled_block_1_1347( CONT_PARAMS );
static RTYPE compiled_block_1_1346( CONT_PARAMS );
static RTYPE compiled_block_1_1345( CONT_PARAMS );
static RTYPE compiled_block_1_1344( CONT_PARAMS );
static RTYPE compiled_block_1_1343( CONT_PARAMS );
static RTYPE compiled_block_1_1342( CONT_PARAMS );
static RTYPE compiled_block_1_1341( CONT_PARAMS );
static RTYPE compiled_block_1_1340( CONT_PARAMS );
static RTYPE compiled_block_1_1339( CONT_PARAMS );
static RTYPE compiled_block_1_1338( CONT_PARAMS );
static RTYPE compiled_block_1_1337( CONT_PARAMS );
static RTYPE compiled_block_1_1336( CONT_PARAMS );
static RTYPE compiled_block_1_1335( CONT_PARAMS );
static RTYPE compiled_block_1_1334( CONT_PARAMS );
static RTYPE compiled_block_1_1333( CONT_PARAMS );
static RTYPE compiled_block_1_1034( CONT_PARAMS );
static RTYPE compiled_block_1_1033( CONT_PARAMS );
static RTYPE compiled_block_1_1027( CONT_PARAMS );
static RTYPE compiled_block_1_1021( CONT_PARAMS );
static RTYPE compiled_block_1_1015( CONT_PARAMS );
static RTYPE compiled_block_1_1009( CONT_PARAMS );
static RTYPE compiled_block_1_1008( CONT_PARAMS );
static RTYPE compiled_start_1_3( CONT_PARAMS );
static RTYPE compiled_start_1_25( CONT_PARAMS );
static RTYPE compiled_block_1_1316( CONT_PARAMS );
static RTYPE compiled_block_1_1318( CONT_PARAMS );
static RTYPE compiled_block_1_1324( CONT_PARAMS );
static RTYPE compiled_temp_1_30( CONT_PARAMS );
static RTYPE compiled_block_1_1325( CONT_PARAMS );
static RTYPE compiled_block_1_1326( CONT_PARAMS );
static RTYPE compiled_temp_1_29( CONT_PARAMS );
static RTYPE compiled_block_1_1319( CONT_PARAMS );
static RTYPE compiled_block_1_1322( CONT_PARAMS );
static RTYPE compiled_temp_1_28( CONT_PARAMS );
static RTYPE compiled_block_1_1320( CONT_PARAMS );
static RTYPE compiled_temp_1_27( CONT_PARAMS );
static RTYPE compiled_start_1_26( CONT_PARAMS );
static RTYPE compiled_temp_1_35( CONT_PARAMS );
static RTYPE compiled_temp_1_34( CONT_PARAMS );
static RTYPE compiled_block_1_1330( CONT_PARAMS );
static RTYPE compiled_block_1_1327( CONT_PARAMS );
static RTYPE compiled_temp_1_33( CONT_PARAMS );
static RTYPE compiled_block_1_1328( CONT_PARAMS );
static RTYPE compiled_temp_1_32( CONT_PARAMS );
static RTYPE compiled_start_1_31( CONT_PARAMS );
static RTYPE compiled_start_1_24( CONT_PARAMS );
static RTYPE compiled_block_1_1305( CONT_PARAMS );
static RTYPE compiled_block_1_1312( CONT_PARAMS );
static RTYPE compiled_block_1_1304( CONT_PARAMS );
static RTYPE compiled_block_1_1308( CONT_PARAMS );
static RTYPE compiled_block_1_1306( CONT_PARAMS );
static RTYPE compiled_block_1_1302( CONT_PARAMS );
static RTYPE compiled_start_1_36( CONT_PARAMS );
static RTYPE compiled_block_1_1299( CONT_PARAMS );
static RTYPE compiled_block_1_1300( CONT_PARAMS );
static RTYPE compiled_block_1_1298( CONT_PARAMS );
static RTYPE compiled_block_1_1297( CONT_PARAMS );
static RTYPE compiled_block_1_1296( CONT_PARAMS );
static RTYPE compiled_block_1_1295( CONT_PARAMS );
static RTYPE compiled_block_1_1292( CONT_PARAMS );
static RTYPE compiled_block_1_1294( CONT_PARAMS );
static RTYPE compiled_block_1_1293( CONT_PARAMS );
static RTYPE compiled_block_1_1291( CONT_PARAMS );
static RTYPE compiled_block_1_1290( CONT_PARAMS );
static RTYPE compiled_start_1_23( CONT_PARAMS );
static RTYPE compiled_block_1_1287( CONT_PARAMS );
static RTYPE compiled_block_1_1288( CONT_PARAMS );
static RTYPE compiled_block_1_1286( CONT_PARAMS );
static RTYPE compiled_block_1_1285( CONT_PARAMS );
static RTYPE compiled_block_1_1284( CONT_PARAMS );
static RTYPE compiled_block_1_1283( CONT_PARAMS );
static RTYPE compiled_block_1_1280( CONT_PARAMS );
static RTYPE compiled_block_1_1282( CONT_PARAMS );
static RTYPE compiled_block_1_1281( CONT_PARAMS );
static RTYPE compiled_block_1_1279( CONT_PARAMS );
static RTYPE compiled_block_1_1278( CONT_PARAMS );
static RTYPE compiled_start_1_22( CONT_PARAMS );
static RTYPE compiled_start_1_21( CONT_PARAMS );
static RTYPE compiled_block_1_1256( CONT_PARAMS );
static RTYPE compiled_start_1_20( CONT_PARAMS );
static RTYPE compiled_block_1_1264( CONT_PARAMS );
static RTYPE compiled_block_1_1274( CONT_PARAMS );
static RTYPE compiled_block_1_1261( CONT_PARAMS );
static RTYPE compiled_block_1_1273( CONT_PARAMS );
static RTYPE compiled_block_1_1270( CONT_PARAMS );
static RTYPE compiled_block_1_1272( CONT_PARAMS );
static RTYPE compiled_block_1_1257( CONT_PARAMS );
static RTYPE compiled_block_1_1268( CONT_PARAMS );
static RTYPE compiled_block_1_1265( CONT_PARAMS );
static RTYPE compiled_block_1_1266( CONT_PARAMS );
static RTYPE compiled_temp_1_39( CONT_PARAMS );
static RTYPE compiled_temp_1_38( CONT_PARAMS );
static RTYPE compiled_block_1_1263( CONT_PARAMS );
static RTYPE compiled_block_1_1260( CONT_PARAMS );
static RTYPE compiled_block_1_1258( CONT_PARAMS );
static RTYPE compiled_start_1_37( CONT_PARAMS );
static RTYPE compiled_block_1_1249( CONT_PARAMS );
static RTYPE compiled_block_1_1250( CONT_PARAMS );
static RTYPE compiled_temp_1_41( CONT_PARAMS );
static RTYPE compiled_block_1_1246( CONT_PARAMS );
static RTYPE compiled_temp_1_40( CONT_PARAMS );
static RTYPE compiled_block_1_1248( CONT_PARAMS );
static RTYPE compiled_block_1_1247( CONT_PARAMS );
static RTYPE compiled_block_1_1240( CONT_PARAMS );
static RTYPE compiled_block_1_1244( CONT_PARAMS );
static RTYPE compiled_block_1_1243( CONT_PARAMS );
static RTYPE compiled_block_1_1242( CONT_PARAMS );
static RTYPE compiled_start_1_19( CONT_PARAMS );
static RTYPE compiled_temp_1_44( CONT_PARAMS );
static RTYPE compiled_block_1_1253( CONT_PARAMS );
static RTYPE compiled_block_1_1252( CONT_PARAMS );
static RTYPE compiled_temp_1_43( CONT_PARAMS );
static RTYPE compiled_start_1_42( CONT_PARAMS );
static RTYPE compiled_block_1_1231( CONT_PARAMS );
static RTYPE compiled_block_1_1222( CONT_PARAMS );
static RTYPE compiled_block_1_1234( CONT_PARAMS );
static RTYPE compiled_temp_1_47( CONT_PARAMS );
static RTYPE compiled_block_1_1230( CONT_PARAMS );
static RTYPE compiled_block_1_1232( CONT_PARAMS );
static RTYPE compiled_temp_1_46( CONT_PARAMS );
static RTYPE compiled_block_1_1220( CONT_PARAMS );
static RTYPE compiled_block_1_1228( CONT_PARAMS );
static RTYPE compiled_block_1_1227( CONT_PARAMS );
static RTYPE compiled_block_1_1224( CONT_PARAMS );
static RTYPE compiled_block_1_1226( CONT_PARAMS );
static RTYPE compiled_block_1_1225( CONT_PARAMS );
static RTYPE compiled_temp_1_45( CONT_PARAMS );
static RTYPE compiled_block_1_1223( CONT_PARAMS );
static RTYPE compiled_start_1_18( CONT_PARAMS );
static RTYPE compiled_temp_1_50( CONT_PARAMS );
static RTYPE compiled_block_1_1237( CONT_PARAMS );
static RTYPE compiled_block_1_1236( CONT_PARAMS );
static RTYPE compiled_temp_1_49( CONT_PARAMS );
static RTYPE compiled_start_1_48( CONT_PARAMS );
static RTYPE compiled_block_1_1214( CONT_PARAMS );
static RTYPE compiled_temp_1_51( CONT_PARAMS );
static RTYPE compiled_block_1_1211( CONT_PARAMS );
static RTYPE compiled_block_1_1212( CONT_PARAMS );
static RTYPE compiled_block_1_1206( CONT_PARAMS );
static RTYPE compiled_block_1_1208( CONT_PARAMS );
static RTYPE compiled_start_1_17( CONT_PARAMS );
static RTYPE compiled_block_1_1217( CONT_PARAMS );
static RTYPE compiled_temp_1_54( CONT_PARAMS );
static RTYPE compiled_block_1_1216( CONT_PARAMS );
static RTYPE compiled_temp_1_53( CONT_PARAMS );
static RTYPE compiled_start_1_52( CONT_PARAMS );
static RTYPE compiled_block_1_1193( CONT_PARAMS );
static RTYPE compiled_block_1_1199( CONT_PARAMS );
static RTYPE compiled_block_1_1195( CONT_PARAMS );
static RTYPE compiled_block_1_1197( CONT_PARAMS );
static RTYPE compiled_block_1_1196( CONT_PARAMS );
static RTYPE compiled_temp_1_57( CONT_PARAMS );
static RTYPE compiled_block_1_1194( CONT_PARAMS );
static RTYPE compiled_block_1_1190( CONT_PARAMS );
static RTYPE compiled_block_1_1191( CONT_PARAMS );
static RTYPE compiled_block_1_1178( CONT_PARAMS );
static RTYPE compiled_block_1_1188( CONT_PARAMS );
static RTYPE compiled_block_1_1187( CONT_PARAMS );
static RTYPE compiled_block_1_1186( CONT_PARAMS );
static RTYPE compiled_temp_1_55( CONT_PARAMS );
static RTYPE compiled_start_1_16( CONT_PARAMS );
static RTYPE compiled_block_1_1202( CONT_PARAMS );
static RTYPE compiled_temp_1_60( CONT_PARAMS );
static RTYPE compiled_block_1_1203( CONT_PARAMS );
static RTYPE compiled_block_1_1201( CONT_PARAMS );
static RTYPE compiled_temp_1_59( CONT_PARAMS );
static RTYPE compiled_start_1_58( CONT_PARAMS );
static RTYPE compiled_block_1_1183( CONT_PARAMS );
static RTYPE compiled_block_1_1184( CONT_PARAMS );
static RTYPE compiled_temp_1_62( CONT_PARAMS );
static RTYPE compiled_block_1_1181( CONT_PARAMS );
static RTYPE compiled_temp_1_61( CONT_PARAMS );
static RTYPE compiled_start_1_56( CONT_PARAMS );
static RTYPE compiled_block_1_1153( CONT_PARAMS );
static RTYPE compiled_block_1_1150( CONT_PARAMS );
static RTYPE compiled_block_1_1154( CONT_PARAMS );
static RTYPE compiled_block_1_1152( CONT_PARAMS );
static RTYPE compiled_block_1_1151( CONT_PARAMS );
static RTYPE compiled_temp_1_65( CONT_PARAMS );
static RTYPE compiled_temp_1_64( CONT_PARAMS );
static RTYPE compiled_block_1_1149( CONT_PARAMS );
static RTYPE compiled_block_1_1145( CONT_PARAMS );
static RTYPE compiled_block_1_1144( CONT_PARAMS );
static RTYPE compiled_start_1_15( CONT_PARAMS );
static RTYPE compiled_block_1_1174( CONT_PARAMS );
static RTYPE compiled_block_1_1175( CONT_PARAMS );
static RTYPE compiled_temp_1_70( CONT_PARAMS );
static RTYPE compiled_block_1_1156( CONT_PARAMS );
static RTYPE compiled_block_1_1172( CONT_PARAMS );
static RTYPE compiled_block_1_1171( CONT_PARAMS );
static RTYPE compiled_block_1_1170( CONT_PARAMS );
static RTYPE compiled_block_1_1169( CONT_PARAMS );
static RTYPE compiled_block_1_1168( CONT_PARAMS );
static RTYPE compiled_block_1_1167( CONT_PARAMS );
static RTYPE compiled_block_1_1166( CONT_PARAMS );
static RTYPE compiled_block_1_1162( CONT_PARAMS );
static RTYPE compiled_block_1_1159( CONT_PARAMS );
static RTYPE compiled_block_1_1158( CONT_PARAMS );
static RTYPE compiled_block_1_1157( CONT_PARAMS );
static RTYPE compiled_temp_1_67( CONT_PARAMS );
static RTYPE compiled_start_1_66( CONT_PARAMS );
static RTYPE compiled_temp_1_71( CONT_PARAMS );
static RTYPE compiled_block_1_1165( CONT_PARAMS );
static RTYPE compiled_block_1_1164( CONT_PARAMS );
static RTYPE compiled_block_1_1163( CONT_PARAMS );
static RTYPE compiled_start_1_69( CONT_PARAMS );
static RTYPE compiled_block_1_1160( CONT_PARAMS );
static RTYPE compiled_block_1_1161( CONT_PARAMS );
static RTYPE compiled_temp_1_73( CONT_PARAMS );
static RTYPE compiled_temp_1_72( CONT_PARAMS );
static RTYPE compiled_start_1_68( CONT_PARAMS );
static RTYPE compiled_temp_1_74( CONT_PARAMS );
static RTYPE compiled_block_1_1148( CONT_PARAMS );
static RTYPE compiled_block_1_1146( CONT_PARAMS );
static RTYPE compiled_start_1_63( CONT_PARAMS );
static RTYPE compiled_block_1_1142( CONT_PARAMS );
static RTYPE compiled_block_1_1126( CONT_PARAMS );
static RTYPE compiled_temp_1_78( CONT_PARAMS );
static RTYPE compiled_block_1_1140( CONT_PARAMS );
static RTYPE compiled_block_1_1111( CONT_PARAMS );
static RTYPE compiled_block_1_1137( CONT_PARAMS );
static RTYPE compiled_block_1_1133( CONT_PARAMS );
static RTYPE compiled_block_1_1136( CONT_PARAMS );
static RTYPE compiled_block_1_1134( CONT_PARAMS );
static RTYPE compiled_block_1_1135( CONT_PARAMS );
static RTYPE compiled_block_1_1131( CONT_PARAMS );
static RTYPE compiled_block_1_1128( CONT_PARAMS );
static RTYPE compiled_block_1_1129( CONT_PARAMS );
static RTYPE compiled_block_1_1125( CONT_PARAMS );
static RTYPE compiled_block_1_1122( CONT_PARAMS );
static RTYPE compiled_block_1_1123( CONT_PARAMS );
static RTYPE compiled_block_1_1118( CONT_PARAMS );
static RTYPE compiled_block_1_1121( CONT_PARAMS );
static RTYPE compiled_block_1_1120( CONT_PARAMS );
static RTYPE compiled_block_1_1119( CONT_PARAMS );
static RTYPE compiled_temp_1_76( CONT_PARAMS );
static RTYPE compiled_block_1_1117( CONT_PARAMS );
static RTYPE compiled_block_1_1116( CONT_PARAMS );
static RTYPE compiled_temp_1_75( CONT_PARAMS );
static RTYPE compiled_block_1_1115( CONT_PARAMS );
static RTYPE compiled_block_1_1114( CONT_PARAMS );
static RTYPE compiled_block_1_1113( CONT_PARAMS );
static RTYPE compiled_start_1_14( CONT_PARAMS );
static RTYPE compiled_start_1_77( CONT_PARAMS );
static RTYPE compiled_block_1_1108( CONT_PARAMS );
static RTYPE compiled_block_1_1109( CONT_PARAMS );
static RTYPE compiled_block_1_1106( CONT_PARAMS );
static RTYPE compiled_start_1_13( CONT_PARAMS );
static RTYPE compiled_block_1_1063( CONT_PARAMS );
static RTYPE compiled_block_1_1064( CONT_PARAMS );
static RTYPE compiled_block_1_1084( CONT_PARAMS );
static RTYPE compiled_block_1_1089( CONT_PARAMS );
static RTYPE compiled_block_1_1104( CONT_PARAMS );
static RTYPE compiled_block_1_1103( CONT_PARAMS );
static RTYPE compiled_block_1_1087( CONT_PARAMS );
static RTYPE compiled_block_1_1086( CONT_PARAMS );
static RTYPE compiled_block_1_1085( CONT_PARAMS );
static RTYPE compiled_block_1_1080( CONT_PARAMS );
static RTYPE compiled_block_1_1081( CONT_PARAMS );
static RTYPE compiled_block_1_1082( CONT_PARAMS );
static RTYPE compiled_block_1_1079( CONT_PARAMS );
static RTYPE compiled_block_1_1062( CONT_PARAMS );
static RTYPE compiled_block_1_1067( CONT_PARAMS );
static RTYPE compiled_temp_1_80( CONT_PARAMS );
static RTYPE compiled_block_1_1065( CONT_PARAMS );
static RTYPE compiled_block_1_1059( CONT_PARAMS );
static RTYPE compiled_block_1_1060( CONT_PARAMS );
static RTYPE compiled_block_1_1057( CONT_PARAMS );
static RTYPE compiled_block_1_1054( CONT_PARAMS );
static RTYPE compiled_block_1_1055( CONT_PARAMS );
static RTYPE compiled_block_1_1045( CONT_PARAMS );
static RTYPE compiled_block_1_1047( CONT_PARAMS );
static RTYPE compiled_block_1_1049( CONT_PARAMS );
static RTYPE compiled_block_1_1052( CONT_PARAMS );
static RTYPE compiled_block_1_1050( CONT_PARAMS );
static RTYPE compiled_block_1_1042( CONT_PARAMS );
static RTYPE compiled_block_1_1043( CONT_PARAMS );
static RTYPE compiled_block_1_1041( CONT_PARAMS );
static RTYPE compiled_temp_1_79( CONT_PARAMS );
static RTYPE compiled_start_1_12( CONT_PARAMS );
static RTYPE compiled_block_1_1095( CONT_PARAMS );
static RTYPE compiled_temp_1_83( CONT_PARAMS );
static RTYPE compiled_block_1_1091( CONT_PARAMS );
static RTYPE compiled_block_1_1093( CONT_PARAMS );
static RTYPE compiled_block_1_1092( CONT_PARAMS );
static RTYPE compiled_start_1_82( CONT_PARAMS );
static RTYPE compiled_block_1_1100( CONT_PARAMS );
static RTYPE compiled_temp_1_86( CONT_PARAMS );
static RTYPE compiled_block_1_1099( CONT_PARAMS );
static RTYPE compiled_block_1_1096( CONT_PARAMS );
static RTYPE compiled_temp_1_85( CONT_PARAMS );
static RTYPE compiled_block_1_1097( CONT_PARAMS );
static RTYPE compiled_start_1_84( CONT_PARAMS );
static RTYPE compiled_block_1_1071( CONT_PARAMS );
static RTYPE compiled_block_1_1070( CONT_PARAMS );
static RTYPE compiled_temp_1_88( CONT_PARAMS );
static RTYPE compiled_block_1_1076( CONT_PARAMS );
static RTYPE compiled_block_1_1068( CONT_PARAMS );
static RTYPE compiled_block_1_1074( CONT_PARAMS );
static RTYPE compiled_block_1_1072( CONT_PARAMS );
static RTYPE compiled_block_1_1069( CONT_PARAMS );
static RTYPE compiled_temp_1_87( CONT_PARAMS );
static RTYPE compiled_start_1_81( CONT_PARAMS );
static RTYPE compiled_block_1_1038( CONT_PARAMS );
static RTYPE compiled_block_1_1036( CONT_PARAMS );
static RTYPE compiled_start_1_11( CONT_PARAMS );
static RTYPE compiled_block_1_1031( CONT_PARAMS );
static RTYPE compiled_block_1_1029( CONT_PARAMS );
static RTYPE compiled_start_1_10( CONT_PARAMS );
static RTYPE compiled_block_1_1025( CONT_PARAMS );
static RTYPE compiled_block_1_1023( CONT_PARAMS );
static RTYPE compiled_start_1_9( CONT_PARAMS );
static RTYPE compiled_block_1_1019( CONT_PARAMS );
static RTYPE compiled_block_1_1017( CONT_PARAMS );
static RTYPE compiled_start_1_8( CONT_PARAMS );
static RTYPE compiled_block_1_1013( CONT_PARAMS );
static RTYPE compiled_block_1_1011( CONT_PARAMS );
static RTYPE compiled_start_1_7( CONT_PARAMS );
static RTYPE compiled_block_1_1006( CONT_PARAMS );
static RTYPE compiled_start_1_6( CONT_PARAMS );
static RTYPE compiled_block_1_1004( CONT_PARAMS );
static RTYPE compiled_block_1_1003( CONT_PARAMS );
static RTYPE compiled_start_1_5( CONT_PARAMS );
static RTYPE compiled_start_1_4( CONT_PARAMS );
static RTYPE compiled_start_1_2( CONT_PARAMS );
static RTYPE compiled_start_1_1( CONT_PARAMS );

static RTYPE compiled_start_1_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 2 ); /*  A:bool~1ay%kV~29383 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 3 ); /*  A:fixN8b~1ay%kV~29382 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 4 ); /*  A:fixN16b~1ay%kV~29381 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 5 ); /*  A:fixN32b~1ay%kV~29380 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 6 ); /*  A:fixN64b~1ay%kV~29379 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 7 ); /*  A:fixZ8b~1ay%kV~29378 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 8 ); /*  A:fixZ16b~1ay%kV~29377 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 9 ); /*  A:fixZ32b~1ay%kV~29376 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 10 ); /*  A:fixZ64b~1ay%kV~29375 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 11 ); /*  A:floR32d~1ay%kV~29374 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 12 ); /*  A:floR64d~1ay%kV~29373 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 13 ); /*  A:floR128d~1ay%kV~29372 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 14 ); /*  A:floR16b~1ay%kV~29371 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 15 ); /*  A:floR32b~1ay%kV~29370 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 16 ); /*  A:floR64b~1ay%kV~29369 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 17 ); /*  A:floR128b~1ay%kV~29368 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 18 ); /*  A:floC16b~1ay%kV~29367 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 19 ); /*  A:floC32b~1ay%kV~29366 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 20 ); /*  A:floC64b~1ay%kV~29365 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 21 ); /*  A:floC128b~1ay%kV~29364 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 22 ); /*  integer-bytes??~1ay%kV~29363 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 23 ); /*  make-prototype-checker~1ay%kV~29362 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 24 ); /*  array-set!~1ay%kV~29361 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 25 ); /*  array-ref~1ay%kV~29360 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 26 ); /*  array-in-bounds?~1ay%kV~29359 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 27 ); /*  array:in-bounds?~1ay%kV~29358 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 28 ); /*  array->vector~1ay%kV~29357 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 29 ); /*  vector->array~1ay%kV~29356 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 30 ); /*  array->list~1ay%kV~29355 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 31 ); /*  list->array~1ay%kV~29354 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 32 ); /*  make-shared-array~1ay%kV~29353 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 33 ); /*  create-array~1ay%kV~29352 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 34 ); /*  make-array~1ay%kV~29351 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 35 ); /*  array-dimensions~1ay%kV~29350 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 36 ); /*  array-rank~1ay%kV~29349 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 37 ); /*  equal?~1ay%kV~29348 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 38 ); /*  array?~1ay%kV~29347 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 39 ); /*  array:construct~1ay%kV~29346 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 40 ); /*  array:offset~1ay%kV~29345 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 41 ); /*  array:store~1ay%kV~29344 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 42 ); /*  array:scales~1ay%kV~29343 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 43 ); /*  array:dimensions~1ay%kV~29342 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 44 ); /*  array:rtd~1ay%kV~29341 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 45 ); /*  record-constructor~1ay%kV~29340 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 46 ); /*  make-record-type~1ay%kV~29339 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 47 ); /*  slib:error~1ay%kV~29338 */
  twobit_lambda( compiled_start_1_1, 49, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_2, 51, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_3, 53, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 54 );
  twobit_setreg( 1 );
  twobit_const( 55 );
  twobit_setreg( 3 );
  twobit_const( 56 );
  twobit_setreg( 4 );
  twobit_const( 57 );
  twobit_setreg( 5 );
  twobit_const( 58 );
  twobit_setreg( 8 );
  twobit_global( 59 ); /* ex:make-library */
  twobit_setrtn( 1362, compiled_block_1_1362 );
  twobit_invoke( 8 );
  twobit_label( 1362, compiled_block_1_1362 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 60 ); /* ex:register-library! */
  twobit_setrtn( 1363, compiled_block_1_1363 );
  twobit_invoke( 1 );
  twobit_label( 1363, compiled_block_1_1363 );
  twobit_load( 0, 0 );
  twobit_global( 61 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 2 ); /*  A:bool~1ay%kV~29383 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 3 ); /*  A:fixN8b~1ay%kV~29382 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 4 ); /*  A:fixN16b~1ay%kV~29381 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 5 ); /*  A:fixN32b~1ay%kV~29380 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 6 ); /*  A:fixN64b~1ay%kV~29379 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 7 ); /*  A:fixZ8b~1ay%kV~29378 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 8 ); /*  A:fixZ16b~1ay%kV~29377 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 9 ); /*  A:fixZ32b~1ay%kV~29376 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 10 ); /*  A:fixZ64b~1ay%kV~29375 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 11 ); /*  A:floR32d~1ay%kV~29374 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 12 ); /*  A:floR64d~1ay%kV~29373 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 13 ); /*  A:floR128d~1ay%kV~29372 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 14 ); /*  A:floR16b~1ay%kV~29371 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 15 ); /*  A:floR32b~1ay%kV~29370 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 16 ); /*  A:floR64b~1ay%kV~29369 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 17 ); /*  A:floR128b~1ay%kV~29368 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 18 ); /*  A:floC16b~1ay%kV~29367 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 19 ); /*  A:floC32b~1ay%kV~29366 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 20 ); /*  A:floC64b~1ay%kV~29365 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 21 ); /*  A:floC128b~1ay%kV~29364 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 22 ); /*  integer-bytes??~1ay%kV~29363 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 23 ); /*  make-prototype-checker~1ay%kV~29362 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 24 ); /*  array-set!~1ay%kV~29361 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 25 ); /*  array-ref~1ay%kV~29360 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 26 ); /*  array-in-bounds?~1ay%kV~29359 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 27 ); /*  array:in-bounds?~1ay%kV~29358 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 28 ); /*  array->vector~1ay%kV~29357 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 29 ); /*  vector->array~1ay%kV~29356 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 30 ); /*  array->list~1ay%kV~29355 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 31 ); /*  list->array~1ay%kV~29354 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 32 ); /*  make-shared-array~1ay%kV~29353 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 33 ); /*  create-array~1ay%kV~29352 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 34 ); /*  make-array~1ay%kV~29351 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 35 ); /*  array-dimensions~1ay%kV~29350 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 36 ); /*  array-rank~1ay%kV~29349 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 37 ); /*  equal?~1ay%kV~29348 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 38 ); /*  array?~1ay%kV~29347 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 39 ); /*  array:construct~1ay%kV~29346 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 40 ); /*  array:offset~1ay%kV~29345 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 41 ); /*  array:store~1ay%kV~29344 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 42 ); /*  array:scales~1ay%kV~29343 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 43 ); /*  array:dimensions~1ay%kV~29342 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 44 ); /*  array:rtd~1ay%kV~29341 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 45 ); /*  record-constructor~1ay%kV~29340 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 46 ); /*  make-record-type~1ay%kV~29339 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 47 ); /*  slib:error~1ay%kV~29338 */
  twobit_lambda( compiled_start_1_4, 49, 0 );
  twobit_setglbl( 47 ); /*  slib:error~1ay%kV~29338 */
  twobit_lambda( compiled_start_1_5, 51, 0 );
  twobit_setglbl( 46 ); /*  make-record-type~1ay%kV~29339 */
  twobit_lambda( compiled_start_1_6, 53, 0 );
  twobit_setglbl( 45 ); /*  record-constructor~1ay%kV~29340 */
  twobit_const( 54 );
  twobit_setreg( 1 );
  twobit_const( 55 );
  twobit_setreg( 2 );
  twobit_global( 46 ); /*  make-record-type~1ay%kV~29339 */
  twobit_setrtn( 1008, compiled_block_1_1008 );
  twobit_invoke( 2 );
  twobit_label( 1008, compiled_block_1_1008 );
  twobit_load( 0, 0 );
  twobit_setglbl( 44 ); /*  array:rtd~1ay%kV~29341 */
  twobit_global( 44 ); /*  array:rtd~1ay%kV~29341 */
  twobit_setreg( 1 );
  twobit_const( 56 );
  twobit_setreg( 2 );
  twobit_global( 57 ); /* rtd-accessor */
  twobit_setrtn( 1009, compiled_block_1_1009 );
  twobit_invoke( 2 );
  twobit_label( 1009, compiled_block_1_1009 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_7, 59, 1 );
  twobit_setglbl( 43 ); /*  array:dimensions~1ay%kV~29342 */
  twobit_global( 44 ); /*  array:rtd~1ay%kV~29341 */
  twobit_setreg( 1 );
  twobit_const( 60 );
  twobit_setreg( 2 );
  twobit_global( 61 ); /* rtd-accessor */
  twobit_setrtn( 1015, compiled_block_1_1015 );
  twobit_invoke( 2 );
  twobit_label( 1015, compiled_block_1_1015 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_8, 63, 1 );
  twobit_setglbl( 42 ); /*  array:scales~1ay%kV~29343 */
  twobit_global( 44 ); /*  array:rtd~1ay%kV~29341 */
  twobit_setreg( 1 );
  twobit_const( 64 );
  twobit_setreg( 2 );
  twobit_global( 65 ); /* rtd-accessor */
  twobit_setrtn( 1021, compiled_block_1_1021 );
  twobit_invoke( 2 );
  twobit_label( 1021, compiled_block_1_1021 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_9, 67, 1 );
  twobit_setglbl( 41 ); /*  array:store~1ay%kV~29344 */
  twobit_global( 44 ); /*  array:rtd~1ay%kV~29341 */
  twobit_setreg( 1 );
  twobit_const( 68 );
  twobit_setreg( 2 );
  twobit_global( 69 ); /* rtd-accessor */
  twobit_setrtn( 1027, compiled_block_1_1027 );
  twobit_invoke( 2 );
  twobit_label( 1027, compiled_block_1_1027 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_10, 71, 1 );
  twobit_setglbl( 40 ); /*  array:offset~1ay%kV~29345 */
  twobit_global( 44 ); /*  array:rtd~1ay%kV~29341 */
  twobit_setreg( 1 );
  twobit_const( 72 );
  twobit_setreg( 2 );
  twobit_global( 45 ); /*  record-constructor~1ay%kV~29340 */
  twobit_setrtn( 1033, compiled_block_1_1033 );
  twobit_invoke( 2 );
  twobit_label( 1033, compiled_block_1_1033 );
  twobit_load( 0, 0 );
  twobit_setglbl( 39 ); /*  array:construct~1ay%kV~29346 */
  twobit_global( 44 ); /*  array:rtd~1ay%kV~29341 */
  twobit_setreg( 1 );
  twobit_global( 73 ); /* rtd-predicate */
  twobit_setrtn( 1034, compiled_block_1_1034 );
  twobit_invoke( 1 );
  twobit_label( 1034, compiled_block_1_1034 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_11, 75, 1 );
  twobit_setglbl( 38 ); /*  array?~1ay%kV~29347 */
  twobit_lambda( compiled_start_1_12, 77, 0 );
  twobit_setglbl( 37 ); /*  equal?~1ay%kV~29348 */
  twobit_lambda( compiled_start_1_13, 79, 0 );
  twobit_setglbl( 36 ); /*  array-rank~1ay%kV~29349 */
  twobit_global( 43 ); /*  array:dimensions~1ay%kV~29342 */
  twobit_setglbl( 35 ); /*  array-dimensions~1ay%kV~29350 */
  twobit_lambda( compiled_start_1_14, 81, 0 );
  twobit_setglbl( 34 ); /*  make-array~1ay%kV~29351 */
  twobit_global( 34 ); /*  make-array~1ay%kV~29351 */
  twobit_setglbl( 33 ); /*  create-array~1ay%kV~29352 */
  twobit_lambda( compiled_start_1_15, 83, 0 );
  twobit_setglbl( 32 ); /*  make-shared-array~1ay%kV~29353 */
  twobit_lambda( compiled_start_1_16, 85, 0 );
  twobit_setglbl( 31 ); /*  list->array~1ay%kV~29354 */
  twobit_lambda( compiled_start_1_17, 87, 0 );
  twobit_setglbl( 30 ); /*  array->list~1ay%kV~29355 */
  twobit_lambda( compiled_start_1_18, 89, 0 );
  twobit_setglbl( 29 ); /*  vector->array~1ay%kV~29356 */
  twobit_lambda( compiled_start_1_19, 91, 0 );
  twobit_setglbl( 28 ); /*  array->vector~1ay%kV~29357 */
  twobit_lambda( compiled_start_1_20, 93, 0 );
  twobit_setglbl( 27 ); /*  array:in-bounds?~1ay%kV~29358 */
  twobit_lambda( compiled_start_1_21, 95, 0 );
  twobit_setglbl( 26 ); /*  array-in-bounds?~1ay%kV~29359 */
  twobit_lambda( compiled_start_1_22, 97, 0 );
  twobit_setglbl( 25 ); /*  array-ref~1ay%kV~29360 */
  twobit_lambda( compiled_start_1_23, 99, 0 );
  twobit_setglbl( 24 ); /*  array-set!~1ay%kV~29361 */
  twobit_lambda( compiled_start_1_24, 101, 0 );
  twobit_setglbl( 23 ); /*  make-prototype-checker~1ay%kV~29362 */
  twobit_lambda( compiled_start_1_25, 103, 0 );
  twobit_setglbl( 22 ); /*  integer-bytes??~1ay%kV~29363 */
  twobit_global( 104 ); /* complex? */
  twobit_setreg( 2 );
  twobit_global( 105 ); /* vector */
  twobit_setreg( 3 );
  twobit_const( 106 );
  twobit_setreg( 1 );
  twobit_global( 23 ); /*  make-prototype-checker~1ay%kV~29362 */
  twobit_setrtn( 1333, compiled_block_1_1333 );
  twobit_invoke( 3 );
  twobit_label( 1333, compiled_block_1_1333 );
  twobit_load( 0, 0 );
  twobit_setglbl( 21 ); /*  A:floC128b~1ay%kV~29364 */
  twobit_global( 107 ); /* complex? */
  twobit_setreg( 2 );
  twobit_global( 108 ); /* vector */
  twobit_setreg( 3 );
  twobit_const( 109 );
  twobit_setreg( 1 );
  twobit_global( 23 ); /*  make-prototype-checker~1ay%kV~29362 */
  twobit_setrtn( 1334, compiled_block_1_1334 );
  twobit_invoke( 3 );
  twobit_label( 1334, compiled_block_1_1334 );
  twobit_load( 0, 0 );
  twobit_setglbl( 20 ); /*  A:floC64b~1ay%kV~29365 */
  twobit_global( 110 ); /* complex? */
  twobit_setreg( 2 );
  twobit_global( 111 ); /* vector */
  twobit_setreg( 3 );
  twobit_const( 112 );
  twobit_setreg( 1 );
  twobit_global( 23 ); /*  make-prototype-checker~1ay%kV~29362 */
  twobit_setrtn( 1335, compiled_block_1_1335 );
  twobit_invoke( 3 );
  twobit_label( 1335, compiled_block_1_1335 );
  twobit_load( 0, 0 );
  twobit_setglbl( 19 ); /*  A:floC32b~1ay%kV~29366 */
  twobit_global( 113 ); /* complex? */
  twobit_setreg( 2 );
  twobit_global( 114 ); /* vector */
  twobit_setreg( 3 );
  twobit_const( 115 );
  twobit_setreg( 1 );
  twobit_global( 23 ); /*  make-prototype-checker~1ay%kV~29362 */
  twobit_setrtn( 1336, compiled_block_1_1336 );
  twobit_invoke( 3 );
  twobit_label( 1336, compiled_block_1_1336 );
  twobit_load( 0, 0 );
  twobit_setglbl( 18 ); /*  A:floC16b~1ay%kV~29367 */
  twobit_global( 116 ); /* real? */
  twobit_setreg( 2 );
  twobit_global( 117 ); /* vector */
  twobit_setreg( 3 );
  twobit_const( 118 );
  twobit_setreg( 1 );
  twobit_global( 23 ); /*  make-prototype-checker~1ay%kV~29362 */
  twobit_setrtn( 1337, compiled_block_1_1337 );
  twobit_invoke( 3 );
  twobit_label( 1337, compiled_block_1_1337 );
  twobit_load( 0, 0 );
  twobit_setglbl( 17 ); /*  A:floR128b~1ay%kV~29368 */
  twobit_global( 119 ); /* real? */
  twobit_setreg( 2 );
  twobit_global( 120 ); /* vector */
  twobit_setreg( 3 );
  twobit_const( 121 );
  twobit_setreg( 1 );
  twobit_global( 23 ); /*  make-prototype-checker~1ay%kV~29362 */
  twobit_setrtn( 1338, compiled_block_1_1338 );
  twobit_invoke( 3 );
  twobit_label( 1338, compiled_block_1_1338 );
  twobit_load( 0, 0 );
  twobit_setglbl( 16 ); /*  A:floR64b~1ay%kV~29369 */
  twobit_global( 122 ); /* real? */
  twobit_setreg( 2 );
  twobit_global( 123 ); /* vector */
  twobit_setreg( 3 );
  twobit_const( 124 );
  twobit_setreg( 1 );
  twobit_global( 23 ); /*  make-prototype-checker~1ay%kV~29362 */
  twobit_setrtn( 1339, compiled_block_1_1339 );
  twobit_invoke( 3 );
  twobit_label( 1339, compiled_block_1_1339 );
  twobit_load( 0, 0 );
  twobit_setglbl( 15 ); /*  A:floR32b~1ay%kV~29370 */
  twobit_global( 125 ); /* real? */
  twobit_setreg( 2 );
  twobit_global( 126 ); /* vector */
  twobit_setreg( 3 );
  twobit_const( 127 );
  twobit_setreg( 1 );
  twobit_global( 23 ); /*  make-prototype-checker~1ay%kV~29362 */
  twobit_setrtn( 1340, compiled_block_1_1340 );
  twobit_invoke( 3 );
  twobit_label( 1340, compiled_block_1_1340 );
  twobit_load( 0, 0 );
  twobit_setglbl( 14 ); /*  A:floR16b~1ay%kV~29371 */
  twobit_global( 128 ); /* real? */
  twobit_setreg( 2 );
  twobit_global( 129 ); /* vector */
  twobit_setreg( 3 );
  twobit_const( 130 );
  twobit_setreg( 1 );
  twobit_global( 23 ); /*  make-prototype-checker~1ay%kV~29362 */
  twobit_setrtn( 1341, compiled_block_1_1341 );
  twobit_invoke( 3 );
  twobit_label( 1341, compiled_block_1_1341 );
  twobit_load( 0, 0 );
  twobit_setglbl( 13 ); /*  A:floR128d~1ay%kV~29372 */
  twobit_global( 131 ); /* real? */
  twobit_setreg( 2 );
  twobit_global( 132 ); /* vector */
  twobit_setreg( 3 );
  twobit_const( 133 );
  twobit_setreg( 1 );
  twobit_global( 23 ); /*  make-prototype-checker~1ay%kV~29362 */
  twobit_setrtn( 1342, compiled_block_1_1342 );
  twobit_invoke( 3 );
  twobit_label( 1342, compiled_block_1_1342 );
  twobit_load( 0, 0 );
  twobit_setglbl( 12 ); /*  A:floR64d~1ay%kV~29373 */
  twobit_global( 134 ); /* real? */
  twobit_setreg( 2 );
  twobit_global( 135 ); /* vector */
  twobit_setreg( 3 );
  twobit_const( 136 );
  twobit_setreg( 1 );
  twobit_global( 23 ); /*  make-prototype-checker~1ay%kV~29362 */
  twobit_setrtn( 1343, compiled_block_1_1343 );
  twobit_invoke( 3 );
  twobit_label( 1343, compiled_block_1_1343 );
  twobit_load( 0, 0 );
  twobit_setglbl( 11 ); /*  A:floR32d~1ay%kV~29374 */
  twobit_imm_const( fixnum(-8) ); /* -8 */
  twobit_setreg( 1 );
  twobit_global( 22 ); /*  integer-bytes??~1ay%kV~29363 */
  twobit_setrtn( 1344, compiled_block_1_1344 );
  twobit_invoke( 1 );
  twobit_label( 1344, compiled_block_1_1344 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 137 ); /* vector */
  twobit_setreg( 3 );
  twobit_const( 138 );
  twobit_setreg( 1 );
  twobit_global( 23 ); /*  make-prototype-checker~1ay%kV~29362 */
  twobit_setrtn( 1345, compiled_block_1_1345 );
  twobit_invoke( 3 );
  twobit_label( 1345, compiled_block_1_1345 );
  twobit_load( 0, 0 );
  twobit_setglbl( 10 ); /*  A:fixZ64b~1ay%kV~29375 */
  twobit_imm_const( fixnum(-4) ); /* -4 */
  twobit_setreg( 1 );
  twobit_global( 22 ); /*  integer-bytes??~1ay%kV~29363 */
  twobit_setrtn( 1346, compiled_block_1_1346 );
  twobit_invoke( 1 );
  twobit_label( 1346, compiled_block_1_1346 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 139 ); /* vector */
  twobit_setreg( 3 );
  twobit_const( 140 );
  twobit_setreg( 1 );
  twobit_global( 23 ); /*  make-prototype-checker~1ay%kV~29362 */
  twobit_setrtn( 1347, compiled_block_1_1347 );
  twobit_invoke( 3 );
  twobit_label( 1347, compiled_block_1_1347 );
  twobit_load( 0, 0 );
  twobit_setglbl( 9 ); /*  A:fixZ32b~1ay%kV~29376 */
  twobit_imm_const( fixnum(-2) ); /* -2 */
  twobit_setreg( 1 );
  twobit_global( 22 ); /*  integer-bytes??~1ay%kV~29363 */
  twobit_setrtn( 1348, compiled_block_1_1348 );
  twobit_invoke( 1 );
  twobit_label( 1348, compiled_block_1_1348 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 141 ); /* vector */
  twobit_setreg( 3 );
  twobit_const( 142 );
  twobit_setreg( 1 );
  twobit_global( 23 ); /*  make-prototype-checker~1ay%kV~29362 */
  twobit_setrtn( 1349, compiled_block_1_1349 );
  twobit_invoke( 3 );
  twobit_label( 1349, compiled_block_1_1349 );
  twobit_load( 0, 0 );
  twobit_setglbl( 8 ); /*  A:fixZ16b~1ay%kV~29377 */
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_setreg( 1 );
  twobit_global( 22 ); /*  integer-bytes??~1ay%kV~29363 */
  twobit_setrtn( 1350, compiled_block_1_1350 );
  twobit_invoke( 1 );
  twobit_label( 1350, compiled_block_1_1350 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 143 ); /* vector */
  twobit_setreg( 3 );
  twobit_const( 144 );
  twobit_setreg( 1 );
  twobit_global( 23 ); /*  make-prototype-checker~1ay%kV~29362 */
  twobit_setrtn( 1351, compiled_block_1_1351 );
  twobit_invoke( 3 );
  twobit_label( 1351, compiled_block_1_1351 );
  twobit_load( 0, 0 );
  twobit_setglbl( 7 ); /*  A:fixZ8b~1ay%kV~29378 */
  twobit_imm_const( fixnum(8) ); /* 8 */
  twobit_setreg( 1 );
  twobit_global( 22 ); /*  integer-bytes??~1ay%kV~29363 */
  twobit_setrtn( 1352, compiled_block_1_1352 );
  twobit_invoke( 1 );
  twobit_label( 1352, compiled_block_1_1352 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 145 ); /* vector */
  twobit_setreg( 3 );
  twobit_const( 146 );
  twobit_setreg( 1 );
  twobit_global( 23 ); /*  make-prototype-checker~1ay%kV~29362 */
  twobit_setrtn( 1353, compiled_block_1_1353 );
  twobit_invoke( 3 );
  twobit_label( 1353, compiled_block_1_1353 );
  twobit_load( 0, 0 );
  twobit_setglbl( 6 ); /*  A:fixN64b~1ay%kV~29379 */
  twobit_imm_const( fixnum(4) ); /* 4 */
  twobit_setreg( 1 );
  twobit_global( 22 ); /*  integer-bytes??~1ay%kV~29363 */
  twobit_setrtn( 1354, compiled_block_1_1354 );
  twobit_invoke( 1 );
  twobit_label( 1354, compiled_block_1_1354 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 147 ); /* vector */
  twobit_setreg( 3 );
  twobit_const( 148 );
  twobit_setreg( 1 );
  twobit_global( 23 ); /*  make-prototype-checker~1ay%kV~29362 */
  twobit_setrtn( 1355, compiled_block_1_1355 );
  twobit_invoke( 3 );
  twobit_label( 1355, compiled_block_1_1355 );
  twobit_load( 0, 0 );
  twobit_setglbl( 5 ); /*  A:fixN32b~1ay%kV~29380 */
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 1 );
  twobit_global( 22 ); /*  integer-bytes??~1ay%kV~29363 */
  twobit_setrtn( 1356, compiled_block_1_1356 );
  twobit_invoke( 1 );
  twobit_label( 1356, compiled_block_1_1356 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 149 ); /* vector */
  twobit_setreg( 3 );
  twobit_const( 150 );
  twobit_setreg( 1 );
  twobit_global( 23 ); /*  make-prototype-checker~1ay%kV~29362 */
  twobit_setrtn( 1357, compiled_block_1_1357 );
  twobit_invoke( 3 );
  twobit_label( 1357, compiled_block_1_1357 );
  twobit_load( 0, 0 );
  twobit_setglbl( 4 ); /*  A:fixN16b~1ay%kV~29381 */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_global( 22 ); /*  integer-bytes??~1ay%kV~29363 */
  twobit_setrtn( 1358, compiled_block_1_1358 );
  twobit_invoke( 1 );
  twobit_label( 1358, compiled_block_1_1358 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 151 ); /* vector */
  twobit_setreg( 3 );
  twobit_const( 152 );
  twobit_setreg( 1 );
  twobit_global( 23 ); /*  make-prototype-checker~1ay%kV~29362 */
  twobit_setrtn( 1359, compiled_block_1_1359 );
  twobit_invoke( 3 );
  twobit_label( 1359, compiled_block_1_1359 );
  twobit_load( 0, 0 );
  twobit_setglbl( 3 ); /*  A:fixN8b~1ay%kV~29382 */
  twobit_global( 153 ); /* boolean? */
  twobit_setreg( 2 );
  twobit_global( 154 ); /* vector */
  twobit_setreg( 3 );
  twobit_const( 155 );
  twobit_setreg( 1 );
  twobit_global( 23 ); /*  make-prototype-checker~1ay%kV~29362 */
  twobit_setrtn( 1360, compiled_block_1_1360 );
  twobit_invoke( 3 );
  twobit_label( 1360, compiled_block_1_1360 );
  twobit_load( 0, 0 );
  twobit_setglbl( 2 ); /*  A:bool~1ay%kV~29383 */
  twobit_global( 156 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_movereg( 2, 4 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /* error */
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_global( 3 ); /* apply */
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* string->symbol */
  twobit_setrtn( 1003, compiled_block_1_1003 );
  twobit_invoke( 1 );
  twobit_label( 1003, compiled_block_1_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* list->vector */
  twobit_setrtn( 1004, compiled_block_1_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_1_1004 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 3 ); /* make-rtd */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_6( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /* list->vector */
  twobit_setrtn( 1006, compiled_block_1_1006 );
  twobit_invoke( 1 );
  twobit_label( 1006, compiled_block_1_1006 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* rtd-constructor */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_7( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_41(); /* vector? */
  twobit_branchf( 1011, compiled_block_1_1011 );
  twobit_reg( 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_return();
  twobit_label( 1011, compiled_block_1_1011 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 1013, compiled_block_1_1013 );
  twobit_reg( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_return();
  twobit_label( 1013, compiled_block_1_1013 );
  twobit_lexical( 0, 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_8( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 1017, compiled_block_1_1017 );
  twobit_const( 1 );
  twobit_return();
  twobit_label( 1017, compiled_block_1_1017 );
  twobit_reg( 1 );
  twobit_op1_41(); /* vector? */
  twobit_branchf( 1019, compiled_block_1_1019 );
  twobit_const( 1 );
  twobit_return();
  twobit_label( 1019, compiled_block_1_1019 );
  twobit_lexical( 0, 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_9( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 1023, compiled_block_1_1023 );
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1023, compiled_block_1_1023 );
  twobit_reg( 1 );
  twobit_op1_41(); /* vector? */
  twobit_branchf( 1025, compiled_block_1_1025 );
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1025, compiled_block_1_1025 );
  twobit_lexical( 0, 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_10( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 1029, compiled_block_1_1029 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_return();
  twobit_label( 1029, compiled_block_1_1029 );
  twobit_reg( 1 );
  twobit_op1_41(); /* vector? */
  twobit_branchf( 1031, compiled_block_1_1031 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_return();
  twobit_label( 1031, compiled_block_1_1031 );
  twobit_lexical( 0, 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_11( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1036, compiled_block_1_1036 );
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1036, compiled_block_1_1036 );
  twobit_reg( 1 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1038, compiled_block_1_1038 );
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1038, compiled_block_1_1038 );
  twobit_lexical( 0, 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_12( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op2_57( 2, 79, compiled_temp_1_79 ); /* eqv? */
  twobit_branchf( 1041, compiled_block_1_1041 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_return();
  twobit_label( 1041, compiled_block_1_1041 );
  twobit_reg( 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1043, compiled_block_1_1043 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1042, compiled_block_1_1042 );
  twobit_label( 1043, compiled_block_1_1043 );
  twobit_reg( 2 );
  twobit_op1_11(); /* pair? */
  twobit_label( 1042, compiled_block_1_1042 );
  twobit_branchf( 1045, compiled_block_1_1045 );
  twobit_reg( 4 );
  twobit_branchf( 1047, compiled_block_1_1047 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1049, compiled_block_1_1049 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  equal?~1ay%kV~29348 */
  twobit_setrtn( 1050, compiled_block_1_1050 );
  twobit_invoke( 2 );
  twobit_label( 1050, compiled_block_1_1050 );
  twobit_load( 0, 0 );
  twobit_branchf( 1052, compiled_block_1_1052 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  equal?~1ay%kV~29348 */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1052, compiled_block_1_1052 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1049, compiled_block_1_1049 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1047, compiled_block_1_1047 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1045, compiled_block_1_1045 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 1055, compiled_block_1_1055 );
  twobit_reg( 2 );
  twobit_op1_800(); /* ustring? */
  twobit_skip( 1054, compiled_block_1_1054 );
  twobit_label( 1055, compiled_block_1_1055 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1054, compiled_block_1_1054 );
  twobit_branchf( 1057, compiled_block_1_1057 );
  twobit_global( 2 ); /* string=? */
  twobit_invoke( 2 );
  twobit_label( 1057, compiled_block_1_1057 );
  twobit_reg( 1 );
  twobit_op1_41(); /* vector? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1060, compiled_block_1_1060 );
  twobit_reg( 2 );
  twobit_op1_41(); /* vector? */
  twobit_skip( 1059, compiled_block_1_1059 );
  twobit_label( 1060, compiled_block_1_1060 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1059, compiled_block_1_1059 );
  twobit_branchf( 1062, compiled_block_1_1062 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 3 );
  twobit_reg( 4 );
  twobit_check( 1, 0, 0, 1063, compiled_block_1_1063 );
  twobit_reg( 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_reg_op2_check_662(reg(2),reg(3),1064,compiled_block_1_1064); /* internal:check-vector?/vector-length:vec with (2 0 0) */
  twobit_store( 3, 4 );
  twobit_movereg( 3, 2 );
  twobit_global( 1 ); /*  equal?~1ay%kV~29348 */
  twobit_setrtn( 1065, compiled_block_1_1065 );
  twobit_invoke( 2 );
  twobit_label( 1065, compiled_block_1_1065 );
  twobit_load( 0, 0 );
  twobit_branchf( 1067, compiled_block_1_1067 );
  twobit_load( 4, 1 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_501( 4, 80, compiled_temp_1_80 ); /* +:fix:fix */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 2 );
  twobit_load( 5, 2 );
  twobit_load( 3, 3 );
  twobit_load( 1, 4 );
  twobit_lambda( compiled_start_1_81, 5, 5 );
  twobit_setreg( 4 );
  twobit_load( 1, 5 );
  twobit_reg( 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 1067, compiled_block_1_1067 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1062, compiled_block_1_1062 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_global( 6 ); /*  array?~1ay%kV~29347 */
  twobit_setrtn( 1079, compiled_block_1_1079 );
  twobit_invoke( 1 );
  twobit_label( 1079, compiled_block_1_1079 );
  twobit_load( 0, 0 );
  twobit_branchf( 1081, compiled_block_1_1081 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /*  array?~1ay%kV~29347 */
  twobit_setrtn( 1082, compiled_block_1_1082 );
  twobit_invoke( 1 );
  twobit_label( 1082, compiled_block_1_1082 );
  twobit_load( 0, 0 );
  twobit_skip( 1080, compiled_block_1_1080 );
  twobit_label( 1081, compiled_block_1_1081 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1080, compiled_block_1_1080 );
  twobit_branchf( 1084, compiled_block_1_1084 );
  twobit_load( 1, 2 );
  twobit_global( 7 ); /*  array:dimensions~1ay%kV~29342 */
  twobit_setrtn( 1085, compiled_block_1_1085 );
  twobit_invoke( 1 );
  twobit_label( 1085, compiled_block_1_1085 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_global( 7 ); /*  array:dimensions~1ay%kV~29342 */
  twobit_setrtn( 1086, compiled_block_1_1086 );
  twobit_invoke( 1 );
  twobit_label( 1086, compiled_block_1_1086 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_global( 1 ); /*  equal?~1ay%kV~29348 */
  twobit_setrtn( 1087, compiled_block_1_1087 );
  twobit_invoke( 2 );
  twobit_label( 1087, compiled_block_1_1087 );
  twobit_load( 0, 0 );
  twobit_branchf( 1089, compiled_block_1_1089 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 3, 1 );
  twobit_load( 2, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_82, 9, 3 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_movereg( 2, 1 );
  twobit_global( 7 ); /*  array:dimensions~1ay%kV~29342 */
  twobit_setrtn( 1103, compiled_block_1_1103 );
  twobit_invoke( 1 );
  twobit_label( 1103, compiled_block_1_1103 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 10 ); /* reverse */
  twobit_setrtn( 1104, compiled_block_1_1104 );
  twobit_invoke( 1 );
  twobit_label( 1104, compiled_block_1_1104 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_stack( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1089, compiled_block_1_1089 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1084, compiled_block_1_1084 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1064, compiled_block_1_1064 );
  twobit_trap( 2, 0, 0, 162 );
  twobit_label( 1063, compiled_block_1_1063 );
  twobit_trap( 1, 0, 0, 162 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_81( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_reg( 1 );
  twobit_op2imm_132( fixnum(0), 87, compiled_temp_1_87 ); /* < */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_branchf( 1069, compiled_block_1_1069 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1068, compiled_block_1_1068 );
  twobit_label( 1069, compiled_block_1_1069 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 1, 2, 0, 1070, compiled_block_1_1070 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 1, 2, 0, 1070, compiled_block_1_1070 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_check( 1, 2, 0, 1070, compiled_block_1_1070 );
  twobit_lexical( 0, 3 );
  twobit_op2_402( 1 ); /* vector-ref:trusted */
  twobit_setreg( 2 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op2_407( 3 ); /* <:fix:fix */
  twobit_setreg( 3 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_check( 1, 31, 0, 1071, compiled_block_1_1071 );
  twobit_lexical( 0, 5 );
  twobit_op2_402( 1 ); /* vector-ref:trusted */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  equal?~1ay%kV~29348 */
  twobit_setrtn( 1072, compiled_block_1_1072 );
  twobit_invoke( 2 );
  twobit_label( 1072, compiled_block_1_1072 );
  twobit_load( 0, 0 );
  twobit_branchf( 1074, compiled_block_1_1074 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1068, compiled_block_1_1068 );
  twobit_label( 1074, compiled_block_1_1074 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_label( 1068, compiled_block_1_1068 );
  twobit_branchf( 1076, compiled_block_1_1076 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1076, compiled_block_1_1076 );
  twobit_load( 4, 2 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 4, 88, compiled_temp_1_88 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1070, compiled_block_1_1070 );
  twobit_trap( 2, 1, 0, 160 );
  twobit_label( 1071, compiled_block_1_1071 );
  twobit_trap( 31, 1, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_82( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1091, compiled_block_1_1091 ); /* internal:branchf-null? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 3 );
  twobit_global( 1 ); /*  array-ref~1ay%kV~29360 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* apply */
  twobit_setrtn( 1092, compiled_block_1_1092 );
  twobit_invoke( 3 );
  twobit_label( 1092, compiled_block_1_1092 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 3, 1 );
  twobit_global( 1 ); /*  array-ref~1ay%kV~29360 */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* apply */
  twobit_setrtn( 1093, compiled_block_1_1093 );
  twobit_invoke( 3 );
  twobit_label( 1093, compiled_block_1_1093 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 3 ); /*  equal?~1ay%kV~29348 */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1091, compiled_block_1_1091 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg_op1_check_652(reg(1),1095,compiled_block_1_1095); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 4, 83, compiled_temp_1_83 ); /* + */
  twobit_setreg( 4 );
  twobit_global( 4 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_lambda( compiled_start_1_84, 6, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 4, 2 );
  twobit_load( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1095, compiled_block_1_1095 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_84( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_9(); /* not */
  twobit_branchf( 1097, compiled_block_1_1097 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1096, compiled_block_1_1096 );
  twobit_label( 1097, compiled_block_1_1097 );
  twobit_reg( 2 );
  twobit_op2imm_132( fixnum(0), 85, compiled_temp_1_85 ); /* < */
  twobit_label( 1096, compiled_block_1_1096 );
  twobit_branchf( 1099, compiled_block_1_1099 );
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1099, compiled_block_1_1099 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 2, 86, compiled_temp_1_86 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1100, compiled_block_1_1100 );
  twobit_invoke( 2 );
  twobit_label( 1100, compiled_block_1_1100 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_13( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  array?~1ay%kV~29347 */
  twobit_setrtn( 1106, compiled_block_1_1106 );
  twobit_invoke( 1 );
  twobit_label( 1106, compiled_block_1_1106 );
  twobit_load( 0, 0 );
  twobit_branchf( 1108, compiled_block_1_1108 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  array:dimensions~1ay%kV~29342 */
  twobit_setrtn( 1109, compiled_block_1_1109 );
  twobit_invoke( 1 );
  twobit_label( 1109, compiled_block_1_1109 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* length */
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1108, compiled_block_1_1108 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_14( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_global( 1 ); /*  array:store~1ay%kV~29344 */
  twobit_setrtn( 1113, compiled_block_1_1113 );
  twobit_invoke( 1 );
  twobit_label( 1113, compiled_block_1_1113 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  array:dimensions~1ay%kV~29342 */
  twobit_setrtn( 1114, compiled_block_1_1114 );
  twobit_invoke( 1 );
  twobit_label( 1114, compiled_block_1_1114 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 2 );
  twobit_global( 3 ); /* length */
  twobit_setrtn( 1115, compiled_block_1_1115 );
  twobit_invoke( 1 );
  twobit_label( 1115, compiled_block_1_1115 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_57( 4, 75, compiled_temp_1_75 ); /* eqv? */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_global( 4 ); /* * */
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 5 ); /* apply */
  twobit_setrtn( 1116, compiled_block_1_1116 );
  twobit_invoke( 2 );
  twobit_label( 1116, compiled_block_1_1116 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 2, 3 );
  twobit_global( 4 ); /* * */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* apply */
  twobit_setrtn( 1117, compiled_block_1_1117 );
  twobit_invoke( 2 );
  twobit_label( 1117, compiled_block_1_1117 );
  twobit_load( 0, 0 );
  twobit_op1_branchf_612( 76, compiled_temp_1_76, 1119, compiled_block_1_1119 ); /* internal:branchf-zero? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_skip( 1118, compiled_block_1_1118 );
  twobit_label( 1119, compiled_block_1_1119 );
  twobit_lambda( compiled_start_1_77, 7, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_global( 8 ); /*  map~1ay%kV~1381 */
  twobit_setrtn( 1120, compiled_block_1_1120 );
  twobit_invoke( 2 );
  twobit_label( 1120, compiled_block_1_1120 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_global( 9 ); /*  array-ref~1ay%kV~29360 */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* apply */
  twobit_setrtn( 1121, compiled_block_1_1121 );
  twobit_invoke( 3 );
  twobit_label( 1121, compiled_block_1_1121 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_label( 1118, compiled_block_1_1118 );
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_branchf( 1123, compiled_block_1_1123 );
  twobit_stack( 5 );
  twobit_op1_800(); /* ustring? */
  twobit_skip( 1122, compiled_block_1_1122 );
  twobit_label( 1123, compiled_block_1_1123 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1122, compiled_block_1_1122 );
  twobit_branchf( 1125, compiled_block_1_1125 );
  twobit_movereg( 4, 3 );
  twobit_global( 10 ); /* make-string */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 2, 2 );
  twobit_check( 2, 0, 0, 1126, compiled_block_1_1126 );
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_global( 5 ); /* apply */
  twobit_pop( 6 );
  twobit_invoke( 3 );
  twobit_label( 1125, compiled_block_1_1125 );
  twobit_stack( 4 );
  twobit_branchf( 1129, compiled_block_1_1129 );
  twobit_stack( 5 );
  twobit_op1_41(); /* vector? */
  twobit_skip( 1128, compiled_block_1_1128 );
  twobit_label( 1129, compiled_block_1_1129 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1128, compiled_block_1_1128 );
  twobit_branchf( 1131, compiled_block_1_1131 );
  twobit_global( 11 ); /* make-vector */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 2, 2 );
  twobit_check( 2, 0, 0, 1126, compiled_block_1_1126 );
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_movereg( 4, 3 );
  twobit_global( 5 ); /* apply */
  twobit_pop( 6 );
  twobit_invoke( 3 );
  twobit_label( 1131, compiled_block_1_1131 );
  twobit_stack( 5 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 1134, compiled_block_1_1134 );
  twobit_load( 2, 6 );
  twobit_global( 10 ); /* make-string */
  twobit_setreg( 1 );
  twobit_movereg( 4, 3 );
  twobit_global( 5 ); /* apply */
  twobit_setrtn( 1135, compiled_block_1_1135 );
  twobit_invoke( 3 );
  twobit_label( 1135, compiled_block_1_1135 );
  twobit_load( 0, 0 );
  twobit_skip( 1133, compiled_block_1_1133 );
  twobit_label( 1134, compiled_block_1_1134 );
  twobit_global( 11 ); /* make-vector */
  twobit_setreg( 1 );
  twobit_load( 2, 6 );
  twobit_movereg( 4, 3 );
  twobit_global( 5 ); /* apply */
  twobit_setrtn( 1136, compiled_block_1_1136 );
  twobit_invoke( 3 );
  twobit_label( 1136, compiled_block_1_1136 );
  twobit_load( 0, 0 );
  twobit_label( 1133, compiled_block_1_1133 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 2 );
  twobit_global( 12 ); /* reverse */
  twobit_setrtn( 1137, compiled_block_1_1137 );
  twobit_invoke( 1 );
  twobit_label( 1137, compiled_block_1_1137 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 5 );
  twobit_load( 1, 2 );
  twobit_const( 13 );
  twobit_setreg( 4 );
  twobit_pop( 6 );
  twobit_label( 1111, compiled_block_1_1111 );
  twobit_reg( 3 );
  twobit_op1_branchf_610( 1140, compiled_block_1_1140 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_load( 4, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_global( 14 ); /*  array:construct~1ay%kV~29346 */
  twobit_pop( 1 );
  twobit_invoke( 4 );
  twobit_label( 1140, compiled_block_1_1140 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg_op1_check_652(reg(3),1142,compiled_block_1_1142); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_op2_63( 31, 78, compiled_temp_1_78 ); /* * */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_branch( 1111, compiled_block_1_1111 );
  twobit_label( 1126, compiled_block_1_1126 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 1142, compiled_block_1_1142 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_77( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_15( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 6 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_global( 2 ); /*  array:scales~1ay%kV~29343 */
  twobit_setrtn( 1144, compiled_block_1_1144 );
  twobit_invoke( 1 );
  twobit_label( 1144, compiled_block_1_1144 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /* length */
  twobit_setrtn( 1145, compiled_block_1_1145 );
  twobit_invoke( 1 );
  twobit_label( 1145, compiled_block_1_1145 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 2, 1 );
  twobit_lambda( compiled_start_1_63, 5, 0 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  map~1ay%kV~1381 */
  twobit_setrtn( 1149, compiled_block_1_1149 );
  twobit_invoke( 2 );
  twobit_label( 1149, compiled_block_1_1149 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_load( 4, 3 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 4, 64, compiled_temp_1_64 ); /* + */
  twobit_setreg( 3 );
  twobit_store( 3, 7 );
  twobit_reg( 4 );
  twobit_op1_branchf_612( 65, compiled_temp_1_65, 1151, compiled_block_1_1151 ); /* internal:branchf-zero? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_skip( 1150, compiled_block_1_1150 );
  twobit_label( 1151, compiled_block_1_1151 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_80( 2 ); /* make-vector */
  twobit_setreg( 1 );
  twobit_global( 7 ); /* vector->list */
  twobit_setrtn( 1152, compiled_block_1_1152 );
  twobit_invoke( 1 );
  twobit_label( 1152, compiled_block_1_1152 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1153,compiled_block_1_1153); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 2 );
  twobit_global( 9 ); /* append */
  twobit_setrtn( 1154, compiled_block_1_1154 );
  twobit_invoke( 2 );
  twobit_label( 1154, compiled_block_1_1154 );
  twobit_load( 0, 0 );
  twobit_label( 1150, compiled_block_1_1150 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 5, 4 );
  twobit_load( 4, 5 );
  twobit_load( 2, 6 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_66, 11, 5 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_load( 1, 7 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_pop( 7 );
  twobit_invoke( 3 );
  twobit_label( 1153, compiled_block_1_1153 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_63( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1146, compiled_block_1_1146 );
  twobit_invoke( 1 );
  twobit_label( 1146, compiled_block_1_1146 );
  twobit_load( 0, 0 );
  twobit_branchf( 1148, compiled_block_1_1148 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1148, compiled_block_1_1148 );
  twobit_load( 4, 1 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 4, 74, compiled_temp_1_74 ); /* + */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_66( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(0), 67, compiled_temp_1_67, 1156, compiled_block_1_1156 ); /* internal:branchf-</imm */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* apply */
  twobit_setrtn( 1157, compiled_block_1_1157 );
  twobit_invoke( 2 );
  twobit_label( 1157, compiled_block_1_1157 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /* * */
  twobit_setreg( 1 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  map~1ay%kV~1381 */
  twobit_setrtn( 1158, compiled_block_1_1158 );
  twobit_invoke( 3 );
  twobit_label( 1158, compiled_block_1_1158 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* + */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* apply */
  twobit_setrtn( 1159, compiled_block_1_1159 );
  twobit_invoke( 2 );
  twobit_label( 1159, compiled_block_1_1159 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_lambda( compiled_start_1_68, 6, 0 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  map~1ay%kV~1381 */
  twobit_setrtn( 1162, compiled_block_1_1162 );
  twobit_invoke( 2 );
  twobit_label( 1162, compiled_block_1_1162 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 2, 1 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_69, 8, 1 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  map~1ay%kV~1381 */
  twobit_setrtn( 1166, compiled_block_1_1166 );
  twobit_invoke( 2 );
  twobit_label( 1166, compiled_block_1_1166 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  array:offset~1ay%kV~29345 */
  twobit_setrtn( 1167, compiled_block_1_1167 );
  twobit_invoke( 1 );
  twobit_label( 1167, compiled_block_1_1167 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_global( 10 ); /* car */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  map~1ay%kV~1381 */
  twobit_setrtn( 1168, compiled_block_1_1168 );
  twobit_invoke( 2 );
  twobit_label( 1168, compiled_block_1_1168 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* apply */
  twobit_setrtn( 1169, compiled_block_1_1169 );
  twobit_invoke( 2 );
  twobit_label( 1169, compiled_block_1_1169 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /* * */
  twobit_setreg( 1 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  map~1ay%kV~1381 */
  twobit_setrtn( 1170, compiled_block_1_1170 );
  twobit_invoke( 3 );
  twobit_label( 1170, compiled_block_1_1170 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_global( 4 ); /* + */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* apply */
  twobit_setrtn( 1171, compiled_block_1_1171 );
  twobit_invoke( 3 );
  twobit_label( 1171, compiled_block_1_1171 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 1 );
  twobit_global( 11 ); /*  array:store~1ay%kV~29344 */
  twobit_setrtn( 1172, compiled_block_1_1172 );
  twobit_invoke( 1 );
  twobit_label( 1172, compiled_block_1_1172 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 2 );
  twobit_load( 2, 1 );
  twobit_load( 1, 3 );
  twobit_global( 12 ); /*  array:construct~1ay%kV~29346 */
  twobit_pop( 3 );
  twobit_invoke( 4 );
  twobit_label( 1156, compiled_block_1_1156 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 1, 70, compiled_temp_1_70 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg_op1_check_652(reg(2),1174,compiled_block_1_1174); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_const( 13 );
  twobit_setreg( 2 );
  twobit_global( 14 ); /* append */
  twobit_setrtn( 1175, compiled_block_1_1175 );
  twobit_invoke( 2 );
  twobit_label( 1175, compiled_block_1_1175 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_load( 3, 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1174, compiled_block_1_1174 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_68( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op1_check_652(reg(1),1160,compiled_block_1_1160); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg_op1_check_652(reg(3),1161,compiled_block_1_1161); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_op2_62( 4, 72, compiled_temp_1_72 ); /* - */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 3, 73, compiled_temp_1_73 ); /* + */
  twobit_return();
  twobit_label( 1161, compiled_block_1_1161 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_label( 1160, compiled_block_1_1160 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_69( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* apply */
  twobit_setrtn( 1163, compiled_block_1_1163 );
  twobit_invoke( 2 );
  twobit_label( 1163, compiled_block_1_1163 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /* * */
  twobit_setreg( 1 );
  twobit_lexical( 1, 4 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  map~1ay%kV~1381 */
  twobit_setrtn( 1164, compiled_block_1_1164 );
  twobit_invoke( 3 );
  twobit_label( 1164, compiled_block_1_1164 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* + */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* apply */
  twobit_setrtn( 1165, compiled_block_1_1165 );
  twobit_invoke( 2 );
  twobit_label( 1165, compiled_block_1_1165 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_62( 4, 71, compiled_temp_1_71 ); /* - */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_16( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_movereg( 3, 2 );
  twobit_store( 2, 1 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 1, 55, compiled_temp_1_55 ); /* + */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 1 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_1_56, 3, 2 );
  twobit_setreg( 31 );
  twobit_movereg( 4, 3 );
  twobit_reg( 1 );
  twobit_op2_84( 31 ); /* cell-set! */
  twobit_reg( 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1186, compiled_block_1_1186 );
  twobit_invoke( 3 );
  twobit_label( 1186, compiled_block_1_1186 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 3 );
  twobit_global( 4 ); /*  make-array~1ay%kV~29351 */
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 5 ); /* apply */
  twobit_setrtn( 1187, compiled_block_1_1187 );
  twobit_invoke( 3 );
  twobit_label( 1187, compiled_block_1_1187 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 3 );
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 5 );
  twobit_load( 1, 1 );
  twobit_load( 3, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_setrtn( 1188, compiled_block_1_1188 );
  twobit_branch( 1178, compiled_block_1_1178 );
  twobit_label( 1188, compiled_block_1_1188 );
  twobit_load( 0, 0 );
  twobit_stack( 2 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1178, compiled_block_1_1178 );
  twobit_reg( 3 );
  twobit_op1_branchf_610( 1190, compiled_block_1_1190 ); /* internal:branchf-null? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 5, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 6 ); /* reverse */
  twobit_setrtn( 1191, compiled_block_1_1191 );
  twobit_invoke( 1 );
  twobit_label( 1191, compiled_block_1_1191 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_global( 7 ); /*  array-set!~1ay%kV~29361 */
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 5 ); /* apply */
  twobit_pop( 2 );
  twobit_invoke( 4 );
  twobit_label( 1190, compiled_block_1_1190 );
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 5 );
  twobit_store( 3, 2 );
  twobit_store( 4, 4 );
  twobit_store( 5, 6 );
  twobit_movereg( 5, 1 );
  twobit_reg_op1_check_652(reg(3),1193,compiled_block_1_1193); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 1 );
  twobit_global( 8 ); /* length */
  twobit_setrtn( 1194, compiled_block_1_1194 );
  twobit_invoke( 1 );
  twobit_label( 1194, compiled_block_1_1194 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_57( 4, 57, compiled_temp_1_57 ); /* eqv? */
  twobit_branchf( 1196, compiled_block_1_1196 );
  twobit_op1_3(); /* unspecified */
  twobit_skip( 1195, compiled_block_1_1195 );
  twobit_label( 1196, compiled_block_1_1196 );
  twobit_load( 4, 2 );
  twobit_stack( 3 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 5 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_const( 10 );
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_global( 12 ); /*  slib:error~1ay%kV~29338 */
  twobit_setrtn( 1197, compiled_block_1_1197 );
  twobit_invoke( 5 );
  twobit_label( 1197, compiled_block_1_1197 );
  twobit_load( 0, 0 );
  twobit_label( 1195, compiled_block_1_1195 );
  twobit_branchf( 1199, compiled_block_1_1199 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 5, 4 );
  twobit_load( 3, 2 );
  twobit_load( 2, 3 );
  twobit_load( 1, 5 );
  twobit_lambda( compiled_start_1_58, 14, 5 );
  twobit_setreg( 3 );
  twobit_load( 2, 6 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_pop( 6 );
  twobit_invoke( 2 );
  twobit_label( 1199, compiled_block_1_1199 );
  twobit_op1_3(); /* unspecified */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1193, compiled_block_1_1193 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_56( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 3 );
  twobit_op2imm_branchf_635( fixnum(0), 61, compiled_temp_1_61, 1181, compiled_block_1_1181 ); /* internal:branchf-</imm */
  twobit_global( 1 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1181, compiled_block_1_1181 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_movereg( 2, 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_check( 4, 0, 0, 1183, compiled_block_1_1183 );
  twobit_lexical( 0, 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 3, 62, compiled_temp_1_62 ); /* + */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_global( 2 ); /* length */
  twobit_setrtn( 1184, compiled_block_1_1184 );
  twobit_invoke( 1 );
  twobit_label( 1184, compiled_block_1_1184 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1183, compiled_block_1_1183 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_58( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_621( 4, 59, compiled_temp_1_59, 1201, compiled_block_1_1201 ); /* internal:branchf->= */
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_label( 1201, compiled_block_1_1201 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 3 );
  twobit_reg_op1_check_652(reg(2),1202,compiled_block_1_1202); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_load( 5, 1 );
  twobit_setrtn( 1203, compiled_block_1_1203 );
  twobit_jump( 1, 1178, compiled_block_1_1178 );
  twobit_label( 1203, compiled_block_1_1203 );
  twobit_load( 0, 0 );
  twobit_load( 4, 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 4, 60, compiled_temp_1_60 ); /* + */
  twobit_setreg( 1 );
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1202, compiled_block_1_1202 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_17( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  array:dimensions~1ay%kV~29342 */
  twobit_setrtn( 1208, compiled_block_1_1208 );
  twobit_invoke( 1 );
  twobit_label( 1208, compiled_block_1_1208 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_pop( 1 );
  twobit_label( 1206, compiled_block_1_1206 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1211, compiled_block_1_1211 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_global( 2 ); /* reverse */
  twobit_setrtn( 1212, compiled_block_1_1212 );
  twobit_invoke( 1 );
  twobit_label( 1212, compiled_block_1_1212 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_global( 3 ); /*  array-ref~1ay%kV~29360 */
  twobit_setreg( 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_label( 1211, compiled_block_1_1211 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg_op1_check_652(reg(2),1214,compiled_block_1_1214); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 4, 51, compiled_temp_1_51 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_global( 5 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 31 );
  twobit_movereg( 31, 4 );
  twobit_lambda( compiled_start_1_52, 7, 4 );
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_reg( 31 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 31 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1214, compiled_block_1_1214 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_52( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op2imm_branchf_635( fixnum(0), 53, compiled_temp_1_53, 1216, compiled_block_1_1216 ); /* internal:branchf-</imm */
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1216, compiled_block_1_1216 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 2, 54, compiled_temp_1_54 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_lexical( 0, 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_setrtn( 1217, compiled_block_1_1217 );
  twobit_jump( 1, 1206, compiled_block_1_1206 );
  twobit_label( 1217, compiled_block_1_1217 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_load( 3, 2 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 1 );
  twobit_lexical( 0, 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_18( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 5 );
  twobit_store( 2, 4 );
  twobit_store( 3, 2 );
  twobit_movereg( 3, 2 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg_op2_check_662(reg(1),reg(31),1222,compiled_block_1_1222); /* internal:check-vector?/vector-length:vec with (1 0 0) */
  twobit_reg( 4 );
  twobit_op2_84( 31 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 31 );
  twobit_store( 31, 1 );
  twobit_global( 2 ); /* * */
  twobit_setreg( 1 );
  twobit_global( 3 ); /* apply */
  twobit_setrtn( 1223, compiled_block_1_1223 );
  twobit_invoke( 2 );
  twobit_label( 1223, compiled_block_1_1223 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_57( 4, 45, compiled_temp_1_45 ); /* eqv? */
  twobit_branchf( 1225, compiled_block_1_1225 );
  twobit_op1_3(); /* unspecified */
  twobit_skip( 1224, compiled_block_1_1224 );
  twobit_label( 1225, compiled_block_1_1225 );
  twobit_load( 4, 2 );
  twobit_const( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_global( 7 ); /*  slib:error~1ay%kV~29338 */
  twobit_setrtn( 1226, compiled_block_1_1226 );
  twobit_invoke( 4 );
  twobit_label( 1226, compiled_block_1_1226 );
  twobit_load( 0, 0 );
  twobit_label( 1224, compiled_block_1_1224 );
  twobit_global( 8 ); /*  make-array~1ay%kV~29351 */
  twobit_setreg( 1 );
  twobit_load( 2, 4 );
  twobit_load( 3, 2 );
  twobit_global( 3 ); /* apply */
  twobit_setrtn( 1227, compiled_block_1_1227 );
  twobit_invoke( 3 );
  twobit_label( 1227, compiled_block_1_1227 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 4, 2 );
  twobit_load( 3, 4 );
  twobit_load( 1, 5 );
  twobit_load( 2, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 5 );
  twobit_setrtn( 1228, compiled_block_1_1228 );
  twobit_branch( 1220, compiled_block_1_1220 );
  twobit_label( 1228, compiled_block_1_1228 );
  twobit_load( 0, 0 );
  twobit_stack( 4 );
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1220, compiled_block_1_1220 );
  twobit_reg( 4 );
  twobit_op1_branchf_610( 1230, compiled_block_1_1230 ); /* internal:branchf-null? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_reg( 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 4, 46, compiled_temp_1_46 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg_op1_check_651(reg(4),1231,compiled_block_1_1231); /* internal:check-fixnum? with (4 1 0) */
  twobit_reg( 1 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 2 );
  twobit_reg_op2_check_661(reg(4),reg(2),1231,compiled_block_1_1231); /* internal:check-range with (4 1 0) */
  twobit_reg( 1 );
  twobit_op2_402( 4 ); /* vector-ref:trusted */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 5, 1 );
  twobit_global( 9 ); /* reverse */
  twobit_setrtn( 1232, compiled_block_1_1232 );
  twobit_invoke( 1 );
  twobit_label( 1232, compiled_block_1_1232 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_load( 3, 2 );
  twobit_global( 10 ); /*  array-set!~1ay%kV~29361 */
  twobit_setreg( 1 );
  twobit_global( 3 ); /* apply */
  twobit_pop( 2 );
  twobit_invoke( 4 );
  twobit_label( 1230, compiled_block_1_1230 );
  twobit_reg_op1_check_652(reg(4),1234,compiled_block_1_1234); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 31, 47, compiled_temp_1_47 ); /* + */
  twobit_setreg( 31 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 30 );
  twobit_movereg( 30, 6 );
  twobit_lambda( compiled_start_1_48, 12, 6 );
  twobit_setreg( 4 );
  twobit_movereg( 31, 1 );
  twobit_reg( 30 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 30 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 1234, compiled_block_1_1234 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 1222, compiled_block_1_1222 );
  twobit_trap( 1, 0, 0, 162 );
  twobit_label( 1231, compiled_block_1_1231 );
  twobit_trap( 1, 4, 0, 160 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_48( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(0), 49, compiled_temp_1_49, 1236, compiled_block_1_1236 ); /* internal:branchf-</imm */
  twobit_lexical( 0, 1 );
  twobit_return();
  twobit_label( 1236, compiled_block_1_1236 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_load( 5, 1 );
  twobit_setrtn( 1237, compiled_block_1_1237 );
  twobit_jump( 1, 1220, compiled_block_1_1220 );
  twobit_label( 1237, compiled_block_1_1237 );
  twobit_load( 0, 0 );
  twobit_load( 4, 2 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 4, 50, compiled_temp_1_50 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 0, 6 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_19( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  array:dimensions~1ay%kV~29342 */
  twobit_setrtn( 1242, compiled_block_1_1242 );
  twobit_invoke( 1 );
  twobit_label( 1242, compiled_block_1_1242 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 2 );
  twobit_global( 2 ); /* * */
  twobit_setreg( 1 );
  twobit_global( 3 ); /* apply */
  twobit_setrtn( 1243, compiled_block_1_1243 );
  twobit_invoke( 2 );
  twobit_label( 1243, compiled_block_1_1243 );
  twobit_load( 0, 0 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_imm_const_setreg( NIL_CONST, 2 ); /* () */
  twobit_op2_80( 2 ); /* make-vector */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_load( 1, 1 );
  twobit_movereg( 4, 2 );
  twobit_load( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 5 );
  twobit_setrtn( 1244, compiled_block_1_1244 );
  twobit_branch( 1240, compiled_block_1_1240 );
  twobit_label( 1244, compiled_block_1_1244 );
  twobit_load( 0, 0 );
  twobit_stack( 3 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1240, compiled_block_1_1240 );
  twobit_reg( 4 );
  twobit_op1_branchf_610( 1246, compiled_block_1_1246 ); /* internal:branchf-null? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_store( 3, 3 );
  twobit_movereg( 5, 1 );
  twobit_global( 4 ); /* reverse */
  twobit_setrtn( 1247, compiled_block_1_1247 );
  twobit_invoke( 1 );
  twobit_label( 1247, compiled_block_1_1247 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /*  array-ref~1ay%kV~29360 */
  twobit_setreg( 1 );
  twobit_global( 3 ); /* apply */
  twobit_setrtn( 1248, compiled_block_1_1248 );
  twobit_invoke( 3 );
  twobit_label( 1248, compiled_block_1_1248 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 3, 40, compiled_temp_1_40 ); /* + */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_stack( 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 2, 3 );
  twobit_check( 4, 3, 2, 1249, compiled_block_1_1249 );
  twobit_stack( 3 );
  twobit_op1_401(); /* vector-length:vec */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2_407( 2 ); /* <:fix:fix */
  twobit_load( 2, 3 );
  twobit_check( 4, 3, 2, 1249, compiled_block_1_1249 );
  twobit_reg_op2imm_check_660(reg(3),fixnum(0),1249,compiled_block_1_1249); /* internal:check->=:fix:fix/imm with (4 3 2) */
  twobit_stack( 3 );
  twobit_op3_403( 3, 4 ); /* vector-set!:trusted */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1246, compiled_block_1_1246 );
  twobit_reg_op1_check_652(reg(4),1250,compiled_block_1_1250); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 31, 41, compiled_temp_1_41 ); /* + */
  twobit_setreg( 31 );
  twobit_global( 6 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 30 );
  twobit_movereg( 30, 6 );
  twobit_lambda( compiled_start_1_42, 8, 6 );
  twobit_setreg( 4 );
  twobit_movereg( 31, 1 );
  twobit_reg( 30 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 30 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 1250, compiled_block_1_1250 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 1249, compiled_block_1_1249 );
  twobit_trap( 2, 3, 4, 161 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_42( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(0), 43, compiled_temp_1_43, 1252, compiled_block_1_1252 ); /* internal:branchf-</imm */
  twobit_lexical( 0, 3 );
  twobit_return();
  twobit_label( 1252, compiled_block_1_1252 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_lexical( 0, 5 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_load( 5, 1 );
  twobit_setrtn( 1253, compiled_block_1_1253 );
  twobit_jump( 1, 1240, compiled_block_1_1240 );
  twobit_label( 1253, compiled_block_1_1253 );
  twobit_load( 0, 0 );
  twobit_load( 4, 2 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 4, 44, compiled_temp_1_44 ); /* + */
  twobit_setreg( 1 );
  twobit_lexical( 0, 6 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_20( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_global( 1 ); /*  array:dimensions~1ay%kV~29342 */
  twobit_setrtn( 1256, compiled_block_1_1256 );
  twobit_invoke( 1 );
  twobit_label( 1256, compiled_block_1_1256 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_37, 4, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_37( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_10(); /* null? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1258, compiled_block_1_1258 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1257, compiled_block_1_1257 );
  twobit_label( 1258, compiled_block_1_1258 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1260, compiled_block_1_1260 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1257, compiled_block_1_1257 );
  twobit_label( 1260, compiled_block_1_1260 );
  twobit_reg_op1_check_652(reg(2),1261,compiled_block_1_1261); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_22(); /* integer? */
  twobit_op1_9(); /* not */
  twobit_branchf( 1263, compiled_block_1_1263 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1257, compiled_block_1_1257 );
  twobit_label( 1263, compiled_block_1_1263 );
  twobit_reg_op1_check_652(reg(1),1264,compiled_block_1_1264); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 3 );
  twobit_op2_66( 31, 38, compiled_temp_1_38 ); /* < */
  twobit_setreg( 31 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_branchf_619( 3, 39, compiled_temp_1_39, 1266, compiled_block_1_1266 ); /* internal:branchf-< */
  twobit_reg( 31 );
  twobit_skip( 1265, compiled_block_1_1265 );
  twobit_label( 1266, compiled_block_1_1266 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1265, compiled_block_1_1265 );
  twobit_branchf( 1268, compiled_block_1_1268 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1257, compiled_block_1_1257 );
  twobit_label( 1268, compiled_block_1_1268 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_label( 1257, compiled_block_1_1257 );
  twobit_branchf( 1270, compiled_block_1_1270 );
  twobit_reg( 4 );
  twobit_branchf( 1272, compiled_block_1_1272 );
  twobit_reg( 2 );
  twobit_op1_10(); /* null? */
  twobit_return();
  twobit_label( 1272, compiled_block_1_1272 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1270, compiled_block_1_1270 );
  twobit_reg_op1_check_652(reg(1),1273,compiled_block_1_1273); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg_op1_check_652(reg(2),1274,compiled_block_1_1274); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 1273, compiled_block_1_1273 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_label( 1261, compiled_block_1_1261 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 1274, compiled_block_1_1274 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_label( 1264, compiled_block_1_1264 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_21( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_global( 1 ); /*  array:in-bounds?~1ay%kV~29358 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_22( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_global( 1 ); /*  array:store~1ay%kV~29344 */
  twobit_setrtn( 1278, compiled_block_1_1278 );
  twobit_invoke( 1 );
  twobit_label( 1278, compiled_block_1_1278 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 2 ); /*  array:in-bounds?~1ay%kV~29358 */
  twobit_setrtn( 1279, compiled_block_1_1279 );
  twobit_invoke( 2 );
  twobit_label( 1279, compiled_block_1_1279 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1281, compiled_block_1_1281 );
  twobit_skip( 1280, compiled_block_1_1280 );
  twobit_label( 1281, compiled_block_1_1281 );
  twobit_load( 3, 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_const( 4 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /*  slib:error~1ay%kV~29338 */
  twobit_setrtn( 1282, compiled_block_1_1282 );
  twobit_invoke( 3 );
  twobit_label( 1282, compiled_block_1_1282 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_label( 1280, compiled_block_1_1280 );
  twobit_reg( 4 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /*  array:offset~1ay%kV~29345 */
  twobit_setrtn( 1283, compiled_block_1_1283 );
  twobit_invoke( 1 );
  twobit_label( 1283, compiled_block_1_1283 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_global( 7 ); /*  array:scales~1ay%kV~29343 */
  twobit_setrtn( 1284, compiled_block_1_1284 );
  twobit_invoke( 1 );
  twobit_label( 1284, compiled_block_1_1284 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 3, 2 );
  twobit_global( 8 ); /* * */
  twobit_setreg( 1 );
  twobit_global( 9 ); /*  map~1ay%kV~1381 */
  twobit_setrtn( 1285, compiled_block_1_1285 );
  twobit_invoke( 3 );
  twobit_label( 1285, compiled_block_1_1285 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 3 );
  twobit_global( 10 ); /* + */
  twobit_setreg( 1 );
  twobit_global( 11 ); /* apply */
  twobit_setrtn( 1286, compiled_block_1_1286 );
  twobit_invoke( 3 );
  twobit_label( 1286, compiled_block_1_1286 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 1288, compiled_block_1_1288 );
  twobit_global( 12 ); /* string-ref */
  twobit_skip( 1287, compiled_block_1_1287 );
  twobit_label( 1288, compiled_block_1_1288 );
  twobit_global( 13 ); /* vector-ref */
  twobit_label( 1287, compiled_block_1_1287 );
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 4 );
  twobit_reg( 3 );
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_23( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 5 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  array:store~1ay%kV~29344 */
  twobit_setrtn( 1290, compiled_block_1_1290 );
  twobit_invoke( 1 );
  twobit_label( 1290, compiled_block_1_1290 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 2, 1 );
  twobit_load( 1, 2 );
  twobit_global( 2 ); /*  array:in-bounds?~1ay%kV~29358 */
  twobit_setrtn( 1291, compiled_block_1_1291 );
  twobit_invoke( 2 );
  twobit_label( 1291, compiled_block_1_1291 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1293, compiled_block_1_1293 );
  twobit_skip( 1292, compiled_block_1_1292 );
  twobit_label( 1293, compiled_block_1_1293 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_const( 4 );
  twobit_setreg( 2 );
  twobit_load( 3, 1 );
  twobit_global( 5 ); /*  slib:error~1ay%kV~29338 */
  twobit_setrtn( 1294, compiled_block_1_1294 );
  twobit_invoke( 3 );
  twobit_label( 1294, compiled_block_1_1294 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_label( 1292, compiled_block_1_1292 );
  twobit_reg( 4 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /*  array:offset~1ay%kV~29345 */
  twobit_setrtn( 1295, compiled_block_1_1295 );
  twobit_invoke( 1 );
  twobit_label( 1295, compiled_block_1_1295 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 2 );
  twobit_global( 7 ); /*  array:scales~1ay%kV~29343 */
  twobit_setrtn( 1296, compiled_block_1_1296 );
  twobit_invoke( 1 );
  twobit_label( 1296, compiled_block_1_1296 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 8 ); /* * */
  twobit_setreg( 1 );
  twobit_load( 3, 1 );
  twobit_global( 9 ); /*  map~1ay%kV~1381 */
  twobit_setrtn( 1297, compiled_block_1_1297 );
  twobit_invoke( 3 );
  twobit_label( 1297, compiled_block_1_1297 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 3 );
  twobit_global( 10 ); /* + */
  twobit_setreg( 1 );
  twobit_global( 11 ); /* apply */
  twobit_setrtn( 1298, compiled_block_1_1298 );
  twobit_invoke( 3 );
  twobit_label( 1298, compiled_block_1_1298 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 1300, compiled_block_1_1300 );
  twobit_global( 12 ); /* string-set! */
  twobit_skip( 1299, compiled_block_1_1299 );
  twobit_label( 1300, compiled_block_1_1300 );
  twobit_global( 13 ); /* vector-set! */
  twobit_label( 1299, compiled_block_1_1299 );
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_load( 3, 5 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 4 );
  twobit_stack( 3 );
  twobit_pop( 5 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_24( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_lambda( compiled_start_1_36, 2, 3 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_36( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* length */
  twobit_setrtn( 1302, compiled_block_1_1302 );
  twobit_invoke( 1 );
  twobit_label( 1302, compiled_block_1_1302 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(1), 1304, compiled_block_1_1304 ); /* internal:branchf-eq?/imm */
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1305, compiled_block_1_1305 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1306, compiled_block_1_1306 );
  twobit_invoke( 1 );
  twobit_label( 1306, compiled_block_1_1306 );
  twobit_load( 0, 0 );
  twobit_branchf( 1308, compiled_block_1_1308 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1308, compiled_block_1_1308 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_const( 2 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_global( 4 ); /*  slib:error~1ay%kV~29338 */
  twobit_pop( 1 );
  twobit_invoke( 4 );
  twobit_label( 1304, compiled_block_1_1304 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_640( fixnum(0), 1312, compiled_block_1_1312 ); /* internal:branchf-eq?/imm */
  twobit_lexical( 0, 3 );
  twobit_pop( 1 );
  twobit_invoke( 0 );
  twobit_label( 1312, compiled_block_1_1312 );
  twobit_stack( 1 );
  twobit_setreg( 4 );
  twobit_movereg( 4, 6 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_const( 5 );
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_const( 7 );
  twobit_setreg( 4 );
  twobit_const( 8 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /*  slib:error~1ay%kV~29338 */
  twobit_pop( 1 );
  twobit_invoke( 6 );
  twobit_label( 1305, compiled_block_1_1305 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_25( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_26, 2, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_26( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1316, compiled_block_1_1316 );
  twobit_reg( 1 );
  twobit_op1_25(); /* exact? */
  twobit_branchf( 1318, compiled_block_1_1318 );
  twobit_lexical( 0, 1 );
  twobit_op2imm_132( fixnum(0), 27, compiled_temp_1_27 ); /* < */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1320, compiled_block_1_1320 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1319, compiled_block_1_1319 );
  twobit_label( 1320, compiled_block_1_1320 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(0), 28, compiled_temp_1_28, 1322, compiled_block_1_1322 ); /* internal:branchf-</imm */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1319, compiled_block_1_1319 );
  twobit_label( 1322, compiled_block_1_1322 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_label( 1319, compiled_block_1_1319 );
  twobit_branchf( 1324, compiled_block_1_1324 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 4 );
  twobit_branchf( 1326, compiled_block_1_1326 );
  twobit_lexical( 0, 1 );
  twobit_op1_32( 29, compiled_temp_1_29 ); /* -- */
  twobit_skip( 1325, compiled_block_1_1325 );
  twobit_label( 1326, compiled_block_1_1326 );
  twobit_lexical( 0, 1 );
  twobit_label( 1325, compiled_block_1_1325 );
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 4, 30, compiled_temp_1_30 ); /* + */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_31, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1324, compiled_block_1_1324 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1318, compiled_block_1_1318 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1316, compiled_block_1_1316 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_31( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_31( 32, compiled_temp_1_32 ); /* zero? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1328, compiled_block_1_1328 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1327, compiled_block_1_1327 );
  twobit_label( 1328, compiled_block_1_1328 );
  twobit_reg( 2 );
  twobit_op2imm_132( fixnum(0), 33, compiled_temp_1_33 ); /* < */
  twobit_label( 1327, compiled_block_1_1327 );
  twobit_branchf( 1330, compiled_block_1_1330 );
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1330, compiled_block_1_1330 );
  twobit_imm_const( fixnum(256) ); /* 256 */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op2_65( 3, 34, compiled_temp_1_34 ); /* quotient */
  twobit_setreg( 1 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_61( 2, 35, compiled_temp_1_35 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


RTYPE twobit_thunk_7a052a2c5b425a612ccaf8fe96b7bb10_0(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_1_0(CONT_ACTUALS));
}
static RTYPE compiled_block_2_1004( CONT_PARAMS );
static RTYPE compiled_block_2_1003( CONT_PARAMS );
static RTYPE compiled_start_2_0( CONT_PARAMS );
static RTYPE compiled_start_2_3( CONT_PARAMS );
static RTYPE compiled_start_2_2( CONT_PARAMS );
static RTYPE compiled_start_2_1( CONT_PARAMS );

static RTYPE compiled_start_2_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_2_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_2_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1003, compiled_block_2_1003 );
  twobit_invoke( 8 );
  twobit_label( 1003, compiled_block_2_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1004, compiled_block_2_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_2_1004 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_7a052a2c5b425a612ccaf8fe96b7bb10_1(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_2_0(CONT_ACTUALS));
}
codeptr_t CDECL twobit_load_table[] = { 
  twobit_thunk_7a052a2c5b425a612ccaf8fe96b7bb10_0,
  twobit_thunk_7a052a2c5b425a612ccaf8fe96b7bb10_1,
  0  /* The table may be empty; some compilers complain */
};

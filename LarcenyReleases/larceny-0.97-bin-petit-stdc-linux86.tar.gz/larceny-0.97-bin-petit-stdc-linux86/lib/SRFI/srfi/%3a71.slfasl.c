/* Generated from /home/henchman/larcenytest/larceny-petit-Nightly-2009-08-19/larceny_src/lib/SRFI/srfi/%3a71.slfasl */
#include "petit-instr.h"

static RTYPE compiled_block_1_3007( CONT_PARAMS );
static RTYPE compiled_block_1_3006( CONT_PARAMS );
static RTYPE compiled_start_1_0( CONT_PARAMS );
static RTYPE compiled_start_1_3( CONT_PARAMS );
static RTYPE compiled_block_1_3003( CONT_PARAMS );
static RTYPE compiled_start_1_10( CONT_PARAMS );
static RTYPE compiled_start_1_9( CONT_PARAMS );
static RTYPE compiled_block_1_3000( CONT_PARAMS );
static RTYPE compiled_block_1_2999( CONT_PARAMS );
static RTYPE compiled_start_1_8( CONT_PARAMS );
static RTYPE compiled_block_1_2997( CONT_PARAMS );
static RTYPE compiled_block_1_2995( CONT_PARAMS );
static RTYPE compiled_block_1_2994( CONT_PARAMS );
static RTYPE compiled_block_1_2996( CONT_PARAMS );
static RTYPE compiled_start_1_7( CONT_PARAMS );
static RTYPE compiled_block_1_2991( CONT_PARAMS );
static RTYPE compiled_block_1_2990( CONT_PARAMS );
static RTYPE compiled_block_1_2992( CONT_PARAMS );
static RTYPE compiled_start_1_6( CONT_PARAMS );
static RTYPE compiled_block_1_2988( CONT_PARAMS );
static RTYPE compiled_block_1_2987( CONT_PARAMS );
static RTYPE compiled_start_1_5( CONT_PARAMS );
static RTYPE compiled_block_1_2985( CONT_PARAMS );
static RTYPE compiled_start_1_4( CONT_PARAMS );
static RTYPE compiled_block_1_2983( CONT_PARAMS );
static RTYPE compiled_block_1_2964( CONT_PARAMS );
static RTYPE compiled_block_1_2945( CONT_PARAMS );
static RTYPE compiled_block_1_2903( CONT_PARAMS );
static RTYPE compiled_block_1_2890( CONT_PARAMS );
static RTYPE compiled_block_1_2877( CONT_PARAMS );
static RTYPE compiled_block_1_2754( CONT_PARAMS );
static RTYPE compiled_block_1_1631( CONT_PARAMS );
static RTYPE compiled_block_1_1523( CONT_PARAMS );
static RTYPE compiled_block_1_1457( CONT_PARAMS );
static RTYPE compiled_block_1_1405( CONT_PARAMS );
static RTYPE compiled_block_1_1339( CONT_PARAMS );
static RTYPE compiled_block_1_1141( CONT_PARAMS );
static RTYPE compiled_block_1_1064( CONT_PARAMS );
static RTYPE compiled_start_1_2( CONT_PARAMS );
static RTYPE compiled_block_1_2966( CONT_PARAMS );
static RTYPE compiled_block_1_2968( CONT_PARAMS );
static RTYPE compiled_block_1_2971( CONT_PARAMS );
static RTYPE compiled_block_1_2973( CONT_PARAMS );
static RTYPE compiled_block_1_2976( CONT_PARAMS );
static RTYPE compiled_block_1_2977( CONT_PARAMS );
static RTYPE compiled_block_1_2974( CONT_PARAMS );
static RTYPE compiled_block_1_2969( CONT_PARAMS );
static RTYPE compiled_start_1_24( CONT_PARAMS );
static RTYPE compiled_block_1_2947( CONT_PARAMS );
static RTYPE compiled_block_1_2949( CONT_PARAMS );
static RTYPE compiled_block_1_2952( CONT_PARAMS );
static RTYPE compiled_block_1_2954( CONT_PARAMS );
static RTYPE compiled_block_1_2957( CONT_PARAMS );
static RTYPE compiled_block_1_2958( CONT_PARAMS );
static RTYPE compiled_block_1_2955( CONT_PARAMS );
static RTYPE compiled_block_1_2950( CONT_PARAMS );
static RTYPE compiled_start_1_23( CONT_PARAMS );
static RTYPE compiled_block_1_2925( CONT_PARAMS );
static RTYPE compiled_block_1_2927( CONT_PARAMS );
static RTYPE compiled_block_1_2929( CONT_PARAMS );
static RTYPE compiled_block_1_2932( CONT_PARAMS );
static RTYPE compiled_block_1_2934( CONT_PARAMS );
static RTYPE compiled_block_1_2937( CONT_PARAMS );
static RTYPE compiled_block_1_2938( CONT_PARAMS );
static RTYPE compiled_block_1_2935( CONT_PARAMS );
static RTYPE compiled_block_1_2930( CONT_PARAMS );
static RTYPE compiled_block_1_2904( CONT_PARAMS );
static RTYPE compiled_block_1_2907( CONT_PARAMS );
static RTYPE compiled_block_1_2909( CONT_PARAMS );
static RTYPE compiled_block_1_2912( CONT_PARAMS );
static RTYPE compiled_block_1_2914( CONT_PARAMS );
static RTYPE compiled_block_1_2917( CONT_PARAMS );
static RTYPE compiled_block_1_2918( CONT_PARAMS );
static RTYPE compiled_block_1_2915( CONT_PARAMS );
static RTYPE compiled_block_1_2910( CONT_PARAMS );
static RTYPE compiled_start_1_22( CONT_PARAMS );
static RTYPE compiled_block_1_2892( CONT_PARAMS );
static RTYPE compiled_block_1_2894( CONT_PARAMS );
static RTYPE compiled_block_1_2896( CONT_PARAMS );
static RTYPE compiled_block_1_2899( CONT_PARAMS );
static RTYPE compiled_block_1_2898( CONT_PARAMS );
static RTYPE compiled_block_1_2897( CONT_PARAMS );
static RTYPE compiled_start_1_21( CONT_PARAMS );
static RTYPE compiled_block_1_2879( CONT_PARAMS );
static RTYPE compiled_block_1_2881( CONT_PARAMS );
static RTYPE compiled_block_1_2883( CONT_PARAMS );
static RTYPE compiled_block_1_2886( CONT_PARAMS );
static RTYPE compiled_block_1_2885( CONT_PARAMS );
static RTYPE compiled_block_1_2884( CONT_PARAMS );
static RTYPE compiled_start_1_20( CONT_PARAMS );
static RTYPE compiled_block_1_2821( CONT_PARAMS );
static RTYPE compiled_block_1_2823( CONT_PARAMS );
static RTYPE compiled_block_1_2825( CONT_PARAMS );
static RTYPE compiled_block_1_2828( CONT_PARAMS );
static RTYPE compiled_block_1_2830( CONT_PARAMS );
static RTYPE compiled_block_1_2832( CONT_PARAMS );
static RTYPE compiled_block_1_2834( CONT_PARAMS );
static RTYPE compiled_block_1_2836( CONT_PARAMS );
static RTYPE compiled_block_1_2838( CONT_PARAMS );
static RTYPE compiled_block_1_2845( CONT_PARAMS );
static RTYPE compiled_block_1_2847( CONT_PARAMS );
static RTYPE compiled_block_1_2849( CONT_PARAMS );
static RTYPE compiled_block_1_2851( CONT_PARAMS );
static RTYPE compiled_block_1_2853( CONT_PARAMS );
static RTYPE compiled_block_1_2856( CONT_PARAMS );
static RTYPE compiled_block_1_2858( CONT_PARAMS );
static RTYPE compiled_block_1_2860( CONT_PARAMS );
static RTYPE compiled_block_1_2859( CONT_PARAMS );
static RTYPE compiled_block_1_2854( CONT_PARAMS );
static RTYPE compiled_block_1_2840( CONT_PARAMS );
static RTYPE compiled_block_1_2841( CONT_PARAMS );
static RTYPE compiled_block_1_2843( CONT_PARAMS );
static RTYPE compiled_block_1_2842( CONT_PARAMS );
static RTYPE compiled_block_1_2839( CONT_PARAMS );
static RTYPE compiled_block_1_2826( CONT_PARAMS );
static RTYPE compiled_block_1_2756( CONT_PARAMS );
static RTYPE compiled_block_1_2781( CONT_PARAMS );
static RTYPE compiled_block_1_2783( CONT_PARAMS );
static RTYPE compiled_block_1_2785( CONT_PARAMS );
static RTYPE compiled_block_1_2788( CONT_PARAMS );
static RTYPE compiled_block_1_2790( CONT_PARAMS );
static RTYPE compiled_block_1_2792( CONT_PARAMS );
static RTYPE compiled_block_1_2794( CONT_PARAMS );
static RTYPE compiled_block_1_2796( CONT_PARAMS );
static RTYPE compiled_block_1_2798( CONT_PARAMS );
static RTYPE compiled_block_1_2800( CONT_PARAMS );
static RTYPE compiled_block_1_2803( CONT_PARAMS );
static RTYPE compiled_block_1_2805( CONT_PARAMS );
static RTYPE compiled_block_1_2807( CONT_PARAMS );
static RTYPE compiled_block_1_2806( CONT_PARAMS );
static RTYPE compiled_block_1_2801( CONT_PARAMS );
static RTYPE compiled_block_1_2786( CONT_PARAMS );
static RTYPE compiled_block_1_2755( CONT_PARAMS );
static RTYPE compiled_block_1_2759( CONT_PARAMS );
static RTYPE compiled_block_1_2761( CONT_PARAMS );
static RTYPE compiled_block_1_2763( CONT_PARAMS );
static RTYPE compiled_block_1_2765( CONT_PARAMS );
static RTYPE compiled_block_1_2767( CONT_PARAMS );
static RTYPE compiled_block_1_2769( CONT_PARAMS );
static RTYPE compiled_block_1_2771( CONT_PARAMS );
static RTYPE compiled_block_1_2772( CONT_PARAMS );
static RTYPE compiled_start_1_19( CONT_PARAMS );
static RTYPE compiled_block_1_2689( CONT_PARAMS );
static RTYPE compiled_block_1_2691( CONT_PARAMS );
static RTYPE compiled_block_1_2694( CONT_PARAMS );
static RTYPE compiled_block_1_2696( CONT_PARAMS );
static RTYPE compiled_block_1_2698( CONT_PARAMS );
static RTYPE compiled_block_1_2700( CONT_PARAMS );
static RTYPE compiled_block_1_2703( CONT_PARAMS );
static RTYPE compiled_block_1_2705( CONT_PARAMS );
static RTYPE compiled_block_1_2707( CONT_PARAMS );
static RTYPE compiled_block_1_2709( CONT_PARAMS );
static RTYPE compiled_block_1_2711( CONT_PARAMS );
static RTYPE compiled_block_1_2713( CONT_PARAMS );
static RTYPE compiled_block_1_2720( CONT_PARAMS );
static RTYPE compiled_block_1_2722( CONT_PARAMS );
static RTYPE compiled_block_1_2724( CONT_PARAMS );
static RTYPE compiled_block_1_2726( CONT_PARAMS );
static RTYPE compiled_block_1_2729( CONT_PARAMS );
static RTYPE compiled_block_1_2731( CONT_PARAMS );
static RTYPE compiled_block_1_2735( CONT_PARAMS );
static RTYPE compiled_block_1_2734( CONT_PARAMS );
static RTYPE compiled_block_1_2733( CONT_PARAMS );
static RTYPE compiled_block_1_2732( CONT_PARAMS );
static RTYPE compiled_block_1_2727( CONT_PARAMS );
static RTYPE compiled_block_1_2715( CONT_PARAMS );
static RTYPE compiled_block_1_2716( CONT_PARAMS );
static RTYPE compiled_block_1_2718( CONT_PARAMS );
static RTYPE compiled_block_1_2717( CONT_PARAMS );
static RTYPE compiled_block_1_2714( CONT_PARAMS );
static RTYPE compiled_block_1_2701( CONT_PARAMS );
static RTYPE compiled_block_1_2692( CONT_PARAMS );
static RTYPE compiled_block_1_1650( CONT_PARAMS );
static RTYPE compiled_block_1_2622( CONT_PARAMS );
static RTYPE compiled_block_1_2624( CONT_PARAMS );
static RTYPE compiled_block_1_2627( CONT_PARAMS );
static RTYPE compiled_block_1_2629( CONT_PARAMS );
static RTYPE compiled_block_1_2631( CONT_PARAMS );
static RTYPE compiled_block_1_2633( CONT_PARAMS );
static RTYPE compiled_block_1_2636( CONT_PARAMS );
static RTYPE compiled_block_1_2638( CONT_PARAMS );
static RTYPE compiled_block_1_2640( CONT_PARAMS );
static RTYPE compiled_block_1_2642( CONT_PARAMS );
static RTYPE compiled_block_1_2644( CONT_PARAMS );
static RTYPE compiled_block_1_2646( CONT_PARAMS );
static RTYPE compiled_block_1_2653( CONT_PARAMS );
static RTYPE compiled_block_1_2655( CONT_PARAMS );
static RTYPE compiled_block_1_2657( CONT_PARAMS );
static RTYPE compiled_block_1_2659( CONT_PARAMS );
static RTYPE compiled_block_1_2661( CONT_PARAMS );
static RTYPE compiled_block_1_2664( CONT_PARAMS );
static RTYPE compiled_block_1_2666( CONT_PARAMS );
static RTYPE compiled_block_1_2668( CONT_PARAMS );
static RTYPE compiled_block_1_2667( CONT_PARAMS );
static RTYPE compiled_block_1_2662( CONT_PARAMS );
static RTYPE compiled_block_1_2648( CONT_PARAMS );
static RTYPE compiled_block_1_2649( CONT_PARAMS );
static RTYPE compiled_block_1_2651( CONT_PARAMS );
static RTYPE compiled_block_1_2650( CONT_PARAMS );
static RTYPE compiled_block_1_2647( CONT_PARAMS );
static RTYPE compiled_block_1_2634( CONT_PARAMS );
static RTYPE compiled_block_1_2625( CONT_PARAMS );
static RTYPE compiled_block_1_1649( CONT_PARAMS );
static RTYPE compiled_block_1_2561( CONT_PARAMS );
static RTYPE compiled_block_1_2563( CONT_PARAMS );
static RTYPE compiled_block_1_2566( CONT_PARAMS );
static RTYPE compiled_block_1_2568( CONT_PARAMS );
static RTYPE compiled_block_1_2570( CONT_PARAMS );
static RTYPE compiled_block_1_2572( CONT_PARAMS );
static RTYPE compiled_block_1_2574( CONT_PARAMS );
static RTYPE compiled_block_1_2576( CONT_PARAMS );
static RTYPE compiled_block_1_2578( CONT_PARAMS );
static RTYPE compiled_block_1_2580( CONT_PARAMS );
static RTYPE compiled_block_1_2582( CONT_PARAMS );
static RTYPE compiled_block_1_2589( CONT_PARAMS );
static RTYPE compiled_block_1_2592( CONT_PARAMS );
static RTYPE compiled_block_1_2594( CONT_PARAMS );
static RTYPE compiled_block_1_2596( CONT_PARAMS );
static RTYPE compiled_block_1_2599( CONT_PARAMS );
static RTYPE compiled_block_1_2601( CONT_PARAMS );
static RTYPE compiled_block_1_2603( CONT_PARAMS );
static RTYPE compiled_block_1_2602( CONT_PARAMS );
static RTYPE compiled_block_1_2597( CONT_PARAMS );
static RTYPE compiled_block_1_2590( CONT_PARAMS );
static RTYPE compiled_block_1_2584( CONT_PARAMS );
static RTYPE compiled_block_1_2585( CONT_PARAMS );
static RTYPE compiled_block_1_2587( CONT_PARAMS );
static RTYPE compiled_block_1_2586( CONT_PARAMS );
static RTYPE compiled_block_1_2583( CONT_PARAMS );
static RTYPE compiled_block_1_2564( CONT_PARAMS );
static RTYPE compiled_block_1_1648( CONT_PARAMS );
static RTYPE compiled_block_1_2504( CONT_PARAMS );
static RTYPE compiled_block_1_2506( CONT_PARAMS );
static RTYPE compiled_block_1_2509( CONT_PARAMS );
static RTYPE compiled_block_1_2511( CONT_PARAMS );
static RTYPE compiled_block_1_2513( CONT_PARAMS );
static RTYPE compiled_block_1_2515( CONT_PARAMS );
static RTYPE compiled_block_1_2517( CONT_PARAMS );
static RTYPE compiled_block_1_2519( CONT_PARAMS );
static RTYPE compiled_block_1_2521( CONT_PARAMS );
static RTYPE compiled_block_1_2523( CONT_PARAMS );
static RTYPE compiled_block_1_2525( CONT_PARAMS );
static RTYPE compiled_block_1_2532( CONT_PARAMS );
static RTYPE compiled_block_1_2534( CONT_PARAMS );
static RTYPE compiled_block_1_2536( CONT_PARAMS );
static RTYPE compiled_block_1_2539( CONT_PARAMS );
static RTYPE compiled_block_1_2541( CONT_PARAMS );
static RTYPE compiled_block_1_2543( CONT_PARAMS );
static RTYPE compiled_block_1_2542( CONT_PARAMS );
static RTYPE compiled_block_1_2537( CONT_PARAMS );
static RTYPE compiled_block_1_2527( CONT_PARAMS );
static RTYPE compiled_block_1_2528( CONT_PARAMS );
static RTYPE compiled_block_1_2530( CONT_PARAMS );
static RTYPE compiled_block_1_2529( CONT_PARAMS );
static RTYPE compiled_block_1_2526( CONT_PARAMS );
static RTYPE compiled_block_1_2507( CONT_PARAMS );
static RTYPE compiled_block_1_1647( CONT_PARAMS );
static RTYPE compiled_block_1_2454( CONT_PARAMS );
static RTYPE compiled_block_1_2456( CONT_PARAMS );
static RTYPE compiled_block_1_2459( CONT_PARAMS );
static RTYPE compiled_block_1_2461( CONT_PARAMS );
static RTYPE compiled_block_1_2463( CONT_PARAMS );
static RTYPE compiled_block_1_2465( CONT_PARAMS );
static RTYPE compiled_block_1_2468( CONT_PARAMS );
static RTYPE compiled_block_1_2470( CONT_PARAMS );
static RTYPE compiled_block_1_2472( CONT_PARAMS );
static RTYPE compiled_block_1_2474( CONT_PARAMS );
static RTYPE compiled_block_1_2476( CONT_PARAMS );
static RTYPE compiled_block_1_2478( CONT_PARAMS );
static RTYPE compiled_block_1_2480( CONT_PARAMS );
static RTYPE compiled_block_1_2483( CONT_PARAMS );
static RTYPE compiled_block_1_2485( CONT_PARAMS );
static RTYPE compiled_block_1_2487( CONT_PARAMS );
static RTYPE compiled_block_1_2486( CONT_PARAMS );
static RTYPE compiled_block_1_2481( CONT_PARAMS );
static RTYPE compiled_block_1_2466( CONT_PARAMS );
static RTYPE compiled_block_1_2457( CONT_PARAMS );
static RTYPE compiled_block_1_1646( CONT_PARAMS );
static RTYPE compiled_block_1_2405( CONT_PARAMS );
static RTYPE compiled_block_1_2407( CONT_PARAMS );
static RTYPE compiled_block_1_2410( CONT_PARAMS );
static RTYPE compiled_block_1_2412( CONT_PARAMS );
static RTYPE compiled_block_1_2414( CONT_PARAMS );
static RTYPE compiled_block_1_2416( CONT_PARAMS );
static RTYPE compiled_block_1_2418( CONT_PARAMS );
static RTYPE compiled_block_1_2420( CONT_PARAMS );
static RTYPE compiled_block_1_2422( CONT_PARAMS );
static RTYPE compiled_block_1_2424( CONT_PARAMS );
static RTYPE compiled_block_1_2426( CONT_PARAMS );
static RTYPE compiled_block_1_2428( CONT_PARAMS );
static RTYPE compiled_block_1_2431( CONT_PARAMS );
static RTYPE compiled_block_1_2434( CONT_PARAMS );
static RTYPE compiled_block_1_2436( CONT_PARAMS );
static RTYPE compiled_block_1_2437( CONT_PARAMS );
static RTYPE compiled_block_1_2432( CONT_PARAMS );
static RTYPE compiled_block_1_2429( CONT_PARAMS );
static RTYPE compiled_block_1_2408( CONT_PARAMS );
static RTYPE compiled_block_1_1645( CONT_PARAMS );
static RTYPE compiled_block_1_2342( CONT_PARAMS );
static RTYPE compiled_block_1_2344( CONT_PARAMS );
static RTYPE compiled_block_1_2347( CONT_PARAMS );
static RTYPE compiled_block_1_2349( CONT_PARAMS );
static RTYPE compiled_block_1_2351( CONT_PARAMS );
static RTYPE compiled_block_1_2354( CONT_PARAMS );
static RTYPE compiled_block_1_2356( CONT_PARAMS );
static RTYPE compiled_block_1_2358( CONT_PARAMS );
static RTYPE compiled_block_1_2360( CONT_PARAMS );
static RTYPE compiled_block_1_2362( CONT_PARAMS );
static RTYPE compiled_block_1_2364( CONT_PARAMS );
static RTYPE compiled_block_1_2366( CONT_PARAMS );
static RTYPE compiled_block_1_2368( CONT_PARAMS );
static RTYPE compiled_block_1_2370( CONT_PARAMS );
static RTYPE compiled_block_1_2372( CONT_PARAMS );
static RTYPE compiled_block_1_2379( CONT_PARAMS );
static RTYPE compiled_block_1_2381( CONT_PARAMS );
static RTYPE compiled_block_1_2383( CONT_PARAMS );
static RTYPE compiled_block_1_2385( CONT_PARAMS );
static RTYPE compiled_block_1_2384( CONT_PARAMS );
static RTYPE compiled_block_1_2374( CONT_PARAMS );
static RTYPE compiled_block_1_2375( CONT_PARAMS );
static RTYPE compiled_block_1_2377( CONT_PARAMS );
static RTYPE compiled_block_1_2376( CONT_PARAMS );
static RTYPE compiled_block_1_2373( CONT_PARAMS );
static RTYPE compiled_block_1_2352( CONT_PARAMS );
static RTYPE compiled_block_1_2345( CONT_PARAMS );
static RTYPE compiled_block_1_1644( CONT_PARAMS );
static RTYPE compiled_block_1_2267( CONT_PARAMS );
static RTYPE compiled_block_1_2269( CONT_PARAMS );
static RTYPE compiled_block_1_2272( CONT_PARAMS );
static RTYPE compiled_block_1_2274( CONT_PARAMS );
static RTYPE compiled_block_1_2276( CONT_PARAMS );
static RTYPE compiled_block_1_2278( CONT_PARAMS );
static RTYPE compiled_block_1_2281( CONT_PARAMS );
static RTYPE compiled_block_1_2283( CONT_PARAMS );
static RTYPE compiled_block_1_2285( CONT_PARAMS );
static RTYPE compiled_block_1_2287( CONT_PARAMS );
static RTYPE compiled_block_1_2289( CONT_PARAMS );
static RTYPE compiled_block_1_2291( CONT_PARAMS );
static RTYPE compiled_block_1_2294( CONT_PARAMS );
static RTYPE compiled_block_1_2296( CONT_PARAMS );
static RTYPE compiled_block_1_2298( CONT_PARAMS );
static RTYPE compiled_block_1_2300( CONT_PARAMS );
static RTYPE compiled_block_1_2307( CONT_PARAMS );
static RTYPE compiled_block_1_2309( CONT_PARAMS );
static RTYPE compiled_block_1_2312( CONT_PARAMS );
static RTYPE compiled_block_1_2314( CONT_PARAMS );
static RTYPE compiled_block_1_2320( CONT_PARAMS );
static RTYPE compiled_block_1_2319( CONT_PARAMS );
static RTYPE compiled_block_1_2318( CONT_PARAMS );
static RTYPE compiled_block_1_2317( CONT_PARAMS );
static RTYPE compiled_block_1_2316( CONT_PARAMS );
static RTYPE compiled_block_1_2315( CONT_PARAMS );
static RTYPE compiled_block_1_2310( CONT_PARAMS );
static RTYPE compiled_block_1_2302( CONT_PARAMS );
static RTYPE compiled_block_1_2303( CONT_PARAMS );
static RTYPE compiled_block_1_2305( CONT_PARAMS );
static RTYPE compiled_block_1_2304( CONT_PARAMS );
static RTYPE compiled_block_1_2301( CONT_PARAMS );
static RTYPE compiled_block_1_2292( CONT_PARAMS );
static RTYPE compiled_block_1_2279( CONT_PARAMS );
static RTYPE compiled_block_1_2270( CONT_PARAMS );
static RTYPE compiled_block_1_1643( CONT_PARAMS );
static RTYPE compiled_block_1_2193( CONT_PARAMS );
static RTYPE compiled_block_1_2195( CONT_PARAMS );
static RTYPE compiled_block_1_2198( CONT_PARAMS );
static RTYPE compiled_block_1_2200( CONT_PARAMS );
static RTYPE compiled_block_1_2202( CONT_PARAMS );
static RTYPE compiled_block_1_2204( CONT_PARAMS );
static RTYPE compiled_block_1_2207( CONT_PARAMS );
static RTYPE compiled_block_1_2209( CONT_PARAMS );
static RTYPE compiled_block_1_2211( CONT_PARAMS );
static RTYPE compiled_block_1_2213( CONT_PARAMS );
static RTYPE compiled_block_1_2215( CONT_PARAMS );
static RTYPE compiled_block_1_2217( CONT_PARAMS );
static RTYPE compiled_block_1_2220( CONT_PARAMS );
static RTYPE compiled_block_1_2222( CONT_PARAMS );
static RTYPE compiled_block_1_2224( CONT_PARAMS );
static RTYPE compiled_block_1_2226( CONT_PARAMS );
static RTYPE compiled_block_1_2233( CONT_PARAMS );
static RTYPE compiled_block_1_2235( CONT_PARAMS );
static RTYPE compiled_block_1_2237( CONT_PARAMS );
static RTYPE compiled_block_1_2239( CONT_PARAMS );
static RTYPE compiled_block_1_2245( CONT_PARAMS );
static RTYPE compiled_block_1_2244( CONT_PARAMS );
static RTYPE compiled_block_1_2243( CONT_PARAMS );
static RTYPE compiled_block_1_2242( CONT_PARAMS );
static RTYPE compiled_block_1_2241( CONT_PARAMS );
static RTYPE compiled_block_1_2240( CONT_PARAMS );
static RTYPE compiled_block_1_2228( CONT_PARAMS );
static RTYPE compiled_block_1_2229( CONT_PARAMS );
static RTYPE compiled_block_1_2231( CONT_PARAMS );
static RTYPE compiled_block_1_2230( CONT_PARAMS );
static RTYPE compiled_block_1_2227( CONT_PARAMS );
static RTYPE compiled_block_1_2218( CONT_PARAMS );
static RTYPE compiled_block_1_2205( CONT_PARAMS );
static RTYPE compiled_block_1_2196( CONT_PARAMS );
static RTYPE compiled_block_1_1642( CONT_PARAMS );
static RTYPE compiled_block_1_2116( CONT_PARAMS );
static RTYPE compiled_block_1_2118( CONT_PARAMS );
static RTYPE compiled_block_1_2121( CONT_PARAMS );
static RTYPE compiled_block_1_2123( CONT_PARAMS );
static RTYPE compiled_block_1_2125( CONT_PARAMS );
static RTYPE compiled_block_1_2128( CONT_PARAMS );
static RTYPE compiled_block_1_2130( CONT_PARAMS );
static RTYPE compiled_block_1_2133( CONT_PARAMS );
static RTYPE compiled_block_1_2135( CONT_PARAMS );
static RTYPE compiled_block_1_2137( CONT_PARAMS );
static RTYPE compiled_block_1_2139( CONT_PARAMS );
static RTYPE compiled_block_1_2141( CONT_PARAMS );
static RTYPE compiled_block_1_2143( CONT_PARAMS );
static RTYPE compiled_block_1_2146( CONT_PARAMS );
static RTYPE compiled_block_1_2148( CONT_PARAMS );
static RTYPE compiled_block_1_2150( CONT_PARAMS );
static RTYPE compiled_block_1_2152( CONT_PARAMS );
static RTYPE compiled_block_1_2159( CONT_PARAMS );
static RTYPE compiled_block_1_2161( CONT_PARAMS );
static RTYPE compiled_block_1_2163( CONT_PARAMS );
static RTYPE compiled_block_1_2171( CONT_PARAMS );
static RTYPE compiled_block_1_2170( CONT_PARAMS );
static RTYPE compiled_block_1_2169( CONT_PARAMS );
static RTYPE compiled_block_1_2168( CONT_PARAMS );
static RTYPE compiled_block_1_2167( CONT_PARAMS );
static RTYPE compiled_block_1_2166( CONT_PARAMS );
static RTYPE compiled_block_1_2165( CONT_PARAMS );
static RTYPE compiled_block_1_2164( CONT_PARAMS );
static RTYPE compiled_block_1_2154( CONT_PARAMS );
static RTYPE compiled_block_1_2155( CONT_PARAMS );
static RTYPE compiled_block_1_2157( CONT_PARAMS );
static RTYPE compiled_block_1_2156( CONT_PARAMS );
static RTYPE compiled_block_1_2153( CONT_PARAMS );
static RTYPE compiled_block_1_2144( CONT_PARAMS );
static RTYPE compiled_block_1_2131( CONT_PARAMS );
static RTYPE compiled_block_1_2126( CONT_PARAMS );
static RTYPE compiled_block_1_2119( CONT_PARAMS );
static RTYPE compiled_block_1_1641( CONT_PARAMS );
static RTYPE compiled_block_1_2046( CONT_PARAMS );
static RTYPE compiled_block_1_2048( CONT_PARAMS );
static RTYPE compiled_block_1_2051( CONT_PARAMS );
static RTYPE compiled_block_1_2053( CONT_PARAMS );
static RTYPE compiled_block_1_2055( CONT_PARAMS );
static RTYPE compiled_block_1_2058( CONT_PARAMS );
static RTYPE compiled_block_1_2060( CONT_PARAMS );
static RTYPE compiled_block_1_2063( CONT_PARAMS );
static RTYPE compiled_block_1_2065( CONT_PARAMS );
static RTYPE compiled_block_1_2067( CONT_PARAMS );
static RTYPE compiled_block_1_2069( CONT_PARAMS );
static RTYPE compiled_block_1_2071( CONT_PARAMS );
static RTYPE compiled_block_1_2073( CONT_PARAMS );
static RTYPE compiled_block_1_2075( CONT_PARAMS );
static RTYPE compiled_block_1_2077( CONT_PARAMS );
static RTYPE compiled_block_1_2079( CONT_PARAMS );
static RTYPE compiled_block_1_2081( CONT_PARAMS );
static RTYPE compiled_block_1_2088( CONT_PARAMS );
static RTYPE compiled_block_1_2090( CONT_PARAMS );
static RTYPE compiled_block_1_2095( CONT_PARAMS );
static RTYPE compiled_block_1_2094( CONT_PARAMS );
static RTYPE compiled_block_1_2093( CONT_PARAMS );
static RTYPE compiled_block_1_2092( CONT_PARAMS );
static RTYPE compiled_block_1_2091( CONT_PARAMS );
static RTYPE compiled_block_1_2083( CONT_PARAMS );
static RTYPE compiled_block_1_2084( CONT_PARAMS );
static RTYPE compiled_block_1_2086( CONT_PARAMS );
static RTYPE compiled_block_1_2085( CONT_PARAMS );
static RTYPE compiled_block_1_2082( CONT_PARAMS );
static RTYPE compiled_block_1_2061( CONT_PARAMS );
static RTYPE compiled_block_1_2056( CONT_PARAMS );
static RTYPE compiled_block_1_2049( CONT_PARAMS );
static RTYPE compiled_block_1_1640( CONT_PARAMS );
static RTYPE compiled_block_1_1996( CONT_PARAMS );
static RTYPE compiled_block_1_1998( CONT_PARAMS );
static RTYPE compiled_block_1_2001( CONT_PARAMS );
static RTYPE compiled_block_1_2003( CONT_PARAMS );
static RTYPE compiled_block_1_2005( CONT_PARAMS );
static RTYPE compiled_block_1_2007( CONT_PARAMS );
static RTYPE compiled_block_1_2009( CONT_PARAMS );
static RTYPE compiled_block_1_2011( CONT_PARAMS );
static RTYPE compiled_block_1_2014( CONT_PARAMS );
static RTYPE compiled_block_1_2016( CONT_PARAMS );
static RTYPE compiled_block_1_2019( CONT_PARAMS );
static RTYPE compiled_block_1_2021( CONT_PARAMS );
static RTYPE compiled_block_1_2023( CONT_PARAMS );
static RTYPE compiled_block_1_2025( CONT_PARAMS );
static RTYPE compiled_block_1_2027( CONT_PARAMS );
static RTYPE compiled_block_1_2029( CONT_PARAMS );
static RTYPE compiled_block_1_2028( CONT_PARAMS );
static RTYPE compiled_block_1_2017( CONT_PARAMS );
static RTYPE compiled_block_1_2012( CONT_PARAMS );
static RTYPE compiled_block_1_1999( CONT_PARAMS );
static RTYPE compiled_block_1_1639( CONT_PARAMS );
static RTYPE compiled_block_1_1946( CONT_PARAMS );
static RTYPE compiled_block_1_1948( CONT_PARAMS );
static RTYPE compiled_block_1_1951( CONT_PARAMS );
static RTYPE compiled_block_1_1953( CONT_PARAMS );
static RTYPE compiled_block_1_1955( CONT_PARAMS );
static RTYPE compiled_block_1_1957( CONT_PARAMS );
static RTYPE compiled_block_1_1959( CONT_PARAMS );
static RTYPE compiled_block_1_1961( CONT_PARAMS );
static RTYPE compiled_block_1_1963( CONT_PARAMS );
static RTYPE compiled_block_1_1966( CONT_PARAMS );
static RTYPE compiled_block_1_1968( CONT_PARAMS );
static RTYPE compiled_block_1_1970( CONT_PARAMS );
static RTYPE compiled_block_1_1972( CONT_PARAMS );
static RTYPE compiled_block_1_1975( CONT_PARAMS );
static RTYPE compiled_block_1_1977( CONT_PARAMS );
static RTYPE compiled_block_1_1979( CONT_PARAMS );
static RTYPE compiled_block_1_1978( CONT_PARAMS );
static RTYPE compiled_block_1_1973( CONT_PARAMS );
static RTYPE compiled_block_1_1964( CONT_PARAMS );
static RTYPE compiled_block_1_1949( CONT_PARAMS );
static RTYPE compiled_block_1_1638( CONT_PARAMS );
static RTYPE compiled_block_1_1919( CONT_PARAMS );
static RTYPE compiled_block_1_1921( CONT_PARAMS );
static RTYPE compiled_block_1_1924( CONT_PARAMS );
static RTYPE compiled_block_1_1926( CONT_PARAMS );
static RTYPE compiled_block_1_1929( CONT_PARAMS );
static RTYPE compiled_block_1_1931( CONT_PARAMS );
static RTYPE compiled_block_1_1933( CONT_PARAMS );
static RTYPE compiled_block_1_1935( CONT_PARAMS );
static RTYPE compiled_block_1_1936( CONT_PARAMS );
static RTYPE compiled_block_1_1927( CONT_PARAMS );
static RTYPE compiled_block_1_1922( CONT_PARAMS );
static RTYPE compiled_block_1_1637( CONT_PARAMS );
static RTYPE compiled_block_1_1876( CONT_PARAMS );
static RTYPE compiled_block_1_1878( CONT_PARAMS );
static RTYPE compiled_block_1_1881( CONT_PARAMS );
static RTYPE compiled_block_1_1883( CONT_PARAMS );
static RTYPE compiled_block_1_1886( CONT_PARAMS );
static RTYPE compiled_block_1_1888( CONT_PARAMS );
static RTYPE compiled_block_1_1890( CONT_PARAMS );
static RTYPE compiled_block_1_1892( CONT_PARAMS );
static RTYPE compiled_block_1_1894( CONT_PARAMS );
static RTYPE compiled_block_1_1896( CONT_PARAMS );
static RTYPE compiled_block_1_1898( CONT_PARAMS );
static RTYPE compiled_block_1_1901( CONT_PARAMS );
static RTYPE compiled_block_1_1905( CONT_PARAMS );
static RTYPE compiled_block_1_1904( CONT_PARAMS );
static RTYPE compiled_block_1_1903( CONT_PARAMS );
static RTYPE compiled_block_1_1902( CONT_PARAMS );
static RTYPE compiled_block_1_1899( CONT_PARAMS );
static RTYPE compiled_block_1_1884( CONT_PARAMS );
static RTYPE compiled_block_1_1879( CONT_PARAMS );
static RTYPE compiled_block_1_1636( CONT_PARAMS );
static RTYPE compiled_block_1_1849( CONT_PARAMS );
static RTYPE compiled_block_1_1851( CONT_PARAMS );
static RTYPE compiled_block_1_1854( CONT_PARAMS );
static RTYPE compiled_block_1_1856( CONT_PARAMS );
static RTYPE compiled_block_1_1859( CONT_PARAMS );
static RTYPE compiled_block_1_1861( CONT_PARAMS );
static RTYPE compiled_block_1_1863( CONT_PARAMS );
static RTYPE compiled_block_1_1865( CONT_PARAMS );
static RTYPE compiled_block_1_1866( CONT_PARAMS );
static RTYPE compiled_block_1_1857( CONT_PARAMS );
static RTYPE compiled_block_1_1852( CONT_PARAMS );
static RTYPE compiled_block_1_1635( CONT_PARAMS );
static RTYPE compiled_block_1_1782( CONT_PARAMS );
static RTYPE compiled_block_1_1784( CONT_PARAMS );
static RTYPE compiled_block_1_1787( CONT_PARAMS );
static RTYPE compiled_block_1_1789( CONT_PARAMS );
static RTYPE compiled_block_1_1792( CONT_PARAMS );
static RTYPE compiled_block_1_1794( CONT_PARAMS );
static RTYPE compiled_block_1_1790( CONT_PARAMS );
static RTYPE compiled_block_1_1785( CONT_PARAMS );
static RTYPE compiled_block_1_1634( CONT_PARAMS );
static RTYPE compiled_block_1_1725( CONT_PARAMS );
static RTYPE compiled_block_1_1727( CONT_PARAMS );
static RTYPE compiled_block_1_1730( CONT_PARAMS );
static RTYPE compiled_block_1_1732( CONT_PARAMS );
static RTYPE compiled_block_1_1728( CONT_PARAMS );
static RTYPE compiled_block_1_1633( CONT_PARAMS );
static RTYPE compiled_block_1_1689( CONT_PARAMS );
static RTYPE compiled_block_1_1691( CONT_PARAMS );
static RTYPE compiled_block_1_1694( CONT_PARAMS );
static RTYPE compiled_block_1_1696( CONT_PARAMS );
static RTYPE compiled_block_1_1698( CONT_PARAMS );
static RTYPE compiled_block_1_1700( CONT_PARAMS );
static RTYPE compiled_block_1_1702( CONT_PARAMS );
static RTYPE compiled_block_1_1704( CONT_PARAMS );
static RTYPE compiled_block_1_1706( CONT_PARAMS );
static RTYPE compiled_block_1_1709( CONT_PARAMS );
static RTYPE compiled_block_1_1713( CONT_PARAMS );
static RTYPE compiled_block_1_1712( CONT_PARAMS );
static RTYPE compiled_block_1_1711( CONT_PARAMS );
static RTYPE compiled_block_1_1710( CONT_PARAMS );
static RTYPE compiled_block_1_1707( CONT_PARAMS );
static RTYPE compiled_block_1_1692( CONT_PARAMS );
static RTYPE compiled_block_1_1632( CONT_PARAMS );
static RTYPE compiled_block_1_1653( CONT_PARAMS );
static RTYPE compiled_block_1_1655( CONT_PARAMS );
static RTYPE compiled_block_1_1658( CONT_PARAMS );
static RTYPE compiled_block_1_1660( CONT_PARAMS );
static RTYPE compiled_block_1_1662( CONT_PARAMS );
static RTYPE compiled_block_1_1665( CONT_PARAMS );
static RTYPE compiled_block_1_1667( CONT_PARAMS );
static RTYPE compiled_block_1_1669( CONT_PARAMS );
static RTYPE compiled_block_1_1671( CONT_PARAMS );
static RTYPE compiled_block_1_1673( CONT_PARAMS );
static RTYPE compiled_block_1_1675( CONT_PARAMS );
static RTYPE compiled_block_1_1676( CONT_PARAMS );
static RTYPE compiled_block_1_1663( CONT_PARAMS );
static RTYPE compiled_block_1_1656( CONT_PARAMS );
static RTYPE compiled_start_1_18( CONT_PARAMS );
static RTYPE compiled_block_1_1836( CONT_PARAMS );
static RTYPE compiled_block_1_1838( CONT_PARAMS );
static RTYPE compiled_block_1_1840( CONT_PARAMS );
static RTYPE compiled_start_1_28( CONT_PARAMS );
static RTYPE compiled_block_1_1796( CONT_PARAMS );
static RTYPE compiled_block_1_1830( CONT_PARAMS );
static RTYPE compiled_block_1_1832( CONT_PARAMS );
static RTYPE compiled_block_1_1831( CONT_PARAMS );
static RTYPE compiled_start_1_27( CONT_PARAMS );
static RTYPE compiled_block_1_1822( CONT_PARAMS );
static RTYPE compiled_block_1_1821( CONT_PARAMS );
static RTYPE compiled_block_1_1827( CONT_PARAMS );
static RTYPE compiled_block_1_1828( CONT_PARAMS );
static RTYPE compiled_block_1_1825( CONT_PARAMS );
static RTYPE compiled_block_1_1798( CONT_PARAMS );
static RTYPE compiled_block_1_1819( CONT_PARAMS );
static RTYPE compiled_block_1_1816( CONT_PARAMS );
static RTYPE compiled_block_1_1817( CONT_PARAMS );
static RTYPE compiled_block_1_1797( CONT_PARAMS );
static RTYPE compiled_block_1_1801( CONT_PARAMS );
static RTYPE compiled_block_1_1804( CONT_PARAMS );
static RTYPE compiled_block_1_1810( CONT_PARAMS );
static RTYPE compiled_block_1_1813( CONT_PARAMS );
static RTYPE compiled_block_1_1811( CONT_PARAMS );
static RTYPE compiled_block_1_1812( CONT_PARAMS );
static RTYPE compiled_temp_1_30( CONT_PARAMS );
static RTYPE compiled_block_1_1809( CONT_PARAMS );
static RTYPE compiled_block_1_1808( CONT_PARAMS );
static RTYPE compiled_block_1_1807( CONT_PARAMS );
static RTYPE compiled_block_1_1806( CONT_PARAMS );
static RTYPE compiled_block_1_1805( CONT_PARAMS );
static RTYPE compiled_block_1_1802( CONT_PARAMS );
static RTYPE compiled_start_1_29( CONT_PARAMS );
static RTYPE compiled_block_1_1771( CONT_PARAMS );
static RTYPE compiled_block_1_1773( CONT_PARAMS );
static RTYPE compiled_block_1_1775( CONT_PARAMS );
static RTYPE compiled_start_1_26( CONT_PARAMS );
static RTYPE compiled_block_1_1734( CONT_PARAMS );
static RTYPE compiled_block_1_1765( CONT_PARAMS );
static RTYPE compiled_block_1_1767( CONT_PARAMS );
static RTYPE compiled_block_1_1766( CONT_PARAMS );
static RTYPE compiled_start_1_25( CONT_PARAMS );
static RTYPE compiled_block_1_1762( CONT_PARAMS );
static RTYPE compiled_block_1_1761( CONT_PARAMS );
static RTYPE compiled_block_1_1763( CONT_PARAMS );
static RTYPE compiled_block_1_1759( CONT_PARAMS );
static RTYPE compiled_block_1_1756( CONT_PARAMS );
static RTYPE compiled_block_1_1757( CONT_PARAMS );
static RTYPE compiled_block_1_1735( CONT_PARAMS );
static RTYPE compiled_block_1_1738( CONT_PARAMS );
static RTYPE compiled_block_1_1741( CONT_PARAMS );
static RTYPE compiled_block_1_1743( CONT_PARAMS );
static RTYPE compiled_block_1_1752( CONT_PARAMS );
static RTYPE compiled_block_1_1751( CONT_PARAMS );
static RTYPE compiled_block_1_1747( CONT_PARAMS );
static RTYPE compiled_block_1_1750( CONT_PARAMS );
static RTYPE compiled_block_1_1748( CONT_PARAMS );
static RTYPE compiled_block_1_1749( CONT_PARAMS );
static RTYPE compiled_temp_1_32( CONT_PARAMS );
static RTYPE compiled_block_1_1746( CONT_PARAMS );
static RTYPE compiled_block_1_1745( CONT_PARAMS );
static RTYPE compiled_block_1_1744( CONT_PARAMS );
static RTYPE compiled_block_1_1739( CONT_PARAMS );
static RTYPE compiled_start_1_31( CONT_PARAMS );
static RTYPE compiled_block_1_1578( CONT_PARAMS );
static RTYPE compiled_block_1_1580( CONT_PARAMS );
static RTYPE compiled_block_1_1582( CONT_PARAMS );
static RTYPE compiled_block_1_1524( CONT_PARAMS );
static RTYPE compiled_block_1_1527( CONT_PARAMS );
static RTYPE compiled_block_1_1529( CONT_PARAMS );
static RTYPE compiled_start_1_17( CONT_PARAMS );
static RTYPE compiled_block_1_1621( CONT_PARAMS );
static RTYPE compiled_block_1_1623( CONT_PARAMS );
static RTYPE compiled_block_1_1626( CONT_PARAMS );
static RTYPE compiled_block_1_1624( CONT_PARAMS );
static RTYPE compiled_start_1_36( CONT_PARAMS );
static RTYPE compiled_block_1_1584( CONT_PARAMS );
static RTYPE compiled_block_1_1615( CONT_PARAMS );
static RTYPE compiled_block_1_1617( CONT_PARAMS );
static RTYPE compiled_block_1_1616( CONT_PARAMS );
static RTYPE compiled_start_1_35( CONT_PARAMS );
static RTYPE compiled_block_1_1613( CONT_PARAMS );
static RTYPE compiled_block_1_1611( CONT_PARAMS );
static RTYPE compiled_block_1_1612( CONT_PARAMS );
static RTYPE compiled_block_1_1609( CONT_PARAMS );
static RTYPE compiled_block_1_1604( CONT_PARAMS );
static RTYPE compiled_block_1_1607( CONT_PARAMS );
static RTYPE compiled_block_1_1605( CONT_PARAMS );
static RTYPE compiled_block_1_1585( CONT_PARAMS );
static RTYPE compiled_block_1_1588( CONT_PARAMS );
static RTYPE compiled_block_1_1591( CONT_PARAMS );
static RTYPE compiled_block_1_1598( CONT_PARAMS );
static RTYPE compiled_block_1_1601( CONT_PARAMS );
static RTYPE compiled_block_1_1599( CONT_PARAMS );
static RTYPE compiled_block_1_1600( CONT_PARAMS );
static RTYPE compiled_block_1_1596( CONT_PARAMS );
static RTYPE compiled_block_1_1597( CONT_PARAMS );
static RTYPE compiled_temp_1_39( CONT_PARAMS );
static RTYPE compiled_temp_1_38( CONT_PARAMS );
static RTYPE compiled_block_1_1595( CONT_PARAMS );
static RTYPE compiled_block_1_1594( CONT_PARAMS );
static RTYPE compiled_block_1_1593( CONT_PARAMS );
static RTYPE compiled_block_1_1592( CONT_PARAMS );
static RTYPE compiled_block_1_1589( CONT_PARAMS );
static RTYPE compiled_start_1_37( CONT_PARAMS );
static RTYPE compiled_block_1_1538( CONT_PARAMS );
static RTYPE compiled_block_1_1569( CONT_PARAMS );
static RTYPE compiled_block_1_1571( CONT_PARAMS );
static RTYPE compiled_block_1_1570( CONT_PARAMS );
static RTYPE compiled_start_1_34( CONT_PARAMS );
static RTYPE compiled_block_1_1567( CONT_PARAMS );
static RTYPE compiled_block_1_1565( CONT_PARAMS );
static RTYPE compiled_block_1_1566( CONT_PARAMS );
static RTYPE compiled_block_1_1563( CONT_PARAMS );
static RTYPE compiled_block_1_1558( CONT_PARAMS );
static RTYPE compiled_block_1_1561( CONT_PARAMS );
static RTYPE compiled_block_1_1559( CONT_PARAMS );
static RTYPE compiled_block_1_1539( CONT_PARAMS );
static RTYPE compiled_block_1_1542( CONT_PARAMS );
static RTYPE compiled_block_1_1545( CONT_PARAMS );
static RTYPE compiled_block_1_1552( CONT_PARAMS );
static RTYPE compiled_block_1_1555( CONT_PARAMS );
static RTYPE compiled_block_1_1553( CONT_PARAMS );
static RTYPE compiled_block_1_1554( CONT_PARAMS );
static RTYPE compiled_block_1_1550( CONT_PARAMS );
static RTYPE compiled_block_1_1551( CONT_PARAMS );
static RTYPE compiled_temp_1_42( CONT_PARAMS );
static RTYPE compiled_temp_1_41( CONT_PARAMS );
static RTYPE compiled_block_1_1549( CONT_PARAMS );
static RTYPE compiled_block_1_1548( CONT_PARAMS );
static RTYPE compiled_block_1_1547( CONT_PARAMS );
static RTYPE compiled_block_1_1546( CONT_PARAMS );
static RTYPE compiled_block_1_1543( CONT_PARAMS );
static RTYPE compiled_start_1_40( CONT_PARAMS );
static RTYPE compiled_block_1_1531( CONT_PARAMS );
static RTYPE compiled_block_1_1533( CONT_PARAMS );
static RTYPE compiled_block_1_1536( CONT_PARAMS );
static RTYPE compiled_block_1_1534( CONT_PARAMS );
static RTYPE compiled_start_1_33( CONT_PARAMS );
static RTYPE compiled_block_1_1504( CONT_PARAMS );
static RTYPE compiled_block_1_1506( CONT_PARAMS );
static RTYPE compiled_block_1_1508( CONT_PARAMS );
static RTYPE compiled_block_1_1510( CONT_PARAMS );
static RTYPE compiled_block_1_1512( CONT_PARAMS );
static RTYPE compiled_block_1_1515( CONT_PARAMS );
static RTYPE compiled_block_1_1516( CONT_PARAMS );
static RTYPE compiled_block_1_1513( CONT_PARAMS );
static RTYPE compiled_block_1_1459( CONT_PARAMS );
static RTYPE compiled_block_1_1479( CONT_PARAMS );
static RTYPE compiled_block_1_1481( CONT_PARAMS );
static RTYPE compiled_block_1_1483( CONT_PARAMS );
static RTYPE compiled_block_1_1485( CONT_PARAMS );
static RTYPE compiled_block_1_1488( CONT_PARAMS );
static RTYPE compiled_block_1_1490( CONT_PARAMS );
static RTYPE compiled_block_1_1493( CONT_PARAMS );
static RTYPE compiled_block_1_1495( CONT_PARAMS );
static RTYPE compiled_block_1_1494( CONT_PARAMS );
static RTYPE compiled_block_1_1491( CONT_PARAMS );
static RTYPE compiled_block_1_1486( CONT_PARAMS );
static RTYPE compiled_block_1_1458( CONT_PARAMS );
static RTYPE compiled_block_1_1462( CONT_PARAMS );
static RTYPE compiled_block_1_1464( CONT_PARAMS );
static RTYPE compiled_block_1_1466( CONT_PARAMS );
static RTYPE compiled_block_1_1468( CONT_PARAMS );
static RTYPE compiled_block_1_1471( CONT_PARAMS );
static RTYPE compiled_block_1_1472( CONT_PARAMS );
static RTYPE compiled_block_1_1469( CONT_PARAMS );
static RTYPE compiled_start_1_16( CONT_PARAMS );
static RTYPE compiled_block_1_1407( CONT_PARAMS );
static RTYPE compiled_block_1_1409( CONT_PARAMS );
static RTYPE compiled_start_1_15( CONT_PARAMS );
static RTYPE compiled_block_1_1418( CONT_PARAMS );
static RTYPE compiled_block_1_1449( CONT_PARAMS );
static RTYPE compiled_block_1_1451( CONT_PARAMS );
static RTYPE compiled_block_1_1450( CONT_PARAMS );
static RTYPE compiled_start_1_44( CONT_PARAMS );
static RTYPE compiled_block_1_1447( CONT_PARAMS );
static RTYPE compiled_block_1_1445( CONT_PARAMS );
static RTYPE compiled_block_1_1446( CONT_PARAMS );
static RTYPE compiled_block_1_1443( CONT_PARAMS );
static RTYPE compiled_block_1_1438( CONT_PARAMS );
static RTYPE compiled_block_1_1441( CONT_PARAMS );
static RTYPE compiled_block_1_1439( CONT_PARAMS );
static RTYPE compiled_block_1_1419( CONT_PARAMS );
static RTYPE compiled_block_1_1422( CONT_PARAMS );
static RTYPE compiled_block_1_1425( CONT_PARAMS );
static RTYPE compiled_block_1_1432( CONT_PARAMS );
static RTYPE compiled_block_1_1435( CONT_PARAMS );
static RTYPE compiled_block_1_1433( CONT_PARAMS );
static RTYPE compiled_block_1_1434( CONT_PARAMS );
static RTYPE compiled_block_1_1430( CONT_PARAMS );
static RTYPE compiled_block_1_1431( CONT_PARAMS );
static RTYPE compiled_temp_1_47( CONT_PARAMS );
static RTYPE compiled_temp_1_46( CONT_PARAMS );
static RTYPE compiled_block_1_1429( CONT_PARAMS );
static RTYPE compiled_block_1_1428( CONT_PARAMS );
static RTYPE compiled_block_1_1427( CONT_PARAMS );
static RTYPE compiled_block_1_1426( CONT_PARAMS );
static RTYPE compiled_block_1_1423( CONT_PARAMS );
static RTYPE compiled_start_1_45( CONT_PARAMS );
static RTYPE compiled_block_1_1411( CONT_PARAMS );
static RTYPE compiled_block_1_1413( CONT_PARAMS );
static RTYPE compiled_block_1_1416( CONT_PARAMS );
static RTYPE compiled_block_1_1414( CONT_PARAMS );
static RTYPE compiled_start_1_43( CONT_PARAMS );
static RTYPE compiled_block_1_1386( CONT_PARAMS );
static RTYPE compiled_block_1_1388( CONT_PARAMS );
static RTYPE compiled_block_1_1390( CONT_PARAMS );
static RTYPE compiled_block_1_1392( CONT_PARAMS );
static RTYPE compiled_block_1_1394( CONT_PARAMS );
static RTYPE compiled_block_1_1397( CONT_PARAMS );
static RTYPE compiled_block_1_1398( CONT_PARAMS );
static RTYPE compiled_block_1_1395( CONT_PARAMS );
static RTYPE compiled_block_1_1341( CONT_PARAMS );
static RTYPE compiled_block_1_1361( CONT_PARAMS );
static RTYPE compiled_block_1_1363( CONT_PARAMS );
static RTYPE compiled_block_1_1365( CONT_PARAMS );
static RTYPE compiled_block_1_1367( CONT_PARAMS );
static RTYPE compiled_block_1_1370( CONT_PARAMS );
static RTYPE compiled_block_1_1372( CONT_PARAMS );
static RTYPE compiled_block_1_1375( CONT_PARAMS );
static RTYPE compiled_block_1_1377( CONT_PARAMS );
static RTYPE compiled_block_1_1376( CONT_PARAMS );
static RTYPE compiled_block_1_1373( CONT_PARAMS );
static RTYPE compiled_block_1_1368( CONT_PARAMS );
static RTYPE compiled_block_1_1340( CONT_PARAMS );
static RTYPE compiled_block_1_1344( CONT_PARAMS );
static RTYPE compiled_block_1_1346( CONT_PARAMS );
static RTYPE compiled_block_1_1348( CONT_PARAMS );
static RTYPE compiled_block_1_1350( CONT_PARAMS );
static RTYPE compiled_block_1_1353( CONT_PARAMS );
static RTYPE compiled_block_1_1354( CONT_PARAMS );
static RTYPE compiled_block_1_1351( CONT_PARAMS );
static RTYPE compiled_start_1_14( CONT_PARAMS );
static RTYPE compiled_block_1_1253( CONT_PARAMS );
static RTYPE compiled_block_1_1255( CONT_PARAMS );
static RTYPE compiled_block_1_1258( CONT_PARAMS );
static RTYPE compiled_block_1_1260( CONT_PARAMS );
static RTYPE compiled_block_1_1262( CONT_PARAMS );
static RTYPE compiled_block_1_1264( CONT_PARAMS );
static RTYPE compiled_block_1_1267( CONT_PARAMS );
static RTYPE compiled_block_1_1269( CONT_PARAMS );
static RTYPE compiled_block_1_1265( CONT_PARAMS );
static RTYPE compiled_block_1_1256( CONT_PARAMS );
static RTYPE compiled_block_1_1143( CONT_PARAMS );
static RTYPE compiled_block_1_1187( CONT_PARAMS );
static RTYPE compiled_block_1_1189( CONT_PARAMS );
static RTYPE compiled_block_1_1192( CONT_PARAMS );
static RTYPE compiled_block_1_1194( CONT_PARAMS );
static RTYPE compiled_block_1_1196( CONT_PARAMS );
static RTYPE compiled_block_1_1199( CONT_PARAMS );
static RTYPE compiled_block_1_1201( CONT_PARAMS );
static RTYPE compiled_block_1_1204( CONT_PARAMS );
static RTYPE compiled_block_1_1206( CONT_PARAMS );
static RTYPE compiled_block_1_1202( CONT_PARAMS );
static RTYPE compiled_block_1_1197( CONT_PARAMS );
static RTYPE compiled_block_1_1190( CONT_PARAMS );
static RTYPE compiled_block_1_1142( CONT_PARAMS );
static RTYPE compiled_block_1_1146( CONT_PARAMS );
static RTYPE compiled_block_1_1148( CONT_PARAMS );
static RTYPE compiled_start_1_13( CONT_PARAMS );
static RTYPE compiled_block_1_1325( CONT_PARAMS );
static RTYPE compiled_block_1_1327( CONT_PARAMS );
static RTYPE compiled_block_1_1329( CONT_PARAMS );
static RTYPE compiled_start_1_53( CONT_PARAMS );
static RTYPE compiled_block_1_1271( CONT_PARAMS );
static RTYPE compiled_block_1_1319( CONT_PARAMS );
static RTYPE compiled_block_1_1321( CONT_PARAMS );
static RTYPE compiled_block_1_1320( CONT_PARAMS );
static RTYPE compiled_start_1_52( CONT_PARAMS );
static RTYPE compiled_block_1_1311( CONT_PARAMS );
static RTYPE compiled_block_1_1302( CONT_PARAMS );
static RTYPE compiled_block_1_1301( CONT_PARAMS );
static RTYPE compiled_block_1_1310( CONT_PARAMS );
static RTYPE compiled_block_1_1317( CONT_PARAMS );
static RTYPE compiled_block_1_1316( CONT_PARAMS );
static RTYPE compiled_block_1_1314( CONT_PARAMS );
static RTYPE compiled_block_1_1274( CONT_PARAMS );
static RTYPE compiled_block_1_1308( CONT_PARAMS );
static RTYPE compiled_block_1_1305( CONT_PARAMS );
static RTYPE compiled_block_1_1306( CONT_PARAMS );
static RTYPE compiled_block_1_1273( CONT_PARAMS );
static RTYPE compiled_block_1_1303( CONT_PARAMS );
static RTYPE compiled_block_1_1299( CONT_PARAMS );
static RTYPE compiled_block_1_1296( CONT_PARAMS );
static RTYPE compiled_block_1_1297( CONT_PARAMS );
static RTYPE compiled_block_1_1272( CONT_PARAMS );
static RTYPE compiled_block_1_1278( CONT_PARAMS );
static RTYPE compiled_block_1_1294( CONT_PARAMS );
static RTYPE compiled_block_1_1290( CONT_PARAMS );
static RTYPE compiled_block_1_1293( CONT_PARAMS );
static RTYPE compiled_block_1_1291( CONT_PARAMS );
static RTYPE compiled_block_1_1292( CONT_PARAMS );
static RTYPE compiled_temp_1_56( CONT_PARAMS );
static RTYPE compiled_block_1_1289( CONT_PARAMS );
static RTYPE compiled_block_1_1288( CONT_PARAMS );
static RTYPE compiled_block_1_1284( CONT_PARAMS );
static RTYPE compiled_block_1_1287( CONT_PARAMS );
static RTYPE compiled_block_1_1285( CONT_PARAMS );
static RTYPE compiled_block_1_1286( CONT_PARAMS );
static RTYPE compiled_temp_1_55( CONT_PARAMS );
static RTYPE compiled_block_1_1283( CONT_PARAMS );
static RTYPE compiled_block_1_1282( CONT_PARAMS );
static RTYPE compiled_block_1_1281( CONT_PARAMS );
static RTYPE compiled_block_1_1280( CONT_PARAMS );
static RTYPE compiled_block_1_1279( CONT_PARAMS );
static RTYPE compiled_block_1_1276( CONT_PARAMS );
static RTYPE compiled_start_1_54( CONT_PARAMS );
static RTYPE compiled_block_1_1237( CONT_PARAMS );
static RTYPE compiled_block_1_1239( CONT_PARAMS );
static RTYPE compiled_block_1_1241( CONT_PARAMS );
static RTYPE compiled_start_1_51( CONT_PARAMS );
static RTYPE compiled_block_1_1208( CONT_PARAMS );
static RTYPE compiled_block_1_1231( CONT_PARAMS );
static RTYPE compiled_block_1_1233( CONT_PARAMS );
static RTYPE compiled_block_1_1232( CONT_PARAMS );
static RTYPE compiled_start_1_50( CONT_PARAMS );
static RTYPE compiled_block_1_1229( CONT_PARAMS );
static RTYPE compiled_block_1_1228( CONT_PARAMS );
static RTYPE compiled_block_1_1226( CONT_PARAMS );
static RTYPE compiled_block_1_1223( CONT_PARAMS );
static RTYPE compiled_block_1_1224( CONT_PARAMS );
static RTYPE compiled_block_1_1209( CONT_PARAMS );
static RTYPE compiled_block_1_1213( CONT_PARAMS );
static RTYPE compiled_block_1_1218( CONT_PARAMS );
static RTYPE compiled_block_1_1221( CONT_PARAMS );
static RTYPE compiled_block_1_1219( CONT_PARAMS );
static RTYPE compiled_block_1_1220( CONT_PARAMS );
static RTYPE compiled_temp_1_58( CONT_PARAMS );
static RTYPE compiled_block_1_1217( CONT_PARAMS );
static RTYPE compiled_block_1_1216( CONT_PARAMS );
static RTYPE compiled_block_1_1215( CONT_PARAMS );
static RTYPE compiled_block_1_1214( CONT_PARAMS );
static RTYPE compiled_block_1_1211( CONT_PARAMS );
static RTYPE compiled_start_1_57( CONT_PARAMS );
static RTYPE compiled_block_1_1156( CONT_PARAMS );
static RTYPE compiled_block_1_1178( CONT_PARAMS );
static RTYPE compiled_block_1_1180( CONT_PARAMS );
static RTYPE compiled_block_1_1179( CONT_PARAMS );
static RTYPE compiled_start_1_49( CONT_PARAMS );
static RTYPE compiled_block_1_1176( CONT_PARAMS );
static RTYPE compiled_block_1_1175( CONT_PARAMS );
static RTYPE compiled_block_1_1173( CONT_PARAMS );
static RTYPE compiled_block_1_1170( CONT_PARAMS );
static RTYPE compiled_block_1_1171( CONT_PARAMS );
static RTYPE compiled_block_1_1157( CONT_PARAMS );
static RTYPE compiled_block_1_1161( CONT_PARAMS );
static RTYPE compiled_block_1_1165( CONT_PARAMS );
static RTYPE compiled_block_1_1168( CONT_PARAMS );
static RTYPE compiled_block_1_1166( CONT_PARAMS );
static RTYPE compiled_block_1_1167( CONT_PARAMS );
static RTYPE compiled_temp_1_60( CONT_PARAMS );
static RTYPE compiled_block_1_1164( CONT_PARAMS );
static RTYPE compiled_block_1_1163( CONT_PARAMS );
static RTYPE compiled_block_1_1162( CONT_PARAMS );
static RTYPE compiled_block_1_1159( CONT_PARAMS );
static RTYPE compiled_start_1_59( CONT_PARAMS );
static RTYPE compiled_block_1_1150( CONT_PARAMS );
static RTYPE compiled_block_1_1152( CONT_PARAMS );
static RTYPE compiled_block_1_1154( CONT_PARAMS );
static RTYPE compiled_start_1_48( CONT_PARAMS );
static RTYPE compiled_block_1_1085( CONT_PARAMS );
static RTYPE compiled_block_1_1087( CONT_PARAMS );
static RTYPE compiled_block_1_1089( CONT_PARAMS );
static RTYPE compiled_block_1_1091( CONT_PARAMS );
static RTYPE compiled_block_1_1093( CONT_PARAMS );
static RTYPE compiled_block_1_1095( CONT_PARAMS );
static RTYPE compiled_block_1_1065( CONT_PARAMS );
static RTYPE compiled_block_1_1068( CONT_PARAMS );
static RTYPE compiled_block_1_1070( CONT_PARAMS );
static RTYPE compiled_block_1_1072( CONT_PARAMS );
static RTYPE compiled_block_1_1074( CONT_PARAMS );
static RTYPE compiled_block_1_1077( CONT_PARAMS );
static RTYPE compiled_block_1_1078( CONT_PARAMS );
static RTYPE compiled_block_1_1075( CONT_PARAMS );
static RTYPE compiled_start_1_12( CONT_PARAMS );
static RTYPE compiled_block_1_1129( CONT_PARAMS );
static RTYPE compiled_block_1_1131( CONT_PARAMS );
static RTYPE compiled_block_1_1133( CONT_PARAMS );
static RTYPE compiled_start_1_62( CONT_PARAMS );
static RTYPE compiled_block_1_1097( CONT_PARAMS );
static RTYPE compiled_block_1_1123( CONT_PARAMS );
static RTYPE compiled_block_1_1125( CONT_PARAMS );
static RTYPE compiled_block_1_1124( CONT_PARAMS );
static RTYPE compiled_start_1_61( CONT_PARAMS );
static RTYPE compiled_block_1_1121( CONT_PARAMS );
static RTYPE compiled_block_1_1120( CONT_PARAMS );
static RTYPE compiled_block_1_1118( CONT_PARAMS );
static RTYPE compiled_block_1_1115( CONT_PARAMS );
static RTYPE compiled_block_1_1116( CONT_PARAMS );
static RTYPE compiled_block_1_1098( CONT_PARAMS );
static RTYPE compiled_block_1_1101( CONT_PARAMS );
static RTYPE compiled_block_1_1104( CONT_PARAMS );
static RTYPE compiled_block_1_1109( CONT_PARAMS );
static RTYPE compiled_block_1_1112( CONT_PARAMS );
static RTYPE compiled_block_1_1110( CONT_PARAMS );
static RTYPE compiled_block_1_1111( CONT_PARAMS );
static RTYPE compiled_temp_1_64( CONT_PARAMS );
static RTYPE compiled_block_1_1108( CONT_PARAMS );
static RTYPE compiled_block_1_1107( CONT_PARAMS );
static RTYPE compiled_block_1_1106( CONT_PARAMS );
static RTYPE compiled_block_1_1105( CONT_PARAMS );
static RTYPE compiled_block_1_1102( CONT_PARAMS );
static RTYPE compiled_start_1_63( CONT_PARAMS );
static RTYPE compiled_block_1_1033( CONT_PARAMS );
static RTYPE compiled_block_1_1035( CONT_PARAMS );
static RTYPE compiled_block_1_1037( CONT_PARAMS );
static RTYPE compiled_block_1_1002( CONT_PARAMS );
static RTYPE compiled_block_1_1005( CONT_PARAMS );
static RTYPE compiled_block_1_1007( CONT_PARAMS );
static RTYPE compiled_start_1_11( CONT_PARAMS );
static RTYPE compiled_block_1_1055( CONT_PARAMS );
static RTYPE compiled_block_1_1057( CONT_PARAMS );
static RTYPE compiled_block_1_1059( CONT_PARAMS );
static RTYPE compiled_start_1_68( CONT_PARAMS );
static RTYPE compiled_block_1_1039( CONT_PARAMS );
static RTYPE compiled_block_1_1049( CONT_PARAMS );
static RTYPE compiled_block_1_1051( CONT_PARAMS );
static RTYPE compiled_block_1_1050( CONT_PARAMS );
static RTYPE compiled_start_1_67( CONT_PARAMS );
static RTYPE compiled_block_1_1041( CONT_PARAMS );
static RTYPE compiled_block_1_1044( CONT_PARAMS );
static RTYPE compiled_block_1_1046( CONT_PARAMS );
static RTYPE compiled_block_1_1045( CONT_PARAMS );
static RTYPE compiled_block_1_1042( CONT_PARAMS );
static RTYPE compiled_start_1_69( CONT_PARAMS );
static RTYPE compiled_block_1_1015( CONT_PARAMS );
static RTYPE compiled_block_1_1024( CONT_PARAMS );
static RTYPE compiled_block_1_1026( CONT_PARAMS );
static RTYPE compiled_block_1_1025( CONT_PARAMS );
static RTYPE compiled_start_1_66( CONT_PARAMS );
static RTYPE compiled_block_1_1017( CONT_PARAMS );
static RTYPE compiled_block_1_1020( CONT_PARAMS );
static RTYPE compiled_block_1_1021( CONT_PARAMS );
static RTYPE compiled_block_1_1018( CONT_PARAMS );
static RTYPE compiled_start_1_70( CONT_PARAMS );
static RTYPE compiled_block_1_1009( CONT_PARAMS );
static RTYPE compiled_block_1_1011( CONT_PARAMS );
static RTYPE compiled_block_1_1013( CONT_PARAMS );
static RTYPE compiled_start_1_65( CONT_PARAMS );
static RTYPE compiled_start_1_1( CONT_PARAMS );

static RTYPE compiled_start_1_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 2 ); /*  unvector~1ay%kV~37370 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 3 ); /*  unlist~1ay%kV~37369 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 4 ); /*  uncons-cons~1ay%kV~37368 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 5 ); /*  uncons-4~1ay%kV~37367 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 6 ); /*  uncons-3~1ay%kV~37366 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 7 ); /*  uncons-2~1ay%kV~37365 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 8 ); /*  uncons~1ay%kV~37364 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 9 ); /*  i:undefined~1ay%kV~36494 */
  twobit_lambda( compiled_start_1_1, 11, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_2, 13, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_3, 15, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_const( 17 );
  twobit_setreg( 3 );
  twobit_const( 18 );
  twobit_setreg( 4 );
  twobit_const( 19 );
  twobit_setreg( 5 );
  twobit_const( 20 );
  twobit_setreg( 8 );
  twobit_global( 21 ); /* ex:make-library */
  twobit_setrtn( 3006, compiled_block_1_3006 );
  twobit_invoke( 8 );
  twobit_label( 3006, compiled_block_1_3006 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 22 ); /* ex:register-library! */
  twobit_setrtn( 3007, compiled_block_1_3007 );
  twobit_invoke( 1 );
  twobit_label( 3007, compiled_block_1_3007 );
  twobit_load( 0, 0 );
  twobit_global( 23 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* ex:uncompress */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_11, 2, 0 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1064, compiled_block_1_1064 );
  twobit_invoke( 2 );
  twobit_label( 1064, compiled_block_1_1064 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_12, 6, 0 );
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1141, compiled_block_1_1141 );
  twobit_invoke( 2 );
  twobit_label( 1141, compiled_block_1_1141 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_13, 9, 0 );
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1339, compiled_block_1_1339 );
  twobit_invoke( 2 );
  twobit_label( 1339, compiled_block_1_1339 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_14, 12, 0 );
  twobit_setreg( 2 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1405, compiled_block_1_1405 );
  twobit_invoke( 2 );
  twobit_label( 1405, compiled_block_1_1405 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_15, 15, 0 );
  twobit_setreg( 2 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1457, compiled_block_1_1457 );
  twobit_invoke( 2 );
  twobit_label( 1457, compiled_block_1_1457 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_16, 18, 0 );
  twobit_setreg( 2 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1523, compiled_block_1_1523 );
  twobit_invoke( 2 );
  twobit_label( 1523, compiled_block_1_1523 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_17, 21, 0 );
  twobit_setreg( 2 );
  twobit_const( 22 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1631, compiled_block_1_1631 );
  twobit_invoke( 2 );
  twobit_label( 1631, compiled_block_1_1631 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_18, 24, 0 );
  twobit_setreg( 2 );
  twobit_const( 25 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 2754, compiled_block_1_2754 );
  twobit_invoke( 2 );
  twobit_label( 2754, compiled_block_1_2754 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_19, 27, 0 );
  twobit_setreg( 2 );
  twobit_const( 28 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 2877, compiled_block_1_2877 );
  twobit_invoke( 2 );
  twobit_label( 2877, compiled_block_1_2877 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_20, 30, 0 );
  twobit_setreg( 2 );
  twobit_const( 31 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 2890, compiled_block_1_2890 );
  twobit_invoke( 2 );
  twobit_label( 2890, compiled_block_1_2890 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_21, 33, 0 );
  twobit_setreg( 2 );
  twobit_const( 34 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 2903, compiled_block_1_2903 );
  twobit_invoke( 2 );
  twobit_label( 2903, compiled_block_1_2903 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_22, 36, 0 );
  twobit_setreg( 2 );
  twobit_const( 37 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 2945, compiled_block_1_2945 );
  twobit_invoke( 2 );
  twobit_label( 2945, compiled_block_1_2945 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_23, 39, 0 );
  twobit_setreg( 2 );
  twobit_const( 40 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 2964, compiled_block_1_2964 );
  twobit_invoke( 2 );
  twobit_label( 2964, compiled_block_1_2964 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_24, 42, 0 );
  twobit_setreg( 2 );
  twobit_const( 43 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 2983, compiled_block_1_2983 );
  twobit_invoke( 2 );
  twobit_label( 2983, compiled_block_1_2983 );
  twobit_load( 0, 0 );
  twobit_global( 44 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_11( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1005, compiled_block_1_1005 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1007, compiled_block_1_1007 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_lambda( compiled_start_1_65, 2, 0 );
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_66, 4, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 5 ); /* ex:map-while */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1007, compiled_block_1_1007 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1005, compiled_block_1_1005 );
  twobit_label( 1002, compiled_block_1_1002 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1033, compiled_block_1_1033 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1035, compiled_block_1_1035 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1037, compiled_block_1_1037 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_67, 7, 3 );
  twobit_setreg( 3 );
  twobit_lambda( compiled_start_1_68, 9, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* ex:map-while */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_label( 1037, compiled_block_1_1037 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1035, compiled_block_1_1035 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1033, compiled_block_1_1033 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_65( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1009, compiled_block_1_1009 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1011, compiled_block_1_1011 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1013, compiled_block_1_1013 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_return();
  twobit_label( 1013, compiled_block_1_1013 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1011, compiled_block_1_1011 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1009, compiled_block_1_1009 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_66( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1015, compiled_block_1_1015 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_70, 2, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1025, compiled_block_1_1025 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_skip( 1024, compiled_block_1_1024 );
  twobit_label( 1025, compiled_block_1_1025 );
  twobit_movereg( 1, 3 );
  twobit_global( 4 ); /* map */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* list */
  twobit_setreg( 2 );
  twobit_global( 6 ); /* apply */
  twobit_setrtn( 1026, compiled_block_1_1026 );
  twobit_invoke( 3 );
  twobit_label( 1026, compiled_block_1_1026 );
  twobit_load( 0, 0 );
  twobit_label( 1024, compiled_block_1_1024 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1015, compiled_block_1_1015 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_jump( 1, 1002, compiled_block_1_1002 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_70( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 1, 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1017, compiled_block_1_1017 ); /* internal:branchf-pair? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 4 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1018, compiled_block_1_1018 );
  twobit_invoke( 1 );
  twobit_label( 1018, compiled_block_1_1018 );
  twobit_load( 0, 0 );
  twobit_branchf( 1020, compiled_block_1_1020 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1021, compiled_block_1_1021 );
  twobit_invoke( 5 );
  twobit_label( 1021, compiled_block_1_1021 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1020, compiled_block_1_1020 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_pop( 4 );
  twobit_jump( 2, 1002, compiled_block_1_1002 );
  twobit_label( 1017, compiled_block_1_1017 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_jump( 2, 1002, compiled_block_1_1002 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_67( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1039, compiled_block_1_1039 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_69, 2, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1050, compiled_block_1_1050 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_skip( 1049, compiled_block_1_1049 );
  twobit_label( 1050, compiled_block_1_1050 );
  twobit_movereg( 1, 3 );
  twobit_global( 4 ); /* map */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* list */
  twobit_setreg( 2 );
  twobit_global( 6 ); /* apply */
  twobit_setrtn( 1051, compiled_block_1_1051 );
  twobit_invoke( 3 );
  twobit_label( 1051, compiled_block_1_1051 );
  twobit_load( 0, 0 );
  twobit_label( 1049, compiled_block_1_1049 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1039, compiled_block_1_1039 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_69( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 1, 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1041, compiled_block_1_1041 ); /* internal:branchf-pair? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 6 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1042, compiled_block_1_1042 );
  twobit_invoke( 1 );
  twobit_label( 1042, compiled_block_1_1042 );
  twobit_load( 0, 0 );
  twobit_branchf( 1044, compiled_block_1_1044 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1045, compiled_block_1_1045 );
  twobit_invoke( 5 );
  twobit_label( 1045, compiled_block_1_1045 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_lexical( 1, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_load( 2, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_stack( 3 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1046, compiled_block_1_1046 );
  twobit_invoke( 5 );
  twobit_label( 1046, compiled_block_1_1046 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_lexical( 1, 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1044, compiled_block_1_1044 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_pop( 6 );
  twobit_invoke( 1 );
  twobit_label( 1041, compiled_block_1_1041 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_68( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1055, compiled_block_1_1055 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1057, compiled_block_1_1057 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1059, compiled_block_1_1059 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_return();
  twobit_label( 1059, compiled_block_1_1059 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1057, compiled_block_1_1057 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1055, compiled_block_1_1055 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_12( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1068, compiled_block_1_1068 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1070, compiled_block_1_1070 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_op1_branchf_610( 1072, compiled_block_1_1072 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1074, compiled_block_1_1074 ); /* internal:branchf-pair? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1075, compiled_block_1_1075 );
  twobit_invoke( 1 );
  twobit_label( 1075, compiled_block_1_1075 );
  twobit_load( 0, 0 );
  twobit_branchf( 1077, compiled_block_1_1077 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1078, compiled_block_1_1078 );
  twobit_invoke( 5 );
  twobit_label( 1078, compiled_block_1_1078 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1077, compiled_block_1_1077 );
  twobit_load( 1, 3 );
  twobit_pop( 3 );
  twobit_branch( 1065, compiled_block_1_1065 );
  twobit_label( 1074, compiled_block_1_1074 );
  twobit_branch( 1065, compiled_block_1_1065 );
  twobit_label( 1072, compiled_block_1_1072 );
  twobit_branch( 1065, compiled_block_1_1065 );
  twobit_label( 1070, compiled_block_1_1070 );
  twobit_branch( 1065, compiled_block_1_1065 );
  twobit_label( 1068, compiled_block_1_1068 );
  twobit_label( 1065, compiled_block_1_1065 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1085, compiled_block_1_1085 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1087, compiled_block_1_1087 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1089, compiled_block_1_1089 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1091, compiled_block_1_1091 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1093, compiled_block_1_1093 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1095, compiled_block_1_1095 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 30, 3 );
  twobit_movereg( 31, 2 );
  twobit_lambda( compiled_start_1_61, 7, 4 );
  twobit_setreg( 3 );
  twobit_lambda( compiled_start_1_62, 9, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 10 ); /* ex:map-while */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_label( 1095, compiled_block_1_1095 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1093, compiled_block_1_1093 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1091, compiled_block_1_1091 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1089, compiled_block_1_1089 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1087, compiled_block_1_1087 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1085, compiled_block_1_1085 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_61( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1097, compiled_block_1_1097 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_63, 2, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1124, compiled_block_1_1124 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_skip( 1123, compiled_block_1_1123 );
  twobit_label( 1124, compiled_block_1_1124 );
  twobit_movereg( 1, 3 );
  twobit_global( 4 ); /* map */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* list */
  twobit_setreg( 2 );
  twobit_global( 6 ); /* apply */
  twobit_setrtn( 1125, compiled_block_1_1125 );
  twobit_invoke( 3 );
  twobit_label( 1125, compiled_block_1_1125 );
  twobit_load( 0, 0 );
  twobit_label( 1123, compiled_block_1_1123 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1097, compiled_block_1_1097 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_63( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 1, 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1101, compiled_block_1_1101 ); /* internal:branchf-pair? */
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 4 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1102, compiled_block_1_1102 );
  twobit_invoke( 1 );
  twobit_label( 1102, compiled_block_1_1102 );
  twobit_load( 0, 0 );
  twobit_branchf( 1104, compiled_block_1_1104 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1105, compiled_block_1_1105 );
  twobit_invoke( 5 );
  twobit_label( 1105, compiled_block_1_1105 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_lexical( 1, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 2 ); /* () */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1106, compiled_block_1_1106 );
  twobit_invoke( 5 );
  twobit_label( 1106, compiled_block_1_1106 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 3, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_load( 1, 3 );
  twobit_global( 7 ); /* length */
  twobit_setrtn( 1107, compiled_block_1_1107 );
  twobit_invoke( 1 );
  twobit_label( 1107, compiled_block_1_1107 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 4 );
  twobit_global( 7 ); /* length */
  twobit_setrtn( 1108, compiled_block_1_1108 );
  twobit_invoke( 1 );
  twobit_label( 1108, compiled_block_1_1108 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_branchf_623( 4, 64, compiled_temp_1_64, 1110, compiled_block_1_1110 ); /* internal:branchf-= */
  twobit_load( 1, 3 );
  twobit_load( 2, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_setrtn( 1111, compiled_block_1_1111 );
  twobit_branch( 1098, compiled_block_1_1098 );
  twobit_label( 1111, compiled_block_1_1111 );
  twobit_load( 0, 0 );
  twobit_skip( 1109, compiled_block_1_1109 );
  twobit_label( 1110, compiled_block_1_1110 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_const( 9 );
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 3 );
  twobit_global( 11 ); /* ex:syntax-violation */
  twobit_setrtn( 1112, compiled_block_1_1112 );
  twobit_invoke( 4 );
  twobit_label( 1112, compiled_block_1_1112 );
  twobit_load( 0, 0 );
  twobit_label( 1109, compiled_block_1_1109 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1104, compiled_block_1_1104 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 12 ); /* ex:invalid-form */
  twobit_pop( 7 );
  twobit_invoke( 1 );
  twobit_label( 1101, compiled_block_1_1101 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 12 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1098, compiled_block_1_1098 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1116, compiled_block_1_1116 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1115, compiled_block_1_1115 );
  twobit_label( 1116, compiled_block_1_1116 );
  twobit_reg( 2 );
  twobit_op1_10(); /* null? */
  twobit_label( 1115, compiled_block_1_1115 );
  twobit_branchf( 1118, compiled_block_1_1118 );
  twobit_movereg( 3, 1 );
  twobit_global( 13 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1118, compiled_block_1_1118 );
  twobit_reg_op1_check_652(reg(2),1120,compiled_block_1_1120); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(1),1121,compiled_block_1_1121); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op2_58( 30 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 31 );
  twobit_op2_58( 4 ); /* cons */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_branch( 1098, compiled_block_1_1098 );
  twobit_label( 1120, compiled_block_1_1120 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 1121, compiled_block_1_1121 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_62( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1129, compiled_block_1_1129 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1131, compiled_block_1_1131 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1133, compiled_block_1_1133 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_return();
  twobit_label( 1133, compiled_block_1_1133 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1131, compiled_block_1_1131 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1129, compiled_block_1_1129 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_13( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1146, compiled_block_1_1146 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1148, compiled_block_1_1148 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_lambda( compiled_start_1_48, 2, 0 );
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_49, 4, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 5 ); /* ex:map-while */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1148, compiled_block_1_1148 );
  twobit_branch( 1143, compiled_block_1_1143 );
  twobit_label( 1146, compiled_block_1_1146 );
  twobit_branch( 1143, compiled_block_1_1143 );
  twobit_label( 1142, compiled_block_1_1142 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1187, compiled_block_1_1187 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1189, compiled_block_1_1189 ); /* internal:branchf-pair? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_const( 6 );
  twobit_setreg( 2 );
  twobit_global( 7 ); /* equal? */
  twobit_setrtn( 1190, compiled_block_1_1190 );
  twobit_invoke( 2 );
  twobit_label( 1190, compiled_block_1_1190 );
  twobit_load( 0, 0 );
  twobit_branchf( 1192, compiled_block_1_1192 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1194, compiled_block_1_1194 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1196, compiled_block_1_1196 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_movereg( 3, 1 );
  twobit_global( 8 ); /* list? */
  twobit_setrtn( 1197, compiled_block_1_1197 );
  twobit_invoke( 1 );
  twobit_label( 1197, compiled_block_1_1197 );
  twobit_load( 0, 0 );
  twobit_branchf( 1199, compiled_block_1_1199 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1201, compiled_block_1_1201 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_movereg( 3, 1 );
  twobit_global( 8 ); /* list? */
  twobit_setrtn( 1202, compiled_block_1_1202 );
  twobit_invoke( 1 );
  twobit_label( 1202, compiled_block_1_1202 );
  twobit_load( 0, 0 );
  twobit_branchf( 1204, compiled_block_1_1204 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1206, compiled_block_1_1206 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_load( 3, 2 );
  twobit_load( 2, 3 );
  twobit_load( 1, 4 );
  twobit_lambda( compiled_start_1_50, 10, 4 );
  twobit_setreg( 3 );
  twobit_lambda( compiled_start_1_51, 12, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* ex:map-while */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 1206, compiled_block_1_1206 );
  twobit_load( 1, 4 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 1204, compiled_block_1_1204 );
  twobit_load( 1, 4 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 1201, compiled_block_1_1201 );
  twobit_load( 1, 4 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 1199, compiled_block_1_1199 );
  twobit_load( 1, 4 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 1196, compiled_block_1_1196 );
  twobit_load( 1, 4 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 1194, compiled_block_1_1194 );
  twobit_load( 1, 4 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 1192, compiled_block_1_1192 );
  twobit_load( 1, 4 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 1189, compiled_block_1_1189 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1187, compiled_block_1_1187 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1143, compiled_block_1_1143 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1253, compiled_block_1_1253 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1255, compiled_block_1_1255 ); /* internal:branchf-pair? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_const( 6 );
  twobit_setreg( 2 );
  twobit_global( 7 ); /* equal? */
  twobit_setrtn( 1256, compiled_block_1_1256 );
  twobit_invoke( 2 );
  twobit_label( 1256, compiled_block_1_1256 );
  twobit_load( 0, 0 );
  twobit_branchf( 1258, compiled_block_1_1258 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1260, compiled_block_1_1260 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_op1_branchf_610( 1262, compiled_block_1_1262 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1264, compiled_block_1_1264 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_movereg( 3, 1 );
  twobit_global( 8 ); /* list? */
  twobit_setrtn( 1265, compiled_block_1_1265 );
  twobit_invoke( 1 );
  twobit_label( 1265, compiled_block_1_1265 );
  twobit_load( 0, 0 );
  twobit_branchf( 1267, compiled_block_1_1267 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1269, compiled_block_1_1269 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 4, 3 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_52, 15, 3 );
  twobit_setreg( 3 );
  twobit_lambda( compiled_start_1_53, 17, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* ex:map-while */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1269, compiled_block_1_1269 );
  twobit_load( 1, 3 );
  twobit_pop( 3 );
  twobit_branch( 1142, compiled_block_1_1142 );
  twobit_label( 1267, compiled_block_1_1267 );
  twobit_load( 1, 3 );
  twobit_pop( 3 );
  twobit_branch( 1142, compiled_block_1_1142 );
  twobit_label( 1264, compiled_block_1_1264 );
  twobit_load( 1, 3 );
  twobit_pop( 3 );
  twobit_branch( 1142, compiled_block_1_1142 );
  twobit_label( 1262, compiled_block_1_1262 );
  twobit_load( 1, 3 );
  twobit_pop( 3 );
  twobit_branch( 1142, compiled_block_1_1142 );
  twobit_label( 1260, compiled_block_1_1260 );
  twobit_load( 1, 3 );
  twobit_pop( 3 );
  twobit_branch( 1142, compiled_block_1_1142 );
  twobit_label( 1258, compiled_block_1_1258 );
  twobit_load( 1, 3 );
  twobit_pop( 3 );
  twobit_branch( 1142, compiled_block_1_1142 );
  twobit_label( 1255, compiled_block_1_1255 );
  twobit_branch( 1142, compiled_block_1_1142 );
  twobit_label( 1253, compiled_block_1_1253 );
  twobit_branch( 1142, compiled_block_1_1142 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_48( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1150, compiled_block_1_1150 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1152, compiled_block_1_1152 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1154, compiled_block_1_1154 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_return();
  twobit_label( 1154, compiled_block_1_1154 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1152, compiled_block_1_1152 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1150, compiled_block_1_1150 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_49( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1156, compiled_block_1_1156 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_59, 2, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1179, compiled_block_1_1179 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_skip( 1178, compiled_block_1_1178 );
  twobit_label( 1179, compiled_block_1_1179 );
  twobit_movereg( 1, 3 );
  twobit_global( 4 ); /* map */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* list */
  twobit_setreg( 2 );
  twobit_global( 6 ); /* apply */
  twobit_setrtn( 1180, compiled_block_1_1180 );
  twobit_invoke( 3 );
  twobit_label( 1180, compiled_block_1_1180 );
  twobit_load( 0, 0 );
  twobit_label( 1178, compiled_block_1_1178 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1156, compiled_block_1_1156 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_jump( 1, 1143, compiled_block_1_1143 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_59( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_lexical( 1, 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1159, compiled_block_1_1159 );
  twobit_invoke( 1 );
  twobit_label( 1159, compiled_block_1_1159 );
  twobit_load( 0, 0 );
  twobit_branchf( 1161, compiled_block_1_1161 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1162, compiled_block_1_1162 );
  twobit_invoke( 5 );
  twobit_label( 1162, compiled_block_1_1162 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1163, compiled_block_1_1163 );
  twobit_invoke( 1 );
  twobit_label( 1163, compiled_block_1_1163 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1164, compiled_block_1_1164 );
  twobit_invoke( 1 );
  twobit_label( 1164, compiled_block_1_1164 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_branchf_623( 4, 60, compiled_temp_1_60, 1166, compiled_block_1_1166 ); /* internal:branchf-= */
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_setrtn( 1167, compiled_block_1_1167 );
  twobit_branch( 1157, compiled_block_1_1157 );
  twobit_label( 1167, compiled_block_1_1167 );
  twobit_load( 0, 0 );
  twobit_skip( 1165, compiled_block_1_1165 );
  twobit_label( 1166, compiled_block_1_1166 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_global( 10 ); /* ex:syntax-violation */
  twobit_setrtn( 1168, compiled_block_1_1168 );
  twobit_invoke( 4 );
  twobit_label( 1168, compiled_block_1_1168 );
  twobit_load( 0, 0 );
  twobit_label( 1165, compiled_block_1_1165 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1161, compiled_block_1_1161 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_pop( 5 );
  twobit_jump( 2, 1143, compiled_block_1_1143 );
  twobit_label( 1157, compiled_block_1_1157 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1171, compiled_block_1_1171 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1170, compiled_block_1_1170 );
  twobit_label( 1171, compiled_block_1_1171 );
  twobit_reg( 2 );
  twobit_op1_10(); /* null? */
  twobit_label( 1170, compiled_block_1_1170 );
  twobit_branchf( 1173, compiled_block_1_1173 );
  twobit_movereg( 3, 1 );
  twobit_global( 12 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1173, compiled_block_1_1173 );
  twobit_reg_op1_check_652(reg(2),1175,compiled_block_1_1175); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(1),1176,compiled_block_1_1176); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op2_58( 30 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 31 );
  twobit_op2_58( 4 ); /* cons */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_branch( 1157, compiled_block_1_1157 );
  twobit_label( 1175, compiled_block_1_1175 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 1176, compiled_block_1_1176 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_50( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1208, compiled_block_1_1208 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_57, 2, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1232, compiled_block_1_1232 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_skip( 1231, compiled_block_1_1231 );
  twobit_label( 1232, compiled_block_1_1232 );
  twobit_movereg( 1, 3 );
  twobit_global( 4 ); /* map */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* list */
  twobit_setreg( 2 );
  twobit_global( 6 ); /* apply */
  twobit_setrtn( 1233, compiled_block_1_1233 );
  twobit_invoke( 3 );
  twobit_label( 1233, compiled_block_1_1233 );
  twobit_load( 0, 0 );
  twobit_label( 1231, compiled_block_1_1231 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1208, compiled_block_1_1208 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_57( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_lexical( 1, 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1211, compiled_block_1_1211 );
  twobit_invoke( 1 );
  twobit_label( 1211, compiled_block_1_1211 );
  twobit_load( 0, 0 );
  twobit_branchf( 1213, compiled_block_1_1213 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1214, compiled_block_1_1214 );
  twobit_invoke( 5 );
  twobit_label( 1214, compiled_block_1_1214 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1215, compiled_block_1_1215 );
  twobit_invoke( 5 );
  twobit_label( 1215, compiled_block_1_1215 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 1 );
  twobit_global( 7 ); /* length */
  twobit_setrtn( 1216, compiled_block_1_1216 );
  twobit_invoke( 1 );
  twobit_label( 1216, compiled_block_1_1216 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 2 );
  twobit_global( 7 ); /* length */
  twobit_setrtn( 1217, compiled_block_1_1217 );
  twobit_invoke( 1 );
  twobit_label( 1217, compiled_block_1_1217 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_branchf_623( 4, 58, compiled_temp_1_58, 1219, compiled_block_1_1219 ); /* internal:branchf-= */
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_setrtn( 1220, compiled_block_1_1220 );
  twobit_branch( 1209, compiled_block_1_1209 );
  twobit_label( 1220, compiled_block_1_1220 );
  twobit_load( 0, 0 );
  twobit_skip( 1218, compiled_block_1_1218 );
  twobit_label( 1219, compiled_block_1_1219 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_const( 9 );
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 3 );
  twobit_global( 11 ); /* ex:syntax-violation */
  twobit_setrtn( 1221, compiled_block_1_1221 );
  twobit_invoke( 4 );
  twobit_label( 1221, compiled_block_1_1221 );
  twobit_load( 0, 0 );
  twobit_label( 1218, compiled_block_1_1218 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_lexical( 1, 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 12 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1213, compiled_block_1_1213 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 6 );
  twobit_invoke( 1 );
  twobit_label( 1209, compiled_block_1_1209 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1224, compiled_block_1_1224 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1223, compiled_block_1_1223 );
  twobit_label( 1224, compiled_block_1_1224 );
  twobit_reg( 2 );
  twobit_op1_10(); /* null? */
  twobit_label( 1223, compiled_block_1_1223 );
  twobit_branchf( 1226, compiled_block_1_1226 );
  twobit_movereg( 3, 1 );
  twobit_global( 14 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1226, compiled_block_1_1226 );
  twobit_reg_op1_check_652(reg(2),1228,compiled_block_1_1228); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(1),1229,compiled_block_1_1229); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op2_58( 30 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 31 );
  twobit_op2_58( 4 ); /* cons */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_branch( 1209, compiled_block_1_1209 );
  twobit_label( 1228, compiled_block_1_1228 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 1229, compiled_block_1_1229 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_51( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1237, compiled_block_1_1237 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1239, compiled_block_1_1239 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1241, compiled_block_1_1241 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_return();
  twobit_label( 1241, compiled_block_1_1241 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1239, compiled_block_1_1239 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1237, compiled_block_1_1237 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_52( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1271, compiled_block_1_1271 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_54, 2, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1320, compiled_block_1_1320 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_skip( 1319, compiled_block_1_1319 );
  twobit_label( 1320, compiled_block_1_1320 );
  twobit_movereg( 1, 3 );
  twobit_global( 4 ); /* map */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* list */
  twobit_setreg( 2 );
  twobit_global( 6 ); /* apply */
  twobit_setrtn( 1321, compiled_block_1_1321 );
  twobit_invoke( 3 );
  twobit_label( 1321, compiled_block_1_1321 );
  twobit_load( 0, 0 );
  twobit_label( 1319, compiled_block_1_1319 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1271, compiled_block_1_1271 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_jump( 1, 1142, compiled_block_1_1142 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_54( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_lexical( 1, 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1276, compiled_block_1_1276 );
  twobit_invoke( 1 );
  twobit_label( 1276, compiled_block_1_1276 );
  twobit_load( 0, 0 );
  twobit_branchf( 1278, compiled_block_1_1278 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1279, compiled_block_1_1279 );
  twobit_invoke( 5 );
  twobit_label( 1279, compiled_block_1_1279 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_load( 1, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_setrtn( 1280, compiled_block_1_1280 );
  twobit_branch( 1274, compiled_block_1_1274 );
  twobit_label( 1280, compiled_block_1_1280 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1281, compiled_block_1_1281 );
  twobit_invoke( 5 );
  twobit_label( 1281, compiled_block_1_1281 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 4 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1282, compiled_block_1_1282 );
  twobit_invoke( 1 );
  twobit_label( 1282, compiled_block_1_1282 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1283, compiled_block_1_1283 );
  twobit_invoke( 1 );
  twobit_label( 1283, compiled_block_1_1283 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_branchf_623( 4, 55, compiled_temp_1_55, 1285, compiled_block_1_1285 ); /* internal:branchf-= */
  twobit_load( 1, 4 );
  twobit_load( 2, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_setrtn( 1286, compiled_block_1_1286 );
  twobit_branch( 1273, compiled_block_1_1273 );
  twobit_label( 1286, compiled_block_1_1286 );
  twobit_load( 0, 0 );
  twobit_skip( 1284, compiled_block_1_1284 );
  twobit_label( 1285, compiled_block_1_1285 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_global( 10 ); /* ex:syntax-violation */
  twobit_setrtn( 1287, compiled_block_1_1287 );
  twobit_invoke( 4 );
  twobit_label( 1287, compiled_block_1_1287 );
  twobit_load( 0, 0 );
  twobit_label( 1284, compiled_block_1_1284 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1288, compiled_block_1_1288 );
  twobit_invoke( 1 );
  twobit_label( 1288, compiled_block_1_1288 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 4 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1289, compiled_block_1_1289 );
  twobit_invoke( 1 );
  twobit_label( 1289, compiled_block_1_1289 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_branchf_623( 4, 56, compiled_temp_1_56, 1291, compiled_block_1_1291 ); /* internal:branchf-= */
  twobit_load( 1, 1 );
  twobit_load( 2, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_setrtn( 1292, compiled_block_1_1292 );
  twobit_branch( 1272, compiled_block_1_1272 );
  twobit_label( 1292, compiled_block_1_1292 );
  twobit_load( 0, 0 );
  twobit_skip( 1290, compiled_block_1_1290 );
  twobit_label( 1291, compiled_block_1_1291 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_global( 10 ); /* ex:syntax-violation */
  twobit_setrtn( 1293, compiled_block_1_1293 );
  twobit_invoke( 4 );
  twobit_label( 1293, compiled_block_1_1293 );
  twobit_load( 0, 0 );
  twobit_label( 1290, compiled_block_1_1290 );
  twobit_setreg( 1 );
  twobit_load( 2, 5 );
  twobit_global( 12 ); /* append */
  twobit_setrtn( 1294, compiled_block_1_1294 );
  twobit_invoke( 2 );
  twobit_label( 1294, compiled_block_1_1294 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 1278, compiled_block_1_1278 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_pop( 8 );
  twobit_jump( 2, 1142, compiled_block_1_1142 );
  twobit_label( 1272, compiled_block_1_1272 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1297, compiled_block_1_1297 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1296, compiled_block_1_1296 );
  twobit_label( 1297, compiled_block_1_1297 );
  twobit_reg( 2 );
  twobit_op1_10(); /* null? */
  twobit_label( 1296, compiled_block_1_1296 );
  twobit_branchf( 1299, compiled_block_1_1299 );
  twobit_movereg( 3, 1 );
  twobit_global( 13 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1299, compiled_block_1_1299 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 3, 4 );
  twobit_reg_op1_check_652(reg(1),1301,compiled_block_1_1301); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg_op1_check_652(reg(2),1302,compiled_block_1_1302); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 1 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 30 );
  twobit_reg( 2 );
  twobit_op2_58( 30 ); /* cons */
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1303, compiled_block_1_1303 );
  twobit_invoke( 5 );
  twobit_label( 1303, compiled_block_1_1303 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_load( 1, 2 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_pop( 4 );
  twobit_branch( 1272, compiled_block_1_1272 );
  twobit_label( 1273, compiled_block_1_1273 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1306, compiled_block_1_1306 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1305, compiled_block_1_1305 );
  twobit_label( 1306, compiled_block_1_1306 );
  twobit_reg( 2 );
  twobit_op1_10(); /* null? */
  twobit_label( 1305, compiled_block_1_1305 );
  twobit_branchf( 1308, compiled_block_1_1308 );
  twobit_movereg( 3, 1 );
  twobit_global( 13 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1308, compiled_block_1_1308 );
  twobit_reg_op1_check_652(reg(2),1310,compiled_block_1_1310); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(1),1311,compiled_block_1_1311); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op2_58( 30 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 31 );
  twobit_op2_58( 4 ); /* cons */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_branch( 1273, compiled_block_1_1273 );
  twobit_label( 1274, compiled_block_1_1274 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1314, compiled_block_1_1314 ); /* internal:branchf-null? */
  twobit_movereg( 2, 1 );
  twobit_global( 13 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1314, compiled_block_1_1314 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 2, 4 );
  twobit_reg_op1_check_652(reg(1),1301,compiled_block_1_1301); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1316, compiled_block_1_1316 );
  twobit_invoke( 5 );
  twobit_label( 1316, compiled_block_1_1316 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1317, compiled_block_1_1317 );
  twobit_invoke( 5 );
  twobit_label( 1317, compiled_block_1_1317 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_pop( 4 );
  twobit_branch( 1274, compiled_block_1_1274 );
  twobit_label( 1310, compiled_block_1_1310 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 1301, compiled_block_1_1301 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_label( 1302, compiled_block_1_1302 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_label( 1311, compiled_block_1_1311 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_53( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1325, compiled_block_1_1325 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1327, compiled_block_1_1327 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1329, compiled_block_1_1329 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_return();
  twobit_label( 1329, compiled_block_1_1329 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1327, compiled_block_1_1327 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1325, compiled_block_1_1325 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_14( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1344, compiled_block_1_1344 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1346, compiled_block_1_1346 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_op1_branchf_610( 1348, compiled_block_1_1348 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1350, compiled_block_1_1350 ); /* internal:branchf-pair? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1351, compiled_block_1_1351 );
  twobit_invoke( 1 );
  twobit_label( 1351, compiled_block_1_1351 );
  twobit_load( 0, 0 );
  twobit_branchf( 1353, compiled_block_1_1353 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1354, compiled_block_1_1354 );
  twobit_invoke( 5 );
  twobit_label( 1354, compiled_block_1_1354 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1353, compiled_block_1_1353 );
  twobit_load( 1, 3 );
  twobit_pop( 3 );
  twobit_branch( 1341, compiled_block_1_1341 );
  twobit_label( 1350, compiled_block_1_1350 );
  twobit_branch( 1341, compiled_block_1_1341 );
  twobit_label( 1348, compiled_block_1_1348 );
  twobit_branch( 1341, compiled_block_1_1341 );
  twobit_label( 1346, compiled_block_1_1346 );
  twobit_branch( 1341, compiled_block_1_1341 );
  twobit_label( 1344, compiled_block_1_1344 );
  twobit_branch( 1341, compiled_block_1_1341 );
  twobit_label( 1340, compiled_block_1_1340 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1361, compiled_block_1_1361 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1363, compiled_block_1_1363 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1365, compiled_block_1_1365 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1367, compiled_block_1_1367 ); /* internal:branchf-pair? */
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 7 );
  twobit_store( 2, 2 );
  twobit_store( 4, 1 );
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 5 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1368, compiled_block_1_1368 );
  twobit_invoke( 1 );
  twobit_label( 1368, compiled_block_1_1368 );
  twobit_load( 0, 0 );
  twobit_branchf( 1370, compiled_block_1_1370 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1372, compiled_block_1_1372 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1373, compiled_block_1_1373 );
  twobit_invoke( 1 );
  twobit_label( 1373, compiled_block_1_1373 );
  twobit_load( 0, 0 );
  twobit_branchf( 1375, compiled_block_1_1375 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1376, compiled_block_1_1376 );
  twobit_invoke( 5 );
  twobit_label( 1376, compiled_block_1_1376 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_load( 2, 1 );
  twobit_stack( 3 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 4 );
  twobit_stack( 5 );
  twobit_op2_58( 1 ); /* cons */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 1 );
  twobit_store( 1, 4 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1377, compiled_block_1_1377 );
  twobit_invoke( 5 );
  twobit_label( 1377, compiled_block_1_1377 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1375, compiled_block_1_1375 );
  twobit_load( 1, 7 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_pop( 7 );
  twobit_invoke( 1 );
  twobit_label( 1372, compiled_block_1_1372 );
  twobit_load( 1, 7 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_pop( 7 );
  twobit_invoke( 1 );
  twobit_label( 1370, compiled_block_1_1370 );
  twobit_load( 1, 7 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_pop( 7 );
  twobit_invoke( 1 );
  twobit_label( 1367, compiled_block_1_1367 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1365, compiled_block_1_1365 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1363, compiled_block_1_1363 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1361, compiled_block_1_1361 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1341, compiled_block_1_1341 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1386, compiled_block_1_1386 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1388, compiled_block_1_1388 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1390, compiled_block_1_1390 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1392, compiled_block_1_1392 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1394, compiled_block_1_1394 ); /* internal:branchf-pair? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 3 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1395, compiled_block_1_1395 );
  twobit_invoke( 1 );
  twobit_label( 1395, compiled_block_1_1395 );
  twobit_load( 0, 0 );
  twobit_branchf( 1397, compiled_block_1_1397 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1398, compiled_block_1_1398 );
  twobit_invoke( 5 );
  twobit_label( 1398, compiled_block_1_1398 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1397, compiled_block_1_1397 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1340, compiled_block_1_1340 );
  twobit_label( 1394, compiled_block_1_1394 );
  twobit_branch( 1340, compiled_block_1_1340 );
  twobit_label( 1392, compiled_block_1_1392 );
  twobit_branch( 1340, compiled_block_1_1340 );
  twobit_label( 1390, compiled_block_1_1390 );
  twobit_branch( 1340, compiled_block_1_1340 );
  twobit_label( 1388, compiled_block_1_1388 );
  twobit_branch( 1340, compiled_block_1_1340 );
  twobit_label( 1386, compiled_block_1_1386 );
  twobit_branch( 1340, compiled_block_1_1340 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_15( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1407, compiled_block_1_1407 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1409, compiled_block_1_1409 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_lambda( compiled_start_1_43, 2, 0 );
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_44, 4, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 5 ); /* ex:map-while */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1409, compiled_block_1_1409 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1407, compiled_block_1_1407 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_43( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1411, compiled_block_1_1411 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1413, compiled_block_1_1413 ); /* internal:branchf-pair? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 4, 3 );
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1414, compiled_block_1_1414 );
  twobit_invoke( 1 );
  twobit_label( 1414, compiled_block_1_1414 );
  twobit_load( 0, 0 );
  twobit_branchf( 1416, compiled_block_1_1416 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1416, compiled_block_1_1416 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1413, compiled_block_1_1413 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1411, compiled_block_1_1411 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_44( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1418, compiled_block_1_1418 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_45, 2, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1450, compiled_block_1_1450 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_skip( 1449, compiled_block_1_1449 );
  twobit_label( 1450, compiled_block_1_1450 );
  twobit_movereg( 1, 3 );
  twobit_global( 4 ); /* map */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* list */
  twobit_setreg( 2 );
  twobit_global( 6 ); /* apply */
  twobit_setrtn( 1451, compiled_block_1_1451 );
  twobit_invoke( 3 );
  twobit_label( 1451, compiled_block_1_1451 );
  twobit_load( 0, 0 );
  twobit_label( 1449, compiled_block_1_1449 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1418, compiled_block_1_1418 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_45( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_lexical( 1, 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1422, compiled_block_1_1422 ); /* internal:branchf-pair? */
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 4 );
  twobit_store( 3, 5 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1423, compiled_block_1_1423 );
  twobit_invoke( 1 );
  twobit_label( 1423, compiled_block_1_1423 );
  twobit_load( 0, 0 );
  twobit_branchf( 1425, compiled_block_1_1425 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1426, compiled_block_1_1426 );
  twobit_invoke( 5 );
  twobit_label( 1426, compiled_block_1_1426 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 3, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_load( 1, 3 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1427, compiled_block_1_1427 );
  twobit_invoke( 1 );
  twobit_label( 1427, compiled_block_1_1427 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 4 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1428, compiled_block_1_1428 );
  twobit_invoke( 1 );
  twobit_label( 1428, compiled_block_1_1428 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 5 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1429, compiled_block_1_1429 );
  twobit_invoke( 1 );
  twobit_label( 1429, compiled_block_1_1429 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_68( 4, 46, compiled_temp_1_46 ); /* = */
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_stack( 2 );
  twobit_op2_branchf_623( 3, 47, compiled_temp_1_47, 1431, compiled_block_1_1431 ); /* internal:branchf-= */
  twobit_reg( 4 );
  twobit_skip( 1430, compiled_block_1_1430 );
  twobit_label( 1431, compiled_block_1_1431 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1430, compiled_block_1_1430 );
  twobit_branchf( 1433, compiled_block_1_1433 );
  twobit_load( 1, 3 );
  twobit_load( 2, 4 );
  twobit_load( 3, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_setrtn( 1434, compiled_block_1_1434 );
  twobit_branch( 1419, compiled_block_1_1419 );
  twobit_label( 1434, compiled_block_1_1434 );
  twobit_load( 0, 0 );
  twobit_skip( 1432, compiled_block_1_1432 );
  twobit_label( 1433, compiled_block_1_1433 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_global( 10 ); /* ex:syntax-violation */
  twobit_setrtn( 1435, compiled_block_1_1435 );
  twobit_invoke( 4 );
  twobit_label( 1435, compiled_block_1_1435 );
  twobit_load( 0, 0 );
  twobit_label( 1432, compiled_block_1_1432 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1425, compiled_block_1_1425 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 12 ); /* ex:invalid-form */
  twobit_pop( 7 );
  twobit_invoke( 1 );
  twobit_label( 1422, compiled_block_1_1422 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 12 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1419, compiled_block_1_1419 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1439, compiled_block_1_1439 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1438, compiled_block_1_1438 );
  twobit_label( 1439, compiled_block_1_1439 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1441, compiled_block_1_1441 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1438, compiled_block_1_1438 );
  twobit_label( 1441, compiled_block_1_1441 );
  twobit_reg( 3 );
  twobit_op1_10(); /* null? */
  twobit_label( 1438, compiled_block_1_1438 );
  twobit_branchf( 1443, compiled_block_1_1443 );
  twobit_movereg( 4, 1 );
  twobit_global( 13 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1443, compiled_block_1_1443 );
  twobit_reg_op1_check_652(reg(3),1445,compiled_block_1_1445); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg_op1_check_652(reg(2),1446,compiled_block_1_1446); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg_op1_check_652(reg(1),1447,compiled_block_1_1447); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 29 );
  twobit_reg( 30 );
  twobit_op2_58( 31 ); /* cons */
  twobit_setreg( 31 );
  twobit_reg( 29 );
  twobit_op2_58( 31 ); /* cons */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_branch( 1419, compiled_block_1_1419 );
  twobit_label( 1446, compiled_block_1_1446 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 1445, compiled_block_1_1445 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_label( 1447, compiled_block_1_1447 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_16( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1462, compiled_block_1_1462 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1464, compiled_block_1_1464 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_op1_branchf_610( 1466, compiled_block_1_1466 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1468, compiled_block_1_1468 ); /* internal:branchf-pair? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1469, compiled_block_1_1469 );
  twobit_invoke( 1 );
  twobit_label( 1469, compiled_block_1_1469 );
  twobit_load( 0, 0 );
  twobit_branchf( 1471, compiled_block_1_1471 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1472, compiled_block_1_1472 );
  twobit_invoke( 5 );
  twobit_label( 1472, compiled_block_1_1472 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1471, compiled_block_1_1471 );
  twobit_load( 1, 3 );
  twobit_pop( 3 );
  twobit_branch( 1459, compiled_block_1_1459 );
  twobit_label( 1468, compiled_block_1_1468 );
  twobit_branch( 1459, compiled_block_1_1459 );
  twobit_label( 1466, compiled_block_1_1466 );
  twobit_branch( 1459, compiled_block_1_1459 );
  twobit_label( 1464, compiled_block_1_1464 );
  twobit_branch( 1459, compiled_block_1_1459 );
  twobit_label( 1462, compiled_block_1_1462 );
  twobit_branch( 1459, compiled_block_1_1459 );
  twobit_label( 1458, compiled_block_1_1458 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1479, compiled_block_1_1479 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1481, compiled_block_1_1481 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1483, compiled_block_1_1483 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1485, compiled_block_1_1485 ); /* internal:branchf-pair? */
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 7 );
  twobit_store( 2, 2 );
  twobit_store( 4, 1 );
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 5 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1486, compiled_block_1_1486 );
  twobit_invoke( 1 );
  twobit_label( 1486, compiled_block_1_1486 );
  twobit_load( 0, 0 );
  twobit_branchf( 1488, compiled_block_1_1488 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1490, compiled_block_1_1490 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1491, compiled_block_1_1491 );
  twobit_invoke( 1 );
  twobit_label( 1491, compiled_block_1_1491 );
  twobit_load( 0, 0 );
  twobit_branchf( 1493, compiled_block_1_1493 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1494, compiled_block_1_1494 );
  twobit_invoke( 5 );
  twobit_label( 1494, compiled_block_1_1494 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_load( 2, 1 );
  twobit_stack( 3 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 4 );
  twobit_stack( 5 );
  twobit_op2_58( 1 ); /* cons */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 1 );
  twobit_store( 1, 4 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1495, compiled_block_1_1495 );
  twobit_invoke( 5 );
  twobit_label( 1495, compiled_block_1_1495 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1493, compiled_block_1_1493 );
  twobit_load( 1, 7 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_pop( 7 );
  twobit_invoke( 1 );
  twobit_label( 1490, compiled_block_1_1490 );
  twobit_load( 1, 7 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_pop( 7 );
  twobit_invoke( 1 );
  twobit_label( 1488, compiled_block_1_1488 );
  twobit_load( 1, 7 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_pop( 7 );
  twobit_invoke( 1 );
  twobit_label( 1485, compiled_block_1_1485 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1483, compiled_block_1_1483 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1481, compiled_block_1_1481 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1479, compiled_block_1_1479 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1459, compiled_block_1_1459 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1504, compiled_block_1_1504 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1506, compiled_block_1_1506 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1508, compiled_block_1_1508 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1510, compiled_block_1_1510 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1512, compiled_block_1_1512 ); /* internal:branchf-pair? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 2, 3 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1513, compiled_block_1_1513 );
  twobit_invoke( 1 );
  twobit_label( 1513, compiled_block_1_1513 );
  twobit_load( 0, 0 );
  twobit_branchf( 1515, compiled_block_1_1515 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1516, compiled_block_1_1516 );
  twobit_invoke( 5 );
  twobit_label( 1516, compiled_block_1_1516 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1515, compiled_block_1_1515 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1458, compiled_block_1_1458 );
  twobit_label( 1512, compiled_block_1_1512 );
  twobit_branch( 1458, compiled_block_1_1458 );
  twobit_label( 1510, compiled_block_1_1510 );
  twobit_branch( 1458, compiled_block_1_1458 );
  twobit_label( 1508, compiled_block_1_1508 );
  twobit_branch( 1458, compiled_block_1_1458 );
  twobit_label( 1506, compiled_block_1_1506 );
  twobit_branch( 1458, compiled_block_1_1458 );
  twobit_label( 1504, compiled_block_1_1504 );
  twobit_branch( 1458, compiled_block_1_1458 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_17( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1527, compiled_block_1_1527 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1529, compiled_block_1_1529 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_lambda( compiled_start_1_33, 2, 0 );
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_34, 4, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 5 ); /* ex:map-while */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1529, compiled_block_1_1529 );
  twobit_branch( 1524, compiled_block_1_1524 );
  twobit_label( 1527, compiled_block_1_1527 );
  twobit_label( 1524, compiled_block_1_1524 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1578, compiled_block_1_1578 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1580, compiled_block_1_1580 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1582, compiled_block_1_1582 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_35, 7, 3 );
  twobit_setreg( 3 );
  twobit_lambda( compiled_start_1_36, 9, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* ex:map-while */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_label( 1582, compiled_block_1_1582 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1580, compiled_block_1_1580 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1578, compiled_block_1_1578 );
  twobit_global( 10 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_33( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1531, compiled_block_1_1531 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1533, compiled_block_1_1533 ); /* internal:branchf-pair? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 4, 3 );
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1534, compiled_block_1_1534 );
  twobit_invoke( 1 );
  twobit_label( 1534, compiled_block_1_1534 );
  twobit_load( 0, 0 );
  twobit_branchf( 1536, compiled_block_1_1536 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1536, compiled_block_1_1536 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1533, compiled_block_1_1533 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1531, compiled_block_1_1531 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_34( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1538, compiled_block_1_1538 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_40, 2, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1570, compiled_block_1_1570 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_skip( 1569, compiled_block_1_1569 );
  twobit_label( 1570, compiled_block_1_1570 );
  twobit_movereg( 1, 3 );
  twobit_global( 4 ); /* map */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* list */
  twobit_setreg( 2 );
  twobit_global( 6 ); /* apply */
  twobit_setrtn( 1571, compiled_block_1_1571 );
  twobit_invoke( 3 );
  twobit_label( 1571, compiled_block_1_1571 );
  twobit_load( 0, 0 );
  twobit_label( 1569, compiled_block_1_1569 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1538, compiled_block_1_1538 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_jump( 1, 1524, compiled_block_1_1524 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_40( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_lexical( 1, 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1542, compiled_block_1_1542 ); /* internal:branchf-pair? */
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 4 );
  twobit_store( 3, 5 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1543, compiled_block_1_1543 );
  twobit_invoke( 1 );
  twobit_label( 1543, compiled_block_1_1543 );
  twobit_load( 0, 0 );
  twobit_branchf( 1545, compiled_block_1_1545 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1546, compiled_block_1_1546 );
  twobit_invoke( 5 );
  twobit_label( 1546, compiled_block_1_1546 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 3, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_load( 1, 3 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1547, compiled_block_1_1547 );
  twobit_invoke( 1 );
  twobit_label( 1547, compiled_block_1_1547 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 4 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1548, compiled_block_1_1548 );
  twobit_invoke( 1 );
  twobit_label( 1548, compiled_block_1_1548 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 5 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1549, compiled_block_1_1549 );
  twobit_invoke( 1 );
  twobit_label( 1549, compiled_block_1_1549 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_68( 4, 41, compiled_temp_1_41 ); /* = */
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_stack( 2 );
  twobit_op2_branchf_623( 3, 42, compiled_temp_1_42, 1551, compiled_block_1_1551 ); /* internal:branchf-= */
  twobit_reg( 4 );
  twobit_skip( 1550, compiled_block_1_1550 );
  twobit_label( 1551, compiled_block_1_1551 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1550, compiled_block_1_1550 );
  twobit_branchf( 1553, compiled_block_1_1553 );
  twobit_load( 1, 3 );
  twobit_load( 2, 4 );
  twobit_load( 3, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_setrtn( 1554, compiled_block_1_1554 );
  twobit_branch( 1539, compiled_block_1_1539 );
  twobit_label( 1554, compiled_block_1_1554 );
  twobit_load( 0, 0 );
  twobit_skip( 1552, compiled_block_1_1552 );
  twobit_label( 1553, compiled_block_1_1553 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_global( 10 ); /* ex:syntax-violation */
  twobit_setrtn( 1555, compiled_block_1_1555 );
  twobit_invoke( 4 );
  twobit_label( 1555, compiled_block_1_1555 );
  twobit_load( 0, 0 );
  twobit_label( 1552, compiled_block_1_1552 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1545, compiled_block_1_1545 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_pop( 7 );
  twobit_jump( 2, 1524, compiled_block_1_1524 );
  twobit_label( 1542, compiled_block_1_1542 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_jump( 2, 1524, compiled_block_1_1524 );
  twobit_label( 1539, compiled_block_1_1539 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1559, compiled_block_1_1559 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1558, compiled_block_1_1558 );
  twobit_label( 1559, compiled_block_1_1559 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1561, compiled_block_1_1561 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1558, compiled_block_1_1558 );
  twobit_label( 1561, compiled_block_1_1561 );
  twobit_reg( 3 );
  twobit_op1_10(); /* null? */
  twobit_label( 1558, compiled_block_1_1558 );
  twobit_branchf( 1563, compiled_block_1_1563 );
  twobit_movereg( 4, 1 );
  twobit_global( 12 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1563, compiled_block_1_1563 );
  twobit_reg_op1_check_652(reg(3),1565,compiled_block_1_1565); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg_op1_check_652(reg(2),1566,compiled_block_1_1566); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg_op1_check_652(reg(1),1567,compiled_block_1_1567); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 29 );
  twobit_reg( 30 );
  twobit_op2_58( 31 ); /* cons */
  twobit_setreg( 31 );
  twobit_reg( 29 );
  twobit_op2_58( 31 ); /* cons */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_branch( 1539, compiled_block_1_1539 );
  twobit_label( 1566, compiled_block_1_1566 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 1565, compiled_block_1_1565 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_label( 1567, compiled_block_1_1567 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_35( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1584, compiled_block_1_1584 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_37, 2, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1616, compiled_block_1_1616 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_skip( 1615, compiled_block_1_1615 );
  twobit_label( 1616, compiled_block_1_1616 );
  twobit_movereg( 1, 3 );
  twobit_global( 4 ); /* map */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* list */
  twobit_setreg( 2 );
  twobit_global( 6 ); /* apply */
  twobit_setrtn( 1617, compiled_block_1_1617 );
  twobit_invoke( 3 );
  twobit_label( 1617, compiled_block_1_1617 );
  twobit_load( 0, 0 );
  twobit_label( 1615, compiled_block_1_1615 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1584, compiled_block_1_1584 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_37( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_lexical( 1, 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1588, compiled_block_1_1588 ); /* internal:branchf-pair? */
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 4 );
  twobit_store( 3, 5 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1589, compiled_block_1_1589 );
  twobit_invoke( 1 );
  twobit_label( 1589, compiled_block_1_1589 );
  twobit_load( 0, 0 );
  twobit_branchf( 1591, compiled_block_1_1591 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1592, compiled_block_1_1592 );
  twobit_invoke( 5 );
  twobit_label( 1592, compiled_block_1_1592 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 3, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_load( 1, 3 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1593, compiled_block_1_1593 );
  twobit_invoke( 1 );
  twobit_label( 1593, compiled_block_1_1593 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 4 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1594, compiled_block_1_1594 );
  twobit_invoke( 1 );
  twobit_label( 1594, compiled_block_1_1594 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 5 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1595, compiled_block_1_1595 );
  twobit_invoke( 1 );
  twobit_label( 1595, compiled_block_1_1595 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_68( 4, 38, compiled_temp_1_38 ); /* = */
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_stack( 2 );
  twobit_op2_branchf_623( 3, 39, compiled_temp_1_39, 1597, compiled_block_1_1597 ); /* internal:branchf-= */
  twobit_reg( 4 );
  twobit_skip( 1596, compiled_block_1_1596 );
  twobit_label( 1597, compiled_block_1_1597 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1596, compiled_block_1_1596 );
  twobit_branchf( 1599, compiled_block_1_1599 );
  twobit_load( 1, 3 );
  twobit_load( 2, 4 );
  twobit_load( 3, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_setrtn( 1600, compiled_block_1_1600 );
  twobit_branch( 1585, compiled_block_1_1585 );
  twobit_label( 1600, compiled_block_1_1600 );
  twobit_load( 0, 0 );
  twobit_skip( 1598, compiled_block_1_1598 );
  twobit_label( 1599, compiled_block_1_1599 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_global( 10 ); /* ex:syntax-violation */
  twobit_setrtn( 1601, compiled_block_1_1601 );
  twobit_invoke( 4 );
  twobit_label( 1601, compiled_block_1_1601 );
  twobit_load( 0, 0 );
  twobit_label( 1598, compiled_block_1_1598 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_lexical( 1, 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1591, compiled_block_1_1591 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_pop( 7 );
  twobit_invoke( 1 );
  twobit_label( 1588, compiled_block_1_1588 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1585, compiled_block_1_1585 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1605, compiled_block_1_1605 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1604, compiled_block_1_1604 );
  twobit_label( 1605, compiled_block_1_1605 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1607, compiled_block_1_1607 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1604, compiled_block_1_1604 );
  twobit_label( 1607, compiled_block_1_1607 );
  twobit_reg( 3 );
  twobit_op1_10(); /* null? */
  twobit_label( 1604, compiled_block_1_1604 );
  twobit_branchf( 1609, compiled_block_1_1609 );
  twobit_movereg( 4, 1 );
  twobit_global( 12 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1609, compiled_block_1_1609 );
  twobit_reg_op1_check_652(reg(3),1611,compiled_block_1_1611); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg_op1_check_652(reg(2),1612,compiled_block_1_1612); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg_op1_check_652(reg(1),1613,compiled_block_1_1613); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 29 );
  twobit_reg( 30 );
  twobit_op2_58( 31 ); /* cons */
  twobit_setreg( 31 );
  twobit_reg( 29 );
  twobit_op2_58( 31 ); /* cons */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_branch( 1585, compiled_block_1_1585 );
  twobit_label( 1612, compiled_block_1_1612 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 1611, compiled_block_1_1611 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_label( 1613, compiled_block_1_1613 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_36( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1621, compiled_block_1_1621 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1623, compiled_block_1_1623 ); /* internal:branchf-pair? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 4, 3 );
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1624, compiled_block_1_1624 );
  twobit_invoke( 1 );
  twobit_label( 1624, compiled_block_1_1624 );
  twobit_load( 0, 0 );
  twobit_branchf( 1626, compiled_block_1_1626 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1626, compiled_block_1_1626 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1623, compiled_block_1_1623 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1621, compiled_block_1_1621 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_18( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1653, compiled_block_1_1653 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1655, compiled_block_1_1655 ); /* internal:branchf-pair? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_const( 1 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1656, compiled_block_1_1656 );
  twobit_invoke( 2 );
  twobit_label( 1656, compiled_block_1_1656 );
  twobit_load( 0, 0 );
  twobit_branchf( 1658, compiled_block_1_1658 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1660, compiled_block_1_1660 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1662, compiled_block_1_1662 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 1663, compiled_block_1_1663 );
  twobit_invoke( 1 );
  twobit_label( 1663, compiled_block_1_1663 );
  twobit_load( 0, 0 );
  twobit_branchf( 1665, compiled_block_1_1665 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1667, compiled_block_1_1667 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1669, compiled_block_1_1669 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1671, compiled_block_1_1671 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_op1_branchf_610( 1673, compiled_block_1_1673 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1675, compiled_block_1_1675 ); /* internal:branchf-null? */
  twobit_load( 4, 2 );
  twobit_reg( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 1676, compiled_block_1_1676 );
  twobit_invoke( 5 );
  twobit_label( 1676, compiled_block_1_1676 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1675, compiled_block_1_1675 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1650, compiled_block_1_1650 );
  twobit_label( 1673, compiled_block_1_1673 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1650, compiled_block_1_1650 );
  twobit_label( 1671, compiled_block_1_1671 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1650, compiled_block_1_1650 );
  twobit_label( 1669, compiled_block_1_1669 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1650, compiled_block_1_1650 );
  twobit_label( 1667, compiled_block_1_1667 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1650, compiled_block_1_1650 );
  twobit_label( 1665, compiled_block_1_1665 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1650, compiled_block_1_1650 );
  twobit_label( 1662, compiled_block_1_1662 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1650, compiled_block_1_1650 );
  twobit_label( 1660, compiled_block_1_1660 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1650, compiled_block_1_1650 );
  twobit_label( 1658, compiled_block_1_1658 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 1650, compiled_block_1_1650 );
  twobit_label( 1655, compiled_block_1_1655 );
  twobit_branch( 1650, compiled_block_1_1650 );
  twobit_label( 1653, compiled_block_1_1653 );
  twobit_branch( 1650, compiled_block_1_1650 );
  twobit_label( 1632, compiled_block_1_1632 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1689, compiled_block_1_1689 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1691, compiled_block_1_1691 ); /* internal:branchf-pair? */
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 8 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_const( 9 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1692, compiled_block_1_1692 );
  twobit_invoke( 2 );
  twobit_label( 1692, compiled_block_1_1692 );
  twobit_load( 0, 0 );
  twobit_branchf( 1694, compiled_block_1_1694 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1696, compiled_block_1_1696 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1698, compiled_block_1_1698 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1700, compiled_block_1_1700 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1702, compiled_block_1_1702 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1704, compiled_block_1_1704 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1706, compiled_block_1_1706 ); /* internal:branchf-null? */
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 1707, compiled_block_1_1707 );
  twobit_invoke( 1 );
  twobit_label( 1707, compiled_block_1_1707 );
  twobit_load( 0, 0 );
  twobit_branchf( 1709, compiled_block_1_1709 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 1710, compiled_block_1_1710 );
  twobit_invoke( 5 );
  twobit_label( 1710, compiled_block_1_1710 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 1711, compiled_block_1_1711 );
  twobit_invoke( 5 );
  twobit_label( 1711, compiled_block_1_1711 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 1712, compiled_block_1_1712 );
  twobit_invoke( 5 );
  twobit_label( 1712, compiled_block_1_1712 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 3, 1 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 11 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 1713, compiled_block_1_1713 );
  twobit_invoke( 5 );
  twobit_label( 1713, compiled_block_1_1713 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 1709, compiled_block_1_1709 );
  twobit_load( 1, 8 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 1706, compiled_block_1_1706 );
  twobit_load( 1, 8 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 1704, compiled_block_1_1704 );
  twobit_load( 1, 8 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 1702, compiled_block_1_1702 );
  twobit_load( 1, 8 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 1700, compiled_block_1_1700 );
  twobit_load( 1, 8 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 1698, compiled_block_1_1698 );
  twobit_load( 1, 8 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 1696, compiled_block_1_1696 );
  twobit_load( 1, 8 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 1694, compiled_block_1_1694 );
  twobit_load( 1, 8 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 1691, compiled_block_1_1691 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1689, compiled_block_1_1689 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1633, compiled_block_1_1633 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1725, compiled_block_1_1725 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1727, compiled_block_1_1727 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_const( 9 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1728, compiled_block_1_1728 );
  twobit_invoke( 2 );
  twobit_label( 1728, compiled_block_1_1728 );
  twobit_load( 0, 0 );
  twobit_branchf( 1730, compiled_block_1_1730 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1732, compiled_block_1_1732 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_25, 15, 2 );
  twobit_setreg( 3 );
  twobit_lambda( compiled_start_1_26, 17, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 18 ); /* ex:map-while */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1732, compiled_block_1_1732 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 1632, compiled_block_1_1632 );
  twobit_label( 1730, compiled_block_1_1730 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 1632, compiled_block_1_1632 );
  twobit_label( 1727, compiled_block_1_1727 );
  twobit_branch( 1632, compiled_block_1_1632 );
  twobit_label( 1725, compiled_block_1_1725 );
  twobit_branch( 1632, compiled_block_1_1632 );
  twobit_label( 1634, compiled_block_1_1634 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1782, compiled_block_1_1782 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1784, compiled_block_1_1784 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_const( 4 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1785, compiled_block_1_1785 );
  twobit_invoke( 2 );
  twobit_label( 1785, compiled_block_1_1785 );
  twobit_load( 0, 0 );
  twobit_branchf( 1787, compiled_block_1_1787 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1789, compiled_block_1_1789 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1790, compiled_block_1_1790 );
  twobit_invoke( 2 );
  twobit_label( 1790, compiled_block_1_1790 );
  twobit_load( 0, 0 );
  twobit_branchf( 1792, compiled_block_1_1792 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1794, compiled_block_1_1794 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_27, 20, 2 );
  twobit_setreg( 3 );
  twobit_lambda( compiled_start_1_28, 22, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 18 ); /* ex:map-while */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1794, compiled_block_1_1794 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 1633, compiled_block_1_1633 );
  twobit_label( 1792, compiled_block_1_1792 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 1633, compiled_block_1_1633 );
  twobit_label( 1789, compiled_block_1_1789 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 1633, compiled_block_1_1633 );
  twobit_label( 1787, compiled_block_1_1787 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 1633, compiled_block_1_1633 );
  twobit_label( 1784, compiled_block_1_1784 );
  twobit_branch( 1633, compiled_block_1_1633 );
  twobit_label( 1782, compiled_block_1_1782 );
  twobit_branch( 1633, compiled_block_1_1633 );
  twobit_label( 1635, compiled_block_1_1635 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1849, compiled_block_1_1849 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1851, compiled_block_1_1851 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_const( 4 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1852, compiled_block_1_1852 );
  twobit_invoke( 2 );
  twobit_label( 1852, compiled_block_1_1852 );
  twobit_load( 0, 0 );
  twobit_branchf( 1854, compiled_block_1_1854 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1856, compiled_block_1_1856 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1857, compiled_block_1_1857 );
  twobit_invoke( 2 );
  twobit_label( 1857, compiled_block_1_1857 );
  twobit_load( 0, 0 );
  twobit_branchf( 1859, compiled_block_1_1859 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1861, compiled_block_1_1861 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1863, compiled_block_1_1863 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1865, compiled_block_1_1865 ); /* internal:branchf-null? */
  twobit_reg( 3 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 23 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 24 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 1866, compiled_block_1_1866 );
  twobit_invoke( 5 );
  twobit_label( 1866, compiled_block_1_1866 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1865, compiled_block_1_1865 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 1634, compiled_block_1_1634 );
  twobit_label( 1863, compiled_block_1_1863 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 1634, compiled_block_1_1634 );
  twobit_label( 1861, compiled_block_1_1861 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 1634, compiled_block_1_1634 );
  twobit_label( 1859, compiled_block_1_1859 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 1634, compiled_block_1_1634 );
  twobit_label( 1856, compiled_block_1_1856 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 1634, compiled_block_1_1634 );
  twobit_label( 1854, compiled_block_1_1854 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 1634, compiled_block_1_1634 );
  twobit_label( 1851, compiled_block_1_1851 );
  twobit_branch( 1634, compiled_block_1_1634 );
  twobit_label( 1849, compiled_block_1_1849 );
  twobit_branch( 1634, compiled_block_1_1634 );
  twobit_label( 1636, compiled_block_1_1636 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1876, compiled_block_1_1876 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1878, compiled_block_1_1878 ); /* internal:branchf-pair? */
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 8 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_const( 4 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1879, compiled_block_1_1879 );
  twobit_invoke( 2 );
  twobit_label( 1879, compiled_block_1_1879 );
  twobit_load( 0, 0 );
  twobit_branchf( 1881, compiled_block_1_1881 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1883, compiled_block_1_1883 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1884, compiled_block_1_1884 );
  twobit_invoke( 2 );
  twobit_label( 1884, compiled_block_1_1884 );
  twobit_load( 0, 0 );
  twobit_branchf( 1886, compiled_block_1_1886 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1888, compiled_block_1_1888 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1890, compiled_block_1_1890 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1892, compiled_block_1_1892 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1894, compiled_block_1_1894 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1896, compiled_block_1_1896 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1898, compiled_block_1_1898 ); /* internal:branchf-null? */
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 1899, compiled_block_1_1899 );
  twobit_invoke( 1 );
  twobit_label( 1899, compiled_block_1_1899 );
  twobit_load( 0, 0 );
  twobit_branchf( 1901, compiled_block_1_1901 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 25 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 1902, compiled_block_1_1902 );
  twobit_invoke( 5 );
  twobit_label( 1902, compiled_block_1_1902 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 25 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 1903, compiled_block_1_1903 );
  twobit_invoke( 5 );
  twobit_label( 1903, compiled_block_1_1903 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 12 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 25 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 1904, compiled_block_1_1904 );
  twobit_invoke( 5 );
  twobit_label( 1904, compiled_block_1_1904 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 3, 1 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 25 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 1905, compiled_block_1_1905 );
  twobit_invoke( 5 );
  twobit_label( 1905, compiled_block_1_1905 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 1901, compiled_block_1_1901 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1635, compiled_block_1_1635 );
  twobit_label( 1898, compiled_block_1_1898 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1635, compiled_block_1_1635 );
  twobit_label( 1896, compiled_block_1_1896 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1635, compiled_block_1_1635 );
  twobit_label( 1894, compiled_block_1_1894 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1635, compiled_block_1_1635 );
  twobit_label( 1892, compiled_block_1_1892 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1635, compiled_block_1_1635 );
  twobit_label( 1890, compiled_block_1_1890 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1635, compiled_block_1_1635 );
  twobit_label( 1888, compiled_block_1_1888 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1635, compiled_block_1_1635 );
  twobit_label( 1886, compiled_block_1_1886 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1635, compiled_block_1_1635 );
  twobit_label( 1883, compiled_block_1_1883 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1635, compiled_block_1_1635 );
  twobit_label( 1881, compiled_block_1_1881 );
  twobit_load( 1, 8 );
  twobit_pop( 8 );
  twobit_branch( 1635, compiled_block_1_1635 );
  twobit_label( 1878, compiled_block_1_1878 );
  twobit_branch( 1635, compiled_block_1_1635 );
  twobit_label( 1876, compiled_block_1_1876 );
  twobit_branch( 1635, compiled_block_1_1635 );
  twobit_label( 1637, compiled_block_1_1637 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1919, compiled_block_1_1919 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1921, compiled_block_1_1921 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_const( 4 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1922, compiled_block_1_1922 );
  twobit_invoke( 2 );
  twobit_label( 1922, compiled_block_1_1922 );
  twobit_load( 0, 0 );
  twobit_branchf( 1924, compiled_block_1_1924 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1926, compiled_block_1_1926 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1927, compiled_block_1_1927 );
  twobit_invoke( 2 );
  twobit_label( 1927, compiled_block_1_1927 );
  twobit_load( 0, 0 );
  twobit_branchf( 1929, compiled_block_1_1929 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1931, compiled_block_1_1931 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1933, compiled_block_1_1933 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1935, compiled_block_1_1935 ); /* internal:branchf-null? */
  twobit_reg( 3 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 26 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 27 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 1936, compiled_block_1_1936 );
  twobit_invoke( 5 );
  twobit_label( 1936, compiled_block_1_1936 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1935, compiled_block_1_1935 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 1636, compiled_block_1_1636 );
  twobit_label( 1933, compiled_block_1_1933 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 1636, compiled_block_1_1636 );
  twobit_label( 1931, compiled_block_1_1931 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 1636, compiled_block_1_1636 );
  twobit_label( 1929, compiled_block_1_1929 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 1636, compiled_block_1_1636 );
  twobit_label( 1926, compiled_block_1_1926 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 1636, compiled_block_1_1636 );
  twobit_label( 1924, compiled_block_1_1924 );
  twobit_load( 1, 2 );
  twobit_pop( 2 );
  twobit_branch( 1636, compiled_block_1_1636 );
  twobit_label( 1921, compiled_block_1_1921 );
  twobit_branch( 1636, compiled_block_1_1636 );
  twobit_label( 1919, compiled_block_1_1919 );
  twobit_branch( 1636, compiled_block_1_1636 );
  twobit_label( 1638, compiled_block_1_1638 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1946, compiled_block_1_1946 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1948, compiled_block_1_1948 ); /* internal:branchf-pair? */
  twobit_save( 11 );
  twobit_store( 0, 0 );
  twobit_store( 1, 11 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_const( 28 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1949, compiled_block_1_1949 );
  twobit_invoke( 2 );
  twobit_label( 1949, compiled_block_1_1949 );
  twobit_load( 0, 0 );
  twobit_branchf( 1951, compiled_block_1_1951 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1953, compiled_block_1_1953 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 10 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1955, compiled_block_1_1955 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 9 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1957, compiled_block_1_1957 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 8 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1959, compiled_block_1_1959 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1961, compiled_block_1_1961 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1963, compiled_block_1_1963 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_movereg( 4, 1 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 1964, compiled_block_1_1964 );
  twobit_invoke( 1 );
  twobit_label( 1964, compiled_block_1_1964 );
  twobit_load( 0, 0 );
  twobit_branchf( 1966, compiled_block_1_1966 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1968, compiled_block_1_1968 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1970, compiled_block_1_1970 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 4 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1972, compiled_block_1_1972 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 3 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_movereg( 3, 1 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 1973, compiled_block_1_1973 );
  twobit_invoke( 1 );
  twobit_label( 1973, compiled_block_1_1973 );
  twobit_load( 0, 0 );
  twobit_branchf( 1975, compiled_block_1_1975 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1977, compiled_block_1_1977 ); /* internal:branchf-null? */
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 29 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 1978, compiled_block_1_1978 );
  twobit_invoke( 5 );
  twobit_label( 1978, compiled_block_1_1978 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 3, 2 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 2 ); /* () */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 4 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 5 );
  twobit_global( 30 ); /* append */
  twobit_setrtn( 1979, compiled_block_1_1979 );
  twobit_invoke( 2 );
  twobit_label( 1979, compiled_block_1_1979 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 28 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 11 );
  twobit_return();
  twobit_label( 1977, compiled_block_1_1977 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1637, compiled_block_1_1637 );
  twobit_label( 1975, compiled_block_1_1975 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1637, compiled_block_1_1637 );
  twobit_label( 1972, compiled_block_1_1972 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1637, compiled_block_1_1637 );
  twobit_label( 1970, compiled_block_1_1970 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1637, compiled_block_1_1637 );
  twobit_label( 1968, compiled_block_1_1968 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1637, compiled_block_1_1637 );
  twobit_label( 1966, compiled_block_1_1966 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1637, compiled_block_1_1637 );
  twobit_label( 1963, compiled_block_1_1963 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1637, compiled_block_1_1637 );
  twobit_label( 1961, compiled_block_1_1961 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1637, compiled_block_1_1637 );
  twobit_label( 1959, compiled_block_1_1959 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1637, compiled_block_1_1637 );
  twobit_label( 1957, compiled_block_1_1957 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1637, compiled_block_1_1637 );
  twobit_label( 1955, compiled_block_1_1955 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1637, compiled_block_1_1637 );
  twobit_label( 1953, compiled_block_1_1953 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1637, compiled_block_1_1637 );
  twobit_label( 1951, compiled_block_1_1951 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1637, compiled_block_1_1637 );
  twobit_label( 1948, compiled_block_1_1948 );
  twobit_branch( 1637, compiled_block_1_1637 );
  twobit_label( 1946, compiled_block_1_1946 );
  twobit_branch( 1637, compiled_block_1_1637 );
  twobit_label( 1639, compiled_block_1_1639 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1996, compiled_block_1_1996 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1998, compiled_block_1_1998 ); /* internal:branchf-pair? */
  twobit_save( 9 );
  twobit_store( 0, 0 );
  twobit_store( 1, 9 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_const( 28 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 1999, compiled_block_1_1999 );
  twobit_invoke( 2 );
  twobit_label( 1999, compiled_block_1_1999 );
  twobit_load( 0, 0 );
  twobit_branchf( 2001, compiled_block_1_2001 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2003, compiled_block_1_2003 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 7 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2005, compiled_block_1_2005 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 6 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2007, compiled_block_1_2007 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 5 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2009, compiled_block_1_2009 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2011, compiled_block_1_2011 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_movereg( 4, 1 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 2012, compiled_block_1_2012 );
  twobit_invoke( 1 );
  twobit_label( 2012, compiled_block_1_2012 );
  twobit_load( 0, 0 );
  twobit_branchf( 2014, compiled_block_1_2014 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2016, compiled_block_1_2016 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_movereg( 3, 1 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 2017, compiled_block_1_2017 );
  twobit_invoke( 1 );
  twobit_label( 2017, compiled_block_1_2017 );
  twobit_load( 0, 0 );
  twobit_branchf( 2019, compiled_block_1_2019 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2021, compiled_block_1_2021 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 2023, compiled_block_1_2023 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2025, compiled_block_1_2025 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2027, compiled_block_1_2027 ); /* internal:branchf-null? */
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 31 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2028, compiled_block_1_2028 );
  twobit_invoke( 5 );
  twobit_label( 2028, compiled_block_1_2028 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 32 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 31 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2029, compiled_block_1_2029 );
  twobit_invoke( 5 );
  twobit_label( 2029, compiled_block_1_2029 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 9 );
  twobit_return();
  twobit_label( 2027, compiled_block_1_2027 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1638, compiled_block_1_1638 );
  twobit_label( 2025, compiled_block_1_2025 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1638, compiled_block_1_1638 );
  twobit_label( 2023, compiled_block_1_2023 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1638, compiled_block_1_1638 );
  twobit_label( 2021, compiled_block_1_2021 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1638, compiled_block_1_1638 );
  twobit_label( 2019, compiled_block_1_2019 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1638, compiled_block_1_1638 );
  twobit_label( 2016, compiled_block_1_2016 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1638, compiled_block_1_1638 );
  twobit_label( 2014, compiled_block_1_2014 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1638, compiled_block_1_1638 );
  twobit_label( 2011, compiled_block_1_2011 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1638, compiled_block_1_1638 );
  twobit_label( 2009, compiled_block_1_2009 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1638, compiled_block_1_1638 );
  twobit_label( 2007, compiled_block_1_2007 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1638, compiled_block_1_1638 );
  twobit_label( 2005, compiled_block_1_2005 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1638, compiled_block_1_1638 );
  twobit_label( 2003, compiled_block_1_2003 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1638, compiled_block_1_1638 );
  twobit_label( 2001, compiled_block_1_2001 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1638, compiled_block_1_1638 );
  twobit_label( 1998, compiled_block_1_1998 );
  twobit_branch( 1638, compiled_block_1_1638 );
  twobit_label( 1996, compiled_block_1_1996 );
  twobit_branch( 1638, compiled_block_1_1638 );
  twobit_label( 1640, compiled_block_1_1640 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2046, compiled_block_1_2046 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2048, compiled_block_1_2048 ); /* internal:branchf-pair? */
  twobit_save( 10 );
  twobit_store( 0, 0 );
  twobit_store( 1, 10 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_const( 33 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 2049, compiled_block_1_2049 );
  twobit_invoke( 2 );
  twobit_label( 2049, compiled_block_1_2049 );
  twobit_load( 0, 0 );
  twobit_branchf( 2051, compiled_block_1_2051 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2053, compiled_block_1_2053 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 9 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2055, compiled_block_1_2055 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 5 );
  twobit_movereg( 2, 1 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 2056, compiled_block_1_2056 );
  twobit_invoke( 1 );
  twobit_label( 2056, compiled_block_1_2056 );
  twobit_load( 0, 0 );
  twobit_branchf( 2058, compiled_block_1_2058 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2060, compiled_block_1_2060 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 8 );
  twobit_movereg( 3, 1 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 2061, compiled_block_1_2061 );
  twobit_invoke( 1 );
  twobit_label( 2061, compiled_block_1_2061 );
  twobit_load( 0, 0 );
  twobit_branchf( 2063, compiled_block_1_2063 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2065, compiled_block_1_2065 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 7 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2067, compiled_block_1_2067 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 6 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2069, compiled_block_1_2069 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2071, compiled_block_1_2071 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2073, compiled_block_1_2073 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_op1_branchf_610( 2075, compiled_block_1_2075 ); /* internal:branchf-null? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2077, compiled_block_1_2077 ); /* internal:branchf-null? */
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 3 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2079, compiled_block_1_2079 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2081, compiled_block_1_2081 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 34 ); /* ex:identifier? */
  twobit_setrtn( 2082, compiled_block_1_2082 );
  twobit_invoke( 1 );
  twobit_label( 2082, compiled_block_1_2082 );
  twobit_load( 0, 0 );
  twobit_branchf( 2084, compiled_block_1_2084 );
  twobit_const( 32 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 35 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2085, compiled_block_1_2085 );
  twobit_invoke( 5 );
  twobit_label( 2085, compiled_block_1_2085 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 36 ); /* ex:free-identifier=? */
  twobit_setrtn( 2086, compiled_block_1_2086 );
  twobit_invoke( 2 );
  twobit_label( 2086, compiled_block_1_2086 );
  twobit_load( 0, 0 );
  twobit_skip( 2083, compiled_block_1_2083 );
  twobit_label( 2084, compiled_block_1_2084 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2083, compiled_block_1_2083 );
  twobit_branchf( 2088, compiled_block_1_2088 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2090, compiled_block_1_2090 ); /* internal:branchf-null? */
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 35 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2091, compiled_block_1_2091 );
  twobit_invoke( 5 );
  twobit_label( 2091, compiled_block_1_2091 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 37 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 35 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2092, compiled_block_1_2092 );
  twobit_invoke( 5 );
  twobit_label( 2092, compiled_block_1_2092 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 5 );
  twobit_global( 30 ); /* append */
  twobit_setrtn( 2093, compiled_block_1_2093 );
  twobit_invoke( 2 );
  twobit_label( 2093, compiled_block_1_2093 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 7 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 7 );
  twobit_const( 37 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 35 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2094, compiled_block_1_2094 );
  twobit_invoke( 5 );
  twobit_label( 2094, compiled_block_1_2094 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 8 );
  twobit_global( 30 ); /* append */
  twobit_setrtn( 2095, compiled_block_1_2095 );
  twobit_invoke( 2 );
  twobit_label( 2095, compiled_block_1_2095 );
  twobit_load( 0, 0 );
  twobit_load( 3, 7 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 10 );
  twobit_return();
  twobit_label( 2090, compiled_block_1_2090 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1639, compiled_block_1_1639 );
  twobit_label( 2088, compiled_block_1_2088 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1639, compiled_block_1_1639 );
  twobit_label( 2081, compiled_block_1_2081 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1639, compiled_block_1_1639 );
  twobit_label( 2079, compiled_block_1_2079 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1639, compiled_block_1_1639 );
  twobit_label( 2077, compiled_block_1_2077 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1639, compiled_block_1_1639 );
  twobit_label( 2075, compiled_block_1_2075 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1639, compiled_block_1_1639 );
  twobit_label( 2073, compiled_block_1_2073 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1639, compiled_block_1_1639 );
  twobit_label( 2071, compiled_block_1_2071 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1639, compiled_block_1_1639 );
  twobit_label( 2069, compiled_block_1_2069 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1639, compiled_block_1_1639 );
  twobit_label( 2067, compiled_block_1_2067 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1639, compiled_block_1_1639 );
  twobit_label( 2065, compiled_block_1_2065 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1639, compiled_block_1_1639 );
  twobit_label( 2063, compiled_block_1_2063 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1639, compiled_block_1_1639 );
  twobit_label( 2060, compiled_block_1_2060 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1639, compiled_block_1_1639 );
  twobit_label( 2058, compiled_block_1_2058 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1639, compiled_block_1_1639 );
  twobit_label( 2055, compiled_block_1_2055 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1639, compiled_block_1_1639 );
  twobit_label( 2053, compiled_block_1_2053 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1639, compiled_block_1_1639 );
  twobit_label( 2051, compiled_block_1_2051 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1639, compiled_block_1_1639 );
  twobit_label( 2048, compiled_block_1_2048 );
  twobit_branch( 1639, compiled_block_1_1639 );
  twobit_label( 2046, compiled_block_1_2046 );
  twobit_branch( 1639, compiled_block_1_1639 );
  twobit_label( 1641, compiled_block_1_1641 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2116, compiled_block_1_2116 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2118, compiled_block_1_2118 ); /* internal:branchf-pair? */
  twobit_save( 12 );
  twobit_store( 0, 0 );
  twobit_store( 1, 12 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_const( 33 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 2119, compiled_block_1_2119 );
  twobit_invoke( 2 );
  twobit_label( 2119, compiled_block_1_2119 );
  twobit_load( 0, 0 );
  twobit_branchf( 2121, compiled_block_1_2121 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2123, compiled_block_1_2123 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 10 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2125, compiled_block_1_2125 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 6 );
  twobit_movereg( 2, 1 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 2126, compiled_block_1_2126 );
  twobit_invoke( 1 );
  twobit_label( 2126, compiled_block_1_2126 );
  twobit_load( 0, 0 );
  twobit_branchf( 2128, compiled_block_1_2128 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2130, compiled_block_1_2130 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 9 );
  twobit_movereg( 3, 1 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 2131, compiled_block_1_2131 );
  twobit_invoke( 1 );
  twobit_label( 2131, compiled_block_1_2131 );
  twobit_load( 0, 0 );
  twobit_branchf( 2133, compiled_block_1_2133 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2135, compiled_block_1_2135 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 8 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2137, compiled_block_1_2137 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 7 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2139, compiled_block_1_2139 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2141, compiled_block_1_2141 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2143, compiled_block_1_2143 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_movereg( 4, 1 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 2144, compiled_block_1_2144 );
  twobit_invoke( 1 );
  twobit_label( 2144, compiled_block_1_2144 );
  twobit_load( 0, 0 );
  twobit_branchf( 2146, compiled_block_1_2146 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2148, compiled_block_1_2148 ); /* internal:branchf-null? */
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2150, compiled_block_1_2150 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 2152, compiled_block_1_2152 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 34 ); /* ex:identifier? */
  twobit_setrtn( 2153, compiled_block_1_2153 );
  twobit_invoke( 1 );
  twobit_label( 2153, compiled_block_1_2153 );
  twobit_load( 0, 0 );
  twobit_branchf( 2155, compiled_block_1_2155 );
  twobit_const( 32 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 38 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2156, compiled_block_1_2156 );
  twobit_invoke( 5 );
  twobit_label( 2156, compiled_block_1_2156 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 36 ); /* ex:free-identifier=? */
  twobit_setrtn( 2157, compiled_block_1_2157 );
  twobit_invoke( 2 );
  twobit_label( 2157, compiled_block_1_2157 );
  twobit_load( 0, 0 );
  twobit_skip( 2154, compiled_block_1_2154 );
  twobit_label( 2155, compiled_block_1_2155 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2154, compiled_block_1_2154 );
  twobit_branchf( 2159, compiled_block_1_2159 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2161, compiled_block_1_2161 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2163, compiled_block_1_2163 ); /* internal:branchf-null? */
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 38 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2164, compiled_block_1_2164 );
  twobit_invoke( 5 );
  twobit_label( 2164, compiled_block_1_2164 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_const( 39 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 38 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2165, compiled_block_1_2165 );
  twobit_invoke( 5 );
  twobit_label( 2165, compiled_block_1_2165 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 37 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 38 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2166, compiled_block_1_2166 );
  twobit_invoke( 5 );
  twobit_label( 2166, compiled_block_1_2166 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 4 );
  twobit_global( 30 ); /* append */
  twobit_setrtn( 2167, compiled_block_1_2167 );
  twobit_invoke( 2 );
  twobit_label( 2167, compiled_block_1_2167 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 6 );
  twobit_global( 30 ); /* append */
  twobit_setrtn( 2168, compiled_block_1_2168 );
  twobit_invoke( 2 );
  twobit_label( 2168, compiled_block_1_2168 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 7 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 8 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 8 );
  twobit_const( 39 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 38 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2169, compiled_block_1_2169 );
  twobit_invoke( 5 );
  twobit_label( 2169, compiled_block_1_2169 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 37 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 38 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2170, compiled_block_1_2170 );
  twobit_invoke( 5 );
  twobit_label( 2170, compiled_block_1_2170 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 9 );
  twobit_global( 30 ); /* append */
  twobit_setrtn( 2171, compiled_block_1_2171 );
  twobit_invoke( 2 );
  twobit_label( 2171, compiled_block_1_2171 );
  twobit_load( 0, 0 );
  twobit_load( 3, 8 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 12 );
  twobit_return();
  twobit_label( 2163, compiled_block_1_2163 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1640, compiled_block_1_1640 );
  twobit_label( 2161, compiled_block_1_2161 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1640, compiled_block_1_1640 );
  twobit_label( 2159, compiled_block_1_2159 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1640, compiled_block_1_1640 );
  twobit_label( 2152, compiled_block_1_2152 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1640, compiled_block_1_1640 );
  twobit_label( 2150, compiled_block_1_2150 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1640, compiled_block_1_1640 );
  twobit_label( 2148, compiled_block_1_2148 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1640, compiled_block_1_1640 );
  twobit_label( 2146, compiled_block_1_2146 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1640, compiled_block_1_1640 );
  twobit_label( 2143, compiled_block_1_2143 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1640, compiled_block_1_1640 );
  twobit_label( 2141, compiled_block_1_2141 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1640, compiled_block_1_1640 );
  twobit_label( 2139, compiled_block_1_2139 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1640, compiled_block_1_1640 );
  twobit_label( 2137, compiled_block_1_2137 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1640, compiled_block_1_1640 );
  twobit_label( 2135, compiled_block_1_2135 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1640, compiled_block_1_1640 );
  twobit_label( 2133, compiled_block_1_2133 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1640, compiled_block_1_1640 );
  twobit_label( 2130, compiled_block_1_2130 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1640, compiled_block_1_1640 );
  twobit_label( 2128, compiled_block_1_2128 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1640, compiled_block_1_1640 );
  twobit_label( 2125, compiled_block_1_2125 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1640, compiled_block_1_1640 );
  twobit_label( 2123, compiled_block_1_2123 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1640, compiled_block_1_1640 );
  twobit_label( 2121, compiled_block_1_2121 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1640, compiled_block_1_1640 );
  twobit_label( 2118, compiled_block_1_2118 );
  twobit_branch( 1640, compiled_block_1_1640 );
  twobit_label( 2116, compiled_block_1_2116 );
  twobit_branch( 1640, compiled_block_1_1640 );
  twobit_label( 1642, compiled_block_1_1642 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2193, compiled_block_1_2193 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2195, compiled_block_1_2195 ); /* internal:branchf-pair? */
  twobit_save( 12 );
  twobit_store( 0, 0 );
  twobit_store( 1, 12 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_const( 33 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 2196, compiled_block_1_2196 );
  twobit_invoke( 2 );
  twobit_label( 2196, compiled_block_1_2196 );
  twobit_load( 0, 0 );
  twobit_branchf( 2198, compiled_block_1_2198 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2200, compiled_block_1_2200 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 11 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2202, compiled_block_1_2202 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 10 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2204, compiled_block_1_2204 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 4 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 2205, compiled_block_1_2205 );
  twobit_invoke( 1 );
  twobit_label( 2205, compiled_block_1_2205 );
  twobit_load( 0, 0 );
  twobit_branchf( 2207, compiled_block_1_2207 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2209, compiled_block_1_2209 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 9 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2211, compiled_block_1_2211 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 8 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2213, compiled_block_1_2213 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2215, compiled_block_1_2215 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2217, compiled_block_1_2217 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_movereg( 4, 1 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 2218, compiled_block_1_2218 );
  twobit_invoke( 1 );
  twobit_label( 2218, compiled_block_1_2218 );
  twobit_load( 0, 0 );
  twobit_branchf( 2220, compiled_block_1_2220 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2222, compiled_block_1_2222 ); /* internal:branchf-null? */
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2224, compiled_block_1_2224 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 2226, compiled_block_1_2226 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 34 ); /* ex:identifier? */
  twobit_setrtn( 2227, compiled_block_1_2227 );
  twobit_invoke( 1 );
  twobit_label( 2227, compiled_block_1_2227 );
  twobit_load( 0, 0 );
  twobit_branchf( 2229, compiled_block_1_2229 );
  twobit_const( 32 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 40 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2230, compiled_block_1_2230 );
  twobit_invoke( 5 );
  twobit_label( 2230, compiled_block_1_2230 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 36 ); /* ex:free-identifier=? */
  twobit_setrtn( 2231, compiled_block_1_2231 );
  twobit_invoke( 2 );
  twobit_label( 2231, compiled_block_1_2231 );
  twobit_load( 0, 0 );
  twobit_skip( 2228, compiled_block_1_2228 );
  twobit_label( 2229, compiled_block_1_2229 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2228, compiled_block_1_2228 );
  twobit_branchf( 2233, compiled_block_1_2233 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2235, compiled_block_1_2235 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2237, compiled_block_1_2237 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 7 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2239, compiled_block_1_2239 ); /* internal:branchf-null? */
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 40 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2240, compiled_block_1_2240 );
  twobit_invoke( 5 );
  twobit_label( 2240, compiled_block_1_2240 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 39 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 40 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2241, compiled_block_1_2241 );
  twobit_invoke( 5 );
  twobit_label( 2241, compiled_block_1_2241 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 4 );
  twobit_global( 30 ); /* append */
  twobit_setrtn( 2242, compiled_block_1_2242 );
  twobit_invoke( 2 );
  twobit_label( 2242, compiled_block_1_2242 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 39 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 40 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2243, compiled_block_1_2243 );
  twobit_invoke( 5 );
  twobit_label( 2243, compiled_block_1_2243 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 5 );
  twobit_global( 30 ); /* append */
  twobit_setrtn( 2244, compiled_block_1_2244 );
  twobit_invoke( 2 );
  twobit_label( 2244, compiled_block_1_2244 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 3, 1 );
  twobit_stack( 7 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 32 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 40 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2245, compiled_block_1_2245 );
  twobit_invoke( 5 );
  twobit_label( 2245, compiled_block_1_2245 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 33 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 12 );
  twobit_return();
  twobit_label( 2239, compiled_block_1_2239 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1641, compiled_block_1_1641 );
  twobit_label( 2237, compiled_block_1_2237 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1641, compiled_block_1_1641 );
  twobit_label( 2235, compiled_block_1_2235 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1641, compiled_block_1_1641 );
  twobit_label( 2233, compiled_block_1_2233 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1641, compiled_block_1_1641 );
  twobit_label( 2226, compiled_block_1_2226 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1641, compiled_block_1_1641 );
  twobit_label( 2224, compiled_block_1_2224 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1641, compiled_block_1_1641 );
  twobit_label( 2222, compiled_block_1_2222 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1641, compiled_block_1_1641 );
  twobit_label( 2220, compiled_block_1_2220 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1641, compiled_block_1_1641 );
  twobit_label( 2217, compiled_block_1_2217 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1641, compiled_block_1_1641 );
  twobit_label( 2215, compiled_block_1_2215 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1641, compiled_block_1_1641 );
  twobit_label( 2213, compiled_block_1_2213 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1641, compiled_block_1_1641 );
  twobit_label( 2211, compiled_block_1_2211 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1641, compiled_block_1_1641 );
  twobit_label( 2209, compiled_block_1_2209 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1641, compiled_block_1_1641 );
  twobit_label( 2207, compiled_block_1_2207 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1641, compiled_block_1_1641 );
  twobit_label( 2204, compiled_block_1_2204 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1641, compiled_block_1_1641 );
  twobit_label( 2202, compiled_block_1_2202 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1641, compiled_block_1_1641 );
  twobit_label( 2200, compiled_block_1_2200 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1641, compiled_block_1_1641 );
  twobit_label( 2198, compiled_block_1_2198 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1641, compiled_block_1_1641 );
  twobit_label( 2195, compiled_block_1_2195 );
  twobit_branch( 1641, compiled_block_1_1641 );
  twobit_label( 2193, compiled_block_1_2193 );
  twobit_branch( 1641, compiled_block_1_1641 );
  twobit_label( 1643, compiled_block_1_1643 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2267, compiled_block_1_2267 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2269, compiled_block_1_2269 ); /* internal:branchf-pair? */
  twobit_save( 11 );
  twobit_store( 0, 0 );
  twobit_store( 1, 11 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_const( 41 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 2270, compiled_block_1_2270 );
  twobit_invoke( 2 );
  twobit_label( 2270, compiled_block_1_2270 );
  twobit_load( 0, 0 );
  twobit_branchf( 2272, compiled_block_1_2272 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2274, compiled_block_1_2274 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 10 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2276, compiled_block_1_2276 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 9 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2278, compiled_block_1_2278 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 4 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 2279, compiled_block_1_2279 );
  twobit_invoke( 1 );
  twobit_label( 2279, compiled_block_1_2279 );
  twobit_load( 0, 0 );
  twobit_branchf( 2281, compiled_block_1_2281 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2283, compiled_block_1_2283 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 8 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2285, compiled_block_1_2285 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 7 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2287, compiled_block_1_2287 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2289, compiled_block_1_2289 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2291, compiled_block_1_2291 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_movereg( 4, 1 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 2292, compiled_block_1_2292 );
  twobit_invoke( 1 );
  twobit_label( 2292, compiled_block_1_2292 );
  twobit_load( 0, 0 );
  twobit_branchf( 2294, compiled_block_1_2294 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2296, compiled_block_1_2296 ); /* internal:branchf-null? */
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2298, compiled_block_1_2298 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 2300, compiled_block_1_2300 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 34 ); /* ex:identifier? */
  twobit_setrtn( 2301, compiled_block_1_2301 );
  twobit_invoke( 1 );
  twobit_label( 2301, compiled_block_1_2301 );
  twobit_load( 0, 0 );
  twobit_branchf( 2303, compiled_block_1_2303 );
  twobit_const( 32 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 42 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2304, compiled_block_1_2304 );
  twobit_invoke( 5 );
  twobit_label( 2304, compiled_block_1_2304 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 36 ); /* ex:free-identifier=? */
  twobit_setrtn( 2305, compiled_block_1_2305 );
  twobit_invoke( 2 );
  twobit_label( 2305, compiled_block_1_2305 );
  twobit_load( 0, 0 );
  twobit_skip( 2302, compiled_block_1_2302 );
  twobit_label( 2303, compiled_block_1_2303 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2302, compiled_block_1_2302 );
  twobit_branchf( 2307, compiled_block_1_2307 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2309, compiled_block_1_2309 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 2310, compiled_block_1_2310 );
  twobit_invoke( 1 );
  twobit_label( 2310, compiled_block_1_2310 );
  twobit_load( 0, 0 );
  twobit_branchf( 2312, compiled_block_1_2312 );
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2314, compiled_block_1_2314 ); /* internal:branchf-null? */
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 42 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2315, compiled_block_1_2315 );
  twobit_invoke( 5 );
  twobit_label( 2315, compiled_block_1_2315 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 39 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 42 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2316, compiled_block_1_2316 );
  twobit_invoke( 5 );
  twobit_label( 2316, compiled_block_1_2316 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 4 );
  twobit_global( 30 ); /* append */
  twobit_setrtn( 2317, compiled_block_1_2317 );
  twobit_invoke( 2 );
  twobit_label( 2317, compiled_block_1_2317 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 39 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 42 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2318, compiled_block_1_2318 );
  twobit_invoke( 5 );
  twobit_label( 2318, compiled_block_1_2318 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 5 );
  twobit_global( 30 ); /* append */
  twobit_setrtn( 2319, compiled_block_1_2319 );
  twobit_invoke( 2 );
  twobit_label( 2319, compiled_block_1_2319 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 32 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 42 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2320, compiled_block_1_2320 );
  twobit_invoke( 5 );
  twobit_label( 2320, compiled_block_1_2320 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 41 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 11 );
  twobit_return();
  twobit_label( 2314, compiled_block_1_2314 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1642, compiled_block_1_1642 );
  twobit_label( 2312, compiled_block_1_2312 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1642, compiled_block_1_1642 );
  twobit_label( 2309, compiled_block_1_2309 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1642, compiled_block_1_1642 );
  twobit_label( 2307, compiled_block_1_2307 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1642, compiled_block_1_1642 );
  twobit_label( 2300, compiled_block_1_2300 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1642, compiled_block_1_1642 );
  twobit_label( 2298, compiled_block_1_2298 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1642, compiled_block_1_1642 );
  twobit_label( 2296, compiled_block_1_2296 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1642, compiled_block_1_1642 );
  twobit_label( 2294, compiled_block_1_2294 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1642, compiled_block_1_1642 );
  twobit_label( 2291, compiled_block_1_2291 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1642, compiled_block_1_1642 );
  twobit_label( 2289, compiled_block_1_2289 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1642, compiled_block_1_1642 );
  twobit_label( 2287, compiled_block_1_2287 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1642, compiled_block_1_1642 );
  twobit_label( 2285, compiled_block_1_2285 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1642, compiled_block_1_1642 );
  twobit_label( 2283, compiled_block_1_2283 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1642, compiled_block_1_1642 );
  twobit_label( 2281, compiled_block_1_2281 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1642, compiled_block_1_1642 );
  twobit_label( 2278, compiled_block_1_2278 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1642, compiled_block_1_1642 );
  twobit_label( 2276, compiled_block_1_2276 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1642, compiled_block_1_1642 );
  twobit_label( 2274, compiled_block_1_2274 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1642, compiled_block_1_1642 );
  twobit_label( 2272, compiled_block_1_2272 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1642, compiled_block_1_1642 );
  twobit_label( 2269, compiled_block_1_2269 );
  twobit_branch( 1642, compiled_block_1_1642 );
  twobit_label( 2267, compiled_block_1_2267 );
  twobit_branch( 1642, compiled_block_1_1642 );
  twobit_label( 1644, compiled_block_1_1644 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2342, compiled_block_1_2342 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2344, compiled_block_1_2344 ); /* internal:branchf-pair? */
  twobit_save( 11 );
  twobit_store( 0, 0 );
  twobit_store( 1, 11 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_const( 41 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 2345, compiled_block_1_2345 );
  twobit_invoke( 2 );
  twobit_label( 2345, compiled_block_1_2345 );
  twobit_load( 0, 0 );
  twobit_branchf( 2347, compiled_block_1_2347 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2349, compiled_block_1_2349 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 10 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2351, compiled_block_1_2351 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 9 );
  twobit_movereg( 2, 1 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 2352, compiled_block_1_2352 );
  twobit_invoke( 1 );
  twobit_label( 2352, compiled_block_1_2352 );
  twobit_load( 0, 0 );
  twobit_branchf( 2354, compiled_block_1_2354 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2356, compiled_block_1_2356 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2358, compiled_block_1_2358 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 5 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2360, compiled_block_1_2360 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 4 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2362, compiled_block_1_2362 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2364, compiled_block_1_2364 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2366, compiled_block_1_2366 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2368, compiled_block_1_2368 ); /* internal:branchf-null? */
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2370, compiled_block_1_2370 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2372, compiled_block_1_2372 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 34 ); /* ex:identifier? */
  twobit_setrtn( 2373, compiled_block_1_2373 );
  twobit_invoke( 1 );
  twobit_label( 2373, compiled_block_1_2373 );
  twobit_load( 0, 0 );
  twobit_branchf( 2375, compiled_block_1_2375 );
  twobit_const( 32 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 43 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2376, compiled_block_1_2376 );
  twobit_invoke( 5 );
  twobit_label( 2376, compiled_block_1_2376 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 36 ); /* ex:free-identifier=? */
  twobit_setrtn( 2377, compiled_block_1_2377 );
  twobit_invoke( 2 );
  twobit_label( 2377, compiled_block_1_2377 );
  twobit_load( 0, 0 );
  twobit_skip( 2374, compiled_block_1_2374 );
  twobit_label( 2375, compiled_block_1_2375 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2374, compiled_block_1_2374 );
  twobit_branchf( 2379, compiled_block_1_2379 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2381, compiled_block_1_2381 ); /* internal:branchf-null? */
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2383, compiled_block_1_2383 ); /* internal:branchf-null? */
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 43 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2384, compiled_block_1_2384 );
  twobit_invoke( 5 );
  twobit_label( 2384, compiled_block_1_2384 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 7 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_stack( 8 );
  twobit_op2_58( 2 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 1 ); /* () */
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 9 );
  twobit_global( 30 ); /* append */
  twobit_setrtn( 2385, compiled_block_1_2385 );
  twobit_invoke( 2 );
  twobit_label( 2385, compiled_block_1_2385 );
  twobit_load( 0, 0 );
  twobit_load( 3, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 11 );
  twobit_return();
  twobit_label( 2383, compiled_block_1_2383 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1643, compiled_block_1_1643 );
  twobit_label( 2381, compiled_block_1_2381 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1643, compiled_block_1_1643 );
  twobit_label( 2379, compiled_block_1_2379 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1643, compiled_block_1_1643 );
  twobit_label( 2372, compiled_block_1_2372 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1643, compiled_block_1_1643 );
  twobit_label( 2370, compiled_block_1_2370 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1643, compiled_block_1_1643 );
  twobit_label( 2368, compiled_block_1_2368 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1643, compiled_block_1_1643 );
  twobit_label( 2366, compiled_block_1_2366 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1643, compiled_block_1_1643 );
  twobit_label( 2364, compiled_block_1_2364 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1643, compiled_block_1_1643 );
  twobit_label( 2362, compiled_block_1_2362 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1643, compiled_block_1_1643 );
  twobit_label( 2360, compiled_block_1_2360 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1643, compiled_block_1_1643 );
  twobit_label( 2358, compiled_block_1_2358 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1643, compiled_block_1_1643 );
  twobit_label( 2356, compiled_block_1_2356 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1643, compiled_block_1_1643 );
  twobit_label( 2354, compiled_block_1_2354 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1643, compiled_block_1_1643 );
  twobit_label( 2351, compiled_block_1_2351 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1643, compiled_block_1_1643 );
  twobit_label( 2349, compiled_block_1_2349 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1643, compiled_block_1_1643 );
  twobit_label( 2347, compiled_block_1_2347 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1643, compiled_block_1_1643 );
  twobit_label( 2344, compiled_block_1_2344 );
  twobit_branch( 1643, compiled_block_1_1643 );
  twobit_label( 2342, compiled_block_1_2342 );
  twobit_branch( 1643, compiled_block_1_1643 );
  twobit_label( 1645, compiled_block_1_1645 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2405, compiled_block_1_2405 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2407, compiled_block_1_2407 ); /* internal:branchf-pair? */
  twobit_save( 11 );
  twobit_store( 0, 0 );
  twobit_store( 1, 11 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_const( 1 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 2408, compiled_block_1_2408 );
  twobit_invoke( 2 );
  twobit_label( 2408, compiled_block_1_2408 );
  twobit_load( 0, 0 );
  twobit_branchf( 2410, compiled_block_1_2410 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2412, compiled_block_1_2412 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 10 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2414, compiled_block_1_2414 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 9 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2416, compiled_block_1_2416 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 8 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2418, compiled_block_1_2418 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2420, compiled_block_1_2420 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2422, compiled_block_1_2422 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2424, compiled_block_1_2424 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2426, compiled_block_1_2426 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2428, compiled_block_1_2428 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 2429, compiled_block_1_2429 );
  twobit_invoke( 1 );
  twobit_label( 2429, compiled_block_1_2429 );
  twobit_load( 0, 0 );
  twobit_branchf( 2431, compiled_block_1_2431 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 2432, compiled_block_1_2432 );
  twobit_invoke( 1 );
  twobit_label( 2432, compiled_block_1_2432 );
  twobit_load( 0, 0 );
  twobit_branchf( 2434, compiled_block_1_2434 );
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2436, compiled_block_1_2436 ); /* internal:branchf-null? */
  twobit_load( 4, 1 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 28 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 44 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2437, compiled_block_1_2437 );
  twobit_invoke( 5 );
  twobit_label( 2437, compiled_block_1_2437 );
  twobit_load( 0, 0 );
  twobit_load( 3, 10 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 11 );
  twobit_return();
  twobit_label( 2436, compiled_block_1_2436 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1644, compiled_block_1_1644 );
  twobit_label( 2434, compiled_block_1_2434 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1644, compiled_block_1_1644 );
  twobit_label( 2431, compiled_block_1_2431 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1644, compiled_block_1_1644 );
  twobit_label( 2428, compiled_block_1_2428 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1644, compiled_block_1_1644 );
  twobit_label( 2426, compiled_block_1_2426 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1644, compiled_block_1_1644 );
  twobit_label( 2424, compiled_block_1_2424 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1644, compiled_block_1_1644 );
  twobit_label( 2422, compiled_block_1_2422 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1644, compiled_block_1_1644 );
  twobit_label( 2420, compiled_block_1_2420 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1644, compiled_block_1_1644 );
  twobit_label( 2418, compiled_block_1_2418 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1644, compiled_block_1_1644 );
  twobit_label( 2416, compiled_block_1_2416 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1644, compiled_block_1_1644 );
  twobit_label( 2414, compiled_block_1_2414 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1644, compiled_block_1_1644 );
  twobit_label( 2412, compiled_block_1_2412 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1644, compiled_block_1_1644 );
  twobit_label( 2410, compiled_block_1_2410 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1644, compiled_block_1_1644 );
  twobit_label( 2407, compiled_block_1_2407 );
  twobit_branch( 1644, compiled_block_1_1644 );
  twobit_label( 2405, compiled_block_1_2405 );
  twobit_branch( 1644, compiled_block_1_1644 );
  twobit_label( 1646, compiled_block_1_1646 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2454, compiled_block_1_2454 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2456, compiled_block_1_2456 ); /* internal:branchf-pair? */
  twobit_save( 9 );
  twobit_store( 0, 0 );
  twobit_store( 1, 9 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_const( 1 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 2457, compiled_block_1_2457 );
  twobit_invoke( 2 );
  twobit_label( 2457, compiled_block_1_2457 );
  twobit_load( 0, 0 );
  twobit_branchf( 2459, compiled_block_1_2459 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2461, compiled_block_1_2461 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 8 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2463, compiled_block_1_2463 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 7 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2465, compiled_block_1_2465 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 6 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 2466, compiled_block_1_2466 );
  twobit_invoke( 1 );
  twobit_label( 2466, compiled_block_1_2466 );
  twobit_load( 0, 0 );
  twobit_branchf( 2468, compiled_block_1_2468 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2470, compiled_block_1_2470 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2472, compiled_block_1_2472 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 2474, compiled_block_1_2474 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2476, compiled_block_1_2476 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2478, compiled_block_1_2478 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2480, compiled_block_1_2480 ); /* internal:branchf-null? */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 2481, compiled_block_1_2481 );
  twobit_invoke( 1 );
  twobit_label( 2481, compiled_block_1_2481 );
  twobit_load( 0, 0 );
  twobit_branchf( 2483, compiled_block_1_2483 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2485, compiled_block_1_2485 ); /* internal:branchf-null? */
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 45 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2486, compiled_block_1_2486 );
  twobit_invoke( 5 );
  twobit_label( 2486, compiled_block_1_2486 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 4 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_stack( 5 );
  twobit_op2_58( 2 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 1 ); /* () */
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 6 );
  twobit_global( 30 ); /* append */
  twobit_setrtn( 2487, compiled_block_1_2487 );
  twobit_invoke( 2 );
  twobit_label( 2487, compiled_block_1_2487 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 9 );
  twobit_return();
  twobit_label( 2485, compiled_block_1_2485 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1645, compiled_block_1_1645 );
  twobit_label( 2483, compiled_block_1_2483 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1645, compiled_block_1_1645 );
  twobit_label( 2480, compiled_block_1_2480 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1645, compiled_block_1_1645 );
  twobit_label( 2478, compiled_block_1_2478 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1645, compiled_block_1_1645 );
  twobit_label( 2476, compiled_block_1_2476 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1645, compiled_block_1_1645 );
  twobit_label( 2474, compiled_block_1_2474 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1645, compiled_block_1_1645 );
  twobit_label( 2472, compiled_block_1_2472 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1645, compiled_block_1_1645 );
  twobit_label( 2470, compiled_block_1_2470 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1645, compiled_block_1_1645 );
  twobit_label( 2468, compiled_block_1_2468 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1645, compiled_block_1_1645 );
  twobit_label( 2465, compiled_block_1_2465 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1645, compiled_block_1_1645 );
  twobit_label( 2463, compiled_block_1_2463 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1645, compiled_block_1_1645 );
  twobit_label( 2461, compiled_block_1_2461 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1645, compiled_block_1_1645 );
  twobit_label( 2459, compiled_block_1_2459 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 1645, compiled_block_1_1645 );
  twobit_label( 2456, compiled_block_1_2456 );
  twobit_branch( 1645, compiled_block_1_1645 );
  twobit_label( 2454, compiled_block_1_2454 );
  twobit_branch( 1645, compiled_block_1_1645 );
  twobit_label( 1647, compiled_block_1_1647 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2504, compiled_block_1_2504 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2506, compiled_block_1_2506 ); /* internal:branchf-pair? */
  twobit_save( 10 );
  twobit_store( 0, 0 );
  twobit_store( 1, 10 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_const( 1 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 2507, compiled_block_1_2507 );
  twobit_invoke( 2 );
  twobit_label( 2507, compiled_block_1_2507 );
  twobit_load( 0, 0 );
  twobit_branchf( 2509, compiled_block_1_2509 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2511, compiled_block_1_2511 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 9 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2513, compiled_block_1_2513 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 8 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2515, compiled_block_1_2515 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 7 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2517, compiled_block_1_2517 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2519, compiled_block_1_2519 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2521, compiled_block_1_2521 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2523, compiled_block_1_2523 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2525, compiled_block_1_2525 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 34 ); /* ex:identifier? */
  twobit_setrtn( 2526, compiled_block_1_2526 );
  twobit_invoke( 1 );
  twobit_label( 2526, compiled_block_1_2526 );
  twobit_load( 0, 0 );
  twobit_branchf( 2528, compiled_block_1_2528 );
  twobit_const( 32 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 46 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2529, compiled_block_1_2529 );
  twobit_invoke( 5 );
  twobit_label( 2529, compiled_block_1_2529 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 36 ); /* ex:free-identifier=? */
  twobit_setrtn( 2530, compiled_block_1_2530 );
  twobit_invoke( 2 );
  twobit_label( 2530, compiled_block_1_2530 );
  twobit_load( 0, 0 );
  twobit_skip( 2527, compiled_block_1_2527 );
  twobit_label( 2528, compiled_block_1_2528 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2527, compiled_block_1_2527 );
  twobit_branchf( 2532, compiled_block_1_2532 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 2534, compiled_block_1_2534 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2536, compiled_block_1_2536 ); /* internal:branchf-null? */
  twobit_stack( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_movereg( 3, 1 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 2537, compiled_block_1_2537 );
  twobit_invoke( 1 );
  twobit_label( 2537, compiled_block_1_2537 );
  twobit_load( 0, 0 );
  twobit_branchf( 2539, compiled_block_1_2539 );
  twobit_stack( 5 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2541, compiled_block_1_2541 ); /* internal:branchf-null? */
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 46 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2542, compiled_block_1_2542 );
  twobit_invoke( 5 );
  twobit_label( 2542, compiled_block_1_2542 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 32 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 46 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2543, compiled_block_1_2543 );
  twobit_invoke( 5 );
  twobit_label( 2543, compiled_block_1_2543 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 33 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 10 );
  twobit_return();
  twobit_label( 2541, compiled_block_1_2541 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1646, compiled_block_1_1646 );
  twobit_label( 2539, compiled_block_1_2539 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1646, compiled_block_1_1646 );
  twobit_label( 2536, compiled_block_1_2536 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1646, compiled_block_1_1646 );
  twobit_label( 2534, compiled_block_1_2534 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1646, compiled_block_1_1646 );
  twobit_label( 2532, compiled_block_1_2532 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1646, compiled_block_1_1646 );
  twobit_label( 2525, compiled_block_1_2525 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1646, compiled_block_1_1646 );
  twobit_label( 2523, compiled_block_1_2523 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1646, compiled_block_1_1646 );
  twobit_label( 2521, compiled_block_1_2521 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1646, compiled_block_1_1646 );
  twobit_label( 2519, compiled_block_1_2519 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1646, compiled_block_1_1646 );
  twobit_label( 2517, compiled_block_1_2517 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1646, compiled_block_1_1646 );
  twobit_label( 2515, compiled_block_1_2515 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1646, compiled_block_1_1646 );
  twobit_label( 2513, compiled_block_1_2513 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1646, compiled_block_1_1646 );
  twobit_label( 2511, compiled_block_1_2511 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1646, compiled_block_1_1646 );
  twobit_label( 2509, compiled_block_1_2509 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1646, compiled_block_1_1646 );
  twobit_label( 2506, compiled_block_1_2506 );
  twobit_branch( 1646, compiled_block_1_1646 );
  twobit_label( 2504, compiled_block_1_2504 );
  twobit_branch( 1646, compiled_block_1_1646 );
  twobit_label( 1648, compiled_block_1_1648 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2561, compiled_block_1_2561 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2563, compiled_block_1_2563 ); /* internal:branchf-pair? */
  twobit_save( 10 );
  twobit_store( 0, 0 );
  twobit_store( 1, 10 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_const( 1 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 2564, compiled_block_1_2564 );
  twobit_invoke( 2 );
  twobit_label( 2564, compiled_block_1_2564 );
  twobit_load( 0, 0 );
  twobit_branchf( 2566, compiled_block_1_2566 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2568, compiled_block_1_2568 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 9 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2570, compiled_block_1_2570 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 8 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2572, compiled_block_1_2572 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 7 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2574, compiled_block_1_2574 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2576, compiled_block_1_2576 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2578, compiled_block_1_2578 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2580, compiled_block_1_2580 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2582, compiled_block_1_2582 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 34 ); /* ex:identifier? */
  twobit_setrtn( 2583, compiled_block_1_2583 );
  twobit_invoke( 1 );
  twobit_label( 2583, compiled_block_1_2583 );
  twobit_load( 0, 0 );
  twobit_branchf( 2585, compiled_block_1_2585 );
  twobit_const( 32 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 47 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2586, compiled_block_1_2586 );
  twobit_invoke( 5 );
  twobit_label( 2586, compiled_block_1_2586 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 36 ); /* ex:free-identifier=? */
  twobit_setrtn( 2587, compiled_block_1_2587 );
  twobit_invoke( 2 );
  twobit_label( 2587, compiled_block_1_2587 );
  twobit_load( 0, 0 );
  twobit_skip( 2584, compiled_block_1_2584 );
  twobit_label( 2585, compiled_block_1_2585 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2584, compiled_block_1_2584 );
  twobit_branchf( 2589, compiled_block_1_2589 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 2590, compiled_block_1_2590 );
  twobit_invoke( 1 );
  twobit_label( 2590, compiled_block_1_2590 );
  twobit_load( 0, 0 );
  twobit_branchf( 2592, compiled_block_1_2592 );
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2594, compiled_block_1_2594 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2596, compiled_block_1_2596 ); /* internal:branchf-null? */
  twobit_stack( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_movereg( 4, 1 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 2597, compiled_block_1_2597 );
  twobit_invoke( 1 );
  twobit_label( 2597, compiled_block_1_2597 );
  twobit_load( 0, 0 );
  twobit_branchf( 2599, compiled_block_1_2599 );
  twobit_stack( 5 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2601, compiled_block_1_2601 ); /* internal:branchf-null? */
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 47 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2602, compiled_block_1_2602 );
  twobit_invoke( 5 );
  twobit_label( 2602, compiled_block_1_2602 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 32 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 47 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2603, compiled_block_1_2603 );
  twobit_invoke( 5 );
  twobit_label( 2603, compiled_block_1_2603 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 41 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 10 );
  twobit_return();
  twobit_label( 2601, compiled_block_1_2601 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1647, compiled_block_1_1647 );
  twobit_label( 2599, compiled_block_1_2599 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1647, compiled_block_1_1647 );
  twobit_label( 2596, compiled_block_1_2596 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1647, compiled_block_1_1647 );
  twobit_label( 2594, compiled_block_1_2594 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1647, compiled_block_1_1647 );
  twobit_label( 2592, compiled_block_1_2592 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1647, compiled_block_1_1647 );
  twobit_label( 2589, compiled_block_1_2589 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1647, compiled_block_1_1647 );
  twobit_label( 2582, compiled_block_1_2582 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1647, compiled_block_1_1647 );
  twobit_label( 2580, compiled_block_1_2580 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1647, compiled_block_1_1647 );
  twobit_label( 2578, compiled_block_1_2578 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1647, compiled_block_1_1647 );
  twobit_label( 2576, compiled_block_1_2576 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1647, compiled_block_1_1647 );
  twobit_label( 2574, compiled_block_1_2574 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1647, compiled_block_1_1647 );
  twobit_label( 2572, compiled_block_1_2572 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1647, compiled_block_1_1647 );
  twobit_label( 2570, compiled_block_1_2570 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1647, compiled_block_1_1647 );
  twobit_label( 2568, compiled_block_1_2568 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1647, compiled_block_1_1647 );
  twobit_label( 2566, compiled_block_1_2566 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1647, compiled_block_1_1647 );
  twobit_label( 2563, compiled_block_1_2563 );
  twobit_branch( 1647, compiled_block_1_1647 );
  twobit_label( 2561, compiled_block_1_2561 );
  twobit_branch( 1647, compiled_block_1_1647 );
  twobit_label( 1649, compiled_block_1_1649 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2622, compiled_block_1_2622 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2624, compiled_block_1_2624 ); /* internal:branchf-pair? */
  twobit_save( 10 );
  twobit_store( 0, 0 );
  twobit_store( 1, 10 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_const( 1 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 2625, compiled_block_1_2625 );
  twobit_invoke( 2 );
  twobit_label( 2625, compiled_block_1_2625 );
  twobit_load( 0, 0 );
  twobit_branchf( 2627, compiled_block_1_2627 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2629, compiled_block_1_2629 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 9 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2631, compiled_block_1_2631 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 8 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2633, compiled_block_1_2633 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 7 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 2634, compiled_block_1_2634 );
  twobit_invoke( 1 );
  twobit_label( 2634, compiled_block_1_2634 );
  twobit_load( 0, 0 );
  twobit_branchf( 2636, compiled_block_1_2636 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2638, compiled_block_1_2638 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2640, compiled_block_1_2640 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 4 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 2642, compiled_block_1_2642 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 3 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2644, compiled_block_1_2644 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2646, compiled_block_1_2646 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 34 ); /* ex:identifier? */
  twobit_setrtn( 2647, compiled_block_1_2647 );
  twobit_invoke( 1 );
  twobit_label( 2647, compiled_block_1_2647 );
  twobit_load( 0, 0 );
  twobit_branchf( 2649, compiled_block_1_2649 );
  twobit_const( 32 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 48 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2650, compiled_block_1_2650 );
  twobit_invoke( 5 );
  twobit_label( 2650, compiled_block_1_2650 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 36 ); /* ex:free-identifier=? */
  twobit_setrtn( 2651, compiled_block_1_2651 );
  twobit_invoke( 2 );
  twobit_label( 2651, compiled_block_1_2651 );
  twobit_load( 0, 0 );
  twobit_skip( 2648, compiled_block_1_2648 );
  twobit_label( 2649, compiled_block_1_2649 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2648, compiled_block_1_2648 );
  twobit_branchf( 2653, compiled_block_1_2653 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2655, compiled_block_1_2655 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2657, compiled_block_1_2657 ); /* internal:branchf-null? */
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2659, compiled_block_1_2659 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2661, compiled_block_1_2661 ); /* internal:branchf-null? */
  twobit_stack( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_movereg( 4, 1 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 2662, compiled_block_1_2662 );
  twobit_invoke( 1 );
  twobit_label( 2662, compiled_block_1_2662 );
  twobit_load( 0, 0 );
  twobit_branchf( 2664, compiled_block_1_2664 );
  twobit_stack( 5 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2666, compiled_block_1_2666 ); /* internal:branchf-null? */
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 48 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2667, compiled_block_1_2667 );
  twobit_invoke( 5 );
  twobit_label( 2667, compiled_block_1_2667 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 3 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_stack( 1 );
  twobit_op2_58( 2 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 1 ); /* () */
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 7 );
  twobit_global( 30 ); /* append */
  twobit_setrtn( 2668, compiled_block_1_2668 );
  twobit_invoke( 2 );
  twobit_label( 2668, compiled_block_1_2668 );
  twobit_load( 0, 0 );
  twobit_load( 3, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 10 );
  twobit_return();
  twobit_label( 2666, compiled_block_1_2666 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1648, compiled_block_1_1648 );
  twobit_label( 2664, compiled_block_1_2664 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1648, compiled_block_1_1648 );
  twobit_label( 2661, compiled_block_1_2661 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1648, compiled_block_1_1648 );
  twobit_label( 2659, compiled_block_1_2659 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1648, compiled_block_1_1648 );
  twobit_label( 2657, compiled_block_1_2657 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1648, compiled_block_1_1648 );
  twobit_label( 2655, compiled_block_1_2655 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1648, compiled_block_1_1648 );
  twobit_label( 2653, compiled_block_1_2653 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1648, compiled_block_1_1648 );
  twobit_label( 2646, compiled_block_1_2646 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1648, compiled_block_1_1648 );
  twobit_label( 2644, compiled_block_1_2644 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1648, compiled_block_1_1648 );
  twobit_label( 2642, compiled_block_1_2642 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1648, compiled_block_1_1648 );
  twobit_label( 2640, compiled_block_1_2640 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1648, compiled_block_1_1648 );
  twobit_label( 2638, compiled_block_1_2638 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1648, compiled_block_1_1648 );
  twobit_label( 2636, compiled_block_1_2636 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1648, compiled_block_1_1648 );
  twobit_label( 2633, compiled_block_1_2633 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1648, compiled_block_1_1648 );
  twobit_label( 2631, compiled_block_1_2631 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1648, compiled_block_1_1648 );
  twobit_label( 2629, compiled_block_1_2629 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1648, compiled_block_1_1648 );
  twobit_label( 2627, compiled_block_1_2627 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1648, compiled_block_1_1648 );
  twobit_label( 2624, compiled_block_1_2624 );
  twobit_branch( 1648, compiled_block_1_1648 );
  twobit_label( 2622, compiled_block_1_2622 );
  twobit_branch( 1648, compiled_block_1_1648 );
  twobit_label( 1650, compiled_block_1_1650 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2689, compiled_block_1_2689 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2691, compiled_block_1_2691 ); /* internal:branchf-pair? */
  twobit_save( 10 );
  twobit_store( 0, 0 );
  twobit_store( 1, 10 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_const( 1 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* equal? */
  twobit_setrtn( 2692, compiled_block_1_2692 );
  twobit_invoke( 2 );
  twobit_label( 2692, compiled_block_1_2692 );
  twobit_load( 0, 0 );
  twobit_branchf( 2694, compiled_block_1_2694 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2696, compiled_block_1_2696 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 9 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2698, compiled_block_1_2698 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 8 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2700, compiled_block_1_2700 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 7 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 2701, compiled_block_1_2701 );
  twobit_invoke( 1 );
  twobit_label( 2701, compiled_block_1_2701 );
  twobit_load( 0, 0 );
  twobit_branchf( 2703, compiled_block_1_2703 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2705, compiled_block_1_2705 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2707, compiled_block_1_2707 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 4 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 2709, compiled_block_1_2709 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 3 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2711, compiled_block_1_2711 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2713, compiled_block_1_2713 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 34 ); /* ex:identifier? */
  twobit_setrtn( 2714, compiled_block_1_2714 );
  twobit_invoke( 1 );
  twobit_label( 2714, compiled_block_1_2714 );
  twobit_load( 0, 0 );
  twobit_branchf( 2716, compiled_block_1_2716 );
  twobit_const( 32 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 49 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2717, compiled_block_1_2717 );
  twobit_invoke( 5 );
  twobit_label( 2717, compiled_block_1_2717 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 36 ); /* ex:free-identifier=? */
  twobit_setrtn( 2718, compiled_block_1_2718 );
  twobit_invoke( 2 );
  twobit_label( 2718, compiled_block_1_2718 );
  twobit_load( 0, 0 );
  twobit_skip( 2715, compiled_block_1_2715 );
  twobit_label( 2716, compiled_block_1_2716 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2715, compiled_block_1_2715 );
  twobit_branchf( 2720, compiled_block_1_2720 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2722, compiled_block_1_2722 ); /* internal:branchf-null? */
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2724, compiled_block_1_2724 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2726, compiled_block_1_2726 ); /* internal:branchf-null? */
  twobit_stack( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_movereg( 4, 1 );
  twobit_global( 3 ); /* list? */
  twobit_setrtn( 2727, compiled_block_1_2727 );
  twobit_invoke( 1 );
  twobit_label( 2727, compiled_block_1_2727 );
  twobit_load( 0, 0 );
  twobit_branchf( 2729, compiled_block_1_2729 );
  twobit_stack( 5 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2731, compiled_block_1_2731 ); /* internal:branchf-null? */
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 49 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2732, compiled_block_1_2732 );
  twobit_invoke( 5 );
  twobit_label( 2732, compiled_block_1_2732 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_const( 50 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 49 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2733, compiled_block_1_2733 );
  twobit_invoke( 5 );
  twobit_label( 2733, compiled_block_1_2733 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 51 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 49 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 5 );
  twobit_global( 8 ); /* ex:syntax-rename */
  twobit_setrtn( 2734, compiled_block_1_2734 );
  twobit_invoke( 5 );
  twobit_label( 2734, compiled_block_1_2734 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 7 );
  twobit_global( 30 ); /* append */
  twobit_setrtn( 2735, compiled_block_1_2735 );
  twobit_invoke( 2 );
  twobit_label( 2735, compiled_block_1_2735 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 10 );
  twobit_return();
  twobit_label( 2731, compiled_block_1_2731 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1649, compiled_block_1_1649 );
  twobit_label( 2729, compiled_block_1_2729 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1649, compiled_block_1_1649 );
  twobit_label( 2726, compiled_block_1_2726 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1649, compiled_block_1_1649 );
  twobit_label( 2724, compiled_block_1_2724 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1649, compiled_block_1_1649 );
  twobit_label( 2722, compiled_block_1_2722 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1649, compiled_block_1_1649 );
  twobit_label( 2720, compiled_block_1_2720 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1649, compiled_block_1_1649 );
  twobit_label( 2713, compiled_block_1_2713 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1649, compiled_block_1_1649 );
  twobit_label( 2711, compiled_block_1_2711 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1649, compiled_block_1_1649 );
  twobit_label( 2709, compiled_block_1_2709 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1649, compiled_block_1_1649 );
  twobit_label( 2707, compiled_block_1_2707 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1649, compiled_block_1_1649 );
  twobit_label( 2705, compiled_block_1_2705 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1649, compiled_block_1_1649 );
  twobit_label( 2703, compiled_block_1_2703 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1649, compiled_block_1_1649 );
  twobit_label( 2700, compiled_block_1_2700 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1649, compiled_block_1_1649 );
  twobit_label( 2698, compiled_block_1_2698 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1649, compiled_block_1_1649 );
  twobit_label( 2696, compiled_block_1_2696 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1649, compiled_block_1_1649 );
  twobit_label( 2694, compiled_block_1_2694 );
  twobit_load( 1, 10 );
  twobit_pop( 10 );
  twobit_branch( 1649, compiled_block_1_1649 );
  twobit_label( 2691, compiled_block_1_2691 );
  twobit_branch( 1649, compiled_block_1_1649 );
  twobit_label( 2689, compiled_block_1_2689 );
  twobit_branch( 1649, compiled_block_1_1649 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_25( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1734, compiled_block_1_1734 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_31, 2, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1766, compiled_block_1_1766 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_skip( 1765, compiled_block_1_1765 );
  twobit_label( 1766, compiled_block_1_1766 );
  twobit_movereg( 1, 3 );
  twobit_global( 4 ); /* map */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* list */
  twobit_setreg( 2 );
  twobit_global( 6 ); /* apply */
  twobit_setrtn( 1767, compiled_block_1_1767 );
  twobit_invoke( 3 );
  twobit_label( 1767, compiled_block_1_1767 );
  twobit_load( 0, 0 );
  twobit_label( 1765, compiled_block_1_1765 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1734, compiled_block_1_1734 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_jump( 1, 1632, compiled_block_1_1632 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_31( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 1, 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1738, compiled_block_1_1738 ); /* internal:branchf-pair? */
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 3 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1739, compiled_block_1_1739 );
  twobit_invoke( 1 );
  twobit_label( 1739, compiled_block_1_1739 );
  twobit_load( 0, 0 );
  twobit_branchf( 1741, compiled_block_1_1741 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1743, compiled_block_1_1743 ); /* internal:branchf-null? */
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1744, compiled_block_1_1744 );
  twobit_invoke( 5 );
  twobit_label( 1744, compiled_block_1_1744 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1745, compiled_block_1_1745 );
  twobit_invoke( 1 );
  twobit_label( 1745, compiled_block_1_1745 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 3 );
  twobit_global( 6 ); /* length */
  twobit_setrtn( 1746, compiled_block_1_1746 );
  twobit_invoke( 1 );
  twobit_label( 1746, compiled_block_1_1746 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_branchf_623( 4, 32, compiled_temp_1_32, 1748, compiled_block_1_1748 ); /* internal:branchf-= */
  twobit_load( 1, 2 );
  twobit_load( 2, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_setrtn( 1749, compiled_block_1_1749 );
  twobit_branch( 1735, compiled_block_1_1735 );
  twobit_label( 1749, compiled_block_1_1749 );
  twobit_load( 0, 0 );
  twobit_skip( 1747, compiled_block_1_1747 );
  twobit_label( 1748, compiled_block_1_1748 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_global( 10 ); /* ex:syntax-violation */
  twobit_setrtn( 1750, compiled_block_1_1750 );
  twobit_invoke( 4 );
  twobit_label( 1750, compiled_block_1_1750 );
  twobit_load( 0, 0 );
  twobit_label( 1747, compiled_block_1_1747 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 3, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1751, compiled_block_1_1751 );
  twobit_invoke( 5 );
  twobit_label( 1751, compiled_block_1_1751 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 3, 4 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_global( 12 ); /* append */
  twobit_setrtn( 1752, compiled_block_1_1752 );
  twobit_invoke( 2 );
  twobit_label( 1752, compiled_block_1_1752 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 1743, compiled_block_1_1743 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_pop( 5 );
  twobit_jump( 2, 1632, compiled_block_1_1632 );
  twobit_label( 1741, compiled_block_1_1741 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_pop( 5 );
  twobit_jump( 2, 1632, compiled_block_1_1632 );
  twobit_label( 1738, compiled_block_1_1738 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_jump( 2, 1632, compiled_block_1_1632 );
  twobit_label( 1735, compiled_block_1_1735 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1757, compiled_block_1_1757 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1756, compiled_block_1_1756 );
  twobit_label( 1757, compiled_block_1_1757 );
  twobit_reg( 2 );
  twobit_op1_10(); /* null? */
  twobit_label( 1756, compiled_block_1_1756 );
  twobit_branchf( 1759, compiled_block_1_1759 );
  twobit_movereg( 3, 1 );
  twobit_global( 13 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1759, compiled_block_1_1759 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 3, 4 );
  twobit_reg_op1_check_652(reg(1),1761,compiled_block_1_1761); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg_op1_check_652(reg(2),1762,compiled_block_1_1762); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 1 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 30 );
  twobit_reg( 2 );
  twobit_op2_58( 30 ); /* cons */
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1763, compiled_block_1_1763 );
  twobit_invoke( 5 );
  twobit_label( 1763, compiled_block_1_1763 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_load( 1, 2 );
  twobit_load( 3, 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_pop( 4 );
  twobit_branch( 1735, compiled_block_1_1735 );
  twobit_label( 1761, compiled_block_1_1761 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_label( 1762, compiled_block_1_1762 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_26( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1771, compiled_block_1_1771 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1773, compiled_block_1_1773 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1775, compiled_block_1_1775 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_return();
  twobit_label( 1775, compiled_block_1_1775 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1773, compiled_block_1_1773 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1771, compiled_block_1_1771 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_27( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1796, compiled_block_1_1796 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_29, 2, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1831, compiled_block_1_1831 ); /* internal:branchf-null? */
  twobit_const( 3 );
  twobit_skip( 1830, compiled_block_1_1830 );
  twobit_label( 1831, compiled_block_1_1831 );
  twobit_movereg( 1, 3 );
  twobit_global( 4 ); /* map */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* list */
  twobit_setreg( 2 );
  twobit_global( 6 ); /* apply */
  twobit_setrtn( 1832, compiled_block_1_1832 );
  twobit_invoke( 3 );
  twobit_label( 1832, compiled_block_1_1832 );
  twobit_load( 0, 0 );
  twobit_label( 1830, compiled_block_1_1830 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 6 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1796, compiled_block_1_1796 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_jump( 1, 1633, compiled_block_1_1633 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_29( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 1, 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1801, compiled_block_1_1801 ); /* internal:branchf-pair? */
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 4 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1802, compiled_block_1_1802 );
  twobit_invoke( 1 );
  twobit_label( 1802, compiled_block_1_1802 );
  twobit_load( 0, 0 );
  twobit_branchf( 1804, compiled_block_1_1804 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1805, compiled_block_1_1805 );
  twobit_invoke( 5 );
  twobit_label( 1805, compiled_block_1_1805 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 1, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_setrtn( 1806, compiled_block_1_1806 );
  twobit_branch( 1798, compiled_block_1_1798 );
  twobit_label( 1806, compiled_block_1_1806 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1807, compiled_block_1_1807 );
  twobit_invoke( 5 );
  twobit_label( 1807, compiled_block_1_1807 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 3, 2 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_load( 1, 1 );
  twobit_global( 7 ); /* length */
  twobit_setrtn( 1808, compiled_block_1_1808 );
  twobit_invoke( 1 );
  twobit_label( 1808, compiled_block_1_1808 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 4 );
  twobit_global( 7 ); /* length */
  twobit_setrtn( 1809, compiled_block_1_1809 );
  twobit_invoke( 1 );
  twobit_label( 1809, compiled_block_1_1809 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_branchf_623( 4, 30, compiled_temp_1_30, 1811, compiled_block_1_1811 ); /* internal:branchf-= */
  twobit_load( 1, 1 );
  twobit_load( 2, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_setrtn( 1812, compiled_block_1_1812 );
  twobit_branch( 1797, compiled_block_1_1797 );
  twobit_label( 1812, compiled_block_1_1812 );
  twobit_load( 0, 0 );
  twobit_skip( 1810, compiled_block_1_1810 );
  twobit_label( 1811, compiled_block_1_1811 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_const( 9 );
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 3 );
  twobit_global( 11 ); /* ex:syntax-violation */
  twobit_setrtn( 1813, compiled_block_1_1813 );
  twobit_invoke( 4 );
  twobit_label( 1813, compiled_block_1_1813 );
  twobit_load( 0, 0 );
  twobit_label( 1810, compiled_block_1_1810 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 12 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1804, compiled_block_1_1804 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_pop( 7 );
  twobit_jump( 2, 1633, compiled_block_1_1633 );
  twobit_label( 1801, compiled_block_1_1801 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_jump( 2, 1633, compiled_block_1_1633 );
  twobit_label( 1797, compiled_block_1_1797 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1817, compiled_block_1_1817 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1816, compiled_block_1_1816 );
  twobit_label( 1817, compiled_block_1_1817 );
  twobit_reg( 2 );
  twobit_op1_10(); /* null? */
  twobit_label( 1816, compiled_block_1_1816 );
  twobit_branchf( 1819, compiled_block_1_1819 );
  twobit_movereg( 3, 1 );
  twobit_global( 13 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1819, compiled_block_1_1819 );
  twobit_reg_op1_check_652(reg(2),1821,compiled_block_1_1821); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(1),1822,compiled_block_1_1822); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op2_58( 30 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 31 );
  twobit_op2_58( 4 ); /* cons */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_branch( 1797, compiled_block_1_1797 );
  twobit_label( 1798, compiled_block_1_1798 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1825, compiled_block_1_1825 ); /* internal:branchf-null? */
  twobit_movereg( 2, 1 );
  twobit_global( 13 ); /* reverse */
  twobit_invoke( 1 );
  twobit_label( 1825, compiled_block_1_1825 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 2, 3 );
  twobit_reg_op1_check_652(reg(1),1827,compiled_block_1_1827); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1828, compiled_block_1_1828 );
  twobit_invoke( 5 );
  twobit_label( 1828, compiled_block_1_1828 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_pop( 3 );
  twobit_branch( 1798, compiled_block_1_1798 );
  twobit_label( 1827, compiled_block_1_1827 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_label( 1821, compiled_block_1_1821 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 1822, compiled_block_1_1822 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_28( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1836, compiled_block_1_1836 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1838, compiled_block_1_1838 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1840, compiled_block_1_1840 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_return();
  twobit_label( 1840, compiled_block_1_1840 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1838, compiled_block_1_1838 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1836, compiled_block_1_1836 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_19( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2759, compiled_block_1_2759 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2761, compiled_block_1_2761 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2763, compiled_block_1_2763 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2765, compiled_block_1_2765 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2767, compiled_block_1_2767 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_op1_branchf_610( 2769, compiled_block_1_2769 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2771, compiled_block_1_2771 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 2 );
  twobit_op2_58( 31 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 2772, compiled_block_1_2772 );
  twobit_invoke( 5 );
  twobit_label( 2772, compiled_block_1_2772 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 2771, compiled_block_1_2771 );
  twobit_branch( 2756, compiled_block_1_2756 );
  twobit_label( 2769, compiled_block_1_2769 );
  twobit_branch( 2756, compiled_block_1_2756 );
  twobit_label( 2767, compiled_block_1_2767 );
  twobit_branch( 2756, compiled_block_1_2756 );
  twobit_label( 2765, compiled_block_1_2765 );
  twobit_branch( 2756, compiled_block_1_2756 );
  twobit_label( 2763, compiled_block_1_2763 );
  twobit_branch( 2756, compiled_block_1_2756 );
  twobit_label( 2761, compiled_block_1_2761 );
  twobit_branch( 2756, compiled_block_1_2756 );
  twobit_label( 2759, compiled_block_1_2759 );
  twobit_branch( 2756, compiled_block_1_2756 );
  twobit_label( 2755, compiled_block_1_2755 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2781, compiled_block_1_2781 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2783, compiled_block_1_2783 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2785, compiled_block_1_2785 ); /* internal:branchf-pair? */
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 8 );
  twobit_store( 3, 7 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 6 );
  twobit_movereg( 2, 1 );
  twobit_global( 5 ); /* list? */
  twobit_setrtn( 2786, compiled_block_1_2786 );
  twobit_invoke( 1 );
  twobit_label( 2786, compiled_block_1_2786 );
  twobit_load( 0, 0 );
  twobit_branchf( 2788, compiled_block_1_2788 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2790, compiled_block_1_2790 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2792, compiled_block_1_2792 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 2794, compiled_block_1_2794 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2796, compiled_block_1_2796 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2798, compiled_block_1_2798 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2800, compiled_block_1_2800 ); /* internal:branchf-null? */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 5 ); /* list? */
  twobit_setrtn( 2801, compiled_block_1_2801 );
  twobit_invoke( 1 );
  twobit_label( 2801, compiled_block_1_2801 );
  twobit_load( 0, 0 );
  twobit_branchf( 2803, compiled_block_1_2803 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2805, compiled_block_1_2805 ); /* internal:branchf-null? */
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 2806, compiled_block_1_2806 );
  twobit_invoke( 5 );
  twobit_label( 2806, compiled_block_1_2806 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 4 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_stack( 5 );
  twobit_op2_58( 2 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 1 ); /* () */
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 6 );
  twobit_global( 8 ); /* append */
  twobit_setrtn( 2807, compiled_block_1_2807 );
  twobit_invoke( 2 );
  twobit_label( 2807, compiled_block_1_2807 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 2805, compiled_block_1_2805 );
  twobit_load( 1, 8 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 2803, compiled_block_1_2803 );
  twobit_load( 1, 8 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 2800, compiled_block_1_2800 );
  twobit_load( 1, 8 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 2798, compiled_block_1_2798 );
  twobit_load( 1, 8 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 2796, compiled_block_1_2796 );
  twobit_load( 1, 8 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 2794, compiled_block_1_2794 );
  twobit_load( 1, 8 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 2792, compiled_block_1_2792 );
  twobit_load( 1, 8 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 2790, compiled_block_1_2790 );
  twobit_load( 1, 8 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 2788, compiled_block_1_2788 );
  twobit_load( 1, 8 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 2785, compiled_block_1_2785 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2783, compiled_block_1_2783 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2781, compiled_block_1_2781 );
  twobit_global( 9 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2756, compiled_block_1_2756 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2821, compiled_block_1_2821 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2823, compiled_block_1_2823 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2825, compiled_block_1_2825 ); /* internal:branchf-pair? */
  twobit_save( 9 );
  twobit_store( 0, 0 );
  twobit_store( 1, 9 );
  twobit_store( 3, 8 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 7 );
  twobit_movereg( 2, 1 );
  twobit_global( 5 ); /* list? */
  twobit_setrtn( 2826, compiled_block_1_2826 );
  twobit_invoke( 1 );
  twobit_label( 2826, compiled_block_1_2826 );
  twobit_load( 0, 0 );
  twobit_branchf( 2828, compiled_block_1_2828 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2830, compiled_block_1_2830 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2832, compiled_block_1_2832 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 4 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 2834, compiled_block_1_2834 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 3 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2836, compiled_block_1_2836 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2838, compiled_block_1_2838 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 10 ); /* ex:identifier? */
  twobit_setrtn( 2839, compiled_block_1_2839 );
  twobit_invoke( 1 );
  twobit_label( 2839, compiled_block_1_2839 );
  twobit_load( 0, 0 );
  twobit_branchf( 2841, compiled_block_1_2841 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 2842, compiled_block_1_2842 );
  twobit_invoke( 5 );
  twobit_label( 2842, compiled_block_1_2842 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 13 ); /* ex:free-identifier=? */
  twobit_setrtn( 2843, compiled_block_1_2843 );
  twobit_invoke( 2 );
  twobit_label( 2843, compiled_block_1_2843 );
  twobit_load( 0, 0 );
  twobit_skip( 2840, compiled_block_1_2840 );
  twobit_label( 2841, compiled_block_1_2841 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2840, compiled_block_1_2840 );
  twobit_branchf( 2845, compiled_block_1_2845 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2847, compiled_block_1_2847 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2849, compiled_block_1_2849 ); /* internal:branchf-null? */
  twobit_stack( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2851, compiled_block_1_2851 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2853, compiled_block_1_2853 ); /* internal:branchf-null? */
  twobit_stack( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* list? */
  twobit_setrtn( 2854, compiled_block_1_2854 );
  twobit_invoke( 1 );
  twobit_label( 2854, compiled_block_1_2854 );
  twobit_load( 0, 0 );
  twobit_branchf( 2856, compiled_block_1_2856 );
  twobit_stack( 5 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2858, compiled_block_1_2858 ); /* internal:branchf-null? */
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 2859, compiled_block_1_2859 );
  twobit_invoke( 5 );
  twobit_label( 2859, compiled_block_1_2859 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 3 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_stack( 1 );
  twobit_op2_58( 2 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 1 ); /* () */
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 7 );
  twobit_global( 8 ); /* append */
  twobit_setrtn( 2860, compiled_block_1_2860 );
  twobit_invoke( 2 );
  twobit_label( 2860, compiled_block_1_2860 );
  twobit_load( 0, 0 );
  twobit_load( 3, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 9 );
  twobit_return();
  twobit_label( 2858, compiled_block_1_2858 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 2755, compiled_block_1_2755 );
  twobit_label( 2856, compiled_block_1_2856 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 2755, compiled_block_1_2755 );
  twobit_label( 2853, compiled_block_1_2853 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 2755, compiled_block_1_2755 );
  twobit_label( 2851, compiled_block_1_2851 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 2755, compiled_block_1_2755 );
  twobit_label( 2849, compiled_block_1_2849 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 2755, compiled_block_1_2755 );
  twobit_label( 2847, compiled_block_1_2847 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 2755, compiled_block_1_2755 );
  twobit_label( 2845, compiled_block_1_2845 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 2755, compiled_block_1_2755 );
  twobit_label( 2838, compiled_block_1_2838 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 2755, compiled_block_1_2755 );
  twobit_label( 2836, compiled_block_1_2836 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 2755, compiled_block_1_2755 );
  twobit_label( 2834, compiled_block_1_2834 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 2755, compiled_block_1_2755 );
  twobit_label( 2832, compiled_block_1_2832 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 2755, compiled_block_1_2755 );
  twobit_label( 2830, compiled_block_1_2830 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 2755, compiled_block_1_2755 );
  twobit_label( 2828, compiled_block_1_2828 );
  twobit_load( 1, 9 );
  twobit_pop( 9 );
  twobit_branch( 2755, compiled_block_1_2755 );
  twobit_label( 2825, compiled_block_1_2825 );
  twobit_branch( 2755, compiled_block_1_2755 );
  twobit_label( 2823, compiled_block_1_2823 );
  twobit_branch( 2755, compiled_block_1_2755 );
  twobit_label( 2821, compiled_block_1_2821 );
  twobit_branch( 2755, compiled_block_1_2755 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_20( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2879, compiled_block_1_2879 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2881, compiled_block_1_2881 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2883, compiled_block_1_2883 ); /* internal:branchf-null? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 2884, compiled_block_1_2884 );
  twobit_invoke( 5 );
  twobit_label( 2884, compiled_block_1_2884 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 2885, compiled_block_1_2885 );
  twobit_invoke( 5 );
  twobit_label( 2885, compiled_block_1_2885 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 2886, compiled_block_1_2886 );
  twobit_invoke( 5 );
  twobit_label( 2886, compiled_block_1_2886 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 2883, compiled_block_1_2883 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2881, compiled_block_1_2881 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2879, compiled_block_1_2879 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_21( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2892, compiled_block_1_2892 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2894, compiled_block_1_2894 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2896, compiled_block_1_2896 ); /* internal:branchf-null? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 2897, compiled_block_1_2897 );
  twobit_invoke( 5 );
  twobit_label( 2897, compiled_block_1_2897 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 2898, compiled_block_1_2898 );
  twobit_invoke( 5 );
  twobit_label( 2898, compiled_block_1_2898 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 2899, compiled_block_1_2899 );
  twobit_invoke( 5 );
  twobit_label( 2899, compiled_block_1_2899 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 2896, compiled_block_1_2896 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2894, compiled_block_1_2894 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2892, compiled_block_1_2892 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_22( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2907, compiled_block_1_2907 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2909, compiled_block_1_2909 ); /* internal:branchf-pair? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 2910, compiled_block_1_2910 );
  twobit_invoke( 1 );
  twobit_label( 2910, compiled_block_1_2910 );
  twobit_load( 0, 0 );
  twobit_branchf( 2912, compiled_block_1_2912 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2914, compiled_block_1_2914 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 2915, compiled_block_1_2915 );
  twobit_invoke( 1 );
  twobit_label( 2915, compiled_block_1_2915 );
  twobit_load( 0, 0 );
  twobit_branchf( 2917, compiled_block_1_2917 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 2918, compiled_block_1_2918 );
  twobit_invoke( 5 );
  twobit_label( 2918, compiled_block_1_2918 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2917, compiled_block_1_2917 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 2904, compiled_block_1_2904 );
  twobit_label( 2914, compiled_block_1_2914 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 2904, compiled_block_1_2904 );
  twobit_label( 2912, compiled_block_1_2912 );
  twobit_load( 1, 4 );
  twobit_pop( 4 );
  twobit_branch( 2904, compiled_block_1_2904 );
  twobit_label( 2909, compiled_block_1_2909 );
  twobit_branch( 2904, compiled_block_1_2904 );
  twobit_label( 2907, compiled_block_1_2907 );
  twobit_label( 2904, compiled_block_1_2904 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2925, compiled_block_1_2925 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2927, compiled_block_1_2927 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2929, compiled_block_1_2929 ); /* internal:branchf-pair? */
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 5 );
  twobit_store( 3, 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 2930, compiled_block_1_2930 );
  twobit_invoke( 1 );
  twobit_label( 2930, compiled_block_1_2930 );
  twobit_load( 0, 0 );
  twobit_branchf( 2932, compiled_block_1_2932 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2934, compiled_block_1_2934 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 2935, compiled_block_1_2935 );
  twobit_invoke( 1 );
  twobit_label( 2935, compiled_block_1_2935 );
  twobit_load( 0, 0 );
  twobit_branchf( 2937, compiled_block_1_2937 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 2938, compiled_block_1_2938 );
  twobit_invoke( 5 );
  twobit_label( 2938, compiled_block_1_2938 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 5 );
  twobit_return();
  twobit_label( 2937, compiled_block_1_2937 );
  twobit_load( 1, 5 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 2934, compiled_block_1_2934 );
  twobit_load( 1, 5 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 2932, compiled_block_1_2932 );
  twobit_load( 1, 5 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_pop( 5 );
  twobit_invoke( 1 );
  twobit_label( 2929, compiled_block_1_2929 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2927, compiled_block_1_2927 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2925, compiled_block_1_2925 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_23( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2947, compiled_block_1_2947 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2949, compiled_block_1_2949 ); /* internal:branchf-pair? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 2950, compiled_block_1_2950 );
  twobit_invoke( 1 );
  twobit_label( 2950, compiled_block_1_2950 );
  twobit_load( 0, 0 );
  twobit_branchf( 2952, compiled_block_1_2952 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2954, compiled_block_1_2954 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 2955, compiled_block_1_2955 );
  twobit_invoke( 1 );
  twobit_label( 2955, compiled_block_1_2955 );
  twobit_load( 0, 0 );
  twobit_branchf( 2957, compiled_block_1_2957 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 2958, compiled_block_1_2958 );
  twobit_invoke( 5 );
  twobit_label( 2958, compiled_block_1_2958 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2957, compiled_block_1_2957 );
  twobit_load( 1, 4 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 2954, compiled_block_1_2954 );
  twobit_load( 1, 4 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 2952, compiled_block_1_2952 );
  twobit_load( 1, 4 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 2949, compiled_block_1_2949 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2947, compiled_block_1_2947 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_24( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 2966, compiled_block_1_2966 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2968, compiled_block_1_2968 ); /* internal:branchf-pair? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 2969, compiled_block_1_2969 );
  twobit_invoke( 1 );
  twobit_label( 2969, compiled_block_1_2969 );
  twobit_load( 0, 0 );
  twobit_branchf( 2971, compiled_block_1_2971 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2973, compiled_block_1_2973 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 2974, compiled_block_1_2974 );
  twobit_invoke( 1 );
  twobit_label( 2974, compiled_block_1_2974 );
  twobit_load( 0, 0 );
  twobit_branchf( 2976, compiled_block_1_2976 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 2977, compiled_block_1_2977 );
  twobit_invoke( 5 );
  twobit_label( 2977, compiled_block_1_2977 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 2976, compiled_block_1_2976 );
  twobit_load( 1, 4 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 2973, compiled_block_1_2973 );
  twobit_load( 1, 4 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 2971, compiled_block_1_2971 );
  twobit_load( 1, 4 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 2968, compiled_block_1_2968 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 2966, compiled_block_1_2966 );
  twobit_global( 6 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 2 ); /*  unvector~1ay%kV~37370 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 3 ); /*  unlist~1ay%kV~37369 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 4 ); /*  uncons-cons~1ay%kV~37368 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 5 ); /*  uncons-4~1ay%kV~37367 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 6 ); /*  uncons-3~1ay%kV~37366 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 7 ); /*  uncons-2~1ay%kV~37365 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 8 ); /*  uncons~1ay%kV~37364 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 9 ); /*  i:undefined~1ay%kV~36494 */
  twobit_const( 10 );
  twobit_setglbl( 9 ); /*  i:undefined~1ay%kV~36494 */
  twobit_lambda( compiled_start_1_4, 12, 0 );
  twobit_setglbl( 8 ); /*  uncons~1ay%kV~37364 */
  twobit_lambda( compiled_start_1_5, 14, 0 );
  twobit_setglbl( 7 ); /*  uncons-2~1ay%kV~37365 */
  twobit_lambda( compiled_start_1_6, 16, 0 );
  twobit_setglbl( 6 ); /*  uncons-3~1ay%kV~37366 */
  twobit_lambda( compiled_start_1_7, 18, 0 );
  twobit_setglbl( 5 ); /*  uncons-4~1ay%kV~37367 */
  twobit_lambda( compiled_start_1_8, 20, 0 );
  twobit_setglbl( 4 ); /*  uncons-cons~1ay%kV~37368 */
  twobit_lambda( compiled_start_1_9, 22, 0 );
  twobit_setglbl( 3 ); /*  unlist~1ay%kV~37369 */
  twobit_lambda( compiled_start_1_10, 24, 0 );
  twobit_setglbl( 2 ); /*  unvector~1ay%kV~37370 */
  twobit_global( 25 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op1_check_652(reg(1),2985,compiled_block_1_2985); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 2985, compiled_block_1_2985 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op1_check_652(reg(1),2987,compiled_block_1_2987); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),2988,compiled_block_1_2988); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 3 );
  twobit_label( 2987, compiled_block_1_2987 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_label( 2988, compiled_block_1_2988 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_6( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg_op1_check_652(reg(1),2990,compiled_block_1_2990); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg_op1_check_652(reg(4),2991,compiled_block_1_2991); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg_op1_check_652(reg(3),2992,compiled_block_1_2992); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* values */
  twobit_pop( 1 );
  twobit_invoke( 4 );
  twobit_label( 2992, compiled_block_1_2992 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_label( 2990, compiled_block_1_2990 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_label( 2991, compiled_block_1_2991 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_7( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg_op1_check_652(reg(1),2994,compiled_block_1_2994); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg_op1_check_652(reg(4),2995,compiled_block_1_2995); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg_op1_check_652(reg(3),2996,compiled_block_1_2996); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg_op1_check_652(reg(2),2997,compiled_block_1_2997); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_movereg( 31, 5 );
  twobit_global( 1 ); /* values */
  twobit_pop( 1 );
  twobit_invoke( 5 );
  twobit_label( 2996, compiled_block_1_2996 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_label( 2994, compiled_block_1_2994 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_label( 2995, compiled_block_1_2995 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_label( 2997, compiled_block_1_2997 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_8( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op1_check_652(reg(1),2999,compiled_block_1_2999); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),3000,compiled_block_1_3000); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 3 );
  twobit_label( 2999, compiled_block_1_2999 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_label( 3000, compiled_block_1_3000 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_9( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /* values */
  twobit_setreg( 1 );
  twobit_global( 2 ); /* apply */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_10( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* vector->list */
  twobit_setrtn( 3003, compiled_block_1_3003 );
  twobit_invoke( 1 );
  twobit_label( 3003, compiled_block_1_3003 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* values */
  twobit_setreg( 1 );
  twobit_global( 3 ); /* apply */
  twobit_pop( 0 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


RTYPE twobit_thunk_8a5886548e0ec0115bfa14e6bc850c23_0(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_1_0(CONT_ACTUALS));
}
static RTYPE compiled_block_2_1004( CONT_PARAMS );
static RTYPE compiled_block_2_1003( CONT_PARAMS );
static RTYPE compiled_start_2_0( CONT_PARAMS );
static RTYPE compiled_start_2_3( CONT_PARAMS );
static RTYPE compiled_start_2_2( CONT_PARAMS );
static RTYPE compiled_start_2_1( CONT_PARAMS );

static RTYPE compiled_start_2_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_2_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_2_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1003, compiled_block_2_1003 );
  twobit_invoke( 8 );
  twobit_label( 1003, compiled_block_2_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1004, compiled_block_2_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_2_1004 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_8a5886548e0ec0115bfa14e6bc850c23_1(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_2_0(CONT_ACTUALS));
}
codeptr_t CDECL twobit_load_table[] = { 
  twobit_thunk_8a5886548e0ec0115bfa14e6bc850c23_0,
  twobit_thunk_8a5886548e0ec0115bfa14e6bc850c23_1,
  0  /* The table may be empty; some compilers complain */
};

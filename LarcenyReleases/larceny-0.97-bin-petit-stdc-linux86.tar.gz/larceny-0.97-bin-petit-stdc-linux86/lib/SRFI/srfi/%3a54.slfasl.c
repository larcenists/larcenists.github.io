/* Generated from /home/henchman/larcenytest/larceny-petit-Nightly-2009-08-19/larceny_src/lib/SRFI/srfi/%3a54.slfasl */
#include "petit-instr.h"

static RTYPE compiled_block_1_2515( CONT_PARAMS );
static RTYPE compiled_block_1_2514( CONT_PARAMS );
static RTYPE compiled_start_1_0( CONT_PARAMS );
static RTYPE compiled_start_1_3( CONT_PARAMS );
static RTYPE compiled_block_1_2239( CONT_PARAMS );
static RTYPE compiled_block_1_2362( CONT_PARAMS );
static RTYPE compiled_block_1_2377( CONT_PARAMS );
static RTYPE compiled_block_1_1940( CONT_PARAMS );
static RTYPE compiled_block_1_2305( CONT_PARAMS );
static RTYPE compiled_block_1_1978( CONT_PARAMS );
static RTYPE compiled_block_1_2378( CONT_PARAMS );
static RTYPE compiled_block_1_2035( CONT_PARAMS );
static RTYPE compiled_block_1_2184( CONT_PARAMS );
static RTYPE compiled_block_1_2511( CONT_PARAMS );
static RTYPE compiled_block_1_2203( CONT_PARAMS );
static RTYPE compiled_block_1_2509( CONT_PARAMS );
static RTYPE compiled_block_1_2507( CONT_PARAMS );
static RTYPE compiled_block_1_2508( CONT_PARAMS );
static RTYPE compiled_temp_1_84( CONT_PARAMS );
static RTYPE compiled_block_1_2505( CONT_PARAMS );
static RTYPE compiled_temp_1_83( CONT_PARAMS );
static RTYPE compiled_temp_1_82( CONT_PARAMS );
static RTYPE compiled_block_1_2502( CONT_PARAMS );
static RTYPE compiled_block_1_2503( CONT_PARAMS );
static RTYPE compiled_temp_1_81( CONT_PARAMS );
static RTYPE compiled_temp_1_80( CONT_PARAMS );
static RTYPE compiled_block_1_2499( CONT_PARAMS );
static RTYPE compiled_block_1_2500( CONT_PARAMS );
static RTYPE compiled_block_1_2501( CONT_PARAMS );
static RTYPE compiled_block_1_2479( CONT_PARAMS );
static RTYPE compiled_block_1_2480( CONT_PARAMS );
static RTYPE compiled_block_1_2498( CONT_PARAMS );
static RTYPE compiled_block_1_2497( CONT_PARAMS );
static RTYPE compiled_block_1_2483( CONT_PARAMS );
static RTYPE compiled_block_1_2490( CONT_PARAMS );
static RTYPE compiled_block_1_2484( CONT_PARAMS );
static RTYPE compiled_block_1_2481( CONT_PARAMS );
static RTYPE compiled_block_1_2475( CONT_PARAMS );
static RTYPE compiled_block_1_2476( CONT_PARAMS );
static RTYPE compiled_block_1_2478( CONT_PARAMS );
static RTYPE compiled_block_1_2477( CONT_PARAMS );
static RTYPE compiled_block_1_2473( CONT_PARAMS );
static RTYPE compiled_block_1_2474( CONT_PARAMS );
static RTYPE compiled_block_1_2443( CONT_PARAMS );
static RTYPE compiled_block_1_2472( CONT_PARAMS );
static RTYPE compiled_block_1_2461( CONT_PARAMS );
static RTYPE compiled_block_1_2471( CONT_PARAMS );
static RTYPE compiled_block_1_2468( CONT_PARAMS );
static RTYPE compiled_block_1_2470( CONT_PARAMS );
static RTYPE compiled_block_1_2465( CONT_PARAMS );
static RTYPE compiled_block_1_2466( CONT_PARAMS );
static RTYPE compiled_block_1_2463( CONT_PARAMS );
static RTYPE compiled_block_1_2464( CONT_PARAMS );
static RTYPE compiled_block_1_2444( CONT_PARAMS );
static RTYPE compiled_block_1_2459( CONT_PARAMS );
static RTYPE compiled_block_1_2458( CONT_PARAMS );
static RTYPE compiled_block_1_2455( CONT_PARAMS );
static RTYPE compiled_block_1_2456( CONT_PARAMS );
static RTYPE compiled_block_1_2451( CONT_PARAMS );
static RTYPE compiled_block_1_2453( CONT_PARAMS );
static RTYPE compiled_block_1_2448( CONT_PARAMS );
static RTYPE compiled_block_1_2449( CONT_PARAMS );
static RTYPE compiled_block_1_2446( CONT_PARAMS );
static RTYPE compiled_block_1_2447( CONT_PARAMS );
static RTYPE compiled_block_1_2204( CONT_PARAMS );
static RTYPE compiled_block_1_2442( CONT_PARAMS );
static RTYPE compiled_block_1_2425( CONT_PARAMS );
static RTYPE compiled_block_1_2441( CONT_PARAMS );
static RTYPE compiled_block_1_2428( CONT_PARAMS );
static RTYPE compiled_block_1_2440( CONT_PARAMS );
static RTYPE compiled_block_1_2431( CONT_PARAMS );
static RTYPE compiled_block_1_2439( CONT_PARAMS );
static RTYPE compiled_block_1_2438( CONT_PARAMS );
static RTYPE compiled_block_1_2437( CONT_PARAMS );
static RTYPE compiled_block_1_2435( CONT_PARAMS );
static RTYPE compiled_block_1_2436( CONT_PARAMS );
static RTYPE compiled_block_1_2432( CONT_PARAMS );
static RTYPE compiled_temp_1_77( CONT_PARAMS );
static RTYPE compiled_block_1_2433( CONT_PARAMS );
static RTYPE compiled_temp_1_76( CONT_PARAMS );
static RTYPE compiled_block_1_2429( CONT_PARAMS );
static RTYPE compiled_block_1_2426( CONT_PARAMS );
static RTYPE compiled_temp_1_75( CONT_PARAMS );
static RTYPE compiled_block_1_2423( CONT_PARAMS );
static RTYPE compiled_temp_1_74( CONT_PARAMS );
static RTYPE compiled_temp_1_73( CONT_PARAMS );
static RTYPE compiled_block_1_2420( CONT_PARAMS );
static RTYPE compiled_block_1_2421( CONT_PARAMS );
static RTYPE compiled_temp_1_72( CONT_PARAMS );
static RTYPE compiled_temp_1_71( CONT_PARAMS );
static RTYPE compiled_block_1_2417( CONT_PARAMS );
static RTYPE compiled_block_1_2418( CONT_PARAMS );
static RTYPE compiled_block_1_2419( CONT_PARAMS );
static RTYPE compiled_block_1_2397( CONT_PARAMS );
static RTYPE compiled_block_1_2398( CONT_PARAMS );
static RTYPE compiled_block_1_2416( CONT_PARAMS );
static RTYPE compiled_block_1_2415( CONT_PARAMS );
static RTYPE compiled_block_1_2401( CONT_PARAMS );
static RTYPE compiled_block_1_2408( CONT_PARAMS );
static RTYPE compiled_block_1_2402( CONT_PARAMS );
static RTYPE compiled_block_1_2399( CONT_PARAMS );
static RTYPE compiled_block_1_2389( CONT_PARAMS );
static RTYPE compiled_block_1_2390( CONT_PARAMS );
static RTYPE compiled_block_1_2396( CONT_PARAMS );
static RTYPE compiled_block_1_2395( CONT_PARAMS );
static RTYPE compiled_temp_1_68( CONT_PARAMS );
static RTYPE compiled_block_1_2391( CONT_PARAMS );
static RTYPE compiled_block_1_2394( CONT_PARAMS );
static RTYPE compiled_temp_1_67( CONT_PARAMS );
static RTYPE compiled_temp_1_66( CONT_PARAMS );
static RTYPE compiled_block_1_2392( CONT_PARAMS );
static RTYPE compiled_block_1_2388( CONT_PARAMS );
static RTYPE compiled_block_1_2208( CONT_PARAMS );
static RTYPE compiled_block_1_2387( CONT_PARAMS );
static RTYPE compiled_block_1_2368( CONT_PARAMS );
static RTYPE compiled_block_1_2386( CONT_PARAMS );
static RTYPE compiled_block_1_2371( CONT_PARAMS );
static RTYPE compiled_block_1_2385( CONT_PARAMS );
static RTYPE compiled_block_1_2374( CONT_PARAMS );
static RTYPE compiled_block_1_2384( CONT_PARAMS );
static RTYPE compiled_block_1_2383( CONT_PARAMS );
static RTYPE compiled_block_1_2382( CONT_PARAMS );
static RTYPE compiled_block_1_2380( CONT_PARAMS );
static RTYPE compiled_block_1_2381( CONT_PARAMS );
static RTYPE compiled_block_1_2375( CONT_PARAMS );
static RTYPE compiled_temp_1_65( CONT_PARAMS );
static RTYPE compiled_block_1_2376( CONT_PARAMS );
static RTYPE compiled_temp_1_64( CONT_PARAMS );
static RTYPE compiled_block_1_2372( CONT_PARAMS );
static RTYPE compiled_block_1_2369( CONT_PARAMS );
static RTYPE compiled_temp_1_63( CONT_PARAMS );
static RTYPE compiled_block_1_2366( CONT_PARAMS );
static RTYPE compiled_temp_1_62( CONT_PARAMS );
static RTYPE compiled_temp_1_61( CONT_PARAMS );
static RTYPE compiled_block_1_2363( CONT_PARAMS );
static RTYPE compiled_block_1_2364( CONT_PARAMS );
static RTYPE compiled_temp_1_60( CONT_PARAMS );
static RTYPE compiled_temp_1_59( CONT_PARAMS );
static RTYPE compiled_block_1_2359( CONT_PARAMS );
static RTYPE compiled_block_1_2360( CONT_PARAMS );
static RTYPE compiled_block_1_2361( CONT_PARAMS );
static RTYPE compiled_block_1_2339( CONT_PARAMS );
static RTYPE compiled_block_1_2340( CONT_PARAMS );
static RTYPE compiled_block_1_2358( CONT_PARAMS );
static RTYPE compiled_block_1_2357( CONT_PARAMS );
static RTYPE compiled_block_1_2343( CONT_PARAMS );
static RTYPE compiled_block_1_2350( CONT_PARAMS );
static RTYPE compiled_block_1_2344( CONT_PARAMS );
static RTYPE compiled_block_1_2341( CONT_PARAMS );
static RTYPE compiled_block_1_2338( CONT_PARAMS );
static RTYPE compiled_block_1_2336( CONT_PARAMS );
static RTYPE compiled_block_1_2337( CONT_PARAMS );
static RTYPE compiled_block_1_2333( CONT_PARAMS );
static RTYPE compiled_block_1_2334( CONT_PARAMS );
static RTYPE compiled_block_1_2335( CONT_PARAMS );
static RTYPE compiled_block_1_2332( CONT_PARAMS );
static RTYPE compiled_block_1_2330( CONT_PARAMS );
static RTYPE compiled_block_1_2331( CONT_PARAMS );
static RTYPE compiled_block_1_2326( CONT_PARAMS );
static RTYPE compiled_block_1_2329( CONT_PARAMS );
static RTYPE compiled_block_1_2327( CONT_PARAMS );
static RTYPE compiled_block_1_2314( CONT_PARAMS );
static RTYPE compiled_block_1_2315( CONT_PARAMS );
static RTYPE compiled_block_1_2321( CONT_PARAMS );
static RTYPE compiled_temp_1_56( CONT_PARAMS );
static RTYPE compiled_block_1_2325( CONT_PARAMS );
static RTYPE compiled_temp_1_55( CONT_PARAMS );
static RTYPE compiled_block_1_2323( CONT_PARAMS );
static RTYPE compiled_block_1_2319( CONT_PARAMS );
static RTYPE compiled_block_1_2317( CONT_PARAMS );
static RTYPE compiled_block_1_2312( CONT_PARAMS );
static RTYPE compiled_block_1_2313( CONT_PARAMS );
static RTYPE compiled_block_1_2303( CONT_PARAMS );
static RTYPE compiled_block_1_2304( CONT_PARAMS );
static RTYPE compiled_block_1_2311( CONT_PARAMS );
static RTYPE compiled_block_1_2310( CONT_PARAMS );
static RTYPE compiled_temp_1_54( CONT_PARAMS );
static RTYPE compiled_block_1_2306( CONT_PARAMS );
static RTYPE compiled_block_1_2309( CONT_PARAMS );
static RTYPE compiled_temp_1_53( CONT_PARAMS );
static RTYPE compiled_temp_1_52( CONT_PARAMS );
static RTYPE compiled_block_1_2307( CONT_PARAMS );
static RTYPE compiled_block_1_2224( CONT_PARAMS );
static RTYPE compiled_block_1_2302( CONT_PARAMS );
static RTYPE compiled_block_1_2301( CONT_PARAMS );
static RTYPE compiled_block_1_2295( CONT_PARAMS );
static RTYPE compiled_block_1_2298( CONT_PARAMS );
static RTYPE compiled_temp_1_51( CONT_PARAMS );
static RTYPE compiled_block_1_2300( CONT_PARAMS );
static RTYPE compiled_temp_1_50( CONT_PARAMS );
static RTYPE compiled_block_1_2296( CONT_PARAMS );
static RTYPE compiled_temp_1_49( CONT_PARAMS );
static RTYPE compiled_block_1_2280( CONT_PARAMS );
static RTYPE compiled_block_1_2294( CONT_PARAMS );
static RTYPE compiled_block_1_2293( CONT_PARAMS );
static RTYPE compiled_block_1_2291( CONT_PARAMS );
static RTYPE compiled_block_1_2292( CONT_PARAMS );
static RTYPE compiled_block_1_2290( CONT_PARAMS );
static RTYPE compiled_block_1_2289( CONT_PARAMS );
static RTYPE compiled_block_1_2288( CONT_PARAMS );
static RTYPE compiled_temp_1_48( CONT_PARAMS );
static RTYPE compiled_block_1_2287( CONT_PARAMS );
static RTYPE compiled_temp_1_47( CONT_PARAMS );
static RTYPE compiled_block_1_2284( CONT_PARAMS );
static RTYPE compiled_block_1_2286( CONT_PARAMS );
static RTYPE compiled_block_1_2285( CONT_PARAMS );
static RTYPE compiled_temp_1_46( CONT_PARAMS );
static RTYPE compiled_temp_1_45( CONT_PARAMS );
static RTYPE compiled_block_1_2281( CONT_PARAMS );
static RTYPE compiled_block_1_2282( CONT_PARAMS );
static RTYPE compiled_temp_1_44( CONT_PARAMS );
static RTYPE compiled_temp_1_43( CONT_PARAMS );
static RTYPE compiled_block_1_2225( CONT_PARAMS );
static RTYPE compiled_block_1_2278( CONT_PARAMS );
static RTYPE compiled_block_1_2276( CONT_PARAMS );
static RTYPE compiled_block_1_2277( CONT_PARAMS );
static RTYPE compiled_block_1_2275( CONT_PARAMS );
static RTYPE compiled_block_1_2274( CONT_PARAMS );
static RTYPE compiled_block_1_2273( CONT_PARAMS );
static RTYPE compiled_block_1_2271( CONT_PARAMS );
static RTYPE compiled_block_1_2272( CONT_PARAMS );
static RTYPE compiled_block_1_2255( CONT_PARAMS );
static RTYPE compiled_block_1_2269( CONT_PARAMS );
static RTYPE compiled_block_1_2268( CONT_PARAMS );
static RTYPE compiled_block_1_2266( CONT_PARAMS );
static RTYPE compiled_block_1_2267( CONT_PARAMS );
static RTYPE compiled_block_1_2265( CONT_PARAMS );
static RTYPE compiled_block_1_2264( CONT_PARAMS );
static RTYPE compiled_block_1_2263( CONT_PARAMS );
static RTYPE compiled_block_1_2262( CONT_PARAMS );
static RTYPE compiled_block_1_2259( CONT_PARAMS );
static RTYPE compiled_block_1_2261( CONT_PARAMS );
static RTYPE compiled_block_1_2260( CONT_PARAMS );
static RTYPE compiled_temp_1_42( CONT_PARAMS );
static RTYPE compiled_block_1_2256( CONT_PARAMS );
static RTYPE compiled_block_1_2257( CONT_PARAMS );
static RTYPE compiled_temp_1_41( CONT_PARAMS );
static RTYPE compiled_temp_1_40( CONT_PARAMS );
static RTYPE compiled_block_1_2227( CONT_PARAMS );
static RTYPE compiled_block_1_2253( CONT_PARAMS );
static RTYPE compiled_block_1_2251( CONT_PARAMS );
static RTYPE compiled_block_1_2252( CONT_PARAMS );
static RTYPE compiled_block_1_2250( CONT_PARAMS );
static RTYPE compiled_block_1_2249( CONT_PARAMS );
static RTYPE compiled_block_1_2248( CONT_PARAMS );
static RTYPE compiled_block_1_2246( CONT_PARAMS );
static RTYPE compiled_block_1_2247( CONT_PARAMS );
static RTYPE compiled_block_1_2229( CONT_PARAMS );
static RTYPE compiled_block_1_2244( CONT_PARAMS );
static RTYPE compiled_block_1_2243( CONT_PARAMS );
static RTYPE compiled_block_1_2241( CONT_PARAMS );
static RTYPE compiled_block_1_2242( CONT_PARAMS );
static RTYPE compiled_block_1_2240( CONT_PARAMS );
static RTYPE compiled_block_1_2238( CONT_PARAMS );
static RTYPE compiled_block_1_2237( CONT_PARAMS );
static RTYPE compiled_block_1_2236( CONT_PARAMS );
static RTYPE compiled_block_1_2233( CONT_PARAMS );
static RTYPE compiled_block_1_2235( CONT_PARAMS );
static RTYPE compiled_block_1_2234( CONT_PARAMS );
static RTYPE compiled_temp_1_39( CONT_PARAMS );
static RTYPE compiled_block_1_2230( CONT_PARAMS );
static RTYPE compiled_block_1_2231( CONT_PARAMS );
static RTYPE compiled_temp_1_38( CONT_PARAMS );
static RTYPE compiled_temp_1_37( CONT_PARAMS );
static RTYPE compiled_block_1_2209( CONT_PARAMS );
static RTYPE compiled_block_1_2223( CONT_PARAMS );
static RTYPE compiled_block_1_2216( CONT_PARAMS );
static RTYPE compiled_block_1_2221( CONT_PARAMS );
static RTYPE compiled_block_1_2218( CONT_PARAMS );
static RTYPE compiled_block_1_2219( CONT_PARAMS );
static RTYPE compiled_block_1_2217( CONT_PARAMS );
static RTYPE compiled_block_1_2213( CONT_PARAMS );
static RTYPE compiled_block_1_2214( CONT_PARAMS );
static RTYPE compiled_block_1_2215( CONT_PARAMS );
static RTYPE compiled_block_1_2211( CONT_PARAMS );
static RTYPE compiled_block_1_2212( CONT_PARAMS );
static RTYPE compiled_block_1_2210( CONT_PARAMS );
static RTYPE compiled_block_1_2205( CONT_PARAMS );
static RTYPE compiled_block_1_2206( CONT_PARAMS );
static RTYPE compiled_block_1_2182( CONT_PARAMS );
static RTYPE compiled_block_1_2202( CONT_PARAMS );
static RTYPE compiled_block_1_2186( CONT_PARAMS );
static RTYPE compiled_block_1_2201( CONT_PARAMS );
static RTYPE compiled_block_1_2200( CONT_PARAMS );
static RTYPE compiled_block_1_2187( CONT_PARAMS );
static RTYPE compiled_block_1_2188( CONT_PARAMS );
static RTYPE compiled_block_1_2190( CONT_PARAMS );
static RTYPE compiled_block_1_2195( CONT_PARAMS );
static RTYPE compiled_block_1_2197( CONT_PARAMS );
static RTYPE compiled_block_1_2198( CONT_PARAMS );
static RTYPE compiled_block_1_2193( CONT_PARAMS );
static RTYPE compiled_block_1_2192( CONT_PARAMS );
static RTYPE compiled_block_1_2183( CONT_PARAMS );
static RTYPE compiled_block_1_2163( CONT_PARAMS );
static RTYPE compiled_block_1_2181( CONT_PARAMS );
static RTYPE compiled_block_1_2169( CONT_PARAMS );
static RTYPE compiled_block_1_2165( CONT_PARAMS );
static RTYPE compiled_block_1_2166( CONT_PARAMS );
static RTYPE compiled_block_1_2167( CONT_PARAMS );
static RTYPE compiled_block_1_2164( CONT_PARAMS );
static RTYPE compiled_block_1_2117( CONT_PARAMS );
static RTYPE compiled_block_1_2162( CONT_PARAMS );
static RTYPE compiled_block_1_2136( CONT_PARAMS );
static RTYPE compiled_block_1_2119( CONT_PARAMS );
static RTYPE compiled_block_1_2120( CONT_PARAMS );
static RTYPE compiled_block_1_2123( CONT_PARAMS );
static RTYPE compiled_block_1_2134( CONT_PARAMS );
static RTYPE compiled_block_1_2133( CONT_PARAMS );
static RTYPE compiled_block_1_2127( CONT_PARAMS );
static RTYPE compiled_block_1_2128( CONT_PARAMS );
static RTYPE compiled_block_1_2130( CONT_PARAMS );
static RTYPE compiled_block_1_2131( CONT_PARAMS );
static RTYPE compiled_block_1_2126( CONT_PARAMS );
static RTYPE compiled_block_1_2125( CONT_PARAMS );
static RTYPE compiled_block_1_2121( CONT_PARAMS );
static RTYPE compiled_block_1_2118( CONT_PARAMS );
static RTYPE compiled_block_1_2095( CONT_PARAMS );
static RTYPE compiled_block_1_2116( CONT_PARAMS );
static RTYPE compiled_block_1_2102( CONT_PARAMS );
static RTYPE compiled_block_1_2097( CONT_PARAMS );
static RTYPE compiled_block_1_2100( CONT_PARAMS );
static RTYPE compiled_block_1_2098( CONT_PARAMS );
static RTYPE compiled_block_1_2096( CONT_PARAMS );
static RTYPE compiled_block_1_2082( CONT_PARAMS );
static RTYPE compiled_block_1_2094( CONT_PARAMS );
static RTYPE compiled_block_1_2085( CONT_PARAMS );
static RTYPE compiled_block_1_2083( CONT_PARAMS );
static RTYPE compiled_block_1_2060( CONT_PARAMS );
static RTYPE compiled_block_1_2081( CONT_PARAMS );
static RTYPE compiled_block_1_2067( CONT_PARAMS );
static RTYPE compiled_block_1_2062( CONT_PARAMS );
static RTYPE compiled_block_1_2065( CONT_PARAMS );
static RTYPE compiled_block_1_2063( CONT_PARAMS );
static RTYPE compiled_block_1_2061( CONT_PARAMS );
static RTYPE compiled_block_1_2029( CONT_PARAMS );
static RTYPE compiled_block_1_2059( CONT_PARAMS );
static RTYPE compiled_block_1_2041( CONT_PARAMS );
static RTYPE compiled_block_1_2031( CONT_PARAMS );
static RTYPE compiled_block_1_2039( CONT_PARAMS );
static RTYPE compiled_block_1_2037( CONT_PARAMS );
static RTYPE compiled_block_1_2034( CONT_PARAMS );
static RTYPE compiled_block_1_2032( CONT_PARAMS );
static RTYPE compiled_block_1_2030( CONT_PARAMS );
static RTYPE compiled_block_1_2012( CONT_PARAMS );
static RTYPE compiled_block_1_2028( CONT_PARAMS );
static RTYPE compiled_block_1_2017( CONT_PARAMS );
static RTYPE compiled_block_1_2014( CONT_PARAMS );
static RTYPE compiled_block_1_2015( CONT_PARAMS );
static RTYPE compiled_block_1_2013( CONT_PARAMS );
static RTYPE compiled_block_1_1999( CONT_PARAMS );
static RTYPE compiled_block_1_2011( CONT_PARAMS );
static RTYPE compiled_block_1_2002( CONT_PARAMS );
static RTYPE compiled_block_1_2000( CONT_PARAMS );
static RTYPE compiled_block_1_1969( CONT_PARAMS );
static RTYPE compiled_block_1_1998( CONT_PARAMS );
static RTYPE compiled_block_1_1977( CONT_PARAMS );
static RTYPE compiled_block_1_1980( CONT_PARAMS );
static RTYPE compiled_block_1_1981( CONT_PARAMS );
static RTYPE compiled_block_1_1973( CONT_PARAMS );
static RTYPE compiled_block_1_1975( CONT_PARAMS );
static RTYPE compiled_block_1_1974( CONT_PARAMS );
static RTYPE compiled_block_1_1971( CONT_PARAMS );
static RTYPE compiled_block_1_1972( CONT_PARAMS );
static RTYPE compiled_block_1_1970( CONT_PARAMS );
static RTYPE compiled_block_1_1956( CONT_PARAMS );
static RTYPE compiled_block_1_1968( CONT_PARAMS );
static RTYPE compiled_block_1_1959( CONT_PARAMS );
static RTYPE compiled_block_1_1957( CONT_PARAMS );
static RTYPE compiled_block_1_1938( CONT_PARAMS );
static RTYPE compiled_block_1_1955( CONT_PARAMS );
static RTYPE compiled_block_1_1944( CONT_PARAMS );
static RTYPE compiled_block_1_1941( CONT_PARAMS );
static RTYPE compiled_block_1_1942( CONT_PARAMS );
static RTYPE compiled_block_1_1939( CONT_PARAMS );
static RTYPE compiled_block_1_1919( CONT_PARAMS );
static RTYPE compiled_block_1_1936( CONT_PARAMS );
static RTYPE compiled_block_1_1933( CONT_PARAMS );
static RTYPE compiled_block_1_1929( CONT_PARAMS );
static RTYPE compiled_block_1_1931( CONT_PARAMS );
static RTYPE compiled_block_1_1926( CONT_PARAMS );
static RTYPE compiled_block_1_1927( CONT_PARAMS );
static RTYPE compiled_block_1_1924( CONT_PARAMS );
static RTYPE compiled_block_1_1921( CONT_PARAMS );
static RTYPE compiled_start_1_25( CONT_PARAMS );
static RTYPE compiled_block_1_2494( CONT_PARAMS );
static RTYPE compiled_block_1_2496( CONT_PARAMS );
static RTYPE compiled_block_1_2495( CONT_PARAMS );
static RTYPE compiled_block_1_2492( CONT_PARAMS );
static RTYPE compiled_block_1_2493( CONT_PARAMS );
static RTYPE compiled_start_1_79( CONT_PARAMS );
static RTYPE compiled_block_1_2487( CONT_PARAMS );
static RTYPE compiled_block_1_2488( CONT_PARAMS );
static RTYPE compiled_block_1_2486( CONT_PARAMS );
static RTYPE compiled_start_1_78( CONT_PARAMS );
static RTYPE compiled_block_1_2412( CONT_PARAMS );
static RTYPE compiled_block_1_2414( CONT_PARAMS );
static RTYPE compiled_block_1_2413( CONT_PARAMS );
static RTYPE compiled_block_1_2410( CONT_PARAMS );
static RTYPE compiled_block_1_2411( CONT_PARAMS );
static RTYPE compiled_start_1_70( CONT_PARAMS );
static RTYPE compiled_block_1_2405( CONT_PARAMS );
static RTYPE compiled_block_1_2406( CONT_PARAMS );
static RTYPE compiled_block_1_2404( CONT_PARAMS );
static RTYPE compiled_start_1_69( CONT_PARAMS );
static RTYPE compiled_block_1_2354( CONT_PARAMS );
static RTYPE compiled_block_1_2356( CONT_PARAMS );
static RTYPE compiled_block_1_2355( CONT_PARAMS );
static RTYPE compiled_block_1_2352( CONT_PARAMS );
static RTYPE compiled_block_1_2353( CONT_PARAMS );
static RTYPE compiled_start_1_58( CONT_PARAMS );
static RTYPE compiled_block_1_2347( CONT_PARAMS );
static RTYPE compiled_block_1_2348( CONT_PARAMS );
static RTYPE compiled_block_1_2346( CONT_PARAMS );
static RTYPE compiled_start_1_57( CONT_PARAMS );
static RTYPE compiled_block_1_2172( CONT_PARAMS );
static RTYPE compiled_block_1_2177( CONT_PARAMS );
static RTYPE compiled_block_1_2179( CONT_PARAMS );
static RTYPE compiled_block_1_2178( CONT_PARAMS );
static RTYPE compiled_block_1_2173( CONT_PARAMS );
static RTYPE compiled_block_1_2174( CONT_PARAMS );
static RTYPE compiled_block_1_2175( CONT_PARAMS );
static RTYPE compiled_block_1_2171( CONT_PARAMS );
static RTYPE compiled_start_1_36( CONT_PARAMS );
static RTYPE compiled_block_1_2150( CONT_PARAMS );
static RTYPE compiled_block_1_2139( CONT_PARAMS );
static RTYPE compiled_block_1_2158( CONT_PARAMS );
static RTYPE compiled_block_1_2160( CONT_PARAMS );
static RTYPE compiled_block_1_2159( CONT_PARAMS );
static RTYPE compiled_block_1_2140( CONT_PARAMS );
static RTYPE compiled_block_1_2141( CONT_PARAMS );
static RTYPE compiled_block_1_2144( CONT_PARAMS );
static RTYPE compiled_block_1_2156( CONT_PARAMS );
static RTYPE compiled_block_1_2155( CONT_PARAMS );
static RTYPE compiled_block_1_2148( CONT_PARAMS );
static RTYPE compiled_block_1_2149( CONT_PARAMS );
static RTYPE compiled_block_1_2152( CONT_PARAMS );
static RTYPE compiled_block_1_2153( CONT_PARAMS );
static RTYPE compiled_block_1_2147( CONT_PARAMS );
static RTYPE compiled_block_1_2146( CONT_PARAMS );
static RTYPE compiled_block_1_2142( CONT_PARAMS );
static RTYPE compiled_block_1_2138( CONT_PARAMS );
static RTYPE compiled_start_1_35( CONT_PARAMS );
static RTYPE compiled_block_1_2105( CONT_PARAMS );
static RTYPE compiled_block_1_2110( CONT_PARAMS );
static RTYPE compiled_block_1_2112( CONT_PARAMS );
static RTYPE compiled_block_1_2114( CONT_PARAMS );
static RTYPE compiled_block_1_2113( CONT_PARAMS );
static RTYPE compiled_block_1_2106( CONT_PARAMS );
static RTYPE compiled_block_1_2109( CONT_PARAMS );
static RTYPE compiled_block_1_2107( CONT_PARAMS );
static RTYPE compiled_block_1_2104( CONT_PARAMS );
static RTYPE compiled_start_1_34( CONT_PARAMS );
static RTYPE compiled_block_1_2088( CONT_PARAMS );
static RTYPE compiled_block_1_2090( CONT_PARAMS );
static RTYPE compiled_block_1_2092( CONT_PARAMS );
static RTYPE compiled_block_1_2091( CONT_PARAMS );
static RTYPE compiled_block_1_2087( CONT_PARAMS );
static RTYPE compiled_start_1_33( CONT_PARAMS );
static RTYPE compiled_block_1_2070( CONT_PARAMS );
static RTYPE compiled_block_1_2075( CONT_PARAMS );
static RTYPE compiled_block_1_2077( CONT_PARAMS );
static RTYPE compiled_block_1_2079( CONT_PARAMS );
static RTYPE compiled_block_1_2078( CONT_PARAMS );
static RTYPE compiled_block_1_2071( CONT_PARAMS );
static RTYPE compiled_block_1_2074( CONT_PARAMS );
static RTYPE compiled_block_1_2072( CONT_PARAMS );
static RTYPE compiled_block_1_2069( CONT_PARAMS );
static RTYPE compiled_start_1_32( CONT_PARAMS );
static RTYPE compiled_block_1_2044( CONT_PARAMS );
static RTYPE compiled_block_1_2049( CONT_PARAMS );
static RTYPE compiled_block_1_2055( CONT_PARAMS );
static RTYPE compiled_block_1_2057( CONT_PARAMS );
static RTYPE compiled_block_1_2056( CONT_PARAMS );
static RTYPE compiled_block_1_2045( CONT_PARAMS );
static RTYPE compiled_block_1_2053( CONT_PARAMS );
static RTYPE compiled_block_1_2051( CONT_PARAMS );
static RTYPE compiled_block_1_2048( CONT_PARAMS );
static RTYPE compiled_block_1_2046( CONT_PARAMS );
static RTYPE compiled_block_1_2043( CONT_PARAMS );
static RTYPE compiled_start_1_31( CONT_PARAMS );
static RTYPE compiled_block_1_2020( CONT_PARAMS );
static RTYPE compiled_block_1_2024( CONT_PARAMS );
static RTYPE compiled_block_1_2026( CONT_PARAMS );
static RTYPE compiled_block_1_2025( CONT_PARAMS );
static RTYPE compiled_block_1_2021( CONT_PARAMS );
static RTYPE compiled_block_1_2022( CONT_PARAMS );
static RTYPE compiled_block_1_2019( CONT_PARAMS );
static RTYPE compiled_start_1_30( CONT_PARAMS );
static RTYPE compiled_block_1_2005( CONT_PARAMS );
static RTYPE compiled_block_1_2007( CONT_PARAMS );
static RTYPE compiled_block_1_2009( CONT_PARAMS );
static RTYPE compiled_block_1_2008( CONT_PARAMS );
static RTYPE compiled_block_1_2004( CONT_PARAMS );
static RTYPE compiled_start_1_29( CONT_PARAMS );
static RTYPE compiled_block_1_1984( CONT_PARAMS );
static RTYPE compiled_block_1_1991( CONT_PARAMS );
static RTYPE compiled_block_1_1995( CONT_PARAMS );
static RTYPE compiled_block_1_1993( CONT_PARAMS );
static RTYPE compiled_block_1_1992( CONT_PARAMS );
static RTYPE compiled_block_1_1987( CONT_PARAMS );
static RTYPE compiled_block_1_1989( CONT_PARAMS );
static RTYPE compiled_block_1_1988( CONT_PARAMS );
static RTYPE compiled_block_1_1985( CONT_PARAMS );
static RTYPE compiled_block_1_1986( CONT_PARAMS );
static RTYPE compiled_block_1_1983( CONT_PARAMS );
static RTYPE compiled_start_1_28( CONT_PARAMS );
static RTYPE compiled_block_1_1962( CONT_PARAMS );
static RTYPE compiled_block_1_1964( CONT_PARAMS );
static RTYPE compiled_block_1_1966( CONT_PARAMS );
static RTYPE compiled_block_1_1965( CONT_PARAMS );
static RTYPE compiled_block_1_1961( CONT_PARAMS );
static RTYPE compiled_start_1_27( CONT_PARAMS );
static RTYPE compiled_block_1_1947( CONT_PARAMS );
static RTYPE compiled_block_1_1951( CONT_PARAMS );
static RTYPE compiled_block_1_1953( CONT_PARAMS );
static RTYPE compiled_block_1_1952( CONT_PARAMS );
static RTYPE compiled_block_1_1948( CONT_PARAMS );
static RTYPE compiled_block_1_1949( CONT_PARAMS );
static RTYPE compiled_block_1_1946( CONT_PARAMS );
static RTYPE compiled_start_1_26( CONT_PARAMS );
static RTYPE compiled_block_1_1862( CONT_PARAMS );
static RTYPE compiled_block_1_1887( CONT_PARAMS );
static RTYPE compiled_block_1_1916( CONT_PARAMS );
static RTYPE compiled_temp_1_104( CONT_PARAMS );
static RTYPE compiled_block_1_1915( CONT_PARAMS );
static RTYPE compiled_temp_1_103( CONT_PARAMS );
static RTYPE compiled_temp_1_102( CONT_PARAMS );
static RTYPE compiled_block_1_1914( CONT_PARAMS );
static RTYPE compiled_block_1_1913( CONT_PARAMS );
static RTYPE compiled_block_1_1907( CONT_PARAMS );
static RTYPE compiled_block_1_1911( CONT_PARAMS );
static RTYPE compiled_temp_1_101( CONT_PARAMS );
static RTYPE compiled_block_1_1910( CONT_PARAMS );
static RTYPE compiled_temp_1_100( CONT_PARAMS );
static RTYPE compiled_temp_1_99( CONT_PARAMS );
static RTYPE compiled_block_1_1909( CONT_PARAMS );
static RTYPE compiled_block_1_1908( CONT_PARAMS );
static RTYPE compiled_temp_1_98( CONT_PARAMS );
static RTYPE compiled_block_1_1885( CONT_PARAMS );
static RTYPE compiled_block_1_1890( CONT_PARAMS );
static RTYPE compiled_block_1_1903( CONT_PARAMS );
static RTYPE compiled_temp_1_97( CONT_PARAMS );
static RTYPE compiled_block_1_1900( CONT_PARAMS );
static RTYPE compiled_block_1_1902( CONT_PARAMS );
static RTYPE compiled_block_1_1901( CONT_PARAMS );
static RTYPE compiled_block_1_1899( CONT_PARAMS );
static RTYPE compiled_block_1_1892( CONT_PARAMS );
static RTYPE compiled_block_1_1897( CONT_PARAMS );
static RTYPE compiled_temp_1_96( CONT_PARAMS );
static RTYPE compiled_block_1_1894( CONT_PARAMS );
static RTYPE compiled_block_1_1896( CONT_PARAMS );
static RTYPE compiled_block_1_1895( CONT_PARAMS );
static RTYPE compiled_block_1_1893( CONT_PARAMS );
static RTYPE compiled_temp_1_95( CONT_PARAMS );
static RTYPE compiled_block_1_1888( CONT_PARAMS );
static RTYPE compiled_block_1_1886( CONT_PARAMS );
static RTYPE compiled_temp_1_94( CONT_PARAMS );
static RTYPE compiled_block_1_1883( CONT_PARAMS );
static RTYPE compiled_block_1_1870( CONT_PARAMS );
static RTYPE compiled_block_1_1881( CONT_PARAMS );
static RTYPE compiled_temp_1_93( CONT_PARAMS );
static RTYPE compiled_block_1_1878( CONT_PARAMS );
static RTYPE compiled_block_1_1880( CONT_PARAMS );
static RTYPE compiled_block_1_1879( CONT_PARAMS );
static RTYPE compiled_temp_1_92( CONT_PARAMS );
static RTYPE compiled_block_1_1877( CONT_PARAMS );
static RTYPE compiled_temp_1_91( CONT_PARAMS );
static RTYPE compiled_block_1_1875( CONT_PARAMS );
static RTYPE compiled_block_1_1876( CONT_PARAMS );
static RTYPE compiled_temp_1_90( CONT_PARAMS );
static RTYPE compiled_block_1_1874( CONT_PARAMS );
static RTYPE compiled_temp_1_89( CONT_PARAMS );
static RTYPE compiled_block_1_1872( CONT_PARAMS );
static RTYPE compiled_temp_1_88( CONT_PARAMS );
static RTYPE compiled_block_1_1867( CONT_PARAMS );
static RTYPE compiled_block_1_1868( CONT_PARAMS );
static RTYPE compiled_temp_1_87( CONT_PARAMS );
static RTYPE compiled_temp_1_86( CONT_PARAMS );
static RTYPE compiled_block_1_1866( CONT_PARAMS );
static RTYPE compiled_block_1_1865( CONT_PARAMS );
static RTYPE compiled_block_1_1863( CONT_PARAMS );
static RTYPE compiled_block_1_1861( CONT_PARAMS );
static RTYPE compiled_temp_1_85( CONT_PARAMS );
static RTYPE compiled_start_1_24( CONT_PARAMS );
static RTYPE compiled_temp_1_105( CONT_PARAMS );
static RTYPE compiled_start_1_23( CONT_PARAMS );
static RTYPE compiled_block_1_1854( CONT_PARAMS );
static RTYPE compiled_block_1_1858( CONT_PARAMS );
static RTYPE compiled_block_1_1855( CONT_PARAMS );
static RTYPE compiled_block_1_1856( CONT_PARAMS );
static RTYPE compiled_start_1_106( CONT_PARAMS );
static RTYPE compiled_temp_1_107( CONT_PARAMS );
static RTYPE compiled_start_1_22( CONT_PARAMS );
static RTYPE compiled_block_1_1849( CONT_PARAMS );
static RTYPE compiled_block_1_1851( CONT_PARAMS );
static RTYPE compiled_start_1_108( CONT_PARAMS );
static RTYPE compiled_start_1_21( CONT_PARAMS );
static RTYPE compiled_block_1_1844( CONT_PARAMS );
static RTYPE compiled_block_1_1846( CONT_PARAMS );
static RTYPE compiled_start_1_109( CONT_PARAMS );
static RTYPE compiled_block_1_1778( CONT_PARAMS );
static RTYPE compiled_block_1_1839( CONT_PARAMS );
static RTYPE compiled_block_1_1842( CONT_PARAMS );
static RTYPE compiled_block_1_1840( CONT_PARAMS );
static RTYPE compiled_temp_1_147( CONT_PARAMS );
static RTYPE compiled_block_1_1838( CONT_PARAMS );
static RTYPE compiled_block_1_1781( CONT_PARAMS );
static RTYPE compiled_block_1_1836( CONT_PARAMS );
static RTYPE compiled_block_1_1826( CONT_PARAMS );
static RTYPE compiled_block_1_1834( CONT_PARAMS );
static RTYPE compiled_temp_1_146( CONT_PARAMS );
static RTYPE compiled_block_1_1833( CONT_PARAMS );
static RTYPE compiled_block_1_1828( CONT_PARAMS );
static RTYPE compiled_block_1_1831( CONT_PARAMS );
static RTYPE compiled_block_1_1830( CONT_PARAMS );
static RTYPE compiled_temp_1_145( CONT_PARAMS );
static RTYPE compiled_temp_1_144( CONT_PARAMS );
static RTYPE compiled_temp_1_143( CONT_PARAMS );
static RTYPE compiled_block_1_1829( CONT_PARAMS );
static RTYPE compiled_temp_1_142( CONT_PARAMS );
static RTYPE compiled_temp_1_141( CONT_PARAMS );
static RTYPE compiled_temp_1_140( CONT_PARAMS );
static RTYPE compiled_temp_1_139( CONT_PARAMS );
static RTYPE compiled_block_1_1786( CONT_PARAMS );
static RTYPE compiled_block_1_1823( CONT_PARAMS );
static RTYPE compiled_block_1_1819( CONT_PARAMS );
static RTYPE compiled_block_1_1821( CONT_PARAMS );
static RTYPE compiled_block_1_1820( CONT_PARAMS );
static RTYPE compiled_temp_1_138( CONT_PARAMS );
static RTYPE compiled_temp_1_137( CONT_PARAMS );
static RTYPE compiled_temp_1_136( CONT_PARAMS );
static RTYPE compiled_temp_1_135( CONT_PARAMS );
static RTYPE compiled_block_1_1810( CONT_PARAMS );
static RTYPE compiled_block_1_1816( CONT_PARAMS );
static RTYPE compiled_block_1_1812( CONT_PARAMS );
static RTYPE compiled_block_1_1814( CONT_PARAMS );
static RTYPE compiled_block_1_1813( CONT_PARAMS );
static RTYPE compiled_temp_1_134( CONT_PARAMS );
static RTYPE compiled_temp_1_133( CONT_PARAMS );
static RTYPE compiled_temp_1_132( CONT_PARAMS );
static RTYPE compiled_temp_1_131( CONT_PARAMS );
static RTYPE compiled_temp_1_130( CONT_PARAMS );
static RTYPE compiled_temp_1_129( CONT_PARAMS );
static RTYPE compiled_temp_1_128( CONT_PARAMS );
static RTYPE compiled_block_1_1788( CONT_PARAMS );
static RTYPE compiled_block_1_1807( CONT_PARAMS );
static RTYPE compiled_temp_1_127( CONT_PARAMS );
static RTYPE compiled_block_1_1806( CONT_PARAMS );
static RTYPE compiled_block_1_1801( CONT_PARAMS );
static RTYPE compiled_block_1_1804( CONT_PARAMS );
static RTYPE compiled_temp_1_126( CONT_PARAMS );
static RTYPE compiled_block_1_1803( CONT_PARAMS );
static RTYPE compiled_block_1_1802( CONT_PARAMS );
static RTYPE compiled_temp_1_125( CONT_PARAMS );
static RTYPE compiled_temp_1_124( CONT_PARAMS );
static RTYPE compiled_temp_1_123( CONT_PARAMS );
static RTYPE compiled_temp_1_122( CONT_PARAMS );
static RTYPE compiled_block_1_1790( CONT_PARAMS );
static RTYPE compiled_block_1_1798( CONT_PARAMS );
static RTYPE compiled_temp_1_121( CONT_PARAMS );
static RTYPE compiled_block_1_1797( CONT_PARAMS );
static RTYPE compiled_block_1_1792( CONT_PARAMS );
static RTYPE compiled_block_1_1795( CONT_PARAMS );
static RTYPE compiled_temp_1_120( CONT_PARAMS );
static RTYPE compiled_block_1_1794( CONT_PARAMS );
static RTYPE compiled_block_1_1793( CONT_PARAMS );
static RTYPE compiled_temp_1_119( CONT_PARAMS );
static RTYPE compiled_temp_1_118( CONT_PARAMS );
static RTYPE compiled_temp_1_117( CONT_PARAMS );
static RTYPE compiled_temp_1_116( CONT_PARAMS );
static RTYPE compiled_temp_1_115( CONT_PARAMS );
static RTYPE compiled_temp_1_114( CONT_PARAMS );
static RTYPE compiled_temp_1_113( CONT_PARAMS );
static RTYPE compiled_temp_1_112( CONT_PARAMS );
static RTYPE compiled_block_1_1784( CONT_PARAMS );
static RTYPE compiled_block_1_1783( CONT_PARAMS );
static RTYPE compiled_temp_1_111( CONT_PARAMS );
static RTYPE compiled_block_1_1782( CONT_PARAMS );
static RTYPE compiled_block_1_1779( CONT_PARAMS );
static RTYPE compiled_block_1_1777( CONT_PARAMS );
static RTYPE compiled_temp_1_110( CONT_PARAMS );
static RTYPE compiled_start_1_20( CONT_PARAMS );
static RTYPE compiled_block_1_1748( CONT_PARAMS );
static RTYPE compiled_start_1_19( CONT_PARAMS );
static RTYPE compiled_block_1_1764( CONT_PARAMS );
static RTYPE compiled_block_1_1774( CONT_PARAMS );
static RTYPE compiled_temp_1_150( CONT_PARAMS );
static RTYPE compiled_block_1_1769( CONT_PARAMS );
static RTYPE compiled_block_1_1771( CONT_PARAMS );
static RTYPE compiled_block_1_1766( CONT_PARAMS );
static RTYPE compiled_start_1_149( CONT_PARAMS );
static RTYPE compiled_block_1_1749( CONT_PARAMS );
static RTYPE compiled_block_1_1761( CONT_PARAMS );
static RTYPE compiled_block_1_1760( CONT_PARAMS );
static RTYPE compiled_block_1_1754( CONT_PARAMS );
static RTYPE compiled_block_1_1757( CONT_PARAMS );
static RTYPE compiled_block_1_1756( CONT_PARAMS );
static RTYPE compiled_block_1_1751( CONT_PARAMS );
static RTYPE compiled_start_1_148( CONT_PARAMS );
static RTYPE compiled_block_1_1741( CONT_PARAMS );
static RTYPE compiled_block_1_1745( CONT_PARAMS );
static RTYPE compiled_block_1_1744( CONT_PARAMS );
static RTYPE compiled_block_1_1743( CONT_PARAMS );
static RTYPE compiled_block_1_1742( CONT_PARAMS );
static RTYPE compiled_start_1_18( CONT_PARAMS );
static RTYPE compiled_block_1_1732( CONT_PARAMS );
static RTYPE compiled_block_1_1735( CONT_PARAMS );
static RTYPE compiled_block_1_1738( CONT_PARAMS );
static RTYPE compiled_block_1_1737( CONT_PARAMS );
static RTYPE compiled_block_1_1736( CONT_PARAMS );
static RTYPE compiled_block_1_1733( CONT_PARAMS );
static RTYPE compiled_start_1_17( CONT_PARAMS );
static RTYPE compiled_block_1_1700( CONT_PARAMS );
static RTYPE compiled_block_1_1680( CONT_PARAMS );
static RTYPE compiled_block_1_1704( CONT_PARAMS );
static RTYPE compiled_block_1_1691( CONT_PARAMS );
static RTYPE compiled_block_1_1682( CONT_PARAMS );
static RTYPE compiled_block_1_1685( CONT_PARAMS );
static RTYPE compiled_block_1_1703( CONT_PARAMS );
static RTYPE compiled_block_1_1727( CONT_PARAMS );
static RTYPE compiled_block_1_1728( CONT_PARAMS );
static RTYPE compiled_block_1_1726( CONT_PARAMS );
static RTYPE compiled_block_1_1725( CONT_PARAMS );
static RTYPE compiled_temp_1_163( CONT_PARAMS );
static RTYPE compiled_block_1_1708( CONT_PARAMS );
static RTYPE compiled_block_1_1709( CONT_PARAMS );
static RTYPE compiled_block_1_1707( CONT_PARAMS );
static RTYPE compiled_block_1_1705( CONT_PARAMS );
static RTYPE compiled_block_1_1706( CONT_PARAMS );
static RTYPE compiled_block_1_1692( CONT_PARAMS );
static RTYPE compiled_block_1_1695( CONT_PARAMS );
static RTYPE compiled_block_1_1701( CONT_PARAMS );
static RTYPE compiled_temp_1_162( CONT_PARAMS );
static RTYPE compiled_block_1_1698( CONT_PARAMS );
static RTYPE compiled_block_1_1699( CONT_PARAMS );
static RTYPE compiled_temp_1_161( CONT_PARAMS );
static RTYPE compiled_block_1_1697( CONT_PARAMS );
static RTYPE compiled_temp_1_160( CONT_PARAMS );
static RTYPE compiled_temp_1_159( CONT_PARAMS );
static RTYPE compiled_block_1_1693( CONT_PARAMS );
static RTYPE compiled_temp_1_158( CONT_PARAMS );
static RTYPE compiled_temp_1_157( CONT_PARAMS );
static RTYPE compiled_block_1_1689( CONT_PARAMS );
static RTYPE compiled_temp_1_156( CONT_PARAMS );
static RTYPE compiled_temp_1_155( CONT_PARAMS );
static RTYPE compiled_block_1_1687( CONT_PARAMS );
static RTYPE compiled_temp_1_154( CONT_PARAMS );
static RTYPE compiled_block_1_1683( CONT_PARAMS );
static RTYPE compiled_temp_1_153( CONT_PARAMS );
static RTYPE compiled_temp_1_152( CONT_PARAMS );
static RTYPE compiled_temp_1_151( CONT_PARAMS );
static RTYPE compiled_block_1_1681( CONT_PARAMS );
static RTYPE compiled_start_1_16( CONT_PARAMS );
static RTYPE compiled_block_1_1714( CONT_PARAMS );
static RTYPE compiled_block_1_1724( CONT_PARAMS );
static RTYPE compiled_block_1_1719( CONT_PARAMS );
static RTYPE compiled_block_1_1723( CONT_PARAMS );
static RTYPE compiled_block_1_1721( CONT_PARAMS );
static RTYPE compiled_block_1_1722( CONT_PARAMS );
static RTYPE compiled_block_1_1716( CONT_PARAMS );
static RTYPE compiled_block_1_1717( CONT_PARAMS );
static RTYPE compiled_block_1_1711( CONT_PARAMS );
static RTYPE compiled_block_1_1713( CONT_PARAMS );
static RTYPE compiled_temp_1_165( CONT_PARAMS );
static RTYPE compiled_start_1_164( CONT_PARAMS );
static RTYPE compiled_block_1_1647( CONT_PARAMS );
static RTYPE compiled_block_1_1648( CONT_PARAMS );
static RTYPE compiled_block_1_1629( CONT_PARAMS );
static RTYPE compiled_block_1_1652( CONT_PARAMS );
static RTYPE compiled_block_1_1638( CONT_PARAMS );
static RTYPE compiled_block_1_1632( CONT_PARAMS );
static RTYPE compiled_block_1_1651( CONT_PARAMS );
static RTYPE compiled_block_1_1675( CONT_PARAMS );
static RTYPE compiled_block_1_1676( CONT_PARAMS );
static RTYPE compiled_block_1_1674( CONT_PARAMS );
static RTYPE compiled_block_1_1673( CONT_PARAMS );
static RTYPE compiled_temp_1_177( CONT_PARAMS );
static RTYPE compiled_block_1_1656( CONT_PARAMS );
static RTYPE compiled_block_1_1657( CONT_PARAMS );
static RTYPE compiled_block_1_1655( CONT_PARAMS );
static RTYPE compiled_block_1_1653( CONT_PARAMS );
static RTYPE compiled_block_1_1654( CONT_PARAMS );
static RTYPE compiled_block_1_1639( CONT_PARAMS );
static RTYPE compiled_block_1_1642( CONT_PARAMS );
static RTYPE compiled_block_1_1649( CONT_PARAMS );
static RTYPE compiled_temp_1_176( CONT_PARAMS );
static RTYPE compiled_block_1_1645( CONT_PARAMS );
static RTYPE compiled_block_1_1646( CONT_PARAMS );
static RTYPE compiled_temp_1_175( CONT_PARAMS );
static RTYPE compiled_block_1_1644( CONT_PARAMS );
static RTYPE compiled_temp_1_174( CONT_PARAMS );
static RTYPE compiled_temp_1_173( CONT_PARAMS );
static RTYPE compiled_block_1_1640( CONT_PARAMS );
static RTYPE compiled_temp_1_172( CONT_PARAMS );
static RTYPE compiled_temp_1_171( CONT_PARAMS );
static RTYPE compiled_block_1_1636( CONT_PARAMS );
static RTYPE compiled_temp_1_170( CONT_PARAMS );
static RTYPE compiled_temp_1_169( CONT_PARAMS );
static RTYPE compiled_block_1_1634( CONT_PARAMS );
static RTYPE compiled_temp_1_168( CONT_PARAMS );
static RTYPE compiled_temp_1_167( CONT_PARAMS );
static RTYPE compiled_temp_1_166( CONT_PARAMS );
static RTYPE compiled_block_1_1630( CONT_PARAMS );
static RTYPE compiled_start_1_15( CONT_PARAMS );
static RTYPE compiled_block_1_1662( CONT_PARAMS );
static RTYPE compiled_block_1_1672( CONT_PARAMS );
static RTYPE compiled_block_1_1667( CONT_PARAMS );
static RTYPE compiled_block_1_1671( CONT_PARAMS );
static RTYPE compiled_block_1_1669( CONT_PARAMS );
static RTYPE compiled_block_1_1670( CONT_PARAMS );
static RTYPE compiled_block_1_1664( CONT_PARAMS );
static RTYPE compiled_block_1_1665( CONT_PARAMS );
static RTYPE compiled_block_1_1659( CONT_PARAMS );
static RTYPE compiled_block_1_1661( CONT_PARAMS );
static RTYPE compiled_temp_1_179( CONT_PARAMS );
static RTYPE compiled_start_1_178( CONT_PARAMS );
static RTYPE compiled_block_1_1628( CONT_PARAMS );
static RTYPE compiled_block_1_1625( CONT_PARAMS );
static RTYPE compiled_block_1_1626( CONT_PARAMS );
static RTYPE compiled_start_1_14( CONT_PARAMS );
static RTYPE compiled_block_1_1624( CONT_PARAMS );
static RTYPE compiled_start_1_13( CONT_PARAMS );
static RTYPE compiled_start_1_12( CONT_PARAMS );
static RTYPE compiled_block_1_1621( CONT_PARAMS );
static RTYPE compiled_block_1_1617( CONT_PARAMS );
static RTYPE compiled_block_1_1618( CONT_PARAMS );
static RTYPE compiled_block_1_1619( CONT_PARAMS );
static RTYPE compiled_temp_1_183( CONT_PARAMS );
static RTYPE compiled_block_1_1616( CONT_PARAMS );
static RTYPE compiled_block_1_1608( CONT_PARAMS );
static RTYPE compiled_block_1_1613( CONT_PARAMS );
static RTYPE compiled_temp_1_182( CONT_PARAMS );
static RTYPE compiled_block_1_1609( CONT_PARAMS );
static RTYPE compiled_block_1_1610( CONT_PARAMS );
static RTYPE compiled_block_1_1611( CONT_PARAMS );
static RTYPE compiled_temp_1_181( CONT_PARAMS );
static RTYPE compiled_start_1_180( CONT_PARAMS );
static RTYPE compiled_start_1_11( CONT_PARAMS );
static RTYPE compiled_block_1_1605( CONT_PARAMS );
static RTYPE compiled_block_1_1603( CONT_PARAMS );
static RTYPE compiled_block_1_1602( CONT_PARAMS );
static RTYPE compiled_block_1_1596( CONT_PARAMS );
static RTYPE compiled_block_1_1599( CONT_PARAMS );
static RTYPE compiled_block_1_1597( CONT_PARAMS );
static RTYPE compiled_start_1_184( CONT_PARAMS );
static RTYPE compiled_block_1_1583( CONT_PARAMS );
static RTYPE compiled_block_1_1593( CONT_PARAMS );
static RTYPE compiled_block_1_1584( CONT_PARAMS );
static RTYPE compiled_block_1_1587( CONT_PARAMS );
static RTYPE compiled_temp_1_188( CONT_PARAMS );
static RTYPE compiled_temp_1_187( CONT_PARAMS );
static RTYPE compiled_block_1_1585( CONT_PARAMS );
static RTYPE compiled_block_1_1581( CONT_PARAMS );
static RTYPE compiled_block_1_1582( CONT_PARAMS );
static RTYPE compiled_temp_1_186( CONT_PARAMS );
static RTYPE compiled_temp_1_185( CONT_PARAMS );
static RTYPE compiled_start_1_10( CONT_PARAMS );
static RTYPE compiled_block_1_1592( CONT_PARAMS );
static RTYPE compiled_block_1_1589( CONT_PARAMS );
static RTYPE compiled_block_1_1591( CONT_PARAMS );
static RTYPE compiled_temp_1_191( CONT_PARAMS );
static RTYPE compiled_block_1_1590( CONT_PARAMS );
static RTYPE compiled_temp_1_190( CONT_PARAMS );
static RTYPE compiled_start_1_189( CONT_PARAMS );
static RTYPE compiled_block_1_1503( CONT_PARAMS );
static RTYPE compiled_block_1_1571( CONT_PARAMS );
static RTYPE compiled_block_1_1579( CONT_PARAMS );
static RTYPE compiled_block_1_1572( CONT_PARAMS );
static RTYPE compiled_block_1_1573( CONT_PARAMS );
static RTYPE compiled_temp_1_215( CONT_PARAMS );
static RTYPE compiled_temp_1_214( CONT_PARAMS );
static RTYPE compiled_block_1_1569( CONT_PARAMS );
static RTYPE compiled_block_1_1556( CONT_PARAMS );
static RTYPE compiled_block_1_1559( CONT_PARAMS );
static RTYPE compiled_block_1_1567( CONT_PARAMS );
static RTYPE compiled_temp_1_212( CONT_PARAMS );
static RTYPE compiled_block_1_1560( CONT_PARAMS );
static RTYPE compiled_block_1_1561( CONT_PARAMS );
static RTYPE compiled_temp_1_211( CONT_PARAMS );
static RTYPE compiled_temp_1_210( CONT_PARAMS );
static RTYPE compiled_block_1_1557( CONT_PARAMS );
static RTYPE compiled_block_1_1506( CONT_PARAMS );
static RTYPE compiled_block_1_1537( CONT_PARAMS );
static RTYPE compiled_block_1_1553( CONT_PARAMS );
static RTYPE compiled_block_1_1552( CONT_PARAMS );
static RTYPE compiled_temp_1_208( CONT_PARAMS );
static RTYPE compiled_temp_1_207( CONT_PARAMS );
static RTYPE compiled_temp_1_206( CONT_PARAMS );
static RTYPE compiled_block_1_1546( CONT_PARAMS );
static RTYPE compiled_block_1_1545( CONT_PARAMS );
static RTYPE compiled_block_1_1538( CONT_PARAMS );
static RTYPE compiled_block_1_1539( CONT_PARAMS );
static RTYPE compiled_temp_1_204( CONT_PARAMS );
static RTYPE compiled_temp_1_203( CONT_PARAMS );
static RTYPE compiled_block_1_1533( CONT_PARAMS );
static RTYPE compiled_block_1_1534( CONT_PARAMS );
static RTYPE compiled_block_1_1535( CONT_PARAMS );
static RTYPE compiled_temp_1_202( CONT_PARAMS );
static RTYPE compiled_block_1_1532( CONT_PARAMS );
static RTYPE compiled_block_1_1508( CONT_PARAMS );
static RTYPE compiled_block_1_1514( CONT_PARAMS );
static RTYPE compiled_block_1_1530( CONT_PARAMS );
static RTYPE compiled_block_1_1529( CONT_PARAMS );
static RTYPE compiled_temp_1_200( CONT_PARAMS );
static RTYPE compiled_temp_1_199( CONT_PARAMS );
static RTYPE compiled_temp_1_198( CONT_PARAMS );
static RTYPE compiled_block_1_1523( CONT_PARAMS );
static RTYPE compiled_block_1_1522( CONT_PARAMS );
static RTYPE compiled_temp_1_196( CONT_PARAMS );
static RTYPE compiled_block_1_1515( CONT_PARAMS );
static RTYPE compiled_block_1_1516( CONT_PARAMS );
static RTYPE compiled_temp_1_195( CONT_PARAMS );
static RTYPE compiled_temp_1_194( CONT_PARAMS );
static RTYPE compiled_temp_1_193( CONT_PARAMS );
static RTYPE compiled_block_1_1510( CONT_PARAMS );
static RTYPE compiled_block_1_1511( CONT_PARAMS );
static RTYPE compiled_block_1_1512( CONT_PARAMS );
static RTYPE compiled_temp_1_192( CONT_PARAMS );
static RTYPE compiled_block_1_1509( CONT_PARAMS );
static RTYPE compiled_block_1_1504( CONT_PARAMS );
static RTYPE compiled_start_1_9( CONT_PARAMS );
static RTYPE compiled_block_1_1578( CONT_PARAMS );
static RTYPE compiled_block_1_1575( CONT_PARAMS );
static RTYPE compiled_block_1_1577( CONT_PARAMS );
static RTYPE compiled_temp_1_218( CONT_PARAMS );
static RTYPE compiled_block_1_1576( CONT_PARAMS );
static RTYPE compiled_temp_1_217( CONT_PARAMS );
static RTYPE compiled_start_1_216( CONT_PARAMS );
static RTYPE compiled_block_1_1566( CONT_PARAMS );
static RTYPE compiled_block_1_1563( CONT_PARAMS );
static RTYPE compiled_block_1_1565( CONT_PARAMS );
static RTYPE compiled_temp_1_220( CONT_PARAMS );
static RTYPE compiled_block_1_1564( CONT_PARAMS );
static RTYPE compiled_temp_1_219( CONT_PARAMS );
static RTYPE compiled_start_1_213( CONT_PARAMS );
static RTYPE compiled_block_1_1551( CONT_PARAMS );
static RTYPE compiled_block_1_1548( CONT_PARAMS );
static RTYPE compiled_block_1_1550( CONT_PARAMS );
static RTYPE compiled_temp_1_222( CONT_PARAMS );
static RTYPE compiled_block_1_1549( CONT_PARAMS );
static RTYPE compiled_temp_1_221( CONT_PARAMS );
static RTYPE compiled_start_1_209( CONT_PARAMS );
static RTYPE compiled_block_1_1544( CONT_PARAMS );
static RTYPE compiled_block_1_1541( CONT_PARAMS );
static RTYPE compiled_block_1_1543( CONT_PARAMS );
static RTYPE compiled_temp_1_224( CONT_PARAMS );
static RTYPE compiled_block_1_1542( CONT_PARAMS );
static RTYPE compiled_temp_1_223( CONT_PARAMS );
static RTYPE compiled_start_1_205( CONT_PARAMS );
static RTYPE compiled_block_1_1528( CONT_PARAMS );
static RTYPE compiled_block_1_1525( CONT_PARAMS );
static RTYPE compiled_block_1_1527( CONT_PARAMS );
static RTYPE compiled_temp_1_226( CONT_PARAMS );
static RTYPE compiled_block_1_1526( CONT_PARAMS );
static RTYPE compiled_temp_1_225( CONT_PARAMS );
static RTYPE compiled_start_1_201( CONT_PARAMS );
static RTYPE compiled_block_1_1521( CONT_PARAMS );
static RTYPE compiled_block_1_1518( CONT_PARAMS );
static RTYPE compiled_block_1_1520( CONT_PARAMS );
static RTYPE compiled_temp_1_228( CONT_PARAMS );
static RTYPE compiled_block_1_1519( CONT_PARAMS );
static RTYPE compiled_temp_1_227( CONT_PARAMS );
static RTYPE compiled_start_1_197( CONT_PARAMS );
static RTYPE compiled_start_1_8( CONT_PARAMS );
static RTYPE compiled_block_1_1497( CONT_PARAMS );
static RTYPE compiled_block_1_1500( CONT_PARAMS );
static RTYPE compiled_block_1_1498( CONT_PARAMS );
static RTYPE compiled_block_1_1496( CONT_PARAMS );
static RTYPE compiled_temp_1_230( CONT_PARAMS );
static RTYPE compiled_start_1_229( CONT_PARAMS );
static RTYPE compiled_start_1_7( CONT_PARAMS );
static RTYPE compiled_block_1_1489( CONT_PARAMS );
static RTYPE compiled_block_1_1492( CONT_PARAMS );
static RTYPE compiled_block_1_1490( CONT_PARAMS );
static RTYPE compiled_block_1_1488( CONT_PARAMS );
static RTYPE compiled_temp_1_232( CONT_PARAMS );
static RTYPE compiled_start_1_231( CONT_PARAMS );
static RTYPE compiled_start_1_6( CONT_PARAMS );
static RTYPE compiled_block_1_1482( CONT_PARAMS );
static RTYPE compiled_block_1_1484( CONT_PARAMS );
static RTYPE compiled_block_1_1481( CONT_PARAMS );
static RTYPE compiled_temp_1_234( CONT_PARAMS );
static RTYPE compiled_start_1_233( CONT_PARAMS );
static RTYPE compiled_block_1_1371( CONT_PARAMS );
static RTYPE compiled_block_1_1435( CONT_PARAMS );
static RTYPE compiled_block_1_1355( CONT_PARAMS );
static RTYPE compiled_block_1_1364( CONT_PARAMS );
static RTYPE compiled_block_1_1386( CONT_PARAMS );
static RTYPE compiled_block_1_1476( CONT_PARAMS );
static RTYPE compiled_block_1_1477( CONT_PARAMS );
static RTYPE compiled_temp_1_277( CONT_PARAMS );
static RTYPE compiled_temp_1_276( CONT_PARAMS );
static RTYPE compiled_block_1_1470( CONT_PARAMS );
static RTYPE compiled_block_1_1472( CONT_PARAMS );
static RTYPE compiled_block_1_1473( CONT_PARAMS );
static RTYPE compiled_temp_1_275( CONT_PARAMS );
static RTYPE compiled_temp_1_274( CONT_PARAMS );
static RTYPE compiled_temp_1_273( CONT_PARAMS );
static RTYPE compiled_block_1_1468( CONT_PARAMS );
static RTYPE compiled_temp_1_272( CONT_PARAMS );
static RTYPE compiled_block_1_1465( CONT_PARAMS );
static RTYPE compiled_block_1_1450( CONT_PARAMS );
static RTYPE compiled_block_1_1462( CONT_PARAMS );
static RTYPE compiled_temp_1_271( CONT_PARAMS );
static RTYPE compiled_temp_1_270( CONT_PARAMS );
static RTYPE compiled_block_1_1457( CONT_PARAMS );
static RTYPE compiled_block_1_1459( CONT_PARAMS );
static RTYPE compiled_temp_1_269( CONT_PARAMS );
static RTYPE compiled_temp_1_268( CONT_PARAMS );
static RTYPE compiled_temp_1_267( CONT_PARAMS );
static RTYPE compiled_block_1_1455( CONT_PARAMS );
static RTYPE compiled_temp_1_266( CONT_PARAMS );
static RTYPE compiled_block_1_1452( CONT_PARAMS );
static RTYPE compiled_block_1_1448( CONT_PARAMS );
static RTYPE compiled_block_1_1447( CONT_PARAMS );
static RTYPE compiled_block_1_1436( CONT_PARAMS );
static RTYPE compiled_block_1_1442( CONT_PARAMS );
static RTYPE compiled_block_1_1445( CONT_PARAMS );
static RTYPE compiled_block_1_1443( CONT_PARAMS );
static RTYPE compiled_block_1_1444( CONT_PARAMS );
static RTYPE compiled_temp_1_265( CONT_PARAMS );
static RTYPE compiled_temp_1_264( CONT_PARAMS );
static RTYPE compiled_temp_1_263( CONT_PARAMS );
static RTYPE compiled_temp_1_262( CONT_PARAMS );
static RTYPE compiled_block_1_1437( CONT_PARAMS );
static RTYPE compiled_block_1_1439( CONT_PARAMS );
static RTYPE compiled_block_1_1440( CONT_PARAMS );
static RTYPE compiled_temp_1_261( CONT_PARAMS );
static RTYPE compiled_temp_1_260( CONT_PARAMS );
static RTYPE compiled_block_1_1400( CONT_PARAMS );
static RTYPE compiled_block_1_1431( CONT_PARAMS );
static RTYPE compiled_block_1_1432( CONT_PARAMS );
static RTYPE compiled_temp_1_259( CONT_PARAMS );
static RTYPE compiled_temp_1_258( CONT_PARAMS );
static RTYPE compiled_block_1_1425( CONT_PARAMS );
static RTYPE compiled_block_1_1427( CONT_PARAMS );
static RTYPE compiled_block_1_1428( CONT_PARAMS );
static RTYPE compiled_temp_1_257( CONT_PARAMS );
static RTYPE compiled_temp_1_256( CONT_PARAMS );
static RTYPE compiled_temp_1_255( CONT_PARAMS );
static RTYPE compiled_block_1_1423( CONT_PARAMS );
static RTYPE compiled_temp_1_254( CONT_PARAMS );
static RTYPE compiled_block_1_1420( CONT_PARAMS );
static RTYPE compiled_block_1_1405( CONT_PARAMS );
static RTYPE compiled_block_1_1417( CONT_PARAMS );
static RTYPE compiled_temp_1_253( CONT_PARAMS );
static RTYPE compiled_temp_1_252( CONT_PARAMS );
static RTYPE compiled_block_1_1412( CONT_PARAMS );
static RTYPE compiled_block_1_1414( CONT_PARAMS );
static RTYPE compiled_temp_1_251( CONT_PARAMS );
static RTYPE compiled_temp_1_250( CONT_PARAMS );
static RTYPE compiled_temp_1_249( CONT_PARAMS );
static RTYPE compiled_block_1_1410( CONT_PARAMS );
static RTYPE compiled_temp_1_248( CONT_PARAMS );
static RTYPE compiled_block_1_1407( CONT_PARAMS );
static RTYPE compiled_block_1_1403( CONT_PARAMS );
static RTYPE compiled_block_1_1402( CONT_PARAMS );
static RTYPE compiled_temp_1_247( CONT_PARAMS );
static RTYPE compiled_block_1_1357( CONT_PARAMS );
static RTYPE compiled_block_1_1395( CONT_PARAMS );
static RTYPE compiled_block_1_1396( CONT_PARAMS );
static RTYPE compiled_temp_1_246( CONT_PARAMS );
static RTYPE compiled_temp_1_245( CONT_PARAMS );
static RTYPE compiled_block_1_1388( CONT_PARAMS );
static RTYPE compiled_block_1_1390( CONT_PARAMS );
static RTYPE compiled_block_1_1391( CONT_PARAMS );
static RTYPE compiled_temp_1_244( CONT_PARAMS );
static RTYPE compiled_temp_1_243( CONT_PARAMS );
static RTYPE compiled_temp_1_242( CONT_PARAMS );
static RTYPE compiled_block_1_1384( CONT_PARAMS );
static RTYPE compiled_temp_1_241( CONT_PARAMS );
static RTYPE compiled_block_1_1381( CONT_PARAMS );
static RTYPE compiled_block_1_1363( CONT_PARAMS );
static RTYPE compiled_block_1_1378( CONT_PARAMS );
static RTYPE compiled_temp_1_240( CONT_PARAMS );
static RTYPE compiled_temp_1_239( CONT_PARAMS );
static RTYPE compiled_block_1_1373( CONT_PARAMS );
static RTYPE compiled_block_1_1375( CONT_PARAMS );
static RTYPE compiled_temp_1_238( CONT_PARAMS );
static RTYPE compiled_temp_1_237( CONT_PARAMS );
static RTYPE compiled_temp_1_236( CONT_PARAMS );
static RTYPE compiled_block_1_1370( CONT_PARAMS );
static RTYPE compiled_block_1_1369( CONT_PARAMS );
static RTYPE compiled_temp_1_235( CONT_PARAMS );
static RTYPE compiled_block_1_1366( CONT_PARAMS );
static RTYPE compiled_block_1_1361( CONT_PARAMS );
static RTYPE compiled_block_1_1359( CONT_PARAMS );
static RTYPE compiled_start_1_5( CONT_PARAMS );
static RTYPE compiled_block_1_1353( CONT_PARAMS );
static RTYPE compiled_block_1_1352( CONT_PARAMS );
static RTYPE compiled_start_1_4( CONT_PARAMS );
static RTYPE compiled_block_1_1350( CONT_PARAMS );
static RTYPE compiled_block_1_1329( CONT_PARAMS );
static RTYPE compiled_block_1_1242( CONT_PARAMS );
static RTYPE compiled_block_1_1084( CONT_PARAMS );
static RTYPE compiled_start_1_2( CONT_PARAMS );
static RTYPE compiled_block_1_1331( CONT_PARAMS );
static RTYPE compiled_block_1_1333( CONT_PARAMS );
static RTYPE compiled_block_1_1335( CONT_PARAMS );
static RTYPE compiled_block_1_1337( CONT_PARAMS );
static RTYPE compiled_block_1_1340( CONT_PARAMS );
static RTYPE compiled_block_1_1344( CONT_PARAMS );
static RTYPE compiled_block_1_1343( CONT_PARAMS );
static RTYPE compiled_block_1_1342( CONT_PARAMS );
static RTYPE compiled_block_1_1341( CONT_PARAMS );
static RTYPE compiled_block_1_1338( CONT_PARAMS );
static RTYPE compiled_start_1_281( CONT_PARAMS );
static RTYPE compiled_block_1_1299( CONT_PARAMS );
static RTYPE compiled_block_1_1301( CONT_PARAMS );
static RTYPE compiled_block_1_1303( CONT_PARAMS );
static RTYPE compiled_block_1_1305( CONT_PARAMS );
static RTYPE compiled_block_1_1307( CONT_PARAMS );
static RTYPE compiled_block_1_1309( CONT_PARAMS );
static RTYPE compiled_block_1_1312( CONT_PARAMS );
static RTYPE compiled_block_1_1315( CONT_PARAMS );
static RTYPE compiled_block_1_1320( CONT_PARAMS );
static RTYPE compiled_block_1_1319( CONT_PARAMS );
static RTYPE compiled_block_1_1318( CONT_PARAMS );
static RTYPE compiled_block_1_1317( CONT_PARAMS );
static RTYPE compiled_block_1_1316( CONT_PARAMS );
static RTYPE compiled_block_1_1313( CONT_PARAMS );
static RTYPE compiled_block_1_1310( CONT_PARAMS );
static RTYPE compiled_block_1_1244( CONT_PARAMS );
static RTYPE compiled_block_1_1285( CONT_PARAMS );
static RTYPE compiled_block_1_1287( CONT_PARAMS );
static RTYPE compiled_block_1_1289( CONT_PARAMS );
static RTYPE compiled_block_1_1292( CONT_PARAMS );
static RTYPE compiled_block_1_1293( CONT_PARAMS );
static RTYPE compiled_block_1_1290( CONT_PARAMS );
static RTYPE compiled_block_1_1243( CONT_PARAMS );
static RTYPE compiled_block_1_1247( CONT_PARAMS );
static RTYPE compiled_block_1_1249( CONT_PARAMS );
static RTYPE compiled_block_1_1251( CONT_PARAMS );
static RTYPE compiled_block_1_1253( CONT_PARAMS );
static RTYPE compiled_block_1_1255( CONT_PARAMS );
static RTYPE compiled_block_1_1257( CONT_PARAMS );
static RTYPE compiled_block_1_1260( CONT_PARAMS );
static RTYPE compiled_block_1_1262( CONT_PARAMS );
static RTYPE compiled_block_1_1265( CONT_PARAMS );
static RTYPE compiled_block_1_1274( CONT_PARAMS );
static RTYPE compiled_block_1_1273( CONT_PARAMS );
static RTYPE compiled_block_1_1272( CONT_PARAMS );
static RTYPE compiled_block_1_1271( CONT_PARAMS );
static RTYPE compiled_block_1_1270( CONT_PARAMS );
static RTYPE compiled_block_1_1269( CONT_PARAMS );
static RTYPE compiled_block_1_1268( CONT_PARAMS );
static RTYPE compiled_block_1_1267( CONT_PARAMS );
static RTYPE compiled_block_1_1266( CONT_PARAMS );
static RTYPE compiled_block_1_1263( CONT_PARAMS );
static RTYPE compiled_block_1_1258( CONT_PARAMS );
static RTYPE compiled_start_1_280( CONT_PARAMS );
static RTYPE compiled_block_1_1194( CONT_PARAMS );
static RTYPE compiled_block_1_1196( CONT_PARAMS );
static RTYPE compiled_block_1_1198( CONT_PARAMS );
static RTYPE compiled_block_1_1200( CONT_PARAMS );
static RTYPE compiled_block_1_1202( CONT_PARAMS );
static RTYPE compiled_block_1_1204( CONT_PARAMS );
static RTYPE compiled_block_1_1235( CONT_PARAMS );
static RTYPE compiled_block_1_1234( CONT_PARAMS );
static RTYPE compiled_block_1_1233( CONT_PARAMS );
static RTYPE compiled_block_1_1232( CONT_PARAMS );
static RTYPE compiled_block_1_1231( CONT_PARAMS );
static RTYPE compiled_block_1_1230( CONT_PARAMS );
static RTYPE compiled_block_1_1229( CONT_PARAMS );
static RTYPE compiled_block_1_1228( CONT_PARAMS );
static RTYPE compiled_block_1_1227( CONT_PARAMS );
static RTYPE compiled_block_1_1226( CONT_PARAMS );
static RTYPE compiled_block_1_1225( CONT_PARAMS );
static RTYPE compiled_block_1_1224( CONT_PARAMS );
static RTYPE compiled_block_1_1223( CONT_PARAMS );
static RTYPE compiled_block_1_1222( CONT_PARAMS );
static RTYPE compiled_block_1_1221( CONT_PARAMS );
static RTYPE compiled_block_1_1220( CONT_PARAMS );
static RTYPE compiled_block_1_1219( CONT_PARAMS );
static RTYPE compiled_block_1_1218( CONT_PARAMS );
static RTYPE compiled_block_1_1217( CONT_PARAMS );
static RTYPE compiled_block_1_1216( CONT_PARAMS );
static RTYPE compiled_block_1_1215( CONT_PARAMS );
static RTYPE compiled_block_1_1214( CONT_PARAMS );
static RTYPE compiled_block_1_1213( CONT_PARAMS );
static RTYPE compiled_block_1_1212( CONT_PARAMS );
static RTYPE compiled_block_1_1211( CONT_PARAMS );
static RTYPE compiled_block_1_1210( CONT_PARAMS );
static RTYPE compiled_block_1_1209( CONT_PARAMS );
static RTYPE compiled_block_1_1208( CONT_PARAMS );
static RTYPE compiled_block_1_1207( CONT_PARAMS );
static RTYPE compiled_block_1_1206( CONT_PARAMS );
static RTYPE compiled_block_1_1205( CONT_PARAMS );
static RTYPE compiled_block_1_1087( CONT_PARAMS );
static RTYPE compiled_block_1_1142( CONT_PARAMS );
static RTYPE compiled_block_1_1144( CONT_PARAMS );
static RTYPE compiled_block_1_1146( CONT_PARAMS );
static RTYPE compiled_block_1_1148( CONT_PARAMS );
static RTYPE compiled_block_1_1150( CONT_PARAMS );
static RTYPE compiled_block_1_1152( CONT_PARAMS );
static RTYPE compiled_block_1_1154( CONT_PARAMS );
static RTYPE compiled_block_1_1185( CONT_PARAMS );
static RTYPE compiled_block_1_1184( CONT_PARAMS );
static RTYPE compiled_block_1_1183( CONT_PARAMS );
static RTYPE compiled_block_1_1182( CONT_PARAMS );
static RTYPE compiled_block_1_1181( CONT_PARAMS );
static RTYPE compiled_block_1_1180( CONT_PARAMS );
static RTYPE compiled_block_1_1179( CONT_PARAMS );
static RTYPE compiled_block_1_1178( CONT_PARAMS );
static RTYPE compiled_block_1_1177( CONT_PARAMS );
static RTYPE compiled_block_1_1176( CONT_PARAMS );
static RTYPE compiled_block_1_1175( CONT_PARAMS );
static RTYPE compiled_block_1_1174( CONT_PARAMS );
static RTYPE compiled_block_1_1173( CONT_PARAMS );
static RTYPE compiled_block_1_1172( CONT_PARAMS );
static RTYPE compiled_block_1_1171( CONT_PARAMS );
static RTYPE compiled_block_1_1170( CONT_PARAMS );
static RTYPE compiled_block_1_1169( CONT_PARAMS );
static RTYPE compiled_block_1_1168( CONT_PARAMS );
static RTYPE compiled_block_1_1167( CONT_PARAMS );
static RTYPE compiled_block_1_1166( CONT_PARAMS );
static RTYPE compiled_block_1_1165( CONT_PARAMS );
static RTYPE compiled_block_1_1164( CONT_PARAMS );
static RTYPE compiled_block_1_1163( CONT_PARAMS );
static RTYPE compiled_block_1_1162( CONT_PARAMS );
static RTYPE compiled_block_1_1161( CONT_PARAMS );
static RTYPE compiled_block_1_1160( CONT_PARAMS );
static RTYPE compiled_block_1_1159( CONT_PARAMS );
static RTYPE compiled_block_1_1158( CONT_PARAMS );
static RTYPE compiled_block_1_1157( CONT_PARAMS );
static RTYPE compiled_block_1_1156( CONT_PARAMS );
static RTYPE compiled_block_1_1155( CONT_PARAMS );
static RTYPE compiled_block_1_1086( CONT_PARAMS );
static RTYPE compiled_block_1_1109( CONT_PARAMS );
static RTYPE compiled_block_1_1111( CONT_PARAMS );
static RTYPE compiled_block_1_1113( CONT_PARAMS );
static RTYPE compiled_block_1_1115( CONT_PARAMS );
static RTYPE compiled_block_1_1117( CONT_PARAMS );
static RTYPE compiled_block_1_1119( CONT_PARAMS );
static RTYPE compiled_block_1_1121( CONT_PARAMS );
static RTYPE compiled_block_1_1123( CONT_PARAMS );
static RTYPE compiled_block_1_1132( CONT_PARAMS );
static RTYPE compiled_block_1_1131( CONT_PARAMS );
static RTYPE compiled_block_1_1130( CONT_PARAMS );
static RTYPE compiled_block_1_1129( CONT_PARAMS );
static RTYPE compiled_block_1_1128( CONT_PARAMS );
static RTYPE compiled_block_1_1127( CONT_PARAMS );
static RTYPE compiled_block_1_1126( CONT_PARAMS );
static RTYPE compiled_block_1_1125( CONT_PARAMS );
static RTYPE compiled_block_1_1124( CONT_PARAMS );
static RTYPE compiled_block_1_1085( CONT_PARAMS );
static RTYPE compiled_block_1_1090( CONT_PARAMS );
static RTYPE compiled_block_1_1092( CONT_PARAMS );
static RTYPE compiled_block_1_1094( CONT_PARAMS );
static RTYPE compiled_block_1_1096( CONT_PARAMS );
static RTYPE compiled_block_1_1098( CONT_PARAMS );
static RTYPE compiled_block_1_1102( CONT_PARAMS );
static RTYPE compiled_block_1_1101( CONT_PARAMS );
static RTYPE compiled_block_1_1100( CONT_PARAMS );
static RTYPE compiled_block_1_1099( CONT_PARAMS );
static RTYPE compiled_start_1_279( CONT_PARAMS );
static RTYPE compiled_block_1_1066( CONT_PARAMS );
static RTYPE compiled_block_1_1068( CONT_PARAMS );
static RTYPE compiled_block_1_1070( CONT_PARAMS );
static RTYPE compiled_block_1_1072( CONT_PARAMS );
static RTYPE compiled_block_1_1074( CONT_PARAMS );
static RTYPE compiled_block_1_1078( CONT_PARAMS );
static RTYPE compiled_block_1_1077( CONT_PARAMS );
static RTYPE compiled_block_1_1076( CONT_PARAMS );
static RTYPE compiled_block_1_1075( CONT_PARAMS );
static RTYPE compiled_block_1_1004( CONT_PARAMS );
static RTYPE compiled_block_1_1044( CONT_PARAMS );
static RTYPE compiled_block_1_1046( CONT_PARAMS );
static RTYPE compiled_block_1_1048( CONT_PARAMS );
static RTYPE compiled_block_1_1050( CONT_PARAMS );
static RTYPE compiled_block_1_1052( CONT_PARAMS );
static RTYPE compiled_block_1_1054( CONT_PARAMS );
static RTYPE compiled_block_1_1058( CONT_PARAMS );
static RTYPE compiled_block_1_1057( CONT_PARAMS );
static RTYPE compiled_block_1_1056( CONT_PARAMS );
static RTYPE compiled_block_1_1055( CONT_PARAMS );
static RTYPE compiled_block_1_1003( CONT_PARAMS );
static RTYPE compiled_block_1_1020( CONT_PARAMS );
static RTYPE compiled_block_1_1022( CONT_PARAMS );
static RTYPE compiled_block_1_1024( CONT_PARAMS );
static RTYPE compiled_block_1_1026( CONT_PARAMS );
static RTYPE compiled_block_1_1028( CONT_PARAMS );
static RTYPE compiled_block_1_1030( CONT_PARAMS );
static RTYPE compiled_block_1_1032( CONT_PARAMS );
static RTYPE compiled_block_1_1035( CONT_PARAMS );
static RTYPE compiled_block_1_1034( CONT_PARAMS );
static RTYPE compiled_block_1_1033( CONT_PARAMS );
static RTYPE compiled_block_1_1002( CONT_PARAMS );
static RTYPE compiled_block_1_1007( CONT_PARAMS );
static RTYPE compiled_block_1_1009( CONT_PARAMS );
static RTYPE compiled_block_1_1011( CONT_PARAMS );
static RTYPE compiled_block_1_1013( CONT_PARAMS );
static RTYPE compiled_block_1_1014( CONT_PARAMS );
static RTYPE compiled_start_1_278( CONT_PARAMS );
static RTYPE compiled_start_1_1( CONT_PARAMS );

static RTYPE compiled_start_1_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 2 ); /*  cat~1ay%kV~27213 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 3 ); /*  real->flonum-string~1ay%kV~26972 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 4 ); /*  non-0-dot-index-right~1ay%kV~26971 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 5 ); /*  non-0-index-right~1ay%kV~26970 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 6 ); /*  non-0-index~1ay%kV~26969 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 7 ); /*  real->fixnum-string~1ay%kV~26968 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 8 ); /*  remove-zero~1ay%kV~26967 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 9 ); /*  flonum-mold~1ay%kV~26966 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 10 ); /*  e-mold~1ay%kV~26965 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 11 ); /*  mold-non-finites~1ay%kV~26964 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 12 ); /*  mold~1ay%kV~26963 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 13 ); /*  exact-integer/string?~1ay%kV~26962 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 14 ); /*  exact-integer?~1ay%kV~26961 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 15 ); /*  every-within-number?~1ay%kV~26960 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 16 ); /*  every?~1ay%kV~26959 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 17 ); /*  separate~1ay%kV~26958 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 18 ); /*  fixnum-string-separate~1ay%kV~26957 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 19 ); /*  str-numeric?~1ay%kV~26956 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 20 ); /*  str-numeric-index~1ay%kV~26955 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 21 ); /*  str-char-index~1ay%kV~26954 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 22 ); /*  take-both-end~1ay%kV~26953 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 23 ); /*  object->string~1ay%kV~26952 */
  twobit_lambda( compiled_start_1_1, 25, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_2, 27, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_3, 29, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 30 );
  twobit_setreg( 1 );
  twobit_const( 31 );
  twobit_setreg( 3 );
  twobit_const( 32 );
  twobit_setreg( 4 );
  twobit_const( 33 );
  twobit_setreg( 5 );
  twobit_const( 34 );
  twobit_setreg( 8 );
  twobit_global( 35 ); /* ex:make-library */
  twobit_setrtn( 2514, compiled_block_1_2514 );
  twobit_invoke( 8 );
  twobit_label( 2514, compiled_block_1_2514 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 36 ); /* ex:register-library! */
  twobit_setrtn( 2515, compiled_block_1_2515 );
  twobit_invoke( 1 );
  twobit_label( 2515, compiled_block_1_2515 );
  twobit_load( 0, 0 );
  twobit_global( 37 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* ex:uncompress */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_278, 2, 0 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1084, compiled_block_1_1084 );
  twobit_invoke( 2 );
  twobit_label( 1084, compiled_block_1_1084 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_279, 6, 0 );
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1242, compiled_block_1_1242 );
  twobit_invoke( 2 );
  twobit_label( 1242, compiled_block_1_1242 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_280, 9, 0 );
  twobit_setreg( 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1329, compiled_block_1_1329 );
  twobit_invoke( 2 );
  twobit_label( 1329, compiled_block_1_1329 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_281, 12, 0 );
  twobit_setreg( 2 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1350, compiled_block_1_1350 );
  twobit_invoke( 2 );
  twobit_label( 1350, compiled_block_1_1350 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_278( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1007, compiled_block_1_1007 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1009, compiled_block_1_1009 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1011, compiled_block_1_1011 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1013, compiled_block_1_1013 ); /* internal:branchf-null? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1014, compiled_block_1_1014 );
  twobit_invoke( 5 );
  twobit_label( 1014, compiled_block_1_1014 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1013, compiled_block_1_1013 );
  twobit_branch( 1004, compiled_block_1_1004 );
  twobit_label( 1011, compiled_block_1_1011 );
  twobit_branch( 1004, compiled_block_1_1004 );
  twobit_label( 1009, compiled_block_1_1009 );
  twobit_branch( 1004, compiled_block_1_1004 );
  twobit_label( 1007, compiled_block_1_1007 );
  twobit_branch( 1004, compiled_block_1_1004 );
  twobit_label( 1002, compiled_block_1_1002 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1020, compiled_block_1_1020 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1022, compiled_block_1_1022 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1024, compiled_block_1_1024 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1026, compiled_block_1_1026 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1028, compiled_block_1_1028 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1030, compiled_block_1_1030 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 29 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1032, compiled_block_1_1032 ); /* internal:branchf-null? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_store( 3, 1 );
  twobit_store( 29, 3 );
  twobit_store( 30, 4 );
  twobit_store( 31, 5 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1033, compiled_block_1_1033 );
  twobit_invoke( 5 );
  twobit_label( 1033, compiled_block_1_1033 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1034, compiled_block_1_1034 );
  twobit_invoke( 5 );
  twobit_label( 1034, compiled_block_1_1034 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 6 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1035, compiled_block_1_1035 );
  twobit_invoke( 5 );
  twobit_label( 1035, compiled_block_1_1035 );
  twobit_load( 0, 0 );
  twobit_load( 3, 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1032, compiled_block_1_1032 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1030, compiled_block_1_1030 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1028, compiled_block_1_1028 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1026, compiled_block_1_1026 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1024, compiled_block_1_1024 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1022, compiled_block_1_1022 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1020, compiled_block_1_1020 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1003, compiled_block_1_1003 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1044, compiled_block_1_1044 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1046, compiled_block_1_1046 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1048, compiled_block_1_1048 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1050, compiled_block_1_1050 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1052, compiled_block_1_1052 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1054, compiled_block_1_1054 ); /* internal:branchf-null? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 2, 3 );
  twobit_store( 3, 1 );
  twobit_store( 30, 4 );
  twobit_store( 31, 5 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1055, compiled_block_1_1055 );
  twobit_invoke( 5 );
  twobit_label( 1055, compiled_block_1_1055 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1056, compiled_block_1_1056 );
  twobit_invoke( 5 );
  twobit_label( 1056, compiled_block_1_1056 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1057, compiled_block_1_1057 );
  twobit_invoke( 5 );
  twobit_label( 1057, compiled_block_1_1057 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 10 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1058, compiled_block_1_1058 );
  twobit_invoke( 5 );
  twobit_label( 1058, compiled_block_1_1058 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1054, compiled_block_1_1054 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1052, compiled_block_1_1052 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1050, compiled_block_1_1050 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1048, compiled_block_1_1048 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1046, compiled_block_1_1046 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1044, compiled_block_1_1044 );
  twobit_branch( 1002, compiled_block_1_1002 );
  twobit_label( 1004, compiled_block_1_1004 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1066, compiled_block_1_1066 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1068, compiled_block_1_1068 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1070, compiled_block_1_1070 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1072, compiled_block_1_1072 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1074, compiled_block_1_1074 ); /* internal:branchf-null? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 2, 3 );
  twobit_store( 3, 1 );
  twobit_store( 31, 4 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1075, compiled_block_1_1075 );
  twobit_invoke( 5 );
  twobit_label( 1075, compiled_block_1_1075 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1076, compiled_block_1_1076 );
  twobit_invoke( 5 );
  twobit_label( 1076, compiled_block_1_1076 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1077, compiled_block_1_1077 );
  twobit_invoke( 5 );
  twobit_label( 1077, compiled_block_1_1077 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_const( 10 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1078, compiled_block_1_1078 );
  twobit_invoke( 5 );
  twobit_label( 1078, compiled_block_1_1078 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1074, compiled_block_1_1074 );
  twobit_branch( 1003, compiled_block_1_1003 );
  twobit_label( 1072, compiled_block_1_1072 );
  twobit_branch( 1003, compiled_block_1_1003 );
  twobit_label( 1070, compiled_block_1_1070 );
  twobit_branch( 1003, compiled_block_1_1003 );
  twobit_label( 1068, compiled_block_1_1068 );
  twobit_branch( 1003, compiled_block_1_1003 );
  twobit_label( 1066, compiled_block_1_1066 );
  twobit_branch( 1003, compiled_block_1_1003 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_279( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1090, compiled_block_1_1090 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1092, compiled_block_1_1092 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1094, compiled_block_1_1094 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1096, compiled_block_1_1096 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1098, compiled_block_1_1098 ); /* internal:branchf-null? */
  twobit_save( 6 );
  twobit_store( 0, 0 );
  twobit_store( 2, 3 );
  twobit_store( 3, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1099, compiled_block_1_1099 );
  twobit_invoke( 5 );
  twobit_label( 1099, compiled_block_1_1099 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1100, compiled_block_1_1100 );
  twobit_invoke( 5 );
  twobit_label( 1100, compiled_block_1_1100 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1101, compiled_block_1_1101 );
  twobit_invoke( 5 );
  twobit_label( 1101, compiled_block_1_1101 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1102, compiled_block_1_1102 );
  twobit_invoke( 5 );
  twobit_label( 1102, compiled_block_1_1102 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 6 );
  twobit_return();
  twobit_label( 1098, compiled_block_1_1098 );
  twobit_branch( 1087, compiled_block_1_1087 );
  twobit_label( 1096, compiled_block_1_1096 );
  twobit_branch( 1087, compiled_block_1_1087 );
  twobit_label( 1094, compiled_block_1_1094 );
  twobit_branch( 1087, compiled_block_1_1087 );
  twobit_label( 1092, compiled_block_1_1092 );
  twobit_branch( 1087, compiled_block_1_1087 );
  twobit_label( 1090, compiled_block_1_1090 );
  twobit_branch( 1087, compiled_block_1_1087 );
  twobit_label( 1085, compiled_block_1_1085 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1109, compiled_block_1_1109 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1111, compiled_block_1_1111 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1113, compiled_block_1_1113 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1115, compiled_block_1_1115 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1117, compiled_block_1_1117 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1119, compiled_block_1_1119 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1121, compiled_block_1_1121 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 29 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1123, compiled_block_1_1123 ); /* internal:branchf-null? */
  twobit_save( 10 );
  twobit_store( 0, 0 );
  twobit_store( 2, 3 );
  twobit_store( 3, 1 );
  twobit_store( 29, 6 );
  twobit_store( 30, 4 );
  twobit_store( 31, 7 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1124, compiled_block_1_1124 );
  twobit_invoke( 5 );
  twobit_label( 1124, compiled_block_1_1124 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1125, compiled_block_1_1125 );
  twobit_invoke( 5 );
  twobit_label( 1125, compiled_block_1_1125 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1126, compiled_block_1_1126 );
  twobit_invoke( 5 );
  twobit_label( 1126, compiled_block_1_1126 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1127, compiled_block_1_1127 );
  twobit_invoke( 5 );
  twobit_label( 1127, compiled_block_1_1127 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1128, compiled_block_1_1128 );
  twobit_invoke( 5 );
  twobit_label( 1128, compiled_block_1_1128 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1129, compiled_block_1_1129 );
  twobit_invoke( 5 );
  twobit_label( 1129, compiled_block_1_1129 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1130, compiled_block_1_1130 );
  twobit_invoke( 5 );
  twobit_label( 1130, compiled_block_1_1130 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1131, compiled_block_1_1131 );
  twobit_invoke( 5 );
  twobit_label( 1131, compiled_block_1_1131 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1132, compiled_block_1_1132 );
  twobit_invoke( 5 );
  twobit_label( 1132, compiled_block_1_1132 );
  twobit_load( 0, 0 );
  twobit_load( 3, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 10 );
  twobit_return();
  twobit_label( 1123, compiled_block_1_1123 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1121, compiled_block_1_1121 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1119, compiled_block_1_1119 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1117, compiled_block_1_1117 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1115, compiled_block_1_1115 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1113, compiled_block_1_1113 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1111, compiled_block_1_1111 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1109, compiled_block_1_1109 );
  twobit_global( 11 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1086, compiled_block_1_1086 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1142, compiled_block_1_1142 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1144, compiled_block_1_1144 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1146, compiled_block_1_1146 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1148, compiled_block_1_1148 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1150, compiled_block_1_1150 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1152, compiled_block_1_1152 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 29 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1154, compiled_block_1_1154 ); /* internal:branchf-null? */
  twobit_save( 22 );
  twobit_store( 0, 0 );
  twobit_store( 2, 3 );
  twobit_store( 3, 1 );
  twobit_store( 29, 4 );
  twobit_store( 30, 9 );
  twobit_store( 31, 13 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1155, compiled_block_1_1155 );
  twobit_invoke( 5 );
  twobit_label( 1155, compiled_block_1_1155 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 22 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1156, compiled_block_1_1156 );
  twobit_invoke( 5 );
  twobit_label( 1156, compiled_block_1_1156 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 21 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1157, compiled_block_1_1157 );
  twobit_invoke( 5 );
  twobit_label( 1157, compiled_block_1_1157 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 20 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1158, compiled_block_1_1158 );
  twobit_invoke( 5 );
  twobit_label( 1158, compiled_block_1_1158 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1159, compiled_block_1_1159 );
  twobit_invoke( 5 );
  twobit_label( 1159, compiled_block_1_1159 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1160, compiled_block_1_1160 );
  twobit_invoke( 5 );
  twobit_label( 1160, compiled_block_1_1160 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 19 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1161, compiled_block_1_1161 );
  twobit_invoke( 5 );
  twobit_label( 1161, compiled_block_1_1161 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 18 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1162, compiled_block_1_1162 );
  twobit_invoke( 5 );
  twobit_label( 1162, compiled_block_1_1162 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 17 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1163, compiled_block_1_1163 );
  twobit_invoke( 5 );
  twobit_label( 1163, compiled_block_1_1163 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1164, compiled_block_1_1164 );
  twobit_invoke( 5 );
  twobit_label( 1164, compiled_block_1_1164 );
  twobit_load( 0, 0 );
  twobit_load( 3, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1165, compiled_block_1_1165 );
  twobit_invoke( 5 );
  twobit_label( 1165, compiled_block_1_1165 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1166, compiled_block_1_1166 );
  twobit_invoke( 5 );
  twobit_label( 1166, compiled_block_1_1166 );
  twobit_load( 0, 0 );
  twobit_load( 3, 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 16 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1167, compiled_block_1_1167 );
  twobit_invoke( 5 );
  twobit_label( 1167, compiled_block_1_1167 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 15 );
  twobit_const( 17 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1168, compiled_block_1_1168 );
  twobit_invoke( 5 );
  twobit_label( 1168, compiled_block_1_1168 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1169, compiled_block_1_1169 );
  twobit_invoke( 5 );
  twobit_label( 1169, compiled_block_1_1169 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 14 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1170, compiled_block_1_1170 );
  twobit_invoke( 5 );
  twobit_label( 1170, compiled_block_1_1170 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1171, compiled_block_1_1171 );
  twobit_invoke( 5 );
  twobit_label( 1171, compiled_block_1_1171 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1172, compiled_block_1_1172 );
  twobit_invoke( 5 );
  twobit_label( 1172, compiled_block_1_1172 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1173, compiled_block_1_1173 );
  twobit_invoke( 5 );
  twobit_label( 1173, compiled_block_1_1173 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1174, compiled_block_1_1174 );
  twobit_invoke( 5 );
  twobit_label( 1174, compiled_block_1_1174 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1175, compiled_block_1_1175 );
  twobit_invoke( 5 );
  twobit_label( 1175, compiled_block_1_1175 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 18 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1176, compiled_block_1_1176 );
  twobit_invoke( 5 );
  twobit_label( 1176, compiled_block_1_1176 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1177, compiled_block_1_1177 );
  twobit_invoke( 5 );
  twobit_label( 1177, compiled_block_1_1177 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1178, compiled_block_1_1178 );
  twobit_invoke( 5 );
  twobit_label( 1178, compiled_block_1_1178 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1179, compiled_block_1_1179 );
  twobit_invoke( 5 );
  twobit_label( 1179, compiled_block_1_1179 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1180, compiled_block_1_1180 );
  twobit_invoke( 5 );
  twobit_label( 1180, compiled_block_1_1180 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1181, compiled_block_1_1181 );
  twobit_invoke( 5 );
  twobit_label( 1181, compiled_block_1_1181 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 20 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1182, compiled_block_1_1182 );
  twobit_invoke( 5 );
  twobit_label( 1182, compiled_block_1_1182 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1183, compiled_block_1_1183 );
  twobit_invoke( 5 );
  twobit_label( 1183, compiled_block_1_1183 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1184, compiled_block_1_1184 );
  twobit_invoke( 5 );
  twobit_label( 1184, compiled_block_1_1184 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1185, compiled_block_1_1185 );
  twobit_invoke( 5 );
  twobit_label( 1185, compiled_block_1_1185 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 13 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 14 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 15 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 16 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 17 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 18 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 19 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 20 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 21 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 22 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 22 );
  twobit_return();
  twobit_label( 1154, compiled_block_1_1154 );
  twobit_branch( 1085, compiled_block_1_1085 );
  twobit_label( 1152, compiled_block_1_1152 );
  twobit_branch( 1085, compiled_block_1_1085 );
  twobit_label( 1150, compiled_block_1_1150 );
  twobit_branch( 1085, compiled_block_1_1085 );
  twobit_label( 1148, compiled_block_1_1148 );
  twobit_branch( 1085, compiled_block_1_1085 );
  twobit_label( 1146, compiled_block_1_1146 );
  twobit_branch( 1085, compiled_block_1_1085 );
  twobit_label( 1144, compiled_block_1_1144 );
  twobit_branch( 1085, compiled_block_1_1085 );
  twobit_label( 1142, compiled_block_1_1142 );
  twobit_branch( 1085, compiled_block_1_1085 );
  twobit_label( 1087, compiled_block_1_1087 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1194, compiled_block_1_1194 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1196, compiled_block_1_1196 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1198, compiled_block_1_1198 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1200, compiled_block_1_1200 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1202, compiled_block_1_1202 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1204, compiled_block_1_1204 ); /* internal:branchf-null? */
  twobit_save( 22 );
  twobit_store( 0, 0 );
  twobit_store( 2, 3 );
  twobit_store( 3, 1 );
  twobit_store( 30, 9 );
  twobit_store( 31, 13 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1205, compiled_block_1_1205 );
  twobit_invoke( 5 );
  twobit_label( 1205, compiled_block_1_1205 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 22 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1206, compiled_block_1_1206 );
  twobit_invoke( 5 );
  twobit_label( 1206, compiled_block_1_1206 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 21 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1207, compiled_block_1_1207 );
  twobit_invoke( 5 );
  twobit_label( 1207, compiled_block_1_1207 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 20 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1208, compiled_block_1_1208 );
  twobit_invoke( 5 );
  twobit_label( 1208, compiled_block_1_1208 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1209, compiled_block_1_1209 );
  twobit_invoke( 5 );
  twobit_label( 1209, compiled_block_1_1209 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1210, compiled_block_1_1210 );
  twobit_invoke( 5 );
  twobit_label( 1210, compiled_block_1_1210 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 19 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1211, compiled_block_1_1211 );
  twobit_invoke( 5 );
  twobit_label( 1211, compiled_block_1_1211 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 18 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1212, compiled_block_1_1212 );
  twobit_invoke( 5 );
  twobit_label( 1212, compiled_block_1_1212 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 17 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1213, compiled_block_1_1213 );
  twobit_invoke( 5 );
  twobit_label( 1213, compiled_block_1_1213 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1214, compiled_block_1_1214 );
  twobit_invoke( 5 );
  twobit_label( 1214, compiled_block_1_1214 );
  twobit_load( 0, 0 );
  twobit_load( 3, 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1215, compiled_block_1_1215 );
  twobit_invoke( 5 );
  twobit_label( 1215, compiled_block_1_1215 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1216, compiled_block_1_1216 );
  twobit_invoke( 5 );
  twobit_label( 1216, compiled_block_1_1216 );
  twobit_load( 0, 0 );
  twobit_load( 3, 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 16 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1217, compiled_block_1_1217 );
  twobit_invoke( 5 );
  twobit_label( 1217, compiled_block_1_1217 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 15 );
  twobit_const( 17 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1218, compiled_block_1_1218 );
  twobit_invoke( 5 );
  twobit_label( 1218, compiled_block_1_1218 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1219, compiled_block_1_1219 );
  twobit_invoke( 5 );
  twobit_label( 1219, compiled_block_1_1219 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 14 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1220, compiled_block_1_1220 );
  twobit_invoke( 5 );
  twobit_label( 1220, compiled_block_1_1220 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1221, compiled_block_1_1221 );
  twobit_invoke( 5 );
  twobit_label( 1221, compiled_block_1_1221 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1222, compiled_block_1_1222 );
  twobit_invoke( 5 );
  twobit_label( 1222, compiled_block_1_1222 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1223, compiled_block_1_1223 );
  twobit_invoke( 5 );
  twobit_label( 1223, compiled_block_1_1223 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1224, compiled_block_1_1224 );
  twobit_invoke( 5 );
  twobit_label( 1224, compiled_block_1_1224 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 7 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1225, compiled_block_1_1225 );
  twobit_invoke( 5 );
  twobit_label( 1225, compiled_block_1_1225 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 18 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1226, compiled_block_1_1226 );
  twobit_invoke( 5 );
  twobit_label( 1226, compiled_block_1_1226 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 19 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1227, compiled_block_1_1227 );
  twobit_invoke( 5 );
  twobit_label( 1227, compiled_block_1_1227 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1228, compiled_block_1_1228 );
  twobit_invoke( 5 );
  twobit_label( 1228, compiled_block_1_1228 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1229, compiled_block_1_1229 );
  twobit_invoke( 5 );
  twobit_label( 1229, compiled_block_1_1229 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1230, compiled_block_1_1230 );
  twobit_invoke( 5 );
  twobit_label( 1230, compiled_block_1_1230 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_load( 3, 7 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1231, compiled_block_1_1231 );
  twobit_invoke( 5 );
  twobit_label( 1231, compiled_block_1_1231 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 20 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1232, compiled_block_1_1232 );
  twobit_invoke( 5 );
  twobit_label( 1232, compiled_block_1_1232 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 14 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1233, compiled_block_1_1233 );
  twobit_invoke( 5 );
  twobit_label( 1233, compiled_block_1_1233 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1234, compiled_block_1_1234 );
  twobit_invoke( 5 );
  twobit_label( 1234, compiled_block_1_1234 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1235, compiled_block_1_1235 );
  twobit_invoke( 5 );
  twobit_label( 1235, compiled_block_1_1235 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 12 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 13 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 14 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 15 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 16 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 17 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 18 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 19 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 20 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 21 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 22 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 22 );
  twobit_return();
  twobit_label( 1204, compiled_block_1_1204 );
  twobit_branch( 1086, compiled_block_1_1086 );
  twobit_label( 1202, compiled_block_1_1202 );
  twobit_branch( 1086, compiled_block_1_1086 );
  twobit_label( 1200, compiled_block_1_1200 );
  twobit_branch( 1086, compiled_block_1_1086 );
  twobit_label( 1198, compiled_block_1_1198 );
  twobit_branch( 1086, compiled_block_1_1086 );
  twobit_label( 1196, compiled_block_1_1196 );
  twobit_branch( 1086, compiled_block_1_1086 );
  twobit_label( 1194, compiled_block_1_1194 );
  twobit_branch( 1086, compiled_block_1_1086 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_280( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1247, compiled_block_1_1247 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1249, compiled_block_1_1249 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1251, compiled_block_1_1251 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1253, compiled_block_1_1253 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_branchf_611( 1255, compiled_block_1_1255 ); /* internal:branchf-pair? */
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_branchf_611( 1257, compiled_block_1_1257 ); /* internal:branchf-pair? */
  twobit_save( 12 );
  twobit_store( 0, 0 );
  twobit_store( 1, 12 );
  twobit_store( 2, 1 );
  twobit_store( 3, 3 );
  twobit_store( 4, 2 );
  twobit_store( 30, 5 );
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 29 );
  twobit_store( 29, 7 );
  twobit_reg( 31 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 4 );
  twobit_movereg( 31, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1258, compiled_block_1_1258 );
  twobit_invoke( 1 );
  twobit_label( 1258, compiled_block_1_1258 );
  twobit_load( 0, 0 );
  twobit_branchf( 1260, compiled_block_1_1260 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1262, compiled_block_1_1262 ); /* internal:branchf-null? */
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1263, compiled_block_1_1263 );
  twobit_invoke( 1 );
  twobit_label( 1263, compiled_block_1_1263 );
  twobit_load( 0, 0 );
  twobit_branchf( 1265, compiled_block_1_1265 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1266, compiled_block_1_1266 );
  twobit_invoke( 5 );
  twobit_label( 1266, compiled_block_1_1266 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1267, compiled_block_1_1267 );
  twobit_invoke( 5 );
  twobit_label( 1267, compiled_block_1_1267 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1268, compiled_block_1_1268 );
  twobit_invoke( 5 );
  twobit_label( 1268, compiled_block_1_1268 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1269, compiled_block_1_1269 );
  twobit_invoke( 5 );
  twobit_label( 1269, compiled_block_1_1269 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1270, compiled_block_1_1270 );
  twobit_invoke( 5 );
  twobit_label( 1270, compiled_block_1_1270 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1271, compiled_block_1_1271 );
  twobit_invoke( 5 );
  twobit_label( 1271, compiled_block_1_1271 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 3, 4 );
  twobit_stack( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_const( 9 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1272, compiled_block_1_1272 );
  twobit_invoke( 5 );
  twobit_label( 1272, compiled_block_1_1272 );
  twobit_load( 0, 0 );
  twobit_load( 3, 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 10 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1273, compiled_block_1_1273 );
  twobit_invoke( 5 );
  twobit_label( 1273, compiled_block_1_1273 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1274, compiled_block_1_1274 );
  twobit_invoke( 5 );
  twobit_label( 1274, compiled_block_1_1274 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_const( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 8 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 9 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 10 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 11 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 12 );
  twobit_return();
  twobit_label( 1265, compiled_block_1_1265 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1244, compiled_block_1_1244 );
  twobit_label( 1262, compiled_block_1_1262 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1244, compiled_block_1_1244 );
  twobit_label( 1260, compiled_block_1_1260 );
  twobit_load( 1, 12 );
  twobit_pop( 12 );
  twobit_branch( 1244, compiled_block_1_1244 );
  twobit_label( 1257, compiled_block_1_1257 );
  twobit_branch( 1244, compiled_block_1_1244 );
  twobit_label( 1255, compiled_block_1_1255 );
  twobit_branch( 1244, compiled_block_1_1244 );
  twobit_label( 1253, compiled_block_1_1253 );
  twobit_branch( 1244, compiled_block_1_1244 );
  twobit_label( 1251, compiled_block_1_1251 );
  twobit_branch( 1244, compiled_block_1_1244 );
  twobit_label( 1249, compiled_block_1_1249 );
  twobit_branch( 1244, compiled_block_1_1244 );
  twobit_label( 1247, compiled_block_1_1247 );
  twobit_branch( 1244, compiled_block_1_1244 );
  twobit_label( 1243, compiled_block_1_1243 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1285, compiled_block_1_1285 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1287, compiled_block_1_1287 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1289, compiled_block_1_1289 ); /* internal:branchf-pair? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 4 );
  twobit_store( 3, 1 );
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1290, compiled_block_1_1290 );
  twobit_invoke( 1 );
  twobit_label( 1290, compiled_block_1_1290 );
  twobit_load( 0, 0 );
  twobit_branchf( 1292, compiled_block_1_1292 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 12 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1293, compiled_block_1_1293 );
  twobit_invoke( 5 );
  twobit_label( 1293, compiled_block_1_1293 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1292, compiled_block_1_1292 );
  twobit_load( 1, 4 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_pop( 4 );
  twobit_invoke( 1 );
  twobit_label( 1289, compiled_block_1_1289 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1287, compiled_block_1_1287 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1285, compiled_block_1_1285 );
  twobit_global( 13 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1244, compiled_block_1_1244 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1299, compiled_block_1_1299 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1301, compiled_block_1_1301 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1303, compiled_block_1_1303 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1305, compiled_block_1_1305 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_branchf_611( 1307, compiled_block_1_1307 ); /* internal:branchf-pair? */
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg( 31 );
  twobit_op1_branchf_611( 1309, compiled_block_1_1309 ); /* internal:branchf-pair? */
  twobit_save( 11 );
  twobit_store( 0, 0 );
  twobit_store( 1, 11 );
  twobit_store( 2, 1 );
  twobit_store( 3, 3 );
  twobit_store( 4, 2 );
  twobit_store( 30, 6 );
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 29 );
  twobit_store( 29, 5 );
  twobit_reg( 31 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 4 );
  twobit_movereg( 31, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1310, compiled_block_1_1310 );
  twobit_invoke( 1 );
  twobit_label( 1310, compiled_block_1_1310 );
  twobit_load( 0, 0 );
  twobit_branchf( 1312, compiled_block_1_1312 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 8 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1313, compiled_block_1_1313 );
  twobit_invoke( 1 );
  twobit_label( 1313, compiled_block_1_1313 );
  twobit_load( 0, 0 );
  twobit_branchf( 1315, compiled_block_1_1315 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1316, compiled_block_1_1316 );
  twobit_invoke( 5 );
  twobit_label( 1316, compiled_block_1_1316 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1317, compiled_block_1_1317 );
  twobit_invoke( 5 );
  twobit_label( 1317, compiled_block_1_1317 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1318, compiled_block_1_1318 );
  twobit_invoke( 5 );
  twobit_label( 1318, compiled_block_1_1318 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 3, 4 );
  twobit_stack( 5 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 6 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1319, compiled_block_1_1319 );
  twobit_invoke( 5 );
  twobit_label( 1319, compiled_block_1_1319 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 3, 8 );
  twobit_stack( 9 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_const( 16 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1320, compiled_block_1_1320 );
  twobit_invoke( 5 );
  twobit_label( 1320, compiled_block_1_1320 );
  twobit_load( 0, 0 );
  twobit_load( 3, 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 11 );
  twobit_return();
  twobit_label( 1315, compiled_block_1_1315 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1243, compiled_block_1_1243 );
  twobit_label( 1312, compiled_block_1_1312 );
  twobit_load( 1, 11 );
  twobit_pop( 11 );
  twobit_branch( 1243, compiled_block_1_1243 );
  twobit_label( 1309, compiled_block_1_1309 );
  twobit_branch( 1243, compiled_block_1_1243 );
  twobit_label( 1307, compiled_block_1_1307 );
  twobit_branch( 1243, compiled_block_1_1243 );
  twobit_label( 1305, compiled_block_1_1305 );
  twobit_branch( 1243, compiled_block_1_1243 );
  twobit_label( 1303, compiled_block_1_1303 );
  twobit_branch( 1243, compiled_block_1_1243 );
  twobit_label( 1301, compiled_block_1_1301 );
  twobit_branch( 1243, compiled_block_1_1243 );
  twobit_label( 1299, compiled_block_1_1299 );
  twobit_branch( 1243, compiled_block_1_1243 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_281( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1331, compiled_block_1_1331 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1333, compiled_block_1_1333 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1335, compiled_block_1_1335 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1337, compiled_block_1_1337 ); /* internal:branchf-pair? */
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 7 );
  twobit_store( 3, 1 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_store( 31, 3 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1338, compiled_block_1_1338 );
  twobit_invoke( 1 );
  twobit_label( 1338, compiled_block_1_1338 );
  twobit_load( 0, 0 );
  twobit_branchf( 1340, compiled_block_1_1340 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1341, compiled_block_1_1341 );
  twobit_invoke( 5 );
  twobit_label( 1341, compiled_block_1_1341 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1342, compiled_block_1_1342 );
  twobit_invoke( 5 );
  twobit_label( 1342, compiled_block_1_1342 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1343, compiled_block_1_1343 );
  twobit_invoke( 5 );
  twobit_label( 1343, compiled_block_1_1343 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 3, 2 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 2, 4 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1344, compiled_block_1_1344 );
  twobit_invoke( 5 );
  twobit_label( 1344, compiled_block_1_1344 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1340, compiled_block_1_1340 );
  twobit_load( 1, 7 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_pop( 7 );
  twobit_invoke( 1 );
  twobit_label( 1337, compiled_block_1_1337 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1335, compiled_block_1_1335 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1333, compiled_block_1_1333 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1331, compiled_block_1_1331 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 2 ); /*  cat~1ay%kV~27213 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 3 ); /*  real->flonum-string~1ay%kV~26972 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 4 ); /*  non-0-dot-index-right~1ay%kV~26971 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 5 ); /*  non-0-index-right~1ay%kV~26970 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 6 ); /*  non-0-index~1ay%kV~26969 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 7 ); /*  real->fixnum-string~1ay%kV~26968 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 8 ); /*  remove-zero~1ay%kV~26967 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 9 ); /*  flonum-mold~1ay%kV~26966 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 10 ); /*  e-mold~1ay%kV~26965 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 11 ); /*  mold-non-finites~1ay%kV~26964 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 12 ); /*  mold~1ay%kV~26963 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 13 ); /*  exact-integer/string?~1ay%kV~26962 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 14 ); /*  exact-integer?~1ay%kV~26961 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 15 ); /*  every-within-number?~1ay%kV~26960 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 16 ); /*  every?~1ay%kV~26959 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 17 ); /*  separate~1ay%kV~26958 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 18 ); /*  fixnum-string-separate~1ay%kV~26957 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 19 ); /*  str-numeric?~1ay%kV~26956 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 20 ); /*  str-numeric-index~1ay%kV~26955 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 21 ); /*  str-char-index~1ay%kV~26954 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 22 ); /*  take-both-end~1ay%kV~26953 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 23 ); /*  object->string~1ay%kV~26952 */
  twobit_lambda( compiled_start_1_4, 25, 0 );
  twobit_setglbl( 23 ); /*  object->string~1ay%kV~26952 */
  twobit_lambda( compiled_start_1_5, 27, 0 );
  twobit_setglbl( 22 ); /*  take-both-end~1ay%kV~26953 */
  twobit_lambda( compiled_start_1_6, 29, 0 );
  twobit_setglbl( 21 ); /*  str-char-index~1ay%kV~26954 */
  twobit_lambda( compiled_start_1_7, 31, 0 );
  twobit_setglbl( 20 ); /*  str-numeric-index~1ay%kV~26955 */
  twobit_lambda( compiled_start_1_8, 33, 0 );
  twobit_setglbl( 19 ); /*  str-numeric?~1ay%kV~26956 */
  twobit_lambda( compiled_start_1_9, 35, 0 );
  twobit_setglbl( 18 ); /*  fixnum-string-separate~1ay%kV~26957 */
  twobit_lambda( compiled_start_1_10, 37, 0 );
  twobit_setglbl( 17 ); /*  separate~1ay%kV~26958 */
  twobit_lambda( compiled_start_1_11, 39, 0 );
  twobit_setglbl( 16 ); /*  every?~1ay%kV~26959 */
  twobit_lambda( compiled_start_1_12, 41, 0 );
  twobit_setglbl( 15 ); /*  every-within-number?~1ay%kV~26960 */
  twobit_lambda( compiled_start_1_13, 43, 0 );
  twobit_setglbl( 14 ); /*  exact-integer?~1ay%kV~26961 */
  twobit_lambda( compiled_start_1_14, 45, 0 );
  twobit_setglbl( 13 ); /*  exact-integer/string?~1ay%kV~26962 */
  twobit_lambda( compiled_start_1_15, 47, 0 );
  twobit_setglbl( 12 ); /*  mold~1ay%kV~26963 */
  twobit_lambda( compiled_start_1_16, 49, 0 );
  twobit_setglbl( 11 ); /*  mold-non-finites~1ay%kV~26964 */
  twobit_lambda( compiled_start_1_17, 51, 0 );
  twobit_setglbl( 10 ); /*  e-mold~1ay%kV~26965 */
  twobit_lambda( compiled_start_1_18, 53, 0 );
  twobit_setglbl( 9 ); /*  flonum-mold~1ay%kV~26966 */
  twobit_lambda( compiled_start_1_19, 55, 0 );
  twobit_setglbl( 8 ); /*  remove-zero~1ay%kV~26967 */
  twobit_lambda( compiled_start_1_20, 57, 0 );
  twobit_setglbl( 7 ); /*  real->fixnum-string~1ay%kV~26968 */
  twobit_lambda( compiled_start_1_21, 59, 0 );
  twobit_setglbl( 6 ); /*  non-0-index~1ay%kV~26969 */
  twobit_lambda( compiled_start_1_22, 61, 0 );
  twobit_setglbl( 5 ); /*  non-0-index-right~1ay%kV~26970 */
  twobit_lambda( compiled_start_1_23, 63, 0 );
  twobit_setglbl( 4 ); /*  non-0-dot-index-right~1ay%kV~26971 */
  twobit_lambda( compiled_start_1_24, 65, 0 );
  twobit_setglbl( 3 ); /*  real->flonum-string~1ay%kV~26972 */
  twobit_lambda( compiled_start_1_25, 67, 0 );
  twobit_setglbl( 2 ); /*  cat~1ay%kV~27213 */
  twobit_global( 68 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* open-output-string */
  twobit_setrtn( 1352, compiled_block_1_1352 );
  twobit_invoke( 0 );
  twobit_label( 1352, compiled_block_1_1352 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_stack( 1 );
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 2 );
  twobit_reg( 3 );
  twobit_setrtn( 1353, compiled_block_1_1353 );
  twobit_invoke( 2 );
  twobit_label( 1353, compiled_block_1_1353 );
  twobit_load( 0, 0 );
  twobit_load( 1, 3 );
  twobit_global( 2 ); /* get-output-string */
  twobit_pop( 3 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg_op1_check_652(reg(2),1355,compiled_block_1_1355); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 1357, compiled_block_1_1357 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1359, compiled_block_1_1359 ); /* internal:branchf-null? */
  twobit_movereg( 1, 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* string-append */
  twobit_invoke( 2 );
  twobit_label( 1359, compiled_block_1_1359 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_store( 4, 3 );
  twobit_movereg( 2, 1 );
  twobit_global( 2 ); /* list? */
  twobit_setrtn( 1361, compiled_block_1_1361 );
  twobit_invoke( 1 );
  twobit_label( 1361, compiled_block_1_1361 );
  twobit_load( 0, 0 );
  twobit_branchf( 1363, compiled_block_1_1363 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1364,compiled_block_1_1364); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 1366, compiled_block_1_1366 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_movereg( 4, 3 );
  twobit_global( 1 ); /* string-append */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1366, compiled_block_1_1366 );
  twobit_reg( 4 );
  twobit_op1_branchf_612( 235, compiled_temp_1_235, 1369, compiled_block_1_1369 ); /* internal:branchf-zero? */
  twobit_const( 3 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1369, compiled_block_1_1369 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_global( 1 ); /* string-append */
  twobit_setrtn( 1370, compiled_block_1_1370 );
  twobit_invoke( 2 );
  twobit_label( 1370, compiled_block_1_1370 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 4, 0, 0, 1371, compiled_block_1_1371 );
  twobit_reg( 4 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2imm_branchf_635( fixnum(0), 236, compiled_temp_1_236, 1373, compiled_block_1_1373 ); /* internal:branchf-</imm */
  twobit_load( 2, 1 );
  twobit_reg( 3 );
  twobit_op2_61( 2, 237, compiled_temp_1_237 ); /* + */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op2imm_branchf_636( fixnum(0), 238, compiled_temp_1_238, 1375, compiled_block_1_1375 ); /* internal:branchf->/imm */
  twobit_movereg( 4, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 4 ); /* substring */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1375, compiled_block_1_1375 );
  twobit_const( 3 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1373, compiled_block_1_1373 );
  twobit_stack( 1 );
  twobit_op2_branchf_619( 3, 239, compiled_temp_1_239, 1378, compiled_block_1_1378 ); /* internal:branchf-< */
  twobit_load( 2, 1 );
  twobit_reg( 3 );
  twobit_op2_62( 2, 240, compiled_temp_1_240 ); /* - */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 4 ); /* substring */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1378, compiled_block_1_1378 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1363, compiled_block_1_1363 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 1381, compiled_block_1_1381 );
  twobit_load( 2, 2 );
  twobit_load( 3, 2 );
  twobit_load( 1, 3 );
  twobit_global( 1 ); /* string-append */
  twobit_pop( 3 );
  twobit_invoke( 4 );
  twobit_label( 1381, compiled_block_1_1381 );
  twobit_reg( 4 );
  twobit_op1_branchf_612( 241, compiled_temp_1_241, 1384, compiled_block_1_1384 ); /* internal:branchf-zero? */
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_global( 1 ); /* string-append */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1384, compiled_block_1_1384 );
  twobit_stack( 2 );
  twobit_op1_800(); /* ustring? */
  twobit_load( 2, 2 );
  twobit_check( 2, 0, 0, 1386, compiled_block_1_1386 );
  twobit_stack( 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_635( fixnum(0), 242, compiled_temp_1_242, 1388, compiled_block_1_1388 ); /* internal:branchf-</imm */
  twobit_reg( 3 );
  twobit_op2_61( 4, 243, compiled_temp_1_243 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_636( fixnum(0), 244, compiled_temp_1_244, 1390, compiled_block_1_1390 ); /* internal:branchf->/imm */
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_movereg( 4, 3 );
  twobit_global( 4 ); /* substring */
  twobit_setrtn( 1391, compiled_block_1_1391 );
  twobit_invoke( 3 );
  twobit_label( 1391, compiled_block_1_1391 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_global( 1 ); /* string-append */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1390, compiled_block_1_1390 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_global( 1 ); /* string-append */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1388, compiled_block_1_1388 );
  twobit_reg( 4 );
  twobit_op2_branchf_619( 3, 245, compiled_temp_1_245, 1395, compiled_block_1_1395 ); /* internal:branchf-< */
  twobit_reg( 3 );
  twobit_op2_62( 4, 246, compiled_temp_1_246 ); /* - */
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 4 ); /* substring */
  twobit_setrtn( 1396, compiled_block_1_1396 );
  twobit_invoke( 3 );
  twobit_label( 1396, compiled_block_1_1396 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_global( 1 ); /* string-append */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1395, compiled_block_1_1395 );
  twobit_load( 2, 2 );
  twobit_load( 3, 2 );
  twobit_load( 1, 3 );
  twobit_global( 1 ); /* string-append */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1357, compiled_block_1_1357 );
  twobit_reg( 4 );
  twobit_op1_branchf_612( 247, compiled_temp_1_247, 1400, compiled_block_1_1400 ); /* internal:branchf-zero? */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1402, compiled_block_1_1402 ); /* internal:branchf-null? */
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1402, compiled_block_1_1402 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 2 ); /* list? */
  twobit_setrtn( 1403, compiled_block_1_1403 );
  twobit_invoke( 1 );
  twobit_label( 1403, compiled_block_1_1403 );
  twobit_load( 0, 0 );
  twobit_branchf( 1405, compiled_block_1_1405 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1364,compiled_block_1_1364); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 1407, compiled_block_1_1407 );
  twobit_load( 1, 2 );
  twobit_movereg( 4, 2 );
  twobit_global( 1 ); /* string-append */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1407, compiled_block_1_1407 );
  twobit_reg( 4 );
  twobit_op1_branchf_612( 248, compiled_temp_1_248, 1410, compiled_block_1_1410 ); /* internal:branchf-zero? */
  twobit_const( 3 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1410, compiled_block_1_1410 );
  twobit_stack( 2 );
  twobit_op1_800(); /* ustring? */
  twobit_load( 2, 2 );
  twobit_check( 2, 0, 0, 1386, compiled_block_1_1386 );
  twobit_stack( 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_635( fixnum(0), 249, compiled_temp_1_249, 1412, compiled_block_1_1412 ); /* internal:branchf-</imm */
  twobit_reg( 3 );
  twobit_op2_61( 4, 250, compiled_temp_1_250 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_636( fixnum(0), 251, compiled_temp_1_251, 1414, compiled_block_1_1414 ); /* internal:branchf->/imm */
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_movereg( 4, 3 );
  twobit_global( 4 ); /* substring */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1414, compiled_block_1_1414 );
  twobit_const( 3 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1412, compiled_block_1_1412 );
  twobit_reg( 4 );
  twobit_op2_branchf_619( 3, 252, compiled_temp_1_252, 1417, compiled_block_1_1417 ); /* internal:branchf-< */
  twobit_reg( 3 );
  twobit_op2_62( 4, 253, compiled_temp_1_253 ); /* - */
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 4 ); /* substring */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1417, compiled_block_1_1417 );
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1405, compiled_block_1_1405 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 1420, compiled_block_1_1420 );
  twobit_load( 2, 2 );
  twobit_load( 1, 2 );
  twobit_movereg( 4, 3 );
  twobit_global( 1 ); /* string-append */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1420, compiled_block_1_1420 );
  twobit_reg( 4 );
  twobit_op1_branchf_612( 254, compiled_temp_1_254, 1423, compiled_block_1_1423 ); /* internal:branchf-zero? */
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1423, compiled_block_1_1423 );
  twobit_stack( 2 );
  twobit_op1_800(); /* ustring? */
  twobit_load( 2, 2 );
  twobit_check( 2, 0, 0, 1386, compiled_block_1_1386 );
  twobit_stack( 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_635( fixnum(0), 255, compiled_temp_1_255, 1425, compiled_block_1_1425 ); /* internal:branchf-</imm */
  twobit_reg( 3 );
  twobit_op2_61( 4, 256, compiled_temp_1_256 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_636( fixnum(0), 257, compiled_temp_1_257, 1427, compiled_block_1_1427 ); /* internal:branchf->/imm */
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_movereg( 4, 3 );
  twobit_global( 4 ); /* substring */
  twobit_setrtn( 1428, compiled_block_1_1428 );
  twobit_invoke( 3 );
  twobit_label( 1428, compiled_block_1_1428 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 1 ); /* string-append */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1427, compiled_block_1_1427 );
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1425, compiled_block_1_1425 );
  twobit_reg( 4 );
  twobit_op2_branchf_619( 3, 258, compiled_temp_1_258, 1431, compiled_block_1_1431 ); /* internal:branchf-< */
  twobit_reg( 3 );
  twobit_op2_62( 4, 259, compiled_temp_1_259 ); /* - */
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 4 ); /* substring */
  twobit_setrtn( 1432, compiled_block_1_1432 );
  twobit_invoke( 3 );
  twobit_label( 1432, compiled_block_1_1432 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 1 ); /* string-append */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1431, compiled_block_1_1431 );
  twobit_load( 2, 2 );
  twobit_load( 1, 2 );
  twobit_global( 1 ); /* string-append */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1400, compiled_block_1_1400 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 1, 0, 0, 1435, compiled_block_1_1435 );
  twobit_reg( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_636( fixnum(0), 260, compiled_temp_1_260, 1437, compiled_block_1_1437 ); /* internal:branchf->/imm */
  twobit_reg( 4 );
  twobit_op2_branchf_619( 3, 261, compiled_temp_1_261, 1439, compiled_block_1_1439 ); /* internal:branchf-< */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_movereg( 4, 3 );
  twobit_global( 4 ); /* substring */
  twobit_setrtn( 1440, compiled_block_1_1440 );
  twobit_invoke( 3 );
  twobit_label( 1440, compiled_block_1_1440 );
  twobit_load( 0, 0 );
  twobit_skip( 1436, compiled_block_1_1436 );
  twobit_label( 1439, compiled_block_1_1439 );
  twobit_reg( 1 );
  twobit_skip( 1436, compiled_block_1_1436 );
  twobit_label( 1437, compiled_block_1_1437 );
  twobit_reg( 3 );
  twobit_op2_61( 4, 262, compiled_temp_1_262 ); /* + */
  twobit_op2imm_branchf_636( fixnum(0), 263, compiled_temp_1_263, 1442, compiled_block_1_1442 ); /* internal:branchf->/imm */
  twobit_reg( 4 );
  twobit_op2imm_branchf_635( fixnum(0), 264, compiled_temp_1_264, 1444, compiled_block_1_1444 ); /* internal:branchf-</imm */
  twobit_reg( 4 );
  twobit_op1_32( 265, compiled_temp_1_265 ); /* -- */
  twobit_skip( 1443, compiled_block_1_1443 );
  twobit_label( 1444, compiled_block_1_1444 );
  twobit_reg( 4 );
  twobit_label( 1443, compiled_block_1_1443 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* substring */
  twobit_setrtn( 1445, compiled_block_1_1445 );
  twobit_invoke( 3 );
  twobit_label( 1445, compiled_block_1_1445 );
  twobit_load( 0, 0 );
  twobit_skip( 1436, compiled_block_1_1436 );
  twobit_label( 1442, compiled_block_1_1442 );
  twobit_const( 3 );
  twobit_label( 1436, compiled_block_1_1436 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1447, compiled_block_1_1447 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1447, compiled_block_1_1447 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* list? */
  twobit_setrtn( 1448, compiled_block_1_1448 );
  twobit_invoke( 1 );
  twobit_label( 1448, compiled_block_1_1448 );
  twobit_load( 0, 0 );
  twobit_branchf( 1450, compiled_block_1_1450 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1364,compiled_block_1_1364); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 1452, compiled_block_1_1452 );
  twobit_load( 1, 2 );
  twobit_movereg( 4, 2 );
  twobit_global( 1 ); /* string-append */
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 1452, compiled_block_1_1452 );
  twobit_reg( 4 );
  twobit_op1_branchf_612( 266, compiled_temp_1_266, 1455, compiled_block_1_1455 ); /* internal:branchf-zero? */
  twobit_const( 3 );
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1455, compiled_block_1_1455 );
  twobit_stack( 2 );
  twobit_op1_800(); /* ustring? */
  twobit_load( 2, 2 );
  twobit_check( 2, 0, 0, 1386, compiled_block_1_1386 );
  twobit_stack( 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_635( fixnum(0), 267, compiled_temp_1_267, 1457, compiled_block_1_1457 ); /* internal:branchf-</imm */
  twobit_reg( 3 );
  twobit_op2_61( 4, 268, compiled_temp_1_268 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_636( fixnum(0), 269, compiled_temp_1_269, 1459, compiled_block_1_1459 ); /* internal:branchf->/imm */
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_movereg( 4, 3 );
  twobit_global( 4 ); /* substring */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 1459, compiled_block_1_1459 );
  twobit_const( 3 );
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1457, compiled_block_1_1457 );
  twobit_reg( 4 );
  twobit_op2_branchf_619( 3, 270, compiled_temp_1_270, 1462, compiled_block_1_1462 ); /* internal:branchf-< */
  twobit_reg( 3 );
  twobit_op2_62( 4, 271, compiled_temp_1_271 ); /* - */
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 4 ); /* substring */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 1462, compiled_block_1_1462 );
  twobit_stack( 2 );
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1450, compiled_block_1_1450 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 1465, compiled_block_1_1465 );
  twobit_load( 2, 3 );
  twobit_load( 1, 2 );
  twobit_movereg( 4, 3 );
  twobit_global( 1 ); /* string-append */
  twobit_pop( 4 );
  twobit_invoke( 3 );
  twobit_label( 1465, compiled_block_1_1465 );
  twobit_reg( 4 );
  twobit_op1_branchf_612( 272, compiled_temp_1_272, 1468, compiled_block_1_1468 ); /* internal:branchf-zero? */
  twobit_stack( 2 );
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1468, compiled_block_1_1468 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_635( fixnum(0), 273, compiled_temp_1_273, 1470, compiled_block_1_1470 ); /* internal:branchf-</imm */
  twobit_stack( 4 );
  twobit_op2_61( 4, 274, compiled_temp_1_274 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_636( fixnum(0), 275, compiled_temp_1_275, 1472, compiled_block_1_1472 ); /* internal:branchf->/imm */
  twobit_load( 1, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_movereg( 4, 3 );
  twobit_global( 4 ); /* substring */
  twobit_setrtn( 1473, compiled_block_1_1473 );
  twobit_invoke( 3 );
  twobit_label( 1473, compiled_block_1_1473 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 1 ); /* string-append */
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 1472, compiled_block_1_1472 );
  twobit_stack( 2 );
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1470, compiled_block_1_1470 );
  twobit_load( 3, 4 );
  twobit_reg( 4 );
  twobit_op2_branchf_619( 3, 276, compiled_temp_1_276, 1476, compiled_block_1_1476 ); /* internal:branchf-< */
  twobit_reg( 3 );
  twobit_op2_62( 4, 277, compiled_temp_1_277 ); /* - */
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_global( 4 ); /* substring */
  twobit_setrtn( 1477, compiled_block_1_1477 );
  twobit_invoke( 3 );
  twobit_label( 1477, compiled_block_1_1477 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 1 ); /* string-append */
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 1476, compiled_block_1_1476 );
  twobit_load( 2, 3 );
  twobit_load( 1, 2 );
  twobit_global( 1 ); /* string-append */
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 1386, compiled_block_1_1386 );
  twobit_trap( 2, 0, 0, 62 );
  twobit_label( 1364, compiled_block_1_1364 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 1355, compiled_block_1_1355 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 1435, compiled_block_1_1435 );
  twobit_trap( 1, 0, 0, 62 );
  twobit_label( 1371, compiled_block_1_1371 );
  twobit_trap( 4, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_6( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 31 );
  twobit_movereg( 31, 3 );
  twobit_lambda( compiled_start_1_233, 3, 4 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 31 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_233( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_623( 4, 234, compiled_temp_1_234, 1481, compiled_block_1_1481 ); /* internal:branchf-= */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1481, compiled_block_1_1481 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1482, compiled_block_1_1482 );
  twobit_lexical( 0, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1482, compiled_block_1_1482 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1482, compiled_block_1_1482 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1482, compiled_block_1_1482 );
  twobit_lexical( 0, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_branchf_625( 4, 1484, compiled_block_1_1484 ); /* internal:branchf-char=? */
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1484, compiled_block_1_1484 );
  twobit_reg( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 1482, compiled_block_1_1482 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_7( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_231, 3, 3 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_231( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_623( 4, 232, compiled_temp_1_232, 1488, compiled_block_1_1488 ); /* internal:branchf-= */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1488, compiled_block_1_1488 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1489, compiled_block_1_1489 );
  twobit_lexical( 0, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1489, compiled_block_1_1489 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1489, compiled_block_1_1489 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1489, compiled_block_1_1489 );
  twobit_lexical( 0, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* char-numeric? */
  twobit_setrtn( 1490, compiled_block_1_1490 );
  twobit_invoke( 1 );
  twobit_label( 1490, compiled_block_1_1490 );
  twobit_load( 0, 0 );
  twobit_branchf( 1492, compiled_block_1_1492 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1492, compiled_block_1_1492 );
  twobit_stack( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1489, compiled_block_1_1489 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_8( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_229, 3, 3 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_229( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_branchf_623( 4, 230, compiled_temp_1_230, 1496, compiled_block_1_1496 ); /* internal:branchf-= */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_return();
  twobit_label( 1496, compiled_block_1_1496 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1497, compiled_block_1_1497 );
  twobit_lexical( 0, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1497, compiled_block_1_1497 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1497, compiled_block_1_1497 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1497, compiled_block_1_1497 );
  twobit_lexical( 0, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* char-numeric? */
  twobit_setrtn( 1498, compiled_block_1_1498 );
  twobit_invoke( 1 );
  twobit_label( 1498, compiled_block_1_1498 );
  twobit_load( 0, 0 );
  twobit_branchf( 1500, compiled_block_1_1500 );
  twobit_stack( 1 );
  twobit_op2imm_520( fixnum(1) ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1500, compiled_block_1_1500 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1497, compiled_block_1_1497 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_9( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 6 );
  twobit_store( 3, 5 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 1, 0, 0, 1503, compiled_block_1_1503 );
  twobit_reg( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 31 );
  twobit_store( 31, 4 );
  twobit_movereg( 31, 4 );
  twobit_imm_const( int_to_char(46) ); /* #\. */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  str-char-index~1ay%kV~26954 */
  twobit_setrtn( 1504, compiled_block_1_1504 );
  twobit_invoke( 4 );
  twobit_label( 1504, compiled_block_1_1504 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_branchf( 1506, compiled_block_1_1506 );
  twobit_stack( 1 );
  twobit_branchf( 1508, compiled_block_1_1508 );
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_movereg( 4, 3 );
  twobit_global( 2 ); /*  str-numeric?~1ay%kV~26956 */
  twobit_setrtn( 1509, compiled_block_1_1509 );
  twobit_invoke( 3 );
  twobit_label( 1509, compiled_block_1_1509 );
  twobit_load( 0, 0 );
  twobit_branchf( 1511, compiled_block_1_1511 );
  twobit_load( 4, 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 4, 192, compiled_temp_1_192 ); /* + */
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_load( 3, 4 );
  twobit_global( 2 ); /*  str-numeric?~1ay%kV~26956 */
  twobit_setrtn( 1512, compiled_block_1_1512 );
  twobit_invoke( 3 );
  twobit_label( 1512, compiled_block_1_1512 );
  twobit_load( 0, 0 );
  twobit_skip( 1510, compiled_block_1_1510 );
  twobit_label( 1511, compiled_block_1_1511 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1510, compiled_block_1_1510 );
  twobit_branchf( 1514, compiled_block_1_1514 );
  twobit_stack( 3 );
  twobit_op2imm_131( fixnum(1), 193, compiled_temp_1_193 ); /* - */
  twobit_load( 3, 5 );
  twobit_op2_103( 3, 194, compiled_temp_1_194 ); /* remainder */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_612( 195, compiled_temp_1_195, 1516, compiled_block_1_1516 ); /* internal:branchf-zero? */
  twobit_stack( 5 );
  twobit_skip( 1515, compiled_block_1_1515 );
  twobit_label( 1516, compiled_block_1_1516 );
  twobit_reg( 4 );
  twobit_label( 1515, compiled_block_1_1515 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 3, 196, compiled_temp_1_196 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 5, 6 );
  twobit_load( 4, 5 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_197, 5, 5 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1522, compiled_block_1_1522 );
  twobit_invoke( 2 );
  twobit_label( 1522, compiled_block_1_1522 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 6 ); /* string-append */
  twobit_setreg( 1 );
  twobit_global( 7 ); /* apply */
  twobit_setrtn( 1523, compiled_block_1_1523 );
  twobit_invoke( 2 );
  twobit_label( 1523, compiled_block_1_1523 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 3, 198, compiled_temp_1_198 ); /* + */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_load( 1, 5 );
  twobit_reg( 3 );
  twobit_op2_61( 1, 199, compiled_temp_1_199 ); /* + */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 3, 200, compiled_temp_1_200 ); /* + */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 1 );
  twobit_store( 1, 7 );
  twobit_load( 5, 6 );
  twobit_load( 4, 5 );
  twobit_load( 3, 2 );
  twobit_load( 2, 4 );
  twobit_lambda( compiled_start_1_201, 9, 5 );
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_load( 1, 1 );
  twobit_stack( 7 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_stack( 7 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1529, compiled_block_1_1529 );
  twobit_invoke( 2 );
  twobit_label( 1529, compiled_block_1_1529 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 6 ); /* string-append */
  twobit_setreg( 1 );
  twobit_global( 7 ); /* apply */
  twobit_setrtn( 1530, compiled_block_1_1530 );
  twobit_invoke( 2 );
  twobit_label( 1530, compiled_block_1_1530 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 1, 8 );
  twobit_const( 10 );
  twobit_setreg( 2 );
  twobit_global( 6 ); /* string-append */
  twobit_pop( 8 );
  twobit_invoke( 3 );
  twobit_label( 1514, compiled_block_1_1514 );
  twobit_stack( 2 );
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 1508, compiled_block_1_1508 );
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_movereg( 4, 3 );
  twobit_global( 2 ); /*  str-numeric?~1ay%kV~26956 */
  twobit_setrtn( 1532, compiled_block_1_1532 );
  twobit_invoke( 3 );
  twobit_label( 1532, compiled_block_1_1532 );
  twobit_load( 0, 0 );
  twobit_branchf( 1534, compiled_block_1_1534 );
  twobit_load( 4, 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 4, 202, compiled_temp_1_202 ); /* + */
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_load( 3, 4 );
  twobit_global( 2 ); /*  str-numeric?~1ay%kV~26956 */
  twobit_setrtn( 1535, compiled_block_1_1535 );
  twobit_invoke( 3 );
  twobit_label( 1535, compiled_block_1_1535 );
  twobit_load( 0, 0 );
  twobit_skip( 1533, compiled_block_1_1533 );
  twobit_label( 1534, compiled_block_1_1534 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1533, compiled_block_1_1533 );
  twobit_branchf( 1537, compiled_block_1_1537 );
  twobit_load( 4, 5 );
  twobit_stack( 3 );
  twobit_op2_103( 4, 203, compiled_temp_1_203 ); /* remainder */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_612( 204, compiled_temp_1_204, 1539, compiled_block_1_1539 ); /* internal:branchf-zero? */
  twobit_reg( 4 );
  twobit_skip( 1538, compiled_block_1_1538 );
  twobit_label( 1539, compiled_block_1_1539 );
  twobit_reg( 3 );
  twobit_label( 1538, compiled_block_1_1538 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 5, 6 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_205, 12, 5 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1545, compiled_block_1_1545 );
  twobit_invoke( 2 );
  twobit_label( 1545, compiled_block_1_1545 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 6 ); /* string-append */
  twobit_setreg( 1 );
  twobit_global( 7 ); /* apply */
  twobit_setrtn( 1546, compiled_block_1_1546 );
  twobit_invoke( 2 );
  twobit_label( 1546, compiled_block_1_1546 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_load( 3, 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 3, 206, compiled_temp_1_206 ); /* + */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_load( 1, 5 );
  twobit_reg( 3 );
  twobit_op2_61( 1, 207, compiled_temp_1_207 ); /* + */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 3, 208, compiled_temp_1_208 ); /* + */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 1 );
  twobit_store( 1, 7 );
  twobit_load( 5, 6 );
  twobit_load( 4, 5 );
  twobit_load( 3, 2 );
  twobit_load( 2, 4 );
  twobit_lambda( compiled_start_1_209, 14, 5 );
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_load( 1, 1 );
  twobit_stack( 7 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_stack( 7 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1552, compiled_block_1_1552 );
  twobit_invoke( 2 );
  twobit_label( 1552, compiled_block_1_1552 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 6 ); /* string-append */
  twobit_setreg( 1 );
  twobit_global( 7 ); /* apply */
  twobit_setrtn( 1553, compiled_block_1_1553 );
  twobit_invoke( 2 );
  twobit_label( 1553, compiled_block_1_1553 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 1, 8 );
  twobit_const( 10 );
  twobit_setreg( 2 );
  twobit_global( 6 ); /* string-append */
  twobit_pop( 8 );
  twobit_invoke( 3 );
  twobit_label( 1537, compiled_block_1_1537 );
  twobit_stack( 2 );
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 1506, compiled_block_1_1506 );
  twobit_stack( 1 );
  twobit_branchf( 1556, compiled_block_1_1556 );
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_load( 3, 4 );
  twobit_global( 2 ); /*  str-numeric?~1ay%kV~26956 */
  twobit_setrtn( 1557, compiled_block_1_1557 );
  twobit_invoke( 3 );
  twobit_label( 1557, compiled_block_1_1557 );
  twobit_load( 0, 0 );
  twobit_branchf( 1559, compiled_block_1_1559 );
  twobit_stack( 4 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_load( 3, 5 );
  twobit_op2_103( 3, 210, compiled_temp_1_210 ); /* remainder */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_612( 211, compiled_temp_1_211, 1561, compiled_block_1_1561 ); /* internal:branchf-zero? */
  twobit_stack( 5 );
  twobit_skip( 1560, compiled_block_1_1560 );
  twobit_label( 1561, compiled_block_1_1561 );
  twobit_reg( 4 );
  twobit_label( 1560, compiled_block_1_1560 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 3, 212, compiled_temp_1_212 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 5, 6 );
  twobit_load( 4, 5 );
  twobit_load( 2, 2 );
  twobit_load( 1, 4 );
  twobit_lambda( compiled_start_1_213, 16, 5 );
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1567, compiled_block_1_1567 );
  twobit_invoke( 2 );
  twobit_label( 1567, compiled_block_1_1567 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 6 ); /* string-append */
  twobit_setreg( 1 );
  twobit_global( 7 ); /* apply */
  twobit_pop( 8 );
  twobit_invoke( 2 );
  twobit_label( 1559, compiled_block_1_1559 );
  twobit_stack( 2 );
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 1556, compiled_block_1_1556 );
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_load( 3, 4 );
  twobit_global( 2 ); /*  str-numeric?~1ay%kV~26956 */
  twobit_setrtn( 1569, compiled_block_1_1569 );
  twobit_invoke( 3 );
  twobit_label( 1569, compiled_block_1_1569 );
  twobit_load( 0, 0 );
  twobit_branchf( 1571, compiled_block_1_1571 );
  twobit_load( 4, 5 );
  twobit_stack( 4 );
  twobit_op2_103( 4, 214, compiled_temp_1_214 ); /* remainder */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_612( 215, compiled_temp_1_215, 1573, compiled_block_1_1573 ); /* internal:branchf-zero? */
  twobit_reg( 4 );
  twobit_skip( 1572, compiled_block_1_1572 );
  twobit_label( 1573, compiled_block_1_1573 );
  twobit_reg( 3 );
  twobit_label( 1572, compiled_block_1_1572 );
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 5, 6 );
  twobit_load( 2, 2 );
  twobit_load( 1, 4 );
  twobit_lambda( compiled_start_1_216, 18, 5 );
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1579, compiled_block_1_1579 );
  twobit_invoke( 2 );
  twobit_label( 1579, compiled_block_1_1579 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 6 ); /* string-append */
  twobit_setreg( 1 );
  twobit_global( 7 ); /* apply */
  twobit_pop( 8 );
  twobit_invoke( 2 );
  twobit_label( 1571, compiled_block_1_1571 );
  twobit_stack( 2 );
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 1503, compiled_block_1_1503 );
  twobit_trap( 1, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_197( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_branchf_619( 4, 227, compiled_temp_1_227, 1518, compiled_block_1_1518 ); /* internal:branchf-< */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* substring */
  twobit_setrtn( 1519, compiled_block_1_1519 );
  twobit_invoke( 3 );
  twobit_label( 1519, compiled_block_1_1519 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_61( 3, 228, compiled_temp_1_228 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1520, compiled_block_1_1520 );
  twobit_invoke( 2 );
  twobit_label( 1520, compiled_block_1_1520 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1518, compiled_block_1_1518 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /* substring */
  twobit_setrtn( 1521, compiled_block_1_1521 );
  twobit_invoke( 3 );
  twobit_label( 1521, compiled_block_1_1521 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_201( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_branchf_619( 4, 225, compiled_temp_1_225, 1525, compiled_block_1_1525 ); /* internal:branchf-< */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* substring */
  twobit_setrtn( 1526, compiled_block_1_1526 );
  twobit_invoke( 3 );
  twobit_label( 1526, compiled_block_1_1526 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_61( 3, 226, compiled_temp_1_226 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1527, compiled_block_1_1527 );
  twobit_invoke( 2 );
  twobit_label( 1527, compiled_block_1_1527 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1525, compiled_block_1_1525 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /* substring */
  twobit_setrtn( 1528, compiled_block_1_1528 );
  twobit_invoke( 3 );
  twobit_label( 1528, compiled_block_1_1528 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_205( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_branchf_619( 4, 223, compiled_temp_1_223, 1541, compiled_block_1_1541 ); /* internal:branchf-< */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* substring */
  twobit_setrtn( 1542, compiled_block_1_1542 );
  twobit_invoke( 3 );
  twobit_label( 1542, compiled_block_1_1542 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_61( 3, 224, compiled_temp_1_224 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1543, compiled_block_1_1543 );
  twobit_invoke( 2 );
  twobit_label( 1543, compiled_block_1_1543 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1541, compiled_block_1_1541 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /* substring */
  twobit_setrtn( 1544, compiled_block_1_1544 );
  twobit_invoke( 3 );
  twobit_label( 1544, compiled_block_1_1544 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_209( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_branchf_619( 4, 221, compiled_temp_1_221, 1548, compiled_block_1_1548 ); /* internal:branchf-< */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* substring */
  twobit_setrtn( 1549, compiled_block_1_1549 );
  twobit_invoke( 3 );
  twobit_label( 1549, compiled_block_1_1549 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_61( 3, 222, compiled_temp_1_222 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1550, compiled_block_1_1550 );
  twobit_invoke( 2 );
  twobit_label( 1550, compiled_block_1_1550 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1548, compiled_block_1_1548 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /* substring */
  twobit_setrtn( 1551, compiled_block_1_1551 );
  twobit_invoke( 3 );
  twobit_label( 1551, compiled_block_1_1551 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_213( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_branchf_619( 4, 219, compiled_temp_1_219, 1563, compiled_block_1_1563 ); /* internal:branchf-< */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* substring */
  twobit_setrtn( 1564, compiled_block_1_1564 );
  twobit_invoke( 3 );
  twobit_label( 1564, compiled_block_1_1564 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_61( 3, 220, compiled_temp_1_220 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1565, compiled_block_1_1565 );
  twobit_invoke( 2 );
  twobit_label( 1565, compiled_block_1_1565 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1563, compiled_block_1_1563 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /* substring */
  twobit_setrtn( 1566, compiled_block_1_1566 );
  twobit_invoke( 3 );
  twobit_label( 1566, compiled_block_1_1566 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_216( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_branchf_619( 4, 217, compiled_temp_1_217, 1575, compiled_block_1_1575 ); /* internal:branchf-< */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* substring */
  twobit_setrtn( 1576, compiled_block_1_1576 );
  twobit_invoke( 3 );
  twobit_label( 1576, compiled_block_1_1576 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_61( 3, 218, compiled_temp_1_218 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1577, compiled_block_1_1577 );
  twobit_invoke( 2 );
  twobit_label( 1577, compiled_block_1_1577 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1575, compiled_block_1_1575 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /* substring */
  twobit_setrtn( 1578, compiled_block_1_1578 );
  twobit_invoke( 3 );
  twobit_label( 1578, compiled_block_1_1578 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_10( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 3 );
  twobit_op2imm_132( fixnum(0), 185, compiled_temp_1_185 ); /* < */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1582, compiled_block_1_1582 );
  twobit_reg( 3 );
  twobit_op1_32( 186, compiled_temp_1_186 ); /* -- */
  twobit_skip( 1581, compiled_block_1_1581 );
  twobit_label( 1582, compiled_block_1_1582 );
  twobit_reg( 3 );
  twobit_label( 1581, compiled_block_1_1581 );
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 1, 0, 0, 1583, compiled_block_1_1583 );
  twobit_reg( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_branchf( 1585, compiled_block_1_1585 );
  twobit_reg( 3 );
  twobit_skip( 1584, compiled_block_1_1584 );
  twobit_label( 1585, compiled_block_1_1585 );
  twobit_reg( 31 );
  twobit_op2_103( 3, 187, compiled_temp_1_187 ); /* remainder */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_612( 188, compiled_temp_1_188, 1587, compiled_block_1_1587 ); /* internal:branchf-zero? */
  twobit_reg( 3 );
  twobit_skip( 1584, compiled_block_1_1584 );
  twobit_label( 1587, compiled_block_1_1587 );
  twobit_reg( 4 );
  twobit_label( 1584, compiled_block_1_1584 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 30 );
  twobit_movereg( 30, 5 );
  twobit_movereg( 31, 4 );
  twobit_lambda( compiled_start_1_189, 3, 5 );
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_reg( 30 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 30 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1593, compiled_block_1_1593 );
  twobit_invoke( 2 );
  twobit_label( 1593, compiled_block_1_1593 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* string-append */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1583, compiled_block_1_1583 );
  twobit_trap( 1, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_189( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_branchf_619( 4, 190, compiled_temp_1_190, 1589, compiled_block_1_1589 ); /* internal:branchf-< */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* substring */
  twobit_setrtn( 1590, compiled_block_1_1590 );
  twobit_invoke( 3 );
  twobit_label( 1590, compiled_block_1_1590 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_61( 3, 191, compiled_temp_1_191 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 0, 5 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1591, compiled_block_1_1591 );
  twobit_invoke( 2 );
  twobit_label( 1591, compiled_block_1_1591 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1589, compiled_block_1_1589 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 4 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /* substring */
  twobit_setrtn( 1592, compiled_block_1_1592 );
  twobit_invoke( 3 );
  twobit_label( 1592, compiled_block_1_1592 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_11( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_184, 3, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_184( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1596, compiled_block_1_1596 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1597, compiled_block_1_1597 );
  twobit_invoke( 1 );
  twobit_label( 1597, compiled_block_1_1597 );
  twobit_load( 0, 0 );
  twobit_branchf( 1599, compiled_block_1_1599 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1599, compiled_block_1_1599 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1596, compiled_block_1_1596 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1602, compiled_block_1_1602 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_return();
  twobit_label( 1602, compiled_block_1_1602 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1603, compiled_block_1_1603 );
  twobit_invoke( 1 );
  twobit_label( 1603, compiled_block_1_1603 );
  twobit_load( 0, 0 );
  twobit_branchf( 1605, compiled_block_1_1605 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1605, compiled_block_1_1605 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_12( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_180, 3, 3 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_180( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1608, compiled_block_1_1608 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_branchf_619( 4, 181, compiled_temp_1_181, 1610, compiled_block_1_1610 ); /* internal:branchf-< */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1611, compiled_block_1_1611 );
  twobit_invoke( 1 );
  twobit_label( 1611, compiled_block_1_1611 );
  twobit_load( 0, 0 );
  twobit_skip( 1609, compiled_block_1_1609 );
  twobit_label( 1610, compiled_block_1_1610 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1609, compiled_block_1_1609 );
  twobit_branchf( 1613, compiled_block_1_1613 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op2imm_130( fixnum(1), 182, compiled_temp_1_182 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1613, compiled_block_1_1613 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1608, compiled_block_1_1608 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1616, compiled_block_1_1616 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_return();
  twobit_label( 1616, compiled_block_1_1616 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_branchf_619( 4, 183, compiled_temp_1_183, 1618, compiled_block_1_1618 ); /* internal:branchf-< */
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1619, compiled_block_1_1619 );
  twobit_invoke( 1 );
  twobit_label( 1619, compiled_block_1_1619 );
  twobit_load( 0, 0 );
  twobit_skip( 1617, compiled_block_1_1617 );
  twobit_label( 1618, compiled_block_1_1618 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1617, compiled_block_1_1617 );
  twobit_branchf( 1621, compiled_block_1_1621 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1621, compiled_block_1_1621 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_13( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1624, compiled_block_1_1624 );
  twobit_reg( 1 );
  twobit_op1_25(); /* exact? */
  twobit_return();
  twobit_label( 1624, compiled_block_1_1624 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_14( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1626, compiled_block_1_1626 );
  twobit_reg( 1 );
  twobit_op1_25(); /* exact? */
  twobit_skip( 1625, compiled_block_1_1625 );
  twobit_label( 1626, compiled_block_1_1626 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1625, compiled_block_1_1625 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1628, compiled_block_1_1628 );
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1628, compiled_block_1_1628 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_15( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 2 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 1, 0, 0, 1629, compiled_block_1_1629 );
  twobit_reg( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 4 );
  twobit_imm_const( int_to_char(46) ); /* #\. */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  str-char-index~1ay%kV~26954 */
  twobit_setrtn( 1630, compiled_block_1_1630 );
  twobit_invoke( 4 );
  twobit_label( 1630, compiled_block_1_1630 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_reg( 4 );
  twobit_branchf( 1632, compiled_block_1_1632 );
  twobit_reg( 4 );
  twobit_op2imm_130( fixnum(1), 166, compiled_temp_1_166 ); /* + */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_62( 3, 167, compiled_temp_1_167 ); /* - */
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_reg( 3 );
  twobit_op2_branchf_623( 2, 168, compiled_temp_1_168, 1634, compiled_block_1_1634 ); /* internal:branchf-= */
  twobit_stack( 3 );
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1634, compiled_block_1_1634 );
  twobit_reg( 3 );
  twobit_op2_branchf_619( 2, 169, compiled_temp_1_169, 1636, compiled_block_1_1636 ); /* internal:branchf-< */
  twobit_reg( 2 );
  twobit_op2_62( 3, 170, compiled_temp_1_170 ); /* - */
  twobit_imm_const_setreg( int_to_char(48), 3 ); /* 0 */
  twobit_op2_799( 3 ); /* make-ustring */
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_global( 2 ); /* string-append */
  twobit_pop( 7 );
  twobit_invoke( 2 );
  twobit_label( 1636, compiled_block_1_1636 );
  twobit_reg( 4 );
  twobit_op2_61( 2, 171, compiled_temp_1_171 ); /* + */
  twobit_setreg( 1 );
  twobit_store( 1, 7 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 1, 172, compiled_temp_1_172 ); /* + */
  twobit_setreg( 2 );
  twobit_store( 2, 6 );
  twobit_reg( 2 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 4, 3 );
  twobit_check( 2, 4, 0, 1638, compiled_block_1_1638 );
  twobit_load( 4, 1 );
  twobit_reg( 2 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_load( 4, 3 );
  twobit_check( 2, 4, 0, 1638, compiled_block_1_1638 );
  twobit_reg_op2imm_check_660(reg(2),fixnum(0),1638,compiled_block_1_1638); /* internal:check->=:fix:fix/imm with (2 4 0) */
  twobit_stack( 3 );
  twobit_op2_802( 2 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_imm_const( int_to_char(53) ); /* #\5 */
  twobit_op2_branchf_629( 4, 1640, compiled_block_1_1640 ); /* internal:branchf-char<? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1639, compiled_block_1_1639 );
  twobit_label( 1640, compiled_block_1_1640 );
  twobit_imm_const( int_to_char(53) ); /* #\5 */
  twobit_op2_branchf_625( 4, 1642, compiled_block_1_1642 ); /* internal:branchf-char=? */
  twobit_load( 4, 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 4, 173, compiled_temp_1_173 ); /* + */
  twobit_op2_66( 3, 174, compiled_temp_1_174 ); /* < */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1644, compiled_block_1_1644 );
  twobit_reg( 4 );
  twobit_skip( 1639, compiled_block_1_1639 );
  twobit_label( 1644, compiled_block_1_1644 );
  twobit_load( 4, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_branchf_623( 4, 175, compiled_temp_1_175, 1646, compiled_block_1_1646 ); /* internal:branchf-= */
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_skip( 1645, compiled_block_1_1645 );
  twobit_label( 1646, compiled_block_1_1646 );
  twobit_reg( 4 );
  twobit_label( 1645, compiled_block_1_1645 );
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_61( 4, 176, compiled_temp_1_176 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 4, 3 );
  twobit_load( 3, 5 );
  twobit_check( 3, 4, 0, 1647, compiled_block_1_1647 );
  twobit_load( 4, 1 );
  twobit_stack( 5 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_load( 3, 3 );
  twobit_load( 4, 5 );
  twobit_check( 4, 3, 0, 1648, compiled_block_1_1648 );
  twobit_stack( 5 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_load( 4, 3 );
  twobit_load( 3, 5 );
  twobit_check( 3, 4, 0, 1647, compiled_block_1_1647 );
  twobit_load( 4, 5 );
  twobit_stack( 3 );
  twobit_op2_802( 4 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_const( 3 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* memv */
  twobit_setrtn( 1649, compiled_block_1_1649 );
  twobit_invoke( 2 );
  twobit_label( 1649, compiled_block_1_1649 );
  twobit_load( 0, 0 );
  twobit_skip( 1639, compiled_block_1_1639 );
  twobit_label( 1642, compiled_block_1_1642 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1639, compiled_block_1_1639 );
  twobit_branchf( 1651, compiled_block_1_1651 );
  twobit_load( 4, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_load( 3, 3 );
  twobit_check( 0, 3, 0, 1652, compiled_block_1_1652 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_802( 4 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_imm_const( int_to_char(45) ); /* #\- */
  twobit_op2_87( 4 ); /* char=? */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_reg( 4 );
  twobit_branchf( 1654, compiled_block_1_1654 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_skip( 1653, compiled_block_1_1653 );
  twobit_label( 1654, compiled_block_1_1654 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_label( 1653, compiled_block_1_1653 );
  twobit_load( 1, 3 );
  twobit_load( 3, 6 );
  twobit_global( 5 ); /* substring */
  twobit_setrtn( 1655, compiled_block_1_1655 );
  twobit_invoke( 3 );
  twobit_label( 1655, compiled_block_1_1655 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_branchf( 1657, compiled_block_1_1657 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_skip( 1656, compiled_block_1_1656 );
  twobit_label( 1657, compiled_block_1_1657 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_label( 1656, compiled_block_1_1656 );
  twobit_setreg( 3 );
  twobit_stack( 7 );
  twobit_op2_62( 3, 177, compiled_temp_1_177 ); /* - */
  twobit_setreg( 1 );
  twobit_store( 1, 6 );
  twobit_global( 6 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_178, 8, 2 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 6 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_setrtn( 1673, compiled_block_1_1673 );
  twobit_invoke( 2 );
  twobit_label( 1673, compiled_block_1_1673 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 9 ); /* reverse */
  twobit_setrtn( 1674, compiled_block_1_1674 );
  twobit_invoke( 1 );
  twobit_label( 1674, compiled_block_1_1674 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_branchf( 1676, compiled_block_1_1676 );
  twobit_imm_const( int_to_char(45) ); /* #\- */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 2 );
  twobit_skip( 1675, compiled_block_1_1675 );
  twobit_label( 1676, compiled_block_1_1676 );
  twobit_movereg( 4, 2 );
  twobit_label( 1675, compiled_block_1_1675 );
  twobit_global( 10 ); /* string */
  twobit_setreg( 1 );
  twobit_global( 11 ); /* apply */
  twobit_pop( 7 );
  twobit_invoke( 2 );
  twobit_label( 1651, compiled_block_1_1651 );
  twobit_load( 1, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_load( 3, 6 );
  twobit_global( 5 ); /* substring */
  twobit_pop( 7 );
  twobit_invoke( 3 );
  twobit_label( 1632, compiled_block_1_1632 );
  twobit_imm_const( int_to_char(48) ); /* #\0 */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_799( 3 ); /* make-ustring */
  twobit_setreg( 3 );
  twobit_load( 1, 3 );
  twobit_const( 12 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* string-append */
  twobit_pop( 7 );
  twobit_invoke( 3 );
  twobit_label( 1638, compiled_block_1_1638 );
  twobit_trap( 4, 2, 0, 60 );
  twobit_label( 1652, compiled_block_1_1652 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_label( 1629, compiled_block_1_1629 );
  twobit_trap( 1, 0, 0, 62 );
  twobit_label( 1648, compiled_block_1_1648 );
  twobit_trap( 3, 4, 0, 60 );
  twobit_label( 1647, compiled_block_1_1647 );
  twobit_trap( 4, 3, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_178( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_branchf_623( 1, 179, compiled_temp_1_179, 1659, compiled_block_1_1659 ); /* internal:branchf-= */
  twobit_reg( 2 );
  twobit_branchf( 1661, compiled_block_1_1661 );
  twobit_const( 1 );
  twobit_return();
  twobit_label( 1661, compiled_block_1_1661 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_label( 1659, compiled_block_1_1659 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1662, compiled_block_1_1662 );
  twobit_lexical( 0, 2 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1662, compiled_block_1_1662 );
  twobit_lexical( 0, 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1662, compiled_block_1_1662 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1662, compiled_block_1_1662 );
  twobit_lexical( 0, 2 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_imm_const( int_to_char(46) ); /* #\. */
  twobit_op2_87( 4 ); /* char=? */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_branchf( 1664, compiled_block_1_1664 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1665, compiled_block_1_1665 );
  twobit_invoke( 2 );
  twobit_label( 1665, compiled_block_1_1665 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1664, compiled_block_1_1664 );
  twobit_reg( 2 );
  twobit_branchf( 1667, compiled_block_1_1667 );
  twobit_imm_const( int_to_char(57) ); /* #\9 */
  twobit_op2_branchf_625( 4, 1669, compiled_block_1_1669 ); /* internal:branchf-char=? */
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1670, compiled_block_1_1670 );
  twobit_invoke( 2 );
  twobit_label( 1670, compiled_block_1_1670 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( int_to_char(48) ); /* #\0 */
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1669, compiled_block_1_1669 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 4 );
  twobit_op1_37(); /* char->integer */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_500( 4 ); /* +:idx:idx */
  twobit_op1_38(); /* integer->char */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_setrtn( 1671, compiled_block_1_1671 );
  twobit_invoke( 2 );
  twobit_label( 1671, compiled_block_1_1671 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1667, compiled_block_1_1667 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_setrtn( 1672, compiled_block_1_1672 );
  twobit_invoke( 2 );
  twobit_label( 1672, compiled_block_1_1672 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1662, compiled_block_1_1662 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_16( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 3 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 1, 0, 0, 1680, compiled_block_1_1680 );
  twobit_reg( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 4 );
  twobit_imm_const( int_to_char(46) ); /* #\. */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  str-char-index~1ay%kV~26954 */
  twobit_setrtn( 1681, compiled_block_1_1681 );
  twobit_invoke( 4 );
  twobit_label( 1681, compiled_block_1_1681 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_reg( 4 );
  twobit_op2imm_130( fixnum(1), 151, compiled_temp_1_151 ); /* + */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_62( 3, 152, compiled_temp_1_152 ); /* - */
  twobit_setreg( 3 );
  twobit_store( 3, 4 );
  twobit_reg( 4 );
  twobit_op2imm_131( fixnum(1), 153, compiled_temp_1_153 ); /* - */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 2 );
  twobit_check( 2, 1, 0, 1682, compiled_block_1_1682 );
  twobit_load( 1, 1 );
  twobit_reg( 2 );
  twobit_op2_407( 1 ); /* <:fix:fix */
  twobit_load( 1, 2 );
  twobit_check( 2, 1, 0, 1682, compiled_block_1_1682 );
  twobit_reg_op2imm_check_660(reg(2),fixnum(0),1682,compiled_block_1_1682); /* internal:check->=:fix:fix/imm with (2 1 0) */
  twobit_stack( 2 );
  twobit_op2_802( 2 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_global( 2 ); /* char-numeric? */
  twobit_setrtn( 1683, compiled_block_1_1683 );
  twobit_invoke( 1 );
  twobit_label( 1683, compiled_block_1_1683 );
  twobit_load( 0, 0 );
  twobit_branchf( 1685, compiled_block_1_1685 );
  twobit_load( 4, 3 );
  twobit_stack( 4 );
  twobit_op2_branchf_623( 4, 154, compiled_temp_1_154, 1687, compiled_block_1_1687 ); /* internal:branchf-= */
  twobit_stack( 2 );
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1687, compiled_block_1_1687 );
  twobit_stack( 4 );
  twobit_op2_branchf_619( 4, 155, compiled_temp_1_155, 1689, compiled_block_1_1689 ); /* internal:branchf-< */
  twobit_load( 3, 4 );
  twobit_reg( 4 );
  twobit_op2_62( 3, 156, compiled_temp_1_156 ); /* - */
  twobit_imm_const_setreg( int_to_char(48), 3 ); /* 0 */
  twobit_op2_799( 3 ); /* make-ustring */
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 3 ); /* string-append */
  twobit_pop( 7 );
  twobit_invoke( 2 );
  twobit_label( 1689, compiled_block_1_1689 );
  twobit_stack( 5 );
  twobit_op2_61( 4, 157, compiled_temp_1_157 ); /* + */
  twobit_setreg( 3 );
  twobit_store( 3, 7 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 3, 158, compiled_temp_1_158 ); /* + */
  twobit_setreg( 2 );
  twobit_store( 2, 6 );
  twobit_reg( 2 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 2 );
  twobit_check( 2, 1, 0, 1682, compiled_block_1_1682 );
  twobit_load( 1, 1 );
  twobit_reg( 2 );
  twobit_op2_407( 1 ); /* <:fix:fix */
  twobit_load( 4, 2 );
  twobit_check( 2, 4, 0, 1691, compiled_block_1_1691 );
  twobit_reg_op2imm_check_660(reg(2),fixnum(0),1691,compiled_block_1_1691); /* internal:check->=:fix:fix/imm with (2 4 0) */
  twobit_stack( 2 );
  twobit_op2_802( 2 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_imm_const( int_to_char(53) ); /* #\5 */
  twobit_op2_branchf_629( 4, 1693, compiled_block_1_1693 ); /* internal:branchf-char<? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1692, compiled_block_1_1692 );
  twobit_label( 1693, compiled_block_1_1693 );
  twobit_imm_const( int_to_char(53) ); /* #\5 */
  twobit_op2_branchf_625( 4, 1695, compiled_block_1_1695 ); /* internal:branchf-char=? */
  twobit_load( 1, 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 1, 159, compiled_temp_1_159 ); /* + */
  twobit_load( 1, 4 );
  twobit_op2_66( 1, 160, compiled_temp_1_160 ); /* < */
  twobit_setreg( 1 );
  twobit_reg( 1 );
  twobit_branchf( 1697, compiled_block_1_1697 );
  twobit_reg( 1 );
  twobit_skip( 1692, compiled_block_1_1692 );
  twobit_label( 1697, compiled_block_1_1697 );
  twobit_load( 4, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_branchf_623( 4, 161, compiled_temp_1_161, 1699, compiled_block_1_1699 ); /* internal:branchf-= */
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_skip( 1698, compiled_block_1_1698 );
  twobit_label( 1699, compiled_block_1_1699 );
  twobit_reg( 4 );
  twobit_label( 1698, compiled_block_1_1698 );
  twobit_setreg( 1 );
  twobit_stack( 5 );
  twobit_op2_61( 1, 162, compiled_temp_1_162 ); /* + */
  twobit_setreg( 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 4, 2 );
  twobit_check( 1, 4, 0, 1700, compiled_block_1_1700 );
  twobit_load( 4, 1 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_load( 4, 2 );
  twobit_check( 1, 4, 0, 1700, compiled_block_1_1700 );
  twobit_reg_op2imm_check_660(reg(1),fixnum(0),1700,compiled_block_1_1700); /* internal:check->=:fix:fix/imm with (1 4 0) */
  twobit_stack( 2 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_const( 4 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* memv */
  twobit_setrtn( 1701, compiled_block_1_1701 );
  twobit_invoke( 2 );
  twobit_label( 1701, compiled_block_1_1701 );
  twobit_load( 0, 0 );
  twobit_skip( 1692, compiled_block_1_1692 );
  twobit_label( 1695, compiled_block_1_1695 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1692, compiled_block_1_1692 );
  twobit_branchf( 1703, compiled_block_1_1703 );
  twobit_load( 4, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_load( 3, 2 );
  twobit_check( 0, 3, 0, 1704, compiled_block_1_1704 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_802( 4 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_imm_const( int_to_char(45) ); /* #\- */
  twobit_op2_87( 4 ); /* char=? */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_reg( 4 );
  twobit_branchf( 1706, compiled_block_1_1706 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_skip( 1705, compiled_block_1_1705 );
  twobit_label( 1706, compiled_block_1_1706 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_label( 1705, compiled_block_1_1705 );
  twobit_load( 1, 2 );
  twobit_load( 3, 6 );
  twobit_global( 6 ); /* substring */
  twobit_setrtn( 1707, compiled_block_1_1707 );
  twobit_invoke( 3 );
  twobit_label( 1707, compiled_block_1_1707 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_branchf( 1709, compiled_block_1_1709 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_skip( 1708, compiled_block_1_1708 );
  twobit_label( 1709, compiled_block_1_1709 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_label( 1708, compiled_block_1_1708 );
  twobit_setreg( 3 );
  twobit_stack( 7 );
  twobit_op2_62( 3, 163, compiled_temp_1_163 ); /* - */
  twobit_setreg( 1 );
  twobit_store( 1, 6 );
  twobit_global( 7 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_164, 9, 2 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 6 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_setrtn( 1725, compiled_block_1_1725 );
  twobit_invoke( 2 );
  twobit_label( 1725, compiled_block_1_1725 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 10 ); /* reverse */
  twobit_setrtn( 1726, compiled_block_1_1726 );
  twobit_invoke( 1 );
  twobit_label( 1726, compiled_block_1_1726 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_branchf( 1728, compiled_block_1_1728 );
  twobit_imm_const( int_to_char(45) ); /* #\- */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 2 );
  twobit_skip( 1727, compiled_block_1_1727 );
  twobit_label( 1728, compiled_block_1_1728 );
  twobit_movereg( 4, 2 );
  twobit_label( 1727, compiled_block_1_1727 );
  twobit_global( 11 ); /* string */
  twobit_setreg( 1 );
  twobit_global( 12 ); /* apply */
  twobit_pop( 7 );
  twobit_invoke( 2 );
  twobit_label( 1703, compiled_block_1_1703 );
  twobit_load( 1, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_load( 3, 6 );
  twobit_global( 6 ); /* substring */
  twobit_pop( 7 );
  twobit_invoke( 3 );
  twobit_label( 1685, compiled_block_1_1685 );
  twobit_const( 13 );
  twobit_setreg( 1 );
  twobit_global( 14 ); /*  error~1ay%kV~11404 */
  twobit_pop( 7 );
  twobit_invoke( 1 );
  twobit_label( 1682, compiled_block_1_1682 );
  twobit_trap( 1, 2, 0, 60 );
  twobit_label( 1691, compiled_block_1_1691 );
  twobit_trap( 4, 2, 0, 60 );
  twobit_label( 1704, compiled_block_1_1704 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_label( 1680, compiled_block_1_1680 );
  twobit_trap( 1, 0, 0, 62 );
  twobit_label( 1700, compiled_block_1_1700 );
  twobit_trap( 4, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_164( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_branchf_623( 1, 165, compiled_temp_1_165, 1711, compiled_block_1_1711 ); /* internal:branchf-= */
  twobit_reg( 2 );
  twobit_branchf( 1713, compiled_block_1_1713 );
  twobit_const( 1 );
  twobit_return();
  twobit_label( 1713, compiled_block_1_1713 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_label( 1711, compiled_block_1_1711 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1714, compiled_block_1_1714 );
  twobit_lexical( 0, 2 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1714, compiled_block_1_1714 );
  twobit_lexical( 0, 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1714, compiled_block_1_1714 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_check( 1, 3, 0, 1714, compiled_block_1_1714 );
  twobit_lexical( 0, 2 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_imm_const( int_to_char(46) ); /* #\. */
  twobit_op2_87( 4 ); /* char=? */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_branchf( 1716, compiled_block_1_1716 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1717, compiled_block_1_1717 );
  twobit_invoke( 2 );
  twobit_label( 1717, compiled_block_1_1717 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1716, compiled_block_1_1716 );
  twobit_reg( 2 );
  twobit_branchf( 1719, compiled_block_1_1719 );
  twobit_imm_const( int_to_char(57) ); /* #\9 */
  twobit_op2_branchf_625( 4, 1721, compiled_block_1_1721 ); /* internal:branchf-char=? */
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1722, compiled_block_1_1722 );
  twobit_invoke( 2 );
  twobit_label( 1722, compiled_block_1_1722 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_imm_const( int_to_char(48) ); /* #\0 */
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1721, compiled_block_1_1721 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 4 );
  twobit_op1_37(); /* char->integer */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_500( 4 ); /* +:idx:idx */
  twobit_op1_38(); /* integer->char */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_setrtn( 1723, compiled_block_1_1723 );
  twobit_invoke( 2 );
  twobit_label( 1723, compiled_block_1_1723 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1719, compiled_block_1_1719 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_setrtn( 1724, compiled_block_1_1724 );
  twobit_invoke( 2 );
  twobit_label( 1724, compiled_block_1_1724 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1714, compiled_block_1_1714 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_17( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 1, 0, 0, 1732, compiled_block_1_1732 );
  twobit_reg( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_reg( 4 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 4 );
  twobit_imm_const( int_to_char(101) ); /* #\e */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  str-char-index~1ay%kV~26954 */
  twobit_setrtn( 1733, compiled_block_1_1733 );
  twobit_invoke( 4 );
  twobit_label( 1733, compiled_block_1_1733 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_branchf( 1735, compiled_block_1_1735 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_movereg( 4, 3 );
  twobit_global( 2 ); /* substring */
  twobit_setrtn( 1736, compiled_block_1_1736 );
  twobit_invoke( 3 );
  twobit_label( 1736, compiled_block_1_1736 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 3 ); /*  mold~1ay%kV~26963 */
  twobit_setrtn( 1737, compiled_block_1_1737 );
  twobit_invoke( 2 );
  twobit_label( 1737, compiled_block_1_1737 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_load( 2, 3 );
  twobit_load( 3, 4 );
  twobit_global( 2 ); /* substring */
  twobit_setrtn( 1738, compiled_block_1_1738 );
  twobit_invoke( 3 );
  twobit_label( 1738, compiled_block_1_1738 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 4 ); /* string-append */
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 1735, compiled_block_1_1735 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 5 ); /*  mold-non-finites~1ay%kV~26964 */
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 1732, compiled_block_1_1732 );
  twobit_trap( 1, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_18( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 1, 0, 0, 1741, compiled_block_1_1741 );
  twobit_reg( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_reg( 4 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 4 );
  twobit_imm_const( int_to_char(101) ); /* #\e */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  str-char-index~1ay%kV~26954 */
  twobit_setrtn( 1742, compiled_block_1_1742 );
  twobit_invoke( 4 );
  twobit_label( 1742, compiled_block_1_1742 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_movereg( 4, 3 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* substring */
  twobit_setrtn( 1743, compiled_block_1_1743 );
  twobit_invoke( 3 );
  twobit_label( 1743, compiled_block_1_1743 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 3 ); /*  mold~1ay%kV~26963 */
  twobit_setrtn( 1744, compiled_block_1_1744 );
  twobit_invoke( 2 );
  twobit_label( 1744, compiled_block_1_1744 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_load( 2, 3 );
  twobit_load( 3, 4 );
  twobit_global( 2 ); /* substring */
  twobit_setrtn( 1745, compiled_block_1_1745 );
  twobit_invoke( 3 );
  twobit_label( 1745, compiled_block_1_1745 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 4 ); /* string-append */
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 1741, compiled_block_1_1741 );
  twobit_trap( 1, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_19( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 3 );
  twobit_branchf( 1748, compiled_block_1_1748 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_148, 3, 3 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 1748, compiled_block_1_1748 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_149, 5, 3 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_148( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1749, compiled_block_1_1749 );
  twobit_lexical( 0, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1749, compiled_block_1_1749 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1749, compiled_block_1_1749 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1749, compiled_block_1_1749 );
  twobit_lexical( 0, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_imm_const( int_to_char(48) ); /* #\0 */
  twobit_op2_branchf_625( 4, 1751, compiled_block_1_1751 ); /* internal:branchf-char=? */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_500( 1 ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 1751, compiled_block_1_1751 );
  twobit_imm_const( int_to_char(46) ); /* #\. */
  twobit_op2_branchf_625( 4, 1754, compiled_block_1_1754 ); /* internal:branchf-char=? */
  twobit_reg( 1 );
  twobit_op2imm_451( fixnum(2) ); /* =:fix:fix */
  twobit_branchf( 1756, compiled_block_1_1756 );
  twobit_lexical( 0, 1 );
  twobit_return();
  twobit_label( 1756, compiled_block_1_1756 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /* substring */
  twobit_setrtn( 1757, compiled_block_1_1757 );
  twobit_invoke( 3 );
  twobit_label( 1757, compiled_block_1_1757 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* string-append */
  twobit_pop( 0 );
  twobit_invoke( 2 );
  twobit_label( 1754, compiled_block_1_1754 );
  twobit_reg( 1 );
  twobit_op2imm_451( fixnum(1) ); /* =:fix:fix */
  twobit_branchf( 1760, compiled_block_1_1760 );
  twobit_lexical( 0, 1 );
  twobit_return();
  twobit_label( 1760, compiled_block_1_1760 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /* substring */
  twobit_setrtn( 1761, compiled_block_1_1761 );
  twobit_invoke( 3 );
  twobit_label( 1761, compiled_block_1_1761 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* string-append */
  twobit_pop( 0 );
  twobit_invoke( 2 );
  twobit_label( 1749, compiled_block_1_1749 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_149( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1764, compiled_block_1_1764 );
  twobit_lexical( 0, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1764, compiled_block_1_1764 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1764, compiled_block_1_1764 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1764, compiled_block_1_1764 );
  twobit_lexical( 0, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_imm_const( int_to_char(48) ); /* #\0 */
  twobit_op2_branchf_625( 4, 1766, compiled_block_1_1766 ); /* internal:branchf-char=? */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_500( 1 ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 1766, compiled_block_1_1766 );
  twobit_imm_const( int_to_char(46) ); /* #\. */
  twobit_op2_branchf_625( 4, 1769, compiled_block_1_1769 ); /* internal:branchf-char=? */
  twobit_reg( 1 );
  twobit_op2imm_451( fixnum(1) ); /* =:fix:fix */
  twobit_branchf( 1771, compiled_block_1_1771 );
  twobit_lexical( 0, 1 );
  twobit_return();
  twobit_label( 1771, compiled_block_1_1771 );
  twobit_reg( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /* substring */
  twobit_invoke( 3 );
  twobit_label( 1769, compiled_block_1_1769 );
  twobit_reg( 1 );
  twobit_op1_branchf_612( 150, compiled_temp_1_150, 1774, compiled_block_1_1774 ); /* internal:branchf-zero? */
  twobit_lexical( 0, 1 );
  twobit_return();
  twobit_label( 1774, compiled_block_1_1774 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /* substring */
  twobit_invoke( 3 );
  twobit_label( 1764, compiled_block_1_1764 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_20( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 1, 5 );
  twobit_reg( 1 );
  twobit_op1_27( 110, compiled_temp_1_110 ); /* exact->inexact */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* number->string */
  twobit_setrtn( 1777, compiled_block_1_1777 );
  twobit_invoke( 1 );
  twobit_label( 1777, compiled_block_1_1777 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 4, 0, 0, 1778, compiled_block_1_1778 );
  twobit_reg( 4 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 3 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 2 );
  twobit_store( 2, 7 );
  twobit_movereg( 2, 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( int_to_char(101) ); /* #\e */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  str-char-index~1ay%kV~26954 */
  twobit_setrtn( 1779, compiled_block_1_1779 );
  twobit_invoke( 4 );
  twobit_label( 1779, compiled_block_1_1779 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_branchf( 1781, compiled_block_1_1781 );
  twobit_load( 1, 1 );
  twobit_imm_const( int_to_char(46) ); /* #\. */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  str-char-index~1ay%kV~26954 */
  twobit_setrtn( 1782, compiled_block_1_1782 );
  twobit_invoke( 4 );
  twobit_label( 1782, compiled_block_1_1782 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 3, 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 3, 111, compiled_temp_1_111 ); /* + */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_load( 3, 3 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 1783, compiled_block_1_1783 );
  twobit_invoke( 3 );
  twobit_label( 1783, compiled_block_1_1783 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* string->number */
  twobit_setrtn( 1784, compiled_block_1_1784 );
  twobit_invoke( 1 );
  twobit_label( 1784, compiled_block_1_1784 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_reg( 4 );
  twobit_op2imm_132( fixnum(0), 112, compiled_temp_1_112 ); /* < */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_branchf( 1786, compiled_block_1_1786 );
  twobit_stack( 4 );
  twobit_branchf( 1788, compiled_block_1_1788 );
  twobit_stack( 5 );
  twobit_op2imm_branchf_635( fixnum(0), 113, compiled_temp_1_113, 1790, compiled_block_1_1790 ); /* internal:branchf-</imm */
  twobit_stack( 4 );
  twobit_op2imm_131( fixnum(1), 114, compiled_temp_1_114 ); /* - */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_32( 115, compiled_temp_1_115 ); /* -- */
  twobit_op2_62( 3, 116, compiled_temp_1_116 ); /* - */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_635( fixnum(0), 117, compiled_temp_1_117, 1792, compiled_block_1_1792 ); /* internal:branchf-</imm */
  twobit_reg( 4 );
  twobit_op1_32( 118, compiled_temp_1_118 ); /* -- */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 4, 119, compiled_temp_1_119 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_movereg( 4, 3 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 1793, compiled_block_1_1793 );
  twobit_invoke( 3 );
  twobit_label( 1793, compiled_block_1_1793 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_load( 2, 5 );
  twobit_load( 3, 4 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 1794, compiled_block_1_1794 );
  twobit_invoke( 3 );
  twobit_label( 1794, compiled_block_1_1794 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 3, 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 3, 120, compiled_temp_1_120 ); /* + */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_load( 3, 2 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 1795, compiled_block_1_1795 );
  twobit_invoke( 3 );
  twobit_label( 1795, compiled_block_1_1795 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 5 );
  twobit_load( 1, 3 );
  twobit_const( 5 );
  twobit_setreg( 2 );
  twobit_global( 6 ); /* string-append */
  twobit_pop( 7 );
  twobit_invoke( 4 );
  twobit_label( 1792, compiled_block_1_1792 );
  twobit_imm_const( int_to_char(48) ); /* #\0 */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_799( 3 ); /* make-ustring */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_load( 3, 4 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 1797, compiled_block_1_1797 );
  twobit_invoke( 3 );
  twobit_label( 1797, compiled_block_1_1797 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 3, 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 3, 121, compiled_temp_1_121 ); /* + */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_load( 3, 2 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 1798, compiled_block_1_1798 );
  twobit_invoke( 3 );
  twobit_label( 1798, compiled_block_1_1798 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 3 );
  twobit_load( 2, 5 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /* string-append */
  twobit_pop( 7 );
  twobit_invoke( 4 );
  twobit_label( 1790, compiled_block_1_1790 );
  twobit_reg( 4 );
  twobit_op1_32( 122, compiled_temp_1_122 ); /* -- */
  twobit_load( 3, 4 );
  twobit_op2_62( 3, 123, compiled_temp_1_123 ); /* - */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_635( fixnum(0), 124, compiled_temp_1_124, 1801, compiled_block_1_1801 ); /* internal:branchf-</imm */
  twobit_reg( 4 );
  twobit_op1_32( 125, compiled_temp_1_125 ); /* -- */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_movereg( 4, 3 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 1802, compiled_block_1_1802 );
  twobit_invoke( 3 );
  twobit_label( 1802, compiled_block_1_1802 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 1 );
  twobit_load( 2, 3 );
  twobit_load( 3, 4 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 1803, compiled_block_1_1803 );
  twobit_invoke( 3 );
  twobit_label( 1803, compiled_block_1_1803 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 3, 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 3, 126, compiled_temp_1_126 ); /* + */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_load( 3, 2 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 1804, compiled_block_1_1804 );
  twobit_invoke( 3 );
  twobit_label( 1804, compiled_block_1_1804 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 3 );
  twobit_load( 1, 5 );
  twobit_const( 5 );
  twobit_setreg( 2 );
  twobit_global( 6 ); /* string-append */
  twobit_pop( 7 );
  twobit_invoke( 4 );
  twobit_label( 1801, compiled_block_1_1801 );
  twobit_imm_const( int_to_char(48) ); /* #\0 */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_799( 3 ); /* make-ustring */
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_load( 3, 4 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 1806, compiled_block_1_1806 );
  twobit_invoke( 3 );
  twobit_label( 1806, compiled_block_1_1806 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 3, 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 3, 127, compiled_temp_1_127 ); /* + */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_load( 3, 2 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 1807, compiled_block_1_1807 );
  twobit_invoke( 3 );
  twobit_label( 1807, compiled_block_1_1807 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 3 );
  twobit_load( 2, 5 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /* string-append */
  twobit_pop( 7 );
  twobit_invoke( 4 );
  twobit_label( 1788, compiled_block_1_1788 );
  twobit_stack( 5 );
  twobit_op2imm_branchf_635( fixnum(0), 128, compiled_temp_1_128, 1810, compiled_block_1_1810 ); /* internal:branchf-</imm */
  twobit_stack( 2 );
  twobit_op2imm_131( fixnum(1), 129, compiled_temp_1_129 ); /* - */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_32( 130, compiled_temp_1_130 ); /* -- */
  twobit_op2_62( 3, 131, compiled_temp_1_131 ); /* - */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_635( fixnum(0), 132, compiled_temp_1_132, 1812, compiled_block_1_1812 ); /* internal:branchf-</imm */
  twobit_reg( 4 );
  twobit_op1_32( 133, compiled_temp_1_133 ); /* -- */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 4, 134, compiled_temp_1_134 ); /* + */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_movereg( 4, 3 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 1813, compiled_block_1_1813 );
  twobit_invoke( 3 );
  twobit_label( 1813, compiled_block_1_1813 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 1 );
  twobit_load( 2, 4 );
  twobit_load( 3, 2 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 1814, compiled_block_1_1814 );
  twobit_invoke( 3 );
  twobit_label( 1814, compiled_block_1_1814 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 1, 5 );
  twobit_const( 5 );
  twobit_setreg( 2 );
  twobit_global( 6 ); /* string-append */
  twobit_pop( 7 );
  twobit_invoke( 3 );
  twobit_label( 1812, compiled_block_1_1812 );
  twobit_imm_const( int_to_char(48) ); /* #\0 */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_799( 3 ); /* make-ustring */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_load( 3, 2 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 1816, compiled_block_1_1816 );
  twobit_invoke( 3 );
  twobit_label( 1816, compiled_block_1_1816 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 4 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /* string-append */
  twobit_pop( 7 );
  twobit_invoke( 3 );
  twobit_label( 1810, compiled_block_1_1810 );
  twobit_reg( 4 );
  twobit_op1_32( 135, compiled_temp_1_135 ); /* -- */
  twobit_load( 3, 2 );
  twobit_op2_62( 3, 136, compiled_temp_1_136 ); /* - */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2imm_branchf_635( fixnum(0), 137, compiled_temp_1_137, 1819, compiled_block_1_1819 ); /* internal:branchf-</imm */
  twobit_reg( 4 );
  twobit_op1_32( 138, compiled_temp_1_138 ); /* -- */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_movereg( 4, 3 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 1820, compiled_block_1_1820 );
  twobit_invoke( 3 );
  twobit_label( 1820, compiled_block_1_1820 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 1 );
  twobit_load( 2, 4 );
  twobit_load( 3, 2 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 1821, compiled_block_1_1821 );
  twobit_invoke( 3 );
  twobit_label( 1821, compiled_block_1_1821 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 1, 5 );
  twobit_const( 5 );
  twobit_setreg( 2 );
  twobit_global( 6 ); /* string-append */
  twobit_pop( 7 );
  twobit_invoke( 3 );
  twobit_label( 1819, compiled_block_1_1819 );
  twobit_imm_const( int_to_char(48) ); /* #\0 */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_799( 3 ); /* make-ustring */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_load( 3, 2 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 1823, compiled_block_1_1823 );
  twobit_invoke( 3 );
  twobit_label( 1823, compiled_block_1_1823 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 4 );
  twobit_const( 8 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /* string-append */
  twobit_pop( 7 );
  twobit_invoke( 3 );
  twobit_label( 1786, compiled_block_1_1786 );
  twobit_stack( 4 );
  twobit_branchf( 1826, compiled_block_1_1826 );
  twobit_stack( 4 );
  twobit_op2imm_130( fixnum(1), 139, compiled_temp_1_139 ); /* + */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_62( 3, 140, compiled_temp_1_140 ); /* - */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_62( 3, 141, compiled_temp_1_141 ); /* - */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op2imm_branchf_635( fixnum(0), 142, compiled_temp_1_142, 1828, compiled_block_1_1828 ); /* internal:branchf-</imm */
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_load( 3, 4 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 1829, compiled_block_1_1829 );
  twobit_invoke( 3 );
  twobit_label( 1829, compiled_block_1_1829 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 3, 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 3, 143, compiled_temp_1_143 ); /* + */
  twobit_setreg( 2 );
  twobit_load( 1, 6 );
  twobit_reg( 3 );
  twobit_op2_61( 1, 144, compiled_temp_1_144 ); /* + */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 3, 145, compiled_temp_1_145 ); /* + */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_load( 1, 1 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 1830, compiled_block_1_1830 );
  twobit_invoke( 3 );
  twobit_label( 1830, compiled_block_1_1830 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 1, 1 );
  twobit_load( 2, 6 );
  twobit_load( 3, 2 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 1831, compiled_block_1_1831 );
  twobit_invoke( 3 );
  twobit_label( 1831, compiled_block_1_1831 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 2, 4 );
  twobit_load( 1, 5 );
  twobit_const( 5 );
  twobit_setreg( 3 );
  twobit_global( 6 ); /* string-append */
  twobit_pop( 7 );
  twobit_invoke( 4 );
  twobit_label( 1828, compiled_block_1_1828 );
  twobit_imm_const( int_to_char(48) ); /* #\0 */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op2_799( 2 ); /* make-ustring */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_load( 3, 4 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 1833, compiled_block_1_1833 );
  twobit_invoke( 3 );
  twobit_label( 1833, compiled_block_1_1833 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 3, 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 3, 146, compiled_temp_1_146 ); /* + */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_load( 3, 2 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 1834, compiled_block_1_1834 );
  twobit_invoke( 3 );
  twobit_label( 1834, compiled_block_1_1834 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 3, 6 );
  twobit_load( 1, 5 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_global( 6 ); /* string-append */
  twobit_pop( 7 );
  twobit_invoke( 4 );
  twobit_label( 1826, compiled_block_1_1826 );
  twobit_imm_const( int_to_char(48) ); /* #\0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_799( 2 ); /* make-ustring */
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_load( 3, 2 );
  twobit_global( 3 ); /* substring */
  twobit_setrtn( 1836, compiled_block_1_1836 );
  twobit_invoke( 3 );
  twobit_label( 1836, compiled_block_1_1836 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 6 );
  twobit_const( 9 );
  twobit_setreg( 3 );
  twobit_global( 6 ); /* string-append */
  twobit_pop( 7 );
  twobit_invoke( 3 );
  twobit_label( 1781, compiled_block_1_1781 );
  twobit_load( 1, 1 );
  twobit_imm_const( int_to_char(46) ); /* #\. */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 3 );
  twobit_load( 4, 7 );
  twobit_global( 2 ); /*  str-char-index~1ay%kV~26954 */
  twobit_setrtn( 1838, compiled_block_1_1838 );
  twobit_invoke( 4 );
  twobit_label( 1838, compiled_block_1_1838 );
  twobit_load( 0, 0 );
  twobit_op2imm_131( fixnum(1), 147, compiled_temp_1_147 ); /* - */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1839, compiled_block_1_1839 );
  twobit_load( 3, 3 );
  twobit_reg_op2_check_661(reg(4),reg(3),1839,compiled_block_1_1839); /* internal:check-range with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_802( 4 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_global( 10 ); /* char-numeric? */
  twobit_setrtn( 1840, compiled_block_1_1840 );
  twobit_invoke( 1 );
  twobit_label( 1840, compiled_block_1_1840 );
  twobit_load( 0, 0 );
  twobit_branchf( 1842, compiled_block_1_1842 );
  twobit_stack( 1 );
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1842, compiled_block_1_1842 );
  twobit_const( 11 );
  twobit_setreg( 1 );
  twobit_global( 12 ); /*  error~1ay%kV~11404 */
  twobit_pop( 7 );
  twobit_invoke( 1 );
  twobit_label( 1839, compiled_block_1_1839 );
  twobit_trap( 1, 4, 0, 60 );
  twobit_label( 1778, compiled_block_1_1778 );
  twobit_trap( 4, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_21( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_109, 3, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_109( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1844, compiled_block_1_1844 );
  twobit_lexical( 0, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1844, compiled_block_1_1844 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1844, compiled_block_1_1844 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1844, compiled_block_1_1844 );
  twobit_lexical( 0, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_imm_const( int_to_char(48) ); /* #\0 */
  twobit_op2_branchf_625( 4, 1846, compiled_block_1_1846 ); /* internal:branchf-char=? */
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_500( 1 ); /* +:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 1846, compiled_block_1_1846 );
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1844, compiled_block_1_1844 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_22( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 2 );
  twobit_op2imm_131( fixnum(1), 107, compiled_temp_1_107 ); /* - */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_1_108, 3, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 4, 1 );
  twobit_load( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_108( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1849, compiled_block_1_1849 );
  twobit_lexical( 0, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1849, compiled_block_1_1849 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1849, compiled_block_1_1849 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1849, compiled_block_1_1849 );
  twobit_lexical( 0, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_imm_const( int_to_char(48) ); /* #\0 */
  twobit_op2_branchf_625( 4, 1851, compiled_block_1_1851 ); /* internal:branchf-char=? */
  twobit_reg( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 1851, compiled_block_1_1851 );
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1849, compiled_block_1_1849 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_23( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 2 );
  twobit_op2imm_131( fixnum(1), 105, compiled_temp_1_105 ); /* - */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_1_106, 3, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 4, 1 );
  twobit_load( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_106( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_23(); /* fixnum? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1854, compiled_block_1_1854 );
  twobit_lexical( 0, 1 );
  twobit_op1_800(); /* ustring? */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1854, compiled_block_1_1854 );
  twobit_lexical( 0, 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_407( 4 ); /* <:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1854, compiled_block_1_1854 );
  twobit_reg( 1 );
  twobit_op2imm_455( fixnum(0) ); /* >=:fix:fix */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_reg( 2 );
  twobit_check( 1, 3, 0, 1854, compiled_block_1_1854 );
  twobit_lexical( 0, 1 );
  twobit_op2_802( 1 ); /* ustring-ref:trusted */
  twobit_setreg( 4 );
  twobit_imm_const( int_to_char(48) ); /* #\0 */
  twobit_op2_branchf_625( 4, 1856, compiled_block_1_1856 ); /* internal:branchf-char=? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1855, compiled_block_1_1855 );
  twobit_label( 1856, compiled_block_1_1856 );
  twobit_imm_const( int_to_char(46) ); /* #\. */
  twobit_op2_87( 4 ); /* char=? */
  twobit_label( 1855, compiled_block_1_1855 );
  twobit_branchf( 1858, compiled_block_1_1858 );
  twobit_reg( 1 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 1858, compiled_block_1_1858 );
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1854, compiled_block_1_1854 );
  twobit_trap( 3, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_24( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 8 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_reg( 1 );
  twobit_op1_27( 85, compiled_temp_1_85 ); /* exact->inexact */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* number->string */
  twobit_setrtn( 1861, compiled_block_1_1861 );
  twobit_invoke( 1 );
  twobit_label( 1861, compiled_block_1_1861 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 4, 0, 0, 1862, compiled_block_1_1862 );
  twobit_reg( 4 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_reg( 3 );
  twobit_op2imm_522( fixnum(1) ); /* -:idx:idx */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( int_to_char(101) ); /* #\e */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  str-char-index~1ay%kV~26954 */
  twobit_setrtn( 1863, compiled_block_1_1863 );
  twobit_invoke( 4 );
  twobit_label( 1863, compiled_block_1_1863 );
  twobit_load( 0, 0 );
  twobit_branchf( 1865, compiled_block_1_1865 );
  twobit_stack( 1 );
  twobit_pop( 8 );
  twobit_return();
  twobit_label( 1865, compiled_block_1_1865 );
  twobit_load( 1, 1 );
  twobit_imm_const( int_to_char(46) ); /* #\. */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 3 );
  twobit_load( 4, 2 );
  twobit_global( 2 ); /*  str-char-index~1ay%kV~26954 */
  twobit_setrtn( 1866, compiled_block_1_1866 );
  twobit_invoke( 4 );
  twobit_label( 1866, compiled_block_1_1866 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_stack( 3 );
  twobit_op2imm_132( fixnum(1), 86, compiled_temp_1_86 ); /* < */
  twobit_setreg( 3 );
  twobit_load( 2, 3 );
  twobit_imm_const( fixnum(-1) ); /* -1 */
  twobit_op2_branchf_619( 2, 87, compiled_temp_1_87, 1868, compiled_block_1_1868 ); /* internal:branchf-< */
  twobit_reg( 3 );
  twobit_skip( 1867, compiled_block_1_1867 );
  twobit_label( 1868, compiled_block_1_1868 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1867, compiled_block_1_1867 );
  twobit_branchf( 1870, compiled_block_1_1870 );
  twobit_reg( 2 );
  twobit_op1_branchf_612( 88, compiled_temp_1_88, 1872, compiled_block_1_1872 ); /* internal:branchf-zero? */
  twobit_load( 1, 1 );
  twobit_const( 3 );
  twobit_setreg( 2 );
  twobit_global( 4 ); /* string-append */
  twobit_pop( 8 );
  twobit_invoke( 2 );
  twobit_label( 1872, compiled_block_1_1872 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 4, 89, compiled_temp_1_89 ); /* + */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /*  non-0-index~1ay%kV~26969 */
  twobit_setrtn( 1874, compiled_block_1_1874 );
  twobit_invoke( 2 );
  twobit_label( 1874, compiled_block_1_1874 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_stack( 3 );
  twobit_op2imm_branchf_635( fixnum(0), 90, compiled_temp_1_90, 1876, compiled_block_1_1876 ); /* internal:branchf-</imm */
  twobit_const( 6 );
  twobit_skip( 1875, compiled_block_1_1875 );
  twobit_label( 1876, compiled_block_1_1876 );
  twobit_const( 7 );
  twobit_label( 1875, compiled_block_1_1875 );
  twobit_setreg( 3 );
  twobit_store( 3, 8 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 4, 91, compiled_temp_1_91 ); /* + */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_movereg( 2, 3 );
  twobit_load( 1, 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 8 ); /* substring */
  twobit_setrtn( 1877, compiled_block_1_1877 );
  twobit_invoke( 3 );
  twobit_label( 1877, compiled_block_1_1877 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_load( 3, 2 );
  twobit_stack( 4 );
  twobit_op2_branchf_623( 3, 92, compiled_temp_1_92, 1879, compiled_block_1_1879 ); /* internal:branchf-= */
  twobit_const( 9 );
  twobit_skip( 1878, compiled_block_1_1878 );
  twobit_label( 1879, compiled_block_1_1879 );
  twobit_load( 1, 1 );
  twobit_load( 2, 3 );
  twobit_load( 3, 5 );
  twobit_global( 8 ); /* substring */
  twobit_setrtn( 1880, compiled_block_1_1880 );
  twobit_invoke( 3 );
  twobit_label( 1880, compiled_block_1_1880 );
  twobit_load( 0, 0 );
  twobit_label( 1878, compiled_block_1_1878 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 3, 6 );
  twobit_stack( 4 );
  twobit_op2_62( 3, 93, compiled_temp_1_93 ); /* - */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* number->string */
  twobit_setrtn( 1881, compiled_block_1_1881 );
  twobit_invoke( 1 );
  twobit_label( 1881, compiled_block_1_1881 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 4, 2 );
  twobit_load( 2, 7 );
  twobit_load( 1, 8 );
  twobit_const( 10 );
  twobit_setreg( 3 );
  twobit_const( 11 );
  twobit_setreg( 5 );
  twobit_load( 6, 3 );
  twobit_global( 4 ); /* string-append */
  twobit_pop( 8 );
  twobit_invoke( 6 );
  twobit_label( 1870, compiled_block_1_1870 );
  twobit_load( 1, 1 );
  twobit_load( 2, 5 );
  twobit_global( 12 ); /*  non-0-index-right~1ay%kV~26970 */
  twobit_setrtn( 1883, compiled_block_1_1883 );
  twobit_invoke( 2 );
  twobit_label( 1883, compiled_block_1_1883 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 3, 6 );
  twobit_reg( 4 );
  twobit_op2_branchf_623( 3, 94, compiled_temp_1_94, 1885, compiled_block_1_1885 ); /* internal:branchf-= */
  twobit_load( 1, 1 );
  twobit_movereg( 3, 2 );
  twobit_global( 12 ); /*  non-0-index-right~1ay%kV~26970 */
  twobit_setrtn( 1886, compiled_block_1_1886 );
  twobit_invoke( 2 );
  twobit_label( 1886, compiled_block_1_1886 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 1, 1 );
  twobit_check( 4, 1, 0, 1887, compiled_block_1_1887 );
  twobit_load( 3, 5 );
  twobit_reg_op2_check_661(reg(4),reg(3),1887,compiled_block_1_1887); /* internal:check-range with (4 1 0) */
  twobit_stack( 1 );
  twobit_op2_802( 4 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_global( 13 ); /* char-numeric? */
  twobit_setrtn( 1888, compiled_block_1_1888 );
  twobit_invoke( 1 );
  twobit_label( 1888, compiled_block_1_1888 );
  twobit_load( 0, 0 );
  twobit_branchf( 1890, compiled_block_1_1890 );
  twobit_stack( 3 );
  twobit_op2imm_branchf_635( fixnum(0), 95, compiled_temp_1_95, 1892, compiled_block_1_1892 ); /* internal:branchf-</imm */
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 3 );
  twobit_global( 8 ); /* substring */
  twobit_setrtn( 1893, compiled_block_1_1893 );
  twobit_invoke( 3 );
  twobit_label( 1893, compiled_block_1_1893 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_stack( 2 );
  twobit_op2imm_451( fixnum(1) ); /* =:fix:fix */
  twobit_branchf( 1895, compiled_block_1_1895 );
  twobit_const( 9 );
  twobit_skip( 1894, compiled_block_1_1894 );
  twobit_label( 1895, compiled_block_1_1895 );
  twobit_load( 3, 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_500( 3 ); /* +:idx:idx */
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_global( 8 ); /* substring */
  twobit_setrtn( 1896, compiled_block_1_1896 );
  twobit_invoke( 3 );
  twobit_label( 1896, compiled_block_1_1896 );
  twobit_load( 0, 0 );
  twobit_label( 1894, compiled_block_1_1894 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_stack( 6 );
  twobit_op2imm_131( fixnum(2), 96, compiled_temp_1_96 ); /* - */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* number->string */
  twobit_setrtn( 1897, compiled_block_1_1897 );
  twobit_invoke( 1 );
  twobit_label( 1897, compiled_block_1_1897 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 3 );
  twobit_load( 1, 5 );
  twobit_movereg( 4, 5 );
  twobit_const( 10 );
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 4 );
  twobit_global( 4 ); /* string-append */
  twobit_pop( 8 );
  twobit_invoke( 5 );
  twobit_label( 1892, compiled_block_1_1892 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 3 );
  twobit_global( 8 ); /* substring */
  twobit_setrtn( 1899, compiled_block_1_1899 );
  twobit_invoke( 3 );
  twobit_label( 1899, compiled_block_1_1899 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_stack( 2 );
  twobit_op2imm_451( fixnum(0) ); /* =:fix:fix */
  twobit_branchf( 1901, compiled_block_1_1901 );
  twobit_const( 9 );
  twobit_skip( 1900, compiled_block_1_1900 );
  twobit_label( 1901, compiled_block_1_1901 );
  twobit_load( 3, 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_500( 3 ); /* +:idx:idx */
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_global( 8 ); /* substring */
  twobit_setrtn( 1902, compiled_block_1_1902 );
  twobit_invoke( 3 );
  twobit_label( 1902, compiled_block_1_1902 );
  twobit_load( 0, 0 );
  twobit_label( 1900, compiled_block_1_1900 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_stack( 6 );
  twobit_op2imm_131( fixnum(1), 97, compiled_temp_1_97 ); /* - */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* number->string */
  twobit_setrtn( 1903, compiled_block_1_1903 );
  twobit_invoke( 1 );
  twobit_label( 1903, compiled_block_1_1903 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 3, 3 );
  twobit_load( 1, 5 );
  twobit_movereg( 4, 5 );
  twobit_const( 10 );
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 4 );
  twobit_global( 4 ); /* string-append */
  twobit_pop( 8 );
  twobit_invoke( 5 );
  twobit_label( 1890, compiled_block_1_1890 );
  twobit_const( 15 );
  twobit_setreg( 1 );
  twobit_global( 16 ); /*  error~1ay%kV~11404 */
  twobit_pop( 8 );
  twobit_invoke( 1 );
  twobit_label( 1885, compiled_block_1_1885 );
  twobit_stack( 3 );
  twobit_op2imm_branchf_635( fixnum(0), 98, compiled_temp_1_98, 1907, compiled_block_1_1907 ); /* internal:branchf-</imm */
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 3 );
  twobit_global( 8 ); /* substring */
  twobit_setrtn( 1908, compiled_block_1_1908 );
  twobit_invoke( 3 );
  twobit_label( 1908, compiled_block_1_1908 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(2) ); /* 2 */
  twobit_setreg( 2 );
  twobit_load( 3, 6 );
  twobit_global( 8 ); /* substring */
  twobit_setrtn( 1909, compiled_block_1_1909 );
  twobit_invoke( 3 );
  twobit_label( 1909, compiled_block_1_1909 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 3, 6 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 3, 99, compiled_temp_1_99 ); /* + */
  twobit_setreg( 2 );
  twobit_load( 1, 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 1, 100, compiled_temp_1_100 ); /* + */
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_global( 8 ); /* substring */
  twobit_setrtn( 1910, compiled_block_1_1910 );
  twobit_invoke( 3 );
  twobit_label( 1910, compiled_block_1_1910 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_stack( 6 );
  twobit_op2imm_131( fixnum(2), 101, compiled_temp_1_101 ); /* - */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* number->string */
  twobit_setrtn( 1911, compiled_block_1_1911 );
  twobit_invoke( 1 );
  twobit_label( 1911, compiled_block_1_1911 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 4, 1 );
  twobit_load( 3, 5 );
  twobit_load( 1, 3 );
  twobit_const( 10 );
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 5 );
  twobit_load( 6, 6 );
  twobit_global( 4 ); /* string-append */
  twobit_pop( 8 );
  twobit_invoke( 6 );
  twobit_label( 1907, compiled_block_1_1907 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 3 );
  twobit_global( 8 ); /* substring */
  twobit_setrtn( 1913, compiled_block_1_1913 );
  twobit_invoke( 3 );
  twobit_label( 1913, compiled_block_1_1913 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_setreg( 2 );
  twobit_load( 3, 6 );
  twobit_global( 8 ); /* substring */
  twobit_setrtn( 1914, compiled_block_1_1914 );
  twobit_invoke( 3 );
  twobit_label( 1914, compiled_block_1_1914 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 3, 6 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 3, 102, compiled_temp_1_102 ); /* + */
  twobit_setreg( 2 );
  twobit_load( 1, 4 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_op2_61( 1, 103, compiled_temp_1_103 ); /* + */
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_global( 8 ); /* substring */
  twobit_setrtn( 1915, compiled_block_1_1915 );
  twobit_invoke( 3 );
  twobit_label( 1915, compiled_block_1_1915 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_stack( 6 );
  twobit_op2imm_131( fixnum(1), 104, compiled_temp_1_104 ); /* - */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* number->string */
  twobit_setrtn( 1916, compiled_block_1_1916 );
  twobit_invoke( 1 );
  twobit_label( 1916, compiled_block_1_1916 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_load( 4, 1 );
  twobit_load( 3, 3 );
  twobit_load( 1, 5 );
  twobit_const( 10 );
  twobit_setreg( 2 );
  twobit_const( 14 );
  twobit_setreg( 5 );
  twobit_load( 6, 6 );
  twobit_global( 4 ); /* string-append */
  twobit_pop( 8 );
  twobit_invoke( 6 );
  twobit_label( 1887, compiled_block_1_1887 );
  twobit_trap( 1, 4, 0, 60 );
  twobit_label( 1862, compiled_block_1_1862 );
  twobit_trap( 4, 0, 0, 62 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_25( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1919, compiled_block_1_1919 ); /* internal:branchf-null? */
  twobit_reg( 1 );
  twobit_op1_18(); /* complex? */
  twobit_branchf( 1921, compiled_block_1_1921 );
  twobit_global( 1 ); /* number->string */
  twobit_invoke( 1 );
  twobit_label( 1921, compiled_block_1_1921 );
  twobit_reg( 1 );
  twobit_op1_17(); /* symbol? */
  twobit_branchf( 1924, compiled_block_1_1924 );
  twobit_global( 2 ); /* symbol->string */
  twobit_invoke( 1 );
  twobit_label( 1924, compiled_block_1_1924 );
  twobit_reg( 1 );
  twobit_op2imm_129( TRUE_CONST ); /* eq? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1927, compiled_block_1_1927 );
  twobit_reg( 4 );
  twobit_skip( 1926, compiled_block_1_1926 );
  twobit_label( 1927, compiled_block_1_1927 );
  twobit_reg( 1 );
  twobit_op2imm_129( FALSE_CONST ); /* eq? */
  twobit_label( 1926, compiled_block_1_1926 );
  twobit_branchf( 1929, compiled_block_1_1929 );
  twobit_reg( 1 );
  twobit_branchf( 1931, compiled_block_1_1931 );
  twobit_const( 3 );
  twobit_return();
  twobit_label( 1931, compiled_block_1_1931 );
  twobit_const( 4 );
  twobit_return();
  twobit_label( 1929, compiled_block_1_1929 );
  twobit_reg( 1 );
  twobit_op1_branchf_615( 1933, compiled_block_1_1933 ); /* internal:branchf-char? */
  twobit_global( 5 ); /* string */
  twobit_invoke( 1 );
  twobit_label( 1933, compiled_block_1_1933 );
  twobit_reg( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 1936, compiled_block_1_1936 );
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1936, compiled_block_1_1936 );
  twobit_global( 6 ); /* display */
  twobit_setreg( 2 );
  twobit_global( 7 ); /*  object->string~1ay%kV~26952 */
  twobit_invoke( 2 );
  twobit_label( 1919, compiled_block_1_1919 );
  twobit_save( 21 );
  twobit_store( 0, 0 );
  twobit_store( 1, 5 );
  twobit_reg( 2 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_610( 1939, compiled_block_1_1939 ); /* internal:branchf-null? */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_skip( 1938, compiled_block_1_1938 );
  twobit_label( 1939, compiled_block_1_1939 );
  twobit_reg_op1_check_652(reg(3),1940,compiled_block_1_1940); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1942, compiled_block_1_1942 );
  twobit_reg( 2 );
  twobit_op1_25(); /* exact? */
  twobit_skip( 1941, compiled_block_1_1941 );
  twobit_label( 1942, compiled_block_1_1942 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1941, compiled_block_1_1941 );
  twobit_branchf( 1944, compiled_block_1_1944 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op2_84( 31 ); /* cell-set! */
  twobit_reg( 2 );
  twobit_skip( 1938, compiled_block_1_1938 );
  twobit_label( 1944, compiled_block_1_1944 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 31 );
  twobit_reg( 2 );
  twobit_op2_58( 31 ); /* cons */
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_global( 8 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 31 );
  twobit_movereg( 4, 2 );
  twobit_movereg( 31, 1 );
  twobit_lambda( compiled_start_1_26, 10, 2 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_op2_84( 30 ); /* cell-set! */
  twobit_reg( 31 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 1 );
  twobit_movereg( 1, 3 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_reg( 3 );
  twobit_setrtn( 1955, compiled_block_1_1955 );
  twobit_invoke( 2 );
  twobit_label( 1955, compiled_block_1_1955 );
  twobit_load( 0, 0 );
  twobit_label( 1938, compiled_block_1_1938 );
  twobit_setreg( 4 );
  twobit_store( 4, 19 );
  twobit_stack( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_610( 1957, compiled_block_1_1957 ); /* internal:branchf-null? */
  twobit_global( 6 ); /* display */
  twobit_skip( 1956, compiled_block_1_1956 );
  twobit_label( 1957, compiled_block_1_1957 );
  twobit_reg_op1_check_652(reg(3),1940,compiled_block_1_1940); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1959, compiled_block_1_1959 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_stack( 3 );
  twobit_op2_84( 1 ); /* cell-set! */
  twobit_reg( 2 );
  twobit_skip( 1956, compiled_block_1_1956 );
  twobit_label( 1959, compiled_block_1_1959 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_global( 8 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_27, 12, 2 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_setrtn( 1968, compiled_block_1_1968 );
  twobit_invoke( 2 );
  twobit_label( 1968, compiled_block_1_1968 );
  twobit_load( 0, 0 );
  twobit_label( 1956, compiled_block_1_1956 );
  twobit_setreg( 4 );
  twobit_store( 4, 6 );
  twobit_stack( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_610( 1970, compiled_block_1_1970 ); /* internal:branchf-null? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1969, compiled_block_1_1969 );
  twobit_label( 1970, compiled_block_1_1970 );
  twobit_reg_op1_check_652(reg(3),1940,compiled_block_1_1940); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_reg( 2 );
  twobit_op2imm_129( TRUE_CONST ); /* eq? */
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_branchf( 1972, compiled_block_1_1972 );
  twobit_reg( 1 );
  twobit_skip( 1971, compiled_block_1_1971 );
  twobit_label( 1972, compiled_block_1_1972 );
  twobit_reg( 2 );
  twobit_op2imm_129( FALSE_CONST ); /* eq? */
  twobit_label( 1971, compiled_block_1_1971 );
  twobit_branchf( 1974, compiled_block_1_1974 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1973, compiled_block_1_1973 );
  twobit_label( 1974, compiled_block_1_1974 );
  twobit_movereg( 2, 1 );
  twobit_global( 13 ); /* output-port? */
  twobit_setrtn( 1975, compiled_block_1_1975 );
  twobit_invoke( 1 );
  twobit_label( 1975, compiled_block_1_1975 );
  twobit_load( 0, 0 );
  twobit_label( 1973, compiled_block_1_1973 );
  twobit_branchf( 1977, compiled_block_1_1977 );
  twobit_stack( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1978,compiled_block_1_1978); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_stack( 1 );
  twobit_branchf( 1980, compiled_block_1_1980 );
  twobit_global( 14 ); /* current-output-port */
  twobit_setrtn( 1981, compiled_block_1_1981 );
  twobit_invoke( 0 );
  twobit_label( 1981, compiled_block_1_1981 );
  twobit_load( 0, 0 );
  twobit_skip( 1969, compiled_block_1_1969 );
  twobit_label( 1980, compiled_block_1_1980 );
  twobit_stack( 2 );
  twobit_skip( 1969, compiled_block_1_1969 );
  twobit_label( 1977, compiled_block_1_1977 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_store( 1, 4 );
  twobit_stack( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1978,compiled_block_1_1978); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_global( 8 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_28, 16, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1998, compiled_block_1_1998 );
  twobit_invoke( 2 );
  twobit_label( 1998, compiled_block_1_1998 );
  twobit_load( 0, 0 );
  twobit_label( 1969, compiled_block_1_1969 );
  twobit_setreg( 4 );
  twobit_store( 4, 21 );
  twobit_stack( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_610( 2000, compiled_block_1_2000 ); /* internal:branchf-null? */
  twobit_imm_const( int_to_char(32) ); /* #\space */
  twobit_skip( 1999, compiled_block_1_1999 );
  twobit_label( 2000, compiled_block_1_2000 );
  twobit_reg_op1_check_652(reg(3),1940,compiled_block_1_1940); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_615( 2002, compiled_block_1_2002 ); /* internal:branchf-char? */
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_stack( 3 );
  twobit_op2_84( 1 ); /* cell-set! */
  twobit_reg( 2 );
  twobit_skip( 1999, compiled_block_1_1999 );
  twobit_label( 2002, compiled_block_1_2002 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_global( 8 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_29, 18, 2 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_setrtn( 2011, compiled_block_1_2011 );
  twobit_invoke( 2 );
  twobit_label( 2011, compiled_block_1_2011 );
  twobit_load( 0, 0 );
  twobit_label( 1999, compiled_block_1_1999 );
  twobit_setreg( 4 );
  twobit_store( 4, 20 );
  twobit_stack( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_610( 2013, compiled_block_1_2013 ); /* internal:branchf-null? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 2012, compiled_block_1_2012 );
  twobit_label( 2013, compiled_block_1_2013 );
  twobit_reg_op1_check_652(reg(3),1940,compiled_block_1_1940); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 2015, compiled_block_1_2015 );
  twobit_reg( 2 );
  twobit_op1_26(); /* inexact? */
  twobit_skip( 2014, compiled_block_1_2014 );
  twobit_label( 2015, compiled_block_1_2015 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2014, compiled_block_1_2014 );
  twobit_branchf( 2017, compiled_block_1_2017 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_stack( 3 );
  twobit_op2_84( 1 ); /* cell-set! */
  twobit_reg( 2 );
  twobit_skip( 2012, compiled_block_1_2012 );
  twobit_label( 2017, compiled_block_1_2017 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_global( 8 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_30, 20, 2 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_setrtn( 2028, compiled_block_1_2028 );
  twobit_invoke( 2 );
  twobit_label( 2028, compiled_block_1_2028 );
  twobit_load( 0, 0 );
  twobit_label( 2012, compiled_block_1_2012 );
  twobit_setreg( 4 );
  twobit_store( 4, 8 );
  twobit_stack( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_610( 2030, compiled_block_1_2030 ); /* internal:branchf-null? */
  twobit_const( 21 );
  twobit_skip( 2029, compiled_block_1_2029 );
  twobit_label( 2030, compiled_block_1_2030 );
  twobit_reg_op1_check_652(reg(3),1940,compiled_block_1_1940); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_const( 21 );
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op2_branchf_624( 1, 2032, compiled_block_1_2032 ); /* internal:branchf-eq? */
  twobit_const( 22 );
  twobit_skip( 2031, compiled_block_1_2031 );
  twobit_label( 2032, compiled_block_1_2032 );
  twobit_const( 22 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_const( 23 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_branchf_624( 4, 2034, compiled_block_1_2034 ); /* internal:branchf-eq? */
  twobit_reg( 1 );
  twobit_skip( 2031, compiled_block_1_2031 );
  twobit_label( 2034, compiled_block_1_2034 );
  twobit_reg_op1_check_652(reg(1),2035,compiled_block_1_2035); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_const( 24 );
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op2_branchf_624( 1, 2037, compiled_block_1_2037 ); /* internal:branchf-eq? */
  twobit_reg( 4 );
  twobit_skip( 2031, compiled_block_1_2031 );
  twobit_label( 2037, compiled_block_1_2037 );
  twobit_reg_op1_check_652(reg(4),1978,compiled_block_1_1978); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_const( 25 );
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op2_branchf_624( 1, 2039, compiled_block_1_2039 ); /* internal:branchf-eq? */
  twobit_reg( 4 );
  twobit_skip( 2031, compiled_block_1_2031 );
  twobit_label( 2039, compiled_block_1_2039 );
  twobit_reg_op1_check_652(reg(4),1978,compiled_block_1_1978); /* internal:check-pair? with (4 0 0) */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2031, compiled_block_1_2031 );
  twobit_branchf( 2041, compiled_block_1_2041 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 2 );
  twobit_skip( 2029, compiled_block_1_2029 );
  twobit_label( 2041, compiled_block_1_2041 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_global( 8 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_31, 27, 2 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_setrtn( 2059, compiled_block_1_2059 );
  twobit_invoke( 2 );
  twobit_label( 2059, compiled_block_1_2059 );
  twobit_load( 0, 0 );
  twobit_label( 2029, compiled_block_1_2029 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_stack( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_610( 2061, compiled_block_1_2061 ); /* internal:branchf-null? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 2060, compiled_block_1_2060 );
  twobit_label( 2061, compiled_block_1_2061 );
  twobit_reg_op1_check_652(reg(3),1940,compiled_block_1_1940); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_const( 28 );
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op2_branchf_624( 1, 2063, compiled_block_1_2063 ); /* internal:branchf-eq? */
  twobit_const( 29 );
  twobit_skip( 2062, compiled_block_1_2062 );
  twobit_label( 2063, compiled_block_1_2063 );
  twobit_const( 29 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_const( 30 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_branchf_624( 4, 2065, compiled_block_1_2065 ); /* internal:branchf-eq? */
  twobit_reg( 1 );
  twobit_skip( 2062, compiled_block_1_2062 );
  twobit_label( 2065, compiled_block_1_2065 );
  twobit_reg_op1_check_652(reg(1),2035,compiled_block_1_2035); /* internal:check-pair? with (1 0 0) */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2062, compiled_block_1_2062 );
  twobit_branchf( 2067, compiled_block_1_2067 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 2 );
  twobit_skip( 2060, compiled_block_1_2060 );
  twobit_label( 2067, compiled_block_1_2067 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_global( 8 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_32, 32, 2 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_setrtn( 2081, compiled_block_1_2081 );
  twobit_invoke( 2 );
  twobit_label( 2081, compiled_block_1_2081 );
  twobit_load( 0, 0 );
  twobit_label( 2060, compiled_block_1_2060 );
  twobit_setreg( 4 );
  twobit_store( 4, 9 );
  twobit_stack( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_610( 2083, compiled_block_1_2083 ); /* internal:branchf-null? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 2082, compiled_block_1_2082 );
  twobit_label( 2083, compiled_block_1_2083 );
  twobit_reg_op1_check_652(reg(3),1940,compiled_block_1_1940); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_const( 33 );
  twobit_op2_branchf_624( 2, 2085, compiled_block_1_2085 ); /* internal:branchf-eq? */
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_stack( 3 );
  twobit_op2_84( 1 ); /* cell-set! */
  twobit_reg( 2 );
  twobit_skip( 2082, compiled_block_1_2082 );
  twobit_label( 2085, compiled_block_1_2085 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_global( 8 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_33, 35, 2 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_setrtn( 2094, compiled_block_1_2094 );
  twobit_invoke( 2 );
  twobit_label( 2094, compiled_block_1_2094 );
  twobit_load( 0, 0 );
  twobit_label( 2082, compiled_block_1_2082 );
  twobit_setreg( 4 );
  twobit_store( 4, 16 );
  twobit_stack( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_610( 2096, compiled_block_1_2096 ); /* internal:branchf-null? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 2095, compiled_block_1_2095 );
  twobit_label( 2096, compiled_block_1_2096 );
  twobit_reg_op1_check_652(reg(3),1940,compiled_block_1_1940); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_const( 36 );
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op2_branchf_624( 1, 2098, compiled_block_1_2098 ); /* internal:branchf-eq? */
  twobit_const( 37 );
  twobit_skip( 2097, compiled_block_1_2097 );
  twobit_label( 2098, compiled_block_1_2098 );
  twobit_const( 37 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_const( 38 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_branchf_624( 4, 2100, compiled_block_1_2100 ); /* internal:branchf-eq? */
  twobit_reg( 1 );
  twobit_skip( 2097, compiled_block_1_2097 );
  twobit_label( 2100, compiled_block_1_2100 );
  twobit_reg_op1_check_652(reg(1),2035,compiled_block_1_2035); /* internal:check-pair? with (1 0 0) */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2097, compiled_block_1_2097 );
  twobit_branchf( 2102, compiled_block_1_2102 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 2 );
  twobit_skip( 2095, compiled_block_1_2095 );
  twobit_label( 2102, compiled_block_1_2102 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_global( 8 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_34, 40, 2 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_setrtn( 2116, compiled_block_1_2116 );
  twobit_invoke( 2 );
  twobit_label( 2116, compiled_block_1_2116 );
  twobit_load( 0, 0 );
  twobit_label( 2095, compiled_block_1_2095 );
  twobit_setreg( 4 );
  twobit_store( 4, 10 );
  twobit_stack( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_610( 2118, compiled_block_1_2118 ); /* internal:branchf-null? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 2117, compiled_block_1_2117 );
  twobit_label( 2118, compiled_block_1_2118 );
  twobit_reg_op1_check_652(reg(3),1940,compiled_block_1_1940); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 2120, compiled_block_1_2120 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 41 ); /*  exact-integer/string?~1ay%kV~26962 */
  twobit_setrtn( 2121, compiled_block_1_2121 );
  twobit_invoke( 1 );
  twobit_label( 2121, compiled_block_1_2121 );
  twobit_load( 0, 0 );
  twobit_branchf( 2123, compiled_block_1_2123 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_10(); /* null? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2125, compiled_block_1_2125 );
  twobit_reg( 4 );
  twobit_skip( 2119, compiled_block_1_2119 );
  twobit_label( 2125, compiled_block_1_2125 );
  twobit_load( 1, 1 );
  twobit_global( 42 ); /* list? */
  twobit_setrtn( 2126, compiled_block_1_2126 );
  twobit_invoke( 1 );
  twobit_label( 2126, compiled_block_1_2126 );
  twobit_load( 0, 0 );
  twobit_branchf( 2128, compiled_block_1_2128 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1978,compiled_block_1_1978); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2130, compiled_block_1_2130 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 41 ); /*  exact-integer/string?~1ay%kV~26962 */
  twobit_setrtn( 2131, compiled_block_1_2131 );
  twobit_invoke( 1 );
  twobit_label( 2131, compiled_block_1_2131 );
  twobit_load( 0, 0 );
  twobit_skip( 2127, compiled_block_1_2127 );
  twobit_label( 2130, compiled_block_1_2130 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 2127, compiled_block_1_2127 );
  twobit_label( 2128, compiled_block_1_2128 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2127, compiled_block_1_2127 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2133, compiled_block_1_2133 );
  twobit_reg( 4 );
  twobit_skip( 2119, compiled_block_1_2119 );
  twobit_label( 2133, compiled_block_1_2133 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_global( 41 ); /*  exact-integer/string?~1ay%kV~26962 */
  twobit_setrtn( 2134, compiled_block_1_2134 );
  twobit_invoke( 1 );
  twobit_label( 2134, compiled_block_1_2134 );
  twobit_load( 0, 0 );
  twobit_skip( 2119, compiled_block_1_2119 );
  twobit_label( 2123, compiled_block_1_2123 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 2119, compiled_block_1_2119 );
  twobit_label( 2120, compiled_block_1_2120 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2119, compiled_block_1_2119 );
  twobit_branchf( 2136, compiled_block_1_2136 );
  twobit_stack( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1978,compiled_block_1_1978); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_stack( 1 );
  twobit_skip( 2117, compiled_block_1_2117 );
  twobit_label( 2136, compiled_block_1_2136 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_stack( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1978,compiled_block_1_1978); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_global( 8 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_35, 44, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 2162, compiled_block_1_2162 );
  twobit_invoke( 2 );
  twobit_label( 2162, compiled_block_1_2162 );
  twobit_load( 0, 0 );
  twobit_label( 2117, compiled_block_1_2117 );
  twobit_setreg( 4 );
  twobit_store( 4, 18 );
  twobit_stack( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_610( 2164, compiled_block_1_2164 ); /* internal:branchf-null? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 2163, compiled_block_1_2163 );
  twobit_label( 2164, compiled_block_1_2164 );
  twobit_reg_op1_check_652(reg(3),1940,compiled_block_1_1940); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 2166, compiled_block_1_2166 ); /* internal:branchf-pair? */
  twobit_global( 45 ); /* procedure? */
  twobit_setreg( 1 );
  twobit_global( 46 ); /*  every?~1ay%kV~26959 */
  twobit_setrtn( 2167, compiled_block_1_2167 );
  twobit_invoke( 2 );
  twobit_label( 2167, compiled_block_1_2167 );
  twobit_load( 0, 0 );
  twobit_skip( 2165, compiled_block_1_2165 );
  twobit_label( 2166, compiled_block_1_2166 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2165, compiled_block_1_2165 );
  twobit_branchf( 2169, compiled_block_1_2169 );
  twobit_stack( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1978,compiled_block_1_1978); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_stack( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_stack( 1 );
  twobit_skip( 2163, compiled_block_1_2163 );
  twobit_label( 2169, compiled_block_1_2169 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_stack( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1978,compiled_block_1_1978); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_global( 8 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_36, 48, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 2181, compiled_block_1_2181 );
  twobit_invoke( 2 );
  twobit_label( 2181, compiled_block_1_2181 );
  twobit_load( 0, 0 );
  twobit_label( 2163, compiled_block_1_2163 );
  twobit_setreg( 4 );
  twobit_store( 4, 17 );
  twobit_stack( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_610( 2183, compiled_block_1_2183 ); /* internal:branchf-null? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 2182, compiled_block_1_2182 );
  twobit_label( 2183, compiled_block_1_2183 );
  twobit_reg_op1_check_652(reg(3),2184,compiled_block_1_2184); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 2186, compiled_block_1_2186 ); /* internal:branchf-null? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 2188, compiled_block_1_2188 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_op1_branchf_615( 2190, compiled_block_1_2190 ); /* internal:branchf-char? */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_10(); /* null? */
  twobit_setreg( 1 );
  twobit_reg( 1 );
  twobit_branchf( 2192, compiled_block_1_2192 );
  twobit_reg( 1 );
  twobit_skip( 2187, compiled_block_1_2187 );
  twobit_label( 2192, compiled_block_1_2192 );
  twobit_movereg( 2, 1 );
  twobit_global( 42 ); /* list? */
  twobit_setrtn( 2193, compiled_block_1_2193 );
  twobit_invoke( 1 );
  twobit_label( 2193, compiled_block_1_2193 );
  twobit_load( 0, 0 );
  twobit_branchf( 2195, compiled_block_1_2195 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1978,compiled_block_1_1978); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2197, compiled_block_1_2197 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 49 ); /*  exact-integer?~1ay%kV~26961 */
  twobit_setrtn( 2198, compiled_block_1_2198 );
  twobit_invoke( 1 );
  twobit_label( 2198, compiled_block_1_2198 );
  twobit_load( 0, 0 );
  twobit_skip( 2187, compiled_block_1_2187 );
  twobit_label( 2197, compiled_block_1_2197 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 2187, compiled_block_1_2187 );
  twobit_label( 2195, compiled_block_1_2195 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 2187, compiled_block_1_2187 );
  twobit_label( 2190, compiled_block_1_2190 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 2187, compiled_block_1_2187 );
  twobit_label( 2188, compiled_block_1_2188 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2187, compiled_block_1_2187 );
  twobit_branchf( 2200, compiled_block_1_2200 );
  twobit_stack( 1 );
  twobit_skip( 2182, compiled_block_1_2182 );
  twobit_label( 2200, compiled_block_1_2200 );
  twobit_stack( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_const( 50 );
  twobit_setreg( 1 );
  twobit_global( 51 ); /*  error~1ay%kV~11404 */
  twobit_setrtn( 2201, compiled_block_1_2201 );
  twobit_invoke( 2 );
  twobit_label( 2201, compiled_block_1_2201 );
  twobit_load( 0, 0 );
  twobit_skip( 2182, compiled_block_1_2182 );
  twobit_label( 2186, compiled_block_1_2186 );
  twobit_const( 52 );
  twobit_setreg( 1 );
  twobit_global( 53 ); /*  error~1ay%kV~11404 */
  twobit_setrtn( 2202, compiled_block_1_2202 );
  twobit_invoke( 2 );
  twobit_label( 2202, compiled_block_1_2202 );
  twobit_load( 0, 0 );
  twobit_label( 2182, compiled_block_1_2182 );
  twobit_setreg( 4 );
  twobit_store( 4, 11 );
  twobit_stack( 5 );
  twobit_op1_18(); /* complex? */
  twobit_branchf( 2204, compiled_block_1_2204 );
  twobit_global( 6 ); /* display */
  twobit_setreg( 3 );
  twobit_stack( 6 );
  twobit_op2_branchf_624( 3, 2206, compiled_block_1_2206 ); /* internal:branchf-eq? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2205, compiled_block_1_2205 );
  twobit_label( 2206, compiled_block_1_2206 );
  twobit_global( 54 ); /* write */
  twobit_setreg( 3 );
  twobit_stack( 6 );
  twobit_op2_56( 3 ); /* eq? */
  twobit_label( 2205, compiled_block_1_2205 );
  twobit_branchf( 2208, compiled_block_1_2208 );
  twobit_const( 21 );
  twobit_setreg( 3 );
  twobit_stack( 7 );
  twobit_op2_branchf_624( 3, 2210, compiled_block_1_2210 ); /* internal:branchf-eq? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 2209, compiled_block_1_2209 );
  twobit_label( 2210, compiled_block_1_2210 );
  twobit_stack( 8 );
  twobit_branchf( 2212, compiled_block_1_2212 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2211, compiled_block_1_2211 );
  twobit_label( 2212, compiled_block_1_2212 );
  twobit_stack( 9 );
  twobit_label( 2211, compiled_block_1_2211 );
  twobit_branchf( 2214, compiled_block_1_2214 );
  twobit_const( 55 );
  twobit_setreg( 1 );
  twobit_global( 56 ); /*  error~1ay%kV~11404 */
  twobit_setrtn( 2215, compiled_block_1_2215 );
  twobit_invoke( 1 );
  twobit_label( 2215, compiled_block_1_2215 );
  twobit_load( 0, 0 );
  twobit_skip( 2213, compiled_block_1_2213 );
  twobit_label( 2214, compiled_block_1_2214 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2213, compiled_block_1_2213 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2217, compiled_block_1_2217 );
  twobit_reg( 4 );
  twobit_skip( 2216, compiled_block_1_2216 );
  twobit_label( 2217, compiled_block_1_2217 );
  twobit_stack( 5 );
  twobit_op1_26(); /* inexact? */
  twobit_branchf( 2219, compiled_block_1_2219 );
  twobit_const( 36 );
  twobit_setreg( 4 );
  twobit_stack( 10 );
  twobit_op2_56( 4 ); /* eq? */
  twobit_op1_9(); /* not */
  twobit_skip( 2218, compiled_block_1_2218 );
  twobit_label( 2219, compiled_block_1_2219 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2218, compiled_block_1_2218 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2221, compiled_block_1_2221 );
  twobit_reg( 4 );
  twobit_skip( 2216, compiled_block_1_2216 );
  twobit_label( 2221, compiled_block_1_2221 );
  twobit_const( 38 );
  twobit_setreg( 3 );
  twobit_stack( 10 );
  twobit_op2_56( 3 ); /* eq? */
  twobit_label( 2216, compiled_block_1_2216 );
  twobit_branchf( 2223, compiled_block_1_2223 );
  twobit_const( 57 );
  twobit_skip( 2209, compiled_block_1_2209 );
  twobit_label( 2223, compiled_block_1_2223 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2209, compiled_block_1_2209 );
  twobit_setreg( 4 );
  twobit_store( 4, 15 );
  twobit_stack( 9 );
  twobit_branchf( 2225, compiled_block_1_2225 );
  twobit_const( 28 );
  twobit_setreg( 3 );
  twobit_stack( 9 );
  twobit_op2_56( 3 ); /* eq? */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_branchf( 2227, compiled_block_1_2227 );
  twobit_stack( 8 );
  twobit_branchf( 2229, compiled_block_1_2229 );
  twobit_stack( 8 );
  twobit_op2imm_branchf_635( fixnum(0), 37, compiled_temp_1_37, 2231, compiled_block_1_2231 ); /* internal:branchf-</imm */
  twobit_stack( 8 );
  twobit_op1_32( 38, compiled_temp_1_38 ); /* -- */
  twobit_skip( 2230, compiled_block_1_2230 );
  twobit_label( 2231, compiled_block_1_2231 );
  twobit_stack( 8 );
  twobit_label( 2230, compiled_block_1_2230 );
  twobit_op1_28( 39, compiled_temp_1_39 ); /* inexact->exact */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_stack( 5 );
  twobit_op1_20(); /* rational? */
  twobit_branchf( 2233, compiled_block_1_2233 );
  twobit_load( 1, 5 );
  twobit_global( 58 ); /*  real->fixnum-string~1ay%kV~26968 */
  twobit_setrtn( 2234, compiled_block_1_2234 );
  twobit_invoke( 1 );
  twobit_label( 2234, compiled_block_1_2234 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_global( 59 ); /*  mold~1ay%kV~26963 */
  twobit_setrtn( 2235, compiled_block_1_2235 );
  twobit_invoke( 2 );
  twobit_label( 2235, compiled_block_1_2235 );
  twobit_load( 0, 0 );
  twobit_skip( 2224, compiled_block_1_2224 );
  twobit_label( 2233, compiled_block_1_2233 );
  twobit_stack( 5 );
  twobit_op1_35(); /* imag-part */
  twobit_setreg( 1 );
  twobit_global( 60 ); /*  real->fixnum-string~1ay%kV~26968 */
  twobit_setrtn( 2236, compiled_block_1_2236 );
  twobit_invoke( 1 );
  twobit_label( 2236, compiled_block_1_2236 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_stack( 5 );
  twobit_op1_34(); /* real-part */
  twobit_setreg( 1 );
  twobit_global( 61 ); /*  real->fixnum-string~1ay%kV~26968 */
  twobit_setrtn( 2237, compiled_block_1_2237 );
  twobit_invoke( 1 );
  twobit_label( 2237, compiled_block_1_2237 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_global( 62 ); /*  mold~1ay%kV~26963 */
  twobit_setrtn( 2238, compiled_block_1_2238 );
  twobit_invoke( 2 );
  twobit_label( 2238, compiled_block_1_2238 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_stack( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_load( 2, 1 );
  twobit_check( 0, 2, 0, 2239, compiled_block_1_2239 );
  twobit_stack( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(3),2239,compiled_block_1_2239); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_802( 3 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_global( 63 ); /* char-numeric? */
  twobit_setrtn( 2240, compiled_block_1_2240 );
  twobit_invoke( 1 );
  twobit_label( 2240, compiled_block_1_2240 );
  twobit_load( 0, 0 );
  twobit_branchf( 2242, compiled_block_1_2242 );
  twobit_const( 64 );
  twobit_skip( 2241, compiled_block_1_2241 );
  twobit_label( 2242, compiled_block_1_2242 );
  twobit_const( 65 );
  twobit_label( 2241, compiled_block_1_2241 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_load( 2, 3 );
  twobit_global( 66 ); /*  mold~1ay%kV~26963 */
  twobit_setrtn( 2243, compiled_block_1_2243 );
  twobit_invoke( 2 );
  twobit_label( 2243, compiled_block_1_2243 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_load( 1, 4 );
  twobit_const( 67 );
  twobit_setreg( 4 );
  twobit_global( 68 ); /* string-append */
  twobit_setrtn( 2244, compiled_block_1_2244 );
  twobit_invoke( 4 );
  twobit_label( 2244, compiled_block_1_2244 );
  twobit_load( 0, 0 );
  twobit_skip( 2224, compiled_block_1_2224 );
  twobit_label( 2229, compiled_block_1_2229 );
  twobit_stack( 5 );
  twobit_op1_20(); /* rational? */
  twobit_branchf( 2246, compiled_block_1_2246 );
  twobit_load( 1, 5 );
  twobit_global( 69 ); /*  real->fixnum-string~1ay%kV~26968 */
  twobit_setrtn( 2247, compiled_block_1_2247 );
  twobit_invoke( 1 );
  twobit_label( 2247, compiled_block_1_2247 );
  twobit_load( 0, 0 );
  twobit_skip( 2224, compiled_block_1_2224 );
  twobit_label( 2246, compiled_block_1_2246 );
  twobit_stack( 5 );
  twobit_op1_35(); /* imag-part */
  twobit_setreg( 1 );
  twobit_global( 70 ); /*  real->fixnum-string~1ay%kV~26968 */
  twobit_setrtn( 2248, compiled_block_1_2248 );
  twobit_invoke( 1 );
  twobit_label( 2248, compiled_block_1_2248 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_stack( 5 );
  twobit_op1_34(); /* real-part */
  twobit_setreg( 1 );
  twobit_global( 71 ); /*  real->fixnum-string~1ay%kV~26968 */
  twobit_setrtn( 2249, compiled_block_1_2249 );
  twobit_invoke( 1 );
  twobit_label( 2249, compiled_block_1_2249 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_load( 2, 1 );
  twobit_check( 0, 2, 0, 2239, compiled_block_1_2239 );
  twobit_stack( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(3),2239,compiled_block_1_2239); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_802( 3 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_global( 72 ); /* char-numeric? */
  twobit_setrtn( 2250, compiled_block_1_2250 );
  twobit_invoke( 1 );
  twobit_label( 2250, compiled_block_1_2250 );
  twobit_load( 0, 0 );
  twobit_branchf( 2252, compiled_block_1_2252 );
  twobit_const( 73 );
  twobit_skip( 2251, compiled_block_1_2251 );
  twobit_label( 2252, compiled_block_1_2252 );
  twobit_const( 74 );
  twobit_label( 2251, compiled_block_1_2251 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_load( 3, 1 );
  twobit_const( 75 );
  twobit_setreg( 4 );
  twobit_global( 76 ); /* string-append */
  twobit_setrtn( 2253, compiled_block_1_2253 );
  twobit_invoke( 4 );
  twobit_label( 2253, compiled_block_1_2253 );
  twobit_load( 0, 0 );
  twobit_skip( 2224, compiled_block_1_2224 );
  twobit_label( 2227, compiled_block_1_2227 );
  twobit_stack( 8 );
  twobit_branchf( 2255, compiled_block_1_2255 );
  twobit_stack( 8 );
  twobit_op2imm_branchf_635( fixnum(0), 40, compiled_temp_1_40, 2257, compiled_block_1_2257 ); /* internal:branchf-</imm */
  twobit_stack( 8 );
  twobit_op1_32( 41, compiled_temp_1_41 ); /* -- */
  twobit_skip( 2256, compiled_block_1_2256 );
  twobit_label( 2257, compiled_block_1_2257 );
  twobit_stack( 8 );
  twobit_label( 2256, compiled_block_1_2256 );
  twobit_op1_28( 42, compiled_temp_1_42 ); /* inexact->exact */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_stack( 5 );
  twobit_op1_20(); /* rational? */
  twobit_branchf( 2259, compiled_block_1_2259 );
  twobit_load( 1, 5 );
  twobit_global( 77 ); /*  real->flonum-string~1ay%kV~26972 */
  twobit_setrtn( 2260, compiled_block_1_2260 );
  twobit_invoke( 1 );
  twobit_label( 2260, compiled_block_1_2260 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 78 ); /*  flonum-mold~1ay%kV~26966 */
  twobit_setrtn( 2261, compiled_block_1_2261 );
  twobit_invoke( 2 );
  twobit_label( 2261, compiled_block_1_2261 );
  twobit_load( 0, 0 );
  twobit_skip( 2224, compiled_block_1_2224 );
  twobit_label( 2259, compiled_block_1_2259 );
  twobit_stack( 5 );
  twobit_op1_35(); /* imag-part */
  twobit_setreg( 1 );
  twobit_global( 79 ); /*  real->flonum-string~1ay%kV~26972 */
  twobit_setrtn( 2262, compiled_block_1_2262 );
  twobit_invoke( 1 );
  twobit_label( 2262, compiled_block_1_2262 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 5 );
  twobit_op1_34(); /* real-part */
  twobit_setreg( 1 );
  twobit_global( 80 ); /*  real->flonum-string~1ay%kV~26972 */
  twobit_setrtn( 2263, compiled_block_1_2263 );
  twobit_invoke( 1 );
  twobit_label( 2263, compiled_block_1_2263 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 81 ); /*  flonum-mold~1ay%kV~26966 */
  twobit_setrtn( 2264, compiled_block_1_2264 );
  twobit_invoke( 2 );
  twobit_label( 2264, compiled_block_1_2264 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_stack( 2 );
  twobit_op1_800(); /* ustring? */
  twobit_load( 2, 2 );
  twobit_check( 0, 2, 0, 2239, compiled_block_1_2239 );
  twobit_stack( 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(3),2239,compiled_block_1_2239); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_802( 3 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_global( 82 ); /* char-numeric? */
  twobit_setrtn( 2265, compiled_block_1_2265 );
  twobit_invoke( 1 );
  twobit_label( 2265, compiled_block_1_2265 );
  twobit_load( 0, 0 );
  twobit_branchf( 2267, compiled_block_1_2267 );
  twobit_const( 83 );
  twobit_skip( 2266, compiled_block_1_2266 );
  twobit_label( 2267, compiled_block_1_2267 );
  twobit_const( 84 );
  twobit_label( 2266, compiled_block_1_2266 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 2 );
  twobit_load( 2, 1 );
  twobit_global( 85 ); /*  flonum-mold~1ay%kV~26966 */
  twobit_setrtn( 2268, compiled_block_1_2268 );
  twobit_invoke( 2 );
  twobit_label( 2268, compiled_block_1_2268 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 3 );
  twobit_load( 1, 4 );
  twobit_const( 86 );
  twobit_setreg( 4 );
  twobit_global( 87 ); /* string-append */
  twobit_setrtn( 2269, compiled_block_1_2269 );
  twobit_invoke( 4 );
  twobit_label( 2269, compiled_block_1_2269 );
  twobit_load( 0, 0 );
  twobit_skip( 2224, compiled_block_1_2224 );
  twobit_label( 2255, compiled_block_1_2255 );
  twobit_stack( 5 );
  twobit_op1_20(); /* rational? */
  twobit_branchf( 2271, compiled_block_1_2271 );
  twobit_load( 1, 5 );
  twobit_global( 88 ); /*  real->flonum-string~1ay%kV~26972 */
  twobit_setrtn( 2272, compiled_block_1_2272 );
  twobit_invoke( 1 );
  twobit_label( 2272, compiled_block_1_2272 );
  twobit_load( 0, 0 );
  twobit_skip( 2224, compiled_block_1_2224 );
  twobit_label( 2271, compiled_block_1_2271 );
  twobit_stack( 5 );
  twobit_op1_35(); /* imag-part */
  twobit_setreg( 1 );
  twobit_global( 89 ); /*  real->flonum-string~1ay%kV~26972 */
  twobit_setrtn( 2273, compiled_block_1_2273 );
  twobit_invoke( 1 );
  twobit_label( 2273, compiled_block_1_2273 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_stack( 5 );
  twobit_op1_34(); /* real-part */
  twobit_setreg( 1 );
  twobit_global( 90 ); /*  real->flonum-string~1ay%kV~26972 */
  twobit_setrtn( 2274, compiled_block_1_2274 );
  twobit_invoke( 1 );
  twobit_label( 2274, compiled_block_1_2274 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 1 );
  twobit_op1_800(); /* ustring? */
  twobit_load( 2, 1 );
  twobit_check( 0, 2, 0, 2239, compiled_block_1_2239 );
  twobit_stack( 1 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(3),2239,compiled_block_1_2239); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_802( 3 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_global( 91 ); /* char-numeric? */
  twobit_setrtn( 2275, compiled_block_1_2275 );
  twobit_invoke( 1 );
  twobit_label( 2275, compiled_block_1_2275 );
  twobit_load( 0, 0 );
  twobit_branchf( 2277, compiled_block_1_2277 );
  twobit_const( 92 );
  twobit_skip( 2276, compiled_block_1_2276 );
  twobit_label( 2277, compiled_block_1_2277 );
  twobit_const( 93 );
  twobit_label( 2276, compiled_block_1_2276 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_load( 3, 1 );
  twobit_const( 94 );
  twobit_setreg( 4 );
  twobit_global( 95 ); /* string-append */
  twobit_setrtn( 2278, compiled_block_1_2278 );
  twobit_invoke( 4 );
  twobit_label( 2278, compiled_block_1_2278 );
  twobit_load( 0, 0 );
  twobit_skip( 2224, compiled_block_1_2224 );
  twobit_label( 2225, compiled_block_1_2225 );
  twobit_stack( 8 );
  twobit_branchf( 2280, compiled_block_1_2280 );
  twobit_stack( 8 );
  twobit_op2imm_branchf_635( fixnum(0), 43, compiled_temp_1_43, 2282, compiled_block_1_2282 ); /* internal:branchf-</imm */
  twobit_stack( 8 );
  twobit_op1_32( 44, compiled_temp_1_44 ); /* -- */
  twobit_skip( 2281, compiled_block_1_2281 );
  twobit_label( 2282, compiled_block_1_2282 );
  twobit_stack( 8 );
  twobit_label( 2281, compiled_block_1_2281 );
  twobit_op1_28( 45, compiled_temp_1_45 ); /* inexact->exact */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_stack( 5 );
  twobit_op1_20(); /* rational? */
  twobit_branchf( 2284, compiled_block_1_2284 );
  twobit_stack( 5 );
  twobit_op1_27( 46, compiled_temp_1_46 ); /* exact->inexact */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* number->string */
  twobit_setrtn( 2285, compiled_block_1_2285 );
  twobit_invoke( 1 );
  twobit_label( 2285, compiled_block_1_2285 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 96 ); /*  e-mold~1ay%kV~26965 */
  twobit_setrtn( 2286, compiled_block_1_2286 );
  twobit_invoke( 2 );
  twobit_label( 2286, compiled_block_1_2286 );
  twobit_load( 0, 0 );
  twobit_skip( 2224, compiled_block_1_2224 );
  twobit_label( 2284, compiled_block_1_2284 );
  twobit_stack( 5 );
  twobit_op1_35(); /* imag-part */
  twobit_op1_27( 47, compiled_temp_1_47 ); /* exact->inexact */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* number->string */
  twobit_setrtn( 2287, compiled_block_1_2287 );
  twobit_invoke( 1 );
  twobit_label( 2287, compiled_block_1_2287 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 5 );
  twobit_op1_34(); /* real-part */
  twobit_op1_27( 48, compiled_temp_1_48 ); /* exact->inexact */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* number->string */
  twobit_setrtn( 2288, compiled_block_1_2288 );
  twobit_invoke( 1 );
  twobit_label( 2288, compiled_block_1_2288 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 97 ); /*  e-mold~1ay%kV~26965 */
  twobit_setrtn( 2289, compiled_block_1_2289 );
  twobit_invoke( 2 );
  twobit_label( 2289, compiled_block_1_2289 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_stack( 2 );
  twobit_op1_800(); /* ustring? */
  twobit_load( 2, 2 );
  twobit_check( 0, 2, 0, 2239, compiled_block_1_2239 );
  twobit_stack( 2 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(3),2239,compiled_block_1_2239); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_stack( 2 );
  twobit_op2_802( 3 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_global( 98 ); /* char-numeric? */
  twobit_setrtn( 2290, compiled_block_1_2290 );
  twobit_invoke( 1 );
  twobit_label( 2290, compiled_block_1_2290 );
  twobit_load( 0, 0 );
  twobit_branchf( 2292, compiled_block_1_2292 );
  twobit_const( 99 );
  twobit_skip( 2291, compiled_block_1_2291 );
  twobit_label( 2292, compiled_block_1_2292 );
  twobit_const( 100 );
  twobit_label( 2291, compiled_block_1_2291 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 2 );
  twobit_load( 2, 1 );
  twobit_global( 101 ); /*  e-mold~1ay%kV~26965 */
  twobit_setrtn( 2293, compiled_block_1_2293 );
  twobit_invoke( 2 );
  twobit_label( 2293, compiled_block_1_2293 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 3 );
  twobit_load( 1, 4 );
  twobit_const( 102 );
  twobit_setreg( 4 );
  twobit_global( 103 ); /* string-append */
  twobit_setrtn( 2294, compiled_block_1_2294 );
  twobit_invoke( 4 );
  twobit_label( 2294, compiled_block_1_2294 );
  twobit_load( 0, 0 );
  twobit_skip( 2224, compiled_block_1_2224 );
  twobit_label( 2280, compiled_block_1_2280 );
  twobit_reg( 4 );
  twobit_branchf( 2296, compiled_block_1_2296 );
  twobit_stack( 5 );
  twobit_op1_28( 49, compiled_temp_1_49 ); /* inexact->exact */
  twobit_skip( 2295, compiled_block_1_2295 );
  twobit_label( 2296, compiled_block_1_2296 );
  twobit_stack( 10 );
  twobit_branchf( 2298, compiled_block_1_2298 );
  twobit_const( 36 );
  twobit_setreg( 3 );
  twobit_stack( 10 );
  twobit_op2_branchf_624( 3, 2300, compiled_block_1_2300 ); /* internal:branchf-eq? */
  twobit_stack( 5 );
  twobit_op1_28( 50, compiled_temp_1_50 ); /* inexact->exact */
  twobit_skip( 2295, compiled_block_1_2295 );
  twobit_label( 2300, compiled_block_1_2300 );
  twobit_stack( 5 );
  twobit_op1_27( 51, compiled_temp_1_51 ); /* exact->inexact */
  twobit_skip( 2295, compiled_block_1_2295 );
  twobit_label( 2298, compiled_block_1_2298 );
  twobit_stack( 5 );
  twobit_label( 2295, compiled_block_1_2295 );
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_load( 1, 7 );
  twobit_const( 104 );
  twobit_setreg( 2 );
  twobit_global( 105 ); /* assq */
  twobit_setrtn( 2301, compiled_block_1_2301 );
  twobit_invoke( 2 );
  twobit_label( 2301, compiled_block_1_2301 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg_op1_check_652(reg(4),1978,compiled_block_1_1978); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* number->string */
  twobit_setrtn( 2302, compiled_block_1_2302 );
  twobit_invoke( 2 );
  twobit_label( 2302, compiled_block_1_2302 );
  twobit_load( 0, 0 );
  twobit_label( 2224, compiled_block_1_2224 );
  twobit_setreg( 4 );
  twobit_store( 4, 14 );
  twobit_stack( 11 );
  twobit_branchf( 2304, compiled_block_1_2304 );
  twobit_stack( 11 );
  twobit_op1_11(); /* pair? */
  twobit_load( 2, 11 );
  twobit_check( 2, 0, 0, 2305, compiled_block_1_2305 );
  twobit_stack( 11 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_610( 2307, compiled_block_1_2307 ); /* internal:branchf-null? */
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_skip( 2306, compiled_block_1_2306 );
  twobit_label( 2307, compiled_block_1_2307 );
  twobit_reg_op1_check_652(reg(3),1940,compiled_block_1_1940); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op2imm_branchf_635( fixnum(0), 52, compiled_temp_1_52, 2309, compiled_block_1_2309 ); /* internal:branchf-</imm */
  twobit_reg( 2 );
  twobit_op1_32( 53, compiled_temp_1_53 ); /* -- */
  twobit_skip( 2306, compiled_block_1_2306 );
  twobit_label( 2309, compiled_block_1_2309 );
  twobit_reg( 2 );
  twobit_label( 2306, compiled_block_1_2306 );
  twobit_setreg( 2 );
  twobit_store( 2, 13 );
  twobit_stack( 5 );
  twobit_op1_34(); /* real-part */
  twobit_op2imm_132( fixnum(0), 54, compiled_temp_1_54 ); /* < */
  twobit_setreg( 3 );
  twobit_store( 3, 12 );
  twobit_stack( 11 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* string */
  twobit_setrtn( 2310, compiled_block_1_2310 );
  twobit_invoke( 1 );
  twobit_label( 2310, compiled_block_1_2310 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 4, 12 );
  twobit_load( 3, 13 );
  twobit_load( 1, 14 );
  twobit_global( 106 ); /*  fixnum-string-separate~1ay%kV~26957 */
  twobit_setrtn( 2311, compiled_block_1_2311 );
  twobit_invoke( 4 );
  twobit_label( 2311, compiled_block_1_2311 );
  twobit_load( 0, 0 );
  twobit_skip( 2303, compiled_block_1_2303 );
  twobit_label( 2304, compiled_block_1_2304 );
  twobit_reg( 4 );
  twobit_label( 2303, compiled_block_1_2303 );
  twobit_setreg( 4 );
  twobit_store( 4, 14 );
  twobit_stack( 15 );
  twobit_branchf( 2313, compiled_block_1_2313 );
  twobit_stack( 15 );
  twobit_skip( 2312, compiled_block_1_2312 );
  twobit_label( 2313, compiled_block_1_2313 );
  twobit_const( 107 );
  twobit_label( 2312, compiled_block_1_2312 );
  twobit_setreg( 3 );
  twobit_store( 3, 12 );
  twobit_stack( 8 );
  twobit_branchf( 2315, compiled_block_1_2315 );
  twobit_stack( 9 );
  twobit_branchf( 2317, compiled_block_1_2317 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 2314, compiled_block_1_2314 );
  twobit_label( 2317, compiled_block_1_2317 );
  twobit_const( 36 );
  twobit_setreg( 2 );
  twobit_stack( 10 );
  twobit_op2_56( 2 ); /* eq? */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_branchf( 2319, compiled_block_1_2319 );
  twobit_reg( 2 );
  twobit_skip( 2314, compiled_block_1_2314 );
  twobit_label( 2319, compiled_block_1_2319 );
  twobit_stack( 5 );
  twobit_op1_25(); /* exact? */
  twobit_branchf( 2321, compiled_block_1_2321 );
  twobit_stack( 10 );
  twobit_branchf( 2323, compiled_block_1_2323 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 2314, compiled_block_1_2314 );
  twobit_label( 2323, compiled_block_1_2323 );
  twobit_stack( 8 );
  twobit_op2imm_135( fixnum(0), 55, compiled_temp_1_55 ); /* > */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_branchf( 2325, compiled_block_1_2325 );
  twobit_reg( 2 );
  twobit_skip( 2314, compiled_block_1_2314 );
  twobit_label( 2325, compiled_block_1_2325 );
  twobit_const( 108 );
  twobit_setreg( 1 );
  twobit_stack( 8 );
  twobit_op2_57( 1, 56, compiled_temp_1_56 ); /* eqv? */
  twobit_skip( 2314, compiled_block_1_2314 );
  twobit_label( 2321, compiled_block_1_2321 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 2314, compiled_block_1_2314 );
  twobit_label( 2315, compiled_block_1_2315 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2314, compiled_block_1_2314 );
  twobit_branchf( 2327, compiled_block_1_2327 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2326, compiled_block_1_2326 );
  twobit_label( 2327, compiled_block_1_2327 );
  twobit_stack( 9 );
  twobit_branchf( 2329, compiled_block_1_2329 );
  twobit_const( 36 );
  twobit_setreg( 2 );
  twobit_stack( 10 );
  twobit_op2_56( 2 ); /* eq? */
  twobit_skip( 2326, compiled_block_1_2326 );
  twobit_label( 2329, compiled_block_1_2329 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2326, compiled_block_1_2326 );
  twobit_branchf( 2331, compiled_block_1_2331 );
  twobit_const( 109 );
  twobit_skip( 2330, compiled_block_1_2330 );
  twobit_label( 2331, compiled_block_1_2331 );
  twobit_const( 110 );
  twobit_label( 2330, compiled_block_1_2330 );
  twobit_setreg( 2 );
  twobit_store( 2, 13 );
  twobit_load( 1, 7 );
  twobit_const( 111 );
  twobit_setreg( 2 );
  twobit_global( 112 ); /* assq */
  twobit_setrtn( 2332, compiled_block_1_2332 );
  twobit_invoke( 2 );
  twobit_label( 2332, compiled_block_1_2332 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1978,compiled_block_1_1978); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 15 );
  twobit_stack( 16 );
  twobit_branchf( 2334, compiled_block_1_2334 );
  twobit_stack( 14 );
  twobit_op1_800(); /* ustring? */
  twobit_load( 2, 14 );
  twobit_check( 0, 2, 0, 2239, compiled_block_1_2239 );
  twobit_stack( 14 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_reg_op2_check_655(RESULT,reg(3),2239,compiled_block_1_2239); /* internal:check-<:fix:fix with (0 2 0) */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_stack( 14 );
  twobit_op2_802( 3 ); /* ustring-ref:trusted */
  twobit_setreg( 1 );
  twobit_global( 113 ); /* char-numeric? */
  twobit_setrtn( 2335, compiled_block_1_2335 );
  twobit_invoke( 1 );
  twobit_label( 2335, compiled_block_1_2335 );
  twobit_load( 0, 0 );
  twobit_skip( 2333, compiled_block_1_2333 );
  twobit_label( 2334, compiled_block_1_2334 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2333, compiled_block_1_2333 );
  twobit_branchf( 2337, compiled_block_1_2337 );
  twobit_const( 114 );
  twobit_skip( 2336, compiled_block_1_2336 );
  twobit_label( 2337, compiled_block_1_2337 );
  twobit_const( 115 );
  twobit_label( 2336, compiled_block_1_2336 );
  twobit_setreg( 4 );
  twobit_load( 3, 15 );
  twobit_load( 2, 13 );
  twobit_load( 1, 12 );
  twobit_load( 5, 14 );
  twobit_global( 116 ); /* string-append */
  twobit_setrtn( 2338, compiled_block_1_2338 );
  twobit_invoke( 5 );
  twobit_label( 2338, compiled_block_1_2338 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 14 );
  twobit_stack( 17 );
  twobit_branchf( 2340, compiled_block_1_2340 );
  twobit_load( 1, 17 );
  twobit_global( 42 ); /* list? */
  twobit_setrtn( 2341, compiled_block_1_2341 );
  twobit_invoke( 1 );
  twobit_label( 2341, compiled_block_1_2341 );
  twobit_load( 0, 0 );
  twobit_branchf( 2343, compiled_block_1_2343 );
  twobit_load( 1, 14 );
  twobit_stack( 17 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 17 );
  twobit_check( 3, 0, 0, 2184, compiled_block_1_2184 );
  twobit_stack( 17 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 14 );
  twobit_stack( 17 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 2344, compiled_block_1_2344 );
  twobit_invoke( 1 );
  twobit_label( 2344, compiled_block_1_2344 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_store( 1, 12 );
  twobit_load( 2, 14 );
  twobit_global( 8 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_57, 118, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 12 );
  twobit_reg( 4 );
  twobit_setrtn( 2350, compiled_block_1_2350 );
  twobit_invoke( 2 );
  twobit_label( 2350, compiled_block_1_2350 );
  twobit_load( 0, 0 );
  twobit_skip( 2339, compiled_block_1_2339 );
  twobit_label( 2343, compiled_block_1_2343 );
  twobit_global( 8 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 14 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_58, 120, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 17 );
  twobit_reg( 4 );
  twobit_setrtn( 2357, compiled_block_1_2357 );
  twobit_invoke( 1 );
  twobit_label( 2357, compiled_block_1_2357 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 121 ); /* string-append */
  twobit_setreg( 1 );
  twobit_global( 122 ); /* apply */
  twobit_setrtn( 2358, compiled_block_1_2358 );
  twobit_invoke( 2 );
  twobit_label( 2358, compiled_block_1_2358 );
  twobit_load( 0, 0 );
  twobit_skip( 2339, compiled_block_1_2339 );
  twobit_label( 2340, compiled_block_1_2340 );
  twobit_reg( 4 );
  twobit_label( 2339, compiled_block_1_2339 );
  twobit_setreg( 4 );
  twobit_stack( 18 );
  twobit_branchf( 2360, compiled_block_1_2360 );
  twobit_movereg( 4, 1 );
  twobit_load( 2, 18 );
  twobit_global( 123 ); /*  take-both-end~1ay%kV~26953 */
  twobit_setrtn( 2361, compiled_block_1_2361 );
  twobit_invoke( 2 );
  twobit_label( 2361, compiled_block_1_2361 );
  twobit_load( 0, 0 );
  twobit_skip( 2359, compiled_block_1_2359 );
  twobit_label( 2360, compiled_block_1_2360 );
  twobit_reg( 4 );
  twobit_label( 2359, compiled_block_1_2359 );
  twobit_setreg( 4 );
  twobit_store( 4, 14 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 4, 0, 0, 2362, compiled_block_1_2362 );
  twobit_reg( 4 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_store( 3, 12 );
  twobit_stack( 19 );
  twobit_op2imm_branchf_635( fixnum(0), 59, compiled_temp_1_59, 2364, compiled_block_1_2364 ); /* internal:branchf-</imm */
  twobit_stack( 19 );
  twobit_op1_32( 60, compiled_temp_1_60 ); /* -- */
  twobit_skip( 2363, compiled_block_1_2363 );
  twobit_label( 2364, compiled_block_1_2364 );
  twobit_stack( 19 );
  twobit_label( 2363, compiled_block_1_2363 );
  twobit_op2_62( 3, 61, compiled_temp_1_61 ); /* - */
  twobit_setreg( 2 );
  twobit_store( 2, 13 );
  twobit_reg( 2 );
  twobit_op2imm_branchf_638( fixnum(0), 62, compiled_temp_1_62, 2366, compiled_block_1_2366 ); /* internal:branchf-<=/imm */
  twobit_reg( 4 );
  twobit_skip( 2203, compiled_block_1_2203 );
  twobit_label( 2366, compiled_block_1_2366 );
  twobit_stack( 19 );
  twobit_op2imm_branchf_636( fixnum(0), 63, compiled_temp_1_63, 2368, compiled_block_1_2368 ); /* internal:branchf->/imm */
  twobit_load( 1, 20 );
  twobit_global( 124 ); /* char-numeric? */
  twobit_setrtn( 2369, compiled_block_1_2369 );
  twobit_invoke( 1 );
  twobit_label( 2369, compiled_block_1_2369 );
  twobit_load( 0, 0 );
  twobit_branchf( 2371, compiled_block_1_2371 );
  twobit_load( 1, 14 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_load( 3, 12 );
  twobit_global( 125 ); /*  str-numeric-index~1ay%kV~26955 */
  twobit_setrtn( 2372, compiled_block_1_2372 );
  twobit_invoke( 3 );
  twobit_label( 2372, compiled_block_1_2372 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_branchf( 2374, compiled_block_1_2374 );
  twobit_reg( 4 );
  twobit_op1_branchf_612( 64, compiled_temp_1_64, 2376, compiled_block_1_2376 ); /* internal:branchf-zero? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2375, compiled_block_1_2375 );
  twobit_label( 2376, compiled_block_1_2376 );
  twobit_reg( 4 );
  twobit_op2imm_131( fixnum(1), 65, compiled_temp_1_65 ); /* - */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 2, 14 );
  twobit_check( 3, 2, 0, 2377, compiled_block_1_2377 );
  twobit_load( 2, 12 );
  twobit_reg( 3 );
  twobit_op2_407( 2 ); /* <:fix:fix */
  twobit_load( 1, 14 );
  twobit_check( 3, 1, 0, 2378, compiled_block_1_2378 );
  twobit_reg_op2imm_check_660(reg(3),fixnum(0),2378,compiled_block_1_2378); /* internal:check->=:fix:fix/imm with (3 1 0) */
  twobit_stack( 14 );
  twobit_op2_802( 3 ); /* ustring-ref:trusted */
  twobit_op2imm_139( int_to_char(46) ); /* char=? */
  twobit_label( 2375, compiled_block_1_2375 );
  twobit_branchf( 2380, compiled_block_1_2380 );
  twobit_load( 3, 20 );
  twobit_stack( 13 );
  twobit_op2_799( 3 ); /* make-ustring */
  twobit_setreg( 1 );
  twobit_load( 2, 14 );
  twobit_global( 126 ); /* string-append */
  twobit_setrtn( 2381, compiled_block_1_2381 );
  twobit_invoke( 2 );
  twobit_label( 2381, compiled_block_1_2381 );
  twobit_load( 0, 0 );
  twobit_skip( 2203, compiled_block_1_2203 );
  twobit_label( 2380, compiled_block_1_2380 );
  twobit_load( 3, 20 );
  twobit_stack( 13 );
  twobit_op2_799( 3 ); /* make-ustring */
  twobit_setreg( 2 );
  twobit_store( 2, 13 );
  twobit_load( 1, 14 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_movereg( 4, 3 );
  twobit_global( 127 ); /* substring */
  twobit_setrtn( 2382, compiled_block_1_2382 );
  twobit_invoke( 3 );
  twobit_label( 2382, compiled_block_1_2382 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 14 );
  twobit_load( 2, 1 );
  twobit_load( 3, 12 );
  twobit_global( 128 ); /* substring */
  twobit_setrtn( 2383, compiled_block_1_2383 );
  twobit_invoke( 3 );
  twobit_label( 2383, compiled_block_1_2383 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 13 );
  twobit_load( 1, 2 );
  twobit_global( 129 ); /* string-append */
  twobit_setrtn( 2384, compiled_block_1_2384 );
  twobit_invoke( 3 );
  twobit_label( 2384, compiled_block_1_2384 );
  twobit_load( 0, 0 );
  twobit_skip( 2203, compiled_block_1_2203 );
  twobit_label( 2374, compiled_block_1_2374 );
  twobit_load( 3, 20 );
  twobit_stack( 13 );
  twobit_op2_799( 3 ); /* make-ustring */
  twobit_setreg( 1 );
  twobit_load( 2, 14 );
  twobit_global( 130 ); /* string-append */
  twobit_setrtn( 2385, compiled_block_1_2385 );
  twobit_invoke( 2 );
  twobit_label( 2385, compiled_block_1_2385 );
  twobit_load( 0, 0 );
  twobit_skip( 2203, compiled_block_1_2203 );
  twobit_label( 2371, compiled_block_1_2371 );
  twobit_load( 4, 20 );
  twobit_stack( 13 );
  twobit_op2_799( 4 ); /* make-ustring */
  twobit_setreg( 1 );
  twobit_load( 2, 14 );
  twobit_global( 131 ); /* string-append */
  twobit_setrtn( 2386, compiled_block_1_2386 );
  twobit_invoke( 2 );
  twobit_label( 2386, compiled_block_1_2386 );
  twobit_load( 0, 0 );
  twobit_skip( 2203, compiled_block_1_2203 );
  twobit_label( 2368, compiled_block_1_2368 );
  twobit_load( 1, 20 );
  twobit_reg( 2 );
  twobit_op2_799( 1 ); /* make-ustring */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 132 ); /* string-append */
  twobit_setrtn( 2387, compiled_block_1_2387 );
  twobit_invoke( 2 );
  twobit_label( 2387, compiled_block_1_2387 );
  twobit_load( 0, 0 );
  twobit_skip( 2203, compiled_block_1_2203 );
  twobit_label( 2208, compiled_block_1_2208 );
  twobit_load( 1, 5 );
  twobit_load( 2, 6 );
  twobit_global( 7 ); /*  object->string~1ay%kV~26952 */
  twobit_setrtn( 2388, compiled_block_1_2388 );
  twobit_invoke( 2 );
  twobit_label( 2388, compiled_block_1_2388 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_stack( 11 );
  twobit_branchf( 2390, compiled_block_1_2390 );
  twobit_stack( 11 );
  twobit_op1_11(); /* pair? */
  twobit_load( 2, 11 );
  twobit_check( 2, 0, 0, 2305, compiled_block_1_2305 );
  twobit_stack( 11 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_610( 2392, compiled_block_1_2392 ); /* internal:branchf-null? */
  twobit_imm_const( fixnum(3) ); /* 3 */
  twobit_skip( 2391, compiled_block_1_2391 );
  twobit_label( 2392, compiled_block_1_2392 );
  twobit_reg_op1_check_652(reg(3),1940,compiled_block_1_1940); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op2imm_branchf_635( fixnum(0), 66, compiled_temp_1_66, 2394, compiled_block_1_2394 ); /* internal:branchf-</imm */
  twobit_reg( 2 );
  twobit_op1_32( 67, compiled_temp_1_67 ); /* -- */
  twobit_skip( 2391, compiled_block_1_2391 );
  twobit_label( 2394, compiled_block_1_2394 );
  twobit_reg( 2 );
  twobit_label( 2391, compiled_block_1_2391 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_stack( 5 );
  twobit_op1_34(); /* real-part */
  twobit_op2imm_132( fixnum(0), 68, compiled_temp_1_68 ); /* < */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_stack( 11 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* string */
  twobit_setrtn( 2395, compiled_block_1_2395 );
  twobit_invoke( 1 );
  twobit_label( 2395, compiled_block_1_2395 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 4, 1 );
  twobit_load( 3, 2 );
  twobit_load( 1, 3 );
  twobit_global( 133 ); /*  fixnum-string-separate~1ay%kV~26957 */
  twobit_setrtn( 2396, compiled_block_1_2396 );
  twobit_invoke( 4 );
  twobit_label( 2396, compiled_block_1_2396 );
  twobit_load( 0, 0 );
  twobit_skip( 2389, compiled_block_1_2389 );
  twobit_label( 2390, compiled_block_1_2390 );
  twobit_reg( 4 );
  twobit_label( 2389, compiled_block_1_2389 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_stack( 17 );
  twobit_branchf( 2398, compiled_block_1_2398 );
  twobit_load( 1, 17 );
  twobit_global( 42 ); /* list? */
  twobit_setrtn( 2399, compiled_block_1_2399 );
  twobit_invoke( 1 );
  twobit_label( 2399, compiled_block_1_2399 );
  twobit_load( 0, 0 );
  twobit_branchf( 2401, compiled_block_1_2401 );
  twobit_load( 1, 3 );
  twobit_stack( 17 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 17 );
  twobit_check( 3, 0, 0, 2184, compiled_block_1_2184 );
  twobit_stack( 17 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_stack( 17 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 2402, compiled_block_1_2402 );
  twobit_invoke( 1 );
  twobit_label( 2402, compiled_block_1_2402 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_load( 2, 3 );
  twobit_global( 8 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_69, 135, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_setrtn( 2408, compiled_block_1_2408 );
  twobit_invoke( 2 );
  twobit_label( 2408, compiled_block_1_2408 );
  twobit_load( 0, 0 );
  twobit_skip( 2397, compiled_block_1_2397 );
  twobit_label( 2401, compiled_block_1_2401 );
  twobit_global( 8 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_70, 137, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 17 );
  twobit_reg( 4 );
  twobit_setrtn( 2415, compiled_block_1_2415 );
  twobit_invoke( 1 );
  twobit_label( 2415, compiled_block_1_2415 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 138 ); /* string-append */
  twobit_setreg( 1 );
  twobit_global( 139 ); /* apply */
  twobit_setrtn( 2416, compiled_block_1_2416 );
  twobit_invoke( 2 );
  twobit_label( 2416, compiled_block_1_2416 );
  twobit_load( 0, 0 );
  twobit_skip( 2397, compiled_block_1_2397 );
  twobit_label( 2398, compiled_block_1_2398 );
  twobit_reg( 4 );
  twobit_label( 2397, compiled_block_1_2397 );
  twobit_setreg( 4 );
  twobit_stack( 18 );
  twobit_branchf( 2418, compiled_block_1_2418 );
  twobit_movereg( 4, 1 );
  twobit_load( 2, 18 );
  twobit_global( 140 ); /*  take-both-end~1ay%kV~26953 */
  twobit_setrtn( 2419, compiled_block_1_2419 );
  twobit_invoke( 2 );
  twobit_label( 2419, compiled_block_1_2419 );
  twobit_load( 0, 0 );
  twobit_skip( 2417, compiled_block_1_2417 );
  twobit_label( 2418, compiled_block_1_2418 );
  twobit_reg( 4 );
  twobit_label( 2417, compiled_block_1_2417 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 4, 0, 0, 2362, compiled_block_1_2362 );
  twobit_reg( 4 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_stack( 19 );
  twobit_op2imm_branchf_635( fixnum(0), 71, compiled_temp_1_71, 2421, compiled_block_1_2421 ); /* internal:branchf-</imm */
  twobit_stack( 19 );
  twobit_op1_32( 72, compiled_temp_1_72 ); /* -- */
  twobit_skip( 2420, compiled_block_1_2420 );
  twobit_label( 2421, compiled_block_1_2421 );
  twobit_stack( 19 );
  twobit_label( 2420, compiled_block_1_2420 );
  twobit_op2_62( 3, 73, compiled_temp_1_73 ); /* - */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_reg( 2 );
  twobit_op2imm_branchf_638( fixnum(0), 74, compiled_temp_1_74, 2423, compiled_block_1_2423 ); /* internal:branchf-<=/imm */
  twobit_reg( 4 );
  twobit_skip( 2203, compiled_block_1_2203 );
  twobit_label( 2423, compiled_block_1_2423 );
  twobit_stack( 19 );
  twobit_op2imm_branchf_636( fixnum(0), 75, compiled_temp_1_75, 2425, compiled_block_1_2425 ); /* internal:branchf->/imm */
  twobit_load( 1, 20 );
  twobit_global( 141 ); /* char-numeric? */
  twobit_setrtn( 2426, compiled_block_1_2426 );
  twobit_invoke( 1 );
  twobit_label( 2426, compiled_block_1_2426 );
  twobit_load( 0, 0 );
  twobit_branchf( 2428, compiled_block_1_2428 );
  twobit_load( 1, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_load( 3, 2 );
  twobit_global( 142 ); /*  str-numeric-index~1ay%kV~26955 */
  twobit_setrtn( 2429, compiled_block_1_2429 );
  twobit_invoke( 3 );
  twobit_label( 2429, compiled_block_1_2429 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_reg( 4 );
  twobit_branchf( 2431, compiled_block_1_2431 );
  twobit_reg( 4 );
  twobit_op1_branchf_612( 76, compiled_temp_1_76, 2433, compiled_block_1_2433 ); /* internal:branchf-zero? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 2432, compiled_block_1_2432 );
  twobit_label( 2433, compiled_block_1_2433 );
  twobit_reg( 4 );
  twobit_op2imm_131( fixnum(1), 77, compiled_temp_1_77 ); /* - */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_23(); /* fixnum? */
  twobit_load( 2, 3 );
  twobit_check( 3, 2, 0, 2377, compiled_block_1_2377 );
  twobit_load( 2, 2 );
  twobit_reg( 3 );
  twobit_op2_407( 2 ); /* <:fix:fix */
  twobit_load( 1, 3 );
  twobit_check( 3, 1, 0, 2378, compiled_block_1_2378 );
  twobit_reg_op2imm_check_660(reg(3),fixnum(0),2378,compiled_block_1_2378); /* internal:check->=:fix:fix/imm with (3 1 0) */
  twobit_stack( 3 );
  twobit_op2_802( 3 ); /* ustring-ref:trusted */
  twobit_op2imm_139( int_to_char(46) ); /* char=? */
  twobit_label( 2432, compiled_block_1_2432 );
  twobit_branchf( 2435, compiled_block_1_2435 );
  twobit_load( 3, 20 );
  twobit_stack( 1 );
  twobit_op2_799( 3 ); /* make-ustring */
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_global( 143 ); /* string-append */
  twobit_setrtn( 2436, compiled_block_1_2436 );
  twobit_invoke( 2 );
  twobit_label( 2436, compiled_block_1_2436 );
  twobit_load( 0, 0 );
  twobit_skip( 2203, compiled_block_1_2203 );
  twobit_label( 2435, compiled_block_1_2435 );
  twobit_load( 3, 20 );
  twobit_stack( 1 );
  twobit_op2_799( 3 ); /* make-ustring */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_load( 1, 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_movereg( 4, 3 );
  twobit_global( 144 ); /* substring */
  twobit_setrtn( 2437, compiled_block_1_2437 );
  twobit_invoke( 3 );
  twobit_label( 2437, compiled_block_1_2437 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 12 );
  twobit_load( 1, 3 );
  twobit_load( 2, 4 );
  twobit_load( 3, 2 );
  twobit_global( 145 ); /* substring */
  twobit_setrtn( 2438, compiled_block_1_2438 );
  twobit_invoke( 3 );
  twobit_label( 2438, compiled_block_1_2438 );
  twobit_load( 0, 0 );
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_load( 1, 12 );
  twobit_global( 146 ); /* string-append */
  twobit_setrtn( 2439, compiled_block_1_2439 );
  twobit_invoke( 3 );
  twobit_label( 2439, compiled_block_1_2439 );
  twobit_load( 0, 0 );
  twobit_skip( 2203, compiled_block_1_2203 );
  twobit_label( 2431, compiled_block_1_2431 );
  twobit_load( 3, 20 );
  twobit_stack( 1 );
  twobit_op2_799( 3 ); /* make-ustring */
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_global( 147 ); /* string-append */
  twobit_setrtn( 2440, compiled_block_1_2440 );
  twobit_invoke( 2 );
  twobit_label( 2440, compiled_block_1_2440 );
  twobit_load( 0, 0 );
  twobit_skip( 2203, compiled_block_1_2203 );
  twobit_label( 2428, compiled_block_1_2428 );
  twobit_load( 4, 20 );
  twobit_stack( 1 );
  twobit_op2_799( 4 ); /* make-ustring */
  twobit_setreg( 1 );
  twobit_load( 2, 3 );
  twobit_global( 148 ); /* string-append */
  twobit_setrtn( 2441, compiled_block_1_2441 );
  twobit_invoke( 2 );
  twobit_label( 2441, compiled_block_1_2441 );
  twobit_load( 0, 0 );
  twobit_skip( 2203, compiled_block_1_2203 );
  twobit_label( 2425, compiled_block_1_2425 );
  twobit_load( 1, 20 );
  twobit_reg( 2 );
  twobit_op2_799( 1 ); /* make-ustring */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 149 ); /* string-append */
  twobit_setrtn( 2442, compiled_block_1_2442 );
  twobit_invoke( 2 );
  twobit_label( 2442, compiled_block_1_2442 );
  twobit_load( 0, 0 );
  twobit_skip( 2203, compiled_block_1_2203 );
  twobit_label( 2204, compiled_block_1_2204 );
  twobit_global( 6 ); /* display */
  twobit_setreg( 3 );
  twobit_stack( 6 );
  twobit_op2_branchf_624( 3, 2444, compiled_block_1_2444 ); /* internal:branchf-eq? */
  twobit_stack( 5 );
  twobit_op1_17(); /* symbol? */
  twobit_branchf( 2446, compiled_block_1_2446 );
  twobit_load( 1, 5 );
  twobit_global( 2 ); /* symbol->string */
  twobit_setrtn( 2447, compiled_block_1_2447 );
  twobit_invoke( 1 );
  twobit_label( 2447, compiled_block_1_2447 );
  twobit_load( 0, 0 );
  twobit_skip( 2443, compiled_block_1_2443 );
  twobit_label( 2446, compiled_block_1_2446 );
  twobit_stack( 5 );
  twobit_op2imm_129( TRUE_CONST ); /* eq? */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_branchf( 2449, compiled_block_1_2449 );
  twobit_reg( 3 );
  twobit_skip( 2448, compiled_block_1_2448 );
  twobit_label( 2449, compiled_block_1_2449 );
  twobit_stack( 5 );
  twobit_op2imm_129( FALSE_CONST ); /* eq? */
  twobit_label( 2448, compiled_block_1_2448 );
  twobit_branchf( 2451, compiled_block_1_2451 );
  twobit_stack( 5 );
  twobit_branchf( 2453, compiled_block_1_2453 );
  twobit_const( 3 );
  twobit_skip( 2443, compiled_block_1_2443 );
  twobit_label( 2453, compiled_block_1_2453 );
  twobit_const( 4 );
  twobit_skip( 2443, compiled_block_1_2443 );
  twobit_label( 2451, compiled_block_1_2451 );
  twobit_stack( 5 );
  twobit_op1_branchf_615( 2455, compiled_block_1_2455 ); /* internal:branchf-char? */
  twobit_load( 1, 5 );
  twobit_global( 5 ); /* string */
  twobit_setrtn( 2456, compiled_block_1_2456 );
  twobit_invoke( 1 );
  twobit_label( 2456, compiled_block_1_2456 );
  twobit_load( 0, 0 );
  twobit_skip( 2443, compiled_block_1_2443 );
  twobit_label( 2455, compiled_block_1_2455 );
  twobit_stack( 5 );
  twobit_op1_800(); /* ustring? */
  twobit_branchf( 2458, compiled_block_1_2458 );
  twobit_stack( 5 );
  twobit_skip( 2443, compiled_block_1_2443 );
  twobit_label( 2458, compiled_block_1_2458 );
  twobit_load( 1, 5 );
  twobit_load( 2, 6 );
  twobit_global( 7 ); /*  object->string~1ay%kV~26952 */
  twobit_setrtn( 2459, compiled_block_1_2459 );
  twobit_invoke( 2 );
  twobit_label( 2459, compiled_block_1_2459 );
  twobit_load( 0, 0 );
  twobit_skip( 2443, compiled_block_1_2443 );
  twobit_label( 2444, compiled_block_1_2444 );
  twobit_global( 150 ); /* write */
  twobit_setreg( 3 );
  twobit_stack( 6 );
  twobit_op2_branchf_624( 3, 2461, compiled_block_1_2461 ); /* internal:branchf-eq? */
  twobit_stack( 5 );
  twobit_op1_17(); /* symbol? */
  twobit_branchf( 2463, compiled_block_1_2463 );
  twobit_load( 1, 5 );
  twobit_global( 2 ); /* symbol->string */
  twobit_setrtn( 2464, compiled_block_1_2464 );
  twobit_invoke( 1 );
  twobit_label( 2464, compiled_block_1_2464 );
  twobit_load( 0, 0 );
  twobit_skip( 2443, compiled_block_1_2443 );
  twobit_label( 2463, compiled_block_1_2463 );
  twobit_stack( 5 );
  twobit_op2imm_129( TRUE_CONST ); /* eq? */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_branchf( 2466, compiled_block_1_2466 );
  twobit_reg( 3 );
  twobit_skip( 2465, compiled_block_1_2465 );
  twobit_label( 2466, compiled_block_1_2466 );
  twobit_stack( 5 );
  twobit_op2imm_129( FALSE_CONST ); /* eq? */
  twobit_label( 2465, compiled_block_1_2465 );
  twobit_branchf( 2468, compiled_block_1_2468 );
  twobit_stack( 5 );
  twobit_branchf( 2470, compiled_block_1_2470 );
  twobit_const( 3 );
  twobit_skip( 2443, compiled_block_1_2443 );
  twobit_label( 2470, compiled_block_1_2470 );
  twobit_const( 4 );
  twobit_skip( 2443, compiled_block_1_2443 );
  twobit_label( 2468, compiled_block_1_2468 );
  twobit_load( 1, 5 );
  twobit_load( 2, 6 );
  twobit_global( 7 ); /*  object->string~1ay%kV~26952 */
  twobit_setrtn( 2471, compiled_block_1_2471 );
  twobit_invoke( 2 );
  twobit_label( 2471, compiled_block_1_2471 );
  twobit_load( 0, 0 );
  twobit_skip( 2443, compiled_block_1_2443 );
  twobit_label( 2461, compiled_block_1_2461 );
  twobit_load( 1, 5 );
  twobit_load( 2, 6 );
  twobit_global( 7 ); /*  object->string~1ay%kV~26952 */
  twobit_setrtn( 2472, compiled_block_1_2472 );
  twobit_invoke( 2 );
  twobit_label( 2472, compiled_block_1_2472 );
  twobit_load( 0, 0 );
  twobit_label( 2443, compiled_block_1_2443 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 11 );
  twobit_branchf( 2474, compiled_block_1_2474 );
  twobit_stack( 11 );
  twobit_op1_11(); /* pair? */
  twobit_load( 2, 11 );
  twobit_check( 2, 0, 0, 2305, compiled_block_1_2305 );
  twobit_stack( 11 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_10(); /* null? */
  twobit_op1_9(); /* not */
  twobit_skip( 2473, compiled_block_1_2473 );
  twobit_label( 2474, compiled_block_1_2474 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2473, compiled_block_1_2473 );
  twobit_branchf( 2476, compiled_block_1_2476 );
  twobit_stack( 11 );
  twobit_op1_11(); /* pair? */
  twobit_load( 2, 11 );
  twobit_check( 2, 0, 0, 2305, compiled_block_1_2305 );
  twobit_stack( 11 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg_op1_check_652(reg(3),1940,compiled_block_1_1940); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_stack( 11 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 5 ); /* string */
  twobit_setrtn( 2477, compiled_block_1_2477 );
  twobit_invoke( 1 );
  twobit_label( 2477, compiled_block_1_2477 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 3, 1 );
  twobit_load( 1, 2 );
  twobit_global( 151 ); /*  separate~1ay%kV~26958 */
  twobit_setrtn( 2478, compiled_block_1_2478 );
  twobit_invoke( 3 );
  twobit_label( 2478, compiled_block_1_2478 );
  twobit_load( 0, 0 );
  twobit_skip( 2475, compiled_block_1_2475 );
  twobit_label( 2476, compiled_block_1_2476 );
  twobit_reg( 4 );
  twobit_label( 2475, compiled_block_1_2475 );
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_stack( 17 );
  twobit_branchf( 2480, compiled_block_1_2480 );
  twobit_load( 1, 17 );
  twobit_global( 42 ); /* list? */
  twobit_setrtn( 2481, compiled_block_1_2481 );
  twobit_invoke( 1 );
  twobit_label( 2481, compiled_block_1_2481 );
  twobit_load( 0, 0 );
  twobit_branchf( 2483, compiled_block_1_2483 );
  twobit_load( 1, 1 );
  twobit_stack( 17 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 17 );
  twobit_check( 3, 0, 0, 2184, compiled_block_1_2184 );
  twobit_stack( 17 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_stack( 17 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 2484, compiled_block_1_2484 );
  twobit_invoke( 1 );
  twobit_label( 2484, compiled_block_1_2484 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_load( 2, 1 );
  twobit_global( 8 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_78, 153, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_setrtn( 2490, compiled_block_1_2490 );
  twobit_invoke( 2 );
  twobit_label( 2490, compiled_block_1_2490 );
  twobit_load( 0, 0 );
  twobit_skip( 2479, compiled_block_1_2479 );
  twobit_label( 2483, compiled_block_1_2483 );
  twobit_global( 8 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_79, 155, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 17 );
  twobit_reg( 4 );
  twobit_setrtn( 2497, compiled_block_1_2497 );
  twobit_invoke( 1 );
  twobit_label( 2497, compiled_block_1_2497 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 156 ); /* string-append */
  twobit_setreg( 1 );
  twobit_global( 157 ); /* apply */
  twobit_setrtn( 2498, compiled_block_1_2498 );
  twobit_invoke( 2 );
  twobit_label( 2498, compiled_block_1_2498 );
  twobit_load( 0, 0 );
  twobit_skip( 2479, compiled_block_1_2479 );
  twobit_label( 2480, compiled_block_1_2480 );
  twobit_reg( 4 );
  twobit_label( 2479, compiled_block_1_2479 );
  twobit_setreg( 4 );
  twobit_stack( 18 );
  twobit_branchf( 2500, compiled_block_1_2500 );
  twobit_movereg( 4, 1 );
  twobit_load( 2, 18 );
  twobit_global( 158 ); /*  take-both-end~1ay%kV~26953 */
  twobit_setrtn( 2501, compiled_block_1_2501 );
  twobit_invoke( 2 );
  twobit_label( 2501, compiled_block_1_2501 );
  twobit_load( 0, 0 );
  twobit_skip( 2499, compiled_block_1_2499 );
  twobit_label( 2500, compiled_block_1_2500 );
  twobit_reg( 4 );
  twobit_label( 2499, compiled_block_1_2499 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_800(); /* ustring? */
  twobit_check( 4, 0, 0, 2362, compiled_block_1_2362 );
  twobit_reg( 4 );
  twobit_op1_801(); /* ustring-length:str */
  twobit_setreg( 3 );
  twobit_stack( 19 );
  twobit_op2imm_branchf_635( fixnum(0), 80, compiled_temp_1_80, 2503, compiled_block_1_2503 ); /* internal:branchf-</imm */
  twobit_stack( 19 );
  twobit_op1_32( 81, compiled_temp_1_81 ); /* -- */
  twobit_skip( 2502, compiled_block_1_2502 );
  twobit_label( 2503, compiled_block_1_2503 );
  twobit_stack( 19 );
  twobit_label( 2502, compiled_block_1_2502 );
  twobit_op2_62( 3, 82, compiled_temp_1_82 ); /* - */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_op2imm_branchf_638( fixnum(0), 83, compiled_temp_1_83, 2505, compiled_block_1_2505 ); /* internal:branchf-<=/imm */
  twobit_reg( 4 );
  twobit_skip( 2203, compiled_block_1_2203 );
  twobit_label( 2505, compiled_block_1_2505 );
  twobit_stack( 19 );
  twobit_op2imm_branchf_636( fixnum(0), 84, compiled_temp_1_84, 2507, compiled_block_1_2507 ); /* internal:branchf->/imm */
  twobit_load( 3, 20 );
  twobit_reg( 2 );
  twobit_op2_799( 3 ); /* make-ustring */
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 159 ); /* string-append */
  twobit_setrtn( 2508, compiled_block_1_2508 );
  twobit_invoke( 2 );
  twobit_label( 2508, compiled_block_1_2508 );
  twobit_load( 0, 0 );
  twobit_skip( 2203, compiled_block_1_2203 );
  twobit_label( 2507, compiled_block_1_2507 );
  twobit_load( 3, 20 );
  twobit_reg( 2 );
  twobit_op2_799( 3 ); /* make-ustring */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 160 ); /* string-append */
  twobit_setrtn( 2509, compiled_block_1_2509 );
  twobit_invoke( 2 );
  twobit_label( 2509, compiled_block_1_2509 );
  twobit_load( 0, 0 );
  twobit_label( 2203, compiled_block_1_2203 );
  twobit_setreg( 4 );
  twobit_stack( 21 );
  twobit_branchf( 2511, compiled_block_1_2511 );
  twobit_movereg( 4, 1 );
  twobit_load( 2, 21 );
  twobit_global( 6 ); /* display */
  twobit_pop( 21 );
  twobit_invoke( 2 );
  twobit_label( 2511, compiled_block_1_2511 );
  twobit_reg( 4 );
  twobit_pop( 21 );
  twobit_return();
  twobit_label( 2184, compiled_block_1_2184 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_label( 2035, compiled_block_1_2035 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_label( 2378, compiled_block_1_2378 );
  twobit_trap( 1, 3, 0, 60 );
  twobit_label( 1978, compiled_block_1_1978 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_label( 2305, compiled_block_1_2305 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_label( 1940, compiled_block_1_1940 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_label( 2377, compiled_block_1_2377 );
  twobit_trap( 2, 3, 0, 60 );
  twobit_label( 2362, compiled_block_1_2362 );
  twobit_trap( 4, 0, 0, 62 );
  twobit_label( 2239, compiled_block_1_2239 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 1 );
  twobit_trap( 2, 1, 0, 60 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_26( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1946, compiled_block_1_1946 ); /* internal:branchf-null? */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_return();
  twobit_label( 1946, compiled_block_1_1946 );
  twobit_reg_op1_check_652(reg(2),1947,compiled_block_1_1947); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 1949, compiled_block_1_1949 );
  twobit_reg( 4 );
  twobit_op1_25(); /* exact? */
  twobit_skip( 1948, compiled_block_1_1948 );
  twobit_label( 1949, compiled_block_1_1949 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1948, compiled_block_1_1948 );
  twobit_branchf( 1951, compiled_block_1_1951 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 4, 2 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /* reverse */
  twobit_setrtn( 1952, compiled_block_1_1952 );
  twobit_invoke( 1 );
  twobit_label( 1952, compiled_block_1_1952 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 2 ); /* append */
  twobit_setrtn( 1953, compiled_block_1_1953 );
  twobit_invoke( 2 );
  twobit_label( 1953, compiled_block_1_1953 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1951, compiled_block_1_1951 );
  twobit_reg( 4 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 1947, compiled_block_1_1947 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_27( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1961, compiled_block_1_1961 ); /* internal:branchf-null? */
  twobit_global( 1 ); /* display */
  twobit_return();
  twobit_label( 1961, compiled_block_1_1961 );
  twobit_reg_op1_check_652(reg(2),1962,compiled_block_1_1962); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 1964, compiled_block_1_1964 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 4, 2 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_global( 2 ); /* reverse */
  twobit_setrtn( 1965, compiled_block_1_1965 );
  twobit_invoke( 1 );
  twobit_label( 1965, compiled_block_1_1965 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 3 ); /* append */
  twobit_setrtn( 1966, compiled_block_1_1966 );
  twobit_invoke( 2 );
  twobit_label( 1966, compiled_block_1_1966 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1964, compiled_block_1_1964 );
  twobit_reg( 4 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 1962, compiled_block_1_1962 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_28( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1983, compiled_block_1_1983 ); /* internal:branchf-null? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1983, compiled_block_1_1983 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_reg_op1_check_652(reg(2),1984,compiled_block_1_1984); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_reg( 4 );
  twobit_op2imm_129( TRUE_CONST ); /* eq? */
  twobit_setreg( 3 );
  twobit_store( 3, 3 );
  twobit_reg( 3 );
  twobit_branchf( 1986, compiled_block_1_1986 );
  twobit_reg( 3 );
  twobit_skip( 1985, compiled_block_1_1985 );
  twobit_label( 1986, compiled_block_1_1986 );
  twobit_reg( 4 );
  twobit_op2imm_129( FALSE_CONST ); /* eq? */
  twobit_label( 1985, compiled_block_1_1985 );
  twobit_branchf( 1988, compiled_block_1_1988 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1987, compiled_block_1_1987 );
  twobit_label( 1988, compiled_block_1_1988 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /* output-port? */
  twobit_setrtn( 1989, compiled_block_1_1989 );
  twobit_invoke( 1 );
  twobit_label( 1989, compiled_block_1_1989 );
  twobit_load( 0, 0 );
  twobit_label( 1987, compiled_block_1_1987 );
  twobit_branchf( 1991, compiled_block_1_1991 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 2 );
  twobit_global( 2 ); /* reverse */
  twobit_setrtn( 1992, compiled_block_1_1992 );
  twobit_invoke( 1 );
  twobit_label( 1992, compiled_block_1_1992 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 3 ); /* append */
  twobit_setrtn( 1993, compiled_block_1_1993 );
  twobit_invoke( 2 );
  twobit_label( 1993, compiled_block_1_1993 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_stack( 3 );
  twobit_branchf( 1995, compiled_block_1_1995 );
  twobit_global( 4 ); /* current-output-port */
  twobit_pop( 4 );
  twobit_invoke( 0 );
  twobit_label( 1995, compiled_block_1_1995 );
  twobit_stack( 4 );
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1991, compiled_block_1_1991 );
  twobit_load( 4, 2 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 1984, compiled_block_1_1984 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_29( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 2004, compiled_block_1_2004 ); /* internal:branchf-null? */
  twobit_imm_const( int_to_char(32) ); /* #\space */
  twobit_return();
  twobit_label( 2004, compiled_block_1_2004 );
  twobit_reg_op1_check_652(reg(2),2005,compiled_block_1_2005); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_615( 2007, compiled_block_1_2007 ); /* internal:branchf-char? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 4, 2 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /* reverse */
  twobit_setrtn( 2008, compiled_block_1_2008 );
  twobit_invoke( 1 );
  twobit_label( 2008, compiled_block_1_2008 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 2 ); /* append */
  twobit_setrtn( 2009, compiled_block_1_2009 );
  twobit_invoke( 2 );
  twobit_label( 2009, compiled_block_1_2009 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2007, compiled_block_1_2007 );
  twobit_reg( 4 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 2005, compiled_block_1_2005 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_30( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 2019, compiled_block_1_2019 ); /* internal:branchf-null? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 2019, compiled_block_1_2019 );
  twobit_reg_op1_check_652(reg(2),2020,compiled_block_1_2020); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_22(); /* integer? */
  twobit_branchf( 2022, compiled_block_1_2022 );
  twobit_reg( 4 );
  twobit_op1_26(); /* inexact? */
  twobit_skip( 2021, compiled_block_1_2021 );
  twobit_label( 2022, compiled_block_1_2022 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2021, compiled_block_1_2021 );
  twobit_branchf( 2024, compiled_block_1_2024 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 4, 2 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /* reverse */
  twobit_setrtn( 2025, compiled_block_1_2025 );
  twobit_invoke( 1 );
  twobit_label( 2025, compiled_block_1_2025 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 2 ); /* append */
  twobit_setrtn( 2026, compiled_block_1_2026 );
  twobit_invoke( 2 );
  twobit_label( 2026, compiled_block_1_2026 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2024, compiled_block_1_2024 );
  twobit_reg( 4 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 2020, compiled_block_1_2020 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_31( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 2043, compiled_block_1_2043 ); /* internal:branchf-null? */
  twobit_const( 1 );
  twobit_return();
  twobit_label( 2043, compiled_block_1_2043 );
  twobit_reg_op1_check_652(reg(2),2044,compiled_block_1_2044); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_const( 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 2046, compiled_block_1_2046 ); /* internal:branchf-eq? */
  twobit_const( 2 );
  twobit_skip( 2045, compiled_block_1_2045 );
  twobit_label( 2046, compiled_block_1_2046 );
  twobit_const( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_const( 3 );
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 31, 2048, compiled_block_1_2048 ); /* internal:branchf-eq? */
  twobit_reg( 3 );
  twobit_skip( 2045, compiled_block_1_2045 );
  twobit_label( 2048, compiled_block_1_2048 );
  twobit_reg_op1_check_652(reg(3),2049,compiled_block_1_2049); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_const( 4 );
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 31, 2051, compiled_block_1_2051 ); /* internal:branchf-eq? */
  twobit_reg( 3 );
  twobit_skip( 2045, compiled_block_1_2045 );
  twobit_label( 2051, compiled_block_1_2051 );
  twobit_reg_op1_check_652(reg(3),2049,compiled_block_1_2049); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_const( 5 );
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 31, 2053, compiled_block_1_2053 ); /* internal:branchf-eq? */
  twobit_reg( 3 );
  twobit_skip( 2045, compiled_block_1_2045 );
  twobit_label( 2053, compiled_block_1_2053 );
  twobit_reg_op1_check_652(reg(3),2049,compiled_block_1_2049); /* internal:check-pair? with (3 0 0) */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2045, compiled_block_1_2045 );
  twobit_branchf( 2055, compiled_block_1_2055 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 4, 2 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_global( 6 ); /* reverse */
  twobit_setrtn( 2056, compiled_block_1_2056 );
  twobit_invoke( 1 );
  twobit_label( 2056, compiled_block_1_2056 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 7 ); /* append */
  twobit_setrtn( 2057, compiled_block_1_2057 );
  twobit_invoke( 2 );
  twobit_label( 2057, compiled_block_1_2057 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2055, compiled_block_1_2055 );
  twobit_reg( 4 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 2049, compiled_block_1_2049 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_label( 2044, compiled_block_1_2044 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_32( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 2069, compiled_block_1_2069 ); /* internal:branchf-null? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 2069, compiled_block_1_2069 );
  twobit_reg_op1_check_652(reg(2),2070,compiled_block_1_2070); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_const( 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 2072, compiled_block_1_2072 ); /* internal:branchf-eq? */
  twobit_const( 2 );
  twobit_skip( 2071, compiled_block_1_2071 );
  twobit_label( 2072, compiled_block_1_2072 );
  twobit_const( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_const( 3 );
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 31, 2074, compiled_block_1_2074 ); /* internal:branchf-eq? */
  twobit_reg( 3 );
  twobit_skip( 2071, compiled_block_1_2071 );
  twobit_label( 2074, compiled_block_1_2074 );
  twobit_reg_op1_check_652(reg(3),2075,compiled_block_1_2075); /* internal:check-pair? with (3 0 0) */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2071, compiled_block_1_2071 );
  twobit_branchf( 2077, compiled_block_1_2077 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 4, 2 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_global( 4 ); /* reverse */
  twobit_setrtn( 2078, compiled_block_1_2078 );
  twobit_invoke( 1 );
  twobit_label( 2078, compiled_block_1_2078 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* append */
  twobit_setrtn( 2079, compiled_block_1_2079 );
  twobit_invoke( 2 );
  twobit_label( 2079, compiled_block_1_2079 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2077, compiled_block_1_2077 );
  twobit_reg( 4 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 2075, compiled_block_1_2075 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_label( 2070, compiled_block_1_2070 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_33( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 2087, compiled_block_1_2087 ); /* internal:branchf-null? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 2087, compiled_block_1_2087 );
  twobit_reg_op1_check_652(reg(2),2088,compiled_block_1_2088); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_const( 1 );
  twobit_op2_branchf_624( 4, 2090, compiled_block_1_2090 ); /* internal:branchf-eq? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 4, 2 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_global( 2 ); /* reverse */
  twobit_setrtn( 2091, compiled_block_1_2091 );
  twobit_invoke( 1 );
  twobit_label( 2091, compiled_block_1_2091 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 3 ); /* append */
  twobit_setrtn( 2092, compiled_block_1_2092 );
  twobit_invoke( 2 );
  twobit_label( 2092, compiled_block_1_2092 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2090, compiled_block_1_2090 );
  twobit_reg( 4 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 2088, compiled_block_1_2088 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_34( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 2104, compiled_block_1_2104 ); /* internal:branchf-null? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 2104, compiled_block_1_2104 );
  twobit_reg_op1_check_652(reg(2),2105,compiled_block_1_2105); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_const( 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 2107, compiled_block_1_2107 ); /* internal:branchf-eq? */
  twobit_const( 2 );
  twobit_skip( 2106, compiled_block_1_2106 );
  twobit_label( 2107, compiled_block_1_2107 );
  twobit_const( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_const( 3 );
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 31, 2109, compiled_block_1_2109 ); /* internal:branchf-eq? */
  twobit_reg( 3 );
  twobit_skip( 2106, compiled_block_1_2106 );
  twobit_label( 2109, compiled_block_1_2109 );
  twobit_reg_op1_check_652(reg(3),2110,compiled_block_1_2110); /* internal:check-pair? with (3 0 0) */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2106, compiled_block_1_2106 );
  twobit_branchf( 2112, compiled_block_1_2112 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 4, 2 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_global( 4 ); /* reverse */
  twobit_setrtn( 2113, compiled_block_1_2113 );
  twobit_invoke( 1 );
  twobit_label( 2113, compiled_block_1_2113 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 5 ); /* append */
  twobit_setrtn( 2114, compiled_block_1_2114 );
  twobit_invoke( 2 );
  twobit_label( 2114, compiled_block_1_2114 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2112, compiled_block_1_2112 );
  twobit_reg( 4 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 2110, compiled_block_1_2110 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_label( 2105, compiled_block_1_2105 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_35( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 2138, compiled_block_1_2138 ); /* internal:branchf-null? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 2138, compiled_block_1_2138 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 2 );
  twobit_reg_op1_check_652(reg(2),2139,compiled_block_1_2139); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2141, compiled_block_1_2141 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  exact-integer/string?~1ay%kV~26962 */
  twobit_setrtn( 2142, compiled_block_1_2142 );
  twobit_invoke( 1 );
  twobit_label( 2142, compiled_block_1_2142 );
  twobit_load( 0, 0 );
  twobit_branchf( 2144, compiled_block_1_2144 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_10(); /* null? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2146, compiled_block_1_2146 );
  twobit_reg( 4 );
  twobit_skip( 2140, compiled_block_1_2140 );
  twobit_label( 2146, compiled_block_1_2146 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* list? */
  twobit_setrtn( 2147, compiled_block_1_2147 );
  twobit_invoke( 1 );
  twobit_label( 2147, compiled_block_1_2147 );
  twobit_load( 0, 0 );
  twobit_branchf( 2149, compiled_block_1_2149 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),2150,compiled_block_1_2150); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 2152, compiled_block_1_2152 ); /* internal:branchf-null? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  exact-integer/string?~1ay%kV~26962 */
  twobit_setrtn( 2153, compiled_block_1_2153 );
  twobit_invoke( 1 );
  twobit_label( 2153, compiled_block_1_2153 );
  twobit_load( 0, 0 );
  twobit_skip( 2148, compiled_block_1_2148 );
  twobit_label( 2152, compiled_block_1_2152 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 2148, compiled_block_1_2148 );
  twobit_label( 2149, compiled_block_1_2149 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2148, compiled_block_1_2148 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 2155, compiled_block_1_2155 );
  twobit_reg( 4 );
  twobit_skip( 2140, compiled_block_1_2140 );
  twobit_label( 2155, compiled_block_1_2155 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  exact-integer/string?~1ay%kV~26962 */
  twobit_setrtn( 2156, compiled_block_1_2156 );
  twobit_invoke( 1 );
  twobit_label( 2156, compiled_block_1_2156 );
  twobit_load( 0, 0 );
  twobit_skip( 2140, compiled_block_1_2140 );
  twobit_label( 2144, compiled_block_1_2144 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 2140, compiled_block_1_2140 );
  twobit_label( 2141, compiled_block_1_2141 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2140, compiled_block_1_2140 );
  twobit_branchf( 2158, compiled_block_1_2158 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 3 );
  twobit_global( 3 ); /* reverse */
  twobit_setrtn( 2159, compiled_block_1_2159 );
  twobit_invoke( 1 );
  twobit_label( 2159, compiled_block_1_2159 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 4 ); /* append */
  twobit_setrtn( 2160, compiled_block_1_2160 );
  twobit_invoke( 2 );
  twobit_label( 2160, compiled_block_1_2160 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_stack( 1 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 2158, compiled_block_1_2158 );
  twobit_load( 4, 3 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 2139, compiled_block_1_2139 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_label( 2150, compiled_block_1_2150 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_36( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 2171, compiled_block_1_2171 ); /* internal:branchf-null? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 2171, compiled_block_1_2171 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_reg_op1_check_652(reg(2),2172,compiled_block_1_2172); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 2174, compiled_block_1_2174 ); /* internal:branchf-pair? */
  twobit_global( 1 ); /* procedure? */
  twobit_setreg( 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 2 ); /*  every?~1ay%kV~26959 */
  twobit_setrtn( 2175, compiled_block_1_2175 );
  twobit_invoke( 2 );
  twobit_label( 2175, compiled_block_1_2175 );
  twobit_load( 0, 0 );
  twobit_skip( 2173, compiled_block_1_2173 );
  twobit_label( 2174, compiled_block_1_2174 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 2173, compiled_block_1_2173 );
  twobit_branchf( 2177, compiled_block_1_2177 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_load( 1, 2 );
  twobit_global( 3 ); /* reverse */
  twobit_setrtn( 2178, compiled_block_1_2178 );
  twobit_invoke( 1 );
  twobit_label( 2178, compiled_block_1_2178 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /* append */
  twobit_setrtn( 2179, compiled_block_1_2179 );
  twobit_invoke( 2 );
  twobit_label( 2179, compiled_block_1_2179 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_stack( 3 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 2177, compiled_block_1_2177 );
  twobit_load( 4, 2 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 2172, compiled_block_1_2172 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_57( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 2346, compiled_block_1_2346 ); /* internal:branchf-null? */
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 2346, compiled_block_1_2346 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg_op1_check_652(reg(2),2347,compiled_block_1_2347); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 2348, compiled_block_1_2348 );
  twobit_invoke( 1 );
  twobit_label( 2348, compiled_block_1_2348 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2347, compiled_block_1_2347 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_58( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 2352, compiled_block_1_2352 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 2353, compiled_block_1_2353 );
  twobit_invoke( 1 );
  twobit_label( 2353, compiled_block_1_2353 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 2352, compiled_block_1_2352 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg_op1_check_652(reg(1),2354,compiled_block_1_2354); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 2355, compiled_block_1_2355 );
  twobit_invoke( 1 );
  twobit_label( 2355, compiled_block_1_2355 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 2356, compiled_block_1_2356 );
  twobit_invoke( 1 );
  twobit_label( 2356, compiled_block_1_2356 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2354, compiled_block_1_2354 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_69( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 2404, compiled_block_1_2404 ); /* internal:branchf-null? */
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 2404, compiled_block_1_2404 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg_op1_check_652(reg(2),2405,compiled_block_1_2405); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 2406, compiled_block_1_2406 );
  twobit_invoke( 1 );
  twobit_label( 2406, compiled_block_1_2406 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2405, compiled_block_1_2405 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_70( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 2410, compiled_block_1_2410 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 2411, compiled_block_1_2411 );
  twobit_invoke( 1 );
  twobit_label( 2411, compiled_block_1_2411 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 2410, compiled_block_1_2410 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg_op1_check_652(reg(1),2412,compiled_block_1_2412); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 2413, compiled_block_1_2413 );
  twobit_invoke( 1 );
  twobit_label( 2413, compiled_block_1_2413 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 2414, compiled_block_1_2414 );
  twobit_invoke( 1 );
  twobit_label( 2414, compiled_block_1_2414 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2412, compiled_block_1_2412 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_78( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 2486, compiled_block_1_2486 ); /* internal:branchf-null? */
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 2486, compiled_block_1_2486 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg_op1_check_652(reg(2),2487,compiled_block_1_2487); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 2488, compiled_block_1_2488 );
  twobit_invoke( 1 );
  twobit_label( 2488, compiled_block_1_2488 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 2487, compiled_block_1_2487 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_79( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_47(); /* procedure? */
  twobit_branchf( 2492, compiled_block_1_2492 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 2493, compiled_block_1_2493 );
  twobit_invoke( 1 );
  twobit_label( 2493, compiled_block_1_2493 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 2492, compiled_block_1_2492 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg_op1_check_652(reg(1),2494,compiled_block_1_2494); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 2495, compiled_block_1_2495 );
  twobit_invoke( 1 );
  twobit_label( 2495, compiled_block_1_2495 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 2496, compiled_block_1_2496 );
  twobit_invoke( 1 );
  twobit_label( 2496, compiled_block_1_2496 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2494, compiled_block_1_2494 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_585e72200b2537d4bd59e2da4fb39ab0_0(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_1_0(CONT_ACTUALS));
}
static RTYPE compiled_block_2_1004( CONT_PARAMS );
static RTYPE compiled_block_2_1003( CONT_PARAMS );
static RTYPE compiled_start_2_0( CONT_PARAMS );
static RTYPE compiled_start_2_3( CONT_PARAMS );
static RTYPE compiled_start_2_2( CONT_PARAMS );
static RTYPE compiled_start_2_1( CONT_PARAMS );

static RTYPE compiled_start_2_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_2_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_2_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1003, compiled_block_2_1003 );
  twobit_invoke( 8 );
  twobit_label( 1003, compiled_block_2_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1004, compiled_block_2_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_2_1004 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_585e72200b2537d4bd59e2da4fb39ab0_1(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_2_0(CONT_ACTUALS));
}
codeptr_t CDECL twobit_load_table[] = { 
  twobit_thunk_585e72200b2537d4bd59e2da4fb39ab0_0,
  twobit_thunk_585e72200b2537d4bd59e2da4fb39ab0_1,
  0  /* The table may be empty; some compilers complain */
};

/* Generated from /home/henchman/larcenytest/larceny-petit-Nightly-2009-08-19/larceny_src/lib/SRFI/srfi/%3a1.slfasl */
#include "petit-instr.h"

static RTYPE compiled_block_1_2055( CONT_PARAMS );
static RTYPE compiled_block_1_2054( CONT_PARAMS );
static RTYPE compiled_start_1_0( CONT_PARAMS );
static RTYPE compiled_start_1_3( CONT_PARAMS );
static RTYPE compiled_block_1_2048( CONT_PARAMS );
static RTYPE compiled_block_1_2046( CONT_PARAMS );
static RTYPE compiled_block_1_2044( CONT_PARAMS );
static RTYPE compiled_block_1_2042( CONT_PARAMS );
static RTYPE compiled_start_1_110( CONT_PARAMS );
static RTYPE compiled_block_1_2051( CONT_PARAMS );
static RTYPE compiled_start_1_111( CONT_PARAMS );
static RTYPE compiled_start_1_112( CONT_PARAMS );
static RTYPE compiled_block_1_2037( CONT_PARAMS );
static RTYPE compiled_block_1_2035( CONT_PARAMS );
static RTYPE compiled_block_1_2033( CONT_PARAMS );
static RTYPE compiled_block_1_2031( CONT_PARAMS );
static RTYPE compiled_start_1_109( CONT_PARAMS );
static RTYPE compiled_block_1_2040( CONT_PARAMS );
static RTYPE compiled_start_1_113( CONT_PARAMS );
static RTYPE compiled_start_1_114( CONT_PARAMS );
static RTYPE compiled_start_1_108( CONT_PARAMS );
static RTYPE compiled_start_1_115( CONT_PARAMS );
static RTYPE compiled_block_1_2022( CONT_PARAMS );
static RTYPE compiled_block_1_2019( CONT_PARAMS );
static RTYPE compiled_start_1_117( CONT_PARAMS );
static RTYPE compiled_block_1_2024( CONT_PARAMS );
static RTYPE compiled_block_1_2027( CONT_PARAMS );
static RTYPE compiled_block_1_2025( CONT_PARAMS );
static RTYPE compiled_start_1_118( CONT_PARAMS );
static RTYPE compiled_start_1_116( CONT_PARAMS );
static RTYPE compiled_start_1_107( CONT_PARAMS );
static RTYPE compiled_start_1_119( CONT_PARAMS );
static RTYPE compiled_block_1_2009( CONT_PARAMS );
static RTYPE compiled_block_1_2006( CONT_PARAMS );
static RTYPE compiled_start_1_121( CONT_PARAMS );
static RTYPE compiled_block_1_2013( CONT_PARAMS );
static RTYPE compiled_block_1_2011( CONT_PARAMS );
static RTYPE compiled_start_1_122( CONT_PARAMS );
static RTYPE compiled_start_1_120( CONT_PARAMS );
static RTYPE compiled_block_1_2000( CONT_PARAMS );
static RTYPE compiled_block_1_1998( CONT_PARAMS );
static RTYPE compiled_block_1_1997( CONT_PARAMS );
static RTYPE compiled_block_1_1995( CONT_PARAMS );
static RTYPE compiled_start_1_106( CONT_PARAMS );
static RTYPE compiled_start_1_123( CONT_PARAMS );
static RTYPE compiled_block_1_2001( CONT_PARAMS );
static RTYPE compiled_start_1_124( CONT_PARAMS );
static RTYPE compiled_block_1_1991( CONT_PARAMS );
static RTYPE compiled_block_1_1989( CONT_PARAMS );
static RTYPE compiled_block_1_1988( CONT_PARAMS );
static RTYPE compiled_block_1_1986( CONT_PARAMS );
static RTYPE compiled_start_1_105( CONT_PARAMS );
static RTYPE compiled_start_1_125( CONT_PARAMS );
static RTYPE compiled_block_1_1992( CONT_PARAMS );
static RTYPE compiled_start_1_126( CONT_PARAMS );
static RTYPE compiled_block_1_1982( CONT_PARAMS );
static RTYPE compiled_block_1_1980( CONT_PARAMS );
static RTYPE compiled_block_1_1978( CONT_PARAMS );
static RTYPE compiled_block_1_1977( CONT_PARAMS );
static RTYPE compiled_start_1_104( CONT_PARAMS );
static RTYPE compiled_start_1_127( CONT_PARAMS );
static RTYPE compiled_start_1_128( CONT_PARAMS );
static RTYPE compiled_block_1_1973( CONT_PARAMS );
static RTYPE compiled_block_1_1971( CONT_PARAMS );
static RTYPE compiled_block_1_1969( CONT_PARAMS );
static RTYPE compiled_block_1_1968( CONT_PARAMS );
static RTYPE compiled_start_1_103( CONT_PARAMS );
static RTYPE compiled_start_1_129( CONT_PARAMS );
static RTYPE compiled_start_1_130( CONT_PARAMS );
static RTYPE compiled_start_1_102( CONT_PARAMS );
static RTYPE compiled_block_1_1960( CONT_PARAMS );
static RTYPE compiled_block_1_1958( CONT_PARAMS );
static RTYPE compiled_block_1_1956( CONT_PARAMS );
static RTYPE compiled_start_1_131( CONT_PARAMS );
static RTYPE compiled_block_1_1961( CONT_PARAMS );
static RTYPE compiled_block_1_1965( CONT_PARAMS );
static RTYPE compiled_block_1_1963( CONT_PARAMS );
static RTYPE compiled_start_1_132( CONT_PARAMS );
static RTYPE compiled_start_1_133( CONT_PARAMS );
static RTYPE compiled_start_1_101( CONT_PARAMS );
static RTYPE compiled_block_1_1948( CONT_PARAMS );
static RTYPE compiled_block_1_1946( CONT_PARAMS );
static RTYPE compiled_block_1_1944( CONT_PARAMS );
static RTYPE compiled_start_1_134( CONT_PARAMS );
static RTYPE compiled_block_1_1952( CONT_PARAMS );
static RTYPE compiled_block_1_1950( CONT_PARAMS );
static RTYPE compiled_start_1_135( CONT_PARAMS );
static RTYPE compiled_start_1_136( CONT_PARAMS );
static RTYPE compiled_start_1_100( CONT_PARAMS );
static RTYPE compiled_block_1_1941( CONT_PARAMS );
static RTYPE compiled_block_1_1939( CONT_PARAMS );
static RTYPE compiled_start_1_137( CONT_PARAMS );
static RTYPE compiled_block_1_1925( CONT_PARAMS );
static RTYPE compiled_block_1_1924( CONT_PARAMS );
static RTYPE compiled_start_1_99( CONT_PARAMS );
static RTYPE compiled_block_1_1928( CONT_PARAMS );
static RTYPE compiled_block_1_1936( CONT_PARAMS );
static RTYPE compiled_block_1_1929( CONT_PARAMS );
static RTYPE compiled_block_1_1933( CONT_PARAMS );
static RTYPE compiled_block_1_1934( CONT_PARAMS );
static RTYPE compiled_block_1_1931( CONT_PARAMS );
static RTYPE compiled_block_1_1930( CONT_PARAMS );
static RTYPE compiled_block_1_1927( CONT_PARAMS );
static RTYPE compiled_start_1_138( CONT_PARAMS );
static RTYPE compiled_block_1_1912( CONT_PARAMS );
static RTYPE compiled_block_1_1911( CONT_PARAMS );
static RTYPE compiled_start_1_98( CONT_PARAMS );
static RTYPE compiled_block_1_1915( CONT_PARAMS );
static RTYPE compiled_block_1_1920( CONT_PARAMS );
static RTYPE compiled_block_1_1916( CONT_PARAMS );
static RTYPE compiled_block_1_1918( CONT_PARAMS );
static RTYPE compiled_block_1_1917( CONT_PARAMS );
static RTYPE compiled_block_1_1914( CONT_PARAMS );
static RTYPE compiled_start_1_139( CONT_PARAMS );
static RTYPE compiled_start_1_97( CONT_PARAMS );
static RTYPE compiled_start_1_140( CONT_PARAMS );
static RTYPE compiled_start_1_96( CONT_PARAMS );
static RTYPE compiled_block_1_1905( CONT_PARAMS );
static RTYPE compiled_block_1_1904( CONT_PARAMS );
static RTYPE compiled_block_1_1902( CONT_PARAMS );
static RTYPE compiled_start_1_141( CONT_PARAMS );
static RTYPE compiled_block_1_1883( CONT_PARAMS );
static RTYPE compiled_start_1_95( CONT_PARAMS );
static RTYPE compiled_block_1_1896( CONT_PARAMS );
static RTYPE compiled_temp_1_144( CONT_PARAMS );
static RTYPE compiled_block_1_1899( CONT_PARAMS );
static RTYPE compiled_block_1_1897( CONT_PARAMS );
static RTYPE compiled_block_1_1895( CONT_PARAMS );
static RTYPE compiled_block_1_1893( CONT_PARAMS );
static RTYPE compiled_start_1_143( CONT_PARAMS );
static RTYPE compiled_start_1_142( CONT_PARAMS );
static RTYPE compiled_block_1_1886( CONT_PARAMS );
static RTYPE compiled_temp_1_147( CONT_PARAMS );
static RTYPE compiled_block_1_1889( CONT_PARAMS );
static RTYPE compiled_block_1_1887( CONT_PARAMS );
static RTYPE compiled_start_1_146( CONT_PARAMS );
static RTYPE compiled_start_1_145( CONT_PARAMS );
static RTYPE compiled_block_1_1871( CONT_PARAMS );
static RTYPE compiled_block_1_1870( CONT_PARAMS );
static RTYPE compiled_block_1_1868( CONT_PARAMS );
static RTYPE compiled_block_1_1853( CONT_PARAMS );
static RTYPE compiled_start_1_94( CONT_PARAMS );
static RTYPE compiled_block_1_1879( CONT_PARAMS );
static RTYPE compiled_block_1_1878( CONT_PARAMS );
static RTYPE compiled_block_1_1876( CONT_PARAMS );
static RTYPE compiled_block_1_1874( CONT_PARAMS );
static RTYPE compiled_block_1_1872( CONT_PARAMS );
static RTYPE compiled_start_1_150( CONT_PARAMS );
static RTYPE compiled_block_1_1856( CONT_PARAMS );
static RTYPE compiled_start_1_149( CONT_PARAMS );
static RTYPE compiled_start_1_151( CONT_PARAMS );
static RTYPE compiled_block_1_1859( CONT_PARAMS );
static RTYPE compiled_block_1_1862( CONT_PARAMS );
static RTYPE compiled_block_1_1860( CONT_PARAMS );
static RTYPE compiled_start_1_153( CONT_PARAMS );
static RTYPE compiled_start_1_152( CONT_PARAMS );
static RTYPE compiled_start_1_148( CONT_PARAMS );
static RTYPE compiled_block_1_1841( CONT_PARAMS );
static RTYPE compiled_block_1_1840( CONT_PARAMS );
static RTYPE compiled_block_1_1838( CONT_PARAMS );
static RTYPE compiled_block_1_1823( CONT_PARAMS );
static RTYPE compiled_start_1_93( CONT_PARAMS );
static RTYPE compiled_block_1_1849( CONT_PARAMS );
static RTYPE compiled_block_1_1848( CONT_PARAMS );
static RTYPE compiled_block_1_1846( CONT_PARAMS );
static RTYPE compiled_block_1_1844( CONT_PARAMS );
static RTYPE compiled_block_1_1842( CONT_PARAMS );
static RTYPE compiled_start_1_156( CONT_PARAMS );
static RTYPE compiled_block_1_1826( CONT_PARAMS );
static RTYPE compiled_start_1_155( CONT_PARAMS );
static RTYPE compiled_start_1_157( CONT_PARAMS );
static RTYPE compiled_block_1_1829( CONT_PARAMS );
static RTYPE compiled_block_1_1832( CONT_PARAMS );
static RTYPE compiled_block_1_1830( CONT_PARAMS );
static RTYPE compiled_start_1_159( CONT_PARAMS );
static RTYPE compiled_start_1_158( CONT_PARAMS );
static RTYPE compiled_start_1_154( CONT_PARAMS );
static RTYPE compiled_start_1_92( CONT_PARAMS );
static RTYPE compiled_block_1_1820( CONT_PARAMS );
static RTYPE compiled_start_1_160( CONT_PARAMS );
static RTYPE compiled_start_1_91( CONT_PARAMS );
static RTYPE compiled_block_1_1818( CONT_PARAMS );
static RTYPE compiled_start_1_161( CONT_PARAMS );
static RTYPE compiled_block_1_1800( CONT_PARAMS );
static RTYPE compiled_block_1_1807( CONT_PARAMS );
static RTYPE compiled_block_1_1816( CONT_PARAMS );
static RTYPE compiled_block_1_1805( CONT_PARAMS );
static RTYPE compiled_block_1_1798( CONT_PARAMS );
static RTYPE compiled_block_1_1803( CONT_PARAMS );
static RTYPE compiled_block_1_1801( CONT_PARAMS );
static RTYPE compiled_block_1_1799( CONT_PARAMS );
static RTYPE compiled_block_1_1797( CONT_PARAMS );
static RTYPE compiled_start_1_90( CONT_PARAMS );
static RTYPE compiled_block_1_1811( CONT_PARAMS );
static RTYPE compiled_block_1_1814( CONT_PARAMS );
static RTYPE compiled_block_1_1812( CONT_PARAMS );
static RTYPE compiled_block_1_1810( CONT_PARAMS );
static RTYPE compiled_block_1_1808( CONT_PARAMS );
static RTYPE compiled_start_1_162( CONT_PARAMS );
static RTYPE compiled_start_1_89( CONT_PARAMS );
static RTYPE compiled_block_1_1788( CONT_PARAMS );
static RTYPE compiled_block_1_1791( CONT_PARAMS );
static RTYPE compiled_block_1_1789( CONT_PARAMS );
static RTYPE compiled_block_1_1786( CONT_PARAMS );
static RTYPE compiled_block_1_1784( CONT_PARAMS );
static RTYPE compiled_start_1_163( CONT_PARAMS );
static RTYPE compiled_start_1_165( CONT_PARAMS );
static RTYPE compiled_start_1_164( CONT_PARAMS );
static RTYPE compiled_block_1_1770( CONT_PARAMS );
static RTYPE compiled_block_1_1776( CONT_PARAMS );
static RTYPE compiled_block_1_1783( CONT_PARAMS );
static RTYPE compiled_block_1_1775( CONT_PARAMS );
static RTYPE compiled_block_1_1768( CONT_PARAMS );
static RTYPE compiled_block_1_1773( CONT_PARAMS );
static RTYPE compiled_block_1_1771( CONT_PARAMS );
static RTYPE compiled_block_1_1769( CONT_PARAMS );
static RTYPE compiled_block_1_1767( CONT_PARAMS );
static RTYPE compiled_start_1_88( CONT_PARAMS );
static RTYPE compiled_block_1_1778( CONT_PARAMS );
static RTYPE compiled_block_1_1781( CONT_PARAMS );
static RTYPE compiled_block_1_1779( CONT_PARAMS );
static RTYPE compiled_start_1_166( CONT_PARAMS );
static RTYPE compiled_start_1_87( CONT_PARAMS );
static RTYPE compiled_block_1_1761( CONT_PARAMS );
static RTYPE compiled_block_1_1764( CONT_PARAMS );
static RTYPE compiled_block_1_1762( CONT_PARAMS );
static RTYPE compiled_block_1_1760( CONT_PARAMS );
static RTYPE compiled_block_1_1758( CONT_PARAMS );
static RTYPE compiled_start_1_167( CONT_PARAMS );
static RTYPE compiled_start_1_86( CONT_PARAMS );
static RTYPE compiled_block_1_1752( CONT_PARAMS );
static RTYPE compiled_block_1_1755( CONT_PARAMS );
static RTYPE compiled_block_1_1756( CONT_PARAMS );
static RTYPE compiled_block_1_1753( CONT_PARAMS );
static RTYPE compiled_block_1_1751( CONT_PARAMS );
static RTYPE compiled_block_1_1749( CONT_PARAMS );
static RTYPE compiled_start_1_168( CONT_PARAMS );
static RTYPE compiled_start_1_85( CONT_PARAMS );
static RTYPE compiled_block_1_1743( CONT_PARAMS );
static RTYPE compiled_block_1_1746( CONT_PARAMS );
static RTYPE compiled_block_1_1744( CONT_PARAMS );
static RTYPE compiled_block_1_1742( CONT_PARAMS );
static RTYPE compiled_block_1_1740( CONT_PARAMS );
static RTYPE compiled_start_1_169( CONT_PARAMS );
static RTYPE compiled_block_1_1739( CONT_PARAMS );
static RTYPE compiled_block_1_1738( CONT_PARAMS );
static RTYPE compiled_block_1_1736( CONT_PARAMS );
static RTYPE compiled_start_1_84( CONT_PARAMS );
static RTYPE compiled_block_1_1731( CONT_PARAMS );
static RTYPE compiled_block_1_1732( CONT_PARAMS );
static RTYPE compiled_start_1_83( CONT_PARAMS );
static RTYPE compiled_block_1_1733( CONT_PARAMS );
static RTYPE compiled_block_1_1734( CONT_PARAMS );
static RTYPE compiled_start_1_170( CONT_PARAMS );
static RTYPE compiled_block_1_1726( CONT_PARAMS );
static RTYPE compiled_block_1_1727( CONT_PARAMS );
static RTYPE compiled_start_1_82( CONT_PARAMS );
static RTYPE compiled_block_1_1728( CONT_PARAMS );
static RTYPE compiled_block_1_1729( CONT_PARAMS );
static RTYPE compiled_start_1_171( CONT_PARAMS );
static RTYPE compiled_start_1_81( CONT_PARAMS );
static RTYPE compiled_block_1_1724( CONT_PARAMS );
static RTYPE compiled_start_1_172( CONT_PARAMS );
static RTYPE compiled_start_1_80( CONT_PARAMS );
static RTYPE compiled_block_1_1719( CONT_PARAMS );
static RTYPE compiled_block_1_1720( CONT_PARAMS );
static RTYPE compiled_start_1_79( CONT_PARAMS );
static RTYPE compiled_block_1_1721( CONT_PARAMS );
static RTYPE compiled_start_1_173( CONT_PARAMS );
static RTYPE compiled_block_1_1708( CONT_PARAMS );
static RTYPE compiled_block_1_1709( CONT_PARAMS );
static RTYPE compiled_start_1_78( CONT_PARAMS );
static RTYPE compiled_block_1_1713( CONT_PARAMS );
static RTYPE compiled_block_1_1716( CONT_PARAMS );
static RTYPE compiled_block_1_1717( CONT_PARAMS );
static RTYPE compiled_block_1_1715( CONT_PARAMS );
static RTYPE compiled_block_1_1714( CONT_PARAMS );
static RTYPE compiled_block_1_1712( CONT_PARAMS );
static RTYPE compiled_block_1_1710( CONT_PARAMS );
static RTYPE compiled_start_1_174( CONT_PARAMS );
static RTYPE compiled_block_1_1697( CONT_PARAMS );
static RTYPE compiled_block_1_1698( CONT_PARAMS );
static RTYPE compiled_start_1_77( CONT_PARAMS );
static RTYPE compiled_block_1_1702( CONT_PARAMS );
static RTYPE compiled_block_1_1706( CONT_PARAMS );
static RTYPE compiled_block_1_1704( CONT_PARAMS );
static RTYPE compiled_block_1_1703( CONT_PARAMS );
static RTYPE compiled_block_1_1701( CONT_PARAMS );
static RTYPE compiled_block_1_1699( CONT_PARAMS );
static RTYPE compiled_start_1_175( CONT_PARAMS );
static RTYPE compiled_block_1_1693( CONT_PARAMS );
static RTYPE compiled_block_1_1694( CONT_PARAMS );
static RTYPE compiled_start_1_76( CONT_PARAMS );
static RTYPE compiled_start_1_176( CONT_PARAMS );
static RTYPE compiled_block_1_1689( CONT_PARAMS );
static RTYPE compiled_block_1_1690( CONT_PARAMS );
static RTYPE compiled_start_1_75( CONT_PARAMS );
static RTYPE compiled_block_1_1691( CONT_PARAMS );
static RTYPE compiled_start_1_177( CONT_PARAMS );
static RTYPE compiled_block_1_1685( CONT_PARAMS );
static RTYPE compiled_block_1_1686( CONT_PARAMS );
static RTYPE compiled_start_1_74( CONT_PARAMS );
static RTYPE compiled_block_1_1687( CONT_PARAMS );
static RTYPE compiled_start_1_178( CONT_PARAMS );
static RTYPE compiled_start_1_73( CONT_PARAMS );
static RTYPE compiled_block_1_1683( CONT_PARAMS );
static RTYPE compiled_start_1_179( CONT_PARAMS );
static RTYPE compiled_start_1_72( CONT_PARAMS );
static RTYPE compiled_block_1_1681( CONT_PARAMS );
static RTYPE compiled_start_1_180( CONT_PARAMS );
static RTYPE compiled_block_1_1657( CONT_PARAMS );
static RTYPE compiled_block_1_1660( CONT_PARAMS );
static RTYPE compiled_block_1_1658( CONT_PARAMS );
static RTYPE compiled_block_1_1639( CONT_PARAMS );
static RTYPE compiled_block_1_1637( CONT_PARAMS );
static RTYPE compiled_start_1_71( CONT_PARAMS );
static RTYPE compiled_block_1_1672( CONT_PARAMS );
static RTYPE compiled_block_1_1675( CONT_PARAMS );
static RTYPE compiled_block_1_1676( CONT_PARAMS );
static RTYPE compiled_block_1_1673( CONT_PARAMS );
static RTYPE compiled_start_1_184( CONT_PARAMS );
static RTYPE compiled_block_1_1662( CONT_PARAMS );
static RTYPE compiled_block_1_1667( CONT_PARAMS );
static RTYPE compiled_block_1_1665( CONT_PARAMS );
static RTYPE compiled_block_1_1663( CONT_PARAMS );
static RTYPE compiled_start_1_183( CONT_PARAMS );
static RTYPE compiled_start_1_182( CONT_PARAMS );
static RTYPE compiled_block_1_1650( CONT_PARAMS );
static RTYPE compiled_block_1_1653( CONT_PARAMS );
static RTYPE compiled_block_1_1651( CONT_PARAMS );
static RTYPE compiled_start_1_185( CONT_PARAMS );
static RTYPE compiled_start_1_181( CONT_PARAMS );
static RTYPE compiled_block_1_1642( CONT_PARAMS );
static RTYPE compiled_block_1_1645( CONT_PARAMS );
static RTYPE compiled_block_1_1643( CONT_PARAMS );
static RTYPE compiled_start_1_186( CONT_PARAMS );
static RTYPE compiled_start_1_70( CONT_PARAMS );
static RTYPE compiled_block_1_1624( CONT_PARAMS );
static RTYPE compiled_block_1_1622( CONT_PARAMS );
static RTYPE compiled_block_1_1620( CONT_PARAMS );
static RTYPE compiled_start_1_187( CONT_PARAMS );
static RTYPE compiled_start_1_189( CONT_PARAMS );
static RTYPE compiled_block_1_1631( CONT_PARAMS );
static RTYPE compiled_block_1_1632( CONT_PARAMS );
static RTYPE compiled_block_1_1627( CONT_PARAMS );
static RTYPE compiled_block_1_1628( CONT_PARAMS );
static RTYPE compiled_block_1_1629( CONT_PARAMS );
static RTYPE compiled_block_1_1625( CONT_PARAMS );
static RTYPE compiled_start_1_188( CONT_PARAMS );
static RTYPE compiled_start_1_69( CONT_PARAMS );
static RTYPE compiled_block_1_1598( CONT_PARAMS );
static RTYPE compiled_block_1_1601( CONT_PARAMS );
static RTYPE compiled_block_1_1617( CONT_PARAMS );
static RTYPE compiled_block_1_1599( CONT_PARAMS );
static RTYPE compiled_block_1_1597( CONT_PARAMS );
static RTYPE compiled_block_1_1595( CONT_PARAMS );
static RTYPE compiled_start_1_190( CONT_PARAMS );
static RTYPE compiled_block_1_1611( CONT_PARAMS );
static RTYPE compiled_block_1_1614( CONT_PARAMS );
static RTYPE compiled_block_1_1612( CONT_PARAMS );
static RTYPE compiled_start_1_192( CONT_PARAMS );
static RTYPE compiled_start_1_191( CONT_PARAMS );
static RTYPE compiled_block_1_1603( CONT_PARAMS );
static RTYPE compiled_block_1_1606( CONT_PARAMS );
static RTYPE compiled_block_1_1604( CONT_PARAMS );
static RTYPE compiled_start_1_193( CONT_PARAMS );
static RTYPE compiled_start_1_68( CONT_PARAMS );
static RTYPE compiled_block_1_1586( CONT_PARAMS );
static RTYPE compiled_block_1_1589( CONT_PARAMS );
static RTYPE compiled_block_1_1592( CONT_PARAMS );
static RTYPE compiled_block_1_1590( CONT_PARAMS );
static RTYPE compiled_block_1_1587( CONT_PARAMS );
static RTYPE compiled_block_1_1585( CONT_PARAMS );
static RTYPE compiled_block_1_1583( CONT_PARAMS );
static RTYPE compiled_start_1_194( CONT_PARAMS );
static RTYPE compiled_block_1_1568( CONT_PARAMS );
static RTYPE compiled_start_1_67( CONT_PARAMS );
static RTYPE compiled_block_1_1579( CONT_PARAMS );
static RTYPE compiled_block_1_1580( CONT_PARAMS );
static RTYPE compiled_block_1_1578( CONT_PARAMS );
static RTYPE compiled_block_1_1576( CONT_PARAMS );
static RTYPE compiled_start_1_196( CONT_PARAMS );
static RTYPE compiled_start_1_195( CONT_PARAMS );
static RTYPE compiled_block_1_1571( CONT_PARAMS );
static RTYPE compiled_block_1_1572( CONT_PARAMS );
static RTYPE compiled_start_1_198( CONT_PARAMS );
static RTYPE compiled_start_1_197( CONT_PARAMS );
static RTYPE compiled_block_1_1552( CONT_PARAMS );
static RTYPE compiled_start_1_66( CONT_PARAMS );
static RTYPE compiled_block_1_1563( CONT_PARAMS );
static RTYPE compiled_block_1_1565( CONT_PARAMS );
static RTYPE compiled_block_1_1564( CONT_PARAMS );
static RTYPE compiled_block_1_1562( CONT_PARAMS );
static RTYPE compiled_block_1_1560( CONT_PARAMS );
static RTYPE compiled_start_1_200( CONT_PARAMS );
static RTYPE compiled_start_1_199( CONT_PARAMS );
static RTYPE compiled_block_1_1555( CONT_PARAMS );
static RTYPE compiled_block_1_1557( CONT_PARAMS );
static RTYPE compiled_block_1_1556( CONT_PARAMS );
static RTYPE compiled_start_1_202( CONT_PARAMS );
static RTYPE compiled_start_1_201( CONT_PARAMS );
static RTYPE compiled_block_1_1531( CONT_PARAMS );
static RTYPE compiled_start_1_65( CONT_PARAMS );
static RTYPE compiled_block_1_1545( CONT_PARAMS );
static RTYPE compiled_block_1_1549( CONT_PARAMS );
static RTYPE compiled_block_1_1547( CONT_PARAMS );
static RTYPE compiled_block_1_1546( CONT_PARAMS );
static RTYPE compiled_block_1_1544( CONT_PARAMS );
static RTYPE compiled_block_1_1542( CONT_PARAMS );
static RTYPE compiled_start_1_204( CONT_PARAMS );
static RTYPE compiled_start_1_203( CONT_PARAMS );
static RTYPE compiled_block_1_1534( CONT_PARAMS );
static RTYPE compiled_block_1_1537( CONT_PARAMS );
static RTYPE compiled_block_1_1538( CONT_PARAMS );
static RTYPE compiled_block_1_1535( CONT_PARAMS );
static RTYPE compiled_start_1_206( CONT_PARAMS );
static RTYPE compiled_start_1_205( CONT_PARAMS );
static RTYPE compiled_block_1_1516( CONT_PARAMS );
static RTYPE compiled_block_1_1529( CONT_PARAMS );
static RTYPE compiled_block_1_1517( CONT_PARAMS );
static RTYPE compiled_block_1_1526( CONT_PARAMS );
static RTYPE compiled_start_1_64( CONT_PARAMS );
static RTYPE compiled_block_1_1527( CONT_PARAMS );
static RTYPE compiled_block_1_1528( CONT_PARAMS );
static RTYPE compiled_start_1_208( CONT_PARAMS );
static RTYPE compiled_block_1_1520( CONT_PARAMS );
static RTYPE compiled_block_1_1518( CONT_PARAMS );
static RTYPE compiled_start_1_207( CONT_PARAMS );
static RTYPE compiled_block_1_1522( CONT_PARAMS );
static RTYPE compiled_block_1_1523( CONT_PARAMS );
static RTYPE compiled_start_1_210( CONT_PARAMS );
static RTYPE compiled_start_1_209( CONT_PARAMS );
static RTYPE compiled_block_1_1502( CONT_PARAMS );
static RTYPE compiled_start_1_63( CONT_PARAMS );
static RTYPE compiled_block_1_1512( CONT_PARAMS );
static RTYPE compiled_block_1_1513( CONT_PARAMS );
static RTYPE compiled_block_1_1511( CONT_PARAMS );
static RTYPE compiled_block_1_1509( CONT_PARAMS );
static RTYPE compiled_start_1_212( CONT_PARAMS );
static RTYPE compiled_block_1_1505( CONT_PARAMS );
static RTYPE compiled_block_1_1506( CONT_PARAMS );
static RTYPE compiled_block_1_1503( CONT_PARAMS );
static RTYPE compiled_start_1_211( CONT_PARAMS );
static RTYPE compiled_block_1_1492( CONT_PARAMS );
static RTYPE compiled_block_1_1491( CONT_PARAMS );
static RTYPE compiled_block_1_1489( CONT_PARAMS );
static RTYPE compiled_block_1_1476( CONT_PARAMS );
static RTYPE compiled_start_1_62( CONT_PARAMS );
static RTYPE compiled_block_1_1497( CONT_PARAMS );
static RTYPE compiled_block_1_1498( CONT_PARAMS );
static RTYPE compiled_block_1_1496( CONT_PARAMS );
static RTYPE compiled_block_1_1494( CONT_PARAMS );
static RTYPE compiled_block_1_1493( CONT_PARAMS );
static RTYPE compiled_start_1_215( CONT_PARAMS );
static RTYPE compiled_block_1_1479( CONT_PARAMS );
static RTYPE compiled_start_1_214( CONT_PARAMS );
static RTYPE compiled_block_1_1480( CONT_PARAMS );
static RTYPE compiled_start_1_216( CONT_PARAMS );
static RTYPE compiled_block_1_1484( CONT_PARAMS );
static RTYPE compiled_block_1_1483( CONT_PARAMS );
static RTYPE compiled_start_1_218( CONT_PARAMS );
static RTYPE compiled_start_1_217( CONT_PARAMS );
static RTYPE compiled_start_1_213( CONT_PARAMS );
static RTYPE compiled_start_1_61( CONT_PARAMS );
static RTYPE compiled_start_1_60( CONT_PARAMS );
static RTYPE compiled_block_1_1467( CONT_PARAMS );
static RTYPE compiled_block_1_1466( CONT_PARAMS );
static RTYPE compiled_block_1_1464( CONT_PARAMS );
static RTYPE compiled_start_1_59( CONT_PARAMS );
static RTYPE compiled_block_1_1469( CONT_PARAMS );
static RTYPE compiled_block_1_1470( CONT_PARAMS );
static RTYPE compiled_start_1_219( CONT_PARAMS );
static RTYPE compiled_block_1_1462( CONT_PARAMS );
static RTYPE compiled_block_1_1461( CONT_PARAMS );
static RTYPE compiled_block_1_1459( CONT_PARAMS );
static RTYPE compiled_start_1_58( CONT_PARAMS );
static RTYPE compiled_block_1_1444( CONT_PARAMS );
static RTYPE compiled_start_1_57( CONT_PARAMS );
static RTYPE compiled_block_1_1455( CONT_PARAMS );
static RTYPE compiled_block_1_1456( CONT_PARAMS );
static RTYPE compiled_block_1_1454( CONT_PARAMS );
static RTYPE compiled_block_1_1452( CONT_PARAMS );
static RTYPE compiled_start_1_221( CONT_PARAMS );
static RTYPE compiled_block_1_1449( CONT_PARAMS );
static RTYPE compiled_block_1_1448( CONT_PARAMS );
static RTYPE compiled_block_1_1447( CONT_PARAMS );
static RTYPE compiled_block_1_1445( CONT_PARAMS );
static RTYPE compiled_start_1_220( CONT_PARAMS );
static RTYPE compiled_block_1_1428( CONT_PARAMS );
static RTYPE compiled_start_1_56( CONT_PARAMS );
static RTYPE compiled_block_1_1439( CONT_PARAMS );
static RTYPE compiled_block_1_1440( CONT_PARAMS );
static RTYPE compiled_block_1_1438( CONT_PARAMS );
static RTYPE compiled_block_1_1436( CONT_PARAMS );
static RTYPE compiled_start_1_223( CONT_PARAMS );
static RTYPE compiled_block_1_1433( CONT_PARAMS );
static RTYPE compiled_block_1_1432( CONT_PARAMS );
static RTYPE compiled_block_1_1431( CONT_PARAMS );
static RTYPE compiled_block_1_1429( CONT_PARAMS );
static RTYPE compiled_start_1_222( CONT_PARAMS );
static RTYPE compiled_block_1_1412( CONT_PARAMS );
static RTYPE compiled_start_1_55( CONT_PARAMS );
static RTYPE compiled_block_1_1423( CONT_PARAMS );
static RTYPE compiled_block_1_1424( CONT_PARAMS );
static RTYPE compiled_block_1_1422( CONT_PARAMS );
static RTYPE compiled_block_1_1420( CONT_PARAMS );
static RTYPE compiled_start_1_225( CONT_PARAMS );
static RTYPE compiled_block_1_1417( CONT_PARAMS );
static RTYPE compiled_block_1_1416( CONT_PARAMS );
static RTYPE compiled_block_1_1415( CONT_PARAMS );
static RTYPE compiled_block_1_1413( CONT_PARAMS );
static RTYPE compiled_start_1_224( CONT_PARAMS );
static RTYPE compiled_block_1_1396( CONT_PARAMS );
static RTYPE compiled_start_1_54( CONT_PARAMS );
static RTYPE compiled_block_1_1407( CONT_PARAMS );
static RTYPE compiled_block_1_1408( CONT_PARAMS );
static RTYPE compiled_block_1_1406( CONT_PARAMS );
static RTYPE compiled_block_1_1404( CONT_PARAMS );
static RTYPE compiled_start_1_227( CONT_PARAMS );
static RTYPE compiled_start_1_226( CONT_PARAMS );
static RTYPE compiled_block_1_1400( CONT_PARAMS );
static RTYPE compiled_block_1_1399( CONT_PARAMS );
static RTYPE compiled_start_1_229( CONT_PARAMS );
static RTYPE compiled_start_1_228( CONT_PARAMS );
static RTYPE compiled_block_1_1376( CONT_PARAMS );
static RTYPE compiled_block_1_1378( CONT_PARAMS );
static RTYPE compiled_start_1_53( CONT_PARAMS );
static RTYPE compiled_block_1_1393( CONT_PARAMS );
static RTYPE compiled_block_1_1392( CONT_PARAMS );
static RTYPE compiled_block_1_1391( CONT_PARAMS );
static RTYPE compiled_block_1_1390( CONT_PARAMS );
static RTYPE compiled_block_1_1388( CONT_PARAMS );
static RTYPE compiled_start_1_231( CONT_PARAMS );
static RTYPE compiled_block_1_1386( CONT_PARAMS );
static RTYPE compiled_block_1_1385( CONT_PARAMS );
static RTYPE compiled_block_1_1384( CONT_PARAMS );
static RTYPE compiled_block_1_1382( CONT_PARAMS );
static RTYPE compiled_block_1_1380( CONT_PARAMS );
static RTYPE compiled_start_1_230( CONT_PARAMS );
static RTYPE compiled_block_1_1366( CONT_PARAMS );
static RTYPE compiled_block_1_1367( CONT_PARAMS );
static RTYPE compiled_start_1_52( CONT_PARAMS );
static RTYPE compiled_block_1_1372( CONT_PARAMS );
static RTYPE compiled_block_1_1371( CONT_PARAMS );
static RTYPE compiled_block_1_1370( CONT_PARAMS );
static RTYPE compiled_block_1_1368( CONT_PARAMS );
static RTYPE compiled_start_1_232( CONT_PARAMS );
static RTYPE compiled_block_1_1343( CONT_PARAMS );
static RTYPE compiled_start_1_51( CONT_PARAMS );
static RTYPE compiled_block_1_1360( CONT_PARAMS );
static RTYPE compiled_block_1_1362( CONT_PARAMS );
static RTYPE compiled_block_1_1363( CONT_PARAMS );
static RTYPE compiled_temp_1_235( CONT_PARAMS );
static RTYPE compiled_block_1_1361( CONT_PARAMS );
static RTYPE compiled_block_1_1359( CONT_PARAMS );
static RTYPE compiled_block_1_1357( CONT_PARAMS );
static RTYPE compiled_start_1_234( CONT_PARAMS );
static RTYPE compiled_block_1_1346( CONT_PARAMS );
static RTYPE compiled_block_1_1344( CONT_PARAMS );
static RTYPE compiled_start_1_233( CONT_PARAMS );
static RTYPE compiled_block_1_1350( CONT_PARAMS );
static RTYPE compiled_block_1_1352( CONT_PARAMS );
static RTYPE compiled_block_1_1353( CONT_PARAMS );
static RTYPE compiled_temp_1_238( CONT_PARAMS );
static RTYPE compiled_block_1_1351( CONT_PARAMS );
static RTYPE compiled_block_1_1349( CONT_PARAMS );
static RTYPE compiled_start_1_237( CONT_PARAMS );
static RTYPE compiled_start_1_236( CONT_PARAMS );
static RTYPE compiled_start_1_50( CONT_PARAMS );
static RTYPE compiled_block_1_1332( CONT_PARAMS );
static RTYPE compiled_start_1_239( CONT_PARAMS );
static RTYPE compiled_start_1_241( CONT_PARAMS );
static RTYPE compiled_start_1_243( CONT_PARAMS );
static RTYPE compiled_start_1_245( CONT_PARAMS );
static RTYPE compiled_start_1_244( CONT_PARAMS );
static RTYPE compiled_start_1_242( CONT_PARAMS );
static RTYPE compiled_start_1_240( CONT_PARAMS );
static RTYPE compiled_start_1_49( CONT_PARAMS );
static RTYPE compiled_start_1_246( CONT_PARAMS );
static RTYPE compiled_block_1_1316( CONT_PARAMS );
static RTYPE compiled_start_1_247( CONT_PARAMS );
static RTYPE compiled_block_1_1320( CONT_PARAMS );
static RTYPE compiled_block_1_1318( CONT_PARAMS );
static RTYPE compiled_start_1_249( CONT_PARAMS );
static RTYPE compiled_start_1_251( CONT_PARAMS );
static RTYPE compiled_start_1_253( CONT_PARAMS );
static RTYPE compiled_start_1_252( CONT_PARAMS );
static RTYPE compiled_start_1_250( CONT_PARAMS );
static RTYPE compiled_start_1_248( CONT_PARAMS );
static RTYPE compiled_start_1_48( CONT_PARAMS );
static RTYPE compiled_start_1_254( CONT_PARAMS );
static RTYPE compiled_block_1_1300( CONT_PARAMS );
static RTYPE compiled_start_1_255( CONT_PARAMS );
static RTYPE compiled_block_1_1304( CONT_PARAMS );
static RTYPE compiled_block_1_1302( CONT_PARAMS );
static RTYPE compiled_start_1_257( CONT_PARAMS );
static RTYPE compiled_start_1_259( CONT_PARAMS );
static RTYPE compiled_start_1_261( CONT_PARAMS );
static RTYPE compiled_start_1_260( CONT_PARAMS );
static RTYPE compiled_start_1_258( CONT_PARAMS );
static RTYPE compiled_start_1_256( CONT_PARAMS );
static RTYPE compiled_start_1_47( CONT_PARAMS );
static RTYPE compiled_block_1_1296( CONT_PARAMS );
static RTYPE compiled_block_1_1295( CONT_PARAMS );
static RTYPE compiled_block_1_1297( CONT_PARAMS );
static RTYPE compiled_start_1_262( CONT_PARAMS );
static RTYPE compiled_start_1_46( CONT_PARAMS );
static RTYPE compiled_start_1_263( CONT_PARAMS );
static RTYPE compiled_block_1_1290( CONT_PARAMS );
static RTYPE compiled_block_1_1285( CONT_PARAMS );
static RTYPE compiled_block_1_1291( CONT_PARAMS );
static RTYPE compiled_block_1_1288( CONT_PARAMS );
static RTYPE compiled_block_1_1286( CONT_PARAMS );
static RTYPE compiled_start_1_264( CONT_PARAMS );
static RTYPE compiled_start_1_45( CONT_PARAMS );
static RTYPE compiled_start_1_44( CONT_PARAMS );
static RTYPE compiled_start_1_43( CONT_PARAMS );
static RTYPE compiled_block_1_1279( CONT_PARAMS );
static RTYPE compiled_block_1_1278( CONT_PARAMS );
static RTYPE compiled_block_1_1276( CONT_PARAMS );
static RTYPE compiled_start_1_265( CONT_PARAMS );
static RTYPE compiled_start_1_42( CONT_PARAMS );
static RTYPE compiled_block_1_1273( CONT_PARAMS );
static RTYPE compiled_block_1_1272( CONT_PARAMS );
static RTYPE compiled_block_1_1270( CONT_PARAMS );
static RTYPE compiled_start_1_266( CONT_PARAMS );
static RTYPE compiled_start_1_41( CONT_PARAMS );
static RTYPE compiled_block_1_1257( CONT_PARAMS );
static RTYPE compiled_block_1_1259( CONT_PARAMS );
static RTYPE compiled_block_1_1260( CONT_PARAMS );
static RTYPE compiled_start_1_267( CONT_PARAMS );
static RTYPE compiled_block_1_1262( CONT_PARAMS );
static RTYPE compiled_block_1_1263( CONT_PARAMS );
static RTYPE compiled_block_1_1264( CONT_PARAMS );
static RTYPE compiled_block_1_1265( CONT_PARAMS );
static RTYPE compiled_start_1_268( CONT_PARAMS );
static RTYPE compiled_start_1_40( CONT_PARAMS );
static RTYPE compiled_block_1_1249( CONT_PARAMS );
static RTYPE compiled_block_1_1247( CONT_PARAMS );
static RTYPE compiled_block_1_1245( CONT_PARAMS );
static RTYPE compiled_start_1_269( CONT_PARAMS );
static RTYPE compiled_block_1_1251( CONT_PARAMS );
static RTYPE compiled_block_1_1252( CONT_PARAMS );
static RTYPE compiled_start_1_271( CONT_PARAMS );
static RTYPE compiled_start_1_270( CONT_PARAMS );
static RTYPE compiled_start_1_39( CONT_PARAMS );
static RTYPE compiled_block_1_1238( CONT_PARAMS );
static RTYPE compiled_block_1_1236( CONT_PARAMS );
static RTYPE compiled_block_1_1234( CONT_PARAMS );
static RTYPE compiled_start_1_272( CONT_PARAMS );
static RTYPE compiled_block_1_1240( CONT_PARAMS );
static RTYPE compiled_block_1_1241( CONT_PARAMS );
static RTYPE compiled_start_1_274( CONT_PARAMS );
static RTYPE compiled_start_1_273( CONT_PARAMS );
static RTYPE compiled_start_1_38( CONT_PARAMS );
static RTYPE compiled_block_1_1227( CONT_PARAMS );
static RTYPE compiled_block_1_1225( CONT_PARAMS );
static RTYPE compiled_block_1_1223( CONT_PARAMS );
static RTYPE compiled_start_1_275( CONT_PARAMS );
static RTYPE compiled_block_1_1229( CONT_PARAMS );
static RTYPE compiled_block_1_1230( CONT_PARAMS );
static RTYPE compiled_start_1_277( CONT_PARAMS );
static RTYPE compiled_start_1_276( CONT_PARAMS );
static RTYPE compiled_start_1_37( CONT_PARAMS );
static RTYPE compiled_block_1_1217( CONT_PARAMS );
static RTYPE compiled_block_1_1215( CONT_PARAMS );
static RTYPE compiled_block_1_1213( CONT_PARAMS );
static RTYPE compiled_start_1_278( CONT_PARAMS );
static RTYPE compiled_block_1_1219( CONT_PARAMS );
static RTYPE compiled_start_1_280( CONT_PARAMS );
static RTYPE compiled_start_1_279( CONT_PARAMS );
static RTYPE compiled_start_1_36( CONT_PARAMS );
static RTYPE compiled_start_1_35( CONT_PARAMS );
static RTYPE compiled_block_1_1207( CONT_PARAMS );
static RTYPE compiled_block_1_1209( CONT_PARAMS );
static RTYPE compiled_start_1_281( CONT_PARAMS );
static RTYPE compiled_block_1_1206( CONT_PARAMS );
static RTYPE compiled_block_1_1205( CONT_PARAMS );
static RTYPE compiled_start_1_34( CONT_PARAMS );
static RTYPE compiled_block_1_1203( CONT_PARAMS );
static RTYPE compiled_block_1_1202( CONT_PARAMS );
static RTYPE compiled_temp_1_283( CONT_PARAMS );
static RTYPE compiled_block_1_1200( CONT_PARAMS );
static RTYPE compiled_temp_1_282( CONT_PARAMS );
static RTYPE compiled_start_1_33( CONT_PARAMS );
static RTYPE compiled_start_1_32( CONT_PARAMS );
static RTYPE compiled_block_1_1191( CONT_PARAMS );
static RTYPE compiled_temp_1_285( CONT_PARAMS );
static RTYPE compiled_start_1_284( CONT_PARAMS );
static RTYPE compiled_block_1_1195( CONT_PARAMS );
static RTYPE compiled_start_1_287( CONT_PARAMS );
static RTYPE compiled_block_1_1193( CONT_PARAMS );
static RTYPE compiled_temp_1_288( CONT_PARAMS );
static RTYPE compiled_start_1_286( CONT_PARAMS );
static RTYPE compiled_block_1_1184( CONT_PARAMS );
static RTYPE compiled_block_1_1182( CONT_PARAMS );
static RTYPE compiled_start_1_31( CONT_PARAMS );
static RTYPE compiled_block_1_1187( CONT_PARAMS );
static RTYPE compiled_block_1_1186( CONT_PARAMS );
static RTYPE compiled_start_1_289( CONT_PARAMS );
static RTYPE compiled_block_1_1176( CONT_PARAMS );
static RTYPE compiled_start_1_30( CONT_PARAMS );
static RTYPE compiled_block_1_1179( CONT_PARAMS );
static RTYPE compiled_block_1_1178( CONT_PARAMS );
static RTYPE compiled_block_1_1180( CONT_PARAMS );
static RTYPE compiled_start_1_290( CONT_PARAMS );
static RTYPE compiled_block_1_1170( CONT_PARAMS );
static RTYPE compiled_start_1_29( CONT_PARAMS );
static RTYPE compiled_block_1_1173( CONT_PARAMS );
static RTYPE compiled_block_1_1172( CONT_PARAMS );
static RTYPE compiled_start_1_291( CONT_PARAMS );
static RTYPE compiled_block_1_1169( CONT_PARAMS );
static RTYPE compiled_temp_1_293( CONT_PARAMS );
static RTYPE compiled_block_1_1168( CONT_PARAMS );
static RTYPE compiled_temp_1_292( CONT_PARAMS );
static RTYPE compiled_start_1_28( CONT_PARAMS );
static RTYPE compiled_start_1_27( CONT_PARAMS );
static RTYPE compiled_block_1_1164( CONT_PARAMS );
static RTYPE compiled_temp_1_296( CONT_PARAMS );
static RTYPE compiled_block_1_1163( CONT_PARAMS );
static RTYPE compiled_temp_1_295( CONT_PARAMS );
static RTYPE compiled_start_1_294( CONT_PARAMS );
static RTYPE compiled_start_1_26( CONT_PARAMS );
static RTYPE compiled_block_1_1159( CONT_PARAMS );
static RTYPE compiled_block_1_1160( CONT_PARAMS );
static RTYPE compiled_temp_1_299( CONT_PARAMS );
static RTYPE compiled_block_1_1158( CONT_PARAMS );
static RTYPE compiled_temp_1_298( CONT_PARAMS );
static RTYPE compiled_start_1_297( CONT_PARAMS );
static RTYPE compiled_block_1_1155( CONT_PARAMS );
static RTYPE compiled_start_1_25( CONT_PARAMS );
static RTYPE compiled_block_1_1153( CONT_PARAMS );
static RTYPE compiled_block_1_1152( CONT_PARAMS );
static RTYPE compiled_block_1_1154( CONT_PARAMS );
static RTYPE compiled_start_1_24( CONT_PARAMS );
static RTYPE compiled_block_1_1150( CONT_PARAMS );
static RTYPE compiled_block_1_1149( CONT_PARAMS );
static RTYPE compiled_block_1_1151( CONT_PARAMS );
static RTYPE compiled_start_1_23( CONT_PARAMS );
static RTYPE compiled_block_1_1147( CONT_PARAMS );
static RTYPE compiled_block_1_1146( CONT_PARAMS );
static RTYPE compiled_block_1_1148( CONT_PARAMS );
static RTYPE compiled_start_1_22( CONT_PARAMS );
static RTYPE compiled_block_1_1144( CONT_PARAMS );
static RTYPE compiled_block_1_1143( CONT_PARAMS );
static RTYPE compiled_block_1_1145( CONT_PARAMS );
static RTYPE compiled_start_1_21( CONT_PARAMS );
static RTYPE compiled_block_1_1141( CONT_PARAMS );
static RTYPE compiled_block_1_1140( CONT_PARAMS );
static RTYPE compiled_block_1_1142( CONT_PARAMS );
static RTYPE compiled_start_1_20( CONT_PARAMS );
static RTYPE compiled_block_1_1138( CONT_PARAMS );
static RTYPE compiled_block_1_1137( CONT_PARAMS );
static RTYPE compiled_block_1_1139( CONT_PARAMS );
static RTYPE compiled_start_1_19( CONT_PARAMS );
static RTYPE compiled_start_1_18( CONT_PARAMS );
static RTYPE compiled_start_1_17( CONT_PARAMS );
static RTYPE compiled_block_1_1131( CONT_PARAMS );
static RTYPE compiled_block_1_1128( CONT_PARAMS );
static RTYPE compiled_block_1_1130( CONT_PARAMS );
static RTYPE compiled_block_1_1133( CONT_PARAMS );
static RTYPE compiled_temp_1_302( CONT_PARAMS );
static RTYPE compiled_temp_1_301( CONT_PARAMS );
static RTYPE compiled_start_1_300( CONT_PARAMS );
static RTYPE compiled_block_1_1103( CONT_PARAMS );
static RTYPE compiled_block_1_1102( CONT_PARAMS );
static RTYPE compiled_start_1_16( CONT_PARAMS );
static RTYPE compiled_block_1_1106( CONT_PARAMS );
static RTYPE compiled_block_1_1108( CONT_PARAMS );
static RTYPE compiled_block_1_1105( CONT_PARAMS );
static RTYPE compiled_start_1_303( CONT_PARAMS );
static RTYPE compiled_block_1_1120( CONT_PARAMS );
static RTYPE compiled_block_1_1123( CONT_PARAMS );
static RTYPE compiled_block_1_1121( CONT_PARAMS );
static RTYPE compiled_block_1_1119( CONT_PARAMS );
static RTYPE compiled_block_1_1117( CONT_PARAMS );
static RTYPE compiled_block_1_1112( CONT_PARAMS );
static RTYPE compiled_block_1_1115( CONT_PARAMS );
static RTYPE compiled_block_1_1113( CONT_PARAMS );
static RTYPE compiled_block_1_1110( CONT_PARAMS );
static RTYPE compiled_start_1_304( CONT_PARAMS );
static RTYPE compiled_block_1_1099( CONT_PARAMS );
static RTYPE compiled_block_1_1097( CONT_PARAMS );
static RTYPE compiled_start_1_15( CONT_PARAMS );
static RTYPE compiled_start_1_14( CONT_PARAMS );
static RTYPE compiled_start_1_13( CONT_PARAMS );
static RTYPE compiled_block_1_1091( CONT_PARAMS );
static RTYPE compiled_block_1_1088( CONT_PARAMS );
static RTYPE compiled_block_1_1090( CONT_PARAMS );
static RTYPE compiled_block_1_1093( CONT_PARAMS );
static RTYPE compiled_start_1_305( CONT_PARAMS );
static RTYPE compiled_start_1_12( CONT_PARAMS );
static RTYPE compiled_block_1_1082( CONT_PARAMS );
static RTYPE compiled_block_1_1079( CONT_PARAMS );
static RTYPE compiled_block_1_1081( CONT_PARAMS );
static RTYPE compiled_block_1_1084( CONT_PARAMS );
static RTYPE compiled_start_1_306( CONT_PARAMS );
static RTYPE compiled_start_1_11( CONT_PARAMS );
static RTYPE compiled_block_1_1073( CONT_PARAMS );
static RTYPE compiled_block_1_1070( CONT_PARAMS );
static RTYPE compiled_block_1_1072( CONT_PARAMS );
static RTYPE compiled_block_1_1075( CONT_PARAMS );
static RTYPE compiled_start_1_307( CONT_PARAMS );
static RTYPE compiled_block_1_1068( CONT_PARAMS );
static RTYPE compiled_start_1_10( CONT_PARAMS );
static RTYPE compiled_block_1_1060( CONT_PARAMS );
static RTYPE compiled_block_1_1061( CONT_PARAMS );
static RTYPE compiled_temp_1_311( CONT_PARAMS );
static RTYPE compiled_temp_1_310( CONT_PARAMS );
static RTYPE compiled_temp_1_309( CONT_PARAMS );
static RTYPE compiled_block_1_1062( CONT_PARAMS );
static RTYPE compiled_block_1_1063( CONT_PARAMS );
static RTYPE compiled_block_1_1058( CONT_PARAMS );
static RTYPE compiled_block_1_1059( CONT_PARAMS );
static RTYPE compiled_block_1_1056( CONT_PARAMS );
static RTYPE compiled_block_1_1057( CONT_PARAMS );
static RTYPE compiled_block_1_1053( CONT_PARAMS );
static RTYPE compiled_block_1_1054( CONT_PARAMS );
static RTYPE compiled_block_1_1055( CONT_PARAMS );
static RTYPE compiled_temp_1_308( CONT_PARAMS );
static RTYPE compiled_start_1_9( CONT_PARAMS );
static RTYPE compiled_temp_1_315( CONT_PARAMS );
static RTYPE compiled_temp_1_314( CONT_PARAMS );
static RTYPE compiled_block_1_1065( CONT_PARAMS );
static RTYPE compiled_temp_1_313( CONT_PARAMS );
static RTYPE compiled_start_1_312( CONT_PARAMS );
static RTYPE compiled_start_1_8( CONT_PARAMS );
static RTYPE compiled_block_1_1050( CONT_PARAMS );
static RTYPE compiled_block_1_1051( CONT_PARAMS );
static RTYPE compiled_start_1_316( CONT_PARAMS );
static RTYPE compiled_start_1_7( CONT_PARAMS );
static RTYPE compiled_block_1_1046( CONT_PARAMS );
static RTYPE compiled_block_1_1047( CONT_PARAMS );
static RTYPE compiled_start_1_317( CONT_PARAMS );
static RTYPE compiled_temp_1_318( CONT_PARAMS );
static RTYPE compiled_start_1_6( CONT_PARAMS );
static RTYPE compiled_block_1_1042( CONT_PARAMS );
static RTYPE compiled_temp_1_321( CONT_PARAMS );
static RTYPE compiled_block_1_1041( CONT_PARAMS );
static RTYPE compiled_temp_1_320( CONT_PARAMS );
static RTYPE compiled_start_1_319( CONT_PARAMS );
static RTYPE compiled_block_1_1032( CONT_PARAMS );
static RTYPE compiled_block_1_1030( CONT_PARAMS );
static RTYPE compiled_block_1_1035( CONT_PARAMS );
static RTYPE compiled_block_1_1034( CONT_PARAMS );
static RTYPE compiled_block_1_1031( CONT_PARAMS );
static RTYPE compiled_start_1_5( CONT_PARAMS );
static RTYPE compiled_temp_1_324( CONT_PARAMS );
static RTYPE compiled_block_1_1037( CONT_PARAMS );
static RTYPE compiled_temp_1_323( CONT_PARAMS );
static RTYPE compiled_start_1_322( CONT_PARAMS );
static RTYPE compiled_start_1_4( CONT_PARAMS );
static RTYPE compiled_block_1_1028( CONT_PARAMS );
static RTYPE compiled_block_1_1011( CONT_PARAMS );
static RTYPE compiled_start_1_2( CONT_PARAMS );
static RTYPE compiled_block_1_1013( CONT_PARAMS );
static RTYPE compiled_block_1_1015( CONT_PARAMS );
static RTYPE compiled_block_1_1017( CONT_PARAMS );
static RTYPE compiled_block_1_1019( CONT_PARAMS );
static RTYPE compiled_block_1_1023( CONT_PARAMS );
static RTYPE compiled_block_1_1022( CONT_PARAMS );
static RTYPE compiled_block_1_1021( CONT_PARAMS );
static RTYPE compiled_block_1_1020( CONT_PARAMS );
static RTYPE compiled_start_1_326( CONT_PARAMS );
static RTYPE compiled_block_1_1003( CONT_PARAMS );
static RTYPE compiled_block_1_1006( CONT_PARAMS );
static RTYPE compiled_block_1_1008( CONT_PARAMS );
static RTYPE compiled_block_1_1007( CONT_PARAMS );
static RTYPE compiled_block_1_1004( CONT_PARAMS );
static RTYPE compiled_start_1_325( CONT_PARAMS );
static RTYPE compiled_start_1_1( CONT_PARAMS );

static RTYPE compiled_start_1_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 2 ); /*  lset-diff+intersection!~1ay%kV~8918 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 3 ); /*  lset-diff+intersection~1ay%kV~8917 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 4 ); /*  lset-xor!~1ay%kV~8916 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 5 ); /*  lset-xor~1ay%kV~8915 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 6 ); /*  lset-difference!~1ay%kV~8914 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 7 ); /*  lset-difference~1ay%kV~8913 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 8 ); /*  lset-intersection!~1ay%kV~8912 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 9 ); /*  lset-intersection~1ay%kV~8911 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 10 ); /*  lset-union!~1ay%kV~8910 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 11 ); /*  lset-union~1ay%kV~8909 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 12 ); /*  lset-adjoin~1ay%kV~8908 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 13 ); /*  lset=~1ay%kV~8907 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 14 ); /*  lset<=~1ay%kV~8906 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 15 ); /*  %lset2<=~1ay%kV~8905 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 16 ); /*  reverse!~1ay%kV~8904 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 17 ); /*  list-index~1ay%kV~8903 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 18 ); /*  every~1ay%kV~8902 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 19 ); /*  any~1ay%kV~8901 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 20 ); /*  break!~1ay%kV~8900 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 21 ); /*  break~1ay%kV~8899 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 22 ); /*  span!~1ay%kV~8898 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 23 ); /*  span~1ay%kV~8897 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 24 ); /*  take-while!~1ay%kV~8896 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 25 ); /*  drop-while~1ay%kV~8895 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 26 ); /*  take-while~1ay%kV~8894 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 27 ); /*  find-tail~1ay%kV~8893 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 28 ); /*  find~1ay%kV~8892 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 29 ); /*  alist-delete!~1ay%kV~8891 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 30 ); /*  alist-delete~1ay%kV~8890 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 31 ); /*  alist-copy~1ay%kV~8889 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 32 ); /*  alist-cons~1ay%kV~8888 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 33 ); /*  assoc~1ay%kV~8887 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 34 ); /*  delete-duplicates!~1ay%kV~8886 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 35 ); /*  delete-duplicates~1ay%kV~8885 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 36 ); /*  member~1ay%kV~8884 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 37 ); /*  delete!~1ay%kV~8883 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 38 ); /*  delete~1ay%kV~8882 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 39 ); /*  remove!~1ay%kV~8881 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 40 ); /*  remove~1ay%kV~8880 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 41 ); /*  partition!~1ay%kV~8879 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 42 ); /*  partition~1ay%kV~8878 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 43 ); /*  filter!~1ay%kV~8877 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 44 ); /*  filter~1ay%kV~8876 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 45 ); /*  for-each~1ay%kV~8875 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 46 ); /*  map~1ay%kV~8874 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 47 ); /*  map-in-order~1ay%kV~8873 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 48 ); /*  filter-map~1ay%kV~8872 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 49 ); /*  map!~1ay%kV~8871 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 50 ); /*  pair-for-each~1ay%kV~8870 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 51 ); /*  really-append-map~1ay%kV~8869 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 52 ); /*  append-map!~1ay%kV~8868 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 53 ); /*  append-map~1ay%kV~8867 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 54 ); /*  reduce-right~1ay%kV~8866 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 55 ); /*  reduce~1ay%kV~8865 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 56 ); /*  pair-fold~1ay%kV~8864 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 57 ); /*  pair-fold-right~1ay%kV~8863 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 58 ); /*  fold-right~1ay%kV~8862 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 59 ); /*  fold~1ay%kV~8861 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 60 ); /*  unfold~1ay%kV~8860 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 61 ); /*  unfold-right~1ay%kV~8859 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 62 ); /*  count~1ay%kV~8858 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 63 ); /*  %cars+cdrs/no-test~1ay%kV~8857 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 64 ); /*  %cars+cdrs+~1ay%kV~8856 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 65 ); /*  %cars+cdrs~1ay%kV~8855 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 66 ); /*  %cars+~1ay%kV~8854 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 67 ); /*  %cdrs~1ay%kV~8853 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 68 ); /*  concatenate!~1ay%kV~8852 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 69 ); /*  concatenate~1ay%kV~8851 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 70 ); /*  append-reverse!~1ay%kV~8850 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 71 ); /*  append-reverse~1ay%kV~8849 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 72 ); /*  append!~1ay%kV~8848 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 73 ); /*  unzip5~1ay%kV~8847 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 74 ); /*  unzip4~1ay%kV~8846 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 75 ); /*  unzip3~1ay%kV~8845 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 76 ); /*  unzip2~1ay%kV~8844 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 77 ); /*  unzip1~1ay%kV~8843 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 78 ); /*  last-pair~1ay%kV~8842 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 79 ); /*  last~1ay%kV~8841 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 80 ); /*  split-at!~1ay%kV~8840 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 81 ); /*  split-at~1ay%kV~8839 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 82 ); /*  drop-right!~1ay%kV~8838 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 83 ); /*  drop-right~1ay%kV~8837 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 84 ); /*  take-right~1ay%kV~8836 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 85 ); /*  take!~1ay%kV~8835 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 86 ); /*  drop~1ay%kV~8834 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 87 ); /*  take~1ay%kV~8833 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 88 ); /*  car+cdr~1ay%kV~8832 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 89 ); /*  tenth~1ay%kV~8831 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 90 ); /*  ninth~1ay%kV~8830 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 91 ); /*  eighth~1ay%kV~8829 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 92 ); /*  seventh~1ay%kV~8828 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 93 ); /*  sixth~1ay%kV~8827 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 94 ); /*  fifth~1ay%kV~8826 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 95 ); /*  fourth~1ay%kV~8825 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 96 ); /*  third~1ay%kV~8824 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 97 ); /*  second~1ay%kV~8823 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 98 ); /*  first~1ay%kV~8822 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 99 ); /*  zip~1ay%kV~8821 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 100 ); /*  length+~1ay%kV~8820 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 101 ); /*  list=~1ay%kV~8819 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 102 ); /*  null-list?~1ay%kV~8818 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 103 ); /*  not-pair?~1ay%kV~8817 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 104 ); /*  circular-list?~1ay%kV~8816 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 105 ); /*  dotted-list?~1ay%kV~8815 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 106 ); /*  proper-list?~1ay%kV~8814 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 107 ); /*  circular-list~1ay%kV~8813 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 108 ); /*  iota~1ay%kV~8812 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 109 ); /*  list-copy~1ay%kV~8811 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 110 ); /*  cons*~1ay%kV~8810 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 111 ); /*  list-tabulate~1ay%kV~8809 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 112 ); /*  make-list~1ay%kV~8808 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 113 ); /*  xcons~1ay%kV~8807 */
  twobit_global( 1 ); /* ex:unspecified */
  twobit_setglbl( 114 ); /*  ignored~1ay%kV~8806 */
  twobit_lambda( compiled_start_1_1, 116, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_2, 118, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_3, 120, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 121 );
  twobit_setreg( 1 );
  twobit_const( 122 );
  twobit_setreg( 3 );
  twobit_const( 123 );
  twobit_setreg( 4 );
  twobit_const( 124 );
  twobit_setreg( 5 );
  twobit_const( 125 );
  twobit_setreg( 8 );
  twobit_global( 126 ); /* ex:make-library */
  twobit_setrtn( 2054, compiled_block_1_2054 );
  twobit_invoke( 8 );
  twobit_label( 2054, compiled_block_1_2054 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 127 ); /* ex:register-library! */
  twobit_setrtn( 2055, compiled_block_1_2055 );
  twobit_invoke( 1 );
  twobit_label( 2055, compiled_block_1_2055 );
  twobit_load( 0, 0 );
  twobit_global( 128 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* ex:uncompress */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_325, 2, 0 );
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1011, compiled_block_1_1011 );
  twobit_invoke( 2 );
  twobit_label( 1011, compiled_block_1_1011 );
  twobit_load( 0, 0 );
  twobit_lambda( compiled_start_1_326, 6, 0 );
  twobit_setreg( 2 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_global( 4 ); /* ex:register-macro! */
  twobit_setrtn( 1028, compiled_block_1_1028 );
  twobit_invoke( 2 );
  twobit_label( 1028, compiled_block_1_1028 );
  twobit_load( 0, 0 );
  twobit_global( 8 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_325( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1003, compiled_block_1_1003 ); /* internal:branchf-pair? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* list? */
  twobit_setrtn( 1004, compiled_block_1_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_1_1004 );
  twobit_load( 0, 0 );
  twobit_branchf( 1006, compiled_block_1_1006 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1007, compiled_block_1_1007 );
  twobit_invoke( 5 );
  twobit_label( 1007, compiled_block_1_1007 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 1 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 3 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 4 );
  twobit_setreg( 5 );
  twobit_global( 5 ); /* ex:syntax-rename */
  twobit_setrtn( 1008, compiled_block_1_1008 );
  twobit_invoke( 5 );
  twobit_label( 1008, compiled_block_1_1008 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1006, compiled_block_1_1006 );
  twobit_load( 1, 3 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_pop( 3 );
  twobit_invoke( 1 );
  twobit_label( 1003, compiled_block_1_1003 );
  twobit_global( 7 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_326( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1013, compiled_block_1_1013 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1015, compiled_block_1_1015 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1017, compiled_block_1_1017 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1019, compiled_block_1_1019 ); /* internal:branchf-null? */
  twobit_save( 7 );
  twobit_store( 0, 0 );
  twobit_store( 2, 3 );
  twobit_store( 3, 1 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1020, compiled_block_1_1020 );
  twobit_invoke( 5 );
  twobit_label( 1020, compiled_block_1_1020 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 7 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 2 ); /* () */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 6 );
  twobit_const( 5 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1021, compiled_block_1_1021 );
  twobit_invoke( 5 );
  twobit_label( 1021, compiled_block_1_1021 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 5 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_const( 6 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1022, compiled_block_1_1022 );
  twobit_invoke( 5 );
  twobit_label( 1022, compiled_block_1_1022 );
  twobit_load( 0, 0 );
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 3 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_stack( 1 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 3 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 4 );
  twobit_const( 3 );
  twobit_setreg( 5 );
  twobit_global( 4 ); /* ex:syntax-rename */
  twobit_setrtn( 1023, compiled_block_1_1023 );
  twobit_invoke( 5 );
  twobit_label( 1023, compiled_block_1_1023 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_load( 3, 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 4 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 5 );
  twobit_op2_58( 4 ); /* cons */
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 6 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_stack( 7 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 7 );
  twobit_return();
  twobit_label( 1019, compiled_block_1_1019 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1017, compiled_block_1_1017 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1015, compiled_block_1_1015 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_label( 1013, compiled_block_1_1013 );
  twobit_global( 8 ); /* ex:invalid-form */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 2 ); /*  lset-diff+intersection!~1ay%kV~8918 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 3 ); /*  lset-diff+intersection~1ay%kV~8917 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 4 ); /*  lset-xor!~1ay%kV~8916 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 5 ); /*  lset-xor~1ay%kV~8915 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 6 ); /*  lset-difference!~1ay%kV~8914 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 7 ); /*  lset-difference~1ay%kV~8913 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 8 ); /*  lset-intersection!~1ay%kV~8912 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 9 ); /*  lset-intersection~1ay%kV~8911 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 10 ); /*  lset-union!~1ay%kV~8910 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 11 ); /*  lset-union~1ay%kV~8909 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 12 ); /*  lset-adjoin~1ay%kV~8908 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 13 ); /*  lset=~1ay%kV~8907 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 14 ); /*  lset<=~1ay%kV~8906 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 15 ); /*  %lset2<=~1ay%kV~8905 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 16 ); /*  reverse!~1ay%kV~8904 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 17 ); /*  list-index~1ay%kV~8903 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 18 ); /*  every~1ay%kV~8902 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 19 ); /*  any~1ay%kV~8901 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 20 ); /*  break!~1ay%kV~8900 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 21 ); /*  break~1ay%kV~8899 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 22 ); /*  span!~1ay%kV~8898 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 23 ); /*  span~1ay%kV~8897 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 24 ); /*  take-while!~1ay%kV~8896 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 25 ); /*  drop-while~1ay%kV~8895 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 26 ); /*  take-while~1ay%kV~8894 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 27 ); /*  find-tail~1ay%kV~8893 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 28 ); /*  find~1ay%kV~8892 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 29 ); /*  alist-delete!~1ay%kV~8891 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 30 ); /*  alist-delete~1ay%kV~8890 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 31 ); /*  alist-copy~1ay%kV~8889 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 32 ); /*  alist-cons~1ay%kV~8888 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 33 ); /*  assoc~1ay%kV~8887 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 34 ); /*  delete-duplicates!~1ay%kV~8886 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 35 ); /*  delete-duplicates~1ay%kV~8885 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 36 ); /*  member~1ay%kV~8884 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 37 ); /*  delete!~1ay%kV~8883 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 38 ); /*  delete~1ay%kV~8882 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 39 ); /*  remove!~1ay%kV~8881 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 40 ); /*  remove~1ay%kV~8880 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 41 ); /*  partition!~1ay%kV~8879 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 42 ); /*  partition~1ay%kV~8878 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 43 ); /*  filter!~1ay%kV~8877 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 44 ); /*  filter~1ay%kV~8876 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 45 ); /*  for-each~1ay%kV~8875 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 46 ); /*  map~1ay%kV~8874 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 47 ); /*  map-in-order~1ay%kV~8873 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 48 ); /*  filter-map~1ay%kV~8872 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 49 ); /*  map!~1ay%kV~8871 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 50 ); /*  pair-for-each~1ay%kV~8870 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 51 ); /*  really-append-map~1ay%kV~8869 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 52 ); /*  append-map!~1ay%kV~8868 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 53 ); /*  append-map~1ay%kV~8867 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 54 ); /*  reduce-right~1ay%kV~8866 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 55 ); /*  reduce~1ay%kV~8865 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 56 ); /*  pair-fold~1ay%kV~8864 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 57 ); /*  pair-fold-right~1ay%kV~8863 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 58 ); /*  fold-right~1ay%kV~8862 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 59 ); /*  fold~1ay%kV~8861 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 60 ); /*  unfold~1ay%kV~8860 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 61 ); /*  unfold-right~1ay%kV~8859 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 62 ); /*  count~1ay%kV~8858 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 63 ); /*  %cars+cdrs/no-test~1ay%kV~8857 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 64 ); /*  %cars+cdrs+~1ay%kV~8856 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 65 ); /*  %cars+cdrs~1ay%kV~8855 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 66 ); /*  %cars+~1ay%kV~8854 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 67 ); /*  %cdrs~1ay%kV~8853 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 68 ); /*  concatenate!~1ay%kV~8852 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 69 ); /*  concatenate~1ay%kV~8851 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 70 ); /*  append-reverse!~1ay%kV~8850 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 71 ); /*  append-reverse~1ay%kV~8849 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 72 ); /*  append!~1ay%kV~8848 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 73 ); /*  unzip5~1ay%kV~8847 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 74 ); /*  unzip4~1ay%kV~8846 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 75 ); /*  unzip3~1ay%kV~8845 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 76 ); /*  unzip2~1ay%kV~8844 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 77 ); /*  unzip1~1ay%kV~8843 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 78 ); /*  last-pair~1ay%kV~8842 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 79 ); /*  last~1ay%kV~8841 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 80 ); /*  split-at!~1ay%kV~8840 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 81 ); /*  split-at~1ay%kV~8839 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 82 ); /*  drop-right!~1ay%kV~8838 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 83 ); /*  drop-right~1ay%kV~8837 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 84 ); /*  take-right~1ay%kV~8836 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 85 ); /*  take!~1ay%kV~8835 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 86 ); /*  drop~1ay%kV~8834 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 87 ); /*  take~1ay%kV~8833 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 88 ); /*  car+cdr~1ay%kV~8832 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 89 ); /*  tenth~1ay%kV~8831 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 90 ); /*  ninth~1ay%kV~8830 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 91 ); /*  eighth~1ay%kV~8829 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 92 ); /*  seventh~1ay%kV~8828 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 93 ); /*  sixth~1ay%kV~8827 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 94 ); /*  fifth~1ay%kV~8826 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 95 ); /*  fourth~1ay%kV~8825 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 96 ); /*  third~1ay%kV~8824 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 97 ); /*  second~1ay%kV~8823 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 98 ); /*  first~1ay%kV~8822 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 99 ); /*  zip~1ay%kV~8821 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 100 ); /*  length+~1ay%kV~8820 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 101 ); /*  list=~1ay%kV~8819 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 102 ); /*  null-list?~1ay%kV~8818 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 103 ); /*  not-pair?~1ay%kV~8817 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 104 ); /*  circular-list?~1ay%kV~8816 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 105 ); /*  dotted-list?~1ay%kV~8815 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 106 ); /*  proper-list?~1ay%kV~8814 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 107 ); /*  circular-list~1ay%kV~8813 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 108 ); /*  iota~1ay%kV~8812 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 109 ); /*  list-copy~1ay%kV~8811 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 110 ); /*  cons*~1ay%kV~8810 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 111 ); /*  list-tabulate~1ay%kV~8809 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 112 ); /*  make-list~1ay%kV~8808 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 113 ); /*  xcons~1ay%kV~8807 */
  twobit_global( 1 ); /* ex:undefined */
  twobit_setglbl( 114 ); /*  ignored~1ay%kV~8806 */
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setglbl( 115 ); /*  ignored~1ay%kV~8806 */
  twobit_lambda( compiled_start_1_4, 117, 0 );
  twobit_setglbl( 118 ); /*  xcons~1ay%kV~8807 */
  twobit_lambda( compiled_start_1_5, 120, 0 );
  twobit_setglbl( 121 ); /*  make-list~1ay%kV~8808 */
  twobit_lambda( compiled_start_1_6, 123, 0 );
  twobit_setglbl( 124 ); /*  list-tabulate~1ay%kV~8809 */
  twobit_lambda( compiled_start_1_7, 126, 0 );
  twobit_setglbl( 127 ); /*  cons*~1ay%kV~8810 */
  twobit_lambda( compiled_start_1_8, 129, 0 );
  twobit_setglbl( 130 ); /*  list-copy~1ay%kV~8811 */
  twobit_lambda( compiled_start_1_9, 132, 0 );
  twobit_setglbl( 133 ); /*  iota~1ay%kV~8812 */
  twobit_lambda( compiled_start_1_10, 135, 0 );
  twobit_setglbl( 136 ); /*  circular-list~1ay%kV~8813 */
  twobit_lambda( compiled_start_1_11, 138, 0 );
  twobit_setglbl( 139 ); /*  proper-list?~1ay%kV~8814 */
  twobit_lambda( compiled_start_1_12, 141, 0 );
  twobit_setglbl( 142 ); /*  dotted-list?~1ay%kV~8815 */
  twobit_lambda( compiled_start_1_13, 144, 0 );
  twobit_setglbl( 145 ); /*  circular-list?~1ay%kV~8816 */
  twobit_lambda( compiled_start_1_14, 147, 0 );
  twobit_setglbl( 148 ); /*  not-pair?~1ay%kV~8817 */
  twobit_lambda( compiled_start_1_15, 150, 0 );
  twobit_setglbl( 151 ); /*  null-list?~1ay%kV~8818 */
  twobit_lambda( compiled_start_1_16, 153, 0 );
  twobit_setglbl( 154 ); /*  list=~1ay%kV~8819 */
  twobit_lambda( compiled_start_1_17, 156, 0 );
  twobit_setglbl( 157 ); /*  length+~1ay%kV~8820 */
  twobit_lambda( compiled_start_1_18, 159, 0 );
  twobit_setglbl( 160 ); /*  zip~1ay%kV~8821 */
  twobit_global( 161 ); /* car */
  twobit_setglbl( 162 ); /*  first~1ay%kV~8822 */
  twobit_global( 163 ); /* cadr */
  twobit_setglbl( 164 ); /*  second~1ay%kV~8823 */
  twobit_global( 165 ); /* caddr */
  twobit_setglbl( 166 ); /*  third~1ay%kV~8824 */
  twobit_global( 167 ); /* cadddr */
  twobit_setglbl( 168 ); /*  fourth~1ay%kV~8825 */
  twobit_lambda( compiled_start_1_19, 170, 0 );
  twobit_setglbl( 171 ); /*  fifth~1ay%kV~8826 */
  twobit_lambda( compiled_start_1_20, 173, 0 );
  twobit_setglbl( 174 ); /*  sixth~1ay%kV~8827 */
  twobit_lambda( compiled_start_1_21, 176, 0 );
  twobit_setglbl( 177 ); /*  seventh~1ay%kV~8828 */
  twobit_lambda( compiled_start_1_22, 179, 0 );
  twobit_setglbl( 180 ); /*  eighth~1ay%kV~8829 */
  twobit_lambda( compiled_start_1_23, 182, 0 );
  twobit_setglbl( 183 ); /*  ninth~1ay%kV~8830 */
  twobit_lambda( compiled_start_1_24, 185, 0 );
  twobit_setglbl( 186 ); /*  tenth~1ay%kV~8831 */
  twobit_lambda( compiled_start_1_25, 188, 0 );
  twobit_setglbl( 189 ); /*  car+cdr~1ay%kV~8832 */
  twobit_lambda( compiled_start_1_26, 191, 0 );
  twobit_setglbl( 192 ); /*  take~1ay%kV~8833 */
  twobit_lambda( compiled_start_1_27, 194, 0 );
  twobit_setglbl( 195 ); /*  drop~1ay%kV~8834 */
  twobit_lambda( compiled_start_1_28, 197, 0 );
  twobit_setglbl( 198 ); /*  take!~1ay%kV~8835 */
  twobit_lambda( compiled_start_1_29, 200, 0 );
  twobit_setglbl( 201 ); /*  take-right~1ay%kV~8836 */
  twobit_lambda( compiled_start_1_30, 203, 0 );
  twobit_setglbl( 204 ); /*  drop-right~1ay%kV~8837 */
  twobit_lambda( compiled_start_1_31, 206, 0 );
  twobit_setglbl( 207 ); /*  drop-right!~1ay%kV~8838 */
  twobit_lambda( compiled_start_1_32, 209, 0 );
  twobit_setglbl( 210 ); /*  split-at~1ay%kV~8839 */
  twobit_lambda( compiled_start_1_33, 212, 0 );
  twobit_setglbl( 213 ); /*  split-at!~1ay%kV~8840 */
  twobit_lambda( compiled_start_1_34, 215, 0 );
  twobit_setglbl( 216 ); /*  last~1ay%kV~8841 */
  twobit_lambda( compiled_start_1_35, 218, 0 );
  twobit_setglbl( 219 ); /*  last-pair~1ay%kV~8842 */
  twobit_lambda( compiled_start_1_36, 221, 0 );
  twobit_setglbl( 222 ); /*  unzip1~1ay%kV~8843 */
  twobit_lambda( compiled_start_1_37, 224, 0 );
  twobit_setglbl( 225 ); /*  unzip2~1ay%kV~8844 */
  twobit_lambda( compiled_start_1_38, 227, 0 );
  twobit_setglbl( 228 ); /*  unzip3~1ay%kV~8845 */
  twobit_lambda( compiled_start_1_39, 230, 0 );
  twobit_setglbl( 231 ); /*  unzip4~1ay%kV~8846 */
  twobit_lambda( compiled_start_1_40, 233, 0 );
  twobit_setglbl( 234 ); /*  unzip5~1ay%kV~8847 */
  twobit_lambda( compiled_start_1_41, 236, 0 );
  twobit_setglbl( 237 ); /*  append!~1ay%kV~8848 */
  twobit_lambda( compiled_start_1_42, 239, 0 );
  twobit_setglbl( 240 ); /*  append-reverse~1ay%kV~8849 */
  twobit_lambda( compiled_start_1_43, 242, 0 );
  twobit_setglbl( 243 ); /*  append-reverse!~1ay%kV~8850 */
  twobit_lambda( compiled_start_1_44, 245, 0 );
  twobit_setglbl( 246 ); /*  concatenate~1ay%kV~8851 */
  twobit_lambda( compiled_start_1_45, 248, 0 );
  twobit_setglbl( 249 ); /*  concatenate!~1ay%kV~8852 */
  twobit_lambda( compiled_start_1_46, 251, 0 );
  twobit_setglbl( 252 ); /*  %cdrs~1ay%kV~8853 */
  twobit_lambda( compiled_start_1_47, 254, 0 );
  twobit_setglbl( 255 ); /*  %cars+~1ay%kV~8854 */
  twobit_lambda( compiled_start_1_48, 257, 0 );
  twobit_setglbl( 258 ); /*  %cars+cdrs~1ay%kV~8855 */
  twobit_lambda( compiled_start_1_49, 260, 0 );
  twobit_setglbl( 261 ); /*  %cars+cdrs+~1ay%kV~8856 */
  twobit_lambda( compiled_start_1_50, 263, 0 );
  twobit_setglbl( 264 ); /*  %cars+cdrs/no-test~1ay%kV~8857 */
  twobit_lambda( compiled_start_1_51, 266, 0 );
  twobit_setglbl( 267 ); /*  count~1ay%kV~8858 */
  twobit_lambda( compiled_start_1_52, 269, 0 );
  twobit_setglbl( 270 ); /*  unfold-right~1ay%kV~8859 */
  twobit_lambda( compiled_start_1_53, 272, 0 );
  twobit_setglbl( 273 ); /*  unfold~1ay%kV~8860 */
  twobit_lambda( compiled_start_1_54, 275, 0 );
  twobit_setglbl( 276 ); /*  fold~1ay%kV~8861 */
  twobit_lambda( compiled_start_1_55, 278, 0 );
  twobit_setglbl( 279 ); /*  fold-right~1ay%kV~8862 */
  twobit_lambda( compiled_start_1_56, 281, 0 );
  twobit_setglbl( 282 ); /*  pair-fold-right~1ay%kV~8863 */
  twobit_lambda( compiled_start_1_57, 284, 0 );
  twobit_setglbl( 285 ); /*  pair-fold~1ay%kV~8864 */
  twobit_lambda( compiled_start_1_58, 287, 0 );
  twobit_setglbl( 288 ); /*  reduce~1ay%kV~8865 */
  twobit_lambda( compiled_start_1_59, 290, 0 );
  twobit_setglbl( 291 ); /*  reduce-right~1ay%kV~8866 */
  twobit_lambda( compiled_start_1_60, 293, 0 );
  twobit_setglbl( 294 ); /*  append-map~1ay%kV~8867 */
  twobit_lambda( compiled_start_1_61, 296, 0 );
  twobit_setglbl( 297 ); /*  append-map!~1ay%kV~8868 */
  twobit_lambda( compiled_start_1_62, 299, 0 );
  twobit_setglbl( 300 ); /*  really-append-map~1ay%kV~8869 */
  twobit_lambda( compiled_start_1_63, 302, 0 );
  twobit_setglbl( 303 ); /*  pair-for-each~1ay%kV~8870 */
  twobit_lambda( compiled_start_1_64, 305, 0 );
  twobit_setglbl( 49 ); /*  map!~1ay%kV~8871 */
  twobit_lambda( compiled_start_1_65, 307, 0 );
  twobit_setglbl( 48 ); /*  filter-map~1ay%kV~8872 */
  twobit_lambda( compiled_start_1_66, 309, 0 );
  twobit_setglbl( 47 ); /*  map-in-order~1ay%kV~8873 */
  twobit_global( 47 ); /*  map-in-order~1ay%kV~8873 */
  twobit_setglbl( 46 ); /*  map~1ay%kV~8874 */
  twobit_lambda( compiled_start_1_67, 311, 0 );
  twobit_setglbl( 45 ); /*  for-each~1ay%kV~8875 */
  twobit_lambda( compiled_start_1_68, 313, 0 );
  twobit_setglbl( 44 ); /*  filter~1ay%kV~8876 */
  twobit_lambda( compiled_start_1_69, 315, 0 );
  twobit_setglbl( 43 ); /*  filter!~1ay%kV~8877 */
  twobit_lambda( compiled_start_1_70, 317, 0 );
  twobit_setglbl( 42 ); /*  partition~1ay%kV~8878 */
  twobit_lambda( compiled_start_1_71, 319, 0 );
  twobit_setglbl( 41 ); /*  partition!~1ay%kV~8879 */
  twobit_lambda( compiled_start_1_72, 321, 0 );
  twobit_setglbl( 40 ); /*  remove~1ay%kV~8880 */
  twobit_lambda( compiled_start_1_73, 323, 0 );
  twobit_setglbl( 39 ); /*  remove!~1ay%kV~8881 */
  twobit_lambda( compiled_start_1_74, 325, 0 );
  twobit_setglbl( 38 ); /*  delete~1ay%kV~8882 */
  twobit_lambda( compiled_start_1_75, 327, 0 );
  twobit_setglbl( 37 ); /*  delete!~1ay%kV~8883 */
  twobit_lambda( compiled_start_1_76, 329, 0 );
  twobit_setglbl( 36 ); /*  member~1ay%kV~8884 */
  twobit_lambda( compiled_start_1_77, 331, 0 );
  twobit_setglbl( 35 ); /*  delete-duplicates~1ay%kV~8885 */
  twobit_lambda( compiled_start_1_78, 333, 0 );
  twobit_setglbl( 34 ); /*  delete-duplicates!~1ay%kV~8886 */
  twobit_lambda( compiled_start_1_79, 335, 0 );
  twobit_setglbl( 33 ); /*  assoc~1ay%kV~8887 */
  twobit_lambda( compiled_start_1_80, 337, 0 );
  twobit_setglbl( 32 ); /*  alist-cons~1ay%kV~8888 */
  twobit_lambda( compiled_start_1_81, 339, 0 );
  twobit_setglbl( 31 ); /*  alist-copy~1ay%kV~8889 */
  twobit_lambda( compiled_start_1_82, 341, 0 );
  twobit_setglbl( 30 ); /*  alist-delete~1ay%kV~8890 */
  twobit_lambda( compiled_start_1_83, 343, 0 );
  twobit_setglbl( 29 ); /*  alist-delete!~1ay%kV~8891 */
  twobit_lambda( compiled_start_1_84, 345, 0 );
  twobit_setglbl( 28 ); /*  find~1ay%kV~8892 */
  twobit_lambda( compiled_start_1_85, 347, 0 );
  twobit_setglbl( 27 ); /*  find-tail~1ay%kV~8893 */
  twobit_lambda( compiled_start_1_86, 349, 0 );
  twobit_setglbl( 26 ); /*  take-while~1ay%kV~8894 */
  twobit_lambda( compiled_start_1_87, 351, 0 );
  twobit_setglbl( 25 ); /*  drop-while~1ay%kV~8895 */
  twobit_lambda( compiled_start_1_88, 353, 0 );
  twobit_setglbl( 24 ); /*  take-while!~1ay%kV~8896 */
  twobit_lambda( compiled_start_1_89, 355, 0 );
  twobit_setglbl( 23 ); /*  span~1ay%kV~8897 */
  twobit_lambda( compiled_start_1_90, 357, 0 );
  twobit_setglbl( 22 ); /*  span!~1ay%kV~8898 */
  twobit_lambda( compiled_start_1_91, 359, 0 );
  twobit_setglbl( 21 ); /*  break~1ay%kV~8899 */
  twobit_lambda( compiled_start_1_92, 361, 0 );
  twobit_setglbl( 20 ); /*  break!~1ay%kV~8900 */
  twobit_lambda( compiled_start_1_93, 363, 0 );
  twobit_setglbl( 19 ); /*  any~1ay%kV~8901 */
  twobit_lambda( compiled_start_1_94, 365, 0 );
  twobit_setglbl( 18 ); /*  every~1ay%kV~8902 */
  twobit_lambda( compiled_start_1_95, 367, 0 );
  twobit_setglbl( 17 ); /*  list-index~1ay%kV~8903 */
  twobit_lambda( compiled_start_1_96, 369, 0 );
  twobit_setglbl( 16 ); /*  reverse!~1ay%kV~8904 */
  twobit_lambda( compiled_start_1_97, 371, 0 );
  twobit_setglbl( 15 ); /*  %lset2<=~1ay%kV~8905 */
  twobit_lambda( compiled_start_1_98, 373, 0 );
  twobit_setglbl( 14 ); /*  lset<=~1ay%kV~8906 */
  twobit_lambda( compiled_start_1_99, 375, 0 );
  twobit_setglbl( 13 ); /*  lset=~1ay%kV~8907 */
  twobit_lambda( compiled_start_1_100, 377, 0 );
  twobit_setglbl( 12 ); /*  lset-adjoin~1ay%kV~8908 */
  twobit_lambda( compiled_start_1_101, 379, 0 );
  twobit_setglbl( 11 ); /*  lset-union~1ay%kV~8909 */
  twobit_lambda( compiled_start_1_102, 381, 0 );
  twobit_setglbl( 10 ); /*  lset-union!~1ay%kV~8910 */
  twobit_lambda( compiled_start_1_103, 383, 0 );
  twobit_setglbl( 9 ); /*  lset-intersection~1ay%kV~8911 */
  twobit_lambda( compiled_start_1_104, 385, 0 );
  twobit_setglbl( 8 ); /*  lset-intersection!~1ay%kV~8912 */
  twobit_lambda( compiled_start_1_105, 387, 0 );
  twobit_setglbl( 7 ); /*  lset-difference~1ay%kV~8913 */
  twobit_lambda( compiled_start_1_106, 389, 0 );
  twobit_setglbl( 6 ); /*  lset-difference!~1ay%kV~8914 */
  twobit_lambda( compiled_start_1_107, 391, 0 );
  twobit_setglbl( 5 ); /*  lset-xor~1ay%kV~8915 */
  twobit_lambda( compiled_start_1_108, 393, 0 );
  twobit_setglbl( 4 ); /*  lset-xor!~1ay%kV~8916 */
  twobit_lambda( compiled_start_1_109, 395, 0 );
  twobit_setglbl( 3 ); /*  lset-diff+intersection~1ay%kV~8917 */
  twobit_lambda( compiled_start_1_110, 397, 0 );
  twobit_setglbl( 2 ); /*  lset-diff+intersection!~1ay%kV~8918 */
  twobit_global( 398 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_4( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op2_58( 1 ); /* cons */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_5( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1031, compiled_block_1_1031 ); /* internal:branchf-null? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1030, compiled_block_1_1030 );
  twobit_label( 1031, compiled_block_1_1031 );
  twobit_reg_op1_check_652(reg(2),1032,compiled_block_1_1032); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_610( 1034, compiled_block_1_1034 ); /* internal:branchf-null? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 1030, compiled_block_1_1030 );
  twobit_label( 1034, compiled_block_1_1034 );
  twobit_reg( 1 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* error */
  twobit_setrtn( 1035, compiled_block_1_1035 );
  twobit_invoke( 2 );
  twobit_label( 1035, compiled_block_1_1035 );
  twobit_load( 0, 0 );
  twobit_label( 1030, compiled_block_1_1030 );
  twobit_setreg( 4 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_322, 5, 2 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1032, compiled_block_1_1032 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_322( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_638( fixnum(0), 323, compiled_temp_1_323, 1037, compiled_block_1_1037 ); /* internal:branchf-<=/imm */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1037, compiled_block_1_1037 );
  twobit_reg( 1 );
  twobit_op2imm_131( fixnum(1), 324, compiled_temp_1_324 ); /* - */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_6( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op2imm_131( fixnum(1), 318, compiled_temp_1_318 ); /* - */
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_319, 3, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_319( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(0), 320, compiled_temp_1_320, 1041, compiled_block_1_1041 ); /* internal:branchf-</imm */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1041, compiled_block_1_1041 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_reg( 1 );
  twobit_op2imm_131( fixnum(1), 321, compiled_temp_1_321 ); /* - */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1042, compiled_block_1_1042 );
  twobit_invoke( 1 );
  twobit_label( 1042, compiled_block_1_1042 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 3, 2 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_7( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_317, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_317( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1046, compiled_block_1_1046 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1047, compiled_block_1_1047 );
  twobit_invoke( 2 );
  twobit_label( 1047, compiled_block_1_1047 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1046, compiled_block_1_1046 );
  twobit_reg( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_8( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_316, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_316( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1050, compiled_block_1_1050 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1051, compiled_block_1_1051 );
  twobit_invoke( 1 );
  twobit_label( 1051, compiled_block_1_1051 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1050, compiled_block_1_1050 );
  twobit_reg( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_9( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_635( fixnum(0), 308, compiled_temp_1_308, 1054, compiled_block_1_1054 ); /* internal:branchf-</imm */
  twobit_movereg( 1, 3 );
  twobit_global( 1 ); /*  iota~1ay%kV~8812 */
  twobit_setreg( 2 );
  twobit_const( 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* error */
  twobit_setrtn( 1055, compiled_block_1_1055 );
  twobit_invoke( 3 );
  twobit_label( 1055, compiled_block_1_1055 );
  twobit_load( 0, 0 );
  twobit_skip( 1053, compiled_block_1_1053 );
  twobit_label( 1054, compiled_block_1_1054 );
  twobit_op1_3(); /* unspecified */
  twobit_label( 1053, compiled_block_1_1053 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1057, compiled_block_1_1057 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_11(); /* pair? */
  twobit_skip( 1056, compiled_block_1_1056 );
  twobit_label( 1057, compiled_block_1_1057 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1056, compiled_block_1_1056 );
  twobit_branchf( 1059, compiled_block_1_1059 );
  twobit_reg( 4 );
  twobit_load( 2, 1 );
  twobit_check( 2, 0, 0, 1060, compiled_block_1_1060 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg_op1_check_652(reg(3),1061,compiled_block_1_1061); /* internal:check-pair? with (3 0 0) */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 1058, compiled_block_1_1058 );
  twobit_label( 1059, compiled_block_1_1059 );
  twobit_imm_const( fixnum(1) ); /* 1 */
  twobit_label( 1058, compiled_block_1_1058 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_branchf( 1063, compiled_block_1_1063 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 1062, compiled_block_1_1062 );
  twobit_label( 1063, compiled_block_1_1063 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_label( 1062, compiled_block_1_1062 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2imm_131( fixnum(1), 309, compiled_temp_1_309 ); /* - */
  twobit_op2_63( 3, 310, compiled_temp_1_310 ); /* * */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op2_61( 2, 311, compiled_temp_1_311 ); /* + */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_global( 4 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 3, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_312, 6, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_load( 2, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1061, compiled_block_1_1061 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_label( 1060, compiled_block_1_1060 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_312( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op2imm_branchf_638( fixnum(0), 313, compiled_temp_1_313, 1065, compiled_block_1_1065 ); /* internal:branchf-<=/imm */
  twobit_reg( 3 );
  twobit_return();
  twobit_label( 1065, compiled_block_1_1065 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op2imm_131( fixnum(1), 314, compiled_temp_1_314 ); /* - */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_62( 4, 315, compiled_temp_1_315 ); /* - */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_10( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /*  last-pair~1ay%kV~8842 */
  twobit_setrtn( 1068, compiled_block_1_1068 );
  twobit_invoke( 1 );
  twobit_label( 1068, compiled_block_1_1068 );
  twobit_load( 0, 0 );
  twobit_load( 3, 1 );
  twobit_op2_60( 3 ); /* set-cdr! */
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_11( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_307, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_307( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1070, compiled_block_1_1070 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1072, compiled_block_1_1072 ); /* internal:branchf-pair? */
  twobit_reg_op1_check_652(reg(2),1073,compiled_block_1_1073); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 1075, compiled_block_1_1075 ); /* internal:branchf-eq? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1075, compiled_block_1_1075 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_movereg( 3, 31 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 31, 2 );
  twobit_reg( 3 );
  twobit_invoke( 2 );
  twobit_label( 1072, compiled_block_1_1072 );
  twobit_reg( 4 );
  twobit_op1_10(); /* null? */
  twobit_return();
  twobit_label( 1070, compiled_block_1_1070 );
  twobit_reg( 1 );
  twobit_op1_10(); /* null? */
  twobit_return();
  twobit_label( 1073, compiled_block_1_1073 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_12( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_306, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_306( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1079, compiled_block_1_1079 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1081, compiled_block_1_1081 ); /* internal:branchf-pair? */
  twobit_reg_op1_check_652(reg(2),1082,compiled_block_1_1082); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2_branchf_624( 3, 1084, compiled_block_1_1084 ); /* internal:branchf-eq? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1084, compiled_block_1_1084 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_movereg( 3, 31 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 31, 2 );
  twobit_reg( 3 );
  twobit_invoke( 2 );
  twobit_label( 1081, compiled_block_1_1081 );
  twobit_reg( 4 );
  twobit_op1_10(); /* null? */
  twobit_op1_9(); /* not */
  twobit_return();
  twobit_label( 1079, compiled_block_1_1079 );
  twobit_reg( 1 );
  twobit_op1_10(); /* null? */
  twobit_op1_9(); /* not */
  twobit_return();
  twobit_label( 1082, compiled_block_1_1082 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_13( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_305, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_305( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1088, compiled_block_1_1088 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1090, compiled_block_1_1090 ); /* internal:branchf-pair? */
  twobit_reg_op1_check_652(reg(2),1091,compiled_block_1_1091); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op2_56( 3 ); /* eq? */
  twobit_setreg( 2 );
  twobit_reg( 2 );
  twobit_branchf( 1093, compiled_block_1_1093 );
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1093, compiled_block_1_1093 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_movereg( 3, 31 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 31, 2 );
  twobit_reg( 3 );
  twobit_invoke( 2 );
  twobit_label( 1090, compiled_block_1_1090 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1088, compiled_block_1_1088 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1091, compiled_block_1_1091 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_14( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_11(); /* pair? */
  twobit_op1_9(); /* not */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_15( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1097, compiled_block_1_1097 ); /* internal:branchf-pair? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1097, compiled_block_1_1097 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1099, compiled_block_1_1099 ); /* internal:branchf-null? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_return();
  twobit_label( 1099, compiled_block_1_1099 );
  twobit_movereg( 1, 2 );
  twobit_const( 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* error */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_16( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_reg( 2 );
  twobit_op1_10(); /* null? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1102, compiled_block_1_1102 );
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1102, compiled_block_1_1102 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_reg_op1_check_652(reg(2),1103,compiled_block_1_1103); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_1_303, 3, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 4, 1 );
  twobit_load( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1103, compiled_block_1_1103 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_303( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_10(); /* null? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1105, compiled_block_1_1105 );
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1105, compiled_block_1_1105 );
  twobit_reg_op1_check_652(reg(2),1106,compiled_block_1_1106); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 3, 1108, compiled_block_1_1108 ); /* internal:branchf-eq? */
  twobit_movereg( 4, 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_movereg( 3, 1 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 1108, compiled_block_1_1108 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_304, 3, 3 );
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_movereg( 3, 2 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1106, compiled_block_1_1106 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_304( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1110, compiled_block_1_1110 );
  twobit_invoke( 1 );
  twobit_label( 1110, compiled_block_1_1110 );
  twobit_load( 0, 0 );
  twobit_branchf( 1112, compiled_block_1_1112 );
  twobit_load( 1, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1113, compiled_block_1_1113 );
  twobit_invoke( 1 );
  twobit_label( 1113, compiled_block_1_1113 );
  twobit_load( 0, 0 );
  twobit_branchf( 1115, compiled_block_1_1115 );
  twobit_lexical( 1, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_lexical( 0, 3 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1115, compiled_block_1_1115 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1112, compiled_block_1_1112 );
  twobit_load( 1, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1117, compiled_block_1_1117 );
  twobit_invoke( 1 );
  twobit_label( 1117, compiled_block_1_1117 );
  twobit_load( 0, 0 );
  twobit_branchf( 1119, compiled_block_1_1119 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1119, compiled_block_1_1119 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 2 );
  twobit_check( 3, 0, 0, 1120, compiled_block_1_1120 );
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1120, compiled_block_1_1120 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setrtn( 1121, compiled_block_1_1121 );
  twobit_invoke( 2 );
  twobit_label( 1121, compiled_block_1_1121 );
  twobit_load( 0, 0 );
  twobit_branchf( 1123, compiled_block_1_1123 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1123, compiled_block_1_1123 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1120, compiled_block_1_1120 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_17( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_300, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_300( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1128, compiled_block_1_1128 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op2imm_130( fixnum(1), 301, compiled_temp_1_301 ); /* + */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1130, compiled_block_1_1130 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op2imm_130( fixnum(1), 302, compiled_temp_1_302 ); /* + */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(2),1131,compiled_block_1_1131); /* internal:check-pair? with (2 0 0) */
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_op2_branchf_624( 2, 1133, compiled_block_1_1133 ); /* internal:branchf-eq? */
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_label( 1133, compiled_block_1_1133 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_movereg( 4, 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_label( 1130, compiled_block_1_1130 );
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1128, compiled_block_1_1128 );
  twobit_reg( 3 );
  twobit_return();
  twobit_label( 1131, compiled_block_1_1131 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_18( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_movereg( 1, 3 );
  twobit_movereg( 2, 4 );
  twobit_global( 1 ); /*  map~1ay%kV~8874 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /* list */
  twobit_setreg( 2 );
  twobit_global( 3 ); /* apply */
  twobit_invoke( 4 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_19( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op1_check_652(reg(1),1137,compiled_block_1_1137); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1138,compiled_block_1_1138); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1138,compiled_block_1_1138); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1138,compiled_block_1_1138); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1139,compiled_block_1_1139); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_return();
  twobit_label( 1139, compiled_block_1_1139 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 1137, compiled_block_1_1137 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_label( 1138, compiled_block_1_1138 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_20( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op1_check_652(reg(1),1140,compiled_block_1_1140); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1141,compiled_block_1_1141); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1141,compiled_block_1_1141); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1141,compiled_block_1_1141); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1141,compiled_block_1_1141); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1142,compiled_block_1_1142); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_return();
  twobit_label( 1142, compiled_block_1_1142 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 1140, compiled_block_1_1140 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_label( 1141, compiled_block_1_1141 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_21( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op1_check_652(reg(1),1143,compiled_block_1_1143); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1144,compiled_block_1_1144); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1144,compiled_block_1_1144); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1144,compiled_block_1_1144); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1144,compiled_block_1_1144); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1144,compiled_block_1_1144); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1145,compiled_block_1_1145); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_return();
  twobit_label( 1145, compiled_block_1_1145 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 1143, compiled_block_1_1143 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_label( 1144, compiled_block_1_1144 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_22( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op1_check_652(reg(1),1146,compiled_block_1_1146); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1147,compiled_block_1_1147); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1147,compiled_block_1_1147); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1147,compiled_block_1_1147); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1147,compiled_block_1_1147); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1147,compiled_block_1_1147); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1147,compiled_block_1_1147); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1148,compiled_block_1_1148); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_return();
  twobit_label( 1148, compiled_block_1_1148 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 1146, compiled_block_1_1146 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_label( 1147, compiled_block_1_1147 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_23( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op1_check_652(reg(1),1149,compiled_block_1_1149); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1150,compiled_block_1_1150); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1150,compiled_block_1_1150); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1150,compiled_block_1_1150); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1150,compiled_block_1_1150); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1150,compiled_block_1_1150); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1150,compiled_block_1_1150); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1150,compiled_block_1_1150); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1151,compiled_block_1_1151); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_return();
  twobit_label( 1151, compiled_block_1_1151 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 1149, compiled_block_1_1149 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_label( 1150, compiled_block_1_1150 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_24( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op1_check_652(reg(1),1152,compiled_block_1_1152); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1153,compiled_block_1_1153); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1153,compiled_block_1_1153); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1153,compiled_block_1_1153); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1153,compiled_block_1_1153); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1153,compiled_block_1_1153); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1153,compiled_block_1_1153); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1153,compiled_block_1_1153); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1153,compiled_block_1_1153); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1154,compiled_block_1_1154); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_return();
  twobit_label( 1154, compiled_block_1_1154 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 1152, compiled_block_1_1152 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_label( 1153, compiled_block_1_1153 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_25( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op1_check_652(reg(1),1155,compiled_block_1_1155); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1155, compiled_block_1_1155 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_26( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_297, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_297( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_612( 298, compiled_temp_1_298, 1158, compiled_block_1_1158 ); /* internal:branchf-zero? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_label( 1158, compiled_block_1_1158 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg_op1_check_652(reg(1),1159,compiled_block_1_1159); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op2imm_131( fixnum(1), 299, compiled_temp_1_299 ); /* - */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1160, compiled_block_1_1160 );
  twobit_invoke( 2 );
  twobit_label( 1160, compiled_block_1_1160 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1159, compiled_block_1_1159 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_27( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_294, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_294( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_612( 295, compiled_temp_1_295, 1163, compiled_block_1_1163 ); /* internal:branchf-zero? */
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1163, compiled_block_1_1163 );
  twobit_reg_op1_check_652(reg(1),1164,compiled_block_1_1164); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op2imm_131( fixnum(1), 296, compiled_temp_1_296 ); /* - */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 1164, compiled_block_1_1164 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_28( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_612( 292, compiled_temp_1_292, 1168, compiled_block_1_1168 ); /* internal:branchf-zero? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_label( 1168, compiled_block_1_1168 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 2 );
  twobit_op2imm_131( fixnum(1), 293, compiled_temp_1_293 ); /* - */
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  drop~1ay%kV~8834 */
  twobit_setrtn( 1169, compiled_block_1_1169 );
  twobit_invoke( 2 );
  twobit_label( 1169, compiled_block_1_1169 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_60( 3 ); /* set-cdr! */
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_29( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  drop~1ay%kV~8834 */
  twobit_setrtn( 1170, compiled_block_1_1170 );
  twobit_invoke( 2 );
  twobit_label( 1170, compiled_block_1_1170 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_291, 4, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_291( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1172, compiled_block_1_1172 ); /* internal:branchf-pair? */
  twobit_reg_op1_check_652(reg(1),1173,compiled_block_1_1173); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 1172, compiled_block_1_1172 );
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1173, compiled_block_1_1173 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_30( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  drop~1ay%kV~8834 */
  twobit_setrtn( 1176, compiled_block_1_1176 );
  twobit_invoke( 2 );
  twobit_label( 1176, compiled_block_1_1176 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_290, 4, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_290( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1178, compiled_block_1_1178 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg_op1_check_652(reg(1),1179,compiled_block_1_1179); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1180, compiled_block_1_1180 );
  twobit_invoke( 2 );
  twobit_label( 1180, compiled_block_1_1180 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1178, compiled_block_1_1178 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_label( 1179, compiled_block_1_1179 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_31( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  drop~1ay%kV~8834 */
  twobit_setrtn( 1182, compiled_block_1_1182 );
  twobit_invoke( 2 );
  twobit_label( 1182, compiled_block_1_1182 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1184, compiled_block_1_1184 ); /* internal:branchf-pair? */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_289, 4, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1184, compiled_block_1_1184 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_289( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1186, compiled_block_1_1186 ); /* internal:branchf-pair? */
  twobit_reg_op1_check_652(reg(1),1187,compiled_block_1_1187); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 1186, compiled_block_1_1186 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op2_60( 4 ); /* set-cdr! */
  twobit_lexical( 0, 1 );
  twobit_return();
  twobit_label( 1187, compiled_block_1_1187 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_32( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_284, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_284( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_612( 285, compiled_temp_1_285, 1191, compiled_block_1_1191 ); /* internal:branchf-zero? */
  twobit_movereg( 1, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1191, compiled_block_1_1191 );
  twobit_lambda( compiled_start_1_286, 3, 2 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_287, 5, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 6 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_286( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 1193, compiled_block_1_1193 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op2imm_131( fixnum(1), 288, compiled_temp_1_288 ); /* - */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 2 );
  twobit_label( 1193, compiled_block_1_1193 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_287( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 1195, compiled_block_1_1195 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1195, compiled_block_1_1195 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_33( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_612( 282, compiled_temp_1_282, 1200, compiled_block_1_1200 ); /* internal:branchf-zero? */
  twobit_movereg( 1, 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1200, compiled_block_1_1200 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 2 );
  twobit_op2imm_131( fixnum(1), 283, compiled_temp_1_283 ); /* - */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  drop~1ay%kV~8834 */
  twobit_setrtn( 1202, compiled_block_1_1202 );
  twobit_invoke( 2 );
  twobit_label( 1202, compiled_block_1_1202 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1203,compiled_block_1_1203); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_60( 3 ); /* set-cdr! */
  twobit_load( 1, 1 );
  twobit_global( 1 ); /* values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1203, compiled_block_1_1203 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_34( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  last-pair~1ay%kV~8842 */
  twobit_setrtn( 1205, compiled_block_1_1205 );
  twobit_invoke( 1 );
  twobit_label( 1205, compiled_block_1_1205 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1206,compiled_block_1_1206); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1206, compiled_block_1_1206 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_35( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_281, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_281( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op1_check_652(reg(1),1207,compiled_block_1_1207); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1209, compiled_block_1_1209 ); /* internal:branchf-pair? */
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_movereg( 4, 1 );
  twobit_reg( 3 );
  twobit_invoke( 1 );
  twobit_label( 1209, compiled_block_1_1209 );
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1207, compiled_block_1_1207 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_36( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_movereg( 1, 2 );
  twobit_global( 1 ); /* car */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  map~1ay%kV~8874 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_37( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_278, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_278( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1213, compiled_block_1_1213 );
  twobit_invoke( 1 );
  twobit_label( 1213, compiled_block_1_1213 );
  twobit_load( 0, 0 );
  twobit_branchf( 1215, compiled_block_1_1215 );
  twobit_load( 2, 1 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1215, compiled_block_1_1215 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1217, compiled_block_1_1217 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_279, 4, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_280, 6, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 7 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1217, compiled_block_1_1217 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_279( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_280( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 3 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_check( 4, 0, 0, 1219, compiled_block_1_1219 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1219,compiled_block_1_1219); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_label( 1219, compiled_block_1_1219 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_38( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_275, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_275( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1223, compiled_block_1_1223 );
  twobit_invoke( 1 );
  twobit_label( 1223, compiled_block_1_1223 );
  twobit_load( 0, 0 );
  twobit_branchf( 1225, compiled_block_1_1225 );
  twobit_load( 2, 1 );
  twobit_load( 3, 1 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* values */
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1225, compiled_block_1_1225 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1227, compiled_block_1_1227 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_276, 4, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_277, 6, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 7 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1227, compiled_block_1_1227 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_276( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_277( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 31 );
  twobit_reg( 4 );
  twobit_check( 31, 0, 0, 1229, compiled_block_1_1229 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1230,compiled_block_1_1230); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1230,compiled_block_1_1230); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 3 );
  twobit_label( 1230, compiled_block_1_1230 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_label( 1229, compiled_block_1_1229 );
  twobit_trap( 31, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_39( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_272, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_272( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1234, compiled_block_1_1234 );
  twobit_invoke( 1 );
  twobit_label( 1234, compiled_block_1_1234 );
  twobit_load( 0, 0 );
  twobit_branchf( 1236, compiled_block_1_1236 );
  twobit_load( 2, 1 );
  twobit_load( 3, 1 );
  twobit_load( 4, 1 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* values */
  twobit_pop( 2 );
  twobit_invoke( 4 );
  twobit_label( 1236, compiled_block_1_1236 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1238, compiled_block_1_1238 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_273, 4, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_274, 6, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 7 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1238, compiled_block_1_1238 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_273( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_274( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 4 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 31 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 30, 0, 0, 1240, compiled_block_1_1240 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg_op1_check_652(reg(31),1241,compiled_block_1_1241); /* internal:check-pair? with (31 0 0) */
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_reg( 31 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg_op1_check_652(reg(31),1241,compiled_block_1_1241); /* internal:check-pair? with (31 0 0) */
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 31 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg_op1_check_652(reg(31),1241,compiled_block_1_1241); /* internal:check-pair? with (31 0 0) */
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 4 );
  twobit_label( 1241, compiled_block_1_1241 );
  twobit_trap( 31, 0, 0, 0 );
  twobit_label( 1240, compiled_block_1_1240 );
  twobit_trap( 30, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_40( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_269, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_269( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1245, compiled_block_1_1245 );
  twobit_invoke( 1 );
  twobit_label( 1245, compiled_block_1_1245 );
  twobit_load( 0, 0 );
  twobit_branchf( 1247, compiled_block_1_1247 );
  twobit_load( 2, 1 );
  twobit_load( 3, 1 );
  twobit_load( 4, 1 );
  twobit_stack( 1 );
  twobit_setreg( 1 );
  twobit_movereg( 1, 5 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* values */
  twobit_pop( 2 );
  twobit_invoke( 5 );
  twobit_label( 1247, compiled_block_1_1247 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1249, compiled_block_1_1249 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_270, 4, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_271, 6, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 7 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1249, compiled_block_1_1249 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_270( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_271( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 31 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 30 );
  twobit_reg( 31 );
  twobit_check( 30, 0, 0, 1251, compiled_block_1_1251 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg_op1_check_652(reg(31),1252,compiled_block_1_1252); /* internal:check-pair? with (31 0 0) */
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_reg( 31 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg_op1_check_652(reg(31),1252,compiled_block_1_1252); /* internal:check-pair? with (31 0 0) */
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 3 );
  twobit_reg( 31 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg_op1_check_652(reg(31),1252,compiled_block_1_1252); /* internal:check-pair? with (31 0 0) */
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_reg( 31 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 31 );
  twobit_reg_op1_check_652(reg(31),1252,compiled_block_1_1252); /* internal:check-pair? with (31 0 0) */
  twobit_reg( 31 );
  twobit_op1_404(); /* car:pair */
  twobit_op2_58( 5 ); /* cons */
  twobit_setreg( 31 );
  twobit_movereg( 31, 5 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 5 );
  twobit_label( 1252, compiled_block_1_1252 );
  twobit_trap( 31, 0, 0, 0 );
  twobit_label( 1251, compiled_block_1_1251 );
  twobit_trap( 30, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_41( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 0 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_267, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_267( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1257, compiled_block_1_1257 ); /* internal:branchf-pair? */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1259, compiled_block_1_1259 ); /* internal:branchf-pair? */
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /*  last-pair~1ay%kV~8842 */
  twobit_setrtn( 1260, compiled_block_1_1260 );
  twobit_invoke( 1 );
  twobit_label( 1260, compiled_block_1_1260 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_store( 1, 3 );
  twobit_load( 2, 1 );
  twobit_store( 2, 4 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_268, 4, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_load( 2, 4 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 1259, compiled_block_1_1259 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_movereg( 3, 1 );
  twobit_movereg( 2, 3 );
  twobit_movereg( 4, 2 );
  twobit_reg( 3 );
  twobit_invoke( 2 );
  twobit_label( 1257, compiled_block_1_1257 );
  twobit_reg( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_268( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1262, compiled_block_1_1262 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_reg( 1 );
  twobit_op2_60( 3 ); /* set-cdr! */
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1264, compiled_block_1_1264 ); /* internal:branchf-pair? */
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /*  last-pair~1ay%kV~8842 */
  twobit_setrtn( 1265, compiled_block_1_1265 );
  twobit_invoke( 1 );
  twobit_label( 1265, compiled_block_1_1265 );
  twobit_load( 0, 0 );
  twobit_skip( 1263, compiled_block_1_1263 );
  twobit_label( 1264, compiled_block_1_1264 );
  twobit_reg( 1 );
  twobit_label( 1263, compiled_block_1_1263 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1262, compiled_block_1_1262 );
  twobit_lexical( 0, 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_42( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_266, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_266( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1270, compiled_block_1_1270 );
  twobit_invoke( 1 );
  twobit_label( 1270, compiled_block_1_1270 );
  twobit_load( 0, 0 );
  twobit_branchf( 1272, compiled_block_1_1272 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1272, compiled_block_1_1272 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 2 );
  twobit_check( 3, 0, 0, 1273, compiled_block_1_1273 );
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_load( 3, 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1273, compiled_block_1_1273 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_43( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_265, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_265( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1276, compiled_block_1_1276 );
  twobit_invoke( 1 );
  twobit_label( 1276, compiled_block_1_1276 );
  twobit_load( 0, 0 );
  twobit_branchf( 1278, compiled_block_1_1278 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1278, compiled_block_1_1278 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 2 );
  twobit_check( 3, 0, 0, 1279, compiled_block_1_1279 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_stack( 2 );
  twobit_op2_60( 3 ); /* set-cdr! */
  twobit_movereg( 4, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1279, compiled_block_1_1279 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_44( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_movereg( 1, 3 );
  twobit_global( 1 ); /* append */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  reduce-right~1ay%kV~8866 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_45( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_movereg( 1, 3 );
  twobit_global( 1 ); /*  append!~1ay%kV~8848 */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  reduce-right~1ay%kV~8866 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_46( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_263, 2, 1 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* call-with-current-continuation */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_263( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_264, 3, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_264( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1285, compiled_block_1_1285 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1286, compiled_block_1_1286 );
  twobit_invoke( 1 );
  twobit_label( 1286, compiled_block_1_1286 );
  twobit_load( 0, 0 );
  twobit_branchf( 1288, compiled_block_1_1288 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1288, compiled_block_1_1288 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1290, compiled_block_1_1290 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1291, compiled_block_1_1291 );
  twobit_invoke( 1 );
  twobit_label( 1291, compiled_block_1_1291 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1285, compiled_block_1_1285 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_label( 1290, compiled_block_1_1290 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_47( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_262, 3, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_262( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1295, compiled_block_1_1295 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg_op1_check_652(reg(4),1296,compiled_block_1_1296); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1297, compiled_block_1_1297 );
  twobit_invoke( 1 );
  twobit_label( 1297, compiled_block_1_1297 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1295, compiled_block_1_1295 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_return();
  twobit_label( 1296, compiled_block_1_1296 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_48( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_254, 2, 1 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* call-with-current-continuation */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_254( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_255, 3, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_255( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1300, compiled_block_1_1300 ); /* internal:branchf-pair? */
  twobit_lambda( compiled_start_1_256, 2, 1 );
  twobit_setreg( 1 );
  twobit_lambda( compiled_start_1_257, 4, 0 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_label( 1300, compiled_block_1_1300 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 6 ); /* values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_256( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  car+cdr~1ay%kV~8832 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_257( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1302, compiled_block_1_1302 );
  twobit_invoke( 1 );
  twobit_label( 1302, compiled_block_1_1302 );
  twobit_load( 0, 0 );
  twobit_branchf( 1304, compiled_block_1_1304 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1304, compiled_block_1_1304 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_258, 3, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 3 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_259, 5, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_258( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  car+cdr~1ay%kV~8832 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_259( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lambda( compiled_start_1_260, 2, 2 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_261, 4, 0 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_260( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 1 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_261( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 3, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_49( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lambda( compiled_start_1_246, 2, 2 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* call-with-current-continuation */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_246( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_247, 3, 2 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_247( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1316, compiled_block_1_1316 ); /* internal:branchf-pair? */
  twobit_lambda( compiled_start_1_248, 2, 1 );
  twobit_setreg( 1 );
  twobit_lambda( compiled_start_1_249, 4, 0 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_label( 1316, compiled_block_1_1316 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_lexical( 1, 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 6 ); /* values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_248( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  car+cdr~1ay%kV~8832 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_249( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1318, compiled_block_1_1318 );
  twobit_invoke( 1 );
  twobit_label( 1318, compiled_block_1_1318 );
  twobit_load( 0, 0 );
  twobit_branchf( 1320, compiled_block_1_1320 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1320, compiled_block_1_1320 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_250, 3, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 3 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_251, 5, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_250( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  car+cdr~1ay%kV~8832 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_251( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lambda( compiled_start_1_252, 2, 2 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_253, 4, 0 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_252( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 1 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_253( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 3, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_50( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_239, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_239( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1332, compiled_block_1_1332 ); /* internal:branchf-pair? */
  twobit_lambda( compiled_start_1_240, 2, 1 );
  twobit_setreg( 1 );
  twobit_lambda( compiled_start_1_241, 4, 0 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_label( 1332, compiled_block_1_1332 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 6 ); /* values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_240( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  car+cdr~1ay%kV~8832 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_241( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_242, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_243, 4, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_242( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  car+cdr~1ay%kV~8832 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_243( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lambda( compiled_start_1_244, 2, 2 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_1_245, 4, 0 );
  twobit_setreg( 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_244( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 1 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op2_58( 2 ); /* cons */
  twobit_setreg( 2 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_245( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 3, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_51( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1343, compiled_block_1_1343 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_store( 2, 2 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_233, 3, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1343, compiled_block_1_1343 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_234, 5, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_233( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 2 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1344, compiled_block_1_1344 );
  twobit_invoke( 1 );
  twobit_label( 1344, compiled_block_1_1344 );
  twobit_load( 0, 0 );
  twobit_branchf( 1346, compiled_block_1_1346 );
  twobit_stack( 1 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1346, compiled_block_1_1346 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_236, 3, 1 );
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_237, 5, 2 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_236( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %cars+cdrs~1ay%kV~8855 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_237( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1349, compiled_block_1_1349 ); /* internal:branchf-null? */
  twobit_lexical( 0, 1 );
  twobit_return();
  twobit_label( 1349, compiled_block_1_1349 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_movereg( 1, 3 );
  twobit_lexical( 0, 2 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_check( 4, 0, 0, 1350, compiled_block_1_1350 );
  twobit_lexical( 0, 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* apply */
  twobit_setrtn( 1351, compiled_block_1_1351 );
  twobit_invoke( 3 );
  twobit_label( 1351, compiled_block_1_1351 );
  twobit_load( 0, 0 );
  twobit_branchf( 1353, compiled_block_1_1353 );
  twobit_lexical( 0, 1 );
  twobit_op2imm_130( fixnum(1), 238, compiled_temp_1_238 ); /* + */
  twobit_skip( 1352, compiled_block_1_1352 );
  twobit_label( 1353, compiled_block_1_1353 );
  twobit_lexical( 0, 1 );
  twobit_label( 1352, compiled_block_1_1352 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_lexical( 1, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1350, compiled_block_1_1350 );
  twobit_trap( 4, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_234( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1357, compiled_block_1_1357 );
  twobit_invoke( 1 );
  twobit_label( 1357, compiled_block_1_1357 );
  twobit_load( 0, 0 );
  twobit_branchf( 1359, compiled_block_1_1359 );
  twobit_stack( 1 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1359, compiled_block_1_1359 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 2 );
  twobit_check( 3, 0, 0, 1360, compiled_block_1_1360 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1361, compiled_block_1_1361 );
  twobit_invoke( 1 );
  twobit_label( 1361, compiled_block_1_1361 );
  twobit_load( 0, 0 );
  twobit_branchf( 1363, compiled_block_1_1363 );
  twobit_stack( 1 );
  twobit_op2imm_130( fixnum(1), 235, compiled_temp_1_235 ); /* + */
  twobit_skip( 1362, compiled_block_1_1362 );
  twobit_label( 1363, compiled_block_1_1363 );
  twobit_stack( 1 );
  twobit_label( 1362, compiled_block_1_1362 );
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1360, compiled_block_1_1360 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_52( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 4 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 4, 1 );
  twobit_reg( 5 );
  twobit_op1_branchf_611( 1367, compiled_block_1_1367 ); /* internal:branchf-pair? */
  twobit_reg( 5 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 1366, compiled_block_1_1366 );
  twobit_label( 1367, compiled_block_1_1367 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_label( 1366, compiled_block_1_1366 );
  twobit_setreg( 31 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 30 );
  twobit_movereg( 30, 4 );
  twobit_lambda( compiled_start_1_232, 3, 4 );
  twobit_setreg( 3 );
  twobit_movereg( 31, 2 );
  twobit_load( 1, 1 );
  twobit_reg( 30 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 30 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_232( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1368, compiled_block_1_1368 );
  twobit_invoke( 1 );
  twobit_label( 1368, compiled_block_1_1368 );
  twobit_load( 0, 0 );
  twobit_branchf( 1370, compiled_block_1_1370 );
  twobit_stack( 1 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1370, compiled_block_1_1370 );
  twobit_load( 1, 2 );
  twobit_lexical( 0, 3 );
  twobit_setrtn( 1371, compiled_block_1_1371 );
  twobit_invoke( 1 );
  twobit_label( 1371, compiled_block_1_1371 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 2 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1372, compiled_block_1_1372 );
  twobit_invoke( 1 );
  twobit_label( 1372, compiled_block_1_1372 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_load( 3, 1 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_lexical( 0, 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_53( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 4 );
  twobit_reg( 5 );
  twobit_op1_branchf_611( 1376, compiled_block_1_1376 ); /* internal:branchf-pair? */
  twobit_reg( 5 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 31 );
  twobit_reg( 5 );
  twobit_op1_405(); /* cdr:pair */
  twobit_op1_branchf_611( 1378, compiled_block_1_1378 ); /* internal:branchf-pair? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 4, 1 );
  twobit_movereg( 1, 4 );
  twobit_store( 4, 2 );
  twobit_store( 3, 3 );
  twobit_stack( 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 5, 4 );
  twobit_global( 1 ); /* error */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  unfold~1ay%kV~8860 */
  twobit_setreg( 3 );
  twobit_movereg( 2, 5 );
  twobit_movereg( 4, 8 );
  twobit_const( 3 );
  twobit_setreg( 2 );
  twobit_load( 4, 2 );
  twobit_load( 6, 3 );
  twobit_load( 7, 1 );
  twobit_global( 4 ); /* apply */
  twobit_pop( 3 );
  twobit_invoke( 8 );
  twobit_label( 1378, compiled_block_1_1378 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 4, 1 );
  twobit_global( 5 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 30 );
  twobit_movereg( 31, 5 );
  twobit_movereg( 30, 4 );
  twobit_lambda( compiled_start_1_230, 7, 5 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 30 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 30 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1376, compiled_block_1_1376 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 4, 1 );
  twobit_global( 5 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 31 );
  twobit_movereg( 31, 4 );
  twobit_lambda( compiled_start_1_231, 9, 4 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 31 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 31 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_230( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1380, compiled_block_1_1380 );
  twobit_invoke( 1 );
  twobit_label( 1380, compiled_block_1_1380 );
  twobit_load( 0, 0 );
  twobit_branchf( 1382, compiled_block_1_1382 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 5 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1382, compiled_block_1_1382 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1384, compiled_block_1_1384 );
  twobit_invoke( 1 );
  twobit_label( 1384, compiled_block_1_1384 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 3 );
  twobit_setrtn( 1385, compiled_block_1_1385 );
  twobit_invoke( 1 );
  twobit_label( 1385, compiled_block_1_1385 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1386, compiled_block_1_1386 );
  twobit_invoke( 1 );
  twobit_label( 1386, compiled_block_1_1386 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_231( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1388, compiled_block_1_1388 );
  twobit_invoke( 1 );
  twobit_label( 1388, compiled_block_1_1388 );
  twobit_load( 0, 0 );
  twobit_branchf( 1390, compiled_block_1_1390 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1390, compiled_block_1_1390 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1391, compiled_block_1_1391 );
  twobit_invoke( 1 );
  twobit_label( 1391, compiled_block_1_1391 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 3 );
  twobit_setrtn( 1392, compiled_block_1_1392 );
  twobit_invoke( 1 );
  twobit_label( 1392, compiled_block_1_1392 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1393, compiled_block_1_1393 );
  twobit_invoke( 1 );
  twobit_label( 1393, compiled_block_1_1393 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_54( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1396, compiled_block_1_1396 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_reg( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_1_226, 3, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 4, 1 );
  twobit_load( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1396, compiled_block_1_1396 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_227, 5, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_load( 3, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_226( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_228, 2, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_229, 4, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_228( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /*  %cars+cdrs+~1ay%kV~8856 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_229( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1399, compiled_block_1_1399 ); /* internal:branchf-null? */
  twobit_lexical( 0, 1 );
  twobit_return();
  twobit_label( 1399, compiled_block_1_1399 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* apply */
  twobit_setrtn( 1400, compiled_block_1_1400 );
  twobit_invoke( 2 );
  twobit_label( 1400, compiled_block_1_1400 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 1, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_227( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1404, compiled_block_1_1404 );
  twobit_invoke( 1 );
  twobit_label( 1404, compiled_block_1_1404 );
  twobit_load( 0, 0 );
  twobit_branchf( 1406, compiled_block_1_1406 );
  twobit_stack( 1 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1406, compiled_block_1_1406 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 2 );
  twobit_check( 3, 0, 0, 1407, compiled_block_1_1407 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1408, compiled_block_1_1408 );
  twobit_invoke( 2 );
  twobit_label( 1408, compiled_block_1_1408 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1407, compiled_block_1_1407 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_55( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1412, compiled_block_1_1412 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_lambda( compiled_start_1_224, 3, 3 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 1412, compiled_block_1_1412 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_225, 5, 3 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_224( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  %cdrs~1ay%kV~8853 */
  twobit_setrtn( 1413, compiled_block_1_1413 );
  twobit_invoke( 1 );
  twobit_label( 1413, compiled_block_1_1413 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_610( 1415, compiled_block_1_1415 ); /* internal:branchf-null? */
  twobit_lexical( 0, 2 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1415, compiled_block_1_1415 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_movereg( 4, 1 );
  twobit_reg( 3 );
  twobit_setrtn( 1416, compiled_block_1_1416 );
  twobit_invoke( 1 );
  twobit_label( 1416, compiled_block_1_1416 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  %cars+~1ay%kV~8854 */
  twobit_setrtn( 1417, compiled_block_1_1417 );
  twobit_invoke( 2 );
  twobit_label( 1417, compiled_block_1_1417 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_225( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1420, compiled_block_1_1420 );
  twobit_invoke( 1 );
  twobit_label( 1420, compiled_block_1_1420 );
  twobit_load( 0, 0 );
  twobit_branchf( 1422, compiled_block_1_1422 );
  twobit_lexical( 0, 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1422, compiled_block_1_1422 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1423, compiled_block_1_1423 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1424, compiled_block_1_1424 );
  twobit_invoke( 1 );
  twobit_label( 1424, compiled_block_1_1424 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1423, compiled_block_1_1423 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_56( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1428, compiled_block_1_1428 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_lambda( compiled_start_1_222, 3, 3 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_label( 1428, compiled_block_1_1428 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 3 );
  twobit_lambda( compiled_start_1_223, 5, 3 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_222( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  %cdrs~1ay%kV~8853 */
  twobit_setrtn( 1429, compiled_block_1_1429 );
  twobit_invoke( 1 );
  twobit_label( 1429, compiled_block_1_1429 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_branchf_610( 1431, compiled_block_1_1431 ); /* internal:branchf-null? */
  twobit_lexical( 0, 2 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1431, compiled_block_1_1431 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_movereg( 4, 1 );
  twobit_reg( 3 );
  twobit_setrtn( 1432, compiled_block_1_1432 );
  twobit_invoke( 1 );
  twobit_label( 1432, compiled_block_1_1432 );
  twobit_load( 0, 0 );
  twobit_imm_const_setreg( NIL_CONST, 3 ); /* () */
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /*  append!~1ay%kV~8848 */
  twobit_setrtn( 1433, compiled_block_1_1433 );
  twobit_invoke( 2 );
  twobit_label( 1433, compiled_block_1_1433 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* apply */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_223( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1436, compiled_block_1_1436 );
  twobit_invoke( 1 );
  twobit_label( 1436, compiled_block_1_1436 );
  twobit_load( 0, 0 );
  twobit_branchf( 1438, compiled_block_1_1438 );
  twobit_lexical( 0, 2 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1438, compiled_block_1_1438 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1439, compiled_block_1_1439 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1440, compiled_block_1_1440 );
  twobit_invoke( 1 );
  twobit_label( 1440, compiled_block_1_1440 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 1 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1439, compiled_block_1_1439 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_57( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1444, compiled_block_1_1444 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_reg( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_1_220, 3, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 4, 1 );
  twobit_load( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1444, compiled_block_1_1444 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 2 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_221, 5, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_load( 3, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_220( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  %cdrs~1ay%kV~8853 */
  twobit_setrtn( 1445, compiled_block_1_1445 );
  twobit_invoke( 1 );
  twobit_label( 1445, compiled_block_1_1445 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_610( 1447, compiled_block_1_1447 ); /* internal:branchf-null? */
  twobit_stack( 1 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1447, compiled_block_1_1447 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 3 );
  twobit_stack( 1 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 2 ); /*  append!~1ay%kV~8848 */
  twobit_setrtn( 1448, compiled_block_1_1448 );
  twobit_invoke( 2 );
  twobit_label( 1448, compiled_block_1_1448 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /* apply */
  twobit_setrtn( 1449, compiled_block_1_1449 );
  twobit_invoke( 2 );
  twobit_label( 1449, compiled_block_1_1449 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 3 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_221( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1452, compiled_block_1_1452 );
  twobit_invoke( 1 );
  twobit_label( 1452, compiled_block_1_1452 );
  twobit_load( 0, 0 );
  twobit_branchf( 1454, compiled_block_1_1454 );
  twobit_stack( 1 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1454, compiled_block_1_1454 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 2 );
  twobit_check( 3, 0, 0, 1455, compiled_block_1_1455 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_load( 1, 2 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1456, compiled_block_1_1456 );
  twobit_invoke( 2 );
  twobit_label( 1456, compiled_block_1_1456 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1455, compiled_block_1_1455 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_58( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1459, compiled_block_1_1459 );
  twobit_invoke( 1 );
  twobit_label( 1459, compiled_block_1_1459 );
  twobit_load( 0, 0 );
  twobit_branchf( 1461, compiled_block_1_1461 );
  twobit_stack( 1 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1461, compiled_block_1_1461 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 2 );
  twobit_check( 3, 0, 0, 1462, compiled_block_1_1462 );
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_load( 1, 3 );
  twobit_global( 2 ); /*  fold~1ay%kV~8861 */
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1462, compiled_block_1_1462 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_59( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_movereg( 3, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1464, compiled_block_1_1464 );
  twobit_invoke( 1 );
  twobit_label( 1464, compiled_block_1_1464 );
  twobit_load( 0, 0 );
  twobit_branchf( 1466, compiled_block_1_1466 );
  twobit_stack( 1 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1466, compiled_block_1_1466 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 2 );
  twobit_check( 3, 0, 0, 1467, compiled_block_1_1467 );
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 2, 3 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_219, 4, 2 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1467, compiled_block_1_1467 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_219( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1469, compiled_block_1_1469 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1470, compiled_block_1_1470 );
  twobit_invoke( 2 );
  twobit_label( 1470, compiled_block_1_1470 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 2 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1469, compiled_block_1_1469 );
  twobit_reg( 1 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_60( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_movereg( 1, 3 );
  twobit_movereg( 2, 4 );
  twobit_stack( 1 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  append-map~1ay%kV~8867 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /* append */
  twobit_setreg( 2 );
  twobit_load( 5, 1 );
  twobit_global( 3 ); /*  really-append-map~1ay%kV~8869 */
  twobit_pop( 1 );
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_61( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 3, 1 );
  twobit_movereg( 1, 3 );
  twobit_movereg( 2, 4 );
  twobit_stack( 1 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  append-map!~1ay%kV~8868 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  append!~1ay%kV~8848 */
  twobit_setreg( 2 );
  twobit_load( 5, 1 );
  twobit_global( 3 ); /*  really-append-map~1ay%kV~8869 */
  twobit_pop( 1 );
  twobit_invoke( 5 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_62( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 5 );
  twobit_reg( 5 );
  twobit_op1_branchf_611( 1476, compiled_block_1_1476 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 4, 2 );
  twobit_movereg( 5, 1 );
  twobit_lambda( compiled_start_1_213, 2, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_load( 2, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_214, 4, 2 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1476, compiled_block_1_1476 );
  twobit_save( 4 );
  twobit_store( 0, 0 );
  twobit_store( 2, 3 );
  twobit_store( 3, 2 );
  twobit_store( 4, 1 );
  twobit_movereg( 4, 1 );
  twobit_global( 6 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1489, compiled_block_1_1489 );
  twobit_invoke( 1 );
  twobit_label( 1489, compiled_block_1_1489 );
  twobit_load( 0, 0 );
  twobit_branchf( 1491, compiled_block_1_1491 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_pop( 4 );
  twobit_return();
  twobit_label( 1491, compiled_block_1_1491 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1492, compiled_block_1_1492 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_store( 1, 4 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_global( 7 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_215, 9, 3 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_movereg( 4, 2 );
  twobit_load( 4, 2 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 4 );
  twobit_reg( 4 );
  twobit_pop( 4 );
  twobit_invoke( 2 );
  twobit_label( 1492, compiled_block_1_1492 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_213( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %cars+cdrs~1ay%kV~8855 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_214( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1479, compiled_block_1_1479 ); /* internal:branchf-null? */
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_label( 1479, compiled_block_1_1479 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_216, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_216( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* apply */
  twobit_setrtn( 1480, compiled_block_1_1480 );
  twobit_invoke( 2 );
  twobit_label( 1480, compiled_block_1_1480 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_217, 3, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_218, 5, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_217( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %cars+cdrs~1ay%kV~8855 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_218( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1483, compiled_block_1_1483 ); /* internal:branchf-null? */
  twobit_lexical( 0, 1 );
  twobit_return();
  twobit_label( 1483, compiled_block_1_1483 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1484, compiled_block_1_1484 );
  twobit_invoke( 2 );
  twobit_label( 1484, compiled_block_1_1484 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 2, 2 );
  twobit_pop( 0 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_215( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1493, compiled_block_1_1493 );
  twobit_invoke( 1 );
  twobit_label( 1493, compiled_block_1_1493 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1494, compiled_block_1_1494 );
  twobit_invoke( 1 );
  twobit_label( 1494, compiled_block_1_1494 );
  twobit_load( 0, 0 );
  twobit_branchf( 1496, compiled_block_1_1496 );
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1496, compiled_block_1_1496 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1497, compiled_block_1_1497 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1498, compiled_block_1_1498 );
  twobit_invoke( 2 );
  twobit_label( 1498, compiled_block_1_1498 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1497, compiled_block_1_1497 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_63( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1502, compiled_block_1_1502 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_1_211, 3, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 4, 1 );
  twobit_load( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1502, compiled_block_1_1502 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_212, 5, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_211( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  %cdrs~1ay%kV~8853 */
  twobit_setrtn( 1503, compiled_block_1_1503 );
  twobit_invoke( 1 );
  twobit_label( 1503, compiled_block_1_1503 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_op1_branchf_611( 1505, compiled_block_1_1505 ); /* internal:branchf-pair? */
  twobit_load( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 2 ); /* apply */
  twobit_setrtn( 1506, compiled_block_1_1506 );
  twobit_invoke( 2 );
  twobit_label( 1506, compiled_block_1_1506 );
  twobit_load( 0, 0 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1505, compiled_block_1_1505 );
  twobit_op1_3(); /* unspecified */
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_212( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1509, compiled_block_1_1509 );
  twobit_invoke( 1 );
  twobit_label( 1509, compiled_block_1_1509 );
  twobit_load( 0, 0 );
  twobit_branchf( 1511, compiled_block_1_1511 );
  twobit_op1_3(); /* unspecified */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1511, compiled_block_1_1511 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1512, compiled_block_1_1512 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1513, compiled_block_1_1513 );
  twobit_invoke( 1 );
  twobit_label( 1513, compiled_block_1_1513 );
  twobit_load( 0, 0 );
  twobit_load( 1, 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1512, compiled_block_1_1512 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_64( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1517, compiled_block_1_1517 ); /* internal:branchf-pair? */
  twobit_movereg( 3, 2 );
  twobit_store( 2, 2 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_207, 3, 2 );
  twobit_setreg( 31 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 31 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_setrtn( 1526, compiled_block_1_1526 );
  twobit_invoke( 2 );
  twobit_label( 1526, compiled_block_1_1526 );
  twobit_load( 0, 0 );
  twobit_skip( 1516, compiled_block_1_1516 );
  twobit_label( 1517, compiled_block_1_1517 );
  twobit_lambda( compiled_start_1_208, 5, 1 );
  twobit_setreg( 1 );
  twobit_global( 6 ); /*  pair-for-each~1ay%kV~8870 */
  twobit_setrtn( 1529, compiled_block_1_1529 );
  twobit_invoke( 2 );
  twobit_label( 1529, compiled_block_1_1529 );
  twobit_load( 0, 0 );
  twobit_label( 1516, compiled_block_1_1516 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_207( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1518, compiled_block_1_1518 );
  twobit_invoke( 1 );
  twobit_label( 1518, compiled_block_1_1518 );
  twobit_load( 0, 0 );
  twobit_branchf( 1520, compiled_block_1_1520 );
  twobit_op1_3(); /* unspecified */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1520, compiled_block_1_1520 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_209, 3, 1 );
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_210, 5, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 6 ); /* call-with-values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_209( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %cars+cdrs/no-test~1ay%kV~8857 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_210( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 3 );
  twobit_lexical( 0, 1 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_check( 4, 0, 0, 1522, compiled_block_1_1522 );
  twobit_lexical( 0, 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* apply */
  twobit_setrtn( 1523, compiled_block_1_1523 );
  twobit_invoke( 3 );
  twobit_label( 1523, compiled_block_1_1523 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_op2_59( 4 ); /* set-car! */
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1522, compiled_block_1_1522 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_208( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg_op1_check_652(reg(1),1527,compiled_block_1_1527); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1528, compiled_block_1_1528 );
  twobit_invoke( 1 );
  twobit_label( 1528, compiled_block_1_1528 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op2_59( 4 ); /* set-car! */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1527, compiled_block_1_1527 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_65( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1531, compiled_block_1_1531 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_1_203, 3, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 4, 1 );
  twobit_load( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1531, compiled_block_1_1531 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_204, 5, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_203( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_205, 2, 1 );
  twobit_setreg( 1 );
  twobit_lambda( compiled_start_1_206, 4, 0 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_205( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %cars+cdrs~1ay%kV~8855 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_206( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1534, compiled_block_1_1534 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* apply */
  twobit_setrtn( 1535, compiled_block_1_1535 );
  twobit_invoke( 2 );
  twobit_label( 1535, compiled_block_1_1535 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_reg( 4 );
  twobit_branchf( 1537, compiled_block_1_1537 );
  twobit_load( 1, 1 );
  twobit_lexical( 1, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1538, compiled_block_1_1538 );
  twobit_invoke( 1 );
  twobit_label( 1538, compiled_block_1_1538 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1537, compiled_block_1_1537 );
  twobit_load( 1, 1 );
  twobit_lexical( 1, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1534, compiled_block_1_1534 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_204( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1542, compiled_block_1_1542 );
  twobit_invoke( 1 );
  twobit_label( 1542, compiled_block_1_1542 );
  twobit_load( 0, 0 );
  twobit_branchf( 1544, compiled_block_1_1544 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1544, compiled_block_1_1544 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1545, compiled_block_1_1545 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1546, compiled_block_1_1546 );
  twobit_invoke( 1 );
  twobit_label( 1546, compiled_block_1_1546 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1547, compiled_block_1_1547 );
  twobit_invoke( 1 );
  twobit_label( 1547, compiled_block_1_1547 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1549, compiled_block_1_1549 );
  twobit_load( 3, 2 );
  twobit_reg( 4 );
  twobit_op2_58( 3 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1549, compiled_block_1_1549 );
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1545, compiled_block_1_1545 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_66( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1552, compiled_block_1_1552 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_1_199, 3, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 4, 1 );
  twobit_load( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1552, compiled_block_1_1552 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_200, 5, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_199( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_201, 2, 1 );
  twobit_setreg( 1 );
  twobit_lambda( compiled_start_1_202, 4, 0 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_201( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %cars+cdrs~1ay%kV~8855 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_202( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1555, compiled_block_1_1555 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* apply */
  twobit_setrtn( 1556, compiled_block_1_1556 );
  twobit_invoke( 2 );
  twobit_label( 1556, compiled_block_1_1556 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_load( 1, 1 );
  twobit_lexical( 1, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1557, compiled_block_1_1557 );
  twobit_invoke( 1 );
  twobit_label( 1557, compiled_block_1_1557 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1555, compiled_block_1_1555 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_200( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1560, compiled_block_1_1560 );
  twobit_invoke( 1 );
  twobit_label( 1560, compiled_block_1_1560 );
  twobit_load( 0, 0 );
  twobit_branchf( 1562, compiled_block_1_1562 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1562, compiled_block_1_1562 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1563, compiled_block_1_1563 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1564, compiled_block_1_1564 );
  twobit_invoke( 1 );
  twobit_label( 1564, compiled_block_1_1564 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_setrtn( 1565, compiled_block_1_1565 );
  twobit_invoke( 1 );
  twobit_label( 1565, compiled_block_1_1565 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1563, compiled_block_1_1563 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_67( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1568, compiled_block_1_1568 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_1_195, 3, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 4, 1 );
  twobit_load( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1568, compiled_block_1_1568 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_196, 5, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_195( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_197, 2, 1 );
  twobit_setreg( 1 );
  twobit_lambda( compiled_start_1_198, 4, 0 );
  twobit_setreg( 2 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_197( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %cars+cdrs~1ay%kV~8855 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_198( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1571, compiled_block_1_1571 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* apply */
  twobit_setrtn( 1572, compiled_block_1_1572 );
  twobit_invoke( 2 );
  twobit_label( 1572, compiled_block_1_1572 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_lexical( 1, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1571, compiled_block_1_1571 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_196( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1576, compiled_block_1_1576 );
  twobit_invoke( 1 );
  twobit_label( 1576, compiled_block_1_1576 );
  twobit_load( 0, 0 );
  twobit_branchf( 1578, compiled_block_1_1578 );
  twobit_op1_3(); /* unspecified */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1578, compiled_block_1_1578 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1579, compiled_block_1_1579 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1580, compiled_block_1_1580 );
  twobit_invoke( 1 );
  twobit_label( 1580, compiled_block_1_1580 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1579, compiled_block_1_1579 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_68( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_194, 3, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_194( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1583, compiled_block_1_1583 );
  twobit_invoke( 1 );
  twobit_label( 1583, compiled_block_1_1583 );
  twobit_load( 0, 0 );
  twobit_branchf( 1585, compiled_block_1_1585 );
  twobit_stack( 1 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1585, compiled_block_1_1585 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1586, compiled_block_1_1586 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_movereg( 4, 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1587, compiled_block_1_1587 );
  twobit_invoke( 1 );
  twobit_label( 1587, compiled_block_1_1587 );
  twobit_load( 0, 0 );
  twobit_branchf( 1589, compiled_block_1_1589 );
  twobit_load( 1, 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1590, compiled_block_1_1590 );
  twobit_invoke( 1 );
  twobit_label( 1590, compiled_block_1_1590 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_branchf_624( 4, 1592, compiled_block_1_1592 ); /* internal:branchf-eq? */
  twobit_stack( 1 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1592, compiled_block_1_1592 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1589, compiled_block_1_1589 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 1 );
  twobit_label( 1586, compiled_block_1_1586 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_69( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_190, 3, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_190( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1595, compiled_block_1_1595 );
  twobit_invoke( 1 );
  twobit_label( 1595, compiled_block_1_1595 );
  twobit_load( 0, 0 );
  twobit_branchf( 1597, compiled_block_1_1597 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1597, compiled_block_1_1597 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1598, compiled_block_1_1598 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1599, compiled_block_1_1599 );
  twobit_invoke( 1 );
  twobit_label( 1599, compiled_block_1_1599 );
  twobit_load( 0, 0 );
  twobit_branchf( 1601, compiled_block_1_1601 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_191, 4, 1 );
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_192, 6, 2 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_load( 4, 2 );
  twobit_reg( 2 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1617, compiled_block_1_1617 );
  twobit_invoke( 2 );
  twobit_label( 1617, compiled_block_1_1617 );
  twobit_load( 0, 0 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1601, compiled_block_1_1601 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1598, compiled_block_1_1598 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_191( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_193, 3, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_193( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1603, compiled_block_1_1603 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 2, 1 );
  twobit_setrtn( 1604, compiled_block_1_1604 );
  twobit_invoke( 1 );
  twobit_label( 1604, compiled_block_1_1604 );
  twobit_load( 0, 0 );
  twobit_branchf( 1606, compiled_block_1_1606 );
  twobit_load( 4, 1 );
  twobit_lexical( 0, 1 );
  twobit_op2_60( 4 ); /* set-cdr! */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 3 );
  twobit_movereg( 4, 1 );
  twobit_reg( 3 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1606, compiled_block_1_1606 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1603, compiled_block_1_1603 );
  twobit_lexical( 0, 1 );
  twobit_op2_60( 1 ); /* set-cdr! */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_192( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1611, compiled_block_1_1611 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setrtn( 1612, compiled_block_1_1612 );
  twobit_invoke( 1 );
  twobit_label( 1612, compiled_block_1_1612 );
  twobit_load( 0, 0 );
  twobit_branchf( 1614, compiled_block_1_1614 );
  twobit_load( 1, 1 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1614, compiled_block_1_1614 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1611, compiled_block_1_1611 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_70( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_187, 3, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_187( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1620, compiled_block_1_1620 );
  twobit_invoke( 1 );
  twobit_label( 1620, compiled_block_1_1620 );
  twobit_load( 0, 0 );
  twobit_branchf( 1622, compiled_block_1_1622 );
  twobit_load( 2, 1 );
  twobit_load( 1, 1 );
  twobit_global( 2 ); /* values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1622, compiled_block_1_1622 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1624, compiled_block_1_1624 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_188, 4, 2 );
  twobit_setreg( 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_189, 6, 1 );
  twobit_setreg( 1 );
  twobit_global( 7 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1624, compiled_block_1_1624 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_188( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 1 );
  twobit_setrtn( 1625, compiled_block_1_1625 );
  twobit_invoke( 1 );
  twobit_label( 1625, compiled_block_1_1625 );
  twobit_load( 0, 0 );
  twobit_branchf( 1627, compiled_block_1_1627 );
  twobit_stack( 1 );
  twobit_op1_branchf_611( 1629, compiled_block_1_1629 ); /* internal:branchf-pair? */
  twobit_load( 4, 2 );
  twobit_lexical( 0, 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_skip( 1628, compiled_block_1_1628 );
  twobit_label( 1629, compiled_block_1_1629 );
  twobit_lexical( 0, 2 );
  twobit_label( 1628, compiled_block_1_1628 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 1 ); /* values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1627, compiled_block_1_1627 );
  twobit_stack( 2 );
  twobit_op1_branchf_611( 1632, compiled_block_1_1632 ); /* internal:branchf-pair? */
  twobit_load( 4, 1 );
  twobit_lexical( 0, 1 );
  twobit_op2_58( 4 ); /* cons */
  twobit_skip( 1631, compiled_block_1_1631 );
  twobit_label( 1632, compiled_block_1_1632 );
  twobit_lexical( 0, 2 );
  twobit_label( 1631, compiled_block_1_1631 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 1 ); /* values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_189( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_71( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 5 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1637, compiled_block_1_1637 );
  twobit_invoke( 1 );
  twobit_label( 1637, compiled_block_1_1637 );
  twobit_load( 0, 0 );
  twobit_branchf( 1639, compiled_block_1_1639 );
  twobit_load( 1, 1 );
  twobit_load( 2, 1 );
  twobit_global( 2 ); /* values */
  twobit_pop( 5 );
  twobit_invoke( 2 );
  twobit_label( 1639, compiled_block_1_1639 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_store( 3, 5 );
  twobit_reg( 4 );
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_load( 2, 2 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_181, 5, 2 );
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_load( 2, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_182, 7, 2 );
  twobit_setreg( 2 );
  twobit_load( 4, 3 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_stack( 4 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_stack( 2 );
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 2, 1 );
  twobit_check( 2, 0, 0, 1657, compiled_block_1_1657 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1658, compiled_block_1_1658 );
  twobit_invoke( 1 );
  twobit_label( 1658, compiled_block_1_1658 );
  twobit_load( 0, 0 );
  twobit_branchf( 1660, compiled_block_1_1660 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 4, 4 );
  twobit_load( 2, 2 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_183, 9, 4 );
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 5 );
  twobit_invoke( 2 );
  twobit_label( 1660, compiled_block_1_1660 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 4 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 4, 5 );
  twobit_load( 2, 2 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_184, 11, 4 );
  twobit_setreg( 4 );
  twobit_load( 2, 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 5 );
  twobit_invoke( 2 );
  twobit_label( 1657, compiled_block_1_1657 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_181( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_186, 3, 2 );
  twobit_setreg( 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_load( 3, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_186( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1642, compiled_block_1_1642 ); /* internal:branchf-pair? */
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setrtn( 1643, compiled_block_1_1643 );
  twobit_invoke( 1 );
  twobit_label( 1643, compiled_block_1_1643 );
  twobit_load( 0, 0 );
  twobit_branchf( 1645, compiled_block_1_1645 );
  twobit_load( 1, 1 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1645, compiled_block_1_1645 );
  twobit_load( 4, 1 );
  twobit_lexical( 0, 2 );
  twobit_op2_60( 4 ); /* set-cdr! */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_store( 4, 3 );
  twobit_movereg( 2, 4 );
  twobit_load( 2, 3 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 3 );
  twobit_label( 1642, compiled_block_1_1642 );
  twobit_lexical( 0, 2 );
  twobit_op2_60( 2 ); /* set-cdr! */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_182( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_store( 2, 2 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_185, 3, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_185( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1650, compiled_block_1_1650 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setrtn( 1651, compiled_block_1_1651 );
  twobit_invoke( 1 );
  twobit_label( 1651, compiled_block_1_1651 );
  twobit_load( 0, 0 );
  twobit_branchf( 1653, compiled_block_1_1653 );
  twobit_load( 1, 1 );
  twobit_load( 4, 1 );
  twobit_lexical( 0, 1 );
  twobit_op2_60( 4 ); /* set-cdr! */
  twobit_reg( 4 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 3 );
  twobit_label( 1653, compiled_block_1_1653 );
  twobit_load( 1, 1 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1650, compiled_block_1_1650 );
  twobit_lexical( 0, 1 );
  twobit_op2_60( 2 ); /* set-cdr! */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_183( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1662, compiled_block_1_1662 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1663, compiled_block_1_1663 );
  twobit_invoke( 1 );
  twobit_label( 1663, compiled_block_1_1663 );
  twobit_load( 0, 0 );
  twobit_branchf( 1665, compiled_block_1_1665 );
  twobit_load( 1, 1 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1665, compiled_block_1_1665 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_lexical( 0, 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_load( 2, 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1667, compiled_block_1_1667 );
  twobit_invoke( 3 );
  twobit_label( 1667, compiled_block_1_1667 );
  twobit_load( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 1 ); /* values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1662, compiled_block_1_1662 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_184( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1672, compiled_block_1_1672 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1673, compiled_block_1_1673 );
  twobit_invoke( 1 );
  twobit_label( 1673, compiled_block_1_1673 );
  twobit_load( 0, 0 );
  twobit_branchf( 1675, compiled_block_1_1675 );
  twobit_load( 1, 1 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1676, compiled_block_1_1676 );
  twobit_invoke( 3 );
  twobit_label( 1676, compiled_block_1_1676 );
  twobit_load( 0, 0 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /* values */
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1675, compiled_block_1_1675 );
  twobit_load( 1, 1 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1672, compiled_block_1_1672 );
  twobit_movereg( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_72( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lambda( compiled_start_1_180, 2, 1 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  filter~1ay%kV~8876 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_180( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1681, compiled_block_1_1681 );
  twobit_invoke( 1 );
  twobit_label( 1681, compiled_block_1_1681 );
  twobit_load( 0, 0 );
  twobit_op1_9(); /* not */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_73( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lambda( compiled_start_1_179, 2, 1 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  filter!~1ay%kV~8877 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_179( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1683, compiled_block_1_1683 );
  twobit_invoke( 1 );
  twobit_label( 1683, compiled_block_1_1683 );
  twobit_load( 0, 0 );
  twobit_op1_9(); /* not */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_74( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1686, compiled_block_1_1686 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 1685, compiled_block_1_1685 );
  twobit_label( 1686, compiled_block_1_1686 );
  twobit_global( 1 ); /* equal? */
  twobit_label( 1685, compiled_block_1_1685 );
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_178, 3, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /*  filter~1ay%kV~8876 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_178( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1687, compiled_block_1_1687 );
  twobit_invoke( 2 );
  twobit_label( 1687, compiled_block_1_1687 );
  twobit_load( 0, 0 );
  twobit_op1_9(); /* not */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_75( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1690, compiled_block_1_1690 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 1689, compiled_block_1_1689 );
  twobit_label( 1690, compiled_block_1_1690 );
  twobit_global( 1 ); /* equal? */
  twobit_label( 1689, compiled_block_1_1689 );
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_177, 3, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /*  filter!~1ay%kV~8877 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_177( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1691, compiled_block_1_1691 );
  twobit_invoke( 2 );
  twobit_label( 1691, compiled_block_1_1691 );
  twobit_load( 0, 0 );
  twobit_op1_9(); /* not */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_76( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1694, compiled_block_1_1694 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 1693, compiled_block_1_1693 );
  twobit_label( 1694, compiled_block_1_1694 );
  twobit_global( 1 ); /* equal? */
  twobit_label( 1693, compiled_block_1_1693 );
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_176, 3, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /*  find-tail~1ay%kV~8893 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_176( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_77( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1698, compiled_block_1_1698 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 1697, compiled_block_1_1697 );
  twobit_label( 1698, compiled_block_1_1698 );
  twobit_global( 1 ); /* equal? */
  twobit_label( 1697, compiled_block_1_1697 );
  twobit_setreg( 4 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_175, 4, 2 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_175( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1699, compiled_block_1_1699 );
  twobit_invoke( 1 );
  twobit_label( 1699, compiled_block_1_1699 );
  twobit_load( 0, 0 );
  twobit_branchf( 1701, compiled_block_1_1701 );
  twobit_stack( 1 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1701, compiled_block_1_1701 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1702, compiled_block_1_1702 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_movereg( 4, 1 );
  twobit_movereg( 3, 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  delete~1ay%kV~8882 */
  twobit_setrtn( 1703, compiled_block_1_1703 );
  twobit_invoke( 3 );
  twobit_label( 1703, compiled_block_1_1703 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1704, compiled_block_1_1704 );
  twobit_invoke( 1 );
  twobit_label( 1704, compiled_block_1_1704 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_branchf_624( 4, 1706, compiled_block_1_1706 ); /* internal:branchf-eq? */
  twobit_stack( 1 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1706, compiled_block_1_1706 );
  twobit_stack( 3 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1702, compiled_block_1_1702 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_78( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1709, compiled_block_1_1709 ); /* internal:branchf-pair? */
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 1708, compiled_block_1_1708 );
  twobit_label( 1709, compiled_block_1_1709 );
  twobit_global( 1 ); /* equal? */
  twobit_label( 1708, compiled_block_1_1708 );
  twobit_setreg( 4 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 4, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_174, 4, 2 );
  twobit_setreg( 4 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_174( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1710, compiled_block_1_1710 );
  twobit_invoke( 1 );
  twobit_label( 1710, compiled_block_1_1710 );
  twobit_load( 0, 0 );
  twobit_branchf( 1712, compiled_block_1_1712 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1712, compiled_block_1_1712 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1713, compiled_block_1_1713 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_movereg( 4, 1 );
  twobit_movereg( 3, 2 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  delete!~1ay%kV~8883 */
  twobit_setrtn( 1714, compiled_block_1_1714 );
  twobit_invoke( 3 );
  twobit_label( 1714, compiled_block_1_1714 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1715, compiled_block_1_1715 );
  twobit_invoke( 1 );
  twobit_label( 1715, compiled_block_1_1715 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_branchf_624( 4, 1717, compiled_block_1_1717 ); /* internal:branchf-eq? */
  twobit_op1_3(); /* unspecified */
  twobit_skip( 1716, compiled_block_1_1716 );
  twobit_label( 1717, compiled_block_1_1717 );
  twobit_stack( 1 );
  twobit_op2_60( 4 ); /* set-cdr! */
  twobit_label( 1716, compiled_block_1_1716 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1713, compiled_block_1_1713 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_79( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1720, compiled_block_1_1720 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 1719, compiled_block_1_1719 );
  twobit_label( 1720, compiled_block_1_1720 );
  twobit_global( 1 ); /* equal? */
  twobit_label( 1719, compiled_block_1_1719 );
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_173, 3, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /*  find~1ay%kV~8892 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_173( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op1_check_652(reg(1),1721,compiled_block_1_1721); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_invoke( 2 );
  twobit_label( 1721, compiled_block_1_1721 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_80( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_reg( 1 );
  twobit_op2_58( 2 ); /* cons */
  twobit_op2_58( 3 ); /* cons */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_81( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_movereg( 1, 2 );
  twobit_lambda( compiled_start_1_172, 2, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  map~1ay%kV~8874 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_172( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_reg_op1_check_652(reg(1),1724,compiled_block_1_1724); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_op2_58( 4 ); /* cons */
  twobit_return();
  twobit_label( 1724, compiled_block_1_1724 );
  twobit_trap( 1, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_82( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1727, compiled_block_1_1727 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 1726, compiled_block_1_1726 );
  twobit_label( 1727, compiled_block_1_1727 );
  twobit_global( 1 ); /* equal? */
  twobit_label( 1726, compiled_block_1_1726 );
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_171, 3, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /*  filter~1ay%kV~8876 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_171( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_reg_op1_check_652(reg(1),1728,compiled_block_1_1728); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1729, compiled_block_1_1729 );
  twobit_invoke( 2 );
  twobit_label( 1729, compiled_block_1_1729 );
  twobit_load( 0, 0 );
  twobit_op1_9(); /* not */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1728, compiled_block_1_1728 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_83( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1732, compiled_block_1_1732 ); /* internal:branchf-pair? */
  twobit_reg( 3 );
  twobit_op1_404(); /* car:pair */
  twobit_skip( 1731, compiled_block_1_1731 );
  twobit_label( 1732, compiled_block_1_1732 );
  twobit_global( 1 ); /* equal? */
  twobit_label( 1731, compiled_block_1_1731 );
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_170, 3, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 4 ); /*  filter!~1ay%kV~8877 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_170( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_reg_op1_check_652(reg(1),1733,compiled_block_1_1733); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1734, compiled_block_1_1734 );
  twobit_invoke( 2 );
  twobit_label( 1734, compiled_block_1_1734 );
  twobit_load( 0, 0 );
  twobit_op1_9(); /* not */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1733, compiled_block_1_1733 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_84( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_global( 1 ); /*  find-tail~1ay%kV~8893 */
  twobit_setrtn( 1736, compiled_block_1_1736 );
  twobit_invoke( 2 );
  twobit_label( 1736, compiled_block_1_1736 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1738, compiled_block_1_1738 );
  twobit_reg_op1_check_652(reg(4),1739,compiled_block_1_1739); /* internal:check-pair? with (4 0 0) */
  twobit_reg( 4 );
  twobit_op1_404(); /* car:pair */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1738, compiled_block_1_1738 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 0 );
  twobit_return();
  twobit_label( 1739, compiled_block_1_1739 );
  twobit_trap( 4, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_85( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_169, 3, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_169( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1740, compiled_block_1_1740 );
  twobit_invoke( 1 );
  twobit_label( 1740, compiled_block_1_1740 );
  twobit_load( 0, 0 );
  twobit_branchf( 1742, compiled_block_1_1742 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1742, compiled_block_1_1742 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1743, compiled_block_1_1743 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1744, compiled_block_1_1744 );
  twobit_invoke( 1 );
  twobit_label( 1744, compiled_block_1_1744 );
  twobit_load( 0, 0 );
  twobit_branchf( 1746, compiled_block_1_1746 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1746, compiled_block_1_1746 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1743, compiled_block_1_1743 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_86( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_168, 3, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_168( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1749, compiled_block_1_1749 );
  twobit_invoke( 1 );
  twobit_label( 1749, compiled_block_1_1749 );
  twobit_load( 0, 0 );
  twobit_branchf( 1751, compiled_block_1_1751 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1751, compiled_block_1_1751 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1752, compiled_block_1_1752 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1753, compiled_block_1_1753 );
  twobit_invoke( 1 );
  twobit_label( 1753, compiled_block_1_1753 );
  twobit_load( 0, 0 );
  twobit_branchf( 1755, compiled_block_1_1755 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_setrtn( 1756, compiled_block_1_1756 );
  twobit_invoke( 1 );
  twobit_label( 1756, compiled_block_1_1756 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1755, compiled_block_1_1755 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1752, compiled_block_1_1752 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_87( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_167, 3, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_167( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1758, compiled_block_1_1758 );
  twobit_invoke( 1 );
  twobit_label( 1758, compiled_block_1_1758 );
  twobit_load( 0, 0 );
  twobit_branchf( 1760, compiled_block_1_1760 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1760, compiled_block_1_1760 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1761, compiled_block_1_1761 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1762, compiled_block_1_1762 );
  twobit_invoke( 1 );
  twobit_label( 1762, compiled_block_1_1762 );
  twobit_load( 0, 0 );
  twobit_branchf( 1764, compiled_block_1_1764 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_label( 1764, compiled_block_1_1764 );
  twobit_stack( 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1761, compiled_block_1_1761 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_88( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1767, compiled_block_1_1767 );
  twobit_invoke( 1 );
  twobit_label( 1767, compiled_block_1_1767 );
  twobit_load( 0, 0 );
  twobit_branchf( 1769, compiled_block_1_1769 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1768, compiled_block_1_1768 );
  twobit_label( 1769, compiled_block_1_1769 );
  twobit_stack( 1 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 2, 2 );
  twobit_check( 2, 0, 0, 1770, compiled_block_1_1770 );
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1771, compiled_block_1_1771 );
  twobit_invoke( 1 );
  twobit_label( 1771, compiled_block_1_1771 );
  twobit_load( 0, 0 );
  twobit_branchf( 1773, compiled_block_1_1773 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1768, compiled_block_1_1768 );
  twobit_label( 1773, compiled_block_1_1773 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_label( 1768, compiled_block_1_1768 );
  twobit_branchf( 1775, compiled_block_1_1775 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1775, compiled_block_1_1775 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 2 );
  twobit_check( 3, 0, 0, 1776, compiled_block_1_1776 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_global( 2 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_166, 4, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_reg( 4 );
  twobit_setrtn( 1783, compiled_block_1_1783 );
  twobit_invoke( 2 );
  twobit_label( 1783, compiled_block_1_1783 );
  twobit_load( 0, 0 );
  twobit_stack( 2 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1776, compiled_block_1_1776 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_label( 1770, compiled_block_1_1770 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_166( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_branchf_611( 1778, compiled_block_1_1778 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1779, compiled_block_1_1779 );
  twobit_invoke( 1 );
  twobit_label( 1779, compiled_block_1_1779 );
  twobit_load( 0, 0 );
  twobit_branchf( 1781, compiled_block_1_1781 );
  twobit_load( 1, 1 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1781, compiled_block_1_1781 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_60( 4 ); /* set-cdr! */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1778, compiled_block_1_1778 );
  twobit_op1_3(); /* unspecified */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_89( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_163, 3, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_163( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1784, compiled_block_1_1784 );
  twobit_invoke( 1 );
  twobit_label( 1784, compiled_block_1_1784 );
  twobit_load( 0, 0 );
  twobit_branchf( 1786, compiled_block_1_1786 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 2 ); /* values */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1786, compiled_block_1_1786 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1788, compiled_block_1_1788 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1789, compiled_block_1_1789 );
  twobit_invoke( 1 );
  twobit_label( 1789, compiled_block_1_1789 );
  twobit_load( 0, 0 );
  twobit_branchf( 1791, compiled_block_1_1791 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_164, 4, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 3 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_165, 6, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 3 );
  twobit_global( 7 ); /* call-with-values */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1791, compiled_block_1_1791 );
  twobit_load( 2, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_global( 2 ); /* values */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1788, compiled_block_1_1788 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_164( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_165( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lexical( 0, 1 );
  twobit_op2_58( 1 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_90( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1797, compiled_block_1_1797 );
  twobit_invoke( 1 );
  twobit_label( 1797, compiled_block_1_1797 );
  twobit_load( 0, 0 );
  twobit_branchf( 1799, compiled_block_1_1799 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1798, compiled_block_1_1798 );
  twobit_label( 1799, compiled_block_1_1799 );
  twobit_stack( 1 );
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 2, 2 );
  twobit_check( 2, 0, 0, 1800, compiled_block_1_1800 );
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_reg( 4 );
  twobit_setrtn( 1801, compiled_block_1_1801 );
  twobit_invoke( 1 );
  twobit_label( 1801, compiled_block_1_1801 );
  twobit_load( 0, 0 );
  twobit_branchf( 1803, compiled_block_1_1803 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_skip( 1798, compiled_block_1_1798 );
  twobit_label( 1803, compiled_block_1_1803 );
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_label( 1798, compiled_block_1_1798 );
  twobit_branchf( 1805, compiled_block_1_1805 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 2 ); /* values */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1805, compiled_block_1_1805 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 2 );
  twobit_check( 3, 0, 0, 1807, compiled_block_1_1807 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_global( 3 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_load( 2, 1 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_162, 5, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_reg( 4 );
  twobit_setrtn( 1816, compiled_block_1_1816 );
  twobit_invoke( 2 );
  twobit_label( 1816, compiled_block_1_1816 );
  twobit_load( 0, 0 );
  twobit_setreg( 2 );
  twobit_load( 1, 2 );
  twobit_global( 2 ); /* values */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1807, compiled_block_1_1807 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_label( 1800, compiled_block_1_1800 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_162( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1808, compiled_block_1_1808 );
  twobit_invoke( 1 );
  twobit_label( 1808, compiled_block_1_1808 );
  twobit_load( 0, 0 );
  twobit_branchf( 1810, compiled_block_1_1810 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1810, compiled_block_1_1810 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1811, compiled_block_1_1811 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1812, compiled_block_1_1812 );
  twobit_invoke( 1 );
  twobit_label( 1812, compiled_block_1_1812 );
  twobit_load( 0, 0 );
  twobit_branchf( 1814, compiled_block_1_1814 );
  twobit_load( 1, 1 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1814, compiled_block_1_1814 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 4 );
  twobit_stack( 2 );
  twobit_op2_60( 4 ); /* set-cdr! */
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1811, compiled_block_1_1811 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_91( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lambda( compiled_start_1_161, 2, 1 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  span~1ay%kV~8897 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_161( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1818, compiled_block_1_1818 );
  twobit_invoke( 1 );
  twobit_label( 1818, compiled_block_1_1818 );
  twobit_load( 0, 0 );
  twobit_op1_9(); /* not */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_92( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lambda( compiled_start_1_160, 2, 1 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  span!~1ay%kV~8898 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_160( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1820, compiled_block_1_1820 );
  twobit_invoke( 1 );
  twobit_label( 1820, compiled_block_1_1820 );
  twobit_load( 0, 0 );
  twobit_op1_9(); /* not */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_93( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1823, compiled_block_1_1823 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_154, 2, 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_155, 4, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1823, compiled_block_1_1823 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 6 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1838, compiled_block_1_1838 );
  twobit_invoke( 1 );
  twobit_label( 1838, compiled_block_1_1838 );
  twobit_load( 0, 0 );
  twobit_branchf( 1840, compiled_block_1_1840 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1840, compiled_block_1_1840 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1841, compiled_block_1_1841 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_global( 7 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_156, 9, 2 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1841, compiled_block_1_1841 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_154( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %cars+cdrs~1ay%kV~8855 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_155( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1826, compiled_block_1_1826 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_157, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1826, compiled_block_1_1826 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_157( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_158, 2, 1 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_159, 4, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_158( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %cars+cdrs~1ay%kV~8855 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_159( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1829, compiled_block_1_1829 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_lexical( 2, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /* apply */
  twobit_setrtn( 1830, compiled_block_1_1830 );
  twobit_invoke( 2 );
  twobit_label( 1830, compiled_block_1_1830 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1832, compiled_block_1_1832 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1832, compiled_block_1_1832 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1829, compiled_block_1_1829 );
  twobit_lexical( 2, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /* apply */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_156( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1842, compiled_block_1_1842 );
  twobit_invoke( 1 );
  twobit_label( 1842, compiled_block_1_1842 );
  twobit_load( 0, 0 );
  twobit_branchf( 1844, compiled_block_1_1844 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 2 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1844, compiled_block_1_1844 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1846, compiled_block_1_1846 );
  twobit_invoke( 1 );
  twobit_label( 1846, compiled_block_1_1846 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1848, compiled_block_1_1848 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1848, compiled_block_1_1848 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 2 );
  twobit_check( 3, 0, 0, 1849, compiled_block_1_1849 );
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1849, compiled_block_1_1849 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_94( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1853, compiled_block_1_1853 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_148, 2, 2 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_149, 4, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1853, compiled_block_1_1853 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 2, 1 );
  twobit_global( 6 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1868, compiled_block_1_1868 );
  twobit_invoke( 1 );
  twobit_label( 1868, compiled_block_1_1868 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1870, compiled_block_1_1870 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1870, compiled_block_1_1870 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1871, compiled_block_1_1871 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 3 );
  twobit_global( 7 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_load( 2, 2 );
  twobit_movereg( 3, 1 );
  twobit_lambda( compiled_start_1_150, 9, 2 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 2 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 3 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1871, compiled_block_1_1871 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_148( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 4 );
  twobit_lexical( 0, 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %cars+cdrs~1ay%kV~8855 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_149( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_11(); /* pair? */
  twobit_op1_9(); /* not */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_branchf( 1856, compiled_block_1_1856 );
  twobit_reg( 4 );
  twobit_return();
  twobit_label( 1856, compiled_block_1_1856 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_151, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_151( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_152, 2, 1 );
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_lambda( compiled_start_1_153, 4, 1 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_152( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %cars+cdrs~1ay%kV~8855 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_153( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1859, compiled_block_1_1859 ); /* internal:branchf-pair? */
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_lexical( 2, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /* apply */
  twobit_setrtn( 1860, compiled_block_1_1860 );
  twobit_invoke( 2 );
  twobit_label( 1860, compiled_block_1_1860 );
  twobit_load( 0, 0 );
  twobit_branchf( 1862, compiled_block_1_1862 );
  twobit_lexical( 1, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1862, compiled_block_1_1862 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1859, compiled_block_1_1859 );
  twobit_lexical( 2, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 1 ); /* apply */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_150( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_movereg( 2, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1872, compiled_block_1_1872 );
  twobit_invoke( 1 );
  twobit_label( 1872, compiled_block_1_1872 );
  twobit_load( 0, 0 );
  twobit_branchf( 1874, compiled_block_1_1874 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 2 );
  twobit_pop( 2 );
  twobit_invoke( 1 );
  twobit_label( 1874, compiled_block_1_1874 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 2 );
  twobit_setrtn( 1876, compiled_block_1_1876 );
  twobit_invoke( 1 );
  twobit_label( 1876, compiled_block_1_1876 );
  twobit_load( 0, 0 );
  twobit_branchf( 1878, compiled_block_1_1878 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 2 );
  twobit_check( 3, 0, 0, 1879, compiled_block_1_1879 );
  twobit_stack( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1878, compiled_block_1_1878 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1879, compiled_block_1_1879 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_95( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_reg( 3 );
  twobit_op1_branchf_611( 1883, compiled_block_1_1883 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_reg( 2 );
  twobit_op2_58( 3 ); /* cons */
  twobit_setreg( 4 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_1_142, 3, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 4, 1 );
  twobit_load( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1883, compiled_block_1_1883 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 2 );
  twobit_lambda( compiled_start_1_143, 5, 2 );
  twobit_setreg( 3 );
  twobit_load( 1, 1 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_imm_const( fixnum(0) ); /* 0 */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_142( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_145, 2, 1 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_146, 4, 1 );
  twobit_setreg( 2 );
  twobit_load( 1, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_145( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %cars+cdrs~1ay%kV~8855 */
  twobit_invoke( 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_146( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_611( 1886, compiled_block_1_1886 ); /* internal:branchf-pair? */
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /* apply */
  twobit_setrtn( 1887, compiled_block_1_1887 );
  twobit_invoke( 2 );
  twobit_label( 1887, compiled_block_1_1887 );
  twobit_load( 0, 0 );
  twobit_branchf( 1889, compiled_block_1_1889 );
  twobit_lexical( 0, 1 );
  twobit_pop( 1 );
  twobit_return();
  twobit_label( 1889, compiled_block_1_1889 );
  twobit_load( 1, 1 );
  twobit_lexical( 0, 1 );
  twobit_op2imm_130( fixnum(1), 147, compiled_temp_1_147 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 1, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_label( 1886, compiled_block_1_1886 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_143( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_store( 2, 2 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1893, compiled_block_1_1893 );
  twobit_invoke( 1 );
  twobit_label( 1893, compiled_block_1_1893 );
  twobit_load( 0, 0 );
  twobit_branchf( 1895, compiled_block_1_1895 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1895, compiled_block_1_1895 );
  twobit_stack( 1 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 1 );
  twobit_check( 3, 0, 0, 1896, compiled_block_1_1896 );
  twobit_stack( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setrtn( 1897, compiled_block_1_1897 );
  twobit_invoke( 1 );
  twobit_label( 1897, compiled_block_1_1897 );
  twobit_load( 0, 0 );
  twobit_branchf( 1899, compiled_block_1_1899 );
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1899, compiled_block_1_1899 );
  twobit_stack( 1 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 1 );
  twobit_stack( 2 );
  twobit_op2imm_130( fixnum(1), 144, compiled_temp_1_144 ); /* + */
  twobit_setreg( 2 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1896, compiled_block_1_1896 );
  twobit_trap( 3, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_96( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_141, 3, 1 );
  twobit_setreg( 3 );
  twobit_reg( 4 );
  twobit_op2_84( 3 ); /* cell-set! */
  twobit_reg( 4 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_reg( 4 );
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_141( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setrtn( 1902, compiled_block_1_1902 );
  twobit_invoke( 1 );
  twobit_label( 1902, compiled_block_1_1902 );
  twobit_load( 0, 0 );
  twobit_branchf( 1904, compiled_block_1_1904 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1904, compiled_block_1_1904 );
  twobit_stack( 2 );
  twobit_op1_11(); /* pair? */
  twobit_load( 3, 2 );
  twobit_check( 3, 0, 0, 1905, compiled_block_1_1905 );
  twobit_stack( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_load( 3, 1 );
  twobit_stack( 2 );
  twobit_op2_60( 3 ); /* set-cdr! */
  twobit_movereg( 4, 1 );
  twobit_load( 2, 2 );
  twobit_lexical( 0, 1 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1905, compiled_block_1_1905 );
  twobit_trap( 3, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_97( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 3 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_1_140, 2, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 3 ); /*  every~1ay%kV~8902 */
  twobit_pop( 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_140( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  member~1ay%kV~8884 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_98( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_reg( 2 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_9(); /* not */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_branchf( 1911, compiled_block_1_1911 );
  twobit_reg( 3 );
  twobit_return();
  twobit_label( 1911, compiled_block_1_1911 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_reg( 4 );
  twobit_check( 2, 0, 0, 1912, compiled_block_1_1912 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_1_139, 3, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 4, 1 );
  twobit_load( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1912, compiled_block_1_1912 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_139( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_9(); /* not */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_branchf( 1914, compiled_block_1_1914 );
  twobit_reg( 3 );
  twobit_return();
  twobit_label( 1914, compiled_block_1_1914 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_reg( 4 );
  twobit_check( 2, 0, 0, 1915, compiled_block_1_1915 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 1 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 3 );
  twobit_op2_branchf_624( 1, 1917, compiled_block_1_1917 ); /* internal:branchf-eq? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1916, compiled_block_1_1916 );
  twobit_label( 1917, compiled_block_1_1917 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %lset2<=~1ay%kV~8905 */
  twobit_setrtn( 1918, compiled_block_1_1918 );
  twobit_invoke( 3 );
  twobit_label( 1918, compiled_block_1_1918 );
  twobit_load( 0, 0 );
  twobit_label( 1916, compiled_block_1_1916 );
  twobit_branchf( 1920, compiled_block_1_1920 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1920, compiled_block_1_1920 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1915, compiled_block_1_1915 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_99( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_reg( 2 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_9(); /* not */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_branchf( 1924, compiled_block_1_1924 );
  twobit_reg( 3 );
  twobit_return();
  twobit_label( 1924, compiled_block_1_1924 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_reg( 4 );
  twobit_check( 2, 0, 0, 1925, compiled_block_1_1925 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 2 );
  twobit_store( 2, 2 );
  twobit_global( 1 ); /* ex:undefined */
  twobit_op1_52(); /* make-cell */
  twobit_setreg( 3 );
  twobit_movereg( 3, 2 );
  twobit_lambda( compiled_start_1_138, 3, 2 );
  twobit_setreg( 1 );
  twobit_store( 1, 1 );
  twobit_movereg( 4, 1 );
  twobit_load( 4, 1 );
  twobit_reg( 3 );
  twobit_op2_84( 4 ); /* cell-set! */
  twobit_reg( 3 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 2, 2 );
  twobit_reg( 4 );
  twobit_pop( 2 );
  twobit_invoke( 2 );
  twobit_label( 1925, compiled_block_1_1925 );
  twobit_trap( 2, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_138( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 2 );
  twobit_op1_11(); /* pair? */
  twobit_setreg( 4 );
  twobit_reg( 4 );
  twobit_op1_9(); /* not */
  twobit_setreg( 3 );
  twobit_reg( 3 );
  twobit_branchf( 1927, compiled_block_1_1927 );
  twobit_reg( 3 );
  twobit_return();
  twobit_label( 1927, compiled_block_1_1927 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_reg( 4 );
  twobit_check( 2, 0, 0, 1928, compiled_block_1_1928 );
  twobit_reg( 2 );
  twobit_op1_405(); /* cdr:pair */
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 2 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 3 );
  twobit_store( 3, 2 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 3, 1930, compiled_block_1_1930 ); /* internal:branchf-eq? */
  twobit_imm_const( TRUE_CONST ); /* #t */
  twobit_skip( 1929, compiled_block_1_1929 );
  twobit_label( 1930, compiled_block_1_1930 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_global( 1 ); /*  %lset2<=~1ay%kV~8905 */
  twobit_setrtn( 1931, compiled_block_1_1931 );
  twobit_invoke( 3 );
  twobit_label( 1931, compiled_block_1_1931 );
  twobit_load( 0, 0 );
  twobit_branchf( 1933, compiled_block_1_1933 );
  twobit_load( 3, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_load( 2, 2 );
  twobit_global( 1 ); /*  %lset2<=~1ay%kV~8905 */
  twobit_setrtn( 1934, compiled_block_1_1934 );
  twobit_invoke( 3 );
  twobit_label( 1934, compiled_block_1_1934 );
  twobit_load( 0, 0 );
  twobit_skip( 1929, compiled_block_1_1929 );
  twobit_label( 1933, compiled_block_1_1933 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_label( 1929, compiled_block_1_1929 );
  twobit_branchf( 1936, compiled_block_1_1936 );
  twobit_load( 2, 3 );
  twobit_lexical( 0, 2 );
  twobit_op1_54(); /* cell-ref */
  twobit_setreg( 4 );
  twobit_load( 1, 2 );
  twobit_reg( 4 );
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 1936, compiled_block_1_1936 );
  twobit_imm_const( FALSE_CONST ); /* #f */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1928, compiled_block_1_1928 );
  twobit_trap( 2, 0, 0, 1 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_100( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_lambda( compiled_start_1_137, 2, 1 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  fold~1ay%kV~8861 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_137( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  member~1ay%kV~8884 */
  twobit_setrtn( 1939, compiled_block_1_1939 );
  twobit_invoke( 3 );
  twobit_label( 1939, compiled_block_1_1939 );
  twobit_load( 0, 0 );
  twobit_branchf( 1941, compiled_block_1_1941 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1941, compiled_block_1_1941 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_101( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_movereg( 2, 3 );
  twobit_lambda( compiled_start_1_134, 2, 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  reduce~1ay%kV~8865 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_134( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1944, compiled_block_1_1944 ); /* internal:branchf-null? */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1944, compiled_block_1_1944 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1946, compiled_block_1_1946 ); /* internal:branchf-null? */
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1946, compiled_block_1_1946 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 2, 1948, compiled_block_1_1948 ); /* internal:branchf-eq? */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1948, compiled_block_1_1948 );
  twobit_movereg( 1, 3 );
  twobit_lambda( compiled_start_1_135, 2, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  fold~1ay%kV~8861 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_135( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_lambda( compiled_start_1_136, 2, 1 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  any~1ay%kV~8901 */
  twobit_setrtn( 1950, compiled_block_1_1950 );
  twobit_invoke( 2 );
  twobit_label( 1950, compiled_block_1_1950 );
  twobit_load( 0, 0 );
  twobit_branchf( 1952, compiled_block_1_1952 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1952, compiled_block_1_1952 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_136( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 2, 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_102( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_movereg( 2, 3 );
  twobit_lambda( compiled_start_1_131, 2, 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  reduce~1ay%kV~8865 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_131( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 1956, compiled_block_1_1956 ); /* internal:branchf-null? */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1956, compiled_block_1_1956 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 1958, compiled_block_1_1958 ); /* internal:branchf-null? */
  twobit_reg( 1 );
  twobit_return();
  twobit_label( 1958, compiled_block_1_1958 );
  twobit_reg( 1 );
  twobit_op2_branchf_624( 2, 1960, compiled_block_1_1960 ); /* internal:branchf-eq? */
  twobit_reg( 2 );
  twobit_return();
  twobit_label( 1960, compiled_block_1_1960 );
  twobit_movereg( 1, 3 );
  twobit_lambda( compiled_start_1_132, 2, 0 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  pair-fold~1ay%kV~8864 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_132( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_reg_op1_check_652(reg(1),1961,compiled_block_1_1961); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 4 );
  twobit_movereg( 4, 1 );
  twobit_lambda( compiled_start_1_133, 2, 1 );
  twobit_setreg( 1 );
  twobit_global( 3 ); /*  any~1ay%kV~8901 */
  twobit_setrtn( 1963, compiled_block_1_1963 );
  twobit_invoke( 2 );
  twobit_label( 1963, compiled_block_1_1963 );
  twobit_load( 0, 0 );
  twobit_branchf( 1965, compiled_block_1_1965 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1965, compiled_block_1_1965 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_op2_60( 4 ); /* set-cdr! */
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 1961, compiled_block_1_1961 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_133( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 2, 1 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_103( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_load( 1, 1 );
  twobit_global( 1 ); /* eq? */
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  delete~1ay%kV~8882 */
  twobit_setrtn( 1968, compiled_block_1_1968 );
  twobit_invoke( 3 );
  twobit_label( 1968, compiled_block_1_1968 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 2 );
  twobit_global( 3 ); /*  null-list?~1ay%kV~8818 */
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  any~1ay%kV~8901 */
  twobit_setrtn( 1969, compiled_block_1_1969 );
  twobit_invoke( 2 );
  twobit_label( 1969, compiled_block_1_1969 );
  twobit_load( 0, 0 );
  twobit_branchf( 1971, compiled_block_1_1971 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1971, compiled_block_1_1971 );
  twobit_stack( 2 );
  twobit_op1_branchf_610( 1973, compiled_block_1_1973 ); /* internal:branchf-null? */
  twobit_stack( 1 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1973, compiled_block_1_1973 );
  twobit_load( 2, 3 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_129, 6, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 7 ); /*  filter~1ay%kV~8876 */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_129( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_130, 2, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  every~1ay%kV~8902 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_130( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  member~1ay%kV~8884 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_104( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_load( 1, 1 );
  twobit_global( 1 ); /* eq? */
  twobit_setreg( 3 );
  twobit_global( 2 ); /*  delete~1ay%kV~8882 */
  twobit_setrtn( 1977, compiled_block_1_1977 );
  twobit_invoke( 3 );
  twobit_label( 1977, compiled_block_1_1977 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 2 );
  twobit_movereg( 4, 2 );
  twobit_global( 3 ); /*  null-list?~1ay%kV~8818 */
  twobit_setreg( 1 );
  twobit_global( 4 ); /*  any~1ay%kV~8901 */
  twobit_setrtn( 1978, compiled_block_1_1978 );
  twobit_invoke( 2 );
  twobit_label( 1978, compiled_block_1_1978 );
  twobit_load( 0, 0 );
  twobit_branchf( 1980, compiled_block_1_1980 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1980, compiled_block_1_1980 );
  twobit_stack( 2 );
  twobit_op1_branchf_610( 1982, compiled_block_1_1982 ); /* internal:branchf-null? */
  twobit_stack( 1 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1982, compiled_block_1_1982 );
  twobit_load( 2, 3 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_127, 6, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 7 ); /*  filter!~1ay%kV~8877 */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_127( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_128, 2, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  every~1ay%kV~8902 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_128( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  member~1ay%kV~8884 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_105( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_global( 1 ); /* pair? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  filter~1ay%kV~8876 */
  twobit_setrtn( 1986, compiled_block_1_1986 );
  twobit_invoke( 2 );
  twobit_label( 1986, compiled_block_1_1986 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_610( 1988, compiled_block_1_1988 ); /* internal:branchf-null? */
  twobit_stack( 1 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1988, compiled_block_1_1988 );
  twobit_load( 1, 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 3 ); /* memq */
  twobit_setrtn( 1989, compiled_block_1_1989 );
  twobit_invoke( 2 );
  twobit_label( 1989, compiled_block_1_1989 );
  twobit_load( 0, 0 );
  twobit_branchf( 1991, compiled_block_1_1991 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1991, compiled_block_1_1991 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_125, 5, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 2 ); /*  filter~1ay%kV~8876 */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_125( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_126, 2, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  every~1ay%kV~8902 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_126( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  member~1ay%kV~8884 */
  twobit_setrtn( 1992, compiled_block_1_1992 );
  twobit_invoke( 3 );
  twobit_label( 1992, compiled_block_1_1992 );
  twobit_load( 0, 0 );
  twobit_op1_9(); /* not */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_106( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_movereg( 3, 2 );
  twobit_global( 1 ); /* pair? */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  filter~1ay%kV~8876 */
  twobit_setrtn( 1995, compiled_block_1_1995 );
  twobit_invoke( 2 );
  twobit_label( 1995, compiled_block_1_1995 );
  twobit_load( 0, 0 );
  twobit_setreg( 4 );
  twobit_store( 4, 3 );
  twobit_reg( 4 );
  twobit_op1_branchf_610( 1997, compiled_block_1_1997 ); /* internal:branchf-null? */
  twobit_stack( 1 );
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 1997, compiled_block_1_1997 );
  twobit_load( 1, 1 );
  twobit_movereg( 4, 2 );
  twobit_global( 3 ); /* memq */
  twobit_setrtn( 1998, compiled_block_1_1998 );
  twobit_invoke( 2 );
  twobit_label( 1998, compiled_block_1_1998 );
  twobit_load( 0, 0 );
  twobit_branchf( 2000, compiled_block_1_2000 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_pop( 3 );
  twobit_return();
  twobit_label( 2000, compiled_block_1_2000 );
  twobit_load( 2, 2 );
  twobit_load( 1, 3 );
  twobit_lambda( compiled_start_1_123, 5, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 6 ); /*  filter!~1ay%kV~8877 */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_123( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_lambda( compiled_start_1_124, 2, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  every~1ay%kV~8902 */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_124( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  member~1ay%kV~8884 */
  twobit_setrtn( 2001, compiled_block_1_2001 );
  twobit_invoke( 3 );
  twobit_label( 2001, compiled_block_1_2001 );
  twobit_load( 0, 0 );
  twobit_op1_9(); /* not */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_107( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_movereg( 2, 3 );
  twobit_lambda( compiled_start_1_119, 2, 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  reduce~1ay%kV~8865 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_119( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lambda( compiled_start_1_120, 2, 2 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_121, 4, 2 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_120( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  lset-diff+intersection~1ay%kV~8917 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_121( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 2006, compiled_block_1_2006 ); /* internal:branchf-null? */
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  lset-difference~1ay%kV~8913 */
  twobit_invoke( 3 );
  twobit_label( 2006, compiled_block_1_2006 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 2009, compiled_block_1_2009 ); /* internal:branchf-null? */
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /* append */
  twobit_invoke( 2 );
  twobit_label( 2009, compiled_block_1_2009 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_122, 4, 1 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 5 ); /*  fold~1ay%kV~8861 */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_122( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 2, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  member~1ay%kV~8884 */
  twobit_setrtn( 2011, compiled_block_1_2011 );
  twobit_invoke( 3 );
  twobit_label( 2011, compiled_block_1_2011 );
  twobit_load( 0, 0 );
  twobit_branchf( 2013, compiled_block_1_2013 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2013, compiled_block_1_2013 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_op2_58( 4 ); /* cons */
  twobit_pop( 2 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_108( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 1 );
  twobit_movereg( 2, 3 );
  twobit_lambda( compiled_start_1_115, 2, 1 );
  twobit_setreg( 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  reduce~1ay%kV~8865 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_115( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_lambda( compiled_start_1_116, 2, 2 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_1_117, 4, 2 );
  twobit_setreg( 2 );
  twobit_movereg( 4, 1 );
  twobit_global( 5 ); /* call-with-values */
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_116( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  lset-diff+intersection!~1ay%kV~8918 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_117( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_reg( 1 );
  twobit_op1_branchf_610( 2019, compiled_block_1_2019 ); /* internal:branchf-null? */
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_lexical( 1, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  lset-difference!~1ay%kV~8914 */
  twobit_invoke( 3 );
  twobit_label( 2019, compiled_block_1_2019 );
  twobit_reg( 2 );
  twobit_op1_branchf_610( 2022, compiled_block_1_2022 ); /* internal:branchf-null? */
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 2 );
  twobit_setreg( 2 );
  twobit_global( 2 ); /*  append!~1ay%kV~8848 */
  twobit_invoke( 2 );
  twobit_label( 2022, compiled_block_1_2022 );
  twobit_save( 1 );
  twobit_store( 0, 0 );
  twobit_store( 1, 1 );
  twobit_movereg( 2, 1 );
  twobit_lambda( compiled_start_1_118, 4, 1 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 3 );
  twobit_global( 5 ); /*  pair-fold~1ay%kV~8864 */
  twobit_pop( 1 );
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_118( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 2 );
  twobit_save( 2 );
  twobit_store( 0, 0 );
  twobit_store( 1, 2 );
  twobit_store( 2, 1 );
  twobit_reg_op1_check_652(reg(1),2024,compiled_block_1_2024); /* internal:check-pair? with (1 0 0) */
  twobit_reg( 1 );
  twobit_op1_404(); /* car:pair */
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_lexical( 2, 1 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  member~1ay%kV~8884 */
  twobit_setrtn( 2025, compiled_block_1_2025 );
  twobit_invoke( 3 );
  twobit_label( 2025, compiled_block_1_2025 );
  twobit_load( 0, 0 );
  twobit_branchf( 2027, compiled_block_1_2027 );
  twobit_stack( 1 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2027, compiled_block_1_2027 );
  twobit_load( 4, 1 );
  twobit_stack( 2 );
  twobit_op2_60( 4 ); /* set-cdr! */
  twobit_stack( 2 );
  twobit_pop( 2 );
  twobit_return();
  twobit_label( 2024, compiled_block_1_2024 );
  twobit_trap( 1, 0, 0, 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_109( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_movereg( 3, 2 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  every~1ay%kV~8902 */
  twobit_setrtn( 2031, compiled_block_1_2031 );
  twobit_invoke( 2 );
  twobit_label( 2031, compiled_block_1_2031 );
  twobit_load( 0, 0 );
  twobit_branchf( 2033, compiled_block_1_2033 );
  twobit_load( 1, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 3 ); /* values */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 2033, compiled_block_1_2033 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 4 ); /* memq */
  twobit_setrtn( 2035, compiled_block_1_2035 );
  twobit_invoke( 2 );
  twobit_label( 2035, compiled_block_1_2035 );
  twobit_load( 0, 0 );
  twobit_branchf( 2037, compiled_block_1_2037 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 3 ); /* values */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 2037, compiled_block_1_2037 );
  twobit_load( 2, 3 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_113, 6, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 7 ); /*  partition~1ay%kV~8878 */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_113( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_114, 2, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  any~1ay%kV~8901 */
  twobit_setrtn( 2040, compiled_block_1_2040 );
  twobit_invoke( 2 );
  twobit_label( 2040, compiled_block_1_2040 );
  twobit_load( 0, 0 );
  twobit_op1_9(); /* not */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_114( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  member~1ay%kV~8884 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_110( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argsge( 2 );
  twobit_save( 3 );
  twobit_store( 0, 0 );
  twobit_store( 1, 3 );
  twobit_store( 2, 1 );
  twobit_store( 3, 2 );
  twobit_movereg( 3, 2 );
  twobit_global( 1 ); /*  null-list?~1ay%kV~8818 */
  twobit_setreg( 1 );
  twobit_global( 2 ); /*  every~1ay%kV~8902 */
  twobit_setrtn( 2042, compiled_block_1_2042 );
  twobit_invoke( 2 );
  twobit_label( 2042, compiled_block_1_2042 );
  twobit_load( 0, 0 );
  twobit_branchf( 2044, compiled_block_1_2044 );
  twobit_load( 1, 1 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 2 );
  twobit_global( 3 ); /* values */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 2044, compiled_block_1_2044 );
  twobit_load( 1, 1 );
  twobit_load( 2, 2 );
  twobit_global( 4 ); /* memq */
  twobit_setrtn( 2046, compiled_block_1_2046 );
  twobit_invoke( 2 );
  twobit_label( 2046, compiled_block_1_2046 );
  twobit_load( 0, 0 );
  twobit_branchf( 2048, compiled_block_1_2048 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 3 ); /* values */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_label( 2048, compiled_block_1_2048 );
  twobit_load( 2, 3 );
  twobit_load( 1, 2 );
  twobit_lambda( compiled_start_1_111, 6, 2 );
  twobit_setreg( 1 );
  twobit_load( 2, 1 );
  twobit_global( 7 ); /*  partition!~1ay%kV~8879 */
  twobit_pop( 3 );
  twobit_invoke( 2 );
  twobit_epilogue();
}


static RTYPE compiled_start_1_111( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_1_112, 2, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 2 );
  twobit_global( 3 ); /*  any~1ay%kV~8901 */
  twobit_setrtn( 2051, compiled_block_1_2051 );
  twobit_invoke( 2 );
  twobit_label( 2051, compiled_block_1_2051 );
  twobit_load( 0, 0 );
  twobit_op1_9(); /* not */
  twobit_pop( 0 );
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_1_112( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 1 );
  twobit_movereg( 1, 2 );
  twobit_lexical( 0, 1 );
  twobit_setreg( 1 );
  twobit_lexical( 1, 2 );
  twobit_setreg( 3 );
  twobit_global( 1 ); /*  member~1ay%kV~8884 */
  twobit_invoke( 3 );
  twobit_epilogue();
}


RTYPE twobit_thunk_41dd9f1f6d17df359b24d11ba546c680_0(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_1_0(CONT_ACTUALS));
}
static RTYPE compiled_block_2_1004( CONT_PARAMS );
static RTYPE compiled_block_2_1003( CONT_PARAMS );
static RTYPE compiled_start_2_0( CONT_PARAMS );
static RTYPE compiled_start_2_3( CONT_PARAMS );
static RTYPE compiled_start_2_2( CONT_PARAMS );
static RTYPE compiled_start_2_1( CONT_PARAMS );

static RTYPE compiled_start_2_0( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_save( 0 );
  twobit_store( 0, 0 );
  twobit_lambda( compiled_start_2_1, 2, 0 );
  twobit_setreg( 2 );
  twobit_lambda( compiled_start_2_2, 4, 0 );
  twobit_setreg( 4 );
  twobit_lambda( compiled_start_2_3, 6, 0 );
  twobit_setreg( 3 );
  twobit_movereg( 3, 7 );
  twobit_movereg( 4, 6 );
  twobit_const( 7 );
  twobit_setreg( 1 );
  twobit_const( 8 );
  twobit_setreg( 3 );
  twobit_const( 9 );
  twobit_setreg( 4 );
  twobit_const( 10 );
  twobit_setreg( 5 );
  twobit_const( 11 );
  twobit_setreg( 8 );
  twobit_global( 12 ); /* ex:make-library */
  twobit_setrtn( 1003, compiled_block_2_1003 );
  twobit_invoke( 8 );
  twobit_label( 1003, compiled_block_2_1003 );
  twobit_load( 0, 0 );
  twobit_setreg( 1 );
  twobit_global( 13 ); /* ex:register-library! */
  twobit_setrtn( 1004, compiled_block_2_1004 );
  twobit_invoke( 1 );
  twobit_label( 1004, compiled_block_2_1004 );
  twobit_load( 0, 0 );
  twobit_global( 14 ); /* values */
  twobit_pop( 0 );
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_1( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_imm_const( NIL_CONST ); /* () */
  twobit_return();
  twobit_epilogue();
}


static RTYPE compiled_start_2_2( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


static RTYPE compiled_start_2_3( CONT_PARAMS ) {
  twobit_prologue(); 
  twobit_argseq( 0 );
  twobit_global( 1 ); /* values */
  twobit_invoke( 0 );
  twobit_epilogue();
}


RTYPE twobit_thunk_41dd9f1f6d17df359b24d11ba546c680_1(CONT_PARAMS) {
  RETURN_RTYPE(compiled_start_2_0(CONT_ACTUALS));
}
codeptr_t CDECL twobit_load_table[] = { 
  twobit_thunk_41dd9f1f6d17df359b24d11ba546c680_0,
  twobit_thunk_41dd9f1f6d17df359b24d11ba546c680_1,
  0  /* The table may be empty; some compilers complain */
};
